#include <OfficePreCompBWP.hpp>

#ifdef BWP_EDITOR

#include "send_to_callback.h"
// BoraDoc.cpp: implementation of the BoraDoc class.
//
//////////////////////////////////////////////////////////////////////
#ifdef USE_SPL_MANAGER
#include "prscreenpagepainter.h"
#endif
#include "BrColor.h"
#include "WString.h"
#include "BwpConstants.h"
#include "bwAppStatic.h"
#include "bwAppConfig.h"
#include "ThreadDefines_i.h"
#include "bwTextProc.h"
#include "bwTextDraw.h"
#include "bwDrawUnit.h"
#include "bwCmdEngine.h"
#include "bwPage.h"
#include "bwField.h"
#include "bwFieldArray.h"
#include "bwFieldTime.h"
#include "bwPageNumItem.h"
#include "bwDataTransfer.h"
#include "bwCellList.h"
#include "bwSlideCustShow.h"
#include "butil.h"
#include "bwTableDrawInfo.h"
#include "bwHeaderFooter.h"
#include "bwordtobora.h"
#include "BrDrawObj.h"
#include "bwMediaInfo.h"
#include "bwFEEngine.h"
#include "bwLine.h"
#include "bwSectionArray.h"
#include "bwRange.h"
#include "drawing/officex_atomdef.h"
#include "drawing/officex_drawing.h"
#include "BrWordArt.h"
#include "bwStack.h"
#include "bwLocation.h"
#include "bwBorderLineInfo.h"
#include "bwStyleAtt.h"

#ifdef USE_RULERBAR
#include "bwRulerBar.h"
#endif//[2012.08.17][MistY]

#if defined(FOR_PPTX_EXPORT)
#include "brxmlstruct.h"
#endif

#include "SlideTextStyle/TextAtt/Engine/TextAttMergeSlideEngine.h"
#include "SlideTextStyle/ParaAtt/Engine/ParaAttMergeSlideEngine.h"

#include "bwGuide.h"
#include "bwTableEngine.h"

//Library
#include "packageBase.h"
#include "package_odf.h"

//Field
#include "bwFieldCaption.h"

#ifdef SUPPORT_DOCX_MATH
#include "Docx/Math/MathInterface.h"
#endif // SUPPORT_DOCX_MATH

#include <string.h>

//Ŭ������ �ҽ� �̵��� ���� ����
//#include "internal/PasteOption/POCBPasteOption.h"
//#include "POCBXMLEngine.h"
#include "../Bwp/frmw/duplication/include/PODuplication.h"
//
//���߿� �����ؾ��ϴ� �͵�
#include "bwLocation.h"
#include "bwCharPos.h"
#include "bwElement.h"
#include "bwTable.h"
#include "bwExpandCell.h"
#include "brdc2.h"

#ifdef BWP_EDITOR
#include "bwFindReplace.h"

#include "PainterBwp.h"
#include "post_threadapp_property.h"
#endif

#ifdef IMPORT_DOC //for MsWord
#include "bwordtobora.h"
#endif //IMPORT_DOC
#ifdef FOR_HWP30_EXPORT
#include "Hwp30/HwpExport.h"
#endif //FOR_HWP30_EXPORT
#ifdef IMPORT_GUL
#include "../../gul/HunToBoraX.h"
#endif //IMPORT_GUL

#ifdef IMPORT_DOCX
#include "DocXMain.h"
#endif
#ifdef FOR_DOCX_EXPORT
#include "DocxWriter_TC.h"
#endif

#ifdef IMPORT_ODT
#include "odt/OdtMain.h"
#endif  // IMPORT_ODT
#ifdef IMPORT_ODP
#include "odp/OdpMain.h"
#endif // IMPORT_ODP

#ifdef SUPPORT_BWP_FORMAT
#include "bwp/BwpFormatConverter.h"
#endif // SUPPORT_BWP_FORMAT

#ifdef XML_DECRYPTOR
#include "OfficeCrypto/Decryptor/XML/CXMLDecryptor.h"
#endif
#if defined(BWP_EDITOR) && defined(IMPORT_TXT)
#include "txt/TxtImport.h"
#endif  // defined(BWP_EDITOR) && defined(IMPORT_TXT)

#include "BFile.h"

#ifdef IMPORT_HTML
#include "HtmlStatic.h"
#include "HtmlLoader.h"
#include "HtmlPage.h"
#include "HtmlUtil.h"
#include "HtmlCharset.h"
#include "HtmlText.h"
#include "HtmlImage.h"
#include "HtmlAction.h"
#include "HtmlLoader.h"
#include "HtmlPaste.h"
#include "../html/Html/HtmlInterface.h"
#ifdef FOR_HTML_EXPORT
#include "HtmlWriter.h"
#endif
#ifdef USE_MIME
#include "MimeDec.h"
#endif //USE_MIME
#endif //IMPORT_HTML

#include "bwSequence.h"

/********PPT INCLUDE Start **********/

#ifdef PPT_EDITOR
#include "SlideSection.h"
#include "SlideEmbeddedFont.h"

#include "ppt/Export/ptExpLoader.h"
#ifdef FOR_PPT_EXPORT
#include "ppt/ptExpMgr.h"
#include "bwpPtFilterApi.h"
#endif//FOR_PPT_EXPORT
#ifdef FOR_PPTX_EXPORT//MistY - 2010.06.28
#include "pptx/ptxExpMgr.h"
#endif//FOR_PPTX_EXPORT
#include "bwCmdMgr/SlideCmdMgr/bwSlideCmdMgr.h"
#include "bwChart.h"
#include "bwChartShape.h"
#include "shtChartFuncApi.h"
#endif//PPT_EDITOR

//[2013.02.05][TID:#13197][�鿵��]PPT & PPTX �ܸ� �ӵ� ������ ���� ��� ������ ����
#ifdef SUPPORT_PPT_TIME_PROFILE
#include "ppt/CmLibrary/Profile/cmProfile.h"
#endif

#include "pptx/ptxDocument.h"
#include "ppt/ptDocument.h"

/********PPT INCLUDE END **********/
#ifdef IMPORT_RTF
#include "BRtfMain.h"
#endif

/*******HWP INCLUDE Start **********/
#ifdef IMPORT_HWP
#include "Common/Manager/HwpCoMgr.h"
#endif //IMPORT_HWP

#ifdef SUPPORT_HWP_EQUATION_EDIT
#include "hwpMathEngine.h"
#endif //SUPPORT_HWP_EQUATION_EDIT

#include "Hwp50/BodyText/ControlData/PageCtrl/Hwp50PageCtrl.h"

#ifdef USE_HWP_CONTROL
//#include "Hwp50/BodyText/ControlData/Clickhere/ClickhereArray.h"
#include "Hwp50/BodyText/ControlData/Clickhere/ClickHere.h"
#include "Hwp50/BodyText/ControlData/Clickhere/ClickHereHandler.h"
#include "OCXEngine/HwpControlCmdEngine.h"
#include "OCXEngine/CheckCaretPositionRestorer.h"
#endif // USE_HWP_CONTROL

#include "bwFieldEngine.h"

/*******HWP INCLUDE END **********/
//[2012.08.20][������][TID:7901] SummayInfo import/export ����.
#include "brXMLSummaryInfo.h"
#include "brSummaryInfoData.h"

#include "bmvinterface.h"
#include "bmvinterface_tool.h"
#include "loadolefile.h"
#include "bwpPPTFunc.h"

#ifdef HAN_CHN_CONV
#include "HanjaConv.h"
#endif

#ifdef USE_HUNSPELL
#include "brSpellCheckManager.h"

#endif
#ifdef USE_THEME
#include "BrTheme.h" //theme color
#endif //USE_THEME


#ifdef DANDONG_SMARTART_EDIT
#include "bwSmartArtEntry.h"
#endif // DANDONG_SMARTART_EDIT

#ifdef BWP_UNDO
#include "Data/Common/Frame/bwUndoMakeFrame.h"
#include "Data/Common/Frame/bwUndoFrameInfo2.h"
#include "Data/Common/Frame/POUndoResetFrame.h"
#include "Data/Common/Page/Frame/Chart/bwUndoChart.h"
#include "Data/Slide/MasterLayout/POUndoSlideMaster.h"
#include "Data/Common/Page/Frame/Line/CharSet/POUndoDeleteMarkData.h"
#endif //BWP_UNDO

#include "LowVision/LowVisionEngine.h"


#ifdef DOCX_DOCUMENT_PROTECTION
#include "OfficeCrypto/DocumentProtector/DocxDocumentProtector.h"
#endif

#ifdef SUPPORT_OOXML_PROTECTION
#include "OfficeCrypto/DocumentProtector/OOXMLWriteProtector.h"
#endif

#ifdef DOC_BINARY_ENCRYPTOR
#include "../Crypto/OfficeBinaryWordEncryptor.h"
#endif // DOC_BINARY_ENCRYPTOR

const char szHttp[] = "http://";

#ifndef NOT_USE_GLOBAL_VARIABLE
extern BrINT32	gnLCDWidth, gnLCDHeight;
#endif


#ifdef USE_COLLABORATION
#include "bwMakeCollborationJson.h"
#include "BWPCommonCollaborationManager.h"
#include "CollaborationProvider.h"
#endif // USE_COLLABORATION

#include "SPIDGenerator/bwSPIDGeneratorDocx.h"
#include "SPIDGenerator/bwSPIDGeneratorPptx.h"
#include "SPIDGenerator/bwSPIDGeneratorHwp.h"

#include "Frame/CellFrame.h"
#include "CKeyValue.h"
#include "Frame/FrameMove.h"
#include "Frame/text/FrameTextLayout.h"
#include "BoraDoc.h"
#include "ParaAtt/Handlers/PoParaAttHandler.h"
#include "TextAtt/Handlers/PoTextAttHandler.h"

#ifdef SUPPORT_PPT_TEXT_STYLE
#include "bwCmdMgr/SlideCmdMgr/bwSlideCmdMgr.h"
#include "bwSlideTxtStyle/bwSlideTxtStyle.h"
#endif
#include "Error/ErrorHandle.h"
#include "brmcoreproc.h"
#include "OfficeCrypto/OfficeCryptoContainer.h"
#include "Image/UrlImageContainer.h"
#include "SlideTextStyle/SlideTextStyles.h"
#include "SlideTextStyle/Engine/TextStyleCreatorDefault.h"
#include "ci_validator_interface.h"
#include "bwFontTableData.h"
#include "bwBatangPageArray.h"
#include "bwPageLayoutEngine.h"
#include "bwHeaderFooterEngine.h"
#ifdef SUPPORT_DOCX_MATH
#include "bwMathEngine.h"
#endif
#include "bwHandoutMaster.h"
#include "bwFrameList.h"
#include "FrameListForSearch.h"
#include "Frame/FrameIDGenerator.h"
#include "bwNoteMaster.h"
#include "bwPPTNoteMaster.h"
#include "bwODFPageStyle.h"
#include "bwODFSectionStyle.h"

#ifdef SUPPORT_MAIL_MERGE
#include "MailMerge/bwMailMerge.h"
#endif
#include "MailMerge/bwMailMergeDoc.h"
#include "SPIDGenerator/bwSPIDGeneratorBase.h"
#include "bwFrameSet.h"
#include "bwMemo.h"
#include "MemoEventManager.h"
#include "bwTypesetInfo.h"

#ifdef	BWP_UNDO
#include "Engine/bwUndoEngine.h"
#endif

#include "bwUndoContinueRestorer.h"
#include "bwCaret.h"

#include "Revision_defines.h"
#include "brImageArray.h"
#include "TextAtt/Data/Attributes/PoTextAttLanguage.h"
#include "bwCharSet.h"

#include "TextAtt/Handlers/PoTextAttHandler.h"
#include "ParaAtt/Handlers/PoParaAttHandler.h"

#include "StyleAtt/Handlers/PoStyleAttHandler.h"

#include "DocumentValidation/ValidationManager.h"

#ifdef SUPPORT_LOW_VISION_SHAPE
#include "LowVision/LowVisionEngine.h"
#endif

#ifdef SUPPORT_GRAPHIC_STYLE//misty- 2013.09.13
#include "brstyle.h"
#endif

#include "bfontex.h"
#include "bwFontArray.h"

#include "ptFilter.h"

#include "bwGrapAttDefault.h"
#include "font/font_descriptor.h"

#include "PrRawData.h"
// serialize data IO buf
//jkjung lpbyte g_pIOBuf = BrNULL;

// save element size
//(For BWP Viewer) int BoraDoc::m_nSave = 39;		// m_nDocFlag(4) + m_rcRAMargin(16) + m_nDirtyPage(4)...
//(For BWP Viewer) int BoraDoc::m_nSave = 39;		// m_nDocFlag(4) + m_rcRAMargin(16) + m_nDirtyPage(4)...
// const int	g_PenWidth = 40;	// 100% 72dpi -> 2pt

// Kinsoku Chars Tables
const unsigned short ChineseSimplifiedNoLineBreaksBefore[]
= {
	0x0021, 0x0025, 0x0029, 0x002C, 0x002E, 0x003A, 0x003B, 0x003E, 0x003F, 0x005D, 0x007D, 0x00A2, 0x00A8, 0x00B0, 0x00B7, 0x02C7,
	0x02C9, 0x2015, 0x2016, 0x2019, 0x201D, 0x2026, 0x2030, 0x2032, 0x2033, 0x203A, 0x2103, 0x2236, 0x3001, 0x3002, 0x3003, 0x3009,
	0x300B, 0x300D, 0x300F, 0x3011, 0x3015, 0x3017, 0x301E, 0xFE36, 0xFE3A, 0xFE3E, 0xFE40, 0xFE44, 0xFE5A, 0xFE5C, 0xFE5E, 0xFF01,
	0xFF02, 0xFF05, 0xFF07, 0xFF09, 0xFF0C, 0xFF0E, 0xFF1A, 0xFF1B, 0xFF1F, 0xFF3D, 0xFF40, 0xFF5C, 0xFF5D, 0xFF5E, 0xFFE0
};
const unsigned short ChineseSimplifiedNoLineBreaksAfter[]
= {
	0x0024, 0x0028, 0x005B, 0x007B, 0x00A3, 0x00A5, 0x00B7, 0x2018, 0x201C, 0x3008, 0x300A, 0x300C, 0x300E, 0x3010, 0x3014, 0x3016,
	0x301D, 0xFE59, 0xFE5B, 0xFE5D, 0xFF04, 0xFF08, 0xFF0E, 0xFF3B, 0xFF5B, 0xFFE1, 0xFFE5
};
const unsigned short ChineseTraditionalNoLineBreaksBefore[]
= {
	0x0021, 0x0029, 0x002C, 0x002E, 0x003A, 0x003B, 0x003F, 0x005D, 0x007D, 0x00A2, 0x00B7, 0x2013, 0x2014, 0x2019, 0x201D, 0x2022,
	0x2025, 0x2026, 0x2027, 0x2032, 0x2574, 0x3001, 0x3002, 0x3009, 0x300B, 0x300D, 0x300F, 0x3011, 0x3015, 0x301E, 0xFE30, 0xFE31,
	0xFE33, 0xFE34, 0xFE36, 0xFE38, 0xFE3A, 0xFE3C, 0xFE3E, 0xFE40, 0xFE42, 0xFE44, 0xFE4F, 0xFE50, 0xFE51, 0xFE52, 0xFE54, 0xFE55,
	0xFE56, 0xFE57, 0xFE5A, 0xFE5C, 0xFE5E, 0xFF01, 0xFF09, 0xFF0C, 0xFF0E, 0xFF1A, 0xFF1B, 0xFF1F, 0xFF3D, 0xFF5C, 0xFF5D, 0xFF64
};
const unsigned short ChineseTraditionalNoLineBreaksAfter[]
= {
	0x0028, 0x005B, 0x007B, 0x00A3, 0x00A5, 0x2018, 0x201C, 0x2035, 0x3008, 0x300A, 0x300C, 0x300E, 0x3010, 0x3014, 0x301D, 0xFE35,
	0xFE37, 0xFE39, 0xFE3B, 0xFE3D, 0xFE3F, 0xFE41, 0xFE43, 0xFE59, 0xFE5B, 0xFE5D, 0xFF08, 0xFF5B
};
const unsigned short JapaneseNoLineBreaksBefore[]
= {
	0x0021, 0x0025, 0x0029, 0x002C, 0x002E, 0x003A, 0x003B, 0x003F, 0x005D, 0x007D, 0x00A2, 0x00B0, 0x2019, 0x201D, 0x2030, 0x2032,
	0x2033, 0x2103, 0x3001, 0x3002, 0x3005, 0x3009, 0x300B, 0x300D, 0x300F, 0x3011, 0x3015, 0x309B, 0x309C, 0x309D, 0x309E, 0x30FB,
	0x30FD, 0x30FE, 0xFF01, 0xFF05, 0xFF09, 0xFF0C, 0xFF0E, 0xFF1A, 0xFF1B, 0xFF1F, 0xFF3D, 0xFF5D, 0xFF61, 0xFF63, 0xFF64, 0xFF65,
	0xFF9E, 0xFF9F, 0xFFE0
};
const unsigned short JapaneseNoLineBreaksAfter[]
= {
	0x0024, 0x0028, 0x005B, 0x005C, 0x007B, 0x00A3, 0x00A5, 0x2018, 0x201C, 0x3008, 0x300A, 0x300C, 0x300E, 0x3010, 0x3014, 0xFF04,
	0xFF08, 0xFF3B, 0xFF5B, 0xFF62, 0xFFE1, 0xFFE5
};
const unsigned short KoreanNoLineBreaksBefore[]
= {
	0x0021, 0x0025, 0x0029, 0x002C, 0x002E, 0x003A, 0x003B, 0x003F, 0x005D, 0x007D, 0x00A2, 0x00B0, 0x2019, 0x201D, 0x2032, 0x2033,
	0x2103, 0x3009, 0x300B, 0x300D, 0x300F, 0x3011, 0x3015, 0xFF01, 0xFF05, 0xFF09, 0xFF0C, 0xFF0E, 0xFF1A, 0xFF1B, 0xFF1F, 0xFF3D,
	0xFF5D, 0xFFE0
};
const unsigned short KoreanNoLineBreaksAfter[]
= {
	0x0024, 0x0028, 0x005B, 0x005C, 0x007B, 0x00A3, 0x00A5, 0x2018, 0x201C, 0x3008, 0x300A, 0x300C, 0x300E, 0x3010, 0x3014, 0xFF04,
	0xFF08, 0xFF3B, 0xFF5B, 0xFFE1, 0xFFE5, 0xFFE6
};
const unsigned short DefaultNoLineBreaksBefore[]
= {
	0x0021, 0x0025, 0x0029, 0x002C, 0x002E, 0x003A, 0x003B, 0x003F, 0x005D, 0x007D, 0x00A2, 0x00B0, 0x2019, 0x201D, 0x2030, 0x2032,
	0x2033, 0x2103, 0x3001, 0x3002, 0x3005, 0x3009, 0x300B, 0x300D, 0x300F, 0x3011, 0x3015, 0x3041, 0x3043, 0x3045, 0x3047, 0x3049,
	0x3063, 0x3083, 0x3085, 0x3087, 0x308E, 0x309B, 0x309C, 0x309D, 0x309E, 0x30A1, 0x30A3, 0x30A5, 0x30A7, 0x30A9, 0x30C3, 0x30E3,
	0x30E5, 0x30E7, 0x30EE, 0x30F5, 0x30F6, 0x30FB, 0x30FC, 0x30FD, 0x30FE, 0xFF01, 0xFF05, 0xFF09, 0xFF0C, 0xFF0E, 0xFF1A, 0xFF1B,
	0xFF1F, 0xFF3D, 0xFF5D, 0xFF61, 0xFF63, 0xFF64, 0xFF65, 0xFF67, 0xFF68, 0xFF69, 0xFF6A, 0xFF6B, 0xFF6C, 0xFF6D, 0xFF6E, 0xFF6F,
	0xFF70, 0xFF9E, 0xFF9F, 0xFFE0
};
const unsigned short DefaultNoLineBreaksAfter[]
= {
	0x0024, 0x0028, 0x005B, 0x005C, 0x007B, 0x00A3, 0x00A5, 0x2018, 0x201C, 0x3008, 0x300A, 0x300C, 0x300E, 0x3010, 0x3014, 0xFF04,
	0xFF08, 0xFF3B, 0xFF5B, 0xFF62, 0xFFE1, 0xFFE5
};

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
BoraDoc::BoraDoc(/*BoraView *pView*/)
{
	//g_pAppStatic = BrNEW CAppStatic;
	//g_pAppConfig = BrNEW CAppConfig;
	//	g_pSysFontInfo = BrNEW CSysFontInfo;
	// CTextProc::InitStatic();


	/*	jkjung
	// ���� BWordDoc�� View�� setting
	m_pView = pView;
	// ���� BWordView�� CmdEngine�� backward pointer�� �޾��ش�.
	pView->setCmdEngine(getCmdEngine());
	// ���� CmdEngine�� View�� setting
	getCmdEngine()->setView(pView);

	m_fileFilter = "Documents(*.bwp);;MS-Word(*.doc);;Text files(*.txt)";
	*/

	//Set global document pointer
	theBWordDoc = this;

	m_Pagination = BrNEW CPagination();
	m_FontArray = BrNEW CFontArray();
	m_FieldArray = BrNEW CFieldArray();
//#ifdef USE_HWP_CONTROL
	m_GrapAtt = BrNEW BrGrapAttDefault();
//#endif//#ifdef USE_HWP_CONTROL
	m_BatangPageArray = BrNEW CBatangPageArray();
	m_PageArray = BrNEW CPageArray();
	m_MstPageArray = BrNEW CPageArray();
	m_WebPageArray = BrNEW CPageArray();
	m_PageLayoutEngine = BrNEW CPageLayoutEngine();
	m_HeaderFooterEngine = BrNEW CHeaderFooterEngine(this);
#ifdef SUPPORT_DOCX_MATH
	m_MathEngine = BrNEW CMathEngine();
#endif//#ifdef SUPPORT_DOCX_MATH
	m_HandoutMaster = BrNEW CHandoutMaster();
	m_BulletArray = BrNEW CBulletArray();
	m_NumArray = BrNEW CBrNumArray();
	m_CmdEngine = BrNEW CCmdEngine();
	m_NoteMaster = BrNEW CNoteMaster();
	m_PPTNoteMaster = BrNEW CPPTNoteMaster();
	m_WordMultiPagePrint = BrNEW CWordMultiPagePrint();
	m_PageStyleArray = BrNEW CPageStyleArray();
	m_ODTPageRefArray = BrNEW CODTPageRefArray();
	m_ODTSectionRefArray = BrNEW CODTSectionRefArray();
	m_SectionStyleArray = BrNEW CSectionStyleArray();
	//////////////////////////////////////////////////////////////////////////

	m_ParaAttHandler = BrNEW PoParaAttHandler();
	m_TextAttHandler = BrNEW PoTextAttHandler();
	m_ParaAttHandler->init();
	m_TextAttHandler->init();

	m_StyleAttHandler = BrNEW PoStyleAttHandler();

	m_Caret = BrNEW CCaret();

	m_BFont = BrNEW BFont();

#ifdef USE_THEME
	m_pTheme = (CTheme*)gpPaint->pTheme;
	m_bIsPageDrawing = BrFALSE;
#endif
	m_CmdEngine->setDocument(this);
	//jkjung m_CmdEngine->setView(BrNULL);
#ifdef IMPORT_RTF
	m_pImportForRTF = BrNULL;
#endif

#ifdef IMPORT_HWP
	m_pHwpCoMgr = BrNULL;
#endif //IMPORT_HWP

	m_pImportForHun = BrNULL;
	m_pFilterDoc = BrNULL;
#ifdef IMPORT_DOCX
	m_pImportForDocx = BrNULL;
#endif
#ifdef IMPORT_ODT
	m_pFilterOdt = BrNULL;
#endif
#ifdef IMPORT_ODP
	m_pImportForOdp = BrNULL;
#endif
#if defined(BWP_EDITOR) && defined(IMPORT_TXT)
	m_pImportTxt = BrNULL;
#endif  // defined(BWP_EDITOR) && defined(IMPORT_TXT)

#ifdef IMPORT_NEW_PPT
	m_pImportForPPT = BrNULL;
#endif

#ifdef BWP_EDITOR
	m_nBWPEngineMode = BrFALSE;
	//m_pExportForDOC = BrNULL;
	m_nFromDocu = FROM_UNKNOWN;
	m_nSubDocu = 0;
	m_nCodePage = CP_UTF8;
	DocFlagEx.flag.m_bHorClipRectFlag = BrFALSE;
	DocFlagEx.flag.m_bVerClipRectFlag = BrFALSE;
	m_pRgn = BrNULL;
#endif

#if defined(IMPORT_HTML) && defined(LOAD_ONE_PAGE_HTML)
	m_pPageForHtml = BrNULL;
	m_pLoaderForHtml = BrNULL;
#endif	// LOAD_ONE_PAGE_HTML

	m_selectionPane_frame_id_generator = BrNULL;

	//ihwa m_pCTile = BrNEW PmPixmap;
	// for html speed, 2007.3.8
	// Init();
	//m_nLimitLine = 0;
	DocFlagEx.m_nDocFlagEx  = 0;
	DocFlagEx.flag.m_bSMSDoc = BrFALSE;
	DocFlagEx.flag.m_bOnUpdateSection = BrFALSE;
#ifdef OFFICE_EDITOR
	DocFlagEx.flag.m_bMasterDrawing = BrFALSE;
	DocFlagEx.flag.m_bFindReplace = BrFALSE;
#endif

	DocFlagEx2.m_nDocFlagEx = 0;	//hnsong:2012-04-13
#ifdef MS_WORD_WRAP_LOCK
	DocFlagEx2.flag.m_bSetWordWrapLocked = BGetMSWordWrapLocked();
#endif // MS_WORD_WRAP_LOCK

#ifdef IMPORT_HTML
	m_pInlineFrame = BrNULL;
	m_nInlineFrameHeight = 0;
	//	m_nInlineFrameHeightMax = 0;
#endif

#ifdef SUPPORT_OFFICE_2007
	m_pDocumentPackage = BrNULL;
#endif //SUPPORT_OFFICE_2007

#ifdef IMPORT_OPEN_DOCUMENT
	m_pOdPackage = BrNULL;
#endif //IMPORT_ODT

#ifdef FOR_WORD_EXPORT
	m_docDyaLinePitch = 0;
	m_docCLM = 0;
#endif

#ifdef SUPPORT_URL_IMAGE
    m_pUrlImageContainer = BrNEW UrlImageContainer();
#endif
	m_aVideoManager = BrNULL;

#ifdef SUPPORT_OFFICE_2007
	m_ContainerSchemeColor = BrNULL;
	m_pContainerTheme = BrNULL;
#endif//#ifdef SUPPORT_OFFICE_2007

	m_bOnDraw = BrFALSE;

#ifdef DANDONG_SMARTART
	m_bSmartArt = BrFALSE;
#endif

#ifdef DANDONG_SMARTART_INSERT
	m_pDiagramInfo = BrNULL;
#endif //DANDONG_SMARTART_INSERT
	m_bSend_TotalLoadComplete = BrFALSE;

	//[2013.04.25][�����][TID:14926] ȭ����ȯ ���� �� ����, ������ �ð� ��� ��� ����
	m_bUseTimings = BrTRUE;

	m_bGutterAtTop = BrFALSE;

	m_bDoNotExpandShiftReturn = BrFALSE;

	m_nAlignBordersAndEdgesGap = 220;	//twip, //MRP-1174, �ܶ� �׵θ��� ǥ �𼭸��� ������ �׵θ��� ���� (page border option)

	m_nGrayMode = GRAY_MODE_COLOR;

	m_bSlideShowLoop = BrFALSE;

	m_bSlideShowWithAnim = BrFALSE;

	m_bUsePresenterTool = BrFALSE;

	m_nSlideShowStartPage = -1;

	m_nSlideShowEndPage = -1;

	m_oSlidePenColor = BrNEW BrColor;
	m_oSlideLaserColor = BrNEW BrColor;

	m_oSlidePenColor->reset();
	m_oSlidePenColor->setRGBColor(255);

	m_oSlideLaserColor->reset();
	m_oSlideLaserColor->setRGBColor(255);
	// [15.07.29][soo_1] '�ѱ� �ؽ�Ʈ�� Word 97�� �� �ٲ� ��Ģ ����', spec ���� 2.15.3.64 ����.
	m_bUseWord97LineBreakRules = BrFALSE;
	m_bDontUseHTMLParagraphAutoSpacing = BrFALSE;
#ifdef PPT_EDITOR
	m_SlideSectionArray = BrNULL;
	m_SlideEmbeddedFontArray = BrNULL;
	m_bRemoveEmbeddedFont = BrFALSE;
	m_SlideCusShowArray = BrNULL;
	m_sPlaceHolderStringArray.RemoveAll();
	m_nfirstslidenumer = 1;
	m_pSlideDefaultTextStyle = BrNULL;
#endif //PPT_EDITOR

	m_MasterScreenBeforePageNum = 0;
	m_nMaxFilterOrgMasterLayoutID = 0x80000000;
	m_nMaxMasterID = 0;

	//	m_HandoutMaster = BrNULL;

	m_OutlineLayout.m_nShowLevel = BR_OUTLINE_SHOW_LEVEL_ALL;
	m_OutlineLayout.m_bTextAtt = 1;
	m_OutlineLayout.m_bFirstLine = 0;
	m_OutlineLayout.m_nTextAtt = -1;


#ifdef SUPPORT_GRAPHIC_STYLE
	m_pGraphicStyle = BrNULL;
	if(!m_pGraphicStyle)
		m_pGraphicStyle = BrNEW CBrGraphicStyle();
#endif
#ifdef NEW_REGROUP_SUPPORT
	m_pReGroupInfoArray = BrNULL;
#endif
	m_eSlideShowType = BR_SLIDESHOW_TYPE_PRESENTER;
	m_nPasteOption = BWP_PASTE_KEEP_SROUCE_FORMAT;

	m_pHeaderArray = BrNEW BArray<CFrame*>();
	m_pFooterArray = BrNEW BArray<CFrame*>();

	m_HandoutMaster->Create(this);
#ifdef PPT_EDITOR
	m_NoteMaster->Create(this);
	m_PPTNoteMaster->Create(this);
	m_WordMultiPagePrint->Create(this);
#endif //PPT_EDITOR


#ifdef SUPPORT_THEME_FONT
	m_pThemeFontLangLatin = BrNULL;
	m_pThemeFontLangEa = BrNULL;
	m_pThemeFontLangBida = BrNULL;
#endif // SUPPORT_THEME_FONT
#ifdef HAN_CHN_CONV
	m_pHanjaConv = BrNULL;
#endif
	m_bAdjustLineHeightInTable = BrFALSE;
	m_bIsHypertext = BrFALSE;
	m_bInsertSymbol = BrFALSE;

#ifdef _SPELLCHECKER
	m_bResetSpellCheck = BrFALSE;
#ifdef USE_HUNSPELL
	m_pSpellCheckManager = BrNULL;
#endif //USE_HUNSPELL
#endif

	memset( &m_SlideNoteHandout_ScreenInfo , 0, BrSizeOf( SLIDENOTEHANDOUT_SCREENINFO ) );
#ifdef SUPPORT_LOW_VISION_SHAPE
	m_pLowVisionColorModeEngine = BrNULL;
#endif

	m_enSlideLastViewType = enSlideView;
#ifdef SUPPORT_HWP_EQUATION_EDIT
	m_pHwpMathEngine = BrNEW HwpMathEngine();
  m_pHwpMathEngine->SetCmdEngine(m_CmdEngine);
#endif // SUPPORT_HWP_EQUATION_EDIT

#ifdef SUPPORT_DOCX_MATH
  m_MathEngine->setCmdEngine(m_CmdEngine);    //zpd-22453   cmdengine�� set���� ������ new doc�� ������ paste �ȵ�.
#endif //SUPPORT_DOCX_MATH

	m_pFieldEngine = BrNEW CFieldEngine();
	m_pFEEngine = BrNEW CFEEngine();

#ifdef USE_HWP_CONTROL
	m_pHWPCotrolCmdEngine = BrNEW HwpControlCmdEngine(m_CmdEngine);
	m_pHWPControlPath = BrNULL;
#endif	//USE_HWP_CONTROL
#ifdef SUPPORT_OOXML_PROTECTION
	m_pDocumentWriteProtector = BrNULL;
#endif // SUPPORT_OOXML_PROTECTION
	m_bViewFixed = BrFALSE;
	m_bIsPowerPointShow = BrFALSE;
	m_bUseDCClientArea = BrFALSE;
	m_nDefaultTabStop = 0;
	m_szConvertOutputPath = BrNULL;

	m_bOriModified = BrFALSE;
	m_pSummaryData = BrNULL;
	m_bSpellCheckSkipMode = BrFALSE;
	m_nIncPageNum = 0;
	m_bHeaderType = 0;
	m_bFooterType = 0;
	m_nHeaderFooterID = 0;
	m_bHeaderFooterHide = BrFALSE;
	m_printHF.nType = 0;
	m_printHF.bUseHeader = BrFALSE;
	m_printHF.bUseFooter = BrFALSE;
	m_BlockMarkType = 0;

#ifdef DOCX_DOCUMENT_PROTECTION
	m_pEditProtector = BrNULL;
#endif
	StylePaneFormatFilter.stylePaneFlag = 0;
#ifdef IMPORT_HTML
	m_HtmlPageSize.cx = 0;
	m_HtmlPageSize.cy = 0;
	m_nOldBasicFrameRight = 0;
#endif // IMPORT_HTML
#ifdef	LOAD_ONE_PAGE_HTML
	m_nHtmlPageCnt = 0;
#endif	//LOAD_ONE_PAGE_HTML
	m_nZoomFactorForViewer = 0;
	m_nWordCount = 0;
	m_bSavePenDraw = BrFALSE;
	m_nInfraDrawMode = 0;
	m_bViewTogetherMode = BrFALSE;
	m_nPenMode = BR_NORMAL_MODE;
	m_dPenColor = RGB_RED;
	m_nPenSize = 0;
	m_nPenTransparency = 0;
	m_nPenLineCap = 0;
	m_dHighlightColor = RGB_RED;
	m_nShapeDrawMode = 0;
	m_nShapeDrawStyle = 0;
	m_bShapeDrawing = BrFALSE;
#ifdef DANDONG_SMARTART_INSERT
	m_bSmartArtEditing = BrFALSE;
#endif
	m_bPrevLassoMode = BrFALSE;
	m_bTablePenMode = BrFALSE;
	m_nCompatibilityMode_Version = eCOMPATIBILITY_None;
	m_nTempSaveUndoCount = 0;
	m_bTempModified  = BrFALSE;
	m_pSpidGenerator = BrNULL;
	m_nPrintWidthRatio = 0;
	m_nPrintHeightRatio = 0;

	m_bReAssignCollaborationID = BrFALSE;

	m_pFEEngine->setDocument(this);

	m_wOldHanDefFontIDForGothic = 0;
	m_wOldHanDefFontIDForBatang = 0;

#ifdef ENCRYPT_PERSONAL_INFORMATION
	m_nPersonalInfoFieldID = -1;
#endif // ENCRYPT_PERSONAL_INFORMATION
#ifdef SUPPORT_WATERMARK_FOR_HWP_ODT
	m_pWatermarkFrame = BrNULL;
	m_bMakingHWPWatermark = BrFALSE;
	m_bFrontHWPWatermark = BrFALSE;
#endif // SUPPORT_WATERMARK_FOR_HWP_ODT

	fontTableDataArray.resize(0);

	m_pCreatingMasterPage = BrNULL;
	m_FrameIDGenerator = BrNEW FrameIDGenerator();
	m_AFrameList = BrNEW FrameListForSearch();
	m_InkFrameList = BrNEW CFrameList();
	m_MstAFrameList = BrNEW CFrameList();
	m_AFrameList4HeaderFooter = BrNEW CFrameList();
	m_BgFrameList = BrNEW CFrameList();
	m_RevisionFrameList = BrNEW CFrameList();
	m_BulletImageFrameList = BrNEW CFrameList();

	m_WordMemoFrameList = BrNEW CFrameList();

#ifdef SUPPORT_MAIL_MERGE
	m_MailMerge = BrNEW CMailMerge;
#endif
	m_MailMergeDoc = BrNEW CMailMergeDoc;
	m_GuideMgr = BrNEW CGuideMgr;
	m_TableEngine = BrNEW CTableEngine;
	m_FrameSet = BrNEW CFrameSet;
	m_MemoArray = BrNEW CMemoArray;
	m_MemoEventManager = BrNEW MemoEventManager(this);
	m_TypesetInfo = BrNEW CTypesetInfo;
#ifdef SHAPE3D_MESH_CACHE
	m_3DMeshPool = BrNEW BrShape3DMeshCache;
#endif
	m_bModifiedMasterPageInfoArray = BrNEW BArray<LayoutInfo *>;
	m_WordArtBitmapArray = BrNEW BrWordArtBitmapArray;
#ifdef	BWP_UNDO
	m_UndoEngine = BrNEW CUndoEngine;
#endif

#ifndef SUPPORT_REMOVE_SECTIONLINE
	m_SectionInfoStack = BrNEW CStack;
#endif
	m_ImagePool = BrNEW BrImageArray;
	wordLang = BrNEW PO_TEXTATT_LANGUAGE::PoTextAttLanguage;
	m_charSetForDrawOneLineSero = BrNEW CCharSet;
	m_unit = BrNEW CDrawUnit;

	m_StyleAttArray = BrNEW CStyleAttArray;
	m_font_descriptor = new font::descriptor_t();

	m_pMasterThemeArray = BrNULL;

	m_bSavedDocuemnt = BrFALSE;

#ifdef USE_PDFEXPORT_TEXTBOX
	m_nExportPDFAnnotCount = 0;
	m_pExportPDFAnnotList = BrNULL;
#endif // USE_PDFEXPORT_TEXTBOX
}

BoraDoc::~BoraDoc()
{
	/*	if ( g_pAppStatic )		{
	BrDELETE 	g_pAppStatic;
	g_pAppStatic = BrNULL;
	}

	if ( g_pAppConfig )	{
	BrDELETE g_pAppConfig;
	g_pAppConfig = BrNULL;
	}
	*/
	/*
	if ( g_pSysFontInfo )	{
	BrDELETE g_pSysFontInfo;
	g_pSysFontInfo = BrNULL;
	}
	*/
	// CTextProc::FreeStatic();

#ifdef IMPORT_DOCX
	//[2012.06.28][������][TID:7391] Package �� ������ �ʾ� Close �ȵǴ� ������ ���� ����.
	BR_SAFE_DELETE(m_pDocumentPackage);
#endif //IMPORT_DOCX

#ifdef IMPORT_OPEN_DOCUMENT
	BR_SAFE_DELETE(m_pOdPackage);
#endif //IMPORT_ODT

#ifdef	NORMAL_RELEASE_DOCUMENT

#ifdef IMPORT_HWP
	BR_SAFE_DELETE(m_pHwpCoMgr);
	BR_SAFE_DELETE(m_pPageCtrlArray);
#ifdef SUPPORT_HWP_EQUATION_EDIT
	BR_SAFE_DELETE(m_pHwpMathEngine);
#endif // SUPPORT_HWP_EQUATION_EDIT
#ifdef USE_HWP_CONTROL
	//BR_SAFE_DELETE(m_pClickhereArray);
	BR_SAFE_FREE(m_pHWPControlPath);
	BR_SAFE_DELETE(m_pHWPCotrolCmdEngine);
#endif // USE_HWP_CONTROL

#endif //IMPORT_HWP

#ifdef IMPORT_RTF
	if (m_pImportForRTF)
	{
		BrDELETE m_pImportForRTF;
		m_pImportForRTF = BrNULL;
	}
#endif

#ifdef IMPORT_GUL
	if ( m_pImportForHun )	{
		BrDELETE m_pImportForHun;
		m_pImportForHun = BrNULL;
	}
#endif //IMPORT_GUL

#ifdef IMPORT_DOC
	if ( m_pFilterDoc )	{
		BrDELETE m_pFilterDoc;
		m_pFilterDoc = BrNULL;
	}
#endif
#ifdef IMPORT_DOCX
	if ( m_pImportForDocx )	{
		BrDELETE m_pImportForDocx;
		m_pImportForDocx = BrNULL;
	}
#endif
#ifdef IMPORT_ODT
	BR_SAFE_DELETE(m_pFilterOdt);
#endif
#if defined(BWP_EDITOR) && defined(IMPORT_TXT)
	BR_SAFE_DELETE(m_pImportTxt);
#endif  // defined(BWP_EDITOR) && defined(IMPORT_TXT)
#ifdef BWP_EDITOR
	/*	if ( m_pExportForDOC ){
	BrDELETE m_pExportForDOC;
	m_pExportForDOC = BrNULL;

	}*/
#endif

#if defined(IMPORT_HTML) && defined(LOAD_ONE_PAGE_HTML)
	if( m_pLoaderForHtml )
	{
		BrDELETE m_pLoaderForHtml;
		m_pLoaderForHtml = BrNULL;
		// HtmlLoad BrDELETE�ϸ鼭 �̹� BrDELETE�ȴ�...
		// if ( m_pPageForHtml )	{
		//	BrDELETE m_pPageForHtml;
		//	m_pPageForHtml = BrNULL;
		// }
	}

	m_pPageForHtml = BrNULL;
#endif	// LOAD_ONE_PAGE_HTML

#ifdef BWP_EDITOR
	if ( m_pRgn )
	{
		BrDELETE m_pRgn;
	}
#endif

#ifdef USE_RULERBAR
	if(m_pHRuler)//[2012.09.07][MistY][TID:#7674] RulerBar ����
		delete m_pHRuler;
#endif

	m_StyleAttArray->RemoveAll();

#if defined(BWP_EDITOR) || defined(PPT_EDITOR)

	clearImageCache(BrTRUE,BrTRUE);

	if (m_pCacheThumbnailImage)
		BrFree((BrLPVOID)m_pCacheThumbnailImage);
#endif

#endif	// NORMAL_RELEASE_DOCUMENT

	//[2012.08.20][������][TID:7901] SummayInfo import/export ����.
	if(m_pSummaryData)
		BR_SAFE_DELETE(m_pSummaryData);

#ifdef SUPPORT_OFFICE_2007
	BR_SAFE_DELETE(m_ContainerSchemeColor);
#endif//#ifdef SUPPORT_OFFICE_2007

	//[2013.08.08][TID:16083][�յ���]�����̵弽�� ��� ��� �Ҹ�
#ifdef PPT_EDITOR
	if(m_SlideSectionArray)
	{
		BrINT32 nSize = m_SlideSectionArray->size();
		for(BrINT32 i = 0; i< nSize; i++)
		{
			BR_SAFE_DELETE(m_SlideSectionArray->at(i));
		}
	}
	BrDELETE m_SlideSectionArray;

	if(m_SlideEmbeddedFontArray)
		BR_PBARRAY_SAFE_DELETE(m_SlideEmbeddedFontArray);

	if(m_SlideCusShowArray)
	{
		BrINT32 nSize = m_SlideCusShowArray->size();
		for(BrINT32 i = 0;i<nSize;i++)
		{
			BR_SAFE_DELETE(m_SlideCusShowArray->at(i));
		}
	}
	BrDELETE m_SlideCusShowArray;

	m_sPlaceHolderStringArray.RemoveAll();
	BR_SAFE_DELETE(m_pSlideDefaultTextStyle);

	if (m_slideAudioFileLoaderArray.size() > 0)
	{
		for (BrINT i = 0 ; i < m_slideAudioFileLoaderArray.size() ; i++)
		{
			BR_SAFE_DELETE(m_slideAudioFileLoaderArray.at(i));
		}
	}

	m_slideAudioFileLoaderArray.resize(0);
#endif //PPT_EDITOR

#ifdef USE_PPT_NOTEMASTER
	m_NoteMaster->Delete();
	m_PPTNoteMaster->Delete();
#endif
#ifdef SUPPORT_GRAPHIC_STYLE
	if(m_pGraphicStyle)
		BrDELETE m_pGraphicStyle;
#endif
#ifdef NEW_REGROUP_SUPPORT
	if(m_pReGroupInfoArray)
	{
		for(BrINT i = 0 ; i < m_pReGroupInfoArray->size(); i++)
		{
			BoraReGroupInfo* pInfo = m_pReGroupInfoArray->at(i);
			BrDELETE pInfo->m_aGroupingInfoChildFrameId;
			BrFree(pInfo);
		}
		BrDELETE m_pReGroupInfoArray;
		m_pReGroupInfoArray = BrNULL;
	}
#endif
#ifdef SUPPORT_URL_IMAGE
    BR_SAFE_DELETE(m_pUrlImageContainer);
#endif
	if(m_aVideoManager)
	{
#ifdef SUPPORT_WEARABLE_DEVICE
		for (BrINT i = 0 ; i < m_aVideoManager->size() ; i++)
		{
			BArray<LPBrBwpVideoInfo>* pPageVideoList = m_aVideoManager->at(i);
			if(pPageVideoList)
			{
				int nSz = pPageVideoList->size();
				for(int j = 0; j < nSz ; j ++)
				{
					BrBwpVideoInfo *pVideoInfo = pPageVideoList->at(j);
					pVideoInfo->pVideoFrame = BrNULL;
					BR_SAFE_FREE(pVideoInfo);
				}

			}
			BR_SAFE_DELETE(pPageVideoList);
		}
		m_aVideoManager->RemoveAll();
		BR_SAFE_DELETE(m_aVideoManager);
#endif
	}

	for (BrINT i = 0 ; i < m_bModifiedMasterPageInfoArray->size() ; i++) {
		LayoutInfo *pData = m_bModifiedMasterPageInfoArray->at(i);
		if (pData)
			BrFree(pData);
	}
	m_bModifiedMasterPageInfoArray->RemoveAll();

	if(m_pHeaderArray)
	{
		for(BrINT i = 0; i < m_pHeaderArray->size(); i++)
		{
			CFrame *pFrame = m_pHeaderArray->at(i);
			BR_SAFE_DELETE(pFrame);
		}
		m_pHeaderArray->RemoveAll();
		BrDELETE m_pHeaderArray;
	}

	if(m_pFooterArray)
	{
		for(BrINT i = 0; i < m_pFooterArray->size(); i++)
		{
			CFrame *pFrame = m_pFooterArray->at(i);
			BR_SAFE_DELETE(pFrame);
		}
		m_pFooterArray->RemoveAll();
		BrDELETE m_pFooterArray;
	}

	if (m_MasterLayoutArray.size() > 0)
	{
		for (BrINT i = 0 ; i < m_MasterLayoutArray.size() ; i++)
		{
			CPageArray *pMasterPageArray = m_MasterLayoutArray.at(i);
			if (pMasterPageArray)
				BrDELETE pMasterPageArray;
		}
		m_MasterLayoutArray.RemoveAll();
	}

	if (m_pCurMasterLayoutArray.size() > 0)
	{
		for (BrINT i = 0 ; i < m_pCurMasterLayoutArray.size() ; i++)
		{
			CPageArray *pMasterPageArray = m_pCurMasterLayoutArray.at(i);
			if (pMasterPageArray)
				BrDELETE pMasterPageArray;
		}
		m_pCurMasterLayoutArray.RemoveAll();
	}

	m_BulletImageFrameList->removeAll();

	BR_SAFE_DELETE(m_pFieldEngine);
	BR_SAFE_DELETE(m_pFEEngine);

#ifdef USE_HWP_CONTROL
	BR_SAFE_DELETE(m_pHWPCotrolCmdEngine);
#endif

#ifdef HAN_CHN_CONV
	if( m_pHanjaConv )
		BrDELETE( m_pHanjaConv );
#endif

#ifdef USE_HUNSPELL
	BR_SAFE_DELETE(m_pSpellCheckManager);
#endif //USE_HUNSPELL

#ifdef SUPPORT_OFFICE_2007
	BR_SAFE_DELETE(m_pContainerTheme);
#endif//#ifdef SUPPORT_OFFICE_2007

#ifdef DOCX_DOCUMENT_PROTECTION
	BR_SAFE_DELETE(m_pEditProtector);
#endif //DOCX_DOCUMENT_PROTECTION
#ifdef SUPPORT_OOXML_PROTECTION
	BR_SAFE_DELETE(m_pDocumentWriteProtector);
#endif //SUPPORT_OOXML_PROTECTION

	if(m_pSpidGenerator)
		BR_SAFE_DELETE(m_pSpidGenerator);

	BR_SAFE_DELETE(m_ParaAttHandler);
	BR_SAFE_DELETE(m_TextAttHandler);
	BR_SAFE_DELETE(m_StyleAttHandler);
	BR_SAFE_DELETE(m_Caret);
	BR_SAFE_DELETE(m_BFont);
#ifdef SUPPORT_WATERMARK_FOR_HWP_ODT
	if ( m_pWatermarkFrame )
		BR_SAFE_DELETE(m_pWatermarkFrame);
#endif // SUPPORT_WATERMARK_FOR_HWP_ODT

	CFontTableData* pData = BrNULL;
	for(BrINT i=0; i<fontTableDataArray.size(); i++)
	{
		pData = fontTableDataArray.at(i);
		BR_SAFE_DELETE(pData);
	}
	BR_SAFE_DELETE(m_Pagination);
	BR_SAFE_DELETE(m_FontArray);
	BR_SAFE_DELETE(m_FieldArray);
//#ifdef USE_HWP_CONTROL
	BR_SAFE_DELETE(m_GrapAtt);
//#endif//#ifdef USE_HWP_CONTROL
	BR_SAFE_DELETE(m_BatangPageArray);
	BR_SAFE_DELETE(m_PageArray);
	BR_SAFE_DELETE(m_MstPageArray);
	BR_SAFE_DELETE(m_WebPageArray);
	BR_SAFE_DELETE(m_PageLayoutEngine);
	BR_SAFE_DELETE(m_HeaderFooterEngine);
#ifdef SUPPORT_DOCX_MATH
	BR_SAFE_DELETE(m_MathEngine);
#endif//#ifdef SUPPORT_DOCX_MATH
	BR_SAFE_DELETE(m_HandoutMaster);
	BR_SAFE_DELETE(m_BulletArray);
	BR_SAFE_DELETE(m_NumArray);
	BR_SAFE_DELETE(m_CmdEngine);
	BR_SAFE_DELETE(m_FrameIDGenerator);
	BR_SAFE_DELETE(m_AFrameList);
	BR_SAFE_DELETE(m_InkFrameList);
	BR_SAFE_DELETE(m_MstAFrameList);
	BR_SAFE_DELETE(m_AFrameList4HeaderFooter);
	BR_SAFE_DELETE(m_BgFrameList);
	BR_SAFE_DELETE(m_RevisionFrameList);
	BR_SAFE_DELETE(m_BulletImageFrameList);
	BR_SAFE_DELETE(m_WordMemoFrameList);
	BR_SAFE_DELETE(m_NoteMaster);
	BR_SAFE_DELETE(m_PPTNoteMaster);
	BR_SAFE_DELETE(m_WordMultiPagePrint);
	BR_SAFE_DELETE(m_PageStyleArray);
	BR_SAFE_DELETE(m_ODTPageRefArray);
	BR_SAFE_DELETE(m_ODTSectionRefArray);
	BR_SAFE_DELETE(m_SectionStyleArray);

#ifdef SUPPORT_MAIL_MERGE
	BR_SAFE_DELETE(m_MailMerge);
#endif
	BR_SAFE_DELETE(m_MailMergeDoc);
	BR_SAFE_DELETE(m_GuideMgr);
	BR_SAFE_DELETE(m_TableEngine);
	BR_SAFE_DELETE(m_FrameSet);
	BR_SAFE_DELETE(m_MemoArray);
	BR_SAFE_DELETE(m_MemoEventManager);
	BR_SAFE_DELETE(m_TypesetInfo);
#ifdef SHAPE3D_MESH_CACHE
	BR_SAFE_DELETE(m_3DMeshPool);
#endif
	BR_SAFE_DELETE(m_bModifiedMasterPageInfoArray);
	BR_SAFE_DELETE(m_WordArtBitmapArray);
#ifdef	BWP_UNDO
	BR_SAFE_DELETE(m_UndoEngine);
#endif
#ifndef SUPPORT_REMOVE_SECTIONLINE
	BR_SAFE_DELETE(m_SectionInfoStack);
#endif
	BR_SAFE_DELETE(m_ImagePool);
	BR_SAFE_DELETE(m_charSetForDrawOneLineSero);
	BR_SAFE_DELETE(m_unit);

	BR_SAFE_DELETE(m_oSlidePenColor);
	BR_SAFE_DELETE(m_oSlideLaserColor);
	BR_SAFE_DELETE(m_StyleAttArray);

	BR_SAFE_DELETE(validationMgr);

#ifdef USE_PDFEXPORT_TEXTBOX
	BR_SAFE_FREE(m_pExportPDFAnnotList);
#endif // USE_PDFEXPORT_TEXTBOX
}

#ifndef NORMAL_RELEASE_DOCUMENT
void BoraDoc::closeForSpecialRelease()
{
#ifdef IMPORT_DOC
	if (m_pFilterDoc)
		m_pFilterDoc->ReleaseOleFile();
#endif  // IMPORT_DOC

	if(m_ImagePool->GetSize())//misty - 2014.01.17
		m_ImagePool->RemoveAll();

#ifdef SUPPORT_URL_IMAGE
    m_pUrlImageContainer->CleanUp();
#endif
	if(m_aVideoManager)
	{
#ifdef SUPPORT_WEARABLE_DEVICE
		for (BrINT i = 0 ; i < m_aVideoManager->size() ; i++)
		{
			BArray<LPBrBwpVideoInfo>* pPageVideoList = m_aVideoManager->at(i);
			if(pPageVideoList)
			{
				int nSz = pPageVideoList->size();
				for(int j = 0; j < nSz ; j ++)
				{
					BrBwpVideoInfo *pVideoInfo = pPageVideoList->at(j);
					pVideoInfo->pVideoFrame = BrNULL;
					BR_SAFE_FREE(pVideoInfo);
				}

			}
			BR_SAFE_DELETE(pPageVideoList);
		}
		m_aVideoManager->RemoveAll();
		BR_SAFE_DELETE(m_aVideoManager);
#endif
	}
#ifdef IMPORT_OPEN_DOCUMENT
	BR_SAFE_DELETE(m_pFilterOdt);
	BR_SAFE_DELETE(m_pOdPackage);
#endif
#ifdef USE_HUNSPELL
	BR_SAFE_DELETE(m_pSpellCheckManager);
	BR_SAFE_DELETE(wordLang);
#endif //USE_HUNSPELL
	if(m_font_descriptor)
		delete m_font_descriptor;
}
#endif //NORMAL_RELEASE_DOCUMENT
const FrameIDGenerator& BoraDoc::GetFrameIDGenerator() const
{
	return *m_FrameIDGenerator;
}

void BoraDoc::ExportFontNameArray(PoStringArray* fontNameArray)
{
	if (!fontNameArray || m_FontArray->size() == 0)
		return;

	fontNameArray->poStringArray = (PoString**)calloc(m_FontArray->size(), sizeof(PoString*));

	BrINT32 fontCount = 0;
	char* fontNameStr = BrNULL;
	PoString* fontNameString = BrNULL;
	for (auto it = m_FontArray->begin(); it < m_FontArray->end(); it++)
	{
		auto fontEx = *it;
		if (fontEx.bFromDocument)
		{
			BString fontName;
			fontName = fontEx.getFaceName();
			if (!fontName.isEmpty())
			{
				BrAutoChar fontNameChar = CUtil::convertBStringToChar(&fontName, CP_UTF8);
				fontNameStr = fontNameChar.get();
				if (fontNameStr)
				{
					fontNameString = (PoString*)malloc(sizeof(PoString));
					if (fontNameString)
					{
						fontNameString->poStringSize = strlen(fontNameStr);
						fontNameString->poString = (char*)malloc(fontNameString->poStringSize + 1);
						memset(fontNameString->poString, 0, fontNameString->poStringSize + 1);
						memcpy(fontNameString->poString, fontNameStr, fontNameString->poStringSize);
						fontNameArray->poStringArray[fontCount] = fontNameString;
						fontCount++;
					}
				}
			}
		}
	}
	fontNameArray->poStringArraySize = fontCount;
}

void BoraDoc::ExportLinkedImageUrlArray(PoStringArray* urlArray)
{
	validationMgr->ExportLinkedImageUrlArray(urlArray);
}

void BoraDoc::ExportOleObjectArray(PoStringArray* oleObjectArray)
{
	validationMgr->ExportOleObjectArray(oleObjectArray);
}

void BoraDoc::ExportCorruptedImageArray(PoStringArray* imageArray)
{
	validationMgr->ExportCorruptedImageArray(imageArray);
}

const BrColor& BoraDoc::GetSlidePenColor() const {
	return *m_oSlidePenColor;
}
const BrColor& BoraDoc::GetSlideLaserColor() const {
	return *m_oSlideLaserColor;
}
void	BoraDoc::SetSlidePenColor(const BrColor& a_oColor) {
	*m_oSlidePenColor = a_oColor;
}
void	BoraDoc::SetSlideLaserColor(const BrColor& a_oColor) {
	*m_oSlideLaserColor = a_oColor;
}

#ifdef SUPPORT_OFFICE_2007
void BoraDoc::CloseZipFile()
{
	if (m_pDocumentPackage)
		m_pDocumentPackage->CloseZipFile();
}
void BoraDoc::OpenZipFile()
{
	if (m_pDocumentPackage)
		m_pDocumentPackage->OpenZipFile();
}
#endif//#ifdef SUPPORT_OFFICE_2007

CDrawUnit& BoraDoc::getDrawUnit() {
	return *m_unit;
}

const PO_TEXTATT_LANGUAGE::PoTextAttLanguage& BoraDoc::getWordLang() {
	return *wordLang;
}

void	BoraDoc::setWordLang (const PO_TEXTATT_LANGUAGE::PoTextAttLanguage& sourceLang) {
	*wordLang = sourceLang;
}

font::descriptor_t& BoraDoc::font_descriptor() const {
	return *m_font_descriptor;
}

void BoraDoc::setPrevSpaceTextAtt(const PoTextAtt *pAtt)
{
	if(!m_pPrevSpaceTextAtt)
		m_pPrevSpaceTextAtt = BrNEW PoTextAtt();

	*m_pPrevSpaceTextAtt = *pAtt;
}


void BoraDoc::ResetErrorCode()
{
  SetErrorCode(kPoProcessSucess);
  g_pErrorHandler->SetLowerBoundIndex();
}


CLocation* BoraDoc::getLocScreenMemo() {
	return m_MemoEventManager->getLocScreenMemo();
}
void BoraDoc::setLocScreenMemo(CLine *pLine , int nCol ) {
	m_MemoEventManager->setLocScreenMemo(pLine, nCol);
}

CTypesetInfo* BoraDoc::getTypesetInfo() {
	return m_TypesetInfo;
}
int BoraDoc::getEndnoteTotalNum() {
	return m_TypesetInfo->getEndnoteTotalNum();
}
int BoraDoc::getFootnoteTotalNum() {
	return m_TypesetInfo->getFootnoteTotalNum();
}
BrBOOL BoraDoc::getFootnoteContinue() {
	return m_TypesetInfo->getFootnoteContinue();
}
int BoraDoc::getCurArrFnoteNum() {
	return m_TypesetInfo->getCurArrFnoteNum();
}
void BoraDoc::setCurArrFnoteNum(int nFnoteNum) {
	m_TypesetInfo->setCurArrFnoteNum(nFnoteNum);
}
BrLONG BoraDoc::getFootnoteMargin() {
	return m_TypesetInfo->getFootnoteMargin();
}

void BoraDoc::setColorScheme(BCOfficeXColorSchemeAtom* pColorScheme)
{
#ifdef SUPPORT_OFFICE_2007
	m_ContainerSchemeColor = BrNEW BCOfficeXColorSchemeAtom(m_pDocumentPackage);
	m_ContainerSchemeColor->Clone(pColorScheme);
#endif//#ifdef SUPPORT_OFFICE_2007
}

BCOfficeXColorSchemeAtom* BoraDoc::getColorScheme() {
#ifdef SUPPORT_OFFICE_2007
	return m_ContainerSchemeColor;
#endif//#ifdef SUPPORT_OFFICE_2007
	return BrNULL;
}

void BoraDoc::setContainerTheme(BCOfficeXThemeX* pColorScheme) {
#ifdef SUPPORT_OFFICE_2007
	m_pContainerTheme = pColorScheme;
#endif//#ifdef SUPPORT_OFFICE_2007
}

BCOfficeXThemeX* BoraDoc::getContainerTheme() {
#ifdef SUPPORT_OFFICE_2007
	return m_pContainerTheme;
#endif//#ifdef SUPPORT_OFFICE_2007
	return BrNULL;
}

void BoraDoc::Init(BrCHAR bDocType, INT16 iRefNum, BrBOOL bNewDoc, BrBOOL bEpub, BrBOOL bMakePackage)
{
	m_iMemRef = iRefNum;
	m_ParaAttHandler->init();
	m_TextAttHandler->init();
	m_TypesetInfo->initFor(m_nDocType);
	m_PageArray->SetDocument(this);
	m_MstPageArray->SetDocument(this);
	m_BatangPageArray->SetDocument(this);
#ifdef	BWP_EDITOR
	m_WebPageArray->SetDocument(this);	// for speed
#endif

#ifdef USE_HWP_CONTROL
    /*m_pClickhereArray = BrNULL;*/
    m_pClickHereHandler = BrNULL;
    m_nFieldViewOption = 2;
    m_pHWPControlPath = BrNULL;
    m_bOCXMode = g_pBInterfaceHandle->m_bOcx;
    m_bBlockClickhereProc = BrFALSE;
    m_bHwpCtrlApiMode = BrFALSE;
    m_bUseAPIMode = BrTRUE;
#endif // USE_HWP_CONTROL

	m_selectionPane_frame_id_generator = BrNEW bwp::Sequence<int, bwp::forward_sequence_generator>(0);

	for(BrINT nIdx = 0; nIdx<m_MasterLayoutArray.size(); nIdx++)
	{
		m_MasterLayoutArray.at(nIdx)->clearApplyMasterInfo();
	}
	m_MasterLayoutArray.resize(0);

	for(BrINT nIdx = 0; nIdx<m_pCurMasterLayoutArray.size(); nIdx++)
	{
		m_pCurMasterLayoutArray.at(nIdx)->clearApplyMasterInfo();
	}
	m_pCurMasterLayoutArray.resize(0);

	m_OutlineLayout.m_pParaAtt = BrNEW PoParaAtt();

	m_MstPageArray->clearApplyMasterInfo();
	m_PaperColor    = TRANSPARENT_COLOR;
	m_rcRAMargin.nLeft = m_rcRAMargin.nTop = m_rcRAMargin.nRight = m_rcRAMargin.nBottom = 0;

#ifdef	BWP_EDITOR
	m_nID           = g_pAppStatic->getMaxDocID();
#endif
	m_nWallZoom = 100;
	m_nWallID = 0;
	DocFlag.m_nDocFlag = 0;
	setViewMode(0);
	DocFlag.flag.m_WraptoWindow = false;

	//(For BWP Viewer) m_bPasswordSum = 0;
	m_nDirtyPage = 0;
	m_nMaxSPID = 0;
	m_nMaxPlaceHolderID = 0;
	m_nSaveFrameID = 0;
	m_multiplePages = BR_PAPER_LAYOUT_VIEW_NORMAL;

	m_nErrCode = kPoProcessSucess;

	BrBOOL bPPT = BrFALSE;
	if (BORA_DOCTYPE_PPT == bDocType || BORA_DOCTYPE_PPTX == bDocType || BORA_DOCTYPE_ODP == bDocType)
	{
		setFromPpt(BrTRUE);
		m_nDocType = bDocType;
		bPPT = BrTRUE;
		m_nBWPEngineMode = EDITOR_PPT;

		if(BORA_DOCTYPE_PPT == bDocType)
		{
			m_slideNotePaperSize.cx = PPT_PAPER_43_Y;
			m_slideNotePaperSize.cy = PPT_PAPER_43_X;
		}
		else
		{
			m_slideNotePaperSize.cx = PPTX_PAPER_43_Y;
			m_slideNotePaperSize.cy = PPTX_PAPER_43_X;
		}
	}
	else
		m_nBWPEngineMode = EDITOR_WORD;


	if(BORA_DOCTYPE_DOCX != m_nDocType && BORA_DOCTYPE_ASCI != m_nDocType) // WPD-960
		m_TableEngine->setStyleMgr(m_nDocType);

	if( (BORA_DOCTYPE_DOCX == m_nDocType ) || (BORA_DOCTYPE_PPTX == m_nDocType) || BORA_DOCTYPE_ASCI == m_nDocType) // WPD-960
		setThemeUsingDoc(BrTRUE);
	else
		setThemeUsingDoc(BrFALSE);


#ifdef	BIDI_SUPPORT
	BrINT32 nLocale = PoGetLocale();
	// set RTL Document
	if (BR_LOCALE_ARABIC == nLocale || BR_LOCALE_HEBREW == nLocale || BR_LOCALE_FARSI == nLocale || BR_LOCALE_URDU == nLocale)
		setBidiFlag(BrTRUE);
#endif // BIDI_SUPPORT

#ifndef BIDI_SUPPORT
	m_nKinsokuLocale = PoGetLocale();
#else
	m_nKinsokuLocale = nLocale;
#endif

	DocFlag.flag.m_KinsokuJC = 0;
	m_drawMarginLineFlag = 0;

	switch (m_nKinsokuLocale) {
	case BR_LOCALE_KOREAN:
		m_strNoLineBreaksAfter.setUnicodeCodes(KoreanNoLineBreaksAfter, BrSizeOf(KoreanNoLineBreaksAfter) / BrSizeOf(unsigned short));
		m_strNoLineBreaksBefore.setUnicodeCodes(KoreanNoLineBreaksBefore, BrSizeOf(KoreanNoLineBreaksBefore) / BrSizeOf(unsigned short));
		break;
	case BR_LOCALE_S_CHINESE:
		m_strNoLineBreaksAfter.setUnicodeCodes(ChineseSimplifiedNoLineBreaksAfter, BrSizeOf(ChineseSimplifiedNoLineBreaksAfter) / BrSizeOf(unsigned short));
		m_strNoLineBreaksBefore.setUnicodeCodes(ChineseSimplifiedNoLineBreaksBefore, BrSizeOf(ChineseSimplifiedNoLineBreaksBefore) / BrSizeOf(unsigned short));
		break;
	case BR_LOCALE_T_CHINESE_TW:
	case BR_LOCALE_T_CHINESE_HK:
		m_strNoLineBreaksAfter.setUnicodeCodes(ChineseTraditionalNoLineBreaksAfter, BrSizeOf(ChineseTraditionalNoLineBreaksAfter) / BrSizeOf(unsigned short));
		m_strNoLineBreaksBefore.setUnicodeCodes(ChineseTraditionalNoLineBreaksBefore, BrSizeOf(ChineseTraditionalNoLineBreaksBefore) / BrSizeOf(unsigned short));
		break;
	case BR_LOCALE_JAPANESE:
		m_strNoLineBreaksAfter.setUnicodeCodes(JapaneseNoLineBreaksAfter, BrSizeOf(JapaneseNoLineBreaksAfter) / BrSizeOf(unsigned short));
		m_strNoLineBreaksBefore.setUnicodeCodes(JapaneseNoLineBreaksBefore, BrSizeOf(JapaneseNoLineBreaksBefore) / BrSizeOf(unsigned short));
		break;
	default:
		m_strNoLineBreaksAfter.setUnicodeCodes(DefaultNoLineBreaksAfter, BrSizeOf(DefaultNoLineBreaksAfter) / BrSizeOf(unsigned short));
		m_strNoLineBreaksBefore.setUnicodeCodes(DefaultNoLineBreaksBefore, BrSizeOf(DefaultNoLineBreaksBefore) / BrSizeOf(unsigned short));
		break;
	}

#ifndef SUPPORT_PPT_TEXT_STYLE
	if( BORA_DOCTYPE_PPT != m_nDocType && BORA_DOCTYPE_PPTX != m_nDocType && BORA_DOCTYPE_ODP != m_nDocType)
#endif
	{
		m_StyleAttArray->init(); // ��Ÿ�� ���� �Ϸ�� ����
		m_StyleAttHandler->initDefaultStyle(*m_StyleAttArray);
	}

	//jkjung m_Summation.initData();
	initDocument(bPPT, bNewDoc, bEpub);

	g_pAppConfig->initBulletSetting(bDocType, isJisuVersion());
#ifdef JUNGUM_GLOBAL
	m_bJungUmDoc = BrFALSE;
#endif

	DocFlagEx.flag.m_bFinishLoading = BrFALSE;
	DocFlagEx.flag.m_bFinishArrange = BrTRUE;
	DocFlagEx.flag.m_bFinishArrangeForWeb = BrTRUE;
	DocFlagEx.flag.m_bNeedArrangeFromFirst = BrFALSE;
	DocFlagEx.flag.m_bDepositArrangeFromFirst = BrFALSE;
	m_nCurLastReadPage = 0;
	//DocFlagEx.flag.m_bIgnoreFootnoteArrange = BrFALSE;

#if defined(IMPORT_HTML) && defined(LOAD_ONE_PAGE_HTML)
	if( m_pLoaderForHtml )
	{
		BrDELETE m_pLoaderForHtml;
		m_pLoaderForHtml = BrNULL;
	}

	if( m_pPageForHtml )
	{
		//BrDELETE m_pPageForHtml; //�δ� ���϶� �������� ���� ����
		m_pPageForHtml = BrNULL;
	}
#endif	// LOAD_ONE_PAGE_HTML

#ifdef IMPORT_HTML
	m_pInlineFrame = BrNULL;
	m_nInlineFrameHeight = 0;
#endif

	DocFlagEx.flag.m_bSMSDoc = BrFALSE;

#ifdef	BWP_EDITOR		// For Editor
	m_unit->setDefaultOutputOption();
	DocFlagEx.flag.m_bModified = BrFALSE;
	DocFlagEx.flag.m_bInvalidateFlag = BrFALSE;
	m_nZoomFactorForViewer = 0;
	m_rcInvaldateRect.setRect(0,0,getLCDWidth(), getLCDHeight());
#endif	// BWP_EDITOR
#ifdef	LOAD_ONE_PAGE_HTML
	m_nHtmlPageCnt = 1;
#endif	//LOAD_ONE_PAGE_HTML

#ifdef PPT_EDITOR
	DocFlagEx.flag.m_bPPTModeChange = BrFALSE;
	if (!bPPT)
	{
			m_slideSize.cx = m_slideSize.cy = 0;
	}

	m_slideNotePaperSize.cx = 10800;
	m_slideNotePaperSize.cy = 14400;

	m_ImportPageNumInfo.resize(0);
	m_SlideIDinfo.resize(0);
	m_bShowHeaderFooterAtTitleSlide = BrTRUE;
	theBWordDoc->setPlaceHolderArray();
	m_slideAudioFileLoaderArray.resize(0);
#endif

#if defined(BWP_EDITOR) || defined(PPT_EDITOR)
	m_bDrawZoom = BrFALSE;
	m_pCacheThumbnailImage = BrNULL;
	m_bChartDrawZoom = BrFALSE;
#endif

#ifdef IMPORT_DOCX
	if(!m_pDocumentPackage && bMakePackage)
	{
	//[2016.11.11][jaesun][OFF-8723]
#ifdef USE_CHART_INTERFACE
		m_pDocumentPackage = CBWPChart::getSheetPackageObj();
#else
		m_pDocumentPackage = BrNEW BoraPackageBase();
#endif

		//m_pDocumentPackage = BrNEW BoraPackageBase();
	}
#endif //IMPORT_DOCX

#ifdef IMPORT_ODT
	if (BORA_DOCTYPE_ODT == m_nDocType && BrNULL == m_pOdPackage && bMakePackage)
		m_pOdPackage = BrNEW BoraPackageOdf();
#endif  // IMPORT_ODT

#ifdef SUPPORT_OOXML_PROTECTION
	BR_SAFE_DELETE(m_pDocumentWriteProtector);
#endif // SUPPORT_OOXML_PROTECTION

	// jjoo:2013-10-11 ClearAll()�Լ��� �ִ����� ���忡�� Init�ϵ��� �ű�.
#ifdef SUPPORT_PAGELAYOUT_FOR_ODT
	if(BORA_DOCTYPE_ODT == m_nDocType)
	{
		m_PageStyleArray->init();
		m_SectionStyleArray->init();
	}
#endif

	//m_TableEngine->setStyleMgr(m_nDocType);

	m_nPenMode = BR_NORMAL_MODE;
	m_dPenColor = RGB_RED;
	m_nPenSize = 40;
	m_nPenTransparency = 255;
	m_nPenLineCap = eRoundLineCap;
	m_dHighlightColor = RGB_LIGHT_RED;
	m_nShapeDrawMode = SHAPEDRAW_NONE;
	m_nShapeDrawStyle = BR_EDITOR_SHAPE_STYLE_NONE;
	m_bShapeDrawing = BrFALSE;
#ifdef DANDONG_SMARTART_INSERT
	//[Dandong] SmartArt�� ���ε����� ���������ΰ��� ��Ÿ���� ����
	m_bSmartArtEditing = BrFALSE;
#endif //DANDONG_SMARTART_INSERT

	m_bPrevLassoMode = BrFALSE;

	m_nCurRevisionFrameID = -1;
	m_nDisabledCurRevisionFrameID = -1;

	m_bThumbnailDraw = 0;
	m_nInfraDrawMode = 0x00;
	m_bViewTogetherMode = 0x00;
	m_nCharacterSpacingControl = eCHARACTERSPACING_doNotCompress;
	m_ShapeThumbnailFrame = BrNULL;
	m_ShapeGroupThumbnailFrame = BrNULL;
	m_bTablePenMode = BrFALSE;

#ifdef IMPORT_HWP
	m_pPageCtrlArray = BrNULL;
#endif

	m_bDeleteCharPopup = BrFALSE;

	m_pDocPropertiesInfo = BrNULL;

#ifdef WIN32
	m_strAuthor = "";
#endif // WIN32

	m_nTempSaveUndoCount = 0;
	m_bTempModified = BrFALSE;

	if(bNewDoc)	//[2013.03.31]������ TempSave�� ���� ���� �ȵǴ� ����
	{
		m_nTempSaveUndoCount = 1;
	}

	m_nGrayMode = GRAY_MODE_COLOR;
	m_bUseDCClientArea = BrFALSE;
	m_bSpellCheckSkipMode = BrFALSE;
	m_bSavePenDraw = BrTRUE;

	m_fPPTPaperRatioX = 1.000000;
	m_fPPTPaperRatioY = 1.000000;
	m_nPPTPaperTextAttIndex = 0;

	m_nDefaultTabStop = PO_PARAATT_BASE::defaultParaTab;

	memset( &m_SlideNoteHandout_ScreenInfo , 0, BrSizeOf( SLIDENOTEHANDOUT_SCREENINFO ) );

	m_szConvertOutputPath = BrNULL;
	m_bHeaderType = 0;
	m_bFooterType = 0;
	m_nHeaderFooterID = 0;
	m_bHeaderFooterHide = BrFALSE;
	m_printHF.bUseHeader = BrFALSE;
	m_printHF.bUseFooter = BrFALSE;
	m_printHF.cStringHeaderLeft[0]= '\0';
	m_printHF.cStringHeaderCenter[0]= '\0';
	m_printHF.cStringHeaderRight[0] = '\0';
	m_printHF.cStringFooterLeft[0]= '\0';
	m_printHF.cStringFooterCenter[0] = '\0';
	m_printHF.cStringFooterRight[0]= '\0';

	m_BlockMarkType = BLOCK_MARK_NONE;
	m_nPrintWidthRatio	=	100;	// �������� �ʾ��� �� �⺻ ���� 100
	m_nPrintHeightRatio	=	100;	// �������� �ʾ��� �� �⺻ ���� 100
#ifdef DOCX_DOCUMENT_PROTECTION
	m_pEditProtector = BrNULL;
#endif // DOCX_DOCUMENT_PROTECTION

#ifdef REFLOW_SIMPLE_TEXT_EDITOR
	m_nTextSize = 0;
	m_nTextFontID = 0;
	memset(m_nTextAsciiWidth, 0, (MAX_ASCII_CODE-MIN_ASCII_CODE+1)*sizeof(BrINT));
	m_nTextKoreanWidth = 0;
	m_nTextChineseWidth = 0;
#endif // REFLOW_SIMPLE_TEXT_EDITOR

	// m_pPrevHangulTextAtt = m_pPrevHanjaTextAtt = BrNULL;
	m_pPrevSpaceTextAtt = BrNULL;
	// nPrevHangulWidth = nPrevHanjaWidth = 0;
	nPrevSpaceWidth = 0;

	m_pSpidGenerator = BrNULL;
	intSpidGenerator(getDocType());
	validationMgr = BrNEW ValidationManager();
	m_NormalDotmStyleArray = BrNULL;
}


BrBOOL BoraDoc::isEmptyDocument()
{
	if(m_PageArray->size() == 1)
	{
		if(getFirstLine() == getLastLine() && getSectionInfo(0))
		{
			if(getFirstLine()->getCharNum() == 1 && getSectionInfo(0)->isEmptyHeaderFooter())
				return BrTRUE;
		}
	}
	return BrFALSE;
}

#ifdef SUPPORT_DOCX_MATH
CMathEngine* BoraDoc::getMathEngine()		{
	return m_MathEngine;
}
#endif//#ifdef SUPPORT_DOCX_MATH

// document�� ���� �ۼ��� �� ���(new, open document)
// bDelImage : BrTRUE => image�� memory���� delete�Ѵ�.
//			   BrFALSE => image�� delete���� �ʴ´�. image�� viewer���� ���� �״�� ����ϰ� ����.
void BoraDoc::ClearAll(BrBOOL bDelImage)
{
	// reset old data
	m_Caret->init();
	m_BFont->Reset();
	m_PageArray->deleteAll();
	m_PageArray->Add(BrNEW CPage(m_PageArray));
	m_MstPageArray->deleteAll();
	m_MstPageArray->Add(BrNEW CPage(m_MstPageArray));
	m_BatangPageArray->deleteAll();
#ifdef	BWP_EDITOR
	m_WebPageArray->deleteAll();	// for speed
	m_WebPageArray->Add(BrNEW CPage(m_WebPageArray));	// for speed
#endif
	m_Pagination->init();
	m_TypesetInfo->init();
	m_FontArray->init();
//	m_ParaAttArray.init();
	m_TextAttHandler->clear();
	m_ParaAttHandler->clear();
	m_FieldArray->init();
	if(m_pHeaderArray)
	{
		for(BrINT i = 0; i < m_pHeaderArray->size(); i++)
		{
			CFrame *pFrame = m_pHeaderArray->at(i);
			BR_SAFE_DELETE(pFrame);
		}
		m_pHeaderArray->RemoveAll();
	}
	if(m_pFooterArray)
	{
		for(BrINT i = 0; i < m_pFooterArray->size(); i++)
		{
			CFrame *pFrame = m_pFooterArray->at(i);
			BR_SAFE_DELETE(pFrame);
		}
		m_pFooterArray->RemoveAll();
	}


//#ifdef USE_HWP_CONTROL
	m_GrapAtt->init();
//#endif//#ifdef USE_HWP_CONTROL
	// m_GrapAtt.setLineWidth(40/*g_PenWidth*/);
	m_AFrameList->removeAll();
	m_AFrameList4HeaderFooter->removeAll();
	m_MstAFrameList->removeAll();

	m_BulletArray->init();
	// m_CmdEngine->init();	// BoraDoc::initDocument()���� ����ȴ�.
	m_TableEngine->init();
#ifdef SUPPORT_DOCX_MATH
	m_MathEngine->init();
#endif
#ifdef	BWP_EDITOR
	m_FrameSet->removeAll();
#endif	// BWP_EDITOR
#ifdef	BWP_UNDO
	m_UndoEngine->resetUndoData();
#endif	// BWP_UNDO

	if ( bDelImage )
		m_ImagePool->RemoveAll();
	//ihwa m_pCTile->detach();

#ifdef SUPPORT_GRAPHIC_STYLE
	//if(m_pGraphicStyle)
	//	m_pGraphicStyle->init();
#endif
#ifdef NEW_REGROUP_SUPPORT
	if(m_pReGroupInfoArray)
	{
		for(BrINT i = 0 ; i < m_pReGroupInfoArray->size(); i++)
		{
			BoraReGroupInfo* pInfo = m_pReGroupInfoArray->at(i);
			BrDELETE pInfo->m_aGroupingInfoChildFrameId;
			BrFree(pInfo);
		}
		BrDELETE m_pReGroupInfoArray;
		m_pReGroupInfoArray = BrNULL;
	}
#endif
#ifdef SUPPORT_URL_IMAGE
    m_pUrlImageContainer->CleanUp();
#endif
	if(m_aVideoManager)
	{
#ifdef SUPPORT_WEARABLE_DEVICE
		for (BrINT i = 0 ; i < m_aVideoManager->size() ; i++)
		{
			BArray<LPBrBwpVideoInfo>* pPageVideoList = m_aVideoManager->at(i);
			if(pPageVideoList)
			{
				int nSz = pPageVideoList->size();
				for(int j = 0; j < nSz ; j ++)
				{
					BrBwpVideoInfo *pVideoInfo = pPageVideoList->at(j);
					pVideoInfo->pVideoFrame = BrNULL;
					BR_SAFE_FREE(pVideoInfo);
				}

			}
			BR_SAFE_DELETE(pPageVideoList);
		}
		m_aVideoManager->RemoveAll();
		BR_SAFE_DELETE(m_aVideoManager);
#endif
	}
}
void BoraDoc::initDocumentForPPT()
{
#ifdef POLARIS_WIN8
	setPPTTextBoxGuildeLineShow(BrFALSE);
#endif

	BrINT sLeftMargin[5] = {0,720,1440,2160,2880};
	for (BrINT i = 0 ; i < 5 ; i++)
	{
		PoParaAtt paraAtt;
		paraAtt.setIndent(-360);
		paraAtt.setLineSpace(0.90000);
		paraAtt.setLeftMargin(sLeftMargin[i]);

		if ( isBidiFlag())
			paraAtt.setAlign(RIGHT);
		else
			paraAtt.setAlign(LEFT);


		BrWORD wBulletCode;
		BrBOOL bOutline = BrFALSE;
		NumFormatType eNumType = eSTNum_none;

		if(eNumType == eSTNum_none)	//�� �� �� �� ��..
		{
			bOutline = BrFALSE;
			wBulletCode = BULLET_CODE_0_2BYTE;
		}
		//////////////////////////////////////////////////////////////////////////
		// set bullet
		//////////////////////////////////////////////////////////////////////////
		BrINT32 nCount = 1;
		eNumType = eSTNum_bullet;
		CBullet *pBullet = BrNEW CBullet();
		if(pBullet)
		{
			pBullet->setCount( (BYTE)nCount );

			CBulletItem *pBulletItem = NULL;
			pBulletItem = BrNEW CBulletItem();
			if(pBulletItem)
			{
				pBulletItem->setOrgMode(BULLET_OUTBUL);
				pBulletItem->setIndent(paraAtt.getIndent());
				pBulletItem->setLeftMargin(paraAtt.getLeftMargin());
				pBulletItem->setCode( wBulletCode );            //Bullet���ڷ� �� ����� ���� Code (0:None)
				pBulletItem->setNumType( eNumType );            // ��ȣ �ű���� ���� (�ѱ�, ����, ����, �θ���, ������, ��ȣ����, ...)
				pBullet->addBulletItem(0, pBulletItem);
			}
			pBullet->setCount(1);
		}
		m_BulletArray->addBullet(pBullet);
		paraAtt.setBulletID(m_BulletArray->size());
		if(pBullet && pBullet->getBulletItem(0))
		{
			BrINT nNewParaID = getParaAttHandler()->insertParaAtt(paraAtt);
			pBullet->getBulletItem(0)->setParaAttID(nNewParaID);
			if (i == 0)
				m_nBaseBulletPlaceholderParaID = nNewParaID;
		}
	}
#ifdef _ANDROID_STANDARD_B2B_H_
	setAnimationMode(BrTRUE);
#endif //_ANDROID_STANDARD_B2B_H_

	m_MemoEventManager->setShowMemo(BrTRUE);

	m_TextAttMergeSlideEngine = BrNEW TextAttMergeSlideEngine();
	m_ParaAttMergeSlideEngine = BrNEW ParaAttMergeSlideEngine();

	m_isProceedingTextAttMerge = BrFALSE;
}

void BoraDoc::setDefaultParaAtt(const PoParaAtt &rPA)
{
	m_ParaAttHandler->setDefaultAttr(rPA);
}

void BoraDoc::initDocument(BrBOOL bPPT, BrBOOL bNewDoc, BrBOOL bEpub)
{
	CPage  *pPage1;
	CPage  *pMast1;
#ifdef	BWP_EDITOR
	CPage  *pWebPage;	// for speed
#endif
	CPage  *pMast2=BrNULL;
	CFrame *pFrame;

	pPage1 = m_PageArray->getPage(1);
	if( pPage1==BrNULL ) return;

	pMast1 = m_MstPageArray->getPage(1);
	if( pMast1==BrNULL ) return;

	// Make page array for Web View
#ifdef	BWP_EDITOR
	pWebPage = m_WebPageArray->getPage(1);
	if( pWebPage==BrNULL ) return;
#endif

	// initial CmdEngine
	m_CmdEngine->init(bEpub);
	m_CmdEngine->setDocument(this);
	//ihwa m_CmdEngine->setView(m_pView);

	//2014-08-29 //sangdon //UI�� ���� ��ȣ ���� �޾ƿ���
	/*BrINT32 bShowEditSymbol = m_CmdEngine->IsShowEditSymbol();

	BrEditSymbolShowStateSetting sEditSymbolState = m_CmdEngine->m_sEditSymbolShowState;
	BGetEditSymbolSettingInfo(&bShowEditSymbol, &sEditSymbolState);
	m_CmdEngine->setShowEditSymbol(bShowEditSymbol==0?false:true);
	m_CmdEngine->setEditSymbolShowState(sEditSymbolState);*/

#ifdef TABLE_HWP_SHARE_TRANSPARENT_LINE
	if(m_nDocType == BORA_DOCTYPE_HWP)
	{
		if(m_CmdEngine->getEditSymbolShowState().bTransparentLine)
			g_pAppStatic->m_nTableInfoMask |= BR_TABLEINFOMASK_GRID; //BR_EDITSYMBOL_TRANSPARENTLINE HWP ��ɰ� ǥ ���ݼ� ��� ����
		else
			g_pAppStatic->m_nTableInfoMask &= (~BR_TABLEINFOMASK_GRID); //BR_EDITSYMBOL_TRANSPARENTLINE HWP ��ɰ� ǥ ���ݼ� ��� ����
	}
#endif
	{
		CPaperSize *pPaperSize = g_pAppConfig->getDefaultPaperSize();
		if (bNewDoc ||
			(m_nDocType != BORA_DOCTYPE_PPT && m_nDocType != BORA_DOCTYPE_PPTX &&
				m_nDocType != BORA_DOCTYPE_DOC && m_nDocType != BORA_DOCTYPE_DOCX &&
				m_nDocType != BORA_DOCTYPE_HWP &&
#ifdef IMPORT_ODT
				m_nDocType != BORA_DOCTYPE_ODT &&
#endif
#ifdef IMPORT_ODS
				m_nDocType != BORA_DOCTYPE_ODS &&
#endif
#ifdef IMPORT_ODP
				m_nDocType != BORA_DOCTYPE_ODP &&
#endif
				m_nDocType != BORA_DOCTYPE_GUL
			))
		{
			*m_Pagination = *(g_pAppConfig->getDefaultPagination());
			*(pPage1->getPaperSize()) = *pPaperSize;

#ifdef	OFFICE_EDITOR
			setCreatedNewDoc(BrTRUE);
#endif

			if (m_nDocType == BORA_DOCTYPE_DOCX)
				m_nCompatibilityMode_Version = eCOMPATIBILITY_V15;	// HEJ-1274

			m_CmdEngine->setMaxEndCoord(DOCX_A4_X, DOCX_A4_Y);
			if (bPPT) // ptt defalut paper size (4:3, 14425 * 10819)
			{
				pPaperSize = pPage1->getPaperSize();

				if(m_nDocType == BORA_DOCTYPE_PPTX)
				{
					pPaperSize->m_nWidth = PPTX_PAPER_43_X;
					pPaperSize->m_nHeight = PPTX_PAPER_43_Y;
				}
				else
				{
					pPaperSize->m_nWidth = PPT_PAPER_43_X; // 14425
					pPaperSize->m_nHeight = PPT_PAPER_43_Y;// 10819;
				}

				pPaperSize->setDirection(LANDSCAPE);
#ifdef  PPT_EDITOR
				// set ppt slide size
				if(m_nDocType == BORA_DOCTYPE_PPTX)
				{
					m_slideSize.cx = PPTX_PAPER_43_X;
					m_slideSize.cy = PPTX_PAPER_43_Y;
				}
				else
				{
					m_slideSize.cx = PPT_PAPER_43_X;
					m_slideSize.cy = PPT_PAPER_43_Y;
				}

				m_CmdEngine->setMaxEndCoord(m_slideSize.cx, m_slideSize.cy);

				m_slideNotePaperSize.cx = 10800;
				m_slideNotePaperSize.cy = 14400;
#endif
			}

			pPage1->getColumn()->copyFromEnv(m_Pagination->getStartFace());
			if( m_Pagination->getFace() == SINGLE_FACE )
			{
				*(pMast1->getPaperSize()) = *pPaperSize;
				pMast1->getColumn()->copyFromEnv(RIGHT_FACE);
			}
			else
			{
				pMast2 = BrNEW CPage();
				m_MstPageArray->insertNext(1, pMast2);
				*(pMast1->getPaperSize()) = *pPaperSize;
				*(pMast2->getPaperSize()) = *pPaperSize;
				if( m_Pagination->getStartFace()==LEFT_FACE ) {
					pMast1->getColumn()->copyFromEnv(LEFT_FACE);
					pMast2->getColumn()->copyFromEnv(RIGHT_FACE);
				}
				else {
					pMast1->getColumn()->copyFromEnv(RIGHT_FACE);
					pMast2->getColumn()->copyFromEnv(LEFT_FACE);
				}
			}
		}

		// Set web Page
#ifdef	BWP_EDITOR
		if (!bPPT)
		{
			*(pWebPage->getPaperSize()) = *pPaperSize;
			pWebPage->getPaperSize()->setHeight(WEB_PAGE_Y);
			pWebPage->getColumn()->copyFromEnv(RIGHT_FACE);
#ifdef USE_HWP_CONTROL
			if ( g_pBInterfaceHandle->m_bOcx )		// HWP OCX
			{
				pWebPage->getPaperSize()->setWidth(pWebPage->width()-(pPage1->leftMargin()+pPage1->rightMargin()-(DEF_LEFT_MARGIN_FOR_WEB+DEF_RIGHT_MARGIN_FOR_WEB)));
			}
#endif // USE_HWP_CONTROL
			pWebPage->getColumn()->initForWebPage(pWebPage->getPaperSize()
				, DEF_LEFT_MARGIN_FOR_WEB
				, DEF_TOP_MARGIN_FOR_WEB
				, DEF_RIGHT_MARGIN_FOR_WEB
				, DEF_BTM_MARGIN_FOR_WEB);
		}
#endif

		PoTextAtt   *pTextAtt = theBWordDoc->getTextAttHandler()->getDefaultAttr();

		//*pTextAtt = *(g_pAppConfig->getDefaultTextAtt());
		PoParaAtt paraAtt;
		paraAtt.setVerAlign(BR_TEXT_VALIGN_BASELINE);		//CAppConfig::init()

		if (bPPT)
		{
			pTextAtt->setEngFSize(360); // 18 point
			pTextAtt->setHanFSize(360); // 18 point
		}
		else
		{
			BrWORD fontSize = g_pAppConfig->getDefaultFontSize();
			pTextAtt->setEngFSize(fontSize);
			pTextAtt->setHanFSize(fontSize);
		}

#ifdef	BIDI_SUPPORT
		if (isBidiFlag())
		{
			paraAtt.setBiDi(BrTRUE);
			paraAtt.setAlign(RIGHT);
			pTextAtt->setBiDi(BrTRUE); // CSP-2108 [9/17/2015 swseo]
		}
#endif	// BIDI_SUPPORT

		if( g_pAppConfig->hasHanFaceName() || g_pAppConfig->hasEngFaceName() )
		{
			LPLOGFONTEX lpex;

			if( g_pAppConfig->hasHanFaceName() ) {
				BrWORD	FaceName[BR_LF_FACESIZE];
				CUtil::BStringToWord(g_pAppConfig->getHanFaceName(), FaceName);
				lpex = g_pSysFontInfo->getLogFontEx(FaceName);
#ifdef BWP_EDITOR
				// CUtil::BYTEtoWORD(lpex->lf.lfFaceName, (LPBYTE)MjBaseFont);
				if ( CUtil::WcsCmp(lpex->lf.lfFaceName, FaceName)!=0 )
					CUtil::WcsCpy(lpex->lf.lfFaceName, FaceName);
#endif
				ASSERT(lpex);
				pTextAtt->setHanFontID(m_FontArray->getFontID(lpex));
			}
			//Andrew C.Lee XPD-17268 ���� �⺻ ��Ʈ ����
			if( g_pAppConfig->hasEngFaceName() ) {
				BrWORD	FaceName[BR_LF_FACESIZE];
				CUtil::BStringToWord(g_pAppConfig->getEngFaceName(), FaceName);
				lpex = g_pSysFontInfo->getLogFontEx(FaceName);
#ifdef BWP_EDITOR
				if ( CUtil::WcsCmp(lpex->lf.lfFaceName, FaceName)!=0 )
					CUtil::WcsCpy(lpex->lf.lfFaceName, FaceName);
#endif
				ASSERT(lpex);
				pTextAtt->setEngFontID(m_FontArray->getFontID(lpex));
			}

			// set default line space for new document XPD-17125

			if(bNewDoc)
			{
				if(getDocType() == BORA_DOCTYPE_DOCX || getDocType() == BORA_DOCTYPE_DOC)
				{
					float fDefaultLineSpace = 0.0;
					paraAtt.setLineSpace(1.08);
					paraAtt.setLineSpaceUnit(LINESP_UNIT_MULTIPLE);
					BrGetDefaultLineSp(&fDefaultLineSpace);
					if ( fDefaultLineSpace )
						paraAtt.setLineSpace(fDefaultLineSpace);
				}
				else if ( paraAtt.getLineSpaceUnit()==LINESP_UNIT_MULTIPLE )
				{
					float fDefaultLineSpace = paraAtt.getLineSpace();
					BrGetDefaultLineSp(&fDefaultLineSpace);
					if ( fDefaultLineSpace )
						paraAtt.setLineSpace(fDefaultLineSpace);
				}
			}

		}

		setProhibitFlag     (g_pAppConfig->getProhibitFlag());
		paraAtt.setOverflowPunct(g_pAppConfig->getStickSymbolFlag());
		//setPullSymbolFlag   (g_pAppConfig->getStickSymbolFlag());
		// setRealSpaceFlag    (g_pAppConfig->getRealSpaceFlag());

		theBWordDoc->setDefaultParaAtt(paraAtt);
	}

	m_TableEngine->setCmdEngine(m_CmdEngine);

	if ( (bNewDoc && !bPPT) || (m_nDocType!=BORA_DOCTYPE_PPT && m_nDocType!=BORA_DOCTYPE_PPTX && m_nDocType!=BORA_DOCTYPE_ODP && m_nDocType!=BORA_DOCTYPE_DOC && m_nDocType!=BORA_DOCTYPE_DOCX && m_nDocType!=BORA_DOCTYPE_HWP && m_nDocType!=BORA_DOCTYPE_GUL && m_nDocType!=BORA_DOCTYPE_RTF) )
	{
#ifdef SUPPORT_PAGELAYOUT_FOR_ODT
		if(m_nDocType == BORA_DOCTYPE_ODT)
			pPage1->getColumn()->initForODT();

#endif
		if(m_nDocType == BORA_DOCTYPE_HWP)
		{
			if(getTypesetInfo()->getFootnoteOption())
				getTypesetInfo()->getFootnoteOption()->initForHWP(BrTRUE);
			if(getTypesetInfo()->getEndnoteOption())
				getTypesetInfo()->getEndnoteOption()->initForHWP(BrFALSE);

			pPage1->getColumn()->initForHWP();

			// UI���� ����� �� �԰� ���� ����
			BrDefaultPaperLayout defaultPaperSize={0,};
			if(BGetDefaultPaperSize(&defaultPaperSize))
			{
				pPage1->getPaperSize()->setWidth(defaultPaperSize.fPaperWidth);
				pPage1->getPaperSize()->setHeight(defaultPaperSize.fPaperHeight);

				if(defaultPaperSize.nDirection == LANDSCAPE)
				{
					pPage1->getPaperSize()->setWidth(defaultPaperSize.fPaperHeight);
					pPage1->getPaperSize()->setHeight(defaultPaperSize.fPaperWidth);
				}
			}
		}
		if(isFromTxt() && g_pBInterfaceHandle->IsOpenTextInWordLayout())
			pPage1->getColumn()->initForTXT();

#ifdef SUPPORT_PAGELAYOUT_FOR_ODT
		if(m_nDocType == BORA_DOCTYPE_ODT)
			pFrame = CTextProc::createDefaultBasicFrameForODT(this, pPage1);
		else
#endif
			pFrame = CTextProc::createDefaultBasicFrame(this, pPage1);

		if(pFrame!=BrNULL)
		{
			CTextProc::setDefaultTextFrame(this, pFrame, false);
#ifdef	BWP_EDITOR
			m_CmdEngine->setMode(TEXTEDIT);
			m_Caret->update(pFrame, BrFALSE);
#endif
		}

		if(pMast1)
			CTextProc::createDefaultBasicFrame(this, pMast1);
		if(pMast2)
			CTextProc::createDefaultBasicFrame(this, pMast2);
	}

#ifdef	BWP_EDITOR
	if(pWebPage)
		CTextProc::createDefaultBasicFrame(this, pWebPage);
#endif
#ifdef LG_SIMPLE_PO60_SECTION
	m_nCurSectionID = 0;
#endif
	//[2012.10.26][TID:7609][��ȸ��]Section ���� �⺻ �ڵ�
	//������ ���� ��������� CSectionInfomation�� ������ First Line ������ �޾��ش�.
	if(bNewDoc)
	{
		if(m_nDocType == BORA_DOCTYPE_DOC
			|| m_nDocType == BORA_DOCTYPE_DOCX
			|| m_nDocType == BORA_DOCTYPE_HWP
			|| m_nDocType == BORA_DOCTYPE_ODT)
		{
			CLine* pDocStartLine = getFirstLine();
			CSectionInfomation* pSectionInfomation = BrNEW CSectionInfomation;

			//[2014.11.24][ZPD-4711][���ؼ�] ���� ������ ���� �� �⺻ ����, ���� ��� ����(���� ���� ����)
			switch(m_nDocType)
			{
			case BORA_DOCTYPE_DOC:
			case BORA_DOCTYPE_DOCX:
			case BORA_DOCTYPE_HWP:
				{
					CNote* pFootNote = BrNEW CNote();
					pSectionInfomation->setFootNote(pFootNote);

					CNote* pEndNote = BrNEW CNote();
					pSectionInfomation->setEndNote(pEndNote);

					if(m_nDocType == BORA_DOCTYPE_DOC || m_nDocType == BORA_DOCTYPE_DOCX)
					{
						pFootNote->initForDOCX(BrTRUE);
						pEndNote->initForDOCX(BrFALSE);
					}
					else if(m_nDocType == BORA_DOCTYPE_HWP)
					{
						pFootNote->initForHWP(BrTRUE);
						pEndNote->initForHWP(BrFALSE);
						pSectionInfomation->initForHWP();
					}
				}
				break;
#ifdef SUPPORT_PAGELAYOUT_FOR_ODT
			case BORA_DOCTYPE_ODT:
				// [WPD-6501]
				m_TypesetInfo->getEndnoteOption()->initForODT(BrFALSE);

				pSectionInfomation->setPageStyleID(1);
				pSectionInfomation->setPageStyleName("Standard");
				break;
#endif //SUPPORT_PAGELAYOUT_FOR_ODT
			}

			//Section �� ��� Header/Footer�� ��� �ִ� frame�� ������ �Ѵ�.
			if( m_nDocType == BORA_DOCTYPE_DOC ||
				m_nDocType == BORA_DOCTYPE_DOCX
#ifndef SUPPORT_ODT_HEADER_FOOTER
				|| m_nDocType == BORA_DOCTYPE_ODT	//ODT �������� page style header/footer ����� �ʰ�, section header/footer ��ϴ� ���
#endif //SUPPORT_ODT_HEADER_FOOTER
				)
			{
				pSectionInfomation->getHeaderFooter()->MakeDefaultFrameArr();
			}

			pDocStartLine->setSectionInformation(pSectionInfomation);
			pDocStartLine->setRegionFirst(BrTRUE);
			pDocStartLine->setRegionLast(BrTRUE);

			if(pDocStartLine->getPage() && pSectionInfomation)
			{
				CColumn* column = pDocStartLine->getPage()->getColumn();
				pSectionInfomation->setPageMarginTop(column->topMar());
				pSectionInfomation->setPageMarginBottom(column->btmMar());
				pSectionInfomation->setPageMarginLeft(column->leftMar());
				pSectionInfomation->setPageMarginRight(column->rightMar());
			}

			ArrangeHeaderFooter();
		}
	}

	//[2014.01.27][TID:22783] HWP �Ӹ��� �ٴڱ�
	if(m_nDocType == BORA_DOCTYPE_HWP)
	{
		if(m_pHeaderArray)
		{
			for(BrINT i = 0; i < m_pHeaderArray->size(); i++)
			{
				CFrame *pFrame = m_pHeaderArray->at(i);
				BR_SAFE_DELETE(pFrame);
			}
			m_pHeaderArray->RemoveAll();
		}
		if(m_pFooterArray)
		{
			for(BrINT i = 0; i < m_pFooterArray->size(); i++)
			{
				CFrame *pFrame = m_pFooterArray->at(i);
				BR_SAFE_DELETE(pFrame);
			}
			m_pFooterArray->RemoveAll();
		}
	}

	m_CmdEngine->setDocEndCoord(DEF_PAGE_GAP + pPage1->width() + DEF_PAGE_GAP,
		DEF_PAGE_GAP + pPage1->height() + DEF_PAGE_GAP);

	// CTextProc::resetAnchorPositionCache();



	// Set wrap to window mode
	// setWraptoWindow(BrTRUE);
	// m_CmdEngine->wrapToWindow(BrTRUE);

	//jkjung setModifiedFlag(BrFALSE);
#ifdef USE_RULERBAR//[2012.08.17][MistY][TID:#7674] RulerBar ����
	m_pHRuler = BrNULL;
	m_pVRuler = BrNULL;
#endif

//[2012.08.20][������][TID:7901] SummayInfo import/export ����.
	m_pSummaryData = BrNULL;

	m_bIsOpenPasswordDoc  = BrFALSE;
	m_nIncPageNum = 1;
#ifdef PPT_EDITOR
	m_bModifiedMasterPageInfoArray->resize(0);
#endif //PPT_EDITOR

	if (bPPT)
	{
		initDocumentForPPT();
	}

	m_GuideMgr->init(bPPT);

//	m_ClipBoardEngine.initClipBoardEngine();

	g_pAppStatic->m_pTableDrawInfo->init((BrEditModeType)m_nBWPEngineMode);

	setfDntBlnSbDbWid(BrTRUE);

	// set Jisu Version
	setJisuVersion(BIsJISUApp());
	// set ODT Editor Version
	setODTEditorVersion(BIsODTEditorApp());
	m_pFEEngine->setDocument(this);
}

void BoraDoc::setKinsokuLocale(BString &strLocale)
{
	m_nKinsokuLocale = BR_LOCALE_KOREAN;
	if (strLocale.length() > 0) {
		if (strcmp(strLocale, "ko-KR") == 0)
			m_nKinsokuLocale = BR_LOCALE_KOREAN;
		else if (strcmp(strLocale, "ja-JP") == 0)
			m_nKinsokuLocale = BR_LOCALE_JAPANESE;
		else if (strcmp(strLocale, "zh-CN") == 0)
			m_nKinsokuLocale = BR_LOCALE_S_CHINESE;
		else if (strcmp(strLocale, "zh-TW") == 0)
			m_nKinsokuLocale = BR_LOCALE_T_CHINESE_TW;
	}
}

void BoraDoc::setNoLineBreaksDefaultChars(void)
{
	m_strNoLineBreaksAfter.setUnicodeCodes(DefaultNoLineBreaksAfter, BrSizeOf(DefaultNoLineBreaksAfter));
	m_strNoLineBreaksBefore.setUnicodeCodes(DefaultNoLineBreaksBefore, BrSizeOf(DefaultNoLineBreaksBefore));
}


// for html speed, 2007.2.13
/*
BrBOOL BoraDoc::OnNewDocument()
{
	//jkjung m_strPathName = "";
	m_bModified = BrFALSE;
	return BrTRUE;
}
*/

//[2012.10.24][TID:7609][��ȸ��]Section Search Routine ����ȭ
BrINT BoraDoc::RegisterSectionLine(CLine* pSectionLine)
{
	if(!pSectionLine)
		return -1;

	//[2014.11.04][TID:30335] �̹� ��ϵǾ� ������ return �Ѵ�.
	BrINT nContain = SectionLineVector.contains(pSectionLine);
	if(nContain)
	{
		BrINT nIndex = SectionLineVector.find(pSectionLine);
		return nIndex;
	}

	//Section Line Vector�� Line�� ��ġ�� ���� ���ĵ� ���¸� �����ؾ��Ѵ�.
	BrINT nPrevSectionNum = -1;
	CLine* pPrevLine = pSectionLine->getPrev();
	if(pPrevLine)
	{
#ifdef LG_SIMPLE_PO60_SECTION
		CLine* pPrevSectionLine = getPrevSectionLine(pSectionLine);
		nPrevSectionNum = getSectionLineIndexBySectionLine(pPrevSectionLine);
#else
		CLine* pPrevSectionLine = getPrevSectionLine(pPrevLine);	//Mantis 52120
		nPrevSectionNum = getSectionLineIndexBySectionLine(pPrevSectionLine);
#endif
	}

	BrINT nSectionID = nPrevSectionNum+1;
	SectionLineVector.InsertAt(nSectionID, pSectionLine);

	m_pFEEngine->initNoteCount(nPrevSectionNum);  // SUPPORT_NOTE_COUNT_IN_SECTION
	m_pFEEngine->initNoteCount(nSectionID);  // SUPPORT_NOTE_COUNT_IN_SECTION

#ifdef LG_SIMPLE_PO60_SECTION
	m_nCurSectionID = nPrevSectionNum+1;
	pSectionLine->setSectionID(m_nCurSectionID);

	int nSectionID = m_nCurSectionID;
	int nSize = SectionLineVector.GetSize();
	CLine *pEndLine, *pLine, *pNextSectionLine = BrNULL;

	pLine = pSectionLine->getNext();
	for(int i = nSectionID+1; i <= nSize; i++, nSectionID++)
	{
		if( i < nSize )
			pNextSectionLine = SectionLineVector.at(i);

		if( pNextSectionLine )
		{
			pEndLine = pNextSectionLine;
		}
		else
		{
			pEndLine = getLastLine();
		}

		while(pLine )
		{
			pLine->setSectionID(nSectionID);
			if( pEndLine == pLine )
				break;
			pLine = pLine->getNext();
		}
	}
#endif

	//[2014.11.04][TID:30282] CHeaderFooter���� sectionInfo ������ ���� �ϱ� ����, CHeaderFooter�� section ID set
	for(BrINT i = 0; i < SectionLineVector.size(); i++)
	{
		CLine *pSectionLine = SectionLineVector.at(i);
		CSectionInfomation *pSectionInfo = pSectionLine ? pSectionLine->getSectionInformation() : BrNULL;
		if(!pSectionInfo) continue;

		pSectionLine->setRefSectionLine(pSectionLine);

		CLine *pNext = pSectionLine->getNext();
		if(pNext && pNext->getRefSectionLine() != pSectionLine)
		{
			while(pNext)
			{
				if(pNext->getSectionInformation())
					break;

				pNext->setRefSectionLine(pSectionLine);
				pNext = pNext->getNext();
			}
		}

		CHeaderFooter *pHeaderFooter = pSectionInfo->getHeaderFooter();
		if(!pHeaderFooter) continue;

		pHeaderFooter->set_parent_id(i);

		if(i == 0)
		{
			pHeaderFooter->setAllLinked(BrFALSE);	//ZPD-5596, 0��° ������ ���� ������ header/footer�� �����ϴ�.
		}
	}

	return nSectionID;	//return section id
}

//[2012.10.24][TID:7609][��ȸ��]Section Search Routine ����ȭ
BrBOOL BoraDoc::UnregisterSectionLine(CLine* pSectionLine)
{
	if(!pSectionLine)
		return BrFALSE;

	BrINT nContain = SectionLineVector.contains(pSectionLine);
	if (nContain == 0)
		return BrTRUE;

	//int nIndex = SectionLineVector.bsearch(pSectionLine);
	int nIndex = SectionLineVector.find(pSectionLine);
	m_pFEEngine->mergeNoteCount(nIndex);  // SUPPORT_NOTE_COUNT_IN_SECTION
	SectionLineVector.RemoveAt(nIndex);

	CLine *pPreSecLine = pSectionLine->getPrev();
	CLine *pNext = pSectionLine->getNext();

	pSectionLine->setRefSectionLine(pPreSecLine);
	if (pNext && pNext->getRefSectionLine() != pPreSecLine)
	{
		while (pNext)
		{
			if (pNext->getSectionInformation())
				break;

			pNext->setRefSectionLine(pPreSecLine);
			pNext = pNext->getNext();
		}
	}

	//[2014.11.04][TID:30282] CHeaderFooter���� sectionInfo ������ ���� �ϱ� ����, CHeaderFooter�� section ID set
	CSectionInfomation *sect_info = pSectionLine->getSectionInformation();
	if (sect_info)
		sect_info->getHeaderFooter()->UnlinkDocument();	//ZPD-3945, crash �̽� ����

	for (BrINT nSectionID = 0; nSectionID < SectionLineVector.GetSize(); nSectionID++)
	{
		CLine *pSectionLine = SectionLineVector.GetAt(nSectionID);
		CSectionInfomation *pSectionInfo = pSectionLine ? pSectionLine->getSectionInformation() : BrNULL;
		if (pSectionInfo && pSectionInfo->getHeaderFooter())	// AOM-41070
			pSectionInfo->getHeaderFooter()->set_parent_id(nSectionID);
	}

#ifdef LG_SIMPLE_PO60_SECTION
	int nSectionID = nIndex - 1;
	m_nCurSectionID = nSectionID;
	pSectionLine->setSectionID(nSectionID);

	int nSize = SectionLineVector.GetSize();
	CLine *pEndLine, *pLine, *pNextSectionLine = BrNULL;

	pLine = pSectionLine->getNext();
	if (pLine)
	{
		for (int i = nSectionID + 1; i <= nSize; i++, nSectionID++)
		{
			if (i < nSize)
				pNextSectionLine = SectionLineVector.at(i);

			if (pNextSectionLine)
			{
				pEndLine = pNextSectionLine;
			}
			else
			{
				pEndLine = getLastLine();
			}

			while (pLine)
			{
				pLine->setSectionID(nSectionID);
				if (pEndLine == pLine)
					break;
				pLine = pLine->getNext();
			}
		}
	}
#endif

	return BrTRUE;
}

//[2013.01.28][TID:7609][��ȸ��]Section ���� �⺻ �ڵ�
BrBOOL BoraDoc::MoveSectionLine(CLine* pSectionLineBefore, CLine* pSectionLineAfter)
{
	if(!pSectionLineBefore || !pSectionLineAfter)
		return BrFALSE;

	CSectionInfomation* pSectionInfoBefore = pSectionLineBefore->getSectionInformation();
	CSectionInfomation* pSectionInfoAfter = pSectionLineAfter->getSectionInformation();
	if(!pSectionInfoBefore || pSectionInfoAfter)
		return BrFALSE;

	pSectionLineBefore->setSectionInformation(BrNULL);
	pSectionLineAfter->setSectionInformation(pSectionInfoBefore);
	pSectionLineAfter->setUpdateSection(pSectionLineBefore->isUpdateSection());
	return BrTRUE;
}

//[2012.08.12][TID:7609][��ȸ��]Section ���� �⺻ �ڵ�
//���� Line�� �����Ͽ� ���� �ִ� Line�� �� ���� ����� Section Line�� �����´�.
CLine* BoraDoc::getPrevSectionLine(CLine* pCurLine)
{
	CLine* pSearchLine = pCurLine;
	if(!pSearchLine)
		return BrNULL;

	if(pCurLine->getFrame() && pCurLine->getFrame()->isWordMemoFrame())
	{
		pSearchLine = pCurLine->getFrame()->getAnchorLine();

		if(!pSearchLine)
			return BrNULL;
	}

	if(pSearchLine->getSectionInformation())
		return pSearchLine;
	else if(!pSearchLine->isDirty() && pSearchLine->getFrame() && pSearchLine->getFrame()->isBasic() && pSearchLine->getRefSectionLine())
		return pSearchLine->getRefSectionLine();

#ifdef LG_SIMPLE_PO60_SECTION
	if( (pSearchLine->getSectionID()-1) >= 0)
	{
		pSearchLine = SectionLineVector.at(pSearchLine->getSectionID()-1);
		if(pSearchLine->getSectionInformation())
			return pSearchLine;
	}
	else if( 0 == pSearchLine->getSectionID() )
		return SectionLineVector.at(0);

#endif

	//Search Line ���� ���� ����ȭ �˰�����.
	BrBOOL bUseFastSectionSearchAlgorithm = BrTRUE;
	if(bUseFastSectionSearchAlgorithm)
	{
		CFrame* pCurFrame = pCurLine->getFrame();
		if( !pCurFrame )
			return BrNULL;

		if(pCurFrame->isBasic() )
		{
			CPage* pCurPage = pCurFrame->getPage();
			if(!pCurPage)
				return BrNULL;

			BrINT nNumSectionLine = SectionLineVector.GetSize();
			for(int i=(nNumSectionLine-1) ; i>=0 ; i--)
			//for(int i=0 ; i<nNumSectionLine ; i++)
			{
				CLine* pSectionLine	= (CLine*)SectionLineVector.GetAt(i);
				if(!pSectionLine)
					continue;

				CSectionInfomation* pSectionInfo = pSectionLine->getSectionInformation();
				if(!pSectionInfo)
					continue;

				CFrame* pSectionFrame = pSectionLine->getFrame();
				if(!pSectionFrame)
					continue;

				CPage* pSectionPage = pSectionFrame->getPage();
				if(!pSectionPage)
					continue;

				if(pSectionPage->getPageNum()==pCurPage->getPageNum() && pCurLine->getFrame()->isBasic())
				{
					pSearchLine = pCurLine;
					break;
				}
				else if(pSectionPage->getPageNum()<pCurPage->getPageNum())
				{
					return pSectionLine;
				}
			}
		}
		else
		{
			// update table-frame before getRootParentFrame().
			if (pCurFrame->isCell()) {
				CBCell *pCell = pCurFrame->getCell();
				CBTable *pTable = pCell->getTable();
				pTable = pTable->getFirstTable();
				pCurFrame = pTable->getFrame();
			}

			// [XPD-6186] Frame ������ SectionLine ã�ºκ� ����
			pCurFrame->getRootParentFrame(&pSearchLine);

			if( (pSearchLine != BrNULL) && (pSearchLine->getFrame() != BrNULL) )
			{
				if(!pSearchLine->getFrame()->isBasic())
					return BrNULL;
			}
// 			CBCell * pCell = BrNULL;
// 			while(1){
// 				if( pCurFrame->isCell())
// 				{
// 					pCell = pCurFrame->getCell();
// 					if (!pCell)
// 						return BrNULL;
//
// 					CBTable *pTable = pCell->getTable();
// 					pTable = pTable->getFirstTable();
// 					pCurFrame = pTable->getFrame();
// 				}
// 				else
// 					return BrNULL;
//
// 				if( pCurFrame && pCurFrame->getAnchorLine() )
// 					pSearchLine = pCurFrame->getAnchorLine();
// 				else
// 					return BrNULL; // M49026 [12/27/2013 swseo]
// 				//else
// 				//{
// 				//	int x =10;
// 				//	pSearchLine = pCurLine->getBasicLine();
// 				//}
//
// 				if(pSearchLine->getFrame()->isBasic())
// 					break;
// 				else
// 					pCurFrame = pSearchLine->getFrame();
// 			}
		}
	}

	//Search Line�� Previous Line�� ��� ���󰡸鼭 ������ ù��° Section Line�� ã�´�.
	while(pSearchLine)
	{
		if(pSearchLine->getSectionInformation())
			return pSearchLine;

		pSearchLine = pSearchLine->getPrev();
	}

	return BrNULL;
}

//[2012.08.12][TID:7609][��ȸ��]Section ���� �⺻ �ڵ�
//���� Line�� �����Ͽ� ������ �ִ� Line�� �� ���� ����� Section Line�� �����´�.
CLine* BoraDoc::getNextSectionLine(CLine* pCurLine)
{
	CLine* pSearchLine = pCurLine;
	if(!pSearchLine)
		return BrNULL;

	if(pSearchLine->getSectionInformation())
		return pSearchLine;

	//if ( g_BoraThreadAtom.m_nSaveStatus==SAVE_STATUS_PROGRESS )
	//{
	//	return getNextSectionLineEx(pCurLine);	// XPD-25973
	//}

	if(!pSearchLine->isDirty() && pSearchLine->getFrame() && pSearchLine->getFrame()->isBasic() && pSearchLine->getRefSectionLine())
	{
		int nIndex = getSectionLineIndexBySectionLine(pSearchLine->getRefSectionLine());
		if(nIndex >= 0)
		{
			CLine *pTmp = getSectionLineBySectionLineIndex(nIndex+1);
			if(pTmp && pTmp->getSectionInformation())
				return pTmp;
			else
				return BrNULL;
		}
	}

#ifdef LG_SIMPLE_PO60_SECTION
	if( (pSearchLine->getSectionID()+1) < SectionLineVector.size() )
	{
		pSearchLine = SectionLineVector.at(pSearchLine->getSectionID()+1);
		if(pSearchLine->getSectionInformation())
			return pSearchLine;
	}
	else
		return BrNULL;
#else
	if(pSearchLine->getSectionInformation())
		return pSearchLine;
#endif

	//Searh Line ���� ���� ����ȭ �˰�����.
	BrBOOL bUseFastSectionSearchAlgorithm = BrTRUE;
	if(bUseFastSectionSearchAlgorithm)
	{
		CFrame* pCurFrame = pCurLine->getFrame();
		if(!pCurFrame)
			return BrNULL;

		if( pCurFrame->isBasic() )
		{
			CPage* pCurPage = pCurFrame->getPage();
			if(!pCurPage)
				pCurPage = getEditingPageArray()->GetFirst();

			BrINT nNumSectionLine = SectionLineVector.GetSize();
			for(int i=0 ; i<nNumSectionLine ; i++)
			//for(int i=(nNumSectionLine-1) ; i>=0 ; i--)
			{
				CLine* pSectionLine	= (CLine*)SectionLineVector.GetAt(i);
				if(!pSectionLine)
					continue;

				CSectionInfomation* pSectionInfo = pSectionLine->getSectionInformation();
				if(!pSectionInfo)
					continue;

				CFrame* pSectionFrame = pSectionLine->getFrame();
				if(!pSectionFrame)
					continue;

				CPage* pSectionPage = pSectionFrame->getPage();
				if(!pSectionPage)
					continue;

				if(pSectionPage->getPageNum()==pCurPage->getPageNum())
				{
					pSearchLine = pCurLine;
					break;
				}
				else if(pSectionPage->getPageNum()>pCurPage->getPageNum())
				{
					pSearchLine = pSectionLine;
				}
			}
		}
		else
		{
			CBCell * pCell = BrNULL;
			while(1){
				if( pCurFrame->isCell())
				{
					pCell = pCurFrame->getCell();
					if (!pCell)
						return BrNULL;

					CBTable *pTable = pCell->getTable();
					pTable = pTable->getFirstTable();
					pCurFrame = pTable->getFrame();
				}
				else
					return BrNULL;

				if( pCurFrame->getAnchorLine() )
					pSearchLine = pCurFrame->getAnchorLine();
				//else
				//{
				//	int x =10;
				//	pSearchLine = pCurLine->getBasicLine();
				//}

				if(pSearchLine->getFrame()->isBasic())
					break;
				else
					pCurFrame = pSearchLine->getFrame();
			}
// 			if( pCurFrame->isCell())
// 			{
// 				CBCell *pCell = pCurFrame->getCell();
// 				if (pCell)
// 				{
// 					pCurFrame = pCell->getTableFrame();
// 				}
// 			}
//
// 			if( pCurFrame->getAnchorLine() )
// 				pSearchLine = pCurFrame->getAnchorLine();
		}
	}

	//Search Line�� Next Line�� ��� ���󰡸鼭 ������ ù��° Section Line�� ã�´�.
	CLine *pPrevSearchLine = BrNULL;
	while(pSearchLine)
	{
		if(pSearchLine->getSectionInformation())
			return pSearchLine;

		pPrevSearchLine = pSearchLine;
		pSearchLine = pSearchLine->getNext();

		if(pPrevSearchLine == pSearchLine)		//[2013.09.09][TID:15717] ���ѷ��� ���� ����
			break;
	}

	return BrNULL;
}

// get section information line while saving the document
//CLine *BoraDoc::getNextSectionLineEx(CLine *pCurLine)
//{
//	if ( !pCurLine )
//		return BrNULL;
//
//	// check current line
//	if ( pCurLine->getSectionInformation() )
//		return pCurLine;
//
//	int nIndex = getSectionLineIndexBySectionLine(pCurLine->getRefSectionLine());
//	if(nIndex >= 0)
//	{
//		CLine *pLine = getSectionLineBySectionLineIndex(nIndex+1);
//		if(pLine && pLine->getSectionInformation())
//			return pLine;
//	}
//
//	// check next line
//	CLine *pLine = pCurLine->getNext();
//	while ( pLine )
//	{
//		if ( pLine->getSectionInformation() )	return pLine;
//		pLine = pLine->getNext();
//	}
//
//	// check previous line
//	pLine = pCurLine->getPrev();
//	while ( pLine )
//	{
//		if ( pLine->getSectionInformation() )	return pLine;
//		pLine = pLine->getPrev();
//	}
//
//	// make a default section information
//	CSectionInfomation* pSectionInfomation = BrNEW CSectionInfomation;
//	pCurLine->setSectionInformation(pSectionInfomation);
//
//	return pCurLine;
//}

//[2012.11.01][TID:7609][��ȸ��]Section ���� �⺻ �ڵ�
//���� pCurLine�� �����ϴ� Section�� ���۵Ǵ� Page�� ��´�.
CPage* BoraDoc::getSectionPageStarted(CLine* pCurLine)
{
	CLine* pSectionLine = getPrevSectionLine(pCurLine);
	CPage* pSectionPageStarted = BrNULL;

	if(pSectionLine)
		pSectionPageStarted = pSectionLine->getPage();

	return pSectionPageStarted;
}

//[2012.11.01][TID:7609][��ȸ��]Section ���� �⺻ �ڵ�
//���� pCurLine�� �����ϴ� Section�� ������ Page�� ��´�.
CPage* BoraDoc::getSectionPageEnded(CLine* pCurLine)
{
	CLine* pLine = pCurLine;
	if(pLine && pLine->getSectionInformation())
		pLine = pCurLine->getNext();

	CLine* pSectionLine = getNextSectionLine(pLine);
	CPage* pSectionPageEnded = BrNULL;

	if(!pSectionLine)
	{
		pSectionPageEnded = theBWordDoc->getPageArray()->GetLast();
	}
	else//if(pSectionLine)
	{
		CLine* pPrevLine = pSectionLine->getPrev();
		pSectionPageEnded = pPrevLine ? pPrevLine->getPage() : BrNULL;
	}

	return pSectionPageEnded;
}

//[2012.11.01][TID:7609][��ȸ��]Section ���� �⺻ �ڵ�
//�������� �����ϴ� Section (Line)�� ���� ��´�.
BrINT BoraDoc::getTotalSectionLines()
{
	BrINT nTotalSectionLine = SectionLineVector.size();
	return nTotalSectionLine;
}

//[2012.10.30][TID:7609][��ȸ��]Section ���� �⺻ �ڵ�
//������������ �ش� Section Line�� Index�� ��´�.
BrINT BoraDoc::getSectionLineIndexBySectionLine(CLine* pSectionLine)
{
#ifdef LG_SIMPLE_PO60_SECTION
	if( pSectionLine )
		return pSectionLine->getSectionID();
	else
		return -1;
#endif

	BrINT nNumSectionLine = SectionLineVector.GetSize();
	for(int i=0 ; i<nNumSectionLine ; i++)
	{
		CLine* pTempSectionLine = (CLine*)SectionLineVector.GetAt(i);
		if(pTempSectionLine == pSectionLine)
			return i;
	}
	// section line�� ��ϵǾ� ���� ������ ����� �Ŀ� index�� return XPD-20993
	if ( IsValidObject(pSectionLine) && pSectionLine->getSectionInformation() )
	{
		return RegisterSectionLine(pSectionLine);
	}
	return -1;
}

//[2012.10.30][TID:7609][��ȸ��]Section ���� �⺻ �ڵ�
//���������� Section Index�� �̿��Ͽ� Section Line�� ��´�.
CLine* BoraDoc::getSectionLineBySectionLineIndex(BrINT nSectionLineIndex)
{
	if(nSectionLineIndex < 0 || nSectionLineIndex >= SectionLineVector.GetSize())
		return BrNULL;

	return SectionLineVector.GetAt(nSectionLineIndex);
}

//���������� Section Index�� �̿��Ͽ� SectionInfo�� ��´�.
CSectionInfomation* BoraDoc::getSectionInfo(BrINT nSectionNum)
{
	if(nSectionNum < 0 || nSectionNum >= SectionLineVector.GetSize())
		return BrNULL;

	if(SectionLineVector.GetAt(nSectionNum))
		return SectionLineVector.GetAt(nSectionNum)->getSectionInformation();

	return BrNULL;
}

//[2012.11.13][TID:7609][��ȸ��]Section ���� �⺻ �ڵ�
//���� Page�� �����ϴ� Section Line�� ������ ��´�.
BrINT BoraDoc::getTotalSectionLinesAtCurPage(CPage* pCurPage)
{
	BrINT nTotalSectionLineAtCurPage = 0;

	BrINT nNumSectionLine = SectionLineVector.GetSize();
	for(int i=0 ; i<nNumSectionLine ; i++)
	{
		CLine* pTempSectionLine = (CLine*)SectionLineVector.GetAt(i);
		if ( IsValidObject(pTempSectionLine) )
		{
			CPage* pTempSectionPage = pTempSectionLine->getPage();
			if(pCurPage && pTempSectionPage && pCurPage->getPageNum() == pTempSectionPage->getPageNum())
				nTotalSectionLineAtCurPage++;
		}
	}

	return nTotalSectionLineAtCurPage;
}

//[2012.11.13][TID:7609][��ȸ��]Section ���� �⺻ �ڵ�
//���� Page�� ������ �����ؼ� Section Line�� Index�� ��´�.
BrINT BoraDoc::getSectionLineIndexBySectionLineAtCurPage(CLine* pSectionLine,CPage* pCurPage)
{
	BrINT nSectionLineAtCurPage = 0;

	BrINT nNumSectionLine = SectionLineVector.GetSize();
	for(int i=0 ; i<nNumSectionLine ; i++)
	{
		CLine* pTempSectionLine = (CLine*)SectionLineVector.GetAt(i);
		if ( IsValidObject(pTempSectionLine) )
		{
			CPage* pTempSectionPage = pTempSectionLine->getPage();
			if(pCurPage && pTempSectionPage && pCurPage->getPageNum() == pTempSectionPage->getPageNum())
			{
				if(pSectionLine == pTempSectionLine)
					break;

				nSectionLineAtCurPage++;
			}
		}
	}

	return nSectionLineAtCurPage;
}

//[2012.11.13][TID:7609][��ȸ��]Section ���� �⺻ �ڵ�
//���� Page�� ������ �����ؼ� Section Line Index�� �������� Section Line�� ��´�.
CLine* BoraDoc::getSectionLineBySectionLineIndexAtCurPage(BrINT nSectionLineIndex, CPage* pCurPage)
{
	BrINT nNumSectionLineAtCurPage = 0;
	BrINT nNumSectionLine = SectionLineVector.GetSize();
	for(int i=0 ; i<nNumSectionLine ; i++)
	{
		CLine* pTempSectionLine = (CLine*)SectionLineVector.GetAt(i);
		if ( IsValidObject(pTempSectionLine) )
		{
			CPage* pTempSectionPage = pTempSectionLine->getPage();
			if(pCurPage && pTempSectionPage && pCurPage->getPageNum() == pTempSectionPage->getPageNum())
			{
				if(nNumSectionLineAtCurPage == nSectionLineIndex)
					return pTempSectionLine;

				nNumSectionLineAtCurPage++;
			}
		}
	}

	return BrNULL;
}

//[2013.01.24][TID:7609][��ȸ��]Section ���� �⺻ �ڵ�
//Ư�� Section�� ���� ������ CharsSet�� �����´�.
CCharSet* BoraDoc::getSectionLastCharSet(CLine* pSectionLine)
{
	if( !pSectionLine )
		return BrNULL;
	CLine* pSectionLastLine = BrNULL;
	CLine* pScanLine = pSectionLine;

	BrBOOL bMeetDocEnd = BrFALSE;
	BrBOOL bMeetNewSection = BrFALSE;
	while(!bMeetDocEnd && !bMeetNewSection)
	{
		pSectionLastLine = pScanLine;


		pScanLine = pScanLine->getNext();

		if(pScanLine == BrNULL)
			bMeetDocEnd = BrTRUE;
		else if(pScanLine != pSectionLine && pScanLine->getSectionInformation())
			bMeetNewSection = BrTRUE;
	}


	BrINT nCharNum = pSectionLastLine->getCharNum();
	CCharSet* pLineEndCharSet = pSectionLastLine->getCharSet(nCharNum-1);

	return pLineEndCharSet;
}


CHeaderFooter* BoraDoc::GetHeaderFooter(BrINT id,
                                        CSectionInfomation** section_info/*=BrNULL*/,
                                        CPageStyle** page_style/*=BrNULL*/)
{
#ifdef SUPPORT_ODT_HEADER_FOOTER
	if (isFromOdt()) {
		CODTPageRef* page_ref = m_ODTPageRefArray->getODTPageRef(id);
		CPageStyle* style = page_ref? page_ref->getPageStyle(): BrNULL;
		if (page_style)
			*page_style = style;
		return style? style->getHeaderFooter(): BrNULL;
	}
#endif //SUPPORT_ODT_HEADER_FOOTER

	CSectionInfomation* section = getSectionInfo(id);
	if (section_info)
		*section_info = section;
	return section? section->getHeaderFooter(): BrNULL;
}


//���� CHeaderFooter�� ������ �ִ� ��� Header/Footer Frame���� Reference�� ��´�.
BVector<CFrame> BoraDoc::MakeHeaderFooterFrameArr(CHeaderFooter* header_footer)
{
	BVector<CFrame> frame_arr;
	if (BrNULL == header_footer)
		return frame_arr;

	for (BrINT i = 0; i < HDR_FTR_MAX; ++i) {
		CFrame* frame = header_footer->GetFrame(static_cast<BrHdrFtrIdx>(i));
		if (frame)
			frame_arr.Add(frame);
	}
	return frame_arr;
}


//[2012.11.13][TID:7609] ��� Header/Footer Frame���� Reference�� ��´�.
void BoraDoc::getAllHeaderFooterFrames(BVector<CFrame>& pAllFrameArray, BrBOOL bLinkedFrame)
{
	if(isFromHwp())
	{
		//Typeset Header/Footer
		CFrame *pFrame = BrNULL;
		CFrame *pTmpFrame = BrNULL;
		if(m_pHeaderArray)
		{
			for(BrINT i = 0; i < m_pHeaderArray->GetSize(); i++)
			{
				pFrame = m_pHeaderArray->at(i);
				pAllFrameArray.Add(pFrame);

				if(bLinkedFrame)
				{
					BArray<CFrame*> bArray;

					theBWordDoc->getLinkedHeaderFooterFrames(pFrame, bArray);
					for(int j=0; j<bArray.size(); j++)
					{
						pTmpFrame = bArray.at(j);
						if(pFrame != pTmpFrame)
							pAllFrameArray.Add(pTmpFrame);
					}
				}

			}
		}

		if(m_pFooterArray)
		{
			for(BrINT i = 0; i < m_pFooterArray->GetSize(); i++)
			{
				pFrame = m_pFooterArray->at(i);
				pAllFrameArray.Add(pFrame);

				if(bLinkedFrame)
				{
					BArray<CFrame*> bArray;

					theBWordDoc->getLinkedHeaderFooterFrames(pFrame, bArray);
					for(int j=0; j<bArray.size(); j++)
					{
						pTmpFrame = bArray.at(j);
						if(pFrame != pTmpFrame)
							pAllFrameArray.Add(pTmpFrame);
					}
				}
			}
		}
	}
#ifdef SUPPORT_ODT_HEADER_FOOTER
	else if(isFromOdt())
	{
		//PageStyle Header/Footer
		for(BrINT i = 0; i < m_PageStyleArray->size(); i++)
		{
			CPageStyle *pPageStyle = m_PageStyleArray->at(i);
			if(!pPageStyle)
				continue;

			CHeaderFooter *pHeaderFooter = pPageStyle->getHeaderFooter();
			if(!pHeaderFooter)
				continue;

			BVector<CFrame> pFrameArray = MakeHeaderFooterFrameArr(pHeaderFooter);
			pAllFrameArray.Append(pFrameArray);
		}
	}
#endif
	else
	{
		//Section Header/Footer
		for(BrINT i = 0; i < SectionLineVector.size(); i++)
		{
			CLine *pSectionLine = (CLine*)SectionLineVector.at(i);
			if(!pSectionLine)
				continue;

			CSectionInfomation *pSectionInfo = pSectionLine->getSectionInformation();
			if(!pSectionInfo)
				continue;

			CHeaderFooter *pHeaderFooter = pSectionInfo->getHeaderFooter();
			BVector<CFrame> pFrameArray = MakeHeaderFooterFrameArr(pHeaderFooter);

			pAllFrameArray.Append(pFrameArray);
		}
	}
}

// Link to prev ���� Ȯ��
BrBOOL BoraDoc::isLinkedHeaderFooter(CFrame *pFrame)
{
	if(getBWPEngineMode() != EDITOR_WORD) return BrFALSE;
	if(isFromHwp()) return BrTRUE;
#ifdef SUPPORT_ODT_HEADER_FOOTER
	if(isFromOdt()) return BrFALSE;
#endif //SUPPORT_ODT_HEADER_FOOTER
	if(!pFrame)	return BrFALSE;
	if(!pFrame->isHeader() && !pFrame->isFooter()) return BrFALSE;
	if(pFrame->getHeaderFooterType() == HdrFtrType_None) return BrFALSE;

	BrHdrFtrType nType = pFrame->getHeaderFooterType();
	BrBOOL bHeader = pFrame->isHeader() ? BrTRUE : BrFALSE;
	BrBOOL bFooter = pFrame->isFooter() ? BrTRUE : BrFALSE;

	CHeaderFooter *pHeaderFooter = pFrame->getHeaderFooter();
	if(!pHeaderFooter)
	{
		BRTHREAD_ASSERT(0);
		return BrFALSE;
	}

	BrINT nSectionID = pHeaderFooter->parent_id();	//doc/docx
	if(nSectionID == -1)
		return BrFALSE;

	if( !(0 <= nSectionID && nSectionID < SectionLineVector.GetSize()) )
	{
		BRTHREAD_ASSERT(0);
		return BrFALSE;
	}

	if(pHeaderFooter->section_info() != getSectionInfo(nSectionID))
	{
		BRTHREAD_ASSERT(0);
		return BrFALSE;
	}

	// Cur/Next section Header/Footer linked check
	for(BrINT i = nSectionID; i <= nSectionID+1 && i < SectionLineVector.GetSize(); i++)
	{
		CLine *pSectionLine = SectionLineVector.GetAt(i);
		CSectionInfomation *pSectionInfo = pSectionLine ? pSectionLine->getSectionInformation() : BrNULL;
		if(!pSectionInfo) return BrFALSE;

		CHeaderFooter *pHeaderFooter = pSectionInfo->getHeaderFooter();

		if(nType == HdrFtrType_odd)					// Odd page header/footer
		{
			if(bHeader && pHeaderFooter->getOddHeaderLinked())
				return BrTRUE;
			else if(bFooter && pHeaderFooter->getOddFooterLinked())
				return BrTRUE;
		}
		else if(nType == HdrFtrType_even)			// Even page header/footer
		{
			if(bHeader && pHeaderFooter->getEvenHeaderLinked())
				return BrTRUE;
			else if(bFooter && pHeaderFooter->getEvenFooterLinked())
				return BrTRUE;
		}
		else if(nType == HdrFtrType_first)			// First page header/footer
		{
			if(bHeader && pHeaderFooter->getFirstHeaderLinked())
				return BrTRUE;
			else if(bFooter && pHeaderFooter->getFirstFooterLinked())
				return BrTRUE;
		}
		else
		{
			BRTHREAD_ASSERT(0);
		}
	}

	return BrFALSE;
}

// Get link head header/footer
CFrame*	BoraDoc::getLinkHeadHeaderFooter(CFrame *pFrame)
{
	if(getBWPEngineMode() != EDITOR_WORD) return BrNULL;
	if(!pFrame)	return BrNULL;
	if(!pFrame->isHeader() && !pFrame->isFooter()) return BrNULL;
	if(pFrame->getHeaderFooterType() == HdrFtrType_None) return BrNULL;

	CFrame *pLinkHead = BrNULL;

	if(isFromHwp())
	{
		CFrameList *pFrameList = pFrame->getFrameList();
		if(!pFrameList)
			pLinkHead = pFrame;
		else
		{
			CFrame *pParent = pFrameList->getParentFrame();
			if(!pParent)
				pLinkHead = pFrame;
			else if(pParent->isHeader() || pParent->isFooter())
				pLinkHead = pParent;
		}
	}
#ifdef SUPPORT_ODT_HEADER_FOOTER
	else if(isFromOdt())
	{
		return pFrame;
	}
#endif //SUPPORT_ODT_HEADER_FOOTER
	else
	{
		BrHdrFtrType nType = pFrame->getHeaderFooterType();
		CHeaderFooter *pHeaderFooter = pFrame->getHeaderFooter();
		if(!pHeaderFooter)
		{
			BRTHREAD_ASSERT(0);
			return BrNULL;
		}

		BrINT nSectionID = pHeaderFooter->parent_id();	//doc/docx
		if( !(0 <= nSectionID && nSectionID < SectionLineVector.GetSize()) )
		{
			BRTHREAD_ASSERT(0);
			return BrNULL;
		}

		CLine *pSectionLine =  SectionLineVector.GetAt(nSectionID);
		CSectionInfomation *pSectionInfo = pSectionLine ? pSectionLine->getSectionInformation() : BrNULL;

		if(pHeaderFooter->section_info() != pSectionInfo)
		{
			BRTHREAD_ASSERT(0);
			return BrNULL;
		}

		if(!pSectionInfo)
			return BrNULL;

		BrBOOL bHeader = pFrame->isHeader();

		// Reverse traverse for finding LinkHead header/footer Section Index
		pLinkHead = pFrame;

		for (BrINT nSectionIndex = nSectionID ; nSectionIndex >= 0; nSectionIndex--) {
			pSectionLine = (CLine*)SectionLineVector.GetAt(nSectionIndex);
			pSectionInfo = pSectionLine ? pSectionLine->getSectionInformation() : BrNULL;
			if(!pSectionInfo)
				break;

			CHeaderFooter* header_footer = pSectionInfo->getHeaderFooter();
			ChoiceHeaderFooter choice = bHeader? CHOICE_HEADER: CHOICE_FOOTER;
			pLinkHead = header_footer->GetFrame(choice, nType);
			if (BrFALSE == header_footer->IsLinked(choice, nType))
				break;
		}
	}

	return pLinkHead;
}


// Link�� header/footer frame ���
BrBOOL BoraDoc::getLinkedHeaderFooterFrames(CFrame *pFrame, BArray<CFrame*> &pFrameArr)
{
	if(getBWPEngineMode() != EDITOR_WORD) return BrFALSE;
	if(!pFrame)	return BrFALSE;
	if(!pFrame->isHeader() && !pFrame->isFooter()) return BrFALSE;
	if(pFrame->getHeaderFooterType() == HdrFtrType_None) return BrFALSE;

	if(isFromHwp())
	{
		// Find LinkHead header/footer
		CFrame *pLinkHead = BrNULL;

		CFrameList *pFrameList = pFrame->getFrameList();
		if(!pFrameList)
			pLinkHead = pFrame;
		else
			pLinkHead = pFrameList->getParentFrame();

		pFrameArr.Add(pLinkHead);

		// Add linked header/footer frame
		CFrame *pLinkedFrame = pFrameList ? pFrameList->getFirst() : BrNULL;
		while(pLinkedFrame)
		{
			pFrameArr.Add(pLinkedFrame);
			pLinkedFrame = pFrameList->getNext(pLinkedFrame);
		}
		return BrTRUE;
	}
#ifdef SUPPORT_ODT_HEADER_FOOTER
	else if(isFromOdt())
	{
		pFrameArr.Add(pFrame);
		return BrTRUE;
	}
#endif //SUPPORT_ODT_HEADER_FOOTER

	// For ms-word
	// 1) Find header/footer type & Find SectionLine
	BrHdrFtrType nType = pFrame->getHeaderFooterType();
	CHeaderFooter *pHeaderFooter = pFrame->getHeaderFooter();
	if(!pHeaderFooter)
	{
		BRTHREAD_ASSERT(0);
		return BrFALSE;
	}

	BrINT nSectionID = pHeaderFooter->parent_id();	//doc/docx
	if( !(0 <= nSectionID && nSectionID < SectionLineVector.GetSize()) )
	{
		BRTHREAD_ASSERT(0);
		return BrFALSE;
	}

	CLine *pSectionLine = SectionLineVector.GetAt(nSectionID);
	CSectionInfomation *pSectionInfo = pSectionLine ? pSectionLine->getSectionInformation() : BrNULL;

	if(pHeaderFooter->section_info() != pSectionInfo)
	{
		BRTHREAD_ASSERT(0);
		return BrFALSE;
	}

	if(!pSectionInfo)
		return BrFALSE;

	// 2) Reverse traverse for finding LinkHead header/footer Section Index
	BrINT nSectionIndex = nSectionID;
	BrINT nLinkHeadSectionIndex = nSectionIndex;

	CFrame *pLinkHead = pFrame;
	for(nLinkHeadSectionIndex = nSectionIndex; nLinkHeadSectionIndex >= 0; nLinkHeadSectionIndex--)
	{
		pSectionLine = (CLine*)SectionLineVector.GetAt(nLinkHeadSectionIndex);
		pSectionInfo = pSectionLine ? pSectionLine->getSectionInformation() : BrNULL;
		if(!pSectionInfo)
			return BrFALSE;

		CHeaderFooter* pHeaderFooter = pSectionInfo->getHeaderFooter();
		ChoiceHeaderFooter choice = pFrame->isHeader()? CHOICE_HEADER: CHOICE_FOOTER;
		pLinkHead = pHeaderFooter->GetFrame(choice, nType);
		if (BrFALSE == pHeaderFooter->IsLinked(choice, nType))
			break;
	}

	pFrameArr.Add(pLinkHead);

	// 3) Traverse & Add linked header/footer frame
	for(BrINT i = nLinkHeadSectionIndex+1; i < SectionLineVector.GetSize(); i++)
	{
		pSectionLine = (CLine*)SectionLineVector.GetAt(i);
		pSectionInfo = pSectionLine ? pSectionLine->getSectionInformation() : BrNULL;
		if(!pSectionInfo)
			return BrFALSE;

		CHeaderFooter* header_footer = pSectionInfo->getHeaderFooter();
		ChoiceHeaderFooter choice = pFrame->isHeader()? CHOICE_HEADER: CHOICE_FOOTER;
		if (BrFALSE == header_footer->IsLinked(choice, nType))
			break;
		CFrame* frame = header_footer->GetFrame(choice, nType);
		if (frame)
			pFrameArr.Add(frame);
	}

	return BrTRUE;
}


//header/footer ���� ������ ����
CPage* BoraDoc::getHeaderFooterStartPage(CFrame *pFrame)
{
	if(getBWPEngineMode() != EDITOR_WORD)
		return BrNULL;
	if(!pFrame || (!pFrame->isHeader() && !pFrame->isFooter()))
		return BrNULL;

	BArray<BrINT> nPageNumArray;
	getHeaderFooterPage(pFrame, nPageNumArray, BrTRUE);

	if(nPageNumArray.GetSize() > 0)
		return getPageArray()->getPage(*nPageNumArray.GetAt(0));

	return BrNULL;
}

//header/footer�� ���� ������ ��� ������ ����
BrBOOL BoraDoc::getHeaderFooterPage(CFrame *pFrame, BArray<BrINT> &pPageNumArray, BrBOOL bGetOnePage)
{
	if(getBWPEngineMode() != EDITOR_WORD)
		return BrFALSE;
	if(!pFrame || (!pFrame->isHeader() && !pFrame->isFooter()))
		return BrFALSE;

	BrBOOL bRet = BrFALSE;

	//Typeset Header/Footer
	if(isFromHwp())
	{
		bRet = getHeaderFooterPageForHWP(pFrame, pPageNumArray, bGetOnePage);
	}
#ifdef SUPPORT_ODT_HEADER_FOOTER
	//PageStyle Header/Footer
	else if(isFromOdt())
	{
		bRet = getHeaderFooterPageInOnePageStyle(pFrame, pPageNumArray, bGetOnePage);
	}
#endif //SUPPORT_ODT_HEADER_FOOTER
	//Section Header/Footer
	else //if(isFromDoc())
	{
		BArray<CFrame*> arrLinkedHeaderFooter;
		if(!getLinkedHeaderFooterFrames(pFrame, arrLinkedHeaderFooter))
			return BrFALSE;

		for(BrINT i = 0; i < arrLinkedHeaderFooter.GetSize(); i++)
		{
			CFrame *pHeaderFooter = *arrLinkedHeaderFooter.GetAt(i);
			if(!pHeaderFooter)
				break;

			if(pFrame->width() != pHeaderFooter->width())
				continue;

			bRet = getHeaderFooterPageInOneSection(pHeaderFooter, pPageNumArray, bGetOnePage);
			if(bRet == BrFALSE)
				return BrFALSE;

			if(bGetOnePage && pPageNumArray.GetSize() > 0)
				break;
		}
	}

	return bRet;
}

//header/footer�� ���� ������ One Section �� ������ ����
BrBOOL BoraDoc::getHeaderFooterPageInOneSection(CFrame *pFrame, BArray<BrINT> &pPageNumArray, BrBOOL bGetOnePage)
{
	if(getBWPEngineMode() != EDITOR_WORD)
		return BrFALSE;
	if(!pFrame || (!pFrame->isHeader() && !pFrame->isFooter()))
		return BrFALSE;

	BrHdrFtrType eHdrFtrType = pFrame->getHeaderFooterType();
	if(eHdrFtrType == HdrFtrType_None)
		return BrFALSE;

	CHeaderFooter *pHeaderFooter = pFrame->getHeaderFooter();
	if(!pHeaderFooter)
	{
		BRTHREAD_ASSERT(0);
		return BrFALSE;
	}

	BrINT nSectionID = pHeaderFooter->parent_id();	//doc/docx
	if( !(0 <= nSectionID && nSectionID < SectionLineVector.GetSize()) )
	{
		BRTHREAD_ASSERT(0);
		return BrFALSE;
	}

	CLine *pSectionLine = SectionLineVector.GetAt(nSectionID);
	CSectionInfomation *pSectionInfo = pSectionLine ? pSectionLine->getSectionInformation() : BrNULL;

	if(pHeaderFooter->section_info() != pSectionInfo)
	{
		BRTHREAD_ASSERT(0);
		return BrFALSE;
	}

	if(!pSectionInfo)
		return BrFALSE;

	CPage *pSectionStartPage = getSectionPageStarted(pSectionLine);
	CPage *pSectionEndPage = getSectionPageEnded(pSectionLine);
	if(!pSectionStartPage || !pSectionEndPage)
		return BrFALSE;

	BrINT nStartPageNum = pSectionStartPage->getPageNum();
	BrINT nEndPageNum = pSectionEndPage->getPageNum();

	if( nStartPageNum == nEndPageNum &&
		pSectionStartPage->getFirstLine() != pSectionLine)
	{
		//pFrame Header/Footer�� � ���������� ��ġ/����/Show �� �� ����.
		return BrTRUE;
	}

	//m_bDiffFirstPage�� ���, section start page ���� �Ұ���
	if( eHdrFtrType != HdrFtrType_first && pHeaderFooter->getDiffFirstPage())
		nStartPageNum++;

	//First Header/Footer �� ���, Section start page���� ���� ����
	if(eHdrFtrType == HdrFtrType_first && pHeaderFooter->getDiffFirstPage())
	{
		pPageNumArray.Add(nStartPageNum);
	}
	//Even Header/Footer �� ���, ¦�� ���������� ���� ����
	else if(eHdrFtrType == HdrFtrType_even && pHeaderFooter->getDiffOddEvenPage())
	{
		if(nStartPageNum % 2 == 1)
			nStartPageNum++;

		if(nEndPageNum % 2 == 1)
			nEndPageNum--;

		while(nStartPageNum <= nEndPageNum)
		{
			pPageNumArray.Add(nStartPageNum);
			nStartPageNum += 2;

			if(bGetOnePage && pPageNumArray.GetSize() > 0)
				break;
		}
	}
	//Odd Header/Footer �� ���,
	else if(eHdrFtrType == HdrFtrType_odd)
	{
		//Ȧ�� ���������� ���� ����
		if(pHeaderFooter->getDiffOddEvenPage())
		{
			if(nStartPageNum % 2 == 0)
				nStartPageNum++;

			if(nEndPageNum % 2 == 0)
				nEndPageNum--;

			while(nStartPageNum <= nEndPageNum)
			{
				pPageNumArray.Add(nStartPageNum);
				nStartPageNum += 2;

				if(bGetOnePage && pPageNumArray.GetSize() > 0)
					break;
			}
		}
		//��� �������� ���� ����
		else
		{
			while(nStartPageNum <= nEndPageNum)
			{
				pPageNumArray.Add(nStartPageNum);
				nStartPageNum++;

				if(bGetOnePage && pPageNumArray.GetSize() > 0)
					break;
			}
		}
	}

	return BrTRUE;
}

//header/footer�� ���� ������ One PageStyle �� ������ ����
BrBOOL BoraDoc::getHeaderFooterPageInOnePageStyle(CFrame *pFrame, BArray<BrINT> &pPageNumArray, BrBOOL bGetOnePage)
{
#ifndef SUPPORT_ODT_HEADER_FOOTER
	return BrFALSE;
#else
	if(getBWPEngineMode() != EDITOR_WORD)
		return BrFALSE;
	if(!pFrame || (!pFrame->isHeader() && !pFrame->isFooter()))
		return BrFALSE;

	BrHdrFtrType eHdrFtrType = pFrame->getHeaderFooterType();
	if(eHdrFtrType == HdrFtrType_None)
		return BrFALSE;

	CHeaderFooter *pHeaderFooter = pFrame->getHeaderFooter();
	BRTHREAD_ASSERT(pHeaderFooter);
	if(!pHeaderFooter)
		return BrFALSE;

	CPageStyle *pPageStyle = pHeaderFooter->page_style();
	BRTHREAD_ASSERT(pPageStyle);
	if(!pPageStyle)
		return BrFALSE;

	BRTHREAD_ASSERT(pPageStyle->getPageStyleID() == pHeaderFooter->parent_id());
	if(pPageStyle->getPageStyleID() != pHeaderFooter->parent_id())
		return BrFALSE;

// Test Code Start (CPageStyle�� reference �ϴ� ��� Page Num ���)
	BArray<BrINT> nPageStylePageNumArray;
	for(BrINT i = 0; i < m_PageArray->size(); i++)
	{
		CPage *pPage = m_PageArray->at(i);
		if(!pPage) continue;

		CPageStyle *pIterator = pPage->getPageStyle();
		if(!pIterator) continue;

		if(pIterator == pPageStyle)
			nPageStylePageNumArray.Add(pPage->getPageNum());
	}
// Test Code End

	BrBOOL bDiffFirstPage = BrFALSE;
	if(pFrame->isHeader())
		bDiffFirstPage = pHeaderFooter->getHeaderDiffFirstPage();
	else if(pFrame->isFooter())
		bDiffFirstPage = pHeaderFooter->getFooterDiffFirstPage();

	BrBOOL bDiffOddEvenPage = BrFALSE;
	if(pFrame->isHeader())
		bDiffOddEvenPage = pHeaderFooter->getHeaderDiffOddEvenPage();
	else if(pFrame->isFooter())
		bDiffOddEvenPage = pHeaderFooter->getFooterDiffOddEvenPage();

	//m_bDiffFirstPage�� ���, PageStyle start page ���� �Ұ���
	if( eHdrFtrType != HdrFtrType_first && bDiffFirstPage)
	{
		if(nPageStylePageNumArray.size() > 0)
			nPageStylePageNumArray.RemoveAt(0);
	}

	//First Header/Footer �� ���, PageStyle start page���� ���� ����
	if(eHdrFtrType == HdrFtrType_first && bDiffFirstPage)
	{
		if(nPageStylePageNumArray.size() > 0)
			pPageNumArray.Add(nPageStylePageNumArray.at(0));
	}
	//Even Header/Footer �� ���, ¦�� ���������� ���� ����
	else if(eHdrFtrType == HdrFtrType_even && bDiffOddEvenPage)
	{
		for(BrINT i = 0; i < nPageStylePageNumArray.size(); i++)
		{
			BrINT nPageNum = nPageStylePageNumArray.at(i);
			if(nPageNum % 2 == 0)
			{
				pPageNumArray.Add(nPageNum);

				if(bGetOnePage && pPageNumArray.size() > 0)
					break;
			}
		}
	}
	//Odd Header/Footer �� ���,
	else if(eHdrFtrType == HdrFtrType_odd)
	{
		//Ȧ�� ���������� ���� ����
		if(bDiffOddEvenPage)
		{
			for(BrINT i = 0; i < nPageStylePageNumArray.size(); i++)
			{
				BrINT nPageNum = nPageStylePageNumArray.at(i);
				if(nPageNum % 2 == 1)
				{
					pPageNumArray.Add(nPageNum);

					if(bGetOnePage && pPageNumArray.size() > 0)
						break;
				}
			}
		}
		//��� �������� ���� ����
		else
		{
			for(BrINT i = 0; i < nPageStylePageNumArray.size(); i++)
			{
				pPageNumArray.Add(nPageStylePageNumArray.at(i));

				if(bGetOnePage && pPageNumArray.size() > 0)
					break;
			}
		}
	}

	return BrTRUE;
#endif
}

//Ticket 32274, hwp typeset header/footer�� ���� ������ ������ ����
BrBOOL BoraDoc::getHeaderFooterPageForHWP(CFrame *pFrame, BArray<BrINT> &pPageNumArray, BrBOOL bGetOnePage)
{
#ifdef IMPORT_HWP
	if(!pFrame) return BrFALSE;
	if(!(pFrame->isHeader() || pFrame->isFooter())) return BrFALSE;

	BArray<CFrame*> *pHeaderFooterArray = BrNULL;
	if(pFrame->isHeader()) pHeaderFooterArray = m_pHeaderArray;
	else				   pHeaderFooterArray = m_pFooterArray;

	BrHdrFtrType eHdrFtrType = pFrame->getHeaderFooterType();
	if(eHdrFtrType == HdrFtrType_None)
		return BrFALSE;

	BrINT nIndex = 0;
	for(nIndex = 0; nIndex < pHeaderFooterArray->size(); nIndex++)
	{
		if(pFrame == pHeaderFooterArray->at(nIndex))
			break;
	}

	CFrame *pNextFrame = ((nIndex + 1) < pHeaderFooterArray->size()) ? pHeaderFooterArray->at(nIndex+1) : BrNULL;

	CPage *pStartPage = IsValidObject(pFrame->getAnchorLine()) ? pFrame->getAnchorLine()->getPage() : BrNULL;
	CPage *pEndPage = (IsValidObject(pNextFrame) && IsValidObject(pNextFrame->getAnchorLine())) ? pNextFrame->getAnchorLine()->getPage() : BrNULL;
	if(!pEndPage)	pEndPage = m_PageArray->GetLast();

	if(!pStartPage || !pEndPage) return BrFALSE;

	BrINT nStartPageNum = pStartPage->getPageNum();
	BrINT nEndPageNum = pEndPage->getPageNum();

	for(BrINT nPageNum = nStartPageNum; nPageNum <= nEndPageNum; nPageNum++)
	{
		CPage *pPage = m_PageArray->getPage(nPageNum);
		if(!pPage) continue;

		BrBOOL bOddPage = (nPageNum % 2 == 1);
		BrBOOL bHide = BrFALSE;

		if(getPageCtrlArray()->size() > 1)
		{
			//[2014-07-22][XRF-2954][�弮��]�ٴڱ� Ȧ��, ¦���� �ʹ�ȣ ����
			Hwp50PageNum drawingPageCtrl;
			pPage->getPageCtrlData(&drawingPageCtrl);
			bOddPage = drawingPageCtrl.getPageNum() % 2 == 1;

			//Ticket 29374, ���� �ʸ� ������ ���߱�
			Hwp50PageHiding pageHiding;
			pPage->getPageCtrlData(&pageHiding);
			bHide = pageHiding.HideFooter();
		}

		if(bHide) continue;

		if(eHdrFtrType == HdrFtrType_odd && bOddPage)
		{
			pPageNumArray.Add(nPageNum);
		}
		else if(eHdrFtrType == HdrFtrType_even && !bOddPage)
		{
			pPageNumArray.Add(nPageNum);
		}
		else if(eHdrFtrType == HdrFtrType_both)
		{
			pPageNumArray.Add(nPageNum);
		}
	}

	return BrTRUE;
#endif
	return BrFALSE;
}

CFrame* BoraDoc::createFrame(byte bClass, BrBOOL bNoteGenID)
{
	CFrame *pFrame = BrNULL;
	if(m_CmdEngine->getSubMode() == DRAWOBJECT_INCHART)
		pFrame = BrNEW CBWPChartShape(); //[�̻�ȣ] ��Ʈ �������� ����
	else if(bClass == CELLFRAME)
		pFrame = BrNEW CellFrame();
	else
		pFrame = BrNEW CFrame();

	// pFrame->updatePage(m_CmdEngine->getCurrentPage(BrTRUE));
	pFrame->setPage(m_CmdEngine->getCurrentPage(BrTRUE)); // XPD-23263

	pFrame->setClass(bClass);

	if(bNoteGenID == BrFALSE)
		pFrame->UpdateID();
#ifdef FOR_PPTX_EXPORT
	//[2013.01.23][inkkim][TID#12806] text object spid ó��
	//pFrame->m_lspid = pFrame->getID();
#endif

	if (TABLEFRAME == bClass)
	{
		pFrame->setHorizontalLocationType(LT_ALIGNMENT);
		pFrame->setHorizontalAlignment(ALG_LEFT);
		pFrame->setHorizontalRelative(RT_COLUMN);

		pFrame->setVerticalLocationType(LT_ABSOLUTE);
		pFrame->setVerticalAlignment(ALG_TOP);
		pFrame->setVerticalRelative(RT_PARAGRAPH);

		CTableInitSet *pTableInit = g_pAppConfig->getTableInitValue();
		if (isFromHwp())
			pFrame->setBorderMargin(pTableInit->m_CellTextMarginForHWP.nLeft, pTableInit->m_CellTextMarginForHWP.nTop,
									pTableInit->m_CellTextMarginForHWP.nRight, pTableInit->m_CellTextMarginForHWP.nBottom);
		else
			pFrame->setBorderMargin(pTableInit->m_CellTextMargin.nLeft, pTableInit->m_CellTextMargin.nTop,
									pTableInit->m_CellTextMargin.nRight, pTableInit->m_CellTextMargin.nBottom);
	}

	return pFrame;
}

CFrame* BoraDoc::createImgObject(BrBOOL bIMGViewer)
{
	CFrame *pImageFrame = BrNEW CFrame();

	if(pImageFrame == BrNULL)
		return BrNULL;

	pImageFrame->setClass(PICTUREFRAME);
	pImageFrame->UpdateID();
	pImageFrame->setNoChangeAspect(BrTRUE);

	//[TID:300][��ȸ��]RECTFRAME �׸��� ����
	//[TID:300][��ȸ��]RECTFRAME�� SubFrame�� �޾��ش�.

	// Image Frame �� subframe�� ������ �ʴ´�.
	// pImageFrame->setSubFrame( pImageFrame->newElementByType(RECTFRAME) );

	// ���� �θ� Ŭ������ ������ �θ��� ����� ����Ѵ�.
	// ���� BrShape���� �����ϴ� ������ ����. [#4792]����.
	// BrDrawObj* pDrawObj = pImageFrame->getDrawObj();
	BrShape* pShape = BrShape::createShape(SHAPE_Rectangle, pImageFrame->getFrameRect());

	if(pShape == BrNULL)
	{
		BR_SAFE_DELETE(pImageFrame);
		return BrNULL;
	}

	// Frame�� shape ���.
	pImageFrame->setBorder(pShape);
	if( pShape && getDocType() == BORA_DOCTYPE_PPTX || getDocType() == BORA_DOCTYPE_DOCX )
	{
		pShape->setOffice2007Shape(BrTRUE);
	}


	//Pen
	BrPenObj* pPenObj = pShape->getPen();
	pPenObj->setLineStyle(BMV_LINESTYLE_NONE);
	pPenObj->setDashStyle(BMV_DASHSTYLE_NONE);

	//Brush
	BrBrushObj* pBrushObj = pShape->getBrush();
	pBrushObj->setStyle(BMV_FILLTYPE_NONE);

	if(pImageFrame)
		pImageFrame->genSpid();

	// Object Default Name �߰� (Picture)
	if(!bIMGViewer)
	{
		BString strName;
		pImageFrame->setNameForSelectionPane(strName);
	}

	if(isFromOdt())
		pShape->setOfficeOdf(BrTRUE);

    pImageFrame->setCreated(BrTRUE);

	return pImageFrame;
}

CFrame* BoraDoc::createOLEFrame(BrBOOL bFillImage)
{
	CFrame *pOLEFrame = BrNEW CFrame();

	pOLEFrame->setClass(OLEFRAME);
	pOLEFrame->UpdateID();

	// ���� �θ� Ŭ������ ������ �θ��� ����� ����Ѵ�.
	// ���� BrShape���� �����ϴ� ������ ����. [#4792]����.
	// BrDrawObj* pDrawObj = pImageFrame->getDrawObj();
	BrShape* pShape = BrShape::createShape(SHAPE_Rectangle, pOLEFrame->getFrameRect());

	// Frame�� shape ���.
	pOLEFrame->setBorder(pShape);

	//Pen
	BrPenObj* pPenObj = pShape->getPen();
	pPenObj->setLineStyle(BMV_LINESTYLE_NONE);
	pPenObj->setDashStyle(BMV_DASHSTYLE_NONE);

	//Brush
	if( bFillImage ) {
		BrBrushObj* pBrushObj = pShape->getBrush();
		pBrushObj->setStyle(BMV_FILLTYPE_IMAGE);
	}

	// Object Default Name �߰� (OLE)
	BString strName;
	pOLEFrame->setNameForSelectionPane(strName);

	return pOLEFrame;
}

//[2013.07.11][TID-15989] �ؽ�Ʈ ���͸�ũ ����
CFrame* BoraDoc::createWordArt()
{
	CFrame *pWordArtFrame = BrNEW CFrame();

	pWordArtFrame->setClass(FLOATFRAME);
	pWordArtFrame->UpdateID();

	// ���� �θ� Ŭ������ ������ �θ��� ����� ����Ѵ�.
	// ���� BrShape���� �����ϴ� ������ ����. [#4792]����.
	BrShape* pShape = BrShape::createShape(SHAPE_TextPlainText, pWordArtFrame->getFrameRect());

	// Frame�� shape ���.
	pWordArtFrame->setBorder(pShape);

	//Pen
	BrPenObj* pPenObj = pShape->getPen();
	pPenObj->setLineStyle(BMV_LINESTYLE_NOLINE);
	pPenObj->setDashStyle(BMV_DASHSTYLE_NOLINE);

	//Brush
	BrBrushObj* pBrushObj = pShape->getBrush();
	pBrushObj->setStyle(BMV_FILLTYPE_SOLID);

	//WordArt
	CShapeWordartInfo *pShapeWordartInfo = BrNEW CShapeWordartInfo();
	pShapeWordartInfo->m_strText = "Word Art";
	pShape->setWordartInfo(pShapeWordartInfo);

	return pWordArtFrame;
}


#ifdef FOR_HTML_EXPORT
BrBOOL	BoraDoc::doExportMht( char *FileName )
{
	BrBOOL bWeb = isViewWebMode();
	if ( !bWeb )
	{
		changeAnchorPageToPara();
		getCmdEngine()->changeEditPageMode(VIEWMODE_WEB);
	}
	else
		getCmdEngine()->wrapToWindow(BrTRUE);

	g_pHtml->m_bSaveToMime = BrTRUE;

	CWString widePath;
	widePath.SetMultiByte( FileName, CP_ACP );
	CHtmlWriter html;
	BrBOOL final = html.save(widePath, this, true);

	g_pHtml->m_bSaveToMime = BrFALSE;

	if( !bWeb )
	{
		getCmdEngine()->changeEditPageMode( BrFALSE );
		restoreAnchorPage();
	}

	return final;
}

BrBOOL BoraDoc::doExportHtml(char* szFilePath)
{
  /* [Azur] - Web Mode Disable
	BrBOOL bWeb = isViewWebMode();
	if ( !bWeb )
	{
		changeAnchorPageToPara();
		getCmdEngine()->changeEditPageMode(VIEWMODE_WEB);
	}
	else
		getCmdEngine()->wrapToWindow(BrTRUE);
  */
    g_pHtml->set_web_editor(true);

	CWString strPath;
	strPath.SetMultiByte( szFilePath , CP_UTF8 );

	if( strPath.IsEmpty() )
		return BrFALSE;

	CWString imgPath = strPath;
	int won = imgPath.ReverseFind('\\');
	int slush = imgPath.ReverseFind('/');

	if( won<slush )
		won = slush;

	int last_dot = imgPath.ReverseFind('.');
	if( last_dot > won )
		g_pHtml->m_strSaveImageDir = imgPath.Left( last_dot ) + ".files";//�̹��� ����ÿ� �����.
	else
		g_pHtml->m_strSaveImageDir = imgPath + ".files";


	CHtmlWriter html;

	BrBOOL final = html.save( strPath, this, false);

	g_pHtml->m_strSaveImageDir.Empty();

  /* [Azur] - Web Mode Disable
	if( !bWeb )
	{
		getCmdEngine()->changeEditPageMode( BrFALSE );
		restoreAnchorPage();
	}
  */
	return final;
}

BrBOOL BoraDoc::doExportHtmlForHwpControl( BrHWPControlFieldType a_nFieldType, BString& strFieldName,BrBYTE* strHeadChar, BrBYTE* strTailChar, const BrCHAR* a_pSaveFilePath , BrUINT32 a_nCodePage)
{
	CCaret* pCaret = getCaret();

	//>>>>>>>>>>>>>>���� ���ϴ� ��ƾ.
	CLine *pSLine=BrNULL,*pELine=BrNULL;
	int nSCol, nECol;

	switch( a_nFieldType )
	{
	case BR_HWPCONTROL_FIELDTYPE_CLICKHERE:
		//���� ��ü ������
		{
			CRange range;
			int nID = GetFieldRange( strFieldName , 0 , BrTRUE , range );
			if( nID!=-1 )
			{
				pSLine = range.getBeginLoc().getLine();
				nSCol = range.getBeginLoc().getColumn();
				pELine = range.getEndLoc().getLine();
				nECol = range.getEndLoc().getColumn();
			}
		}
		break;

	case BR_HWPCONTROL_FIELDTYPE_CELL:
		//cell frame ������
		{
			CFrame* pFrame = GetFieldCellFrame(  strFieldName , 0 );
			if( pFrame )
			{
				pSLine = pFrame->getFirstLine();
				nSCol = 0;
				pELine = pFrame->getLastLine();
				nECol = pFrame->getLastLine()->getCharNum();
			}
		}
		break;
	case BR_HWPCONTROL_FIELDTYPE_NONE:
		{
			pSLine = getFirstLine();
			nSCol = 0;
			pELine = getLastLine();
			nECol = pELine->getCharNum();
		}
		break;

	case BR_HWPCONTROL_FIELDTYPE_SECTION: //3
		{
			if( !isFromOdt() )
				break;

			CLine* pLine = getFirstLine();
			CSectionInfomation* pCurSection = BrNULL;

			while( pLine )
			{
				CSectionInfomation* pSI2 = pLine->getSectionInformation();
				if( pSI2 )
				{
					if( pCurSection )
					{
						//��ŸƮ�� ���� ���Ŀ� ������ ���� ����.
						pELine = pLine->getPrev();
						nECol = pELine->getCharNum();
						pCurSection = BrNULL;
						break;
					}
				}

				if( pSI2 && pSI2->getSectionStyle() )
				{
					BString bstrName = pSI2->getSectionStyle()->getSectionName();
					if( !bstrName.isEmpty() )
					{
						if( bstrName.compare( strFieldName ) == 0 )
						{
							pCurSection = pSI2;
							pSLine = pLine ;//���� ��ŸƮ ����.
							nSCol = 0;
						}
					}
				}

				pLine  = pLine->getNext();

			}

			if( pCurSection && pLine == BrNULL  )
			{
				//������ ���������� �������� ���� ����
				pELine = getLastLine();
				nECol = pELine->getCharNum();
			}
		}
		break;
	}

	if( !pSLine || !pELine )
		return BrFALSE;

	//<<<<<<<<<<<<���� ���ϴ� ��ƾ ����


	//BrBOOL bWeb = isViewWebMode();
	//if ( !bWeb )
	//{
	//	changeAnchorPageToPara();
	//	getCmdEngine()->changeEditPageMode(VIEWMODE_WEB);
	//}
	//else
	//	getCmdEngine()->wrapToWindow(BrTRUE);

	CWString strPath;

	if( CHtmlCharset::IsUTF8fromData( (BrLPBYTE)a_pSaveFilePath, BrStrLen( a_pSaveFilePath ) ) )
		strPath.SetMultiByte( a_pSaveFilePath , CP_UTF8  );//utf8�� �ִ� ��찡 �ֱ� ������
	else
		strPath.SetMultiByte( a_pSaveFilePath );

	if( strPath.IsEmpty() )
		return BrFALSE;

	CWString imgPath = strPath;

	int won = imgPath.ReverseFind(_T('\\'));
	int slush = imgPath.ReverseFind(_T('/'));

	if( won<slush )
		won = slush;

	//�ѱ� ���빮���� ���� ���丮�� �������� �ʰ� , ������ ���丮�� �����մϴ�.

	g_pHtml->m_strSaveImageDir = imgPath.Left( won );

	//int last_dot = imgPath.ReverseFind(_T('.'));
	//if( last_dot > won )
	//	g_pHtml->m_strSaveImageDir = imgPath.Left( last_dot ) + ".files";//�̹��� ����ÿ� �����.
	//else
	//	g_pHtml->m_strSaveImageDir = imgPath + ".files";

	g_pHtml->m_bHwpControl = true;

	// set_web_editor(true)
	struct ScopeGuard final {
	public:
		explicit ScopeGuard(std::function<void(void)> cb) :
			cb{ cb }
		{
		}

		~ScopeGuard()
		{
			cb();
		}

	private:
		std::function<void(void)> const cb;
	};

	bool prev_web_editor = g_pHtml->is_web_editor();
	g_pHtml->set_web_editor(true);
	ScopeGuard guard([prev_web_editor]() {
		g_pHtml->set_web_editor(prev_web_editor);
	});

	CHtmlWriter html;
	BrBOOL final = html.saveForHwpControl(this, pSLine, nSCol , pELine, nECol ,  strHeadChar, strTailChar, strPath ,a_nCodePage);

	g_pHtml->m_strSaveImageDir.Empty();
	g_pHtml->m_bHwpControl = false;

	//if( !bWeb )
	//{
	//	getCmdEngine()->changeEditPageMode( BrFALSE );
	//	restoreAnchorPage();
	//}

	return final;
}
#endif


#ifdef FOR_WORD_EXPORT
BrBOOL BoraDoc::DoSaveDoc(const BString& filename, LPBrSaveEventType event)
{
# ifdef FOR_DOCX_EXPORT
	if (BORA_DOCTYPE_DOCX == m_nDocType)  //[M-24558] hnsong:2013-02-27 Ȯ���ڰ� doc������ ���������� docx�� ���
		return doSaveDocX(filename, event);
# endif  // FOR_DOCX_EXPORT

# ifdef IMPORT_DOC
	PO_THREAD_TRY_BLOCK {
		if (BrNULL == m_pFilterDoc) {
			m_pFilterDoc = BrNEW BWordToBora();
			if (m_pFilterDoc == BrNULL)
				return BrFALSE;
		}
		if (BrFALSE == m_pFilterDoc->DoExport(filename, m_iMemRef, event))
			return BrFALSE;
	} PO_THREAD_CATCH_BLOCK {
		if (m_pFilterDoc->getWordDoc()) {
			BrDELETE m_pFilterDoc->getWordDoc();
			m_pFilterDoc->setWordDoc(BrNULL);
		}

		g_BoraThreadAtom.m_nSaveStatus = SAVE_STATUS_END;
		m_pFilterDoc->SaveFileClose();

		BString backup = CUtil::getBackupFilePathInTempPath(filename);
		BFile::Remove(backup);

	} PO_THREAD_END
# endif  // IMPORT_DOC

# ifdef DOC_BINARY_ENCRYPTOR
    /*  Azur: .doc �б��ȣ ����. �� �Ŀ� doc ��ȣ ���� ������ �̿��غ��ÿ� */
    OfficeBinaryWordEncryptor enc;
    enc.openDocument(filename);
	BString strEnc;
	strEnc += filename;
	strEnc += "pw-1234.doc";
    enc.saveDocument(strEnc, "1234");
# endif  // DOC_BINARY_ENCRYPTOR

	return BrTRUE;
}
#endif  // FOR_WORD_EXPORT


#ifdef FOR_DOCX_EXPORT
BrBOOL BoraDoc::doSaveDocX(BString pathName, LPBrSaveEventType pEvent)
{
#ifdef FOR_WORD_EXPORT
	if (BORA_DOCTYPE_DOC == m_nDocType)  //[M-24558] hnsong:2013-02-27 Ȯ���ڰ� docx������ ���������� doc�� ���
		return DoSaveDoc(pathName, pEvent);
#endif

#ifdef	IMPORT_DOC
	PO_THREAD_TRY_BLOCK {
		if( !m_pImportForDocx )
			m_pImportForDocx = BrNEW CDocXMain(m_pDocumentPackage);

		if(isFromHwp())
		{	// HWP typeset header/footer -> Section header/footer
			CHeaderFooterConverter headerFooterConverter;
			headerFooterConverter.convertHeaderFooterFromTypesetToSection(this);
		}

		if( !m_pImportForDocx->convertBwptoDocx(pathName, pEvent) )
			return BrFALSE;

	} PO_THREAD_CATCH_BLOCK {

		g_BoraThreadAtom.m_nSaveStatus = SAVE_STATUS_END;

		//BString strBackFileName(pathName);
		//strBackFileName.append(".qbk");
		BString strBackFileName = CUtil::getBackupFilePathInTempPath(pathName);
		BFile::Remove(strBackFileName);
	} PO_THREAD_END

#endif	//IMPORT_DOC
	return BrTRUE;
}
#endif

#ifdef FOR_HWP30_EXPORT
BrBOOL BoraDoc::doSaveHwp(BString pathName, LPBrSaveEventType pEvent)
{
	if( !(m_nDocType == BORA_DOCTYPE_HWP))
		return BrFALSE;

	BString tmpStr = _T("tmp");

	CHwpExport *pExportForHWP = BrNULL;
#ifdef CONV_LIB_HWP
	PO_THREAD_TRY_BLOCK {
		pExportForHWP = BrNEW CHwpExport();

		BrBOOL bRet = pExportForHWP->doExport(tmpStr, pathName, this);

		BrDELETE pExportForHWP;
		return bRet;

	} PO_THREAD_CATCH_BLOCK {

		g_BoraThreadAtom.m_nSaveStatus = SAVE_STATUS_END;

		//BString strBackFileName(pathName);
		//strBackFileName.append(".qbk");
		BString strBackFileName = CUtil::getBackupFilePathInTempPath(pathName);
		BFile::Remove(strBackFileName);

	} PO_THREAD_END

	return BrTRUE;
#endif //CONV_LIB_HWP
}
#endif //FOR_HWP30_EXPORT

#ifdef FOR_HWP50_EXPORT
BrBOOL BoraDoc::doSaveHwp50(BString pathName, LPBrSaveEventType pEvent)
{
	setArrangeDuringExport(true); // NOTE! WPD-4522
	BrBOOL bRet = BrFALSE;

	PO_THREAD_TRY_BLOCK {
		shorten_text_frame_post_processor::scoped_callstack_atomic_t scoped_callstack_lock;

		// ������ �� ���α��� ������ �� ���¿��� �����Ѵ�.
		CLine* pLine = getFirstLine();
		if(!pLine)
		{
			SetErrorCode(kPoErrGetFirstLineIsNullInBoradoc);
			return BrFALSE;
		}

		if(pLine->getSectionInformation() == BrNULL)
		{
			//���� �� ù ���ο� ���� ������ ���� ��� �������� �ʰ� ���� ó��
			SetErrorCode(kPoErrNoSectionInformationInFirstLine);
			return BrFALSE;
		}

		// arrange special frame, header/footer frame and typeset frame OFF-17354
		ArrangeAllPage();

		while ( pLine )
		{
			pLine = pLine->getFirstNextDirtyLine();
			if ( pLine )
			{
				pLine = CTextProc::arrangeMarkingLines(this, pLine, BrNULL);
			}
		}

		//CPage *pPage = (CPage *)m_PageArray->at(m_PageArray->size() - 1);
		//CLine *pLine = pPage->getFirstLine();

		//pLine = pLine->getFirstNextDirtyLine();
		//while (pLine && pLine->isDirty())
		//{
		//	CTextProc::arrangeMarkingLines(this, pLine, BrNULL);
		//	pPage = (CPage *)m_PageArray->at(m_PageArray->size() - 1);
		//	pLine = pPage->getFirstLine();

		//	if (pLine)
		//		pLine = pLine->getFirstNextDirtyLine();
		//}

		//[2014.12.17][OFF-190][���ؼ�] �������� ������ ���� HwpCoMgr�� ����
		if(!m_pHwpCoMgr)
		{
			m_pHwpCoMgr = BrNEW HwpCoMgr();
			if(!m_pHwpCoMgr)
				return BrFALSE;
		}

		bRet = m_pHwpCoMgr->IDoExportHwp(pathName, pEvent);
		m_pHwpCoMgr->FreeInstance();

	} PO_THREAD_CATCH_BLOCK {

		setArrangeDuringExport(false); // NOTE! WPD-4522
		if(shorten_text_frame_post_processor::callstack_locked > 0)
			std::atomic_fetch_sub(&shorten_text_frame_post_processor::callstack_locked, 1); // IMPORTANT!

		g_BoraThreadAtom.m_nSaveStatus = SAVE_STATUS_END;

		//BString strBackFileName(pathName);
		//strBackFileName.append(".qbk");
		BString strBackFileName = CUtil::getBackupFilePathInTempPath(pathName);
		BFile::Remove(strBackFileName);

	} PO_THREAD_END

	setArrangeDuringExport(false); // NOTE! WPD-4522
	return bRet;
}
#endif //FOR_HWP50_EXPORT

//#define AUTOSAVE_TEST_SLIDE		// �ڵ� ���� �׽�Ʈ

#define AUTOSAVE_TEST_SLIDEPAGE
//#define AUTOSAVE_TEST_NOTEPAGE
//#define AUTOSAVE_TEST_SLIDEMASTERLAYOUT
//#define AUTOSAVE_TEST_HANDOUTMASTER
//#define AUTOSAVE_TEST_NOTEMASTER

// ���� �������� ���� ����
//#define AUTOSAVE_TEST_EACH_SLIDEPAGE

// ������ ������ ����
//#define AUTOSAVE_TEST_RANDOM
#ifdef AUTOSAVE_TEST_RANDOM
	#define AUTOSAVE_TEST_RANDOM_PAGEMOVE
	#define AUTOSAVE_TEST_RANDOM_PAGEINSERT
	#define AUTOSAVE_TEST_RANDOM_PAGEDELETE
	#define AUTOSAVE_TEST_RANDOM_PAGEMODIFY
#endif


#ifdef	FOR_PPT_EXPORT
BrBOOL BoraDoc::doSavePpt(BString pathName, LPBrSaveEventType pEvent)
{
	if( !(m_nDocType == BORA_DOCTYPE_PPT || m_nDocType == BORA_DOCTYPE_PPTX))
		return FALSE;

	CPPTExport cPPTExport;
	PO_THREAD_TRY_BLOCK {

#ifdef AUTOSAVE_TEST_SLIDE
#ifdef AUTOSAVE_TEST_RANDOM
		autoSaveTest_random();
#endif
		autoSaveTest_ppt(pathName, pEvent);
#endif

		BrCHAR* strMemMsg = "PPT Save Start";
		SET_INFO_LOG(strMemMsg);

		if( !cPPTExport.convertBwptoPpt(pathName, pEvent) )
			return BrFALSE;

	} PO_THREAD_CATCH_BLOCK {

		g_BoraThreadAtom.m_nSaveStatus = SAVE_STATUS_END;

		if (cPPTExport.m_pSaveFile)
			cPPTExport.m_pSaveFile->Close();

		//BString strBackFileName(pathName);
		//strBackFileName.append(".qbk");
		BString strBackFileName = CUtil::getBackupFilePathInTempPath(pathName);
		BFile::Remove(strBackFileName);

	} PO_THREAD_END

	return BrTRUE;
}
#endif	//PPT_EXPORT

#ifdef FOR_PPTX_EXPORT
BrBOOL BoraDoc::doSavePptX(BString pathName, LPBrSaveEventType pEvent)
{
	if( !(m_nDocType == BORA_DOCTYPE_PPT || m_nDocType == BORA_DOCTYPE_PPTX))
		return FALSE;

	ptxExpMgr *pPptxMain = BrNULL;
	PO_THREAD_TRY_BLOCK {

#ifdef AUTOSAVE_TEST_SLIDE	// �ڵ� ���� �׽�Ʈ
#ifdef AUTOSAVE_TEST_RANDOM
		autoSaveTest_random();
#endif
		autoSaveTest_pptx(pathName, pEvent);
#endif

 		BrCHAR* strMemMsg = "PPTX Save Start";
 		SET_INFO_LOG(strMemMsg);

		pPptxMain = BrNEW ptxExpMgr();
		if(!pPptxMain->convertBwptoPptx(pathName, pEvent))
		{
			BrDELETE pPptxMain;
			return BrFALSE;
		}
		BrDELETE pPptxMain;

	} PO_THREAD_CATCH_BLOCK {

		g_BoraThreadAtom.m_nSaveStatus = SAVE_STATUS_END;

		//BString strBackFileName(pathName);
		//strBackFileName.append(".qbk");
		BString strBackFileName = CUtil::getBackupFilePathInTempPath(pathName);
		BFile::Remove(strBackFileName);

	} PO_THREAD_END

	return BrTRUE;
}


#ifdef IMPORT_ODT
BrBOOL BoraDoc::ExtractOdtBookmark(BVector<BrCHAR> &names, const BrCHAR *path)
{
	if (path == BrNULL)
		return BrFALSE;

  	BoraPackageOdf package;
	if (package.InitPackage(const_cast<BrCHAR *>(path)) == BrFALSE)
		return BrFALSE;

	opendocument::OdtMain odt_main(&package);
	return odt_main.ExtractBookmark(names);
}
#endif  // IMPORT_ODT


BrBOOL BoraDoc::autoSaveTest_random()
{
	if( !(m_nDocType == BORA_DOCTYPE_PPT || m_nDocType == BORA_DOCTYPE_PPTX))
		return BrFALSE;

	srand(BrGetTickCount());

#ifdef AUTOSAVE_TEST_RANDOM_PAGEDELETE
	autoSaveTest_randomPageDelete();
#endif

#ifdef AUTOSAVE_TEST_RANDOM_PAGEINSERT
	autoSaveTest_randomPageInsert();
#endif

#ifdef AUTOSAVE_TEST_RANDOM_PAGEMOVE
	autoSaveTest_randomPageMove();
#endif
	return BrTRUE;
}

BrBOOL BoraDoc::autoSaveTest_randomPageMove()
{
	CPageArray *pPageArray = getPageArray();
	BrINT32 nPageSize = pPageArray->size();

	if(nPageSize < 3)
		return BrFALSE;

	BrINT32 nMovePageCount = (rand()%(nPageSize-2))+1;	//�ִ� �� ��������-2 ��ŭ �̵�

	for (int i = 0; i < nMovePageCount; i++)
	{
		BrINT32 nSrcPageNum = (rand()%nPageSize)+1;
		BrINT32 nDstPageNum = nSrcPageNum;

		while (nSrcPageNum == nDstPageNum)
		{
			nDstPageNum = (rand()%nPageSize)+1;
		}

		if(!(pPageArray->getPage(nSrcPageNum)) || !(pPageArray->getPage(nDstPageNum)))
			continue;

		CTextProc::movePage(this, nSrcPageNum, nDstPageNum);
	}

	return BrTRUE;
}

BrBOOL BoraDoc::autoSaveTest_randomPageInsert()
{
	CPageArray *pPageArray = getPageArray();
	BrINT32 nPageSize = pPageArray->size();
	BrINT32 nInserPageCount = (rand()%nPageSize)+1;		//�ִ� �� ����������ŭ �߰�

	for (int i = 0; i < nInserPageCount; i++)
	{
		BrINT32 nInsertPageNum = (rand()%(nPageSize+1))+1;

		if(nInsertPageNum > nPageSize)
			CTextProc::insertPage(this, nPageSize, BrFALSE);
		else
			CTextProc::insertPage(this, nInsertPageNum, BrTRUE);

		CPage* pPage = (CPage*)pPageArray->getPage(nInsertPageNum);

		if(pPage)
		{
			pPage->setCreated(BrTRUE);
#ifdef SEPERATE_MASTERID
			pPage->setMasterID(1);
			pPage->setLayoutID(1);
#else //SEPERATE_MASTERID
			pPage->setMasterID(0x00010001);
#endif //SEPERATE_MASTERID
			pPage->setLayout(LAYOUT_TYPE_BLANK);
		}

		nPageSize = pPageArray->size();
	}

	return BrTRUE;
}

BrBOOL BoraDoc::autoSaveTest_randomPageDelete()
{
	CPageArray *pPageArray = getPageArray();
	BrINT32 nPageSize = pPageArray->size();

	if(nPageSize < 3)
		return BrFALSE;

	BrINT32 nDeletePageCount = ((rand()%nPageSize)+1)/3;	//�ִ� �� ���������� 1/3�� ����

	for (int i = 0; i < nDeletePageCount; i++)
	{
		BrINT32 nDeletePageNum = (rand()%nPageSize)+1;

		CTextProc::deletePages(this, nDeletePageNum, BrTRUE);

		nPageSize = pPageArray->size();
	}

	return BrTRUE;
}

BrBOOL BoraDoc::autoSaveTest_ppt(BString pathName, LPBrSaveEventType pEvent)
{
	if( !(m_nDocType == BORA_DOCTYPE_PPT || m_nDocType == BORA_DOCTYPE_PPTX))
		return BrFALSE;

#ifndef AUTOSAVE_TEST_EACH_SLIDEPAGE
	setSlidePageModified_Autotest();
#else
	CPageArray *pPageArray = getPageArray();

	for(BrINT nSize = 0; nSize < pPageArray->size(); nSize++)
	{
		setSlidePageModified_Autotest(BrTRUE, nSize+1);

		CPPTExport cPPTExportTest;

		BString autoSaveName = pathName;
		BrCHAR pageNum[10] = {0, };
		BString strPageNum((BrCHAR*)BrItoa(nSize+1, pageNum, 10));

		autoSaveName.append((BrCHAR*)"_");
		autoSaveName.append(strPageNum);
		autoSaveName.append(".ppt");

		if( !cPPTExportTest.convertBwptoPpt(autoSaveName, pEvent) )
			BRTHREAD_ASSERT(0);
	}
	setSlidePageModified_Autotest();
#endif

#ifdef AUTOSAVE_TEST_SLIDEMASTERLAYOUT
	setMasterLayoutPageModified_Autotest();
#endif	//AUTOSAVE_TEST_SLIDEMASTERLAYOUT

	return BrTRUE;
}

BrBOOL BoraDoc::autoSaveTest_pptx(BString pathName, LPBrSaveEventType pEvent)
{
	if( !(m_nDocType == BORA_DOCTYPE_PPT || m_nDocType == BORA_DOCTYPE_PPTX))
		return BrFALSE;

#ifndef AUTOSAVE_TEST_EACH_SLIDEPAGE
	setSlidePageModified_Autotest();
#else
	CPageArray *pPageArray = getPageArray();

	for(BrINT nSize = 0; nSize < pPageArray->size(); nSize++)
	{
		setSlidePageModified_Autotest(BrTRUE, nSize+1);

		ptxExpMgr* pPptxMain = BrNEW ptxExpMgr();

		BString autoSaveName = pathName;
		BrCHAR pageNum[10] = {0, };
		BString strPageNum((BrCHAR*)BrItoa(nSize+1, pageNum, 10));

		autoSaveName.append((BrCHAR*)"_");
		autoSaveName.append(strPageNum);
		autoSaveName.append(".pptx");

		if(!pPptxMain->convertBwptoPptx(autoSaveName, pEvent))
			BRTHREAD_ASSERT(0);

		BrDELETE pPptxMain;
	}
	setSlidePageModified_Autotest();
#endif

#ifdef AUTOSAVE_TEST_SLIDEMASTERLAYOUT
	setMasterLayoutPageModified_Autotest();
#endif	//AUTOSAVE_TEST_SLIDEMASTERLAYOUT

#ifdef AUTOSAVE_TEST_HANDOUTMASTER
	setHandoutMasterPageModified_Autotest();
#endif	//AUTOSAVE_TEST_HANDOUTMASTER

#ifdef AUTOSAVE_TEST_NOTEMASTER
	setNoteMasterPageModified_Autotest();
#endif	//AUTOSAVE_TEST_NOTEMASTER

	return BrTRUE;
}

BrBOOL BoraDoc::setSlidePageModified_Autotest(BrBOOL a_bImportAllPage, BrINT32 a_nModifiedPageNum)
{
	CPageArray *pPageArray = getPageArray();
	BrINT32 nPageSize = pPageArray->size();

	for(BrINT nSize = 0; nSize < nPageSize; nSize++)
	{
		CPage* pPage = (CPage*)pPageArray->getPage(nSize+1);

		if(!(a_nModifiedPageNum == 0 || a_nModifiedPageNum == nSize+1))
		{
#ifdef AUTOSAVE_TEST_SLIDEPAGE
			setPageModifiedOff_Autotest(pPage);
#endif

#ifdef AUTOSAVE_TEST_NOTEPAGE
			if(pPage)
				setPageModifiedOff_Autotest(pPage->getNoteSlidePage());
#endif
			continue;
		}

#ifdef AUTOSAVE_TEST_RANDOM_PAGEMODIFY
		if(nPageSize > 1 && a_nModifiedPageNum == 0)
		{
			BrINT32 bPass = rand()%2;
			if((BrBOOL)bPass == BrTRUE)
				continue;
		}
#endif

		if(!pPage)
		{
			if(!a_bImportAllPage)
				continue;

			BMVFilterInterfaceType FilterInterface;
			memset(&FilterInterface, 0, sizeof(BMVFilterInterfaceType));

			BrBOOL bRet = BrFALSE;

#ifdef IMPORT_PPTX
			if(m_nDocType == BORA_DOCTYPE_PPTX)
				bRet = HandsPointer_GetPagePtr_PptX(gpPaint, getDocFileName(), nSize+1, nSize+1, &FilterInterface);
			else
#endif //IMPORT_PPTX
				bRet = HandsPointer_GetPagePtr_Ppt(gpPaint, getDocFileName(), nSize+1, nSize+1, &FilterInterface);

			if( bRet )
				gpPaint->doc.m_pDoc->m_DocProperty.m_nPageCount = nSize+1;

			pPage = (CPage*)pPageArray->getPage(nSize+1);
			if(!pPage)
				continue;
		}
#ifdef AUTOSAVE_TEST_SLIDEPAGE
		setAllFrameModified_Autotest(pPage);
#endif

#ifdef AUTOSAVE_TEST_NOTEPAGE
		setAllFrameModified_Autotest(pPage->getNoteSlidePage());
#endif
	}

	return BrTRUE;
}

BrBOOL BoraDoc::setMasterLayoutPageModified_Autotest()
{
	for(BrINT nIdx = 0 ; nIdx < m_MasterLayoutArray.size(); nIdx++)
	{
		CPageArray *pMasterPageArray = m_MasterLayoutArray.at(nIdx);
		if (pMasterPageArray && pMasterPageArray->size() > 0)
		{
			CPage* pMasterPage = pMasterPageArray->at(0);

			if(!pMasterPage)
			{
#ifdef IMPORT_PPTX
				if(m_nDocType == BORA_DOCTYPE_PPTX)
					((ptxDocument*)(mp_doc))->ReadPptxSlideLayouts(nIdx, 0);
				else
#endif //IMPORT_PPTX
					((ptDocument*)(mp_doc))->ReadMasterSlides();

				pMasterPage = pMasterPageArray->at(0);
				if(!pMasterPage)
					continue;
			}

#ifdef IMPORT_PPTX
			if(m_nDocType == BORA_DOCTYPE_PPTX)
			{
				for(BrINT32 nLayoutIdx = 1; nLayoutIdx < pMasterPageArray->size(); nLayoutIdx++)
				{
					CPage* pLayoutPage = pMasterPageArray->at(nLayoutIdx);
					if(!pLayoutPage)
					{
						((ptxDocument*)(mp_doc))->ReadPptxSlideLayouts(nIdx, nLayoutIdx+1);

						pLayoutPage = pMasterPageArray->at(nLayoutIdx);
						if(!pLayoutPage)
							continue;
					}

					setAllFrameModified_Autotest(pLayoutPage);
				}
			}
#endif //IMPORT_PPTX
		}
	}

	return BrTRUE;
}

BrBOOL BoraDoc::setHandoutMasterPageModified_Autotest()
{
	if(m_nDocType == BORA_DOCTYPE_PPT)
		return BrFALSE;

	CHandoutMaster* pHandoutMaster = getHandoutMaster();
	CPageArray* pHandoutMasterArray = pHandoutMaster->GetPageArray();

	if(pHandoutMasterArray->size() > 0)
	{
		CPage* pHandoutPage = pHandoutMasterArray->at(0);
		if(!pHandoutPage)
		{
			pHandoutPage = BrNEW CPage(pHandoutMasterArray);

			if(!pHandoutPage)
				return BrFALSE;

#ifdef IMPORT_PPTX
			if(((ptxDocument*)(mp_doc))->ReadPptxHandoutMaster(pHandoutPage) == BrFALSE)
			{
				BR_SAFE_DELETE(pHandoutPage);
				return BrFALSE;
			}
#endif //IMPORT_PPTX

			pHandoutMasterArray->SetAt(0, pHandoutPage);
		}

		setAllFrameModified_Autotest(pHandoutPage);
	}

	return BrTRUE;
}

BrBOOL BoraDoc::setNoteMasterPageModified_Autotest()
{
	if(m_nDocType == BORA_DOCTYPE_PPT)
		return BrFALSE;

#ifdef SUPPORT_PPTX_NOTEMASTER_IMPORT
	CPPTNoteMaster* pNotesMaster = getPPTNoteMaster();
	CPageArray* pNotesMasterArray = pNotesMaster->GetNoteMasterPageArray();

	if(pNotesMasterArray->size() > 0)
	{
		CPage* pNotesMasterPage = pNotesMasterArray->at(0);
		if(!pNotesMasterPage)
		{
			pNotesMasterPage = BrNEW CPage(pNotesMasterArray);

			if(!pNotesMasterPage)
				return BrFALSE;

#ifdef IMPORT_PPTX
			if(((ptxDocument*)(mp_doc))->ReadPptxNotesMaster(pNotesMasterPage) == BrFALSE)
			{
				BR_SAFE_DELETE(pNotesMasterPage);
				return BrFALSE;
			}
#endif //IMPORT_PPTX

			pNotesMasterArray->SetAt(0, pNotesMasterPage);
		}

		setAllFrameModified_Autotest(pNotesMasterPage);
	}
#endif

	return BrTRUE;
}

BrBOOL BoraDoc::setPageModifiedOff_Autotest(CPage* a_pPage)
{
	if(a_pPage)
	{
		a_pPage->setModifiedFrame(BrFALSE);
		a_pPage->setModifiedPaperLayout(BrFALSE);
		a_pPage->setModifiedSlideHide(BrFALSE);
		a_pPage->setModifiedSlideShowEffect(BrFALSE);
		a_pPage->setModifiedAnimation(BrFALSE);
		a_pPage->setModifiedMemo(BrFALSE);
		a_pPage->setModifiedMasterLayoutPage(BrFALSE);
		a_pPage->setModifiedSlideLayout(BrFALSE);

		return BrTRUE;
	}

	return BrFALSE;
}

BrBOOL BoraDoc::setAllFrameModified_Autotest(CPage* a_pPage)
{
	if(!a_pPage)
		return BrFALSE;

	CFrameList *pFrameList = a_pPage->getPageAFrameList();

	BrINT32 nFrameSize = pFrameList->getTotalFrame();
	CFrame *pFrame = pFrameList->getFirst();

	for(BrINT32 nIdx = 0; nIdx < nFrameSize; nIdx++)
	{
		if(!pFrame)
			break;

		checkFrameClass_Autotest(pFrame);

		pFrame = pFrame->getNext();
	}

	return BrTRUE;
}

BrBOOL BoraDoc::checkFrameClass_Autotest(CFrame* a_pFrame)
{
	if(m_nDocType == BORA_DOCTYPE_PPTX)
	{
		if(a_pFrame->isTable())
		{
			CBTable *pTable = (CBTable*)a_pFrame->getSubFrame();
			if(pTable)
			{
				CCellList* pCellList = pTable->getCellList();
				CBCell* pCell = BrNULL;

				while(pCellList)
				{
					pCell = pCellList->getFirstCell();
					while(pCell)
					{
						CFrame *pCellFrame = pCell->getFrame();
						if(pCellFrame)
							setFrameModified_Autotest(pCellFrame);

						pCell = pCell->getNext();
					}

					pCellList = pCellList->getNext();
				}
			}
		}
		else if(a_pFrame->isGroup())
		{
			CFrameList *pSubFrameList = (CFrameList*)a_pFrame->getSubFrame();

			BrINT32 nSubFrameSize = pSubFrameList->getTotalFrame();
			CFrame *pSubFrame = pSubFrameList->getFirst();

			for(BrINT32 nIdx = 0; nIdx < nSubFrameSize; nIdx++)
			{
				if(!pSubFrame)
					break;

				checkFrameClass_Autotest(pSubFrame);

				pSubFrame = pSubFrame->getNext();
			}
		}
		else if( a_pFrame->isChart())
		{
			CBWPChart* pChart = (CBWPChart*)a_pFrame;
			pChart->ReadEmbedChart();
		}
	}

	setFrameModified_Autotest(a_pFrame);

	return BrTRUE;
}

BrBOOL BoraDoc::setFrameModified_Autotest(CFrame* a_pFrame)
{
	if(frameModifyException_Autotest(a_pFrame) == BrFALSE)
	{
		a_pFrame->setModifiedSize(BrTRUE);
		a_pFrame->setModifiedAttribute(BrTRUE);
		a_pFrame->setModifiedText(BrTRUE);
		a_pFrame->setModifiedTextAttribute(BrTRUE);
		a_pFrame->setModifiedParaAttribute(BrTRUE);
	}

	return BrTRUE;
}

BrBOOL BoraDoc::frameModifyException_Autotest(CFrame* a_pFrame)
{
	BrBOOL bModifyException = BrFALSE;

	if(getDocType() == BORA_DOCTYPE_PPT)
	{
		CLineList *pLineList = (CLineList*)a_pFrame->getSubFrame();
		BrINT32 nType = -1;
		BrShape* pBorder = BrNULL;
		BrBrushObj* pBrush = BrNULL;
		BrBrushObj* pPenBrush = BrNULL;
		BrPenObj* pPen = BrNULL;

		pBorder = a_pFrame->getBorder();

		if(pBorder)
		{
			nType = pBorder->getBorderStyle();
			pBrush = pBorder->getBrush();
			pPen = pBorder->getPen();
			if(pPen)
				pPenBrush = pPen->getFillBrush();
		}

		if((pBrush && pBrush->getStyle() == BMV_FILLTYPE_IMAGE) || (pPenBrush && pPenBrush->getStyle() == BMV_FILLTYPE_IMAGE))
			bModifyException = BrTRUE; //.ppt ä��Ӽ� Image�� ��� ������ mofieid flag ���ָ� ��ȿ�������� default ������ ���⿡ ���Ͽ� �����˾� ���� ��

		if((pBrush && pBrush->getStyle() == BMV_FILLTYPE_TEXTURE) || (pPenBrush && pPenBrush->getStyle() == BMV_FILLTYPE_TEXTURE))
			bModifyException = BrTRUE; //.ppt ä��Ӽ� texture�� ��� ������ mofieid flag ���ָ� ��ȿ�������� default ������ ���⿡ ���Ͽ� �����˾� ���� ��

		if((pBrush && pBrush->getStyle() == BMV_FILLTYPE_GRADIENT) || (pPenBrush && pPenBrush->getStyle() == BMV_FILLTYPE_GRADIENT))
			bModifyException = BrTRUE; //.ppt ä��Ӽ� gradient�� ��� ������ mofieid flag ���ָ� ��ȿ�������� default ������ ���⿡ ���Ͽ� �����˾� ���� ��

		if(pLineList == BrNULL || a_pFrame->isOLE() || (nType >= SHAPE_StraightConnector1 && nType <= SHAPE_CurvedConnector5) || nType == SHAPE_Line || nType == SHAPE_NotchedCircularArrow)
			bModifyException = BrTRUE; //�ؽ�Ʈ������ �� �� ���� ������ ��� text modified flag�� ���ָ� default ������ ���⿡ ���Ͽ� �����˾� ���� ��
	}

	return bModifyException;
}
#endif //FOR_PPTX_EXPORT

#ifdef EXPORT_ODT
BrBOOL BoraDoc::doSaveOdt(const BString &filename, LPBrSaveEventType save_event)
{
	PO_THREAD_TRY_BLOCK {
		if (isFromHwp()) {
			//Ticket 32274, HWP typeset header/footer -> Section header/footer
			CHeaderFooterConverter hf_converter;
			hf_converter.convertHeaderFooterFromTypesetToSection(this);
		}

		if (BrNULL == m_pFilterOdt)
			m_pFilterOdt = BrNEW opendocument::OdtMain(m_pOdPackage);
		ResetErrorCode();
		BrBOOL result = m_pFilterOdt->DoExport(filename, save_event);
		m_pFilterOdt->DeleteStaticInstance();
		return result;
	}
	PO_THREAD_CATCH_BLOCK {
		g_BoraThreadAtom.m_nSaveStatus = SAVE_STATUS_END;
	}
	PO_THREAD_END

	return BrTRUE;
}
#endif  // EXPORT_ODT


#ifdef EXPORT_ODP
BrBOOL BoraDoc::doSaveOdp(const BString &filename, LPBrSaveEventType save_event)
{
	PO_THREAD_TRY_BLOCK {
		if (m_pImportForOdp == BrNULL)
			m_pImportForOdp = BrNEW opendocument::OdpMain();
		return m_pImportForOdp->doExportOdp(filename, save_event);
	} PO_THREAD_CATCH_BLOCK {

		g_BoraThreadAtom.m_nSaveStatus = SAVE_STATUS_END;
	} PO_THREAD_END

	return BrTRUE;
}
#endif // EXPORT_ODP



#ifdef	BWP_EDITOR	// For Editor

BrBOOL	BoraDoc::doNewDoc(Painter *pPainter, BrCHAR bDocType,  BRPPTPaperType ePPTPaperType,  BrSlideTemplateType eTemplatePPT)
{
	m_nDocType = bDocType;// Init �ȿ��� ��Ÿ�� �V���� ���� �ֱ� ������ ���⼭ �� ��� �մϴ�. - hunius 2011-04-08
	Init(bDocType);
	setSendTotalLoadComplete(BrTRUE);	// �� ���������� TotalLoadComplete�� TRUE�� ����� �Ѵ�.


	if( BrNULL == m_TableEngine->getStyleMgr())
		m_TableEngine->setStyleMgr(m_nDocType);

	if( (BORA_DOCTYPE_DOCX == m_nDocType ) || (BORA_DOCTYPE_PPTX == m_nDocType))
		setThemeUsingDoc(BrTRUE);
	else
		setThemeUsingDoc(BrFALSE);

	// m_pFilterDoc = BrNEW BWordToBora();
	// if ( m_pFilterDoc == BrNULL )
	//	return BrFALSE;
	g_pAppStatic->bProtectUndo = BrTRUE;
#ifdef PPT_EDITOR
	if ( bDocType==BORA_DOCTYPE_DOC || bDocType==BORA_DOCTYPE_DOCX )
		setFromDoc(BrTRUE);
	else if ( bDocType==BORA_DOCTYPE_PPT || bDocType==BORA_DOCTYPE_PPTX )
		setFromPpt(BrTRUE);
	else if ( bDocType==BORA_DOCTYPE_HWP )
		setFromHwp(BrTRUE);
	else if (bDocType == BORA_DOCTYPE_ODT)
		setFromOdt(BrTRUE);
	else if (bDocType == BORA_DOCTYPE_ODP)
		setFromOdp(BrTRUE);

	if(isFromDoc())
	{
		m_pSummaryData = BrNEW	CBrSummaryData();
		BString author = getAuthor();
		if(!author.isNull())
			m_pSummaryData->setAuthor(&author);
	}

    if (isFromSlideType())
	{
		g_pAppStatic->bProtectUndo = BrTRUE;
		CPage* pPage = getPageArray()->at(0);
		//getMstPageArray()->Delete(1, 1, BrTRUE);

		if (ePPTPaperType != BR_PPT_PAPER_TYPE_NONE)
		{
			//switch(ePPTPaperType)

			CPaperSize *pPaperSize = pPage->getPaperSize();
			BrINT nPaperID = 0;
			getCmdEngine()->getPPTPaperTypeSize(ePPTPaperType, &nPaperID, &pPaperSize->m_nWidth, &pPaperSize->m_nHeight );
			pPaperSize->setSizeID(nPaperID);
			// set ppt slide size
			if((ePPTPaperType == BR_PPT_PAPER_TYPE_USER) && (pPainter->m_SlideWidth > 0) && (pPainter->m_SlideHeight > 0))
			{
				pPaperSize->m_nWidth = MMtoTWIP(pPainter->m_SlideWidth);
				pPaperSize->m_nHeight = MMtoTWIP(pPainter->m_SlideHeight);
			}
			m_slideSize.cx = pPaperSize->m_nWidth;
			m_slideSize.cy = pPaperSize->m_nHeight;
			m_CmdEngine->setMaxEndCoord(m_slideSize.cx, m_slideSize.cy);

			m_slideNotePaperSize.cx = 10800;
			m_slideNotePaperSize.cy = 14400;

			m_PPTPaperID = nPaperID;
		}

		PoTextStyleCreatorDefault defaultTextStyleCreator;
		defaultTextStyleCreator.createTextStyle();

		createDefaultMasterLayout(BrFALSE);
#ifdef BWP_IMG_VIEWER_SLIDE
		if (getFilterMode() != FILTER_IMAGE)
		{
			createPPTTemplate(eTemplatePPT);
		}
		else
		{
			BrINT nIndex = m_MasterLayoutArray.size();
			CPage* pMasterPage = m_MasterLayoutArray.at(nIndex - 1)->at(0);
			pPage->setMasterID(pMasterPage->getMasterID() + (0x10000 * 1));
		}
#else //BWP_IMG_VIEWER_SLIDE
		createPPTTemplate(eTemplatePPT);
#endif //BWP_IMG_VIEWER_SLIDE

		setModifiedFlag(BrFALSE); //New ���� ���� �ÿ� ModifiedFlag OFF ó��
		g_pAppStatic->bProtectUndo = BrFALSE;
	}
#endif

#ifdef IMPORT_HWP
	if(isFromHwp())
	{
		m_pHwpCoMgr = BrNEW HwpCoMgr();
		if(!m_pHwpCoMgr)
			return BrFALSE;
	}
#endif //IMPORT_HWP

#ifdef BWP_EDITOR
	if ( bDocType==BORA_DOCTYPE_ASCI )
		getCmdEngine()->changeEditPageMode(VIEWMODE_WEB);
	if ( bDocType==BORA_DOCTYPE_DOC || bDocType==BORA_DOCTYPE_DOCX )
		setInheritLastRegion(BrTRUE);	// [2014.08.05][johnkim][ZPD-452]
#endif
#ifdef IMPORT_ODT
	if (BORA_DOCTYPE_ODT == bDocType) {
		//[2014.09.30][������] SingleByte->DoubleByte ODT �������� ����.
		setfDntBlnSbDbWid(BrFALSE);
		setIncPageNum(1);
#ifdef SUPPORT_PAGELAYOUT_FOR_ODT
		setInheritLastRegion(BrTRUE);	// ZPD-27761
		getPageArray()->GetFirst()->setPageStyle(this->getPageStyleArray()->GetFirst());		// �� ������ ������ ��Ÿ�� ����
#endif  // SUPPORT_PAGELAYOUT_FOR_ODT
	}
#endif  // IMPORT_ODT

	g_pAppStatic->bProtectUndo = BrFALSE;
	g_BoraThreadAtom.m_bSendTotalLoadComplete = BrTRUE;

	return BrTRUE;
}

#endif	// BWP_EDITOR

BrBOOL BoraDoc::doOpenDoc(Painter *pPainter, BString pathName, INT16 & iRefNum, int nPage)
{
	BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);

	BrBOOL rc, bResizeTable = BrFALSE;
	m_nDocType = getDocTypeFromName(pathName);

//#ifdef BWP_EDITOR
//	CTextProc::resetAnchorPositionCache();
//#endif

	ClearAll();
	Init(BORA_DOCTYPE_BORA,iRefNum, BrFALSE, 0);
	if ( BORA_DOCTYPE_DOCX!=m_nDocType && BORA_DOCTYPE_DOC!= m_nDocType && BORA_DOCTYPE_ASCI!=m_nDocType &&
		BORA_DOCTYPE_HWP!=m_nDocType && BORA_DOCTYPE_GUL!=m_nDocType && BORA_DOCTYPE_HTML!=m_nDocType &&
		BORA_DOCTYPE_MHT!=m_nDocType && BORA_DOCTYPE_RTF != m_nDocType &&
		BORA_DOCTYPE_ODT!=m_nDocType && BORA_DOCTYPE_PPT!=m_nDocType && BORA_DOCTYPE_ICML != m_nDocType &&
		BORA_DOCTYPE_ICMA != m_nDocType && BORA_DOCTYPE_ODP != m_nDocType && BORA_DOCTYPE_PPTX != m_nDocType &&
		BORA_DOCTYPE_BWP != m_nDocType)
	{
		m_nDocType = BORA_DOCTYPE_ASCI;
	}

	m_strPathName = pathName;

	m_TableEngine->setStyleMgr(m_nDocType);
BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);

	//Ticket 27818, TXT_EACH_PAGE_MODE feature ����(2014.07.28)
	//.txt ���� view web layout mode�� open�� total load complete�� �ȵǴ� ������ �ֽ��ϴ�.
	rc = doImport(pathName, m_nDocType, nPage);
BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);

	// TXT�� ������ HWP �б� ���� �߰� CSP-1704
	if(	!rc && m_nDocType == BORA_DOCTYPE_HWP &&	getErrorCode() == kPoErrFileContentsMismatched)
		rc = doImport(pathName, BORA_DOCTYPE_ASCI, nPage);		// HWP �б� ���н� ������ TXT�� �б� �õ�
BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);

	bResizeTable = BrTRUE;

#ifdef	BWP_EDITOR	// For Editor
	CLine * pFirstLine = getFirstLine();
	if ( pFirstLine != BrNULL && pFirstLine->isEmpty() == BrFALSE){
		BrINT nReadableCol = pFirstLine->getFirstReadableLinkCol();
		m_Caret->update(pFirstLine, nReadableCol, BR_CARET_NORMAL);
	}
#ifdef WINDOWS_8
	m_CmdEngine->setMode(TEXTEDIT);
#endif // WINDOWS_8
#endif	// BWP_EDITOR

	// brWordQM���� �ۼ��� ������ �ƴ� ��쿡 cell �� text�� ��Ÿ���� �ʴ�
	// ��츦 �ؼ��ϱ� ���ؼ� call ��
	// Error �־ �ӽ÷� ����.... 2006.3.13
	// gul �����϶��� resizeTables()�� ���� ����... 2006.6.23
	if ( rc && !g_pBInterfaceHandle->getDocumentValidattionMode() && bResizeTable && (m_nDocType==BORA_DOCTYPE_DOC || m_nDocType==BORA_DOCTYPE_HWP ||
		 m_nDocType==BORA_DOCTYPE_DOCX || m_nDocType==BORA_DOCTYPE_ODT || m_nDocType == BORA_DOCTYPE_RTF) ) //�ӵ������� ���� �ӽ÷� ����!! 2003-08-18
	{
		setArrangeDuringImport(BrTRUE);
		m_TableEngine->resizeTables();
		setArrangeDuringImport(BrFALSE);
	}

	// boraX���� �ۼ��� ������ ��� document end coordinate�� �ٲ�� ������
	// �� function�� call
	if( rc && !g_pBInterfaceHandle->getDocumentValidattionMode() )
		getCmdEngine()->setDocEndCoord();


	if (rc)  //�������� ȭ�Ͽ���
	{
	}
	else
	{
		m_iMemRef = -1;
		return BrFALSE;
	}


	return BrTRUE;
}

void BoraDoc::setWraptoWindow(BrBOOL b)
{
	DocFlag.flag.m_WraptoWindow = b;
}

//Ticket 30365, draw page edge/shadow
void BoraDoc::drawPageEdge(Painter *pPainter, BrDC *pDC, BRect rcPage, CPage *pPage, BrINT nCurPageNum)
{
	BRCONTEXT

	BrBOOL bSlideshow = m_CmdEngine->isSlideShow() && !m_CmdEngine->isSlideShowInteractiveMode();
	BrUCHAR nEdgeWidth = Brcontext.m_GeneralValue.byPageEdgeWidth;
	if( !pDC || nEdgeWidth <= 0 ||
		bSlideshow || m_CmdEngine->isCurOperation(ACTMAKETHUMBNAIL) ||
		(g_BoraThreadAtom.m_nPrintStatus==PRINT_STATUS_START||g_BoraThreadAtom.m_nPrintStatus==PRINT_STATUS_PROGRESS) )
	{
		return;
	}

	LINETYPE nLineType;
	nLineType.m_nLineType = 0;
	nLineType.flag.m_nDashStyle = BMV_DASHSTYLE_SOLID;
	nLineType.flag.m_nLineStyle = BMV_LINESTYLE_SIMPLE;

	BrCOLORREF edgeColor = Brcontext.m_GeneralValue.dwEdgeColor; //NORMAL_PAGE_EDGE_COLOR; // BrRGB(62, 80, 91);

#if !defined(USE_SPL_MANAGER) && defined(USE_CURRENT_PAGE_EDGE_COLOR)
	if (m_CmdEngine->isContinuePage() && !m_CmdEngine->isFlicking() && !m_CmdEngine->isCurOperation(ACTANIMATIONMOVEPAGE) && m_CmdEngine->getCurPageNum() == nCurPageNum && 1 < getTotalPage())
		edgeColor = CURRENT_PAGE_EDGE_COLOR;	// BrRGB(4,237,231)
	else if ((m_CmdEngine->getScreenPageMode() & SCREENPAGEMODE_DOUBLEPAGE) == SCREENPAGEMODE_DOUBLEPAGE && m_CmdEngine->getCurPageNum() == nCurPageNum)
		edgeColor = CURRENT_PAGE_EDGE_COLOR;	// BrRGB(4,237,231)
#endif //USE_CURRENT_PAGE_EDGE_COLOR

	//draw page edge

	if(isFromWordType() || isFromHwp())
	{
		if (canDrawMemoFrame() || canDrawRevisionFrame())
		{
			BRect rc(0, 0, pPage->width() + MEMO_PAGE_WIDTH, pPage->height());
			m_CmdEngine->page2Logical(pPage, rc);
			BrDrawObj::drawRect(pDC, rc.nLeft, rc.nTop, rc.nRight, rc.nBottom, nLineType.m_nLineType, nEdgeWidth, edgeColor);
		}
		else
			BrDrawObj::drawRect(pDC, rcPage.nLeft, rcPage.nTop, rcPage.nRight, rcPage.nBottom, nLineType.m_nLineType, nEdgeWidth, edgeColor);
	}
	else
		BrDrawObj::drawRect(pDC, rcPage.nLeft, rcPage.nTop, rcPage.nRight+1, rcPage.nBottom+1, nLineType.m_nLineType, nEdgeWidth, edgeColor);

	//draw page shadow
	if(Brcontext.m_GeneralValue.bPageOutline)
	{
		if( this->GetGrayMode()!=GRAY_MODE_COLOR && pPage )
			edgeColor = BrColor::getBwColor( GetGrayMode() ,  pPage->getBgColorMode() , edgeColor , GRAY_MODE_APPLY_BORDER );

		pDC->fillSolidRect(rcPage.nRight, rcPage.nTop + 3, rcPage.nRight + 3, rcPage.nBottom + 3, edgeColor);
		pDC->fillSolidRect(rcPage.nLeft + 3, rcPage.nBottom, rcPage.nRight, rcPage.nBottom + 3, edgeColor);
	}
}

#ifdef BWP_EDITOR
void BoraDoc::OnBackgroundDraw(Painter *pPainter, BrDC *pDC)
{
	BRCONTEXT;
	BRect   rcPage, tmpRect;
	CPage   *pPage;

	BrINT n;
	BrINT nStartPage = m_CmdEngine->getScrStartPage();
	BrINT nEndPage = m_CmdEngine->getScrEndPage();

	CPageArray *pPageArray = getEditingPageArray();

	if( nStartPage < 1 )
		nStartPage = 1;

	if( nEndPage > (int)pPageArray->GetSize() )
		nEndPage = pPageArray->GetSize();

	//--- set Coordinate Conversion Factors
	CDrawUnit dUnit;
	m_CmdEngine->setDrawUnit(dUnit);
	dUnit.setDrawOption(DRAW_ALL);
	CmdOperation nCurOperation = m_CmdEngine->getCurOperation();

	m_bOnDraw = BrTRUE;
	n = nStartPage;

	for( n = nStartPage; n <= nEndPage; n++)
	{
		pPage = pPageArray->getPage(n);

		if( pPage )
		{
			rcPage.setRect(0, 0, pPage->width(), pPage->height());
			m_CmdEngine->page2Logical(pPage, rcPage);

			dUnit.setPageStart(rcPage.nLeft, rcPage.nTop);

			// web mode �϶��� ��ü ȭ���� page�� ����
			if ( BrFALSE == theBWordDoc->isViewPrintMode() )
			{
				rcPage.setRect(0, 0, getLCDWidth(), getLCDHeight());
			}

			BRect rcEraseBkgnd;
			rcEraseBkgnd.SetEmpty();
			BrCOLORREF color;

			if (Brcontext.m_GeneralValue.dwBgColorForTXT != WHITE_COLOR )
			//if ( getDocType()==BORA_DOCTYPE_ASCI && isViewWebMode() )
				color = Brcontext.m_GeneralValue.dwBgColorForTXT;
			else
				color = getPaperColor();
#ifndef PPT_EDITOR_ERROR
			if( this->GetGrayMode() != GRAY_MODE_COLOR)
			{
				color = BrColor::getBwColor( GetGrayMode(), pPage->getBgColorMode() , color , GRAY_MODE_APPLY_FILL );
			}
#endif //PPT_EDITOR
			if(getInvalidateFlag())
			{
				if(tmpRect.IntersectRect(rcPage, m_rcInvaldateRect))
				{
					if (rcPage.nTop < m_rcInvaldateRect.nTop)
					{
						rcEraseBkgnd = m_rcInvaldateRect;
						if(rcPage.nRight < m_rcInvaldateRect.nRight)
							rcEraseBkgnd.nRight = rcPage.nRight;
						if(rcPage.nBottom < m_rcInvaldateRect.nBottom)
							rcEraseBkgnd.nBottom = rcPage.nBottom;
						if(rcPage.nLeft > m_rcInvaldateRect.nLeft)
							rcEraseBkgnd.nLeft = rcPage.nLeft;

						pDC->fillSolidRect(rcEraseBkgnd.nLeft, rcEraseBkgnd.nTop,
							rcEraseBkgnd.nRight, rcEraseBkgnd.nBottom, color);
					}
					else if ( rcPage.nTop < m_rcInvaldateRect.nBottom)
					{
						rcEraseBkgnd = m_rcInvaldateRect;

						rcEraseBkgnd.nTop = rcPage.nTop;
						if(rcPage.nRight < m_rcInvaldateRect.nRight)
							rcEraseBkgnd.nRight = rcPage.nRight;
						if(rcPage.nBottom < m_rcInvaldateRect.nBottom)
							rcEraseBkgnd.nBottom = rcPage.nBottom;
						if(rcPage.nLeft > m_rcInvaldateRect.nLeft)
							rcEraseBkgnd.nLeft = rcPage.nLeft;

						pDC->fillSolidRect(rcEraseBkgnd.nLeft, rcEraseBkgnd.nTop,
							rcEraseBkgnd.nRight, rcEraseBkgnd.nBottom, color);
					}
					else
					{
						pDC->fillSolidRect(rcPage.nLeft, rcPage.nTop, rcPage.nRight, rcPage.nBottom, color);
					}
				}
			}
			else
			{
				fillSolidRectWithClip(pPainter, rcPage.nLeft, rcPage.nTop, rcPage.nRight, rcPage.nBottom, color);
			}
		}
#ifdef PPT_EDITOR
		else if (EDITOR_PPT == getBWPEngineMode())
		{
			if ( !m_CmdEngine->isSlideShow() && ACTMAKETHUMBNAIL != nCurOperation)
			{
				BrSize *pSize;
				if( isEditMasterHandout() || isEditMasterNote() )
					pSize = getSlideNotePaperSize();
				else
					pSize = getSlideSize();

				rcPage.setRect(0, 0, pSize->cx, pSize->cy);
				m_CmdEngine->page2Logical(n, rcPage);
				pDC->fillSolidRect(rcPage.nLeft, rcPage.nTop, rcPage.nRight, rcPage.nBottom, RGB_WHITE);
			}
		}
#endif // PPT_EDITOR
	}

}

#ifndef USE_SPL_MANAGER
void BoraDoc::onDraw(Painter *pPainter, BrDC *pDC)
#else	// USE_SPL_MANAGER
void BoraDoc::onDraw(Painter *pPainter, BrDC *pDC, BArray<PrDirtyPosInfo>* arrDirtyPos)
#endif	// USE_SPL_MANAGER
{
//[2013.02.19][TID:#13197][�鿵��]PPT & PPTX �ܸ� �ӵ� ������ ���� ��� ������ ����
#ifdef SUPPORT_PPT_TIME_PROFILE
	PROFILE_BEGIN((BrINT32)this, 0);
#endif //SUPPORT_PPT_TIME_PROFILE

	BRect   rcPage, tmpRect, rcPageGap, rcTemp, rcInvalidForHeaderFooter; //ZPD-2889
	CPage   *pPage = BrNULL;

	int nStartPage = m_CmdEngine->getScrStartPage();
	int nEndPage = m_CmdEngine->getScrEndPage();
	BrINT nPgEditModeType = DocFlagEx2.flag.m_EditMasterType;
	CPageArray *pPageArray = getEditingPageArray();
	if (pPageArray == BrNULL)		return;

	BrBOOL bSPLPaintMode = (pPainter->getPaintMode() == eBrSPLPaintMode)? BrTRUE : BrFALSE;
	BrBOOL bOldNativeDraw = isSetGeneralStatus(eNativeDrawPageGValueStatus);

	setGeneralStatus(BrFALSE, eNativeDrawPageGValueStatus);
	setGeneralStatus(BrFALSE, eHasUnwindRendDataGValueStatus);

	if( nStartPage < 1 )
		nStartPage = 1;

	if( nEndPage > (int)pPageArray->GetSize() )
		nEndPage = pPageArray->GetSize();

	//--- set Coordinate Conversion Factors
	CDrawUnit dUnit;
	m_CmdEngine->setDrawUnit(dUnit);
	dUnit.setDrawOption(DRAW_ALL);

	int n = nStartPage;
	CmdOperation nCurOperation = m_CmdEngine->getCurOperation();

	BrBOOL bDrawPage = BrFALSE;
	m_bOnDraw = BrTRUE;
	m_MemoEventManager->setDrawingMemoReference(-1);
	setInCurrentMemo(BrFALSE); //���� Draw ���ۿ��� Memo Draw Link �� ���� �������� ������ �� �־� draw ���� �ʱ�ȭ ó��
#ifdef USE_SPL_MANAGER
	PrDirtyPosInfo sDirtyPos = {0};
#endif	// USE_SPL_MANAGER

	PO_THREAD_TRY_BLOCK {
		if( isEditMasterHandout() )
		{
			m_HandoutMaster->OnDraw( pPainter , pDC , dUnit );
			return;
		}

		for( n = nStartPage; n <= nEndPage; n++)
		{
			if (m_CmdEngine->isSlideShow())
			{
				if (!m_CmdEngine->isSlideShowEditorPageDraw())
					pPage = pPageArray->getPage(n, m_CmdEngine->isSlideShowInteractiveMode());

				if (pPage == BrNULL)
					pPage = pPageArray->getPage(n);
			}
			else
				pPage = pPageArray->getPage(n);

			if(pPage && ((nPgEditModeType ==  EDIT_SLIDE_NOTE && !m_bThumbnailDraw && !g_pAppStatic->isPrtPreview()/*nBwpEditMode == EDITOR_PPT*/) ||
				(g_pAppStatic->isPrtPreview() &&  g_BoraThreadAtom.m_nPPTHandoutType == 11)))
			{
				pPage = pPage->getNoteSlidePage();//m_PPTNoteMaster->GetNotePage(n);
				if(!pPage)
				{
					BRTHREAD_ASSERT(0);
					return;
				}
			}

			if( pPage )
			{
				rcPage.setRect(0, 0, pPage->width(), pPage->height());

				if (canDrawMemoFrame() || canDrawRevisionFrame())
					rcPage.nRight += (MEMO_PAGE_WIDTH); //������ boder �׸��� ������ ���� 20��ŭ ����

				m_CmdEngine->page2Logical(pPage, rcPage);

				dUnit.setPageStart(rcPage.nLeft, rcPage.nTop);

				// web mode �϶��� ��ü ȭ���� page�� ����
				if ( BrFALSE == isViewPrintMode() )
				{
					rcPage.setRect(0, 0, getLCDWidth(), getLCDHeight());
				}

				bDrawPage = BrTRUE;

				BRect rcEraseBkgnd;
				rcEraseBkgnd.SetEmpty();
				BrCOLORREF color;

#ifdef SUPPORT_NIGHT_VIEW_MODE
				if ( isNightViewMode() )
					color = RGB_BLACK;
				else if ( getDocType()==BORA_DOCTYPE_ASCI && isViewWebMode() )
#else
				if (Brcontext.m_GeneralValue.dwBgColorForTXT != WHITE_COLOR)
				//if ( getDocType()==BORA_DOCTYPE_ASCI && isViewWebMode() )
#endif // SUPPORT_NIGHT_VIEW_MODE
					color = Brcontext.m_GeneralValue.dwBgColorForTXT;
				else
					color = getPaperColor();
#ifndef PPT_EDITOR_ERROR
				if( this->GetGrayMode() != GRAY_MODE_COLOR)
				{
					color = BrColor::getBwColor( GetGrayMode(), pPage->getBgColorMode() , color , GRAY_MODE_APPLY_FILL );
				}
#endif //PPT_EDITOR_ERROR
				//���÷��ڿ� ���� ��� ����
				BrCOLORREF nLowVisionTextColor = NONE_COLOR_BITS;
				BrCOLORREF nLowVisionBackColor = NONE_COLOR_BITS;
				if(m_CmdEngine->GetLowVisionEngine() && m_CmdEngine->GetLowVisionEngine()->IsLowVisionColorMode(nLowVisionTextColor,nLowVisionBackColor))
					color = nLowVisionBackColor;

				//ZPD-2889, for word header/footer page invalid rect
				//ZPD-2889 ���̵� �̽��� XPD-4837 ������ �����ǰ�, ����� 2889 �̽��� �������� �����Ƿ� �ּ� ó��
				//XPD-9971 2������ �̻��� ��� ���/Ǫ�� ȭ�� ���� ���� ����
				CSetInvalidateRectForHeaderFooter SetInvalidateRectForHeaderFooter(this, pPage, m_rcInvaldateRect, rcInvalidForHeaderFooter);

				BrBOOL bDrawBackgroundMode = BrFALSE;
				if ( g_pBInterfaceHandle->IsUserConvenienceMode() )
				{
					if( g_pBInterfaceHandle->IsBackgroundPatternMode() && !g_pBInterfaceHandle->IsTextureFilterMode() )
					{
						BrRect pOldClipRect;
						pPainter->pDC->getClipRect(pOldClipRect);
						pPainter->pDC->setClipRect(BrNULL);

						pPainter->drawBackgroundPattern(0, 0, getLCDWidth(), getLCDHeight());

						pPainter->pDC->setClipRect(&pOldClipRect);
						bDrawBackgroundMode = BrTRUE;
					}
					else if ( !g_pBInterfaceHandle->IsBackgroundPatternMode() )
						color = Brcontext.m_GeneralValue.dwPageBgColor;
				}

				if(getInvalidateFlag())
				{
					if (tmpRect.IntersectRect(rcPage, m_rcInvaldateRect))
					{
						CFrame *pFrame = pPage->getFirstBasic();
						if(isFromWordType() && pFrame && pFrame->getDirection() == SERO)	 // XPD-3655 �ٹ�ȣ�� ���ŵ��� �ʴ� ����
						{
							int nTop = dUnit.doc2LogicalDY(pFrame->top());
							if(m_rcInvaldateRect.nBottom < nTop)
							{
								CLine *pLine = pPage->getFirstLine();
								CLine *pSecLine = BrNULL;

								while(pLine)
								{
									if(pLine->getPage() != pPage)
										break;

									pSecLine = pLine->getStartLineInSection();
									if(pSecLine && pSecLine->getSectionInformation())
									{
										if(pSecLine->getSectionInformation()->getLineCountBy() > 0)
										{
											m_rcInvaldateRect.nBottom = nTop;
											break;
										}
									}

									pLine = pLine->getLastLineInFrame();
									if(pLine)
										pLine = pLine->getNext();
								}
							}
						}

						BrBOOL bUpdateMemoRect = BrFALSE;
						BrINT nUpdateRight = 0;

						if (isMemoModeSimple())
						{
							BrRect cliprect;
							pDC->getClipRect(cliprect);

							if (pPage->getMemoFrameIDArray().size() > 0)
							{
								bUpdateMemoRect = BrTRUE;
								if (rcPage.nRight > getLCDWidth())
									nUpdateRight = getLCDWidth();
								else
									nUpdateRight = rcPage.nRight;

								cliprect.right = nUpdateRight;
							}

							pDC->setClipRect(&cliprect);
						}

						if (rcPage.nTop < m_rcInvaldateRect.nTop)
						{
							rcEraseBkgnd = m_rcInvaldateRect;
							if(rcPage.nRight < m_rcInvaldateRect.nRight)
								rcEraseBkgnd.nRight = rcPage.nRight;
							if(rcPage.nBottom < m_rcInvaldateRect.nBottom)
								rcEraseBkgnd.nBottom = rcPage.nBottom;
							if(rcPage.nLeft > m_rcInvaldateRect.nLeft)
								rcEraseBkgnd.nLeft = rcPage.nLeft;

							if(bUpdateMemoRect && nUpdateRight != 0)
								rcEraseBkgnd.nRight = nUpdateRight;

								if ( !bDrawBackgroundMode )
							pDC->fillSolidRect(rcEraseBkgnd.nLeft, rcEraseBkgnd.nTop,
								rcEraseBkgnd.nRight, rcEraseBkgnd.nBottom, color);
						}
						else if ( rcPage.nTop < m_rcInvaldateRect.nBottom)
						{
							rcEraseBkgnd = m_rcInvaldateRect;

							rcEraseBkgnd.nTop = rcPage.nTop;
							if(rcPage.nRight < m_rcInvaldateRect.nRight)
								rcEraseBkgnd.nRight = rcPage.nRight;
							if(rcPage.nBottom < m_rcInvaldateRect.nBottom)
								rcEraseBkgnd.nBottom = rcPage.nBottom;
							if(rcPage.nLeft > m_rcInvaldateRect.nLeft)
								rcEraseBkgnd.nLeft = rcPage.nLeft;

							if(bUpdateMemoRect && nUpdateRight != 0)
								rcEraseBkgnd.nRight = nUpdateRight;

							if ( !bDrawBackgroundMode && !m_CmdEngine->isSlideShowPresentationMode())
								pDC->fillSolidRect(rcEraseBkgnd.nLeft, rcEraseBkgnd.nTop, rcEraseBkgnd.nRight, rcEraseBkgnd.nBottom, color);
						}
						else
						{
							if ( !bDrawBackgroundMode && !m_CmdEngine->isSlideShowPresentationMode())
								pDC->fillSolidRect(rcPage.nLeft, rcPage.nTop, rcPage.nRight, rcPage.nBottom, color);
						}
					}
					else
					{
						if (!(EDITOR_PPT == m_nBWPEngineMode && !m_CmdEngine->isContinuePage()))
							bDrawPage = BrFALSE;
					}
				}
				else
				{
					if ( !bDrawBackgroundMode && !m_CmdEngine->isSlideShowPresentationMode())
						fillSolidRectWithClip(pPainter, rcPage.nLeft, rcPage.nTop, rcPage.nRight, rcPage.nBottom, color);
				}

#ifndef SUPPORT_SCROLL_ARRANGE
				if(bDrawPage)
				{
					int nArrangePage = 0;
					int nDirtyNum = getDirtyPage();
					int nPageNum = pPage->getPageNum();
					int nViewPageNum = nPageNum;
					CPage *pStartPage = pPage;
					CPage *pStopPage = pStartPage;
					CLine *pStartLine = pStartPage->getFirstLine();
					CLine *pStopLine = BrNULL;

					if(nDirtyNum != 0)
					{
						CCmdEngine *pCmdEngine = getCmdEngine();
						if(pCmdEngine->getScreenPageMode() & SCREENPAGEMODE_DOUBLEPAGE)
							nArrangePage = 6;
						else if(pCmdEngine->getScreenPageMode() & SCREENPAGEMODE_TRIPLEPAGE)
							nArrangePage = 9;
						else if(pCmdEngine->getScreenPageMode() & SCREENPAGEMODE_QUADRUPLEPAGE)
							nArrangePage = 12;
						else
							nArrangePage = 4;

						if(nDirtyNum < nPageNum)
							pStartPage = getPageArray()->getPage(nDirtyNum);

						if(!pStartPage)
							break;

						pStartLine = pStartPage->getFirstLine();

						for(int i=0; i<nArrangePage; i++)
						{
							if(pStopPage->getNext())
								pStopPage = pStopPage->getNext();
						}

						pStopLine = pStopPage->getLastLine();

						while(pStartLine)
						{
							if(pStartLine->isDirty())
							{
								bDrawPage = BrFALSE;
								break;
							}
							if(pStopLine == pStartLine)
								break;
							pStartLine = pStartLine->getNext();
						}

						if(!bDrawPage && pStartLine)
						{
							g_pAppStatic->bNoPauseArrange = BrTRUE;
							// ��ũ�� ���� Ư�� �������� �����ϴ� ���
							/*
							while(pStopLine)
							{
							*/
								CTextProc::arrangeMarkingLines(theBWordDoc, pStartLine, pStopLine);
							/*
								if(getDirtyPage() == 0 || pStopPage->getPageNum() < getDirtyPage())
									break;

								pStartPage = pPageArray->getPage(getDirtyPage());
								if(pStartPage)
									pStartLine = pStartPage->getFirstLine();
							}
							*/
							g_pAppStatic->bNoPauseArrange = BrFALSE;
							bDrawPage = BrTRUE;
							getCmdEngine()->updateScreenAndPage();
							InvalidateRect(BrNULL);
						}
					}
				}
#endif

				if (m_CmdEngine->isSlideShowPresentationMode()) {
					bDrawPage = BrFALSE;
				}

				//Draw page edge
				if ( bDrawPage && !(isFromWordType() || isFromHwp()) && !isViewWebMode() )
					drawPageEdge(pPainter, pDC, rcPage, pPage, n);

				//Draw page
				if (bDrawPage)
				{
					setPageDrawing(BrTRUE, pPage);
#ifdef USE_SPL_FLICK_NODRAW //shryu_test_spl
					if(BIHANDLE_BRCONTEXT.m_GeneralValue.m_bIsSPLFlicking != BrTRUE) // SPL ���� FLICK ���� ��ġ �Ǿ��� ���� ȭ���� �׸��� �ʰ� ��
#endif //USE_SPL_FLICK_NODRAW
						pPage->OnDraw(pPainter, pDC, dUnit, BrTRUE);
					setPageDrawing(BrFALSE);

					m_MemoEventManager->drawReviewFrames(pPainter, dUnit, pPage, pDC, color);

#ifdef USE_SPL_MANAGER
					if(bSPLPaintMode)
					{
						if(isSetGeneralStatus(eNativeDrawPageGValueStatus))
						{
							sDirtyPos.nFirstY = rcPage.nTop;
							sDirtyPos.nLastY = rcPage.nBottom;
							if (arrDirtyPos)
								arrDirtyPos->Add(sDirtyPos);
							setGeneralStatus(FALSE, eNativeDrawPageGValueStatus);
						}
					}
#endif	// USE_SPL_MANAGER
				}
				//Draw page edge // ZPD-25216 ����迭�� �������� ����� �׷����� �����Ƿ� �������� �׵θ��� �׷��ش�.
				if (bDrawPage && isFromWordType())
					drawPageEdge(pPainter, pDC, rcPage, pPage, n);

#ifdef UPDATE_RECT_DEBUG	// ȭ�� ���� ���� �ð��� ǥ��
				static unsigned int nCnt = 1;
				BrRect br;
				if(1)	// invalidRect or ClipRect
					br = m_rcInvaldateRect.getBrRect();
				else
					pDC->getClipRect(br);
				BrTrace("PageNum : %d | Top : %d | Bottom : %d | Left : %d | Right : %d", pPage->getPageNum(), m_rcInvaldateRect.nTop, m_rcInvaldateRect.nBottom, m_rcInvaldateRect.nLeft, m_rcInvaldateRect.nRight);
				BrBmvPen *backPen;
				BrBmvBrush *backBrush;
				BFont *backFont;
				BrBmvPen setPen;
				BrBmvBrush setBrush;
				BFont setFont;
				BrINT nFontSize = 15;
				setFont.setFontInfo(nFontSize,BrFALSE,BrFALSE,BrFALSE,BrFALSE);

				BrCOLORREF rgb;
				switch (nCnt % 3)
				{
				case 0:
					rgb = RGB_RED;
					break;
				case 1:
					rgb = RGB_GREEN;
					break;
				case 2:
					rgb = RGB_BLUE;
					break;
				}

				setPen.createPen(0, 2, rgb);
				setBrush.createNullBrush();
				setFont.setFontColor(rgb);
				backPen = pDC->setPen(&setPen);
				backBrush = pDC->setBrush(&setBrush);
				backFont = pDC->setFont(&setFont);

				if(br.right == 0 || br.bottom == 0 || br.right >= getLCDWidth() || br.bottom >= getLCDHeight())
				{
					br.bottom = getLCDHeight()-5;
					br.right = getLCDWidth()-5;
				}
				pDC->rectangle(br.left+1, br.top+1, br.right-1, br.bottom-1);
				char buf[128] ={0};
				wsprintf(buf, "%d", nCnt);
				BString str = buf;
				pDC->drawChars(&str, br.left+1, br.top+1);

				pDC->setPen(backPen);
				pDC->setBrush(backBrush);
				pDC->setFont(backFont);
				nCnt++;
#endif
			}
#ifdef PPT_EDITOR
			else if (EDITOR_PPT == getBWPEngineMode())
			{
				if ( !m_CmdEngine->isSlideShow() && ACTMAKETHUMBNAIL != nCurOperation)
				{
					BrSize *pSize;
					if( isEditMasterHandout() || isEditMasterNote() )
						pSize = getSlideNotePaperSize();
					else
						pSize = getSlideSize();

					rcPage.setRect(0, 0, pSize->cx, pSize->cy);
					m_CmdEngine->page2Logical(n, rcPage);
					pDC->fillSolidRect(rcPage.nLeft, rcPage.nTop, rcPage.nRight, rcPage.nBottom, RGB_WHITE);

					drawPageEdge(pPainter, pDC, rcPage, pPage, n);

					BrUSHORT dispText[255] = {0};
					BrINT nLen = 255;

					nLen = getCmdEngine()->getResString(BR_RESSTR_LOADING, dispText, nLen);

					BString str;
					str = dispText;
					PoTextAtt textAtt;
					// textAtt.setHanFSize(400);
					textAtt.setEngFSize(400);

					CTextDraw::DrawSlideText(pDC, this, &str, &textAtt, CENTER, MIDDLE_ARRANGE, 0, &rcPage, BrTRUE);

					m_CmdEngine->setNeedValidateScreen(BrTRUE);
					m_CmdEngine->setJustUpdateScreen(BrTRUE);

#ifdef USE_SPL_MANAGER
					if(arrDirtyPos)
					{
						sDirtyPos.nFirstY = rcPage.nTop;
						sDirtyPos.nLastY = rcPage.nBottom;
						arrDirtyPos->Add(sDirtyPos);
					}
#endif	// USE_SPL_MANAGER
				}
			}
#endif // PPT_EDITOR
		}

		this->getCaret()->DrawIMECompUnderLine( pPainter , pDC );

	} PO_THREAD_CATCH_BLOCK {

		if(bSPLPaintMode)
		{
			setGeneralStatus(bOldNativeDraw, eNativeDrawPageGValueStatus);
		}
		else if(m_CmdEngine->isNeedValidateScreen())
		{
			setGeneralStatus(BrTRUE, eNativeDrawPageGValueStatus);
		}
		// pPainter->pageImg.m_ScreenBitmap.dumpImage(0, 0);
		// pPainter->pageImg.m_PageBitmap.dumpImage(0, 0);

		BrRect orgClipRect, clipRect;
		pDC->getClipRect(orgClipRect);

		clipRect.left = clipRect.top = 0;
		clipRect.right = getLCDWidth();
		clipRect.bottom = getLCDHeight();
		pDC->setClipRect(&clipRect);

		n++;
		for (n; n <= nEndPage; n++)
		{
			pPage = pPageArray->getPage(n);

			if (pPage)
			{
				rcPage.setRect(0, 0, pPage->width(), pPage->height());
				m_CmdEngine->page2Logical(pPage, rcPage);
				dUnit.setPageStart(rcPage.nLeft, rcPage.nTop);

				BRect rcEraseBkgnd;
				rcEraseBkgnd.SetEmpty();
				BrCOLORREF color;
				if (Brcontext.m_GeneralValue.dwBgColorForTXT != WHITE_COLOR)
				//if ( getDocType()==BORA_DOCTYPE_ASCI )
					color = Brcontext.m_GeneralValue.dwBgColorForTXT;
				else
					color = getPaperColor();

#ifndef PPT_EDITOR_ERROR
				if( this->GetGrayMode() != GRAY_MODE_COLOR )
				{
					color = BrColor::getBwColor( GetGrayMode(), pPage->getBgColorMode() , color , GRAY_MODE_APPLY_FILL );
				}
#endif //PPT_EDITOR_ERROR
				if(getInvalidateFlag())
				{
					if (tmpRect.IntersectRect(rcPage, m_rcInvaldateRect))
					{
						if (rcPage.nTop < m_rcInvaldateRect.nTop)
						{
							rcEraseBkgnd = m_rcInvaldateRect;
							if(rcPage.nRight < m_rcInvaldateRect.nRight)
								rcEraseBkgnd.nRight = rcPage.nRight;
							if(rcPage.nBottom < m_rcInvaldateRect.nBottom)
								rcEraseBkgnd.nBottom = rcPage.nBottom;
							if(rcPage.nLeft > m_rcInvaldateRect.nLeft)
								rcEraseBkgnd.nLeft = rcPage.nLeft;


							pDC->fillSolidRect(rcEraseBkgnd.nLeft, rcEraseBkgnd.nTop,
								rcEraseBkgnd.nRight, rcEraseBkgnd.nBottom, color);
						}
						else if ( rcPage.nTop < m_rcInvaldateRect.nBottom)
						{
							rcEraseBkgnd = m_rcInvaldateRect;

							rcEraseBkgnd.nTop = rcPage.nTop;
							if(rcPage.nRight < m_rcInvaldateRect.nRight)
								rcEraseBkgnd.nRight = rcPage.nRight;
							if(rcPage.nBottom < m_rcInvaldateRect.nBottom)
								rcEraseBkgnd.nBottom = rcPage.nBottom;
							if(rcPage.nLeft > m_rcInvaldateRect.nLeft)
								rcEraseBkgnd.nLeft = rcPage.nLeft;

							pDC->fillSolidRect(rcEraseBkgnd.nLeft, rcEraseBkgnd.nTop,
								rcEraseBkgnd.nRight, rcEraseBkgnd.nBottom, color);
						}
						else
						{
							pDC->fillSolidRect(rcPage.nLeft, rcPage.nTop, rcPage.nRight, rcPage.nBottom, color);
						}
					}
				}
				else
					fillSolidRectWithClip(pPainter, rcPage.nLeft, rcPage.nTop, rcPage.nRight, rcPage.nBottom, color);
			}
		}

		pDC->setClipRect(&orgClipRect);

		// for update screen
		m_CmdEngine->setNeedValidateScreen(BrTRUE);
		m_CmdEngine->setJustUpdateScreen(BrTRUE);
		m_bOnDraw = BrFALSE;

	} PO_THREAD_END

	//ZPD-2889, for word header/footer page invalid rect
	if(m_HeaderFooterEngine->is_edit_mode() && !rcInvalidForHeaderFooter.IsEmpty())
		setInvalidateRect(&rcInvalidForHeaderFooter);

	m_HeaderFooterEngine->set_is_change_mode(BrFALSE);

	if(bSPLPaintMode)
	{
		setGeneralStatus(bOldNativeDraw, eNativeDrawPageGValueStatus);
	}
	else if(m_CmdEngine->isNeedValidateScreen())
	{
		setGeneralStatus(BrTRUE, eNativeDrawPageGValueStatus);
	}

	m_bOnDraw = BrFALSE;

//[2013.02.19][TID:#13197][�鿵��]PPT & PPTX �ܸ� �ӵ� ������ ���� ��� ������ ����
#ifdef SUPPORT_PPT_TIME_PROFILE
	PROFILE_END((BrINT32)this, 0);
#endif //SUPPORT_PPT_TIME_PROFILE

}
#endif


/*
BrBOOL BoraDoc::DoSave(BString &fn, INT16 * pRefMem)
{
	if(pRefMem)
	{
		INT16 oldRefNum = m_iMemRef;

		m_iMemRef = *pRefMem;

		if (!DoSave (fn))
		{
			m_iMemRef = oldRefNum;
			return false;
		}
		else
		{
			m_strPathName = fn;
		}
	}
	else
	{
		if (!DoSave (fn)) return false;
			m_strPathName = fn;
	}

	return true;
}
*/

/*
bool BoraDoc::DoSave(BString &pszPathName)
{
	int nDocType = getDocTypeFromName(pszPathName);
	if (BORA_DOCTYPE_BORA == nDocType)
	{
		BFile f(pszPathName, m_iMemRef);
		if (f.open(PVFM_WRITEONLY))
		{
			BDataStream loadArchive(&f);
//jyoh 			loadArchive.setByteOrder (BDataStream::LittleEndian);
			CBoraArchive bar(&loadArchive);
			Serialize(bar);
			f.close();
			m_bModified = BrFALSE;
			return BrTRUE;
		}
		else
		{
			DisplayError(0);
			return BrFALSE;
		}
	}
	else
	{
		BrBOOL b = doExport(pszPathName, nDocType);
		if (!b)
		{
			DisplayError(0);
		}

		return b;
	}

	return false;
}
*/

/* jkjung
void BoraDoc::DisplayError(int nType)
{
	if(nType == 0)
        PmMsgBox::msgNormalWarning("Cannot save file.");
	else
	 	PmMsgBox::msgNormalWarning("Cannot load file.");
}
*/

/////////////////////////////////////////////////////////////////////////////
// BoraDoc serialization

/*
void BoraDoc::Serialize(CBoraArchive& bar)
{
	int nDataSize;
	BYTE *pBuf;

	// allocation serialize IO buf
	g_pIOBuf = (lpbyte)BrMalloc(DATAIOSIZE);

	if (bar.IsStoring())
	{
		RemoveUnusedImageObj();

		pBuf = g_pIOBuf;
		setInt(pBuf, CURRENTVERSION);  pBuf += SIZEINT;
		setInt(pBuf, DOCTYPE_BORAQM);

		bar.Write(g_pIOBuf, SIZEINT * 2);

		nDataSize = setDataToBuf();
		bar.Write(g_pIOBuf, nDataSize);
	}
	else
	{
		int nSize;

		// info
		bar.Read(g_pIOBuf, SIZEINT * 2);
		pBuf = g_pIOBuf;

		m_nFileVersion = getInt(pBuf);	pBuf += SIZEINT;
		m_nDocType = getInt(pBuf);

		// data
		nDataSize = CUtil::getElementDataSize(bar, E_BBrWORDDOC);

		if (0 >= nDataSize)
			return;

		if (m_nSave > nDataSize)	// old version
		{
			nSize = setDataToBuf(BrFALSE);
			ASSERT(nSize == m_nSave);
		}

		bar.Read(g_pIOBuf, nDataSize);
		pBuf = g_pIOBuf;

		DocFlag.m_nDocFlag	= getInt(pBuf);		pBuf += SIZEINT;
		m_rcRAMargin.left	= getInt(pBuf);		pBuf += SIZEINT;
		m_rcRAMargin.top	= getInt(pBuf);		pBuf += SIZEINT;
		m_rcRAMargin.right	= getInt(pBuf);		pBuf += SIZEINT;
		m_rcRAMargin.bottom	= getInt(pBuf);		pBuf += SIZEINT;

		m_nDirtyPage	= getInt(pBuf);			pBuf += SIZEINT;
		m_bPageNumType	= *pBuf++;
		m_bTimeNumType	= *pBuf++;
		m_bPasswordSum	= *pBuf++;
		m_nWallID		= getInt(pBuf);			pBuf += SIZEINT;
		m_PaperColor	= getInt(pBuf);
	}

	// attribute
	m_Pagination.Serialize(bar);
	m_TypesetInfo->Serialize(bar);
 	m_FontArray.Serialize(bar);
	m_ParaAttArray.Serialize(bar);
	m_TextAttArray.Serialize(bar);

	// m_StyleAttArray->setFilter((BYTE)(STYLE_USED | STYLE_CUSTOM));
	m_StyleAttArray->Serialize(bar);
	m_FieldArray.Serialize(bar);
	m_GrapAtt.Serialize(bar);
	m_BulletArray.Serialize(bar);
	m_CmdEngine->Serialize(bar);
	m_TableEngine->Serialize(bar);

	// data
	m_MstPageArray->Serialize(bar);
    m_PageArray->Serialize(bar);
	m_WebPageArray->Serialize(bar);
	m_MstAFrameList->Serialize(bar);
	m_AFrameList.Serialize(bar);
    m_ImagePool->Serialize(bar);
	m_Summation.Serialize(bar);

	if (bar.IsStoring())
	{
		bar.Flush();
	}

	BrFree(g_pIOBuf);
}
*/

/*
int BoraDoc::setDataToBuf(BrBOOL bSave)
{
	BYTE *pBuf = g_pIOBuf;
	int nDataSize = m_nSave;

	if (bSave)	// save
	{
		setInt(pBuf, E_BBrWORDDOC);	pBuf += SIZEINT;
		setInt(pBuf, nDataSize);	pBuf += SIZEINT;
		nDataSize += ELEMENTHEADERSIZE;
	}

	setInt(pBuf, DocFlag.m_nDocFlag);	pBuf += SIZEINT;
	setInt(pBuf, m_rcRAMargin.left); 	pBuf += SIZEINT;
	setInt(pBuf, m_rcRAMargin.top); 		pBuf += SIZEINT;
	setInt(pBuf, m_rcRAMargin.right); 	pBuf += SIZEINT;
	setInt(pBuf, m_rcRAMargin.bottom); 	pBuf += SIZEINT;
	setInt(pBuf, m_nDirtyPage);			pBuf += SIZEINT;
	*pBuf++	= m_bPageNumType;
	*pBuf++	= m_bTimeNumType;
	*pBuf++	= m_bPasswordSum;
	setInt(pBuf, m_nWallID); 			pBuf += SIZEINT;
	setInt(pBuf, m_PaperColor);

	return nDataSize;
}
*/

//unsigned long	nGStartTime;
BrBOOL BoraDoc::doImport(BString &fileName, int nDocType, int nPage)
{
	PO_THREAD_TRY_BLOCK {
	shorten_text_frame_post_processor::scoped_callstack_atomic_t scoped_callstack_lock;
	BrBOOL bRet = BrFALSE;

	//nGStartTime = BrGetTickCount();

	m_Caret->setCaretStatus(BR_CARET_OFF);

#ifdef USE_HWP_CONTROL
	//OCX�� ��� ���½ÿ� Editing Mark ������ �����Ƿ� ���½� �Ʒ��� ���� Setting��.
	if(Brcontext.m_GeneralValue.bSyncMode)
	{
		//P�� import �� �ܶ���ȣ show ������
		/*BrEditSymbolShowStateSetting SymbolState = {0, };
		m_CmdEngine->setEditSymbolShowState(SymbolState);
		m_CmdEngine->setShowEditSymbol(BrFALSE);*/
		if(getDocExt() == BORA_EXT_HWP)
			g_BoraThreadAtom.m_nPrintFilterMode = gpPaint->mode.m_nFilterMode = FILTER_WORD;
		else if(getDocExt() == BORA_EXT_TXT)
			g_BoraThreadAtom.m_nPrintFilterMode = gpPaint->mode.m_nFilterMode = FILTER_TEXT;
		else if(getDocExt() == BORA_EXT_HTML)
			g_BoraThreadAtom.m_nPrintFilterMode = gpPaint->mode.m_nFilterMode = FILTER_WORD;
		else if(getDocExt() == BORA_EXT_ODT)
			g_BoraThreadAtom.m_nPrintFilterMode = gpPaint->mode.m_nFilterMode = FILTER_WORD;

		m_bOCXMode = BrTRUE;

	}
#endif	//USE_HWP_CONTROL

	if (g_pBInterfaceHandle->getDocumentValidattionMode())
	{
		if (getDocType() != CUtil::getFileSignatureFormat(fileName))
			return SetErrorFReturn(CPublicError(kPoErrFileContentsMismatched));
	}

	switch (nDocType)
	{
	case BORA_DOCTYPE_HTML:
		{
#ifdef IMPORT_HTML

          this->ClearAll();
          doNewDoc(BrNULL, BORA_DOCTYPE_ODT, BR_PPT_PAPER_TYPE_NONE, BR_SLIDE_TEMPLATE_BLANK);
          BrAutoChar temp = CUtil::convertBStringToChar(&fileName, CP_UTF8);
          html::HtmlInterface html_interface(temp.get());
          bRet = html_interface.ImportHtml(kDocumentType);

          setFinishLoading(BrTRUE);

			if (bRet)
			{
				if (kPoProcessSucess != GetErrorCode())
					g_BoraThreadAtom.m_nErrorCode = GetErrorCode();
				SetErrorCode(kPoProcessSucess);
#ifdef	BWP_EDITOR
				if ( isFinishLoading() )	{
					m_Caret->moveToStartOfDoc();
					CLine *pLine = getFirstLine();
					if ( pLine )
                      CTextProc::removeLastCR(this, pLine->getFrame());
					getCmdEngine()->setDocEndCoord();
				}
#endif	//BWP_EDITOR
			}
#endif //IMPORT_HTML
		}
		break;

	case BORA_DOCTYPE_MHT:
		{
#ifdef IMPORT_HTML
#ifdef USE_MIME
#ifdef USE_MHT_MEMORY
			{
				BrAutoChar temp = CUtil::convertBStringToChar(&fileName, CP_UTF8);
				bRet = importMime_Memory( (BrLPCTSTR) temp.get() );
#ifndef LOAD_ONE_PAGE_HTML
				setFinishLoading(BrTRUE);
#endif	// LOAD_ONE_PAGE_HTML
			}
#else
			{
				BrAutoChar temp = CUtil::convertBStringToChar(&fileName, CP_UTF8);
				bRet = importMime_File( (BrLPCTSTR) temp.get() );
				//bRet = importHtml( (BrLPCTSTR) newPath);

				setFinishLoading(BrTRUE);
			}
#endif //USE_MHT_MEMORY
#endif //USE_MIME

			if (bRet)
			{
				if (kPoProcessSucess != GetErrorCode())
					g_BoraThreadAtom.m_nErrorCode = GetErrorCode();
				SetErrorCode(kPoProcessSucess);
#ifdef	BWP_EDITOR
				// m_unit->setStatus(DOC_FLAG_SHOWCR, ON);
				if ( isFinishLoading() )	{
					m_Caret->moveToStartOfDoc();
					CLine *pLine = getFirstLine();
					if ( pLine )	CTextProc::removeLastCR(this, pLine->getFrame());
				}
#endif	//BWP_EDITOR
			}
#endif //IMPORT_HTML
		}
		break;

#ifdef IMPORT_HWP
	case BORA_DOCTYPE_HWP:
		{
			BRCONTEXT;
			BString orgName = fileName;
			BrINT32 nOldErrcode = kPoProcessSucess;

			setFromHwp(BrTRUE);
#ifdef USE_HWP_CONTROL
			if(Brcontext.m_GeneralValue.bSyncMode)
				setIncPageNum(1000);
			else
				setIncPageNum(1);
#else	//USE_HWP_CONTROL
				setIncPageNum(1);
#endif	//USE_HWP_CONTROL
			m_pHwpCoMgr = BrNEW HwpCoMgr();
			if(!m_pHwpCoMgr)
				return BrFALSE;

			setOnBgLoad(BrTRUE);
			bRet = m_pHwpCoMgr->IDoImportHwp(fileName, nPage + getIncPageNum());
			setOnBgLoad(BrFALSE);
			if(bRet)
			{
				if (kPoProcessSucess != GetErrorCode())
					g_BoraThreadAtom.m_nErrorCode = GetErrorCode();
				SetErrorCode(kPoProcessSucess);

				//jkjung pTableEngine->resizeTables();
				//jkjung CTextProc::arrangeMarkingLines(this, getFirstLine(), BrNULL);
				fileName = orgName;	// ���� ���������� �缳��(current directory�� �����ֱ� ����...)

#ifdef RENDERING_WITH_BORATHREAD
				setCurLastReadPage(1);
#else
				setCurLastReadPage(6/*1*/);
#endif//RENDERING_WITH_BORATHREAD

				//[2011.09.23][TID : 88][���ؼ�] IMAGE_OTS ��� ������ ���� �̹��� �÷��� ����
				if(isFinishLoading())
					m_pHwpCoMgr->FreeInstance();
			}
			else
			{
				//[2015.01.15][ZPD-6922][���ؼ�] ���� ����� 0�� ��� �������� ����
				BFile* pFile = BrNEW BFile();
				if(pFile->Open(fileName, BMV_READ_ONLY))
				{
					if(pFile->Size() == 0)
					{
						BR_SAFE_DELETE(m_pHwpCoMgr);
						doNewDoc(BrNULL, nDocType, BR_PPT_PAPER_TYPE_NONE,  BR_SLIDE_TEMPLATE_BLANK);
						setFinishLoading(BrTRUE);
						bRet = BrTRUE;
					}
					else
					{
						if(GetErrorCode() == kPoProcessSucess)
						{
							SET_ERROR(kPoErrInternal, "Error setting required during import");
						}
					}
				}
				else
				{
					SET_ERROR((PoError)kPoErrCorruptFile, "");
					bRet = BrFALSE;
				}

				BR_SAFE_DELETE(pFile);
			}
		}
		break;
#endif //IMPORT_HWP

#ifdef IMPORT_GUL
	case BORA_DOCTYPE_GUL:
		{//2006-04-27 open
			BString orgName = fileName;
			setIncPageNum(5);

			m_pImportForHun = BrNEW CHunToBoraX;
			m_pImportForHun->setCommonBora(this);
			setOnBgLoad(BrTRUE);
			bRet = m_pImportForHun->convHunToBoraX(fileName, nPage+getIncPageNum()/*6*//*1*/);
			setOnBgLoad(BrFALSE);

			if (bRet)
			{
				if (kPoProcessSucess != GetErrorCode())
					g_BoraThreadAtom.m_nErrorCode = GetErrorCode();
				SetErrorCode(kPoProcessSucess);	// 0x01 : ���� ���� ����

				setFromGul(BrTRUE);
#ifdef	BWP_EDITOR
				// m_unit->setStatus(DOC_FLAG_SHOWCR, ON);
#endif	//BWP_EDITOR
				//jkjung pTableEngine->resizeTables();
				//jkjung CTextProc::arrangeMarkingLines(this, getFirstLine(), BrNULL);
				fileName = orgName;	// ���� ���������� �缳��(current directory�� �����ֱ� ����...)

#ifdef RENDERING_WITH_BORATHREAD
				setCurLastReadPage(1);
#else
				setCurLastReadPage(6/*1*/);
#endif //RENDERING_WITH_BORATHREAD
				if ( isFinishLoading() )	{
					if ( m_pImportForHun )	{
						BrDELETE	m_pImportForHun;
						m_pImportForHun = BrNULL;
					}
				}
			}
		}
		break;
#endif //IMPORT_GUL

#ifdef IMPORT_DOC
	case BORA_DOCTYPE_DOC:
		{
			//[T-14836]
			BFile file;
			if (BrFALSE == file.Open(fileName, BMV_READ_ONLY, 0, BrTRUE))
				return BrFALSE;

			//���� contents Ȯ���ϴ� ��ƾ
			BrINT32 content_type = CUtil::getFileSignatureFormat(fileName);
# ifdef IMPORT_DOCX
			if (BORA_DOCTYPE_DOCX == content_type) {
				file.Close();
				m_nDocType = BORA_DOCTYPE_DOCX;
				m_TableEngine->setStyleMgr(m_nDocType);
				g_pErrorHandler->init();
				goto DOCX_READ;
			}
			if (BORA_DOCTYPE_DOC != content_type) {
				SET_ERROR_ONLY(kPoErrFileContentsMismatched, ErrMsg("content_type = %d", content_type));
				break;
			}

			BString strExt = fileName.mid(fileName.findRev("."));
			if (!strExt.compareIgnorUpperLower(".dot"))
				theBWordDoc->setEditProtect(BrTRUE);

# else  // IMPORT_DOCX
			if (BORA_DOCTYPE_DOC != content_type && BORA_DOCTYPE_DOCX != content_type) {
				SET_ERROR_ONLY(kPoErrFileContentsMismatched, ErrMsg("content_type = %d", content_type));
				break;
			}
# endif  // IMPORT_DOCX

			setDocContentType(BORA_DOCTYPE_DOC);

			BrINT32 file_size = file.Size();
			file.Close();
			if (0 == file_size) {
				doNewDoc(BrNULL, nDocType,BR_PPT_PAPER_TYPE_NONE, BR_SLIDE_TEMPLATE_BLANK);
				setFinishLoading(BrTRUE);
				bRet = BrTRUE;
				break;
			}

			BString file_name = fileName;
			BRCONTEXT;
			setIncPageNum(1);

			m_pFilterDoc = BrNEW BWordToBora();
			//[dwchun :2011.08.30] : ù ������ ������� �����ִ� ��� �ӵ� ����� ���� 2�������� ���鵵�� ����
			setOnBgLoad(BrTRUE);
			bRet = m_pFilterDoc->DoImport(fileName, nPage + getIncPageNum());
			setOnBgLoad(BrFALSE);

			auto isPasswordDoc = [&]()->bool {
				return (kPoErrReadOnlyRecommenedDoc == GetErrorCode() || kPoErrWritePasswordDoc == GetErrorCode() || kPoErrReadPasswordDoc == GetErrorCode());
			};

			if (BrFALSE == bRet && BrFALSE == g_pErrorHandler->CanContinue() && BrFALSE == isPasswordDoc())
			{
				m_nDocType = BORA_DOCTYPE_DOCX;
				m_TableEngine->setStyleMgr(m_nDocType);
				g_pErrorHandler->init();
				goto DOCX_READ;
			}

			if (bRet) {
				setFromDoc(BrTRUE);
				// MS-Word ������ ��� ���ο� Page�� �����ɶ� ������ ������ Region �� ������ �����ϰԲ� ����
				setInheritLastRegion(BrTRUE);
				if (kPoProcessSucess != GetErrorCode())
					g_BoraThreadAtom.m_nErrorCode = GetErrorCode();
				ResetErrorCode();
# ifdef NOT_USED
				CTextProc::arrangeMarkingLines(this, getFirstLine(), BrNULL);
# endif
				fileName = file_name;	// ���� ���������� �缳��(current directory�� �����ֱ� ����...)

# ifdef RENDERING_WITH_BORATHREAD
				setCurLastReadPage(1);
# else  // RENDERING_WITH_BORATHREAD
				setCurLastReadPage(6);
# endif  // RENDERING_WITH_BORATHREAD

				if (isFinishLoading())
					BR_SAFE_DELETE(m_pFilterDoc);
			}
		}
		break;
#endif  // IMPORT_DOC
#ifdef IMPORT_DOCX
	case BORA_DOCTYPE_DOCX:
		{
DOCX_READ:
			BString orgName = fileName;

			//���� contents Ȯ���ϴ� ��ƾ
			BrINT32 nDocumentContentType = CUtil::getFileSignatureFormat(fileName);
			if(nDocumentContentType != BORA_DOCTYPE_DOCX && nDocumentContentType != BORA_DOCTYPE_DOC)
			{
				if (nDocumentContentType == BORA_DOCTYPE_ASCI)
				{
					SET_ERROR((PoError)kPoErrCorruptFile, "");
				}
				else
				{
					SET_ERROR((PoError)kPoErrFileContentsMismatched, "ext = DOCX and contents are not DOCX");
				}
				break;
			}
			
			BString strExt = fileName.mid(fileName.findRev("."));
			if ( !strExt.compareIgnorUpperLower(".docm") || !strExt.compareIgnorUpperLower(".dotx"))
				theBWordDoc->setEditProtect(BrTRUE);

			setDocContentType(BORA_DOCTYPE_DOCX);
			//[2011.11.09][�̻�][TID:1080] File name ���� ��� ����
			if(!m_pDocumentPackage->InitPackage(getDocFileName())) //readrelationfile(); �� initPackage���� �����
			{
				BrBYTE cStorageMagic[8] = {0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1};

				BFile file;
				if ( file.Open(fileName, BMV_READ_ONLY) )
				{
					BrBYTE bufP[256];
					BrULONG numBytes = BrSizeOf(bufP);
					BrUINT32 nRead;

					nRead = file.Read((BrBYTE*)bufP, numBytes );
					file.Close();


					//[TID 2195][toypilot] 0K DOCX ���� open
					if(0 == nRead) {
						doNewDoc(BrNULL, nDocType,BR_PPT_PAPER_TYPE_NONE,  BR_SLIDE_TEMPLATE_BLANK);
						setFinishLoading(BrTRUE);
						bRet = BrTRUE;
						break;
					}

					if( ( nRead > 8 ) && (memcmp(bufP, &cStorageMagic[0], 8) == 0) )//[2012.06.28][������[TID:7391]��ȣȭ �����϶� RTF�� ������ �ʰ� ����.
					{
						LoadOleFile cOleFile;
						cOleFile.Open(fileName);
						SvStream *tmpStr = BrNULL;
						// doc document
						if( (tmpStr = cOleFile.openStream("EncryptedPackage")) != BrNULL )
						{
							theBWordDoc->setPasswordDoc(BrTRUE);
                            OfficeCryptoContainer * pOfficeCryptoContinaer = OfficeCryptoContainer::GetInstance();
                            DecryptResultType bRet = pOfficeCryptoContinaer->OpenEncryptedXML(fileName, m_pDocumentPackage);
							if(bRet == kSuccess )
							{
								SET_ERROR(kPoProcessSucess, "");
								theBWordDoc->SetOpenPasswordDoc(BrTRUE);
 							}
							else {
								BR_SAFE_DELETE(m_pDocumentPackage);
								break;
							}
						}
						else
							SET_ERROR((PoError)kPoErrCorruptFile, "");
					}

				}
			}
	//[2012.08.20][������][TID:7901] SummayInfo import/export ����.
	CBrXMLAppImporter* pAppImporter = BrNEW CBrXMLAppImporter();
	pAppImporter->ReadAppInfo(m_pDocumentPackage);

	if(pAppImporter)
		BR_SAFE_DELETE(pAppImporter);

		setIncPageNum(1);

			m_pImportForDocx = BrNEW CDocXMain(m_pDocumentPackage);
			setOnBgLoad(BrTRUE);
			setFromDoc(BrTRUE);
			bRet = m_pImportForDocx->doImportDocX(fileName, m_iMemRef, nPage+getIncPageNum()/*6*//*1*/);
			setOnBgLoad(BrFALSE);

			if (bRet)
			{
#ifdef	BWP_EDITOR
				// m_unit->setStatus(DOC_FLAG_SHOWCR, ON);
#endif	//BWP_EDITOR
				// MS-Word ������ ��� ���ο� Page�� �����ɶ� ������ ������ Region �� ������ �����ϰԲ� ����
				setInheritLastRegion(BrTRUE);
				if (kPoProcessSucess != GetErrorCode())
					g_BoraThreadAtom.m_nErrorCode = GetErrorCode();
				SetErrorCode(kPoProcessSucess);	// 0x01 : ���� ���� ����

#ifdef  NOT_USED
                CTextProc::arrangeMarkingLines(this, getFirstLine(), BrNULL);
#endif
				fileName = orgName;	// ���� ���������� �缳��(current directory�� �����ֱ� ����...)

#ifdef RENDERING_WITH_BORATHREAD
				setCurLastReadPage(1);
#else
				setCurLastReadPage(6/*1*/);
#endif // RENDERING_WITH_BORATHREAD
				// BrDELETE DOCX Filter
				if ( isFinishLoading() )	{
					BR_SAFE_DELETE(m_pImportForDocx);
				}
			}
		}
		break;
#endif //IMPORT_DOCX

#ifdef IMPORT_ODT
	case BORA_DOCTYPE_ODT: {
			if (BrFALSE == m_pOdPackage->InitPackage(getDocFileName())) {
				switch (m_nErrCode)
				{
				case kPoErrReadPasswordDoc:
				case kPoErrWrongReadPassword:
					bRet = BrFALSE;
					break;
				case kPoErrUnsupportedVersionODF_1_3:
					bRet = BrFALSE;
					break;
				case kPoErrUnknownMessageDigestInOpenSSL:
					bRet = BrFALSE;
					break;
				case kPoProcessSucess:
					doNewDoc(BrNULL, nDocType, BR_PPT_PAPER_TYPE_NONE, BR_SLIDE_TEMPLATE_BLANK);
					bRet = BrTRUE;
					break;
				default:
					SET_ERROR(kPoErrCorruptFile, BrNULL);
					bRet = BrFALSE;
					break;
				}
				setFinishLoading(BrTRUE);
				break;
			}

			//[2014.09.30][������] SingleByte->DoubleByte ODT �������� ����.
			setfDntBlnSbDbWid(BrFALSE);

			setIncPageNum(1);

			m_pFilterOdt = BrNEW opendocument::OdtMain(m_pOdPackage);
			m_pFilterOdt->InitImport();
			setFromOdt(BrTRUE);
			bRet = m_pFilterOdt->DoImport(m_iMemRef, nPage + getIncPageNum());
			if (bRet) {
				// MS-Word ������ ��� ���ο� Page�� �����ɶ� ������ ������ Region �� ������ �����ϰԲ� ����
				setInheritLastRegion(BrTRUE);
				PoError err = GetErrorCode();
				if (kPoProcessSucess != err)
					g_BoraThreadAtom.m_nErrorCode = err;
				ResetErrorCode();
				setCurLastReadPage(1);
				if (isFinishLoading())
					BR_SAFE_DELETE(m_pFilterOdt);
			}
			else {
				setFinishLoading(BrTRUE);
				SetErrorCode(kPoErrInternal);
			}
		}
		break;
#endif  // IMPORT_ODT

#ifdef IMPORT_RTF
	case BORA_DOCTYPE_RTF:
		{
			theBWordDoc->setEditProtect(BrTRUE);
			BString orgName = fileName;
			m_pImportForRTF = BrNEW CRtfMain();
			if( !m_pImportForRTF ) {
				SET_ERROR((PoError)kPoErrMemory, "");
			}
			setIncPageNum(5);
			setOnBgLoad(BrTRUE);
			BrAutoChar temp = CUtil::convertBStringToChar(&fileName, CP_UTF8);
			bRet = m_pImportForRTF->doImportRtf((BrLPCTSTR)temp.get(), nPage+getIncPageNum());
			setOnBgLoad(BrFALSE);
			if (bRet)
			{
				setFromRtf(BrTRUE);

				CTextProc::arrangeMarkingLines(this, getFirstLine(), BrNULL);
				BCoreNotify(BR_DOCTYPE_RTF_UNCLEARFILENAME);//Ȯ���� doc ������ rtf�϶� ui�� rtf���� �˷���
				//pLine = BrNULL;
				SetErrorCode(kPoProcessSucess);	// 0x01 : ���� ���� ����
				fileName = orgName;	// ���� ���������� �缳��(current directory�� �����ֱ� ����...)
				if ( isFinishLoading() )	{
					if ( m_pImportForRTF && !m_pImportForRTF->m_Rtf->m_bIsImage)	{
						BrDELETE	m_pImportForRTF;
						m_pImportForRTF = BrNULL;
					}
				}
			}
			else if(!bRet && kPoProcessSucess == m_nErrCode)
			{
				SET_ERROR(kPoErrCorruptFile, "");
			}
		}
		break;
#endif//IMPORT_RTF
#ifdef SUPPORT_BWP_FORMAT
	case BORA_DOCTYPE_BWP:
		{
			BString orgName = fileName;
			BwpFormatConverter* pBwpFormatConverter = BrNEW BwpFormatConverter();
			if( !pBwpFormatConverter )
			{
				SET_ERROR((PoError)kPoErrMemory, "");
			}
			setOnBgLoad(BrTRUE);
			bRet = pBwpFormatConverter->doImportBWP(fileName);
			setOnBgLoad(BrFALSE);

			if(!bRet && kPoProcessSucess == m_nErrCode)
			{
				SET_ERROR(kPoErrCorruptFile, "");
			}
		}
		break;
#endif//SUPPORT_BWP_FORMAT
	case BORA_DOCTYPE_ASCI: {
			BrBOOL is_prev_import_proc = g_pAppStatic->bImportProc;
			g_pAppStatic->bImportProc = BrTRUE;

#if defined(BWP_EDITOR) && defined(IMPORT_TXT)
			getCmdEngine()->setDefFSize(DEF_FONT_SIZE_IN_TEXT);
			m_pImportTxt = BrNEW TxtImport(this);
			if (m_pImportTxt->Initialize(fileName)) {  // make page information
				if (m_pImportTxt->empty()) {
					if (g_pBInterfaceHandle->IsOpenTextInWordLayout())
					{
						doNewDoc(BrNULL, BORA_DOCTYPE_DOCX, BR_PPT_PAPER_TYPE_NONE, BR_SLIDE_TEMPLATE_BLANK);  // TXT�� DOC�� ��� OFF-1913
						// TXT�� DOCX�� ���� ������ �ٸ�
						CLine* first_line = theBWordDoc->getFirstLine();
						CSectionInfomation* section = first_line ? first_line->getSectionInformation() : BrNULL;
						if (section)
							section->initForTXT();
					}
					else
						doNewDoc(BrNULL, BORA_DOCTYPE_ASCI, BR_PPT_PAPER_TYPE_NONE, BR_SLIDE_TEMPLATE_BLANK);
					setFinishLoading(BrTRUE);
					setSendTotalLoadComplete(BrFALSE);
					bRet = BrTRUE;
				}
				else {
					BrCHAR bDocType = BORA_DOCTYPE_ASCI;
					if (g_pBInterfaceHandle->IsOpenTextInWordLayout())
						bDocType = (m_nDocType == BORA_DOCTYPE_HWP) ? BORA_DOCTYPE_HWP : BORA_DOCTYPE_DOCX;
					doNewDoc(BrNULL,
							 bDocType,
					         BR_PPT_PAPER_TYPE_NONE,
					         BR_SLIDE_TEMPLATE_BLANK);
					setSendTotalLoadComplete(BrFALSE);
					g_BoraThreadAtom.m_bSendTotalLoadComplete = BrFALSE;
					setOnBgLoad(BrTRUE);
					bRet = m_pImportTxt->FirstImport();
					setOnBgLoad(BrFALSE);
					if (bRet) {
						if (g_pBInterfaceHandle->IsOpenTextInWordLayout())
						{
							// TXT�� DOCX�� ���� ������ �ٸ�
							CLine* first_line = theBWordDoc->getFirstLine();
							CSectionInfomation* section = first_line ? first_line->getSectionInformation() : BrNULL;
							if (section)
								section->initForTXT();
						}
						ResetErrorCode();
						DocFlagEx.flag.m_bModified = BrFALSE;
					}
				}
				if (isFinishLoading())
					BR_SAFE_DELETE(m_pImportTxt);
				theBWordDoc->setFromSubTxt(BrTRUE);
			}
			else {
				BR_SAFE_DELETE(m_pImportTxt);
			}

			g_pAppStatic->bImportProc = is_prev_import_proc;

			if (bRet) {
				if (kPoProcessSucess != GetErrorCode())
					g_BoraThreadAtom.m_nErrorCode = GetErrorCode();
				ResetErrorCode();
				if (g_pBInterfaceHandle->IsOpenTextInWordLayout())
				{
					if (m_nDocType == BORA_DOCTYPE_HWP)
						setFromHwp(BrTRUE);		// TXT�� ������ HWP �б� ���� �߰� CSP-1704
					else
						setFromDoc(BrTRUE);		// TXT�� DOC�� ��� OFF-1913
				}

#	ifdef RENDERING_WITH_BORATHREAD
				setCurLastReadPage(1);
#	else
				setCurLastReadPage(6);
#	endif  // RENDERING_WITH_BORATHREAD
			}
#endif	// defined(BWP_EDITOR) && defined(IMPORT_TXT)
            break;
		}
	}

#ifdef	BWP_EDITOR
	if ( bRet )
	{
		ci_validate_during_import();
		if ( isViewPrintMode())
		{
			getCmdEngine()->setWorkOrgCoord(getPageArray(), 1);
			getCmdEngine()->setDocEndCoord();
		}

		m_MemoEventManager->chkArrangeForMemoFrame(BrFALSE);
	}
#endif	// BWP_EDITOR


//#ifdef _DEBUG
//	if ( isFromHwp() )	m_CmdEngine->m_sEditSymbolShowState.bHWPTypeSet = true;
//#endif // _DEBUG
	return bRet;
	} PO_THREAD_CATCH_BLOCK {

		if(shorten_text_frame_post_processor::callstack_locked > 0)
			std::atomic_fetch_sub(&shorten_text_frame_post_processor::callstack_locked, 1); // IMPORTANT!
	} PO_THREAD_END
	return false;
}

// Read only one page (For HWP, GUL, DOC)
// nPgNum : �о�� �� page number�� ���� ���ڶ��� �ʰ� ����� ����...
//          -1 (last page���� �д� ������)
BrBOOL BoraDoc::doImportOnePage(int nPgNum)
{
	PO_THREAD_TRY_BLOCK {

		shorten_text_frame_post_processor::scoped_callstack_atomic_t scoped_callstack_lock;

	if ( this->isFinishLoading() )
		return BrFALSE;
	// mouse left button�� down�� ��쿡�� import�� ��� ������ OFF-8013
	if ( getCmdEngine()->isLButtonDown() )
		return BrTRUE;

#ifdef	BWP_EDITOR
	if (  BrFALSE == theBWordDoc->isViewPrintMode() )	{
		nPgNum = getTotalPage() + 1;
	}
#endif	// BWP_EDITOR

	BrBOOL bRet = BrFALSE;

	BString fileName = GetPathName();

	int		nPage = this->getTotalPage();

	setIncPageNum(6);
	// G-zero �ܸ����� ��� ������ �̵� UI �� Ư���ؼ� ���� ������ ���� �ּ� 6 ������ �� ������ �� �� �־�� �ϴ� ��찡 �߻�....
	if ( nPgNum != 0x7FFFFFFF )
		nPgNum += getIncPageNum();

	short sType = m_nDocType;
#ifdef IMPORT_TXT
	// TXT�� ������ HWP �б� ���� �߰� CSP-1704 // TXT�� DOC�� ��� OFF-1913
	if ((sType == BORA_DOCTYPE_DOCX || sType == BORA_DOCTYPE_HWP) && m_pImportTxt)
		sType = BORA_DOCTYPE_ASCI;
#endif  // IMPORT_TXT

	switch ( sType )
	{
#ifdef LOAD_ONE_PAGE_HTML
	case BORA_DOCTYPE_HTML:
	case BORA_DOCTYPE_MHT:
		{
#ifdef IMPORT_HTML
			setOnBgLoad(BrTRUE);
			bRet = importOnePageHtml();
			setOnBgLoad(BrFALSE);
#ifdef	BWP_EDITOR
			if ( isFinishLoading() )	{
				m_Caret->moveToStartOfDoc();
				getCmdEngine()->setDocEndCoord();

				CLine *pLine = getFirstLine();
				if ( pLine )	CTextProc::removeLastCR(this, pLine->getFrame());
			}
#endif	//BWP_EDITOR
			return bRet;
#endif //IMPORT_HTML
		}
		break;
#endif	// LOAD_ONE_PAGE_HTML
#ifdef IMPORT_HWP
	case BORA_DOCTYPE_HWP:
		{
			BString orgName = fileName;
			//[2015.08.10][OFF-2752][���ؼ�] �� ������ ��� Import�� �� �ʿ䰡 ����
			if(!orgName)
				break;

			if(m_pHwpCoMgr)
			{
				setOnBgLoad(BrTRUE);
				bRet = m_pHwpCoMgr->IDoImportHwp(fileName, nPgNum);
				setOnBgLoad(BrFALSE);
			}

			if(bRet)
			{
				SetErrorCode(kPoProcessSucess);
				fileName = orgName;	// ���� ���������� �缳��(current directory�� �����ֱ� ����...)
				if(isFinishLoading())
					m_pHwpCoMgr->FreeInstance();
			}
		}
		break;
#endif
#ifdef IMPORT_GUL
	case BORA_DOCTYPE_GUL:
		{//2006-04-27 open
			BString orgName = fileName;
			if ( m_pImportForHun )	{
				setOnBgLoad(BrTRUE);
				bRet = m_pImportForHun->convHunToBoraX(fileName, nPgNum);
				setOnBgLoad(BrFALSE);
			}

			if (bRet)
			{
				SetErrorCode(kPoProcessSucess);	// 0x01 : ���� ���� ����
				fileName = orgName;	// ���� ���������� �缳��(current directory�� �����ֱ� ����...)
				if ( isFinishLoading() )	{
					if ( m_pImportForHun )	{
						BrDELETE	m_pImportForHun;
						m_pImportForHun = BrNULL;
					}
				}
			}
		}
		break;
#endif

#ifdef IMPORT_RTF
	case BORA_DOCTYPE_RTF:
		{
			BString orgName = fileName;
			setOnBgLoad(BrTRUE);
			bRet = m_pImportForRTF->doImportRtf((BrLPCTSTR)fileName, nPgNum);
			setOnBgLoad(BrFALSE);
			//CTextProc::arrangeMarkingLines(this, getFirstLine(), BrNULL);
			if (bRet)
			{
				//pLine = BrNULL;
				SetErrorCode(kPoProcessSucess);	// 0x01 : ���� ���� ����
				fileName = orgName;	// ���� ���������� �缳��(current directory�� �����ֱ� ����...)
				if ( isFinishLoading() )	{
					if ( m_pImportForRTF && !m_pImportForRTF->m_Rtf->m_bIsImage)	{
							BrDELETE	m_pImportForRTF;
							m_pImportForRTF = BrNULL;
						}
				}
			}
		}
		break;
#endif//IMPORT_RTF
#ifdef IMPORT_DOC
	case BORA_DOCTYPE_DOC:
		{
			BString orgName = fileName;
			if (m_pFilterDoc) {
				setOnBgLoad(BrTRUE);
				bRet = m_pFilterDoc->DoImport(fileName, nPgNum);
				setOnBgLoad(BrFALSE);
				if (BrFALSE == bRet && BrFALSE == g_pErrorHandler->CanContinue())
				{
					PoError err = kPoErrInternal;
					if (g_BoraThreadAtom.m_nErrorCode != kPoProcessSucess)
						err = g_BoraThreadAtom.m_nErrorCode;
					BRTERMINATE(err, "", PO_PUBLIC_CLASS);
				}
			}

			if (bRet) {
				ResetErrorCode();
				fileName = orgName;	 // ���� ���������� �缳��(current directory�� �����ֱ� ����...)
				if (isFinishLoading())
					BR_SAFE_DELETE(m_pFilterDoc);
			}
		}
		break;
#endif  // IMPORT_DOC
#ifdef IMPORT_DOCX
	case BORA_DOCTYPE_DOCX:
		{
			BString orgName = fileName;
#if 1 //2007-01-08
			if ( m_pImportForDocx )	{
				// BRTHREAD_STOPWATCH;
				// BTrace("PgNum = %d", nPgNum);
				setOnBgLoad(BrTRUE);
				bRet = m_pImportForDocx->doImportDocX(fileName, m_iMemRef, nPgNum);
				setOnBgLoad(BrFALSE);
			}
#endif
			if (bRet)
			{
				SetErrorCode(kPoProcessSucess);	// 0x01 : ���� ���� ����
				fileName = orgName;	// ���� ���������� �缳��(current directory�� �����ֱ� ����...)
				// delete DOCX Filter
				if ( isFinishLoading() )	{
					if ( m_pImportForDocx )	{
						BrDELETE	m_pImportForDocx;
						m_pImportForDocx = BrNULL;
					}
				}
			}
		}
		break;
#endif //
#ifdef IMPORT_ODT
	case BORA_DOCTYPE_ODT: {
		BString orgName = fileName;
		//[2020.03.03][WPD-5202][���ؼ�] Hwp�� �����ϰ� �� ������ ��� Import�� �� �ʿ䰡 ����
		if (!orgName)
			break;

		setOnBgLoad(BrTRUE);
		if (m_pFilterOdt)
			bRet = m_pFilterOdt->DoImport(m_iMemRef, nPage + getIncPageNum());
		setOnBgLoad(BrFALSE);
		if (bRet) {
			if (kPoProcessSucess != GetErrorCode())
				g_BoraThreadAtom.m_nErrorCode = GetErrorCode();
			ResetErrorCode();
			if (isFinishLoading())
				BR_SAFE_DELETE(m_pFilterOdt);
		}
		else {
			setFinishLoading(BrTRUE);
			SetErrorCode(kPoErrInternal);
		}
		break;
	}
#endif // IMPORT_ODT
#if defined(BWP_EDITOR) && defined(IMPORT_TXT)
	case BORA_DOCTYPE_ASCI:
		if (m_pImportTxt) {
			BrBOOL bOldImportProc = g_pAppStatic->bImportProc;
			g_pAppStatic->bImportProc = BrTRUE;

			setOnBgLoad(BrTRUE);
			bRet = m_pImportTxt->DoImport();
			setOnBgLoad(BrFALSE);
			if (bRet)
				ResetErrorCode();
			g_pAppStatic->bImportProc = bOldImportProc;
			if (isFinishLoading())
				BR_SAFE_DELETE(m_pImportTxt);
		}
		break;
#endif  // defined(BWP_EDITOR) && defined(IMPORT_TXT)
	}

/*
int		nCharNum, nPageNum;
// CLine	*pTmpLine = getFirstLine();
CPage *pPage = this->getPageArray()->getPage(7);
if ( pPage )	{
	CLine	*pTmpLine = pPage->getFirstLine();
	while ( pTmpLine )	{
		nCharNum = pTmpLine->getCharNum();
		nPageNum = pTmpLine->getPage()->getPageNum();
		pTmpLine = pTmpLine->getNext();
	}
}
*/

	if ( bRet )
	{
		ci_validate_during_import();
		// BRTHREAD_STOPWATCH;
#ifdef BWP_EDITOR
		if (  BrFALSE == theBWordDoc->isViewPrintMode() )	moveAllLinesToWebPage();
#endif // BWP_EDITOR

		ChkArrangeForSpecialFrameList();

		// header/footer������ �Ǹ鼭 ������ ���� ���ĵǴ� ��찡 �߻��Ͽ� table ������ �����ϱ� ���� ���� ��ġ ����, XPD-22338 [1/22/2018 swseo]
		if ( m_nDocType!=BORA_DOCTYPE_GUL && m_nDocType!=BORA_DOCTYPE_ASCI )
		{
			CFrame *pLastFloatingTableFrame = BrNULL;
#ifdef BWP_EDITOR
			if (getBWPEngineMode() == EDITOR_WORD)
			{
				m_TableEngine->m_bLoadOnePage = BrTRUE;
				m_TableEngine->resizeTables(BrNULL, &pLastFloatingTableFrame);
				m_TableEngine->m_bLoadOnePage = BrFALSE;
			}
			else
#endif
				m_TableEngine->resizeTables(BrNULL, &pLastFloatingTableFrame);

			if (pLastFloatingTableFrame)
				m_TableEngine->arrangeFloatingTable(pLastFloatingTableFrame);
		}

		//[2014.02.12][TID:22443] �Ӹ���/�ٴڱ��� �������� ���� �ڸ� ��ƾ���
		// Arrange header & footer frames
		ArrangeHeaderFooter(BrTRUE);

		// Arrange batang(master) pages
		ArrangeBatangPage();

		setArrangeDuringImport(BrTRUE);

#if 0
		if ( m_nDocType!=BORA_DOCTYPE_GUL && m_nDocType!=BORA_DOCTYPE_ASCI )
		{
			CFrame *pLastFloatingTableFrame = BrNULL;
#ifdef BWP_EDITOR
			if (getBWPEngineMode() == EDITOR_WORD)
			{
				m_TableEngine->m_bLoadOnePage = BrTRUE;
				m_TableEngine->resizeTables(BrNULL, &pLastFloatingTableFrame);
				m_TableEngine->m_bLoadOnePage = BrFALSE;
			}
			else
#endif
				m_TableEngine->resizeTables(BrNULL, &pLastFloatingTableFrame);

			if (pLastFloatingTableFrame)
				m_TableEngine->arrangeFloatingTable(pLastFloatingTableFrame);
		}
#endif // 0

		// table������ ���Ͽ� ���� �������鿡 dirty�� ���ܼ� ���� HEJ-1702
		CLine	*pLine = getFirstLine();		// OFF-6195
		if ( pLine )	pLine = pLine->getFirstNextDirtyLine();
		// ���� frame�ȿ��� previous line�� page, column break�� ������ ���� ���κ��� ���� ERH-73
		if ( pLine )
		{
			CLine *pPrev = pLine->getPrevInFrame();
			if ( pPrev && (pPrev->isPageOrColBreak() || (pPrev->getPosArray().size() <= pPrev->getCharNum())) ) // WPD-1535 prev line pos array check
				pLine = pPrev;
		}

		//OFF-15825 pLine==BrNULL�� ��� ���� ��ü �������ϴ� �ڵ� ����
		if ( pLine )
		{
#ifndef	BWP_EDITOR
#ifdef RENDERING_WITH_BORATHREAD
			if(!pLine)
#endif //RENDERING_WITH_BORATHREAD
			{
				CPage *pPage = getPageArray()->getPage(nPage);
				if ( pPage )
				{
					CLine *pTmpLine = pPage->getFirstLine();
					if ( pTmpLine )
						pLine = pTmpLine;
				}
			}
			// Filter���� ���� line�� base position�� �����ϴ� ��찡 �־ �ٽ� �ѹ� check�Ͽ� arrange�� ����.
			if ( pLine )	pLine = pLine->getFirstDirtyLine();
#endif //BWP_EDITOR

#ifdef REFLOW_SIMPLE_TEXT_EDITOR
			if ( getDocType()!=BORA_DOCTYPE_ASCI || pLine==BrNULL || !pLine->isDirty() )
#endif // REFLOW_SIMPLE_TEXT_EDITOR
				CTextProc::arrangeMarkingLines(this, pLine, BrNULL);
		}
		// DOC, HWP�� ������ ������ page�� �а� �� ���� ������ ó������ arrange�� �ʿ䰡 ������...
		// Header, Footer���� ���� ��...
#ifdef	BWP_EDITOR
		if ( isNeedArrangeFromFirst() && isViewPrintMode() )	{
#else //BWP_EDITOR
		if ( isNeedArrangeFromFirst()/* && isFinishLoading()*/)	{
#endif //BWP_EDITOR
			setIgnoreFootnoteArrange(BrFALSE);
			setDirtyPage(1);
			setNeedArrangeFromFirst(BrFALSE);
			setFinishArrange(BrFALSE);
		}

		if ( nPgNum > getTotalPage() )
			setCurLastReadPage(getTotalPage());
		else
			setCurLastReadPage(nPgNum);

		setArrangeDuringImport(BrFALSE);

#ifdef	BWP_EDITOR
		if (isViewPrintMode() )
		{
			getCmdEngine()->setWorkOrgCoord(getPageArray(), 1);
			getCmdEngine()->setDocEndCoord();
		}
#endif	// BWP_EDITOR
	}

	m_MemoEventManager->chkArrangeForMemoFrame(BrTRUE);

	//if ( isFinishLoading() )
	//{
	//	int nTmp = BrGetElapsedTime(nGStartTime);
	//	BTrace("Total Reading Time [ %d ]", nTmp);
	//}
		return bRet;
	} PO_THREAD_CATCH_BLOCK {

		if(shorten_text_frame_post_processor::callstack_locked > 0)
			std::atomic_fetch_sub(&shorten_text_frame_post_processor::callstack_locked, 1); // IMPORTANT!
	} PO_THREAD_END
	return false;
}


/*
BrBOOL BoraDoc::doExport(BString &fileName, int nDocType)
{
	BrBOOL bRet = BrFALSE;


	switch (nDocType)
	{
	case BORA_DOCTYPE_DOC:
		bRet = doExportDoc(fileName);
		break;

	case BORA_DOCTYPE_ASCI:
		bRet = doExportText(fileName);
		break;
	}

	if (bRet)
		m_bModified = BrFALSE;     // back to unmodified

	return bRet;
}
*/

/*
BrBOOL BoraDoc::doExportText(BString &fileName)
{
	//ihwa BFile *file = BrNEW BFile(fileName);

	CLine *pStartLine, *pTmpLine;
    CCharSetArray *pLinkArray;
	CCharSet *pLink;
	BrWORD wCode;
    int nSize;	// , nCount = 0;
	// BrLPSTR pStr = BrNULL;

    pStartLine = getFirstLine();
    pTmpLine = pStartLine;

    //ihwa if (file->open (PVFM_WRITEONLY | PVFM_CREATE))
	{
#ifndef MIZI2
		// unicode file header
		//ihwa file->putch(0xff);
		//ihwa file->putch(0xfe);
#endif
		while (pTmpLine)
		{
			// get node array
			pLinkArray = pTmpLine->getCharSetArray();
			ASSERT_VALID(pLinkArray);
			nSize = pLinkArray->size();
			pLink = (CCharSet *)pLinkArray->data();

			for (int i = 0; i < nSize; i++)
			{
				ASSERT(pLink);
				ASSERT(pLinkArray->getCharSet(i) == pLink);

				if (!pLink)
					break;
#ifdef MIZI2
				if (pLink->isTextLink())
				{
					wCode = pLink->m_wCode;
					if (ASCII_CODE_CR == wCode)
					{
						file->putch(0x0d);
						file->putch(0x0a);
					}
					else
					{
						BChar	ch(wCode);
						BString	txt(ch);
						QBString ctxt = txt.local8Bit();
						const char *pTxt = (const char *)ctxt;
						while ( *pTxt )
							file->putch(*pTxt++);
					}
				}
#else
				if (pLink->isAnchorLink())
				{
					//ihwa file->putch(0);
					//ihwa file->putch(0);
				}
				else if (pLink->isTextLink())
				{
					wCode = pLink->m_wCode;
					if (ASCII_CODE_CR == wCode)
					{
						//ihwa file->putch(0x0d);
						//ihwa file->putch(0);
						//ihwa file->putch(0x0a);
						//ihwa ->putch(0);
					}
					else
					{
						//ihwa file->putch(BrLOBYTE(wCode));
						//ihwa file->putch(BrHIBYTE(wCode));
					}
				}
#endif
				pLink++;
			}

			pTmpLine = pTmpLine->getNext();
		}//while

		//ihwa file->close ();
		//ihwa BrDELETE file;

		return BrTRUE;
	}
	//ihwa else
	{
		//ihwa BrDELETE file;
		return BrFALSE;
	}
}
*/

BString BoraDoc::getNameFromDoc()
{
	BString name;
	CLine *pStartLine;
    CCharSetArray *pLinkArray;
	CCharSet *pLink;
	BrWORD wCode;
    int nSize;

    pStartLine = getFirstLine();
	if (pStartLine)
	{
		pLinkArray = pStartLine->getCharSetArray();
		ASSERT_VALID(pLinkArray);
		nSize = pLinkArray->size();
		pLink = (CCharSet *)pLinkArray->data();

		for (int i = 0; i < nSize; i++)
		{
			ASSERT(pLink);
			ASSERT(pLinkArray->getCharSet(i) == pLink);

			if (!pLink)	break;

			if (pLink->isTextLink())
			{
				wCode = pLink->m_wCode;
				if (ASCII_CODE_CR != wCode)
				{
					BChar	ch(wCode);
					BString	txt(ch);
//					QBString ctxt = txt.local8Bit();
					name.append(txt);
				}
			}
			pLink++;
		}
	}

	BString pt = name.simplifyWhiteSpace();
//	int i = pt.find( ' ' );
	BString docname = pt;
//	if (i > 0)
//	    docname = name.left( i );
	// remove "." at the beginning
	while( docname.startsWith( "." ) )
	    docname = docname.mid( 1 );
	for (uint ii=0; ii<docname.length (); ii++)
	{
		if (docname.at (ii) == BChar('/')) docname.replace (ii, 1, "_" );
		if (docname.at (ii) == BChar(' ')) docname.replace (ii, 1, "_" );
	}

	if ( docname.length() > 12 )
	    docname = docname.left(12);
	if ( docname.isEmpty() )
	    docname = "Untitled";

	return docname;
}

BString BoraDoc::getNewFileName()
{
	BString szDir;

	return szDir;

	//jyoh comm
	/*
	BString szDir, szName, szExt, szFileName;

	BrConfig	config;
	config.load("word");

	szDir = BrEnv::documentDir();
	if (config.readEntry  ("FileOptions", "SaveTo", 0) == 1)	//
	{
		szDir += "HDD/";
	}

	szName = getNameFromDoc();

	switch (config.readEntry  ("FileOptions", "FileType", 0))
	{
	case 0: szExt = ".doc"; break;
	case 1: szExt = ".bwp"; break;
	case 2: szExt = ".txt"; break;
	}

	szFileName = szDir + szName + szExt;

	QDir	dir;
	int		i = 1;
	BString num;
	while (dir.exists(szFileName))
	{
		num.sprintf ("(%d)", i++);
		szFileName = szDir + szName + num + szExt;
	}

	return szFileName;
	*/
}
CPagination* BoraDoc::getPagination()    {
	return m_Pagination;
}
CCmdEngine* BoraDoc::getCmdEngine()  {
	return m_CmdEngine;
}

CPageLayoutEngine* BoraDoc::getPageLayoutEngine()  {
	return m_PageLayoutEngine;
}
CHeaderFooterEngine* BoraDoc::getHeaderFooterEngine()  {
	return m_HeaderFooterEngine;
}
//#ifdef	NOT_USED	// 18-DEC-2001
/*ihwa
void BoraDoc::AddClipboardImage(BitmapPtr pBitmap)
{
	if(pBitmap)
	{
		CBoraImage *pBora = BrNEW CBoraImage();
		//ihwa PmPixmap *pPix = BrNEW PmPixmap;
		//ihwa pPix->setBitmap(pBitmap);
		//ihwa pBora->SetImage(pPix);

		CImageObject *pImg = createImgObject();

		int nID = m_ImagePool->AddImageObject(pBora, eImage_DIB, BrTRUE);
		if (nID)
			pImg->SetRawID(nID);

		m_CmdEngine->placeImage(pImg, BrNULL, BrNULL, BrNULL);
	}
}
*/
//#endif

#ifndef BWP_EDITOR
/*
CImageObject *BoraDoc::AddImageObject(CBoraImage *pImage, IMAGEOPENSTRUCT &io)
{
	CImageObject *pImg = createImgObject();

	int nID = m_ImagePool->AddImageObject(pImage, eImage_DIB);
	if (nID)
	{
		pImg->SetDibID( nID );
	}

	if( BrStrLen(io.szPath) )
		pImg->SetPath( io.szPath );
	if (io.tColor != -1)
		pImg->SetTransparentColor(io.tColor);

	// ������ ������ ��������

	if( !io.pRaw )
		return BrNULL;

	//ASSERT(io.hRaw);
	if (io.pRaw) && !io.bLinkImage)
	{
		nID = m_ImagePool->AddImageObject(io.pRaw, io.nImageType? io.nImageType : CImageReader::GetImageType(io.szPath), BrFALSE);
		pImg->SetRawID(nID);
	}

	return pImg;
*/
#else
CFrame *BoraDoc::AddImageObject(BString szFileName)
{
	CFrame *pImgFrame = createImgObject();
	if( pImgFrame )
		return BrNULL;

	BrImageFileLoader loader(BrNULL,LOADER_BWP, 0, szFileName,color_auto);
	PrBitmap image;
	image.setRawBitmapLoader(&loader);
	PrBitmap *pImage = BrNEW PrBitmap;
	image.loadDisplayImage(BrNULL, BrNULL, BrFALSE, 0 , 0, 100, pImage);

	BrImageAttr* pImgAttr = pImgFrame->getBorder()->getImageAttr();
	BrAutoChar temp = CUtil::convertBStringToChar(&szFileName, CP_UTF8);
	 BrINT nImageType = PrBitmap::getImageTypeFile((char *)temp.get());
	pImgAttr->SetImageType(nImageType);

	if( szFileName.length()>0 )
		pImgAttr->SetPath( szFileName );

	BrCOLORREF tColor;
	pImage->getRawBitmap()->getData(BrNULL, &tColor );
	if (tColor != -1)
		pImgAttr->SetTransparentColor(tColor);

	if (pImage)
	{
		BrBOOL bAddedImage = BrFALSE;
		BrINT nID = m_ImagePool->AddImageObject(pImage, nImageType, bAddedImage, BrFALSE);
		if ( !bAddedImage )
			BR_SAFE_DELETE(pImage);
		pImgAttr->SetRawID(nID);
	}

	return pImgFrame;
}
#endif // #ifdef BWP_EDITOR

 BrINT BoraDoc::getDocVideoTotalCnt(BrBYTE bPageType)
 {//online video
	 if(!m_aVideoManager)
		 return 0;
	 BrINT nTotalVideoCount = 0;
	 BrINT nTotalPg = 0;
#ifdef SUPPORT_WEARABLE_DEVICE
	 if(getSummaryData())
		nTotalPg = getSummaryData()->getSlideCnt();

	 for(int n = 1 ; n< nTotalPg; n++)
	 	 nTotalVideoCount += getCurPgVideoCnt(n);
#endif
	 return nTotalVideoCount;
 }
 //video Manager ����.. - thumbnail ���� �� video info ����
 BrINT BoraDoc::getCurPgVideoCnt(BrINT nPgNum,BrBYTE bPageType)
 {
	 if(!m_aVideoManager)
		 return 0;

	 if(!nPgNum)
		 return 0;
#ifdef SUPPORT_WEARABLE_DEVICE
	 //int nTotalPg = m_aVideoManager->size(); //pgnum�� 1���� ���� �̳�, array �� 0���� ����
	 BrINT nTotalVideoCount = 0;
	 BrINT nNormalVideoCnt = 0,nMasterVideoCnt = 0 , nLayoutVideoCnt = 0;
	 BrINT nPgSz = 	 m_aVideoManager->size() ;

	 if(nPgSz)
	 {
		 BArray<LPBrBwpVideoInfo>* pCurPgVideoInfoList = m_aVideoManager->at(nPgNum-1);
		 if(pCurPgVideoInfoList)
		 {
			 BrINT nSize = pCurPgVideoInfoList->size();
			 BrINT nCurPgNum = theBWordDoc->getCmdEngine()->getCurPageNum();
			 CPage *pCurPage = theBWordDoc->getPageArray()->getPage(nCurPgNum);

			 if(pCurPage)
			 {

#ifdef SEPERATE_MASTERID
				 BrUINT nCurMstID = pCurPage->getMasterID();
				 BrUINT nCurLayoutID = pCurPage->getLayoutID();
#else //SEPERATE_MASTERID
				 BrINT32 nCurMasterLayoutID = pCurPage->getMasterID();
				 BrINT nCurMstID = nCurMasterLayoutID & 0x0000ffff;
				 BrINT nCurLayoutID = nCurMasterLayoutID & 0xffff0000;
#endif //SEPERATE_MASTERID

				 for(BrINT nCnt = 0 ; nCnt <nSize; nCnt++)
				 {
					 LPBrBwpVideoInfo pVideoInfo = pCurPgVideoInfoList->at(nCnt);
					 if(pVideoInfo)
					 {
						 CPage *pVideoFramePage = pVideoInfo->pVideoFrame->getPage();

						 if(pVideoFramePage)
						 {
							 BrBYTE bVideoType = SLIDE_PAGE;//pVideoInfo->bPageType;
							 BrINT32 nMasterLayoutID = pVideoFramePage->getMasterID();//pVideoInfo->nMasterLayoutID;
#ifdef SEPERATE_MASTERID
							 BrUINT nMasterID = pVideoFramePage->getMasterID();
							 BrUINT nLayoutID = pVideoFramePage->getLayoutID();
#else //SEPERATE_MASTERID
							 BrINT nMasterID = nMasterLayoutID & 0x0000ffff;
							 BrINT nLayoutID = nMasterLayoutID & 0xffff0000;
#endif //SEPERATE_MASTERID


							 switch(bVideoType)
							 {
							 case MASTER_PAGE:
								 if(nCurMstID == nMasterID)
									 nMasterVideoCnt++;
								 break;
							 case LAYOUT_PAGE:
								 if(nCurLayoutID == nLayoutID)
									 nLayoutVideoCnt++;
								 break;
							 case SLIDE_PAGE:
								 nNormalVideoCnt++;
								 break;
							 }
						 }
					 }
				 }

				 switch(bPageType)
				 {
				 case MASTER_PAGE:
					 nTotalVideoCount = nMasterVideoCnt + nLayoutVideoCnt + nNormalVideoCnt;
					 break;
				 case LAYOUT_PAGE:
					 nTotalVideoCount = nMasterVideoCnt + nLayoutVideoCnt;
					 break;
				 case SLIDE_PAGE:
					 nTotalVideoCount = nNormalVideoCnt;
					 break;
				 default://slideshow
					 nTotalVideoCount = nMasterVideoCnt + nLayoutVideoCnt + nNormalVideoCnt;
					 break;
				 }
				 return nTotalVideoCount;
			 }
		 }
	 }
	 else
		 return 0;
#endif

	 return 0;
 }

 BrINT BoraDoc::RemoveVideoFrame(CFrame *pVideoFrame)
 {
#ifdef SUPPORT_WEARABLE_DEVICE
	 if(!pVideoFrame || !m_aVideoManager)
		 return 0;

	 if(pVideoFrame->getMediaType() == BR_MEDIA_NONE)
		 return 0;

	 CPage *pVideoPg = pVideoFrame->getPage();
	 if(pVideoPg)
	 {
		 BrINT nPgNum = pVideoPg->getPageNum();

		 if(nPgNum)
		 {
			 AnimationComponentMgr* pACmgr = pVideoPg->getAnimationCMgr();
			 if(pACmgr)
			 {
				 BrMediaInfo* pMediaInfo = pVideoFrame->getMediaInfo();
				 if(pMediaInfo)
					 pACmgr->RemoveMeidaNode(pMediaInfo->ACNode());
			 }

			 BrINT nPgIdx = nPgNum -1;
			 BArray<LPBrBwpVideoInfo>* pPgVideoList = m_aVideoManager->at(nPgIdx);
			 if(pPgVideoList)
			 {
				 BrINT nCnt = 0,nSz = pPgVideoList->size(),nRmIdx = -1;

				 if(nSz)
				 {
					 BrBwpVideoInfo* pVideoInfo = pPgVideoList->at(nCnt++);
					 if(pVideoInfo)
					 {
						 while(pVideoInfo)
						 {
							 if(pVideoInfo->pVideoFrame == pVideoFrame)
								 nRmIdx = pVideoInfo->nMgrIdx;
							 else
							 {
								 if(nRmIdx != -1  && (nRmIdx < pVideoInfo->nMgrIdx))
									 pVideoInfo->nMgrIdx--;
							 }

							 if(nCnt< nSz)
								 pVideoInfo = pPgVideoList->at(nCnt++);
							 else
								 pVideoInfo = BrNULL;
						 }

						 if(nRmIdx != -1)
						 {
							 pVideoInfo = pPgVideoList->at(nRmIdx);
							 pVideoInfo->pVideoFrame = BrNULL;
							 BR_SAFE_FREE(pVideoInfo);
							 pPgVideoList->RemoveAt(nRmIdx);
						 }
					 }
					 else
						 return 0;
				 }
				 else
					 return 0;
			 }
			 else
				 return 0;
		 }
		 else
			 return 0;
		 // MediaInfo ���� ����
	 }
	 else
		 return 0;
#endif//SUPPORT_WEARABLE_DEVICE
	 return 1;
 }

 void BoraDoc::AddVideoFrame(CFrame *pVideoFrame)
 {
#ifdef SUPPORT_WEARABLE_DEVICE
	 if(!pVideoFrame || !pVideoFrame->isSupportMedia() )
		 return;

	 if(!(pVideoFrame->getMediaType() == BR_MEDIA_VIDEO || pVideoFrame->getMediaType() == BR_MEDIA_AUDIO))
		 return;


	 CPage *pPage = pVideoFrame->getPage() ;
	 if(!pPage)
		 return;

	 if(pPage)
	 {
		 BrMediaInfo* pMediaInfo = pVideoFrame->getMediaInfo();
		 AnimationComponentMgr* pACmgr = pPage->getAnimationCMgr();
		 if(pACmgr && pMediaInfo)
			 pACmgr->AddMeidaNode(pMediaInfo->ACNode());
	 }

	 if(!m_aVideoManager)
		 m_aVideoManager = BrNEW BArray<BArray<LPBrBwpVideoInfo>*>;

	 BrINT nPgNum = pPage->getPageNum();
	 BrINT nPgIdx = nPgNum-1;
	 if(nPgIdx <= 0)
		 nPgIdx = 0;

	 BArray<LPBrBwpVideoInfo>* pPgVideoList = BrNULL;
	 BrINT nVideoPgCnt = m_aVideoManager->size();

	 BrBwpVideoInfo* pNewVideoInfo = (LPBrBwpVideoInfo)BrMalloc(sizeof(BrBwpVideoInfo));
	 pNewVideoInfo->pVideoFrame = pVideoFrame;

	 if(nVideoPgCnt > nPgIdx)
	 {
		pPgVideoList = m_aVideoManager->at(nPgIdx);//[nPgIdx];
		if(pPgVideoList)
		{
			pNewVideoInfo->nMgrIdx = pPgVideoList->size();
			pPgVideoList->Add(pNewVideoInfo);

		}
		else
		{
			pPgVideoList =  BrNEW BArray<LPBrBwpVideoInfo>;
			pNewVideoInfo->nMgrIdx = 0;
			pPgVideoList->Add(pNewVideoInfo);
			m_aVideoManager->InsertAt(nPgIdx, pPgVideoList);
		}
		return;
	 }
	 else
	 {
		 if(nPgNum)
		 {
			 if(nVideoPgCnt != nPgNum)
			 {
				 for(BrINT nCnt = nVideoPgCnt ; nVideoPgCnt < nPgIdx ; nVideoPgCnt++)
				 {
					 pPgVideoList =  BrNEW BArray<LPBrBwpVideoInfo>;
					 m_aVideoManager->InsertAt(nCnt, pPgVideoList);
				 }
			 }

			 pPgVideoList =  BrNEW BArray<LPBrBwpVideoInfo>;
			 pNewVideoInfo->nMgrIdx = pPgVideoList->size();
			 pPgVideoList->Add(pNewVideoInfo);
			 m_aVideoManager->InsertAt(nPgIdx, pPgVideoList);
			 return;
		 }
	 }
	 BR_SAFE_FREE(pNewVideoInfo);
#endif
 }

#ifdef IMPORT_HTML
BrBOOL BoraDoc::makeTileBitmap( BrLPCTSTR lpPath, int color, int dwImgID)
{
	int imgID = 0;
	CImageArray *pArray = getImageArray();

	CHString temp=lpPath;
	CHString tempLocal;

  	if (dwImgID == 0)
  	{
		if (lpPath==BrNULL)
  		{
  			setWallPaperFlag(OFF);
  	  		m_PaperColor = color;
			if (m_nWallID != 0)
			{
				pArray->Remove(m_nWallID, true);
				m_nWallID = 0;
			}
	  	  	return true;
  	  	}

		BrBOOL b=BrTRUE;
		if( temp.Find( _T("://") ) !=-1 )
		{
			return BrFALSE;
			//CHtmlUtil::URLDownloadToCacheFile( BrNULL , temp , tempLocal.GetBuffer( MAX_PATH ) , URLOSTRM_GETNEWESTVERSION , 0 ,BrNULL );
			//tempLocal.ReleaseBuffer();
		}
		else
			tempLocal = temp;

		if( tempLocal.IsEmpty() )
		{
			return BrFALSE;
		}


		BrHANDLE hDIB = 0;//CImageReader::LoadRawHandle( tempLocal );
		if (hDIB == 0)
			return false;

/*		if (m_strWallPaperName.Size() != 0 && m_strWallPaperName.CompareNoCase(temp) != 0)
		{
			if (m_cTile)
				GlobalFree(m_cTile);
			m_cTile = BrNULL;
*/			if (m_nWallID != 0)
			{
				pArray->Remove(m_nWallID, true);
				m_nWallID = 0;
			}
//		}

/*		int nType = CImageReader::GetImageType(tempLocal);
		if (nType == eImage_NONE)
			nType = CImageReader::GetImageTypeFromRaw(hDIB);
		imgID = pArray->AddImageObject(hDIB, nType, BrTRUE);
  */	}
	else
		imgID = dwImgID;

	//m_strWallPaperName = temp;
  	m_nWallID = imgID;
	setWallPaperFlag(ON);
	return true;
}
#endif

CLine *BoraDoc::getFirstLine()
{
	CPageArray  *pPageArray = getEditingPageArray();
	CPage  *pPage=BrNULL;
	CLine  *pLine=BrNULL;

	int   nTotal = pPageArray->GetSize();
	for ( int nNum = 1; nNum <= nTotal; nNum++ )
	{
		pPage = pPageArray->getPage(nNum);

		if( pPage==BrNULL )  return BrNULL;
		pLine = pPage->getFirstLine();
		if( pLine!=BrNULL )   break;
	}

	return pLine;
}

CFrame *BoraDoc::getFirstFrame()
{
	CPageArray  *pPageArray = getEditingPageArray();
	CPage	*pPage=BrNULL;
	CFrame	*pFrame=BrNULL;

	int   nTotal = pPageArray->GetSize();
	for ( int nNum = 1; nNum <= nTotal; nNum++ )
	{
		pPage = pPageArray->getPage(nNum);

		if( pPage==BrNULL )  return BrNULL;
		pFrame = pPage->getFirstBasic();
		if( pFrame!=BrNULL )   break;
	}

	return pFrame;
}

CLine *BoraDoc::getLastLine()
{
	CPageArray  *pPageArray = getEditingPageArray();
	CPage  *pPage=BrNULL;
	CLine  *pLine=BrNULL;

	// [XPD-28050]
	if (pPageArray->GetSize() == 0)
		return BrNULL;

	pPage = pPageArray->GetLast();
	if(pPage == BrNULL)
		return BrNULL;

	pLine = pPage->getLastLine();
	if(!pLine)
	{
		BrINT	nPgNum = pPage->getPageNum();
		while ( --nPgNum>0 )
		{
			pPage = pPageArray->getPage(nPgNum);
			if ( pPage )	pLine = pPage->getLastLine();
			if ( pLine )	break;
		}
	}

	return pLine;
}

#ifdef	BWP_EDITOR
CLine *BoraDoc::getFirstLineOfNormalPage()
{
	CPageArray  *pPageArray = getPageArray();
	CPage  *pPage=BrNULL;
	CLine  *pLine=BrNULL;

	int   nTotal = pPageArray->GetSize();
	for ( int nNum = 1; nNum <= nTotal; nNum++ )
	{
		pPage = pPageArray->getPage(nNum);

		if( pPage==BrNULL )  return BrNULL;
		pLine = pPage->getFirstLine();
		if( pLine!=BrNULL )   break;
	}

	return pLine;
}
#endif

#ifdef	BWP_EDITOR
void BoraDoc::setModifiedFlag(BrBOOL bModified)
{
#ifdef SUPPORT_WATERMARK_FOR_HWP_ODT
	if ( isMakingHWPWatermark() )	return;
#endif // SUPPORT_WATERMARK_FOR_HWP_ODT

	if (m_bThumbnailDraw)
		return;

    if (bModified)
  		theBWordDoc->SetTempSaveUndoCount(0);

	// SetModifiedFlag(bModified);
	BrBOOL bPreModifined = DocFlagEx.flag.m_bModified;

	DocFlagEx.flag.m_bModified = bModified;

	if( bPreModifined == BrFALSE && DocFlagEx.flag.m_bModified == BrTRUE)
		SendBaseResultCallback(0, Bora_doc_modified, 0, g_pUIPROCESS_CBFUNC, BrNULL, BrTRUE);

	SetTempModified(bModified);
}
#endif

BrBOOL BoraDoc::getScrStartEndPageNum(int &nSPgNum, int &nEPgNum)
{
	//--- default
    nSPgNum=1;
	nEPgNum=1;

    CCmdEngine *pCmdEngine;

    pCmdEngine = m_Caret->getCmdEngine();
    ASSERT_VALID(pCmdEngine);
    if( pCmdEngine ) {
		nSPgNum = pCmdEngine->getScrStartPage();
        nEPgNum = pCmdEngine->getScrEndPage();
	}

    return BrTRUE;
}

int BoraDoc::getDrawPageNum(int nPgNum)
{
    int nDrawNum=0;

    if( getEditMasterType()!=EDIT_MASTER_NONE )
    {
        nDrawNum = nPgNum;
    }
    else
    {
        if( nPgNum >= 1 &&
            nPgNum <= (int)m_PageArray->GetSize() )
        {
            nDrawNum = m_Pagination->getDrawPageNum(nPgNum, m_PageArray->GetSize());
        }
    }
    return nDrawNum;
}

CGuideMgr* BoraDoc::getGuideMgr()
{
	return m_GuideMgr;
}
CPageArray* BoraDoc::getPageArray()	   {
	return m_PageArray;
}
CPageArray* BoraDoc::getMstPageArray()	   {
	return m_MstPageArray;
}

CBatangPageArray* BoraDoc::getBatangPageArray() {
	return m_BatangPageArray;
}

CPageArray* BoraDoc::getWebPageArray()	  {
	return m_WebPageArray;
}	// for speed

CPageArray*	BoraDoc::getEditingPageArray()
{
#ifdef	BWP_EDITOR
	if ( BrFALSE == theBWordDoc->isViewPrintMode() )		// for speed
		return m_WebPageArray;
	else if ( isEditMasterPage() )
	{
		int nMasterIndex = -1, nPageNum = -1;
		getMasterIndexPageNum(&nMasterIndex, &nPageNum);
		if (nMasterIndex < 0 || nMasterIndex > m_MasterLayoutArray.size())
		{
			//BRTHREAD_ASSERT(0);
			nMasterIndex = 0;
		}
		return m_MasterLayoutArray.at(nMasterIndex);
	}
	else if( isEditMasterHandout() )
	{
		return m_HandoutMaster->GetPageArray();
	}
	else if (isEditMasterNote()) //POD-2069
	{
		return m_PPTNoteMaster->GetNoteMasterPageArray();
	}
	else
		return m_PageArray;
#else
	if (isEditMasterPage())
		return &m_MstPageArray;
	else
		return &m_PageArray;
#endif	//BWP_EDITOR
}

int	BoraDoc::getMasterTotalPageNum()
{
	int nTotalCnt = 0;

	for (int i = 0 ; i < m_MasterLayoutArray.size(); i++) {
		nTotalCnt += m_MasterLayoutArray.at(i)->size();
	}

	return nTotalCnt;
}
int	BoraDoc::getTotalPage() {
	return m_PageArray->GetSize();
}
int BoraDoc::getEditingTotalPage()
{
#ifdef	BWP_EDITOR
	if ( BrFALSE == theBWordDoc->isViewPrintMode()  )
		return m_WebPageArray->GetSize();
	else if ( isEditMasterPage() )
	{
		if (m_MasterLayoutArray.size() == 0)
		{
			BRTHREAD_ASSERT(0);
			return 0;
		}
		int nTotalCnt = 0;
		for (int i = 0 ; i < m_MasterLayoutArray.size(); i++) {
			nTotalCnt += m_MasterLayoutArray.at(i)->size();
		}
		return nTotalCnt;
	}
	else if( isEditMasterHandout() )
		return 1;
	else if( isEditMasterNote() )
		return 1;
	else
		return m_PageArray->GetSize();
#else
	// if (isViewWebMode())		// for speed
	//	return m_WebPageArray->GetSize();
	// else if (isEditMasterPage())
	if (isEditMasterPage())
		return m_MstPageArray->GetSize();
	else
		return m_PageArray->GetSize();
#endif	//BWP_EDITOR
}

#ifdef USE_THEME
int	BoraDoc::getThemeID(CPage *pPage)
{
	if (EDITOR_PPT == getBWPEngineMode())
	{
		if(pPage == BrNULL)
		{
			if(isPageDrawing()) //������ ����� ���� üũ. ������ ������϶� �׷����� �ִ� �������� �׸����̵� �����;���.
				return getGraphicStyle()->getCurThemeID();
			else
				pPage = m_CmdEngine->getCurrentPage();
		}

		if(pPage && pPage->getRefThemeID())
		{
			return pPage->getRefThemeID();
		}
	}

	return 1;
}
#endif //USE_THEME

int BoraDoc::getDrawPageNumString(int nPageNum, BrLPWSTR lpBuf, BrBOOL bBefore, BrBOOL bAfter)
{
	int     nCount=0;
	int     nDrawNum;

	if( lpBuf != BrNULL )  {
		nDrawNum = getDrawPageNum(nPageNum);
		if(nDrawNum > 0)
		{
			CPageNumItem*  pItem = m_Pagination->getItemOfCurPage(nPageNum);
			if( pItem != BrNULL )
				nCount = pItem->makeItemString(lpBuf, nDrawNum, bBefore, bAfter);
		}
	}
	return nCount;
}

int BoraDoc::getDocTypeFromName(BString &fileName)
{
	//only for kind of word format document

#ifdef USE_HWP_CONTROL
	if(BIHANDLE_BRCONTEXT.m_GeneralValue.bSyncMode)
	{
		if(getDocExt() == BORA_EXT_HWP)
			return BORA_DOCTYPE_HWP;
		else if(getDocExt() == BORA_EXT_HTML)
		{
			DocFlagEx.flag.m_bSMSDoc = BrFALSE;
			return BORA_DOCTYPE_HTML;
		}
		else if(getDocExt() == BORA_EXT_ODT)
			return BORA_DOCTYPE_ODT;
		else
			return BORA_DOCTYPE_ASCI;
	}
#endif //USE_HWP_CONTROL

	//BString ext = fileName.Right(4);
	int index = fileName.findRev('.');
#ifdef SUPPORT_GET_FILE_EXTENSION_BY_EXTERNAL
	BrCHAR strExt[BRMAX_EXTENSION_LENGTH];
	strExt[0] = 0;
	if(0 < BGetDocumentFileExtension(strExt))
		index = 0;
#endif

	if ( index == -1 )
    {
		BRCONTEXT;
		switch(getDocExt())
		{
		case BORA_EXT_DOC:
            return BORA_DOCTYPE_DOC;
		case BORA_EXT_DOCX:
			return BORA_DOCTYPE_DOCX;
		case BORA_EXT_PPT:
            return BORA_DOCTYPE_PPT;
		case BORA_EXT_PPTX:
			return BORA_DOCTYPE_PPTX;
		case BORA_EXT_ODT:
			return BORA_DOCTYPE_ODT;
		case BORA_EXT_ODS:
			return BORA_DOCTYPE_ODS;
		case BORA_EXT_ODP:
			return BORA_DOCTYPE_ODP;
        default:
            return BORA_DOCTYPE_ASCI;
        }
    }

// const char *pTmp = fileName.ascii();
	BString ext;
#ifdef SUPPORT_GET_FILE_EXTENSION_BY_EXTERNAL
	if(0 != strExt[0])
		ext = strExt;
	else
#endif
	ext = fileName.right(fileName.length() - index).lower();

	if (ext.compare(".bwp") == 0)
		return BORA_DOCTYPE_BWP;
#ifdef IMPORT_HWP
	if (ext.compare(".hwp") == 0 || ext.compare(".hml") == 0)
		return BORA_DOCTYPE_HWP;
#ifdef IMPORT_HWX
	if (ext.compare(".hwx") == 0)
		return BORA_DOCTYPE_HWP;
#endif //IMPORT_HWX
#ifdef IMPORT_HWT
	if (ext.compare(".hwt") == 0)
		return BORA_DOCTYPE_HWP;
#endif //IMPORT_HWT
#ifdef IMPORT_HWPX
	if (ext.compare(".hwpx") == 0)
		return BORA_DOCTYPE_HWP;
#endif //IMPORT_HWPX
#endif //IMPORT_HWP
#ifdef IMPORT_GUL
	if (ext.compare(".gul") == 0)
		return BORA_DOCTYPE_GUL;
#endif
#ifdef IMPORT_DOC
	if (ext.compare(".doc")  == 0)
		return BORA_DOCTYPE_DOC;
	if (ext.compare(".dot") == 0) {
		setTemplateDocument(BrTRUE);
		return BORA_DOCTYPE_DOC;
	}
#endif
#ifdef IMPORT_DOCX
	if (ext.compare(".docx") == 0 )
		return BORA_DOCTYPE_DOCX;
	if (ext.compare(".dotx") == 0) {
		setTemplateDocument(BrTRUE);
		return BORA_DOCTYPE_DOCX;
	}
	if (ext.compare(".docm") == 0) {
		setTemplateDocument(BrTRUE);
		return BORA_DOCTYPE_DOCX;
	}
#endif //IMPORT_DOCX
	if (ext.compare(".txt") == 0)
		return BORA_DOCTYPE_ASCI;
	if( ext.compare(".mht")==0 ||ext.compare(".mhtml")==0 )
		return BORA_DOCTYPE_MHT;
	if( ext.compare(".sms")==0 )	{
		DocFlagEx.flag.m_bSMSDoc = BrTRUE;
		return BORA_DOCTYPE_HTML;
	}
#ifdef FOR_BMV
	if (ext.compare(".bmv") == 0)
		return DOCTYPE_BMV;
#endif
#ifdef IMPORT_RTF
	if( ext.compare(".rtf") == 0)
		return BORA_DOCTYPE_RTF;
#endif
#ifdef IMPORT_ODT
	if( ext.compare(".odt") == 0)
		return BORA_DOCTYPE_ODT;
#endif
#ifdef IMPORT_ODS
	if( ext.compare(".ods") == 0)
		return BORA_DOCTYPE_ODS;
#endif
#ifdef IMPORT_ODP
	if( ext.lower().compare(".odp") == 0)
		return BORA_DOCTYPE_ODP;
#endif
	if (ext.compare(".htm") == 0 || ext.compare(".html") == 0 ||
		fileName.find/*FindOneOf*/(szHttp) != -1 || fileName.find("www.") != -1)	{
			DocFlagEx.flag.m_bSMSDoc = BrFALSE;
			return BORA_DOCTYPE_HTML;
	}

	return BORA_DOCTYPE_ASCI;
}

BrBOOL BoraDoc::hasSpecialData()
{
	if (m_TypesetInfo->getFootnoteTotalNum() > 0 || m_TypesetInfo->getEndnoteTotalNum() > 0 ||
        /*m_TypesetInfo->getBookMarkArray()->GetSize() > 0 ||*/ m_AFrameList->getFirst() ||
		m_AFrameList4HeaderFooter->getFirst() ||
		m_FieldArray->GetSize() > 1 ||
#ifdef USE_HWP_CONTROL
		getClickHereHandler()->item_count() > 1 ||
#endif //USE_HWP_CONTROL
		m_BulletArray->size() > 0 ||
		(m_pHeaderArray && m_pHeaderArray->size() > 0) ||
		(m_pFooterArray && m_pFooterArray->size() > 0) )
	{
		return BrTRUE;
	}
	else
	{
		return BrFALSE;
	}
}

BArray<CPageArray*>	BoraDoc::MakeCurMasterLyaout( BrINT nPageNumber)
{
	CPage* pCurPage = BrNULL;
	if (getPageArray())
		 pCurPage = getPageArray()->getPage(nPageNumber);

	if (pCurPage)
	{
#ifdef SEPERATE_MASTERID
		BrUINT nCurMasterID = pCurPage->getMasterID();
		BrUINT nCurLayoutID = pCurPage->getLayoutID();
#else //SEPERATE_MASTERID
		BrINT nCurMasterID = pCurPage->getMasterID() & 0x0000ffff ;
		BrINT nCurLayoutID = (pCurPage->getMasterID() & 0xffff0000) >> 16 ;
#endif //SEPERATE_MASTERID

		BArray<CPageArray*>* pSlideMasterArray = theBWordDoc->getMasterLayoutArray();		// 1) ������ �����̵� ������ �迭
		if (pSlideMasterArray && pSlideMasterArray->size() > 0)
		{
			CPageArray* pMasterArray = BrNULL;
			CPageArray* pCopyMasterArray = BrNULL;
			BArray<CPageArray*>* pCopyMasterLayoutArray = BrNEW BArray<CPageArray*>();

			for (BrINT i = 0 ; i < pSlideMasterArray->size() ; i++)
			{
				pMasterArray = pSlideMasterArray->at(i);
				if (pMasterArray)
				{
					pCopyMasterArray = BrNEW CPageArray(BrNULL, BrFALSE);
					pCopyMasterArray->SetDocument(pCurPage->getDocument());
					CPage* pCopyMasterPage = BrNULL;

					CPage* pMaster = pMasterArray->at(0);
					if (pMaster)
					{
#ifdef SEPERATE_MASTERID
						BrUINT nTempMasterID = pMaster->getMasterID();
#else //SEPERATE_MASTERID
						BrINT nTempMasterID = pMaster->getMasterID() & 0x0000ffff;
#endif //SEPERATE_MASTERID

						if (nTempMasterID == nCurMasterID)
						{
							CPage* pCopyMaster = pMaster->BrCopy(BrNULL);
							pCopyMaster->setPageArray(pCopyMasterArray);
							pCopyMasterArray->Add(pCopyMaster);								// 2) ���� �������� �����̵� ������

							BrINT nLayoutCount = pMasterArray->size();
							for(BrINT j = 0 ; j < nLayoutCount ; j++)
							{
								CPage* pLayout = pMasterArray->GetAt(j);
								if (pLayout)
								{
#ifdef SEPERATE_MASTERID
									BrUINT nTempLayoutID = pLayout->getLayoutID();
#else //SEPERATE_MASTERID
									BrINT nTempLayoutID = (pLayout->getMasterID() & 0xffff0000) >> 16 ;
#endif //SEPERATE_MASTERID

									if (nTempLayoutID  == nCurLayoutID)
									{
										CPage* pCopyLayout = pLayout->BrCopy(BrNULL);
										pCopyLayout->setPageArray(pCopyMasterArray);
										pCopyMasterArray->Add(pCopyLayout);					// 3) ���� �������� �����̵� ������ ���̾ƿ�

										pCopyMasterLayoutArray->Add(pCopyMasterArray);
										return *pCopyMasterLayoutArray;
									}
								}
							}
						}
					}
				}
			}
			BR_SAFE_DELETE(pCopyMasterLayoutArray);
		}
	}
	return BArray<CPageArray*>();
}

void	BoraDoc::ClearCurMasterLayout()
{
	if (m_pCurMasterLayoutArray)
	{
		CPageArray* pMasterArray = m_pCurMasterLayoutArray.at(0);
		if (pMasterArray)
		{
			//CPage* pMasterPage = pMasterArray->at(0);
			BrINT nArraySize = pMasterArray->size();
			if (nArraySize > 0 && pMasterArray)
			{
				for (BrINT j = nArraySize-1 ; j >= 0 ; j--)
				{
					CPage* pPage = (CPage *)pMasterArray->at(j);
					if (pPage)
						BrDELETE pPage;
				}
				pMasterArray->RemoveAll();
			}
		}
		BR_SAFE_DELETE(pMasterArray)
			m_pCurMasterLayoutArray.RemoveAll();
	}
}

//===================================================  html


#ifdef IMPORT_HTML
#ifdef USE_MIME
BString BoraDoc::decodeMime( BrLPCTSTR mhtPath )
{
	BString newPath;
	CMimeDec mime_dec;
	BrBOOL bRet = mime_dec.SetMhtFile( mhtPath );

	INCREASE_PROGRESS(5);
	CANCEL_LOAD_RETURN_PTR_EX1;

	if (!bRet)
		return newPath;

	CMimePart* pMain = mime_dec.GetMainPart();

	if( mime_dec.IsGood()  && pMain )
	{
		g_pHtml->m_TempValue.m_bMimeMode = true;

		bRet = mime_dec.SaveFile( BrNULL );

		mime_dec.ConvertHtmlCID();

		newPath = pMain->GetSaveFilePath();

		g_pHtml->m_TempValue.m_bMimeMode = false;
	}

	INCREASE_PROGRESS(10);
	CANCEL_LOAD_RETURN_PTR_EX1;

	return newPath;
}

BrBOOL BoraDoc::importMime_File( BrLPCTSTR mhtPath )
{
	CMimeDec* mime_dec = BrNEW CMimeDec();

	BrBOOL bRet = mime_dec->SetMhtFile( mhtPath );

	INCREASE_PROGRESS(5);
	CANCEL_LOAD_RETURN_PTR_EX1;

	if (!bRet){
		BrDELETE mime_dec;
		return false;
	}

	CMimePart* pMain = mime_dec->GetMainPart();

	if( mime_dec->IsGood()  && pMain )
	{
		g_pHtml->m_TempValue.m_bMimeMode = true;

		bRet = mime_dec->SaveFile( BrNULL );

		CWString strPath = pMain->GetSaveFilePath();
		g_pHtml->m_TempValue.m_bMimeMode = false;

		if( strPath.IsEmpty() )
		{
			BrDELETE mime_dec;
			return BrFALSE;
		}

#ifdef LOAD_ONE_PAGE_HTML
		m_pLoaderForHtml = BrNEW CHtmlLoader();
		m_pLoaderForHtml->m_pMimeDec = mime_dec;//�δ��� �޾� �ְ� ���߿� �������� �V���մϴ�.

		m_pPageForHtml =  m_pLoaderForHtml->loadFromFile( strPath, false);

		if (m_pPageForHtml == BrNULL)
		{
			SET_ERROR(kPoErrInternal, "");
			return BrFALSE;
		}

		m_pPageForHtml->m_nReadCnt = 0;

		// increase page width and height for HTML document
		increasePageHgtWidForHTML();

		BrBOOL bProtectUndo = g_pAppStatic->bProtectUndo;
		g_pAppStatic->bProtectUndo = true;
		BrBOOL rtCode = ((CHtmlPage*)m_pPageForHtml)->decodeToDoc(this);
		g_pAppStatic->bProtectUndo = bProtectUndo;

		// in case reading all html document
		if ( m_pPageForHtml->getSize()<=m_pPageForHtml->m_nReadCnt )	{
			// ��Ʋ�� ���鶧 �⺻������ �� CR�� ���� �ش�.
			CTextProc::removeLastCR(this, CTextProc::getLastBasicFrame(this));

			setFinishLoading(BrTRUE);
			m_pPageForHtml->clear();
		}
		// �Ϻθ� ���� ���
		else	{
			m_pPageForHtml->clear(m_pPageForHtml->m_nReadCnt);
		}

		// check page width for HTML document
		checkPageWidthForHTML();
#else	// LOAD_ONE_PAGE_HTML

		CHtmlLoader* loader = BrNEW CHtmlLoader();
		loader->m_pMimeDec = mime_dec;//�δ��� �޾� �ְ� ���߿� �������� �V���մϴ�.

		CHtmlPageBase * pPage = loader->loadFromFile( strPath, false );

		//	if (dwServiceType == INTERNET_SERVICE_HTTP)
	//		DeleteFile(szHtml);
		if (pPage == BrNULL)
		{
			SET_ERROR(kPoErrInternal, "");
			return BrFALSE;
		}

		// increase page width and height for HTML document
		increasePageHgtWidForHTML();

		BrBOOL bProtectUndo = g_pAppStatic->bProtectUndo;
		g_pAppStatic->bProtectUndo = true;
		bool rtCode = ((CHtmlPage *)pPage)->decodeToDoc(this);
		g_pAppStatic->bProtectUndo = bProtectUndo;

		pPage->clear();
		BrDELETE loader;
		//BrDELETE pPage;

		// check page width for HTML document
		checkPageWidthForHTML();
#endif	// LOAD_ONE_PAGE_HTML

	}
	else
	{
		BrDELETE mime_dec;
		bRet = BrFALSE;
	}

	INCREASE_PROGRESS(10);
	CANCEL_LOAD_RETURN_PTR_EX1;

	return ( bRet ? BrTRUE : BrFALSE );
}

BrBOOL BoraDoc::importMime_Memory( BrLPCTSTR mhtPath )
{
	BString newPath;
	CMimeDec* mime_dec = BrNEW CMimeDec();

	BrBOOL bRet = mime_dec->SetMhtFile( mhtPath );

	INCREASE_PROGRESS(5);
	CANCEL_LOAD_RETURN_PTR_EX1;

	if (!bRet){
		BrDELETE mime_dec;
		return false;
	}

	CMimePart* pMain = mime_dec->GetMainPart();

	if( mime_dec->IsGood()  && pMain )
	{
		g_pHtml->m_TempValue.m_bMimeMode = true;

		mime_dec->SaveMemory();



		//.. CHString strURL;
#ifdef LOAD_ONE_PAGE_HTML
		m_pLoaderForHtml = BrNEW CHtmlLoader();
#else	// LOAD_ONE_PAGE_HTML
		CHtmlLoader* loader = BrNEW CHtmlLoader();
#endif	// LOAD_ONE_PAGE_HTML

		CBrMemFile* pMem  = pMain->getMemFile();
		if( pMem == BrNULL )
		{
			BrDELETE mime_dec;
#ifndef LOAD_ONE_PAGE_HTML
			BrDELETE loader;
#endif	// LOAD_ONE_PAGE_HTML
			return BrFALSE;
		}

		int len = pMem->GetLength();
		if( len == 0 )
		{
			BrDELETE mime_dec;
#ifndef LOAD_ONE_PAGE_HTML
			BrDELETE loader;
#endif	// LOAD_ONE_PAGE_HTML
			return BrFALSE;
		}

#ifdef LOAD_ONE_PAGE_HTML
		m_pLoaderForHtml->m_pMimeDec = mime_dec;//�δ��� �޾� �ְ� ���߿� �������� �V���մϴ�.
#else	// LOAD_ONE_PAGE_HTML
		loader->m_pMimeDec = mime_dec;//�δ��� �޾� �ְ� ���߿� �������� �V���մϴ�.
#endif	// LOAD_ONE_PAGE_HTML

		BrLPBYTE pBuf = (BrLPBYTE) BrCalloc( len + 4 , 1 );

		pMem->Read( pBuf , len );

		// ���� ����Ʈ �����κ��� Unicode�� ������ �Ŀ� �� ���� ���μ����� ������.
		BrLPWSTR wBuf = (BrLPWSTR) BrCalloc( len + 3 ,  BrSizeOf(BrWCHAR) );//����� ũ�� ��´�.


		INCREASE_PROGRESS(5);
		CANCEL_LOAD_RETURN_PTR_EX1;

		if( len == 0 )
			wBuf[0] =0;
		else if( len==1 )
			wBuf[0] = pBuf[0];
		else if( pBuf[0] ==0xff && pBuf[1] == 0xfe )
		{
			// �����ڵ�
			int len_uni = CUtil::WcsLen( (const unsigned short *) (pBuf+2)  );
			memcpy( wBuf , pBuf+2 , (len_uni+1)*2 );
			//wcscpy( pUni , (BrLPCWSTR)( lpBuf+2 ) );
		}
		else if( pBuf[0] ==0xfe && pBuf[1] == 0xff )
		{
			//big endian
			CHtmlUtil::MultiByteToWideChar( 1201 , 0 , (BrLPCSTR)( pBuf+2 ) , -1 , wBuf ,len + 3 );
		}
		else if( len > 2 && pBuf[0] ==0xef && pBuf[1] == 0xbb && pBuf[2] == 0xbf )
		{
			//utf8
			CHtmlUtil::MultiByteToWideChar( CP_UTF8 , 0 , (BrLPCSTR)( pBuf+3 ) , -1 , wBuf , len + 3 );
		}
		else
		{	//�Ƚ�
			// �̰�쿣 ���ο� ��� �ִ� ĳ���� �ڵ带 ���� ���ƾ� �Ѵ�.
			int code = CHtmlCharset::GetHtmlCodePage( pBuf );
			if( code == 0 )
				code = CP_ACP;

			CHtmlUtil::MultiByteToWideChar( code , 0 , (BrLPCSTR)( pBuf ) , -1 , wBuf , len + 3 );
		}

		BrFree(pBuf );

		INCREASE_PROGRESS(5);
		CANCEL_LOAD_RETURN_PTR_EX1;


		//szHtml = szFilePath;
		//setHtmlRoot(szHtml);
		//.. g_pAppStatic->bLoadFromInternet = false;

#ifdef LOAD_ONE_PAGE_HTML

		m_pPageForHtml = m_pLoaderForHtml->processStream(  wBuf , BrNULL, false);

		if (m_pPageForHtml == BrNULL)
		{
			SET_ERROR(kPoErrInternal, "");
			BrDELETE m_pLoaderForHtml;
			m_pLoaderForHtml = BrNULL;
			return BrFALSE;
		}

		if( m_pPageForHtml )
		{
			m_pPageForHtml->SetStyleItem( m_pPageForHtml );

			m_pPageForHtml->DeleteDisplayNone();
			m_pPageForHtml->SetEstimatedWidthHeight( DOCX_A4_X , DOCX_A4_Y/2);
		}

		INCREASE_PROGRESS(10);
		CANCEL_LOAD_RETURN_PTR_EX1;

		// increase page width and height for HTML document
		increasePageHgtWidForHTML();

		BrBOOL bProtectUndo = g_pAppStatic->bProtectUndo;
		g_pAppStatic->bProtectUndo = true;
		bRet = ((CHtmlPage*)m_pPageForHtml)->decodeToDoc( this );
		g_pAppStatic->bProtectUndo = bProtectUndo;

		// in case reading all html document
		if ( m_pPageForHtml->getSize()<=m_pPageForHtml->m_nReadCnt )	{
			// ��Ʋ�� ���鶧 �⺻������ �� CR�� ���� �ش�.
			CTextProc::removeLastCR(this, CTextProc::getLastBasicFrame(this));

			setFinishLoading(BrTRUE);
			m_pPageForHtml->clear();
		}
		// �Ϻθ� ���� ���
		else	{
			m_pPageForHtml->clear(m_pPageForHtml->m_nReadCnt);
		}

		// check page width for HTML document
		checkPageWidthForHTML();
#else	// LOAD_ONE_PAGE_HTML

		CHtmlPageBase * pPage = loader->processStream( wBuf , BrNULL , false);

		if (pPage == BrNULL)
		{
			SET_ERROR(kPoErrInternal, "");
			BrDELETE loader;
			return false;
		}

		if( pPage )
		{
			pPage->SetStyleItem( pPage );

			pPage->DeleteDisplayNone();
			pPage->SetEstimatedWidthHeight( DOCX_A4_X , DOCX_A4_Y/2);
		}

		INCREASE_PROGRESS(10);
		CANCEL_LOAD_RETURN_PTR_EX1;

		// increase page width and height for HTML document
		increasePageHgtWidForHTML();

		BrBOOL bProtectUndo = g_pAppStatic->bProtectUndo;
		g_pAppStatic->bProtectUndo = true;
		bRet = ((CHtmlPage *)pPage)->decodeToDoc(this);
		g_pAppStatic->bProtectUndo = bProtectUndo;
		pPage->clear();
		BrDELETE loader;

		// check page width for HTML document
		checkPageWidthForHTML();
#endif	// LOAD_ONE_PAGE_HTML

		//mime_dec.ConvertHtmlCID();

		g_pHtml->m_TempValue.m_bMimeMode = false;
	}
	else
	{
		BrDELETE mime_dec;
		SET_ERROR(kPoErrCorruptFile, "");
		bRet = BrFALSE;
	}

	INCREASE_PROGRESS(10);
	CANCEL_LOAD_RETURN_PTR_EX1;

	return ( bRet ? BrTRUE : BrFALSE );
}



#endif //USE_MIME
#endif //IMPORT_HTML

#if defined(IMPORT_HTML) && defined(LOAD_ONE_PAGE_HTML)
// �� ������ �з��� html�� import
BrBOOL BoraDoc::importOnePageHtml()
{
	BrAtomicOp
	if (m_pPageForHtml == BrNULL)
		return BrFALSE;

	// move to last position of document (#1219)
	getCaret()->moveToEndOfDoc();

	m_pPageForHtml->m_nReadCnt = 0;

	// increase page width and height for HTML document
	increasePageHgtWidForHTML(BrFALSE);

	BrBOOL bProtectUndo = g_pAppStatic->bProtectUndo;
	g_pAppStatic->bProtectUndo = true;
	BrBOOL rtCode =((CHtmlPage*) m_pPageForHtml)->decodeToDoc(this);
	g_pAppStatic->bProtectUndo = bProtectUndo;

	// ��� �� ���� ���
	if ( m_pPageForHtml->getSize()<=m_pPageForHtml->m_nReadCnt )	{
		// ��Ʋ�� ���鶧 �⺻������ �� CR�� ���� �ش�.
		CTextProc::removeLastCR(this, CTextProc::getLastBasicFrame(this));

		setFinishLoading(BrTRUE);
		m_pPageForHtml->clear();
	}
	// �Ϻθ� ���� ���
	else	{
		m_pPageForHtml->clear(m_pPageForHtml->m_nReadCnt);
	}

	// check page width for HTML document
	checkPageWidthForHTML(BrFALSE);

	return rtCode;
}
#endif	// LOAD_ONE_PAGE_HTML


bool BoraDoc::changePageWidth()
{
#ifdef IMPORT_HTML
	// increase page width and height for HTML document
	increasePageHgtWidForHTML();

	CCaret* pCaret = getCaret();
	if(pCaret == BrNULL)
		return false;
	pCaret->setCaretStatus(BR_CARET_OFF);

	CLine* pLine = this->getFirstLine();
	if(pLine == BrNULL)
		return false;
	CFrame* pFrame = pLine->getFrame();
	if(pFrame == BrNULL)
		return false;

	if( m_HtmlPageSize.cx != 0 )
		pFrame->setRight( m_HtmlPageSize.cx - ((m_HtmlPageSize.cx<=120) ? 0 : 120) );

	// anchored frame�� width�� parent frame�� width���� ū ��� �ٽ� ���� �� �ش�.
	// HTML import�� ����� �߸� �Ǵ� ��찡 ���� �߻��ؼ�....
// 	if ( getFirstLine() )
// 	{
// 		adjustWidthOfAnchoredFrameInText(getFirstLine()->getFrame());
// 		CTextProc::arrangeMarkingLines(this, getFirstLine(), BrNULL);
// 	}

	// check page width for HTML document
	checkPageWidthForHTML();
#endif
	return BrTRUE;
}


// �� Mode�� �ٲٱ� ���� page/margin anchor object�� paragraph anchor object�� �����Ѵ�.
void BoraDoc::changeAnchorPageToPara()
{
	if (getBWPEngineMode() == EDITOR_PPT)
	{
		BRTHREAD_ASSERT(0); // PPT�� �� ��� ����� ����.. �������� ��� ���� �ȵ�.
		return;
	}

	CFrameList	*pFrameList = getAFrameList();
	CFrame		*pFrame = pFrameList->getFirst();
	if(!pFrame)     return;

	BrBYTE nRelative = 0;

	while(pFrame)
	{
		// page or margin anchor object
		if ( !pFrame->isAnchored() )
		{
			switch(pFrame->getHorizontalLocationType()){
			case LT_ALIGNMENT:
			case LT_BOOKLAYOUT:
			case LT_RELATIVE:
				pFrame->setXOrgType(ORG_MARGIN);
				break;
			case LT_ABSOLUTE:
				nRelative = pFrame->getHorizontalRelative();

				if(nRelative == RT_PAGE || nRelative == RT_LEFT_MARGIN || nRelative == RT_RIGHT_MARGIN || nRelative == RT_PADDING || nRelative == RT_OUTSIDE_MARGIN)
					pFrame->setXOrgType(ORG_MARGIN);
				break;
			}

			// Vertical Location
			switch(pFrame->getVerticalLocationType()){
			case LT_ALIGNMENT:
			case LT_RELATIVE:
				pFrame->setYOrgType(ORG_PARA);
				break;
			case LT_ABSOLUTE:
				if(pFrame->getVerticalRelative() != RT_LINE)
					pFrame->setYOrgType(ORG_PARA);
				break;
			}
		}
		pFrame = pFrameList->getNext(pFrame);
	}
}

//void BoraDoc::changeAnchorPageToPara()
//{
//	if (getBWPEngineMode() == EDITOR_PPT)
//	{
//		BRTHREAD_ASSERT(0); // PPT�� �� ��� ����� ����.. �������� ��� ���� �ȵ�.
//		return;
//	}
//	CLocation   cLoc;
//	CFrameList	*pFrameList = getAFrameList();
//	CFrame		*pFrame = pFrameList->getFirst();
//	if(!pFrame)     return;
//
//	CLine	*pLine;
//	CFrame	*pParent;
//	BRect	rc, rcParent;
//	int		dx, dy;
//	while(pFrame)
//	{
//		// page or margin anchor object
//		if ( !pFrame->isAnchored() )
//		{
//			pLine = BrNULL;
//			if ( pFrame->getXOrgType() == ORG_PAGE || pFrame->getXOrgType() == ORG_MARGIN )
//			{
//				if ( pFrame->getAnchorLine() )
//					pLine  = pFrame->getAnchorLine();
//				else if ( pFrame->getLocation(cLoc) )
//					pLine = cLoc.getLine();
//
//				if ( pLine )
//				{
//					pLine = pLine->getStartLineOfParaInOneFrame();
//					rc = pFrame->getFrameRect();
//					pParent = pLine->getFrame();
//					rcParent = pParent->getFrameRect();
//					dx = rc.nLeft - rcParent.nLeft;
//					// dy = rc.nTop - rcParent.nTop - pLine->getBasePos() + pLine->getHeight();
//
//					if ( pFrame->getXOrgType()==ORG_PAGE )
//						pFrame->setChangedPageAnchorX(true);
//					else
//						pFrame->setChangedMarginAnchorX(true);
//
//					pFrame->setOrgDx(dx);
//					// pFrame->setOrgDy(dy);
//					pFrame->setXOrgType(ORG_PARA);
//				}
//			}
//			if ( pFrame->getYOrgType() == ORG_PAGE || pFrame->getYOrgType() == ORG_MARGIN )
//			{
//				if ( pLine==BrNULL )
//				{
//					if ( pFrame->getAnchorLine() )
//						pLine  = pFrame->getAnchorLine();
//					else if ( pFrame->getLocation(cLoc) )
//						pLine = cLoc.getLine();
//				}
//
//				if ( pLine )
//				{
//					pLine = pLine->getStartLineOfParaInOneFrame();
//					rc = pFrame->getFrameRect();
//					pParent = pLine->getFrame();
//					rcParent = pParent->getFrameRect();
//					// dx = rc.nLeft - rcParent.nLeft;
//					CLine *pPrevLine = pLine->getPrevInFrame();
//					if ( pPrevLine )
//						dy = rc.nTop - rcParent.nTop - (pPrevLine->getBasePos() + CTextProc::CalcLineSpace(this, pPrevLine, BrFALSE));
//					else
//						dy = rc.nTop - rcParent.nTop;	// - pLine->getBasePos() + pLine->getHeight();
//
//					if ( pFrame->getYOrgType()==ORG_PAGE )
//						pFrame->setChangedPageAnchorY(true);
//					else
//						pFrame->setChangedMarginAnchorY(true);
//
//					// pFrame->setOrgDx(dx);
//					pFrame->setOrgDy(dy);
//					pFrame->setYOrgType(ORG_PARA);
//				}
//			}
//		}
//		pFrame = pFrameList->getNext(pFrame);
//	}
//}

void BoraDoc::restoreAnchorPage()
{
	if (getBWPEngineMode() == EDITOR_PPT)
	{
		BRTHREAD_ASSERT(0); // PPT�� �� ��� ����� ����.. �������� ��� ���� �ȵ�.
		return;
	}
	CFrameList	*pFrameList = getAFrameList();
	CFrame		*pFrame = pFrameList->getFirst();
	if(!pFrame)     return;

	while(pFrame)
	{
		pFrame->setHorizontalRelative(pFrame->getHorizontalRelative());
		pFrame->setVerticalRelative(pFrame->getVerticalRelative());

		pFrame = pFrameList->getNext(pFrame);
	}
}

// �μ� Mode�� �ٲٱ� ���� ������ page/margin anchor object�� �����Ѵ�.
//void BoraDoc::restoreAnchorPage()
//{
//	if (getBWPEngineMode() == EDITOR_PPT)
//	{
//		BRTHREAD_ASSERT(0); // PPT�� �� ��� ����� ����.. �������� ��� ���� �ȵ�.
//		return;
//	}
//	CFrameList	*pFrameList = getAFrameList();
//	CFrame		*pFrame = pFrameList->getFirst();
//	if(!pFrame)     return;
//
//	CPage   *pPage;
//	BRect	rc, rcMargin;
//	int		dx, dy;
//	while(pFrame)
//	{
//		//  changeAnchorPageToPara()���� ������ frame
//		if ( pFrame->getXOrgType()==ORG_PARA )	{
//			// paragraph anchor => page anchor
//			if ( pFrame->isChangedPageAnchorX() )	{
//				rc = pFrame->getFrameRect();
//				dx = rc.nLeft;
//				pFrame->setOrgDx(dx);
//				pFrame->setXOrgType(ORG_PAGE);
//				pFrame->setChangedPageAnchorX(BrFALSE);
//			}
//			// paragraph anchor => margin anchor
//			else if ( pFrame->isChangedMarginAnchorX() )	{
//				rc = pFrame->getFrameRect();
//				pPage = pFrame->getPage();
//				pPage->getBasicBoundary(rcMargin);
//				dx = rc.nLeft - rcMargin.nLeft;
//				pFrame->setOrgDx(dx);
//				pFrame->setXOrgType(ORG_MARGIN);
//				pFrame->setChangedMarginAnchorX(BrFALSE);
//			}
//		}
//		if ( pFrame->getYOrgType()==ORG_PARA )	{
//			// paragraph anchor => page anchor
//			if ( pFrame->isChangedPageAnchorY() )	{
//				rc = pFrame->getFrameRect();
//				dy = rc.nTop;
//				pFrame->setOrgDy(dy);
//				pFrame->setYOrgType(ORG_PAGE);
//				pFrame->setChangedPageAnchorY(BrFALSE);
//			}
//			// paragraph anchor => margin anchor
//			else if ( pFrame->isChangedMarginAnchorY() )	{
//				rc = pFrame->getFrameRect();
//				pPage = pFrame->getPage();
//				pPage->getBasicBoundary(rcMargin);
//				dy = rc.nTop - rcMargin.nTop;
//				pFrame->setOrgDy(dy);
//				pFrame->setYOrgType(ORG_MARGIN);
//				pFrame->setChangedMarginAnchorY(BrFALSE);
//			}
//		}
//		pFrame = pFrameList->getNext(pFrame);
//	}
//}

#ifdef	NOT_USED	// 18-DEC-2001
BString BoraDoc::getWorkDirectory()
{
	BString strResult;


	BrLPTSTR lpBuffer=BrNULL;
	lpBuffer=BrMalloc(BrSizeOf(char)*MAX_PATH);

	BrDWORD length = GetCurrentDirectory( MAX_PATH ,lpBuffer);

	if(0 < length &&  length < MAX_PATH)
		strResult=(BrLPCTSTR) lpBuffer;

	BrFree(lpBuffer);

	return strResult;
}

BrBOOL BoraDoc::openHtmlSite(BrLPTSTR lpszSite)
{
	if ( !SaveModified() )
		return BrFALSE;

	BString pathName=lpszSite;
	CCaret* pCaret=getCaret();

	pCaret->hide();
	ClearAll();
	Init();
	CWaitCursor wait;
    CHtmlImportInterface html_importer;
	BrBOOL rc=html_importer.OpenHtml(pathName);

	pCaret->
		(getFirstLine());
	pCaret->show();
 	m_pView->resetViewMode();
//jyoh comm 	m_pView->Invalidate();

	BString http=pathName.Left(7);
	http.MakeLower();

	if(rc)
	{
		if( http.CompareNoCase( "http://" ) )
			pathName="http://"+pathName;
		BString szNewFile;
		szNewFile.LoadString(IDS_NEWHTML);
		SetPathName(szNewFile, BrFALSE);

//jyoh comm 		m_pView->SetFocus();
		setModifiedFlag(BrTRUE);
 		m_pView->GetBoraXControl()->FireDocLoadComplete( pathName );
		return BrTRUE;
	}
	return BrFALSE;
}
#endif

#ifdef IMPORT_HTML
// increase page width and height for HTML document
void BoraDoc::increasePageHgtWidForHTML(BrBOOL bFirst)
{
	// 2006.7.28
	// CPage	*pPage = getWebPageArray()->getPage(1);
	CPage	*pPage = getEditingPageArray()->getPage(1);
	if ( pPage==BrNULL )	return;

	pPage->getPaperSize()->setHeight(WEB_PAGE_Y);

#ifdef BWP_EDITOR
	getCmdEngine()->setDocEndCoord();
#endif

	// upper changed to bellow by sosful 2006-03-30
	// ó�� ���� ��...
	if ( bFirst )	{
		pPage->getColumn()->initForWebPage(pPage->getPaperSize(),
			DEF_LEFT_MARGIN_FOR_WEB,
			DEF_TOP_MARGIN_FOR_WEB,
			DEF_RIGHT_MARGIN_FOR_WEB,
			DEF_BTM_MARGIN_FOR_WEB);

		CFrame	*pBasicFrame = pPage->getFirstBasic();
		if ( pBasicFrame )
		{
			BRect	rcBasic( DEF_LEFT_MARGIN_FOR_WEB,
				DEF_TOP_MARGIN_FOR_WEB,
				pPage->width() - DEF_RIGHT_MARGIN_FOR_WEB,
				pPage->height() - DEF_BTM_MARGIN_FOR_WEB);
			pBasicFrame->setFrameRect(rcBasic);
		}
	}
	// �� ��° ����
	else	{
		CFrame	*pBasicFrame = pPage->getFirstBasic();
		if ( pBasicFrame )	{
			pPage->getColumn()->initForWebPage(pPage->getPaperSize(),
				DEF_LEFT_MARGIN_FOR_WEB,
				pBasicFrame->top(),
				DEF_RIGHT_MARGIN_FOR_WEB,
				DEF_BTM_MARGIN_FOR_WEB);
			BRect	rcBasic( pBasicFrame->left(),
				pBasicFrame->top(),
				pBasicFrame->right(),
				pPage->height() - DEF_TOP_MARGIN_FOR_WEB - DEF_BTM_MARGIN_FOR_WEB);
			pBasicFrame->setFrameRect(rcBasic);
		}
	}
}

// check page width for HTML document
void	BoraDoc::checkPageWidthForHTML(BrBOOL bFirst)
{
	CFrame	*pFrame;
	int		nMaxWidth = 0;
	if (getBWPEngineMode() == EDITOR_PPT)
	{
		BRTHREAD_ASSERT(0); // PPT�� �� ��� ����� ����.. �������� ��� ���� �ȵ�.
		return;
	}
	// 2006.7.28
	// CPage	*pPage = getWebPageArray()->getPage(1);
#ifdef	BWP_EDITOR
	CPage	*pPage = getEditingPageArray()->getPage(1);
#else
	CPage	*pPage = getPageArray()->getPage(1);
#endif
	if ( pPage==BrNULL )	return;
	CPaperSize	*pPaper = pPage->getPaperSize();
	if ( pPaper==BrNULL )	return;

	// recalculate y
	int		nEndDy=0;
	// check maximum x-coordinate
	/*
	CFrameList	*pFrameList = getAFrameList();
	pFrame = pFrameList->getFirst();
	while ( pFrame )
	{
		if ( pFrame->right() > nEndDx )
		{
			nEndDx = pFrame->right() + DEF_RIGHT_MARGIN_FOR_WEB;
		}
		pFrame = pFrameList->getNext(pFrame);
	}
	*/

	// check maximum y-coordinate
	CLine	*pLine = pPage->getLastLine();
	if ( pLine )
	{
		nEndDy = pLine->getBasePos() + pPage->topMargin() + pPage->bottomMargin();
		int		nFrameEndDy = getMaxFrameYForWeb() + pPage->bottomMargin();
		if ( nFrameEndDy > nEndDy )
			nEndDy = nFrameEndDy;
	}
	nEndDy += 200;		// 200 ���� ������ ����...
	pPage->getPaperSize()->setHeight(nEndDy);

	// get actual basic frame width
	CFrame	*pBasicFrame = pPage->getFirstBasic();
	if ( pBasicFrame==BrNULL )		return;
	BRect	rcBasic = pBasicFrame->getFrameRect();
	int		nFrameWidth = rcBasic.getWidth();

	// check width of Anchored Frame
    CFrameList *pFrameList = getAFrameList();
    ASSERT_VALID(pFrameList);
    pFrame = pFrameList->getFirst();

    while(pFrame)
    {
        if( pFrame->isAnchored() )	{
			if ( (pFrame->getFrameRect()->nRight - pFrame->getFrameRect()->nLeft) > nMaxWidth ) {
				nMaxWidth = pFrame->getFrameRect()->nRight - pFrame->getFrameRect()->nLeft;
			}
        }
        pFrame = pFrameList->getNext(pFrame);
    }

	// Increase page width and frame width
	int		nIncWidth = 0;
	if ( nMaxWidth > nFrameWidth && m_HtmlPageSize.cx == 0 )
		nIncWidth = nMaxWidth-nFrameWidth;

	if ( nIncWidth )
		pPaper->setWidth(pPaper->width()+nIncWidth);
	CColumn	*pColumn = pPage->getColumn();
	if ( bFirst )	{
		pColumn->initForWebPage(pPaper, DEF_LEFT_MARGIN_FOR_WEB,
			DEF_TOP_MARGIN_FOR_WEB,
			DEF_RIGHT_MARGIN_FOR_WEB,
			DEF_BTM_MARGIN_FOR_WEB);
	}
	else	{
		pColumn->initForWebPage(pPaper, DEF_LEFT_MARGIN_FOR_WEB,
			rcBasic.Top(),
			DEF_RIGHT_MARGIN_FOR_WEB,
			DEF_BTM_MARGIN_FOR_WEB);
	}

#ifdef		BWP_EDITOR
	rcBasic.nBottom = pPaper->height() - pColumn->btmMar() - pColumn->topMar();
#else
	rcBasic.nBottom = nEndDy - pColumn->btmMar();
	rcBasic.nRight += nIncWidth;
#endif
	pBasicFrame->setFrameRect(rcBasic);
}
#endif //IMPORT_HTML

int	BoraDoc::getMaxFrameYForWeb()
{
	int		nMaxY=0;
	BRect   *pRect;

	if (getBWPEngineMode() == EDITOR_PPT)
	{
		BRTHREAD_ASSERT(0); // PPT�� �� ��� ����� ����.. �������� ��� ���� �ȵ�.
		return 0;
	}
	CFrameList *pFrameList = getAFrameList();
	ASSERT_VALID(pFrameList);
	CFrame *pFrame = pFrameList->getFirst();

	//--- Scanning all Special FCS (First Item==>Last Item )
	while(pFrame)
	{
		pRect = pFrame->getFrameRect();
		if ( pFrame->getSubFrame() && (pRect->nBottom) > nMaxY )	{
			nMaxY = pRect->nBottom;
		}

		pFrame = pFrameList->getNext(pFrame);

	}
	return nMaxY;
}

#ifdef USE_HWP_CONTROL
/*
  ������ �ʵ忡�� ���ڿ��� ���Ѵ�.
  Parameters
	strFieldName
		�ʵ� �̸�
  Return Values
	�ؽ�Ʈ �����Ͱ� ���ƿ´�. ������ �̸��� �ʵ尡 ���ų� ����ڰ� �ش� �ʵ忡 �ƹ� �ؽ�Ʈ��
	�Է����� �ʾ����� �ش� �ؽ�Ʈ���� �� ���ڿ��� ���ƿ´�.
*/
BString BoraDoc::getFieldText(BString &strFieldName, BrINT a_nFieldNum)
{
	BString		strFieldText;

	//strFieldText.Empty();

	CCaret *pCaret=getCaret();

	pCaret->saveCaret();

	CFrame* pCellFieldFrame = GetFieldCellFrame( strFieldName, a_nFieldNum );
	if(pCellFieldFrame)
	{
		strFieldText = pCellFieldFrame->getStringInFrame();
	}
	else
	{
		CRange rngClickhere;
		BrINT32 nID = GetFieldRange(strFieldName, a_nFieldNum, BrTRUE, rngClickhere);
		if(nID > 0)
		{
			clickhere::ClickHere* pClickhere = getClickHereHandler()->find(nID);
			if(pClickhere && pClickhere->ContentExists())
				m_pHWPCotrolCmdEngine->GetRangeNormalText(rngClickhere,strFieldText);
		}
	}

	pCaret->restoreCaret();

	return strFieldText;
}

/*
  ������ �ʵ��� ������ ä���.
  Parameters
	strFieldName
		�ʵ� �̸�
	strText
		�ʵ忡 ä�� ���� ���ڿ�
*/
BrBOOL	BoraDoc::putFieldText(BString &strFieldName, BrINT a_nFieldNum, BString &strText)
{
	BWP_UNDO_CONTINUE_RESTORER
	CCaret *pCaret=getCaret();
	if(!pCaret)
		return BrFALSE;

	clickhere::ClickHereHandler* pClickhereArray = getClickHereHandler();
	if(!pClickhereArray)
		return BrFALSE;

	BrBOOL bRet = BrFALSE;

#ifdef	BWP_UNDO
	CUndoEngine *pUndoEngine = getUndoEngine();
	if(pUndoEngine==BrNULL)
		return BrFALSE;

	//���� ������ �����ϰ� ���ο� ������ �ִ� ��� �ϳ��� API�����̱� ������ �ϳ��� undo�� ó������ �ʴ´�(���İ� �����ϰ� �����ϵ��� ó��)
	//BrBOOL bPrevContinue = pUndoEngine->setContinueFlag(BrTRUE);
#endif //BWP_UNDO

	CheckCaretPositionRestorer restorer(BrTRUE);

	CRange rngField;
	if ( m_pHWPCotrolCmdEngine && m_pHWPCotrolCmdEngine->getFieldRange(rngField, strFieldName, a_nFieldNum, BrTRUE, BrTRUE, BrTRUE) )
	{
		BrWORD wAttID = 0;
		CLine* pLine = BrNULL;
		BrINT nCol = 0;
		if(rngField.getBeginLoc().isValid())
		{
			pLine = rngField.getBeginLoc().getLine();
			nCol = rngField.getBeginLoc().getColumn();
		}
		else
		{
			pLine = rngField.getEndLoc().getLine();
			nCol = rngField.getEndLoc().getColumn();
		}

		if(pLine)
		{
			//CellField ���ο� ������ ���� ù��° NormalTextLink �Ӽ����� ���Եǰ� ����Ʋ�� ������ ���� Begin Link�� �ؽ�Ʈ �Ӽ��� ����
			CLocation oLoc;
			oLoc.setLocation(pLine, nCol);
			BrINT nClkID = oLoc.IsInnerClickHere();
			if( nClkID > 0)
			{
				PoTextAtt DefaultTextAttr;

				CRange rngClk;
				if(GetFieldRange(strFieldName, a_nFieldNum, BrFALSE, rngClk) > 0)
				{
					if(rngClk.getBeginLoc().getCharSet() && rngClk.getBeginLoc().getCharSet()->isClickhereBeginLink())
					{
						getTextAttHandler()->getTextAtt(DefaultTextAttr, rngClk.getBeginLoc().getCharSet()->getAttrID());
					}
				}

				DefaultTextAttr.setLinkType(LINKTYPE::HWP_FIELD);
				DefaultTextAttr.setSubType(FILED_EX_TYPE_DISPLAY);
				wAttID = GetTextAttrID(DefaultTextAttr);
			}
			else
			{
				if(pLine->getFrame() && pLine->getFrame()->isCell())
				{
					for(BrINT i=0; i<pLine->getCharNum(); i++)
					{
						CCharSet* pFirstNormalTextLink = pLine->getCharSet(i);
						if(pFirstNormalTextLink && pFirstNormalTextLink->isNormalTextLink() && !pFirstNormalTextLink->isSpace())
						{
							wAttID = pFirstNormalTextLink->getAttrID();
							break;
						}
					}
				}
			}
		}

    if(rngField.getEndLoc().isValid())
    {
      CLine* pInsertLine = rngField.getEndLoc().getLine();
      BrINT nInsertCol = rngField.getEndLoc().getColumn();

      clickhere::ClickHere* pClickhere = BrNULL;
      CCharSet* pClickhereLink = rngField.getEndLoc().getCharSet();
      if(pClickhereLink && pClickhereLink->isClickhereEndLink())
      {
        pClickhere = pClickhereArray->find(pClickhereLink->getCode());
      }

      if(pClickhere == BrNULL || pClickhere->ContentExists() == BrTRUE)
      {
        if(rngField.getBeginLoc().isValid())
        {
#ifdef	BWP_UNDO
          if(rngField.getBeginLoc().getLine() != rngField.getEndLoc().getLine() || rngField.getBeginLoc().getColumn() != rngField.getEndLoc().getColumn())
          {
            POUndoRedo::MarkTextData *pData = BrNEW POUndoRedo::MarkTextData();
            if(pData)
            {
              if( pUndoEngine->makeUndoDeleteMarkData(this, rngField.getBeginLoc().getLine(), rngField.getEndLoc().getLine(), rngField.getBeginLoc().getColumn(), rngField.getEndLoc().getColumn(), pData) )
              {
                pUndoEngine->storeUndoData(ActionClearMarkText, pData);
                pInsertLine = rngField.getBeginLoc().getLine();
                nInsertCol = rngField.getBeginLoc().getColumn();
              }
              else
                BrDELETE pData;
            }
          }
#endif //BWP_UNDO
        }
      }
      else
      {
#ifdef	BWP_UNDO
        POUndoRedo::Clickhere *pData = BrNEW POUndoRedo::Clickhere();
        if( pUndoEngine->makeUndoDeleteMarkData(this, rngField.getBeginLoc().getLine(), rngField.getEndLoc().getLine(), rngField.getBeginLoc().getColumn(), rngField.getEndLoc().getColumn(), pData) )
        {
          pData->m_nClickhereID = pClickhere->ID();
          pUndoEngine->storeUndoData(ActionDeleteClickhereText, pData);
          pInsertLine = rngField.getBeginLoc().getLine();
          nInsertCol = rngField.getBeginLoc().getColumn();
          pClickhere->UpdateContentExists(true);
        } else {
          BR_SAFE_DELETE(pData);
        }
      }
#endif


			CCharSetArray* pCharSetArray = BrNEW CCharSetArray(strText.length());
			for(int i=0 ; i<strText.length() ; i++)
			{
				CCharSet* pLink = pCharSetArray->getCharSet(i);
				pLink->setCode(strText.at(i).unicode());
				pLink->setAttrID(wAttID);
			}
			CTextProc::InsertCharSetArray(this, pInsertLine, nInsertCol, pCharSetArray, BrTRUE);
			CTextProc::arrangeAndExpandFrame(this, pInsertLine, BrNULL, EXPAND, 0);

			bRet = BrTRUE;
		}
	}
	return bRet;
}



/*�������� ��� �ʵ��� �̸��� ������(|&|)�� �̿��Ͽ� �����Ѵ�.
*/
BString BoraDoc::GetFieldList(BrINT a_nNumber , BrINT a_nOption)
{
	const BrINT NUMBER_FIELD_PLAIN = 0;
	const BrINT NUMBER_FIELD_NUMBER = 1;
	const BrINT NUMBER_FIELD_COUNT = 2;

	const BrINT OPTION_FIELD_CELL = 0x01;
	const BrINT OPTION_FIELD_CLICKHERE = 0x02;
	const BrINT OPTION_FIELD_SELECTION = 0x04;

	BString strResult;
	BObArray<BString> arrFieldList;

	//0�� ��� �Ѵ� ã�´�.
	if(a_nOption == 0)
		a_nOption = OPTION_FIELD_CELL| OPTION_FIELD_CLICKHERE;

	CFrame* pFrame = BrNULL;

#if 1
	CLine* pSLine = BrNULL;
	CLine* pELine = BrNULL;
	BrINT nSCol = 0;
	BrINT nECol = 0;

	if(a_nOption & OPTION_FIELD_SELECTION)
	{
		CCaret* pCaret = getCaret();
		switch(pCaret->getCaretStatus())
		{
		case BR_CARET_NORMAL:
		case BR_CARET_OFF:
		case BR_CARET_COLMARK:
		case BR_CARET_ANCHOR:
			{
				return strResult;
			}
			break;
		case BR_CARET_MARKING:
			{
				pSLine = pCaret->getSLine();
				pELine = pCaret->getLine() ? pCaret->getLine()->getNext() : BrNULL;
				nSCol = pCaret->getSCol();
				nECol = pCaret->getCol();
			}
			break;
		}
	}
	else
	{
		pSLine = getFirstLine();
		pELine = BrNULL;
		nSCol = 0;
		nECol = getLastLine()->getCharNum();
	}

	CCharSetArray* pLinkArray = BrNULL;
	CCharSet* pLink = BrNULL;
	while(pSLine && pSLine != pELine)
	{
		pLinkArray = pSLine->getCharSetArray();
		BrINT nSize = (pSLine == pELine) ? nECol : pLinkArray->size();

		if ( (pSLine->getStatus(LINE_FIELD) && (a_nOption & OPTION_FIELD_CLICKHERE)) || (pSLine->getStatus(LINE_ANCHOR) && (a_nOption & OPTION_FIELD_CELL)))
		{
			for (BrINT i = nSCol; i < nSize; i++)
			{
				pLink = pLinkArray->getCharSet(i);
				if ( pLink->isClickhereBeginLink() && (a_nOption & OPTION_FIELD_CLICKHERE))
				{
					clickhere::ClickHere* pClickhere = getClickHereHandler()->find(pLink->getCode());
					if(pClickhere)
					{
						arrFieldList.Add(pClickhere->FieldName());
					}
				}
				else if ( pLink->isAnchorLink() && (a_nOption & OPTION_FIELD_CELL))
				{
					pFrame = pLink->getFrame(this);
					if ( pFrame )
					{
						switch ( pFrame->GetClass() )
						{
						case TABLEFRAME :
							{
								CBTable *pTable;
								CBCell  *pCell;

								pTable = (CBTable *) pFrame->getSubFrame();
								CCellList* pCellList = pTable->getCellList();
								while(pCellList)
								{
									pCell = pCellList->getFirstCell();
									while(pCell)
									{
										//XPD-13213 except middle and end split cell
										if(pCell->getSplitType() <= SPLIT_START)
										{
											pFrame = pCell->getFrame();
											if(pFrame && pFrame->getHwpFieldName().length() > 0)
											{
												arrFieldList.Add(pFrame->getHwpFieldName());
											}
										}
										pCell = pCell->getNext();
									}
									pCellList = pCellList->getNext();
								}
							}
							break;
						case FLOATFRAME:
							{
								if(pFrame && pFrame->getHwpFieldName().length() > 0)
								{
									arrFieldList.Add(pFrame->getHwpFieldName());
								}
							}
							break;
						}
					}
				}
			}
		}
		pSLine = pSLine->getNext();
		nSCol = 0;
	}
#else

	//�ɼǿ� ���� ã�����ϴ� �ʵ带 ã�´�
	if(a_nOption & OPTION_FIELD_CELL)
	{
		pFrame = m_AFrameList->getFirst();
		while(pFrame)
		{
			if(pFrame->isTable())
			{
				CBTable *pTable = (CBTable *)pFrame->getSubFrame();
				CCellList *pCellList = pTable->getCellList();

				CBCell *pCell = BrNULL;

				while (BrNULL != pCellList)
				{
					pCell = pCellList->m_pCell;
					while (BrNULL != pCell)
					{
						CFrame* pCellFrame = pCell->getFrame();
						if(pCellFrame->getHwpFieldName().length() > 0)
						{
							arrFieldList.Add(pCellFrame->getHwpFieldName());
						}
						pCell = pCell->getNext();
					}
					pCellList = pCellList->m_pNext;
				}
			}
			pFrame = m_AFrameList->getNext(pFrame);
		}
	}
	if(a_nOption & OPTION_FIELD_CLICKHERE)
	{
		CClickhereArray* pClickhereArray = getClickHereHandler();
		BrINT nSize = pClickhereArray ? pClickhereArray->size() : 0;
		for(BrINT i=0; i<nSize; i++)
		{
			CClickhere* pClickhere = pClickhereArray->at(i);
			if(pClickhere)
			{
				arrFieldList.Add(pClickhere->getFieldName());
			}
		}
	}
#endif
	BrINT nFieldCount = arrFieldList.size();
	//��ȣ���� ��Ŀ� ���� ������ڿ��� �����Ѵ�.
	if(a_nNumber == NUMBER_FIELD_PLAIN)
	{
		for (BrINT i=0; i<nFieldCount; i++)
		{
			strResult.append(arrFieldList.at(i));

			if(i != nFieldCount-1)
				strResult.append((BrCHAR)0x02);
		}

	}
	else if(a_nNumber == NUMBER_FIELD_NUMBER)
	{

	}
	else //a_nNumber == NUMBER_FIELD_COUNT
	{

	}

	return strResult;
}

/*
  ���� ĳ�� ��ġ�� ���ڵ� �ʵ� �̸��� ���Ѵ�.
  Return Values
  	�ʵ� �̸��� ���ƿ´�. �ʵ� �̸��� ���� ��� �� ���ڿ��� ���ƿ´�.
*/
BString BoraDoc::GetCurFieldName(BrINT a_nOption)
{
	const BrINT OPTION_FIELD_CELL = 1;
	const BrINT OPTION_FIELD_CLICKHERE = 2;

	BString		strFieldName;

	CCaret* pCaret = getCaret();
	if(!pCaret)
		return strFieldName;

	if(a_nOption == 0)
		a_nOption = OPTION_FIELD_CELL | OPTION_FIELD_CLICKHERE;

	if(a_nOption & OPTION_FIELD_CELL)
	{
		CFrame* pCellFrame = BrNULL;
		if(getTableEngine()->isCellMarked())
		{
			CBCell* pMarkingEndCell = getTableEngine()->getMarker()->getEndCell();
			if(pMarkingEndCell)
				pCellFrame = pMarkingEndCell->getFrame();
		}
		else
		{
			pCellFrame = GetCurFrameField();
		}

		if(pCellFrame)
		{
			strFieldName = pCellFrame->getHwpFieldName();
			return strFieldName;
		}
	}

	if(a_nOption & OPTION_FIELD_CLICKHERE)
	{
		clickhere::ClickHere* pClickhere = GetCurClickhereField();
		if(pClickhere)
		{
			strFieldName = pClickhere->FieldName();
			return strFieldName;
		}
	}

	return strFieldName;
}

//���� ĳ�� ��ġ�� �ʵ� ���� ����
BrBOOL BoraDoc::SetCurFieldName(BString a_strFieldName, BrINT a_nOption, BString a_strDirection, BString a_strMemo)
{
	CCaret* pCaret = getCaret();
	if(!pCaret)
		return BrFALSE;

	const BrINT OPTION_FIELD_CELL = 1;
	const BrINT OPTION_FIELD_CLICKHERE = 2;

	if(a_nOption == 0)
		a_nOption = OPTION_FIELD_CELL | OPTION_FIELD_CLICKHERE;

	if(a_nOption & OPTION_FIELD_CLICKHERE)
	{
		clickhere::ClickHere* pClickhere = GetCurClickhereField();
		if(pClickhere)
		{
			pClickhere->UpdateFieldName(a_strFieldName);
			pClickhere->UpdateDirective(a_strDirection);
			pClickhere->UpdateHelpState(a_strMemo);
			setModifiedFlag(BrTRUE);
			return BrTRUE;
		}
	}

	if(a_nOption & OPTION_FIELD_CELL)
	{
		CFrame* pFrame = BrNULL;
		if(!m_TableEngine->isCellMarked())
		{
			pFrame = pCaret->getFrame();
			if(pFrame && pFrame->isCell())
			{
				pFrame->setHwpFieldName(a_strFieldName);
				setModifiedFlag(BrTRUE);
				return BrTRUE;
			}
		}
		else
		{
			CObArray *pFrameSetArray = BrNULL;
			pFrameSetArray = m_TableEngine->getMarker()->getMarkingFrameSets();
			if(pFrameSetArray)
			{
				CFrameSet* pFrameSet = BrNULL;
				CFrame* pCellFrame  = BrNULL;
				CElement* pElement = BrNULL;
				BrINT nSize = pFrameSetArray->GetSize();
				for (BrINT i =0 ; i < nSize ; i++)
				{
					pFrameSet = (CFrameSet *)pFrameSetArray->GetAt(i);
					if(pFrameSet)
					{
						pElement = pFrameSet->getFirst();
						while (pElement != BrNULL)
						{
							pCellFrame = pElement->getFrame();
							if(pCellFrame)
							{
								pCellFrame->setHwpFieldName(a_strFieldName);
								setModifiedFlag(BrTRUE);
							}
							pElement = pFrameSet->getNext(pElement);
						}
					}
				}
				return BrTRUE;
			}
		}
	}
	return BrFALSE;
}

//���� ĳ���� clickhere*�� ��ȯ
clickhere::ClickHere* BoraDoc::GetCurClickhereField()
{
	CCaret* pCaret = getCaret();
	if(!pCaret)
		return BrNULL;
#if 0
	CLocation oLoc;
	oLoc.setLocation(pCaret->getLine(), pCaret->getCol());

	CRange rngField;
	rngField.setRange(&oLoc, &oLoc);

	if(rngField.expandRangeToPair(BrTRUE))
	{
		CCharSet* pLink = rngField.getBeginLoc().getCharSet();
		if(pLink && pLink->isClickhereBeginLink() && getClickHereHandler()->size() > pLink->getCode())
		{
			CClickhere* pClickhere = getClickHereHandler()->at(pLink->getCode());
			return pClickhere ? pClickhere : BrNULL;
		}
	}
#endif
	if(pCaret->isCaretNormalOrMarking())
	{
		CLine* pLine = pCaret->getLine();
		if(pLine == BrNULL)
			return BrNULL;

		BrINT i = pCaret->getCol();
		CCharSet* pClickhereLink = BrNULL;
		while(pLine && pLine->IsClickHereLine())
		{
			for(;i<pLine->getCharNum();i++)
			{
				pClickhereLink = pLine->getCharSet(i);
				if(pClickhereLink && pClickhereLink->isClickhereEndLink())
				{
					return getClickHereHandler()->find(pClickhereLink->getCode());
				}
			}
			pLine = pLine->getNext();
			if(pLine)
				i = 0;
		}
	}

	return BrNULL;
}

//���� ĳ���� frame�� field�� ��� frame*�� ��ȯ
CFrame* BoraDoc::GetCurFrameField()
{
	CCaret* pCaret = getCaret();
	if(!pCaret)
		return BrNULL;

	CFrame* pFrame = pCaret->getFrame();
	if(!pFrame)
		return BrNULL;

	return pFrame->isHwpFieldFrame() ? pFrame : BrNULL;
}

/*
  ���� �߿� ������ �ʵ尡 �����ϴ��� �˻��Ѵ�.
  Parameters
	strFieldName
		ã���� �ϴ� �ʵ� �̸�
  Return Values
	�����ϸ� True
*/
BrBOOL	BoraDoc::FieldExist(BString strFieldName, BrINT32 a_nFieldNum)
{
	clickhere::ClickHere* pClickHere = BrNULL;
	if(getClickHereHandler())
		pClickHere = getClickHereHandler()->get_clickhere( strFieldName, a_nFieldNum );
	//����Ʋ.
	if(pClickHere)
		return BrTRUE;
	else
	{
		CFrame* pTargetFrame = GetFieldCellFrame(strFieldName, a_nFieldNum);
		if(pTargetFrame)
			return BrTRUE;
	}

	return BrFALSE;
}


BrINT BoraDoc::CurFieldState()
{
	const BrINT CUR_FIELD_CELL = 0x01;
	const BrINT CUR_FIELD_CLICKHERE = 0x02;
	const BrINT HAS_FIELD_NAME = 0x10;

	BrINT nRet = 0;
	clickhere::ClickHere* pClickhere = GetCurClickhereField();
	if(pClickhere)
	{
		nRet |= CUR_FIELD_CLICKHERE;
		if(pClickhere->FieldName().length() > 0)
			nRet |= HAS_FIELD_NAME;
	}
	else
	{
		//Caret ���� Ȯ�� �ʿ�
		CLine* pCurLine = BrNULL;
		if(m_Caret->isCaretNormal() || m_Caret->isCaretMarking())
			pCurLine = m_Caret->getLine();

		if(pCurLine)
		{
			CFrame* pFieldFrame = pCurLine->getFrame();
			if(pFieldFrame && pFieldFrame->isCell())
			{
				nRet |= CUR_FIELD_CELL;
				if(pFieldFrame->getHwpFieldName().length() > 0)
					nRet |= HAS_FIELD_NAME;
			}
		}
	}
	return nRet;
}

void	BoraDoc::renameField(BString a_strOldName, BrINT32 a_nOldNum, BString a_strNewName)
{
	if(a_strOldName.length() <= 0)
		return;
#if 0
	CClickhere* pClickHere = BrNULL;
	if(getClickHereHandler())
		pClickHere = getClickHereHandler()->getItem( a_strOldName, a_nOldNum);
	//����Ʋ.
	if(pClickHere)
	{
		pClickHere->setFieldName(a_strNewName);
		return;
	}
	else
	{
		CFrame* pTargetFrame = GetFieldCellFrame(a_strOldName, a_nOldNum);
		if(!pTargetFrame)
			return;
		pTargetFrame->setHwpFieldName(a_strNewName);
	}
#endif
	CRange rngField;
	BrHWPControlFieldType eFieldType = GetHwpControlCmdEngine()->getHwpFieldRange(a_strOldName, a_nOldNum, rngField);
	if(eFieldType == BR_HWPCONTROL_FIELDTYPE_CELL)
	{
		if(rngField.getBeginLoc().getLine())
		{
			CFrame* pFrame = rngField.getBeginLoc().getLine()->getFrame();
			if(pFrame)
			{
				pFrame->setHwpFieldName(a_strNewName);
				setModifiedFlag(BrTRUE);
			}
		}
	}
	else if(eFieldType == BR_HWPCONTROL_FIELDTYPE_CLICKHERE)
	{
		CCharSet* pLink = rngField.getBeginLoc().getCharSet();
		if(pLink && pLink->isClickhereBeginLink())
		{
			clickhere::ClickHere* pClickhere = getClickHereHandler()->find(pLink->getCode());
			if(pClickhere)
			{
				pClickhere->UpdateFieldName(a_strNewName);
				setModifiedFlag(BrTRUE);
			}
		}
	}
}

BrBOOL	BoraDoc::isApiModeForFormMode()
{
	if(!m_bUseAPIMode)
		return BrTRUE;
	if(!g_pBInterfaceHandle->m_bOcx)
		return BrTRUE;
	if(!(isFromHwp() || isFromOdt()))
		return BrTRUE;
	if(!getFormModeForHWP())
		return BrTRUE;
	//API ���۽ÿ��� CellMaking, Caret Update ��ȿ��.
	if(m_bHwpCtrlApiMode)
		return BrTRUE;

	return BrFALSE;
}

#endif //USE_HWP_CONTROL



int	BoraDoc::GetFieldRange(BString &strFieldName, BrINT a_nFieldNum, BrBOOL bOnlyText,  CRange &range  )
{
#ifdef USE_HWP_CONTROL
	CLine		*pLine = getFirstLine();
	if( !pLine )
		return -1;

	CFrame	*pFrame = pLine->getFrame();
	if( !pFrame )
		return -1;

	clickhere::ClickHere* pClickhere = getClickHereHandler()->get_clickhere(strFieldName, a_nFieldNum);

	if ( pLine && pClickhere )
	{
		//int nID = pClickhere->ID();
		range.getBeginLoc().setLocation(pClickhere->BeginLoc().getLine(), bOnlyText == BrTRUE ? pClickhere->BeginLoc().getColumn()+1 : pClickhere->BeginLoc().getColumn());
		range.getEndLoc().setLocation(pClickhere->EndLoc().getLine(), bOnlyText == BrTRUE ? pClickhere->EndLoc().getColumn() : pClickhere->EndLoc().getColumn()+1);
		/*if( pFrame->GetFieldRange( nID, bOnlyText, range ) )
			return nID;*/
		return pClickhere->ID();
	}
#endif
	//g_pAppStatic->nFieldCounter=-1;
	return -1;
}


CFrame*	BoraDoc::GetFieldCellFrame(BString &strFieldName, BrINT32 a_nFieldNum)
{
#ifdef USE_HWP_CONTROL

	if(a_nFieldNum < 0)
		a_nFieldNum = 0;

	CFrame		*pFrame = BrNULL;
	BrUINT32	nCurFieldNum = 0;

	//g_pAppStatic->nFieldCounter=-1;
#if 0
	pFrame = m_AFrameList->getFirst();
	while(pFrame)
	{
		if(pFrame->isTable())
		{
			CBTable *pTable = (CBTable *)pFrame->getSubFrame();
			CCellList *pCellList = pTable->getCellList();

			CBCell *pCell = BrNULL;

			while (BrNULL != pCellList)
			{
				pCell = pCellList->getFirstCell();
				while (BrNULL != pCell)
				{
					CFrame* pCellFrame = pCell->getFrame();
					if(pCellFrame->getHwpFieldName().compare(strFieldName) == 0)
					{
						CLine* pFirstLine = pCellFrame->getFirstLine();
						CLine* pLastLine = pCellFrame->getLastLine();
						if(nCurFieldNum == a_nFieldNum)
						{
							if(!pFirstLine || !pLastLine)
								return BrNULL;

							return pCellFrame;
						}
						else
							nCurFieldNum++;


					}
					pCell = pCell->getNext();
				}
				pCellList = pCellList->getNext();
			}
		}
		pFrame = m_AFrameList->getNext(pFrame);
	}
#else

	CRange rngField;

	BrHWPControlFieldType eFieldType = GetHwpControlCmdEngine()->getHwpFieldRange(strFieldName, a_nFieldNum, rngField);
	if(eFieldType == BR_HWPCONTROL_FIELDTYPE_CELL)
	{
		if(rngField.getBeginLoc().getLine())
			return rngField.getBeginLoc().getLine()->getFrame();
	}

#endif
#endif
	return BrNULL;
}


/*
  ������ �ʵ�� ĳ���� �̵��Ѵ�.
  Parameters
	strFieldName
		�ʵ� �̸�
	bStart
		�ʵ��� ó��(True)���� �̵����� ��(False)���� �̵����� �����Ѵ�.
		bSelect�� True�� �����ϸ� ���õȴ�. �����ϸ� True�� �����ȴ�.
	bSelect
		�ʵ� ������ �������� ��������(True), ĳ���� �̵�����(False) �����Ѵ�.
		�����ϸ� False�� �����ȴ�.
  Return Values
	�����̸� True ���и� False
*/
BrBOOL	BoraDoc::MoveToField(BString &strFieldName, BrINT a_nFieldNum, BrBOOL bOnlyText, BrBOOL bStart, BrBOOL bSelect , BrBOOL a_bEx )
{
	CCmdEngine* pCmdEngine = getCmdEngine();
	if(!pCmdEngine)
		return BrFALSE;
#ifdef USE_HWP_CONTROL
	CheckCaretPositionRestorer restorer(!a_bEx);
#endif	//USE_HWP_CONTROL
	//Cell Field�̰� bSelect�� ��� ���� ������ Ctrl ����ŷ �����̹Ƿ� cancelProcess�� ȣ������ �ʴ´�.
	//�� ��찡 �ƴ� ��쿡 ���� cancelProcess�� ȣ��
	//pCmdEngine->cancelProcess();
	CCaret* pCaret = getCaret();
	CFrame* pFrame = GetFieldCellFrame( strFieldName, a_nFieldNum );

#ifdef USE_HWP_CONTROL
  HandsPointer_BeforeRunClickHere();
#endif

	if( pFrame )
	{
		if( bSelect )
		{
			pCaret->update( pFrame->getFirstLine() , 0, BR_CARET_NORMAL );
			pCaret->setCaretStatus(BR_CARET_OFF);

			//���İ� ������ �����.
			if(pFrame->isCell())
			{
				m_TableEngine->getMarker()->setHwpOneMode();
				m_TableEngine->getMarker()->newMarkCell(pFrame->getCell());
			}
		}
		else
		{
			pCmdEngine->cancelProcess();

			if(bStart)
			{
				pCaret->update( pFrame->getFirstLine() , 0  , BR_CARET_NORMAL);
			}
			else
			{
				pCaret->update(pFrame->getLastLine() ,pFrame->getLastLine()->getCharNum()-1, BR_CARET_NORMAL);
			}
		}

		if( a_bEx )
			getCmdEngine()->checkCaretPosition(getCaret()->getLine(), getCaret()->getCol());

#ifdef USE_HWP_CONTROL
    HandsPointer_RunClickHere();
#endif

		return BrTRUE;
	}

	pCmdEngine->cancelProcess();
	CRange range;
	int nID = GetFieldRange( strFieldName, a_nFieldNum, bOnlyText, range );

	if( nID != -1 )
	{
		if( bSelect )
		{
			pCaret->updateMS( range.getBeginLoc().getLine() , range.getBeginLoc().getColumn() );
			pCaret->update(range.getEndLoc().getLine() , range.getEndLoc().getColumn(), BR_CARET_MARKING);

			if( !bOnlyText )
			{
				pCaret->setFieldID( nID );
			}
		}
		else
		{
			if(bStart)
			{
				pCaret->update( range.getBeginLoc().getLine() , range.getBeginLoc().getColumn() , BR_CARET_NORMAL);
				if( !bOnlyText )
				{
					pCaret->setFieldID( nID );
				}
			}
			else
			{
				pCaret->update(range.getEndLoc().getLine() , range.getEndLoc().getColumn(), BR_CARET_NORMAL);
				if( bOnlyText )
				{
					pCaret->setFieldID( nID );
				}
			}
		}

		if( a_bEx )
			getCmdEngine()->checkCaretPosition(getCaret()->getLine(), getCaret()->getCol());

#ifdef USE_HWP_CONTROL
    HandsPointer_RunClickHere();
#endif

		return BrTRUE;
	}
	//g_pAppStatic->nFieldCounter=-1;

#ifdef USE_HWP_CONTROL
  HandsPointer_RunClickHere();
#endif

	return BrFALSE;
}


/*
void BoraDoc::ListupFrameList(CFrameList *pFrameList, CImageArray *pArray, int *pUsed)
{
	ASSERT(pFrameList);
	CFrame *pCellFrame, *pFrame = pFrameList->getFirst();
	CFrame *pImg;
	int nID, nIndex=-1;

	while(pFrame)
	{
		if (pFrame->isGroup())
		{
			CFrameList *pList = (CFrameList *)pFrame->getSubFrame();
			ListupFrameList(pList, pArray, pUsed);
		}
		if (pFrame->isFillImage())
		{
			pImg = pFrame;
			if (nIndex != -1)
				pUsed[nIndex]++;
			nID = pImg->getBorder()->getImageAttr()->GetRawID();
			nIndex = pArray->GetIndex(nID);
			if (nIndex != -1)
				pUsed[nIndex]++;
		}

		if (pFrame->isTable())
		{
			CBTable *pTable = (CBTable *)pFrame->getSubFrame();
			CCellList *pCellList = pTable->getCellList();
			CBCell *pCell;

			while (pCellList)
			{
				pCell = pCellList->m_pCell;

				while (pCell)
				{
					pCellFrame = pCell->getFrame();

					if (pCellFrame->isFillImage())
					{
						pImg = pCellFrame;
						nID = pImg->getBorder()->getImageAttr()->GetRawID();
						nIndex = pArray->GetIndex(nID);
						if (nIndex != -1)
							pUsed[nIndex]++;
					}

					pCell = pCell->getNext();
				}

				pCellList = pCellList->m_pNext;
			}
		}

		pFrame = pFrameList->getNext(pFrame);
	}
}
*/

/* jkjung
void BoraDoc::RemoveUnusedImageObj()
{
	// == remove unused image data
	int nIndex, nID;
	CImageArray *pArray = getImageArray();
	int nCount = pArray->GetSize();

	if (0 == nCount)
		return;

	int *pUsed = (int *)calloc(BrSizeOf(int), nCount);

	CFrameList* pFrameList = getAFrameList();
	ListupFrameList(pFrameList, pArray, pUsed);

	pFrameList = getMstAFrameList();
	ListupFrameList(pFrameList, pArray, pUsed);

	nID = getTileImageID();
	if (nID)
	{
		nIndex = pArray->GetIndex(nID);
		if (nIndex != -1)
			pUsed[nIndex]++;
	}
	pArray->RemoveUnused(pUsed);
	BrFree(pUsed);
}
*/

// nLeft, nTop, nRight, nBottom : mm unit
/* for speed
void BoraDoc::resetWebPageInfo(int nLeft, int nTop, int nRight, int nBottom)
{
	// reset page info for Web View
    CPage *pWebPage = m_WebPageArray->getPage(1);
    if (BrNULL == pWebPage)
		return;

	// reset column info
	CPaperSize	*pPaperSize = pWebPage->getPaperSize();
	pWebPage->getColumn()->initForWebPage(pPaperSize, nLeft, nTop, nRight, nBottom);

	// reset basic frame rect
	CFrame *pFrame = pWebPage->getFirstBasic();

	if (BrNULL == pFrame)
		return;

	BRect *pRect = pFrame->getFrameRect();

	pRect->nLeft = CDrawUnit::mmToTWIP(nLeft);
	pRect->nTop = CDrawUnit::mmToTWIP(nTop);
	pRect->nRight = pPaperSize->m_nWidth - CDrawUnit::mmToTWIP(nRight);
	pRect->nBottom = pPaperSize->m_nHeight - CDrawUnit::mmToTWIP(nBottom);
}
*/

CPage *BoraDoc::getEditingPage(int nPgNum)
{
	CPageArray *pPgArray = getEditingPageArray();
	if ( !pPgArray )	return BrNULL;

		if(isEditSlideNote() && !m_bThumbnailDraw && !g_pAppStatic->isPrtPreview())
		{
			CPPTNoteMaster* pPNM = getPPTNoteMaster();
			return pPNM->GetNotePage(nPgNum);
		}
		else
			return pPgArray->getPage(nPgNum);
}

// for html speed, 2007.2.13
/*
#ifdef IMPORT_HTML
void	BoraDoc::setCompanyVersion( BrLPCTSTR lpszCompany )
{
	CHString str( lpszCompany );

	str.TrimLeft();
	str.TrimRight();

	if( str.IsEmpty() )
		m_nCompanyVersion = VER_BORATECH;	//	�⺻
	else if( str.CompareNoCase( _T("DANAWA") )==0 )
		m_nCompanyVersion = VER_DANAWA;	//	1
	else if( str.CompareNoCase( _T("HYOSUNG") )==0 )
		m_nCompanyVersion = VER_HYOSUNG;	//	2
	else if( str.CompareNoCase( _T("SDS") )==0 )
		m_nCompanyVersion = VER_SDS;		//	3
	else if( str.CompareNoCase( _T("HYUNDAI_HI") )==0 )
		m_nCompanyVersion = VER_HYUNDAI_HI;	//	4
	else if( str.CompareNoCase( _T("AMWAY") )==0 )
		m_nCompanyVersion = VER_AMWAY;	//	5
	else if( str.CompareNoCase( _T("MAILBOOK") )==0 )
		m_nCompanyVersion = VER_MAILBOOK;	//	6
	else if( str.CompareNoCase( _T("DONGYANG_SEC") )==0 )
		m_nCompanyVersion = VER_DONGYANG_SEC;	//	7
	else if( str.CompareNoCase( _T("NEXZONE") )==0 )
		m_nCompanyVersion = VER_NEXZONE;	//	8
	else if( str.CompareNoCase( _T("KYOBO_LIFE") )==0 )
		m_nCompanyVersion = VER_KYOBO_LIFE;	//	9
	else if( str.CompareNoCase( _T("HANGUK_SEC") )==0 )
		m_nCompanyVersion = VER_HANGUK_SEC;	//	10
	else if( str.CompareNoCase( _T("SAMSUNG_HQ") )==0 )
		m_nCompanyVersion = VER_SAMSUNG_HQ;	//	11
	else if( str.CompareNoCase( _T("HALLA_CC") )==0 )
		m_nCompanyVersion = VER_HALLA_CC;	//	12
	else
		m_nCompanyVersion = -1; //�˼� ���� ����Ʈ
}

#endif //IMPORT_HTML
*/

#ifdef IMPORT_HTML
// anchored frame�� width�� parent frame�� width���� ū ��� �ٽ� ���� �� �ش�.
// HTML import�� ����� �߸� �Ǵ� ��찡 ���� �߻��ؼ�....
void BoraDoc::adjustWidthOfAnchoredFrame(CFrame *pFrame, CFrame *pParent)
{
	if ( pFrame==BrNULL || pParent==BrNULL ) return;

	if ( pFrame->isAnchored() )	{
		bool	bChange = false;
		BRect rc = pFrame->getFrameRect();

		// check width
		/*if ( pFrame->GetHtmlWidth() < 0 && pFrame->GetHtmlWidth() >= -100 )
		{
			int		nWidth = (int)(((pParent->width(BrFALSE) - (pParent->getBorderMarginLeft()+pParent->getBorderMarginRight())) * -pFrame->GetHtmlWidth())/100.);
			if ( rc.getWidth() !=  nWidth )
			{
				rc.nRight = rc.nLeft + nWidth;
				bChange = true;
			}
		}
		else */  if ( pParent->isCell() && (pFrame->width()+pParent->getBorderMarginLeft()+pParent->getBorderMarginRight()) > pParent->width() )
		{
			rc.nLeft = pParent->left() + pParent->getBorderMarginLeft();
			rc.nRight = pParent->right() - pParent->getBorderMarginRight();
			bChange = true;
		}

		// check height
		if ( pFrame->GetHtmlHeight() < 0 && pFrame->GetHtmlHeight() >= -100 )
		{
			int		nParentHgt;

			if ( pParent->isBasic() )
			{
				//BRect tmpRect;
				//tmpRect.m_pView->GetClientRect(tmpRect);
				nParentHgt = m_CmdEngine->distanceLogical2DocX( 320 /*tmpRect.Height()*/ );//������ ����.
			}
			else	nParentHgt = pParent->height();

			int		nHeight = (int)(((nParentHgt - (pParent->getBorderMarginTop()+pParent->getBorderMarginBottom())) * -pFrame->GetHtmlHeight())/100.);

			// height�� 100%�̰� �ۿ� �ִ� table�� height�� ���� �ʴ� ��� (for ��������)
			if ( pParent->isCell() )	{
				CBCell	*pCell = pParent->getCell();
				if ( pCell )	{
					CFrame	*pTableFrame = pCell->getTableFrame();
					if ( pTableFrame && pTableFrame->getAnchorLine() && pTableFrame->getAnchorLine()->getPrev()==BrNULL &&
						pTableFrame->getAnchorLine()->getNext()==BrNULL )	{
						CFrame	*pGrandParent = pTableFrame->getAnchorLine()->getFrame();
						if ( pGrandParent && pGrandParent->isCell() )	{
							nHeight += (int)(pGrandParent->height() - pTableFrame->height());
						}
					}
				}
			}

			if ( rc.getHeight() !=  nHeight ) {
				rc.nBottom = rc.nTop + nHeight;
				bChange = true;
			}
		}

		if( rc.nLeft >= rc.nRight )
			rc.nRight = rc.nLeft + 1;


		if ( bChange )	CTextProc::resizeFrame(this, pParent->getPage(), pFrame,  rc);
	}
}

void BoraDoc::adjustWidthOfAnchoredFrameInText(CFrame *pFrame)
{
	if ( pFrame==BrNULL || !pFrame->isText() ) return;

	CCharSetArray *pLinkArray;
	CCharSet      *pLink;
	CFrame       *pObject;
	int           nCol, nCharNum;

	CLineList *pLineList = (CLineList *)pFrame->getSubFrame();
	if(pLineList==BrNULL)  return;

	//PoTextAttHandler  *pTextAttArray = getTextAttHandler();
	PoTextAtt	cNewTextAtt;

	CLine  *pLine = pLineList->getFirst();
	while(pLine)
	{
		if ( pLine->isDirty() )	{
            CTextProc::arrangeOneLine(this, pLine);
		}
		// HandsPointer������ NON_BREAKING_SPACE�� SPACE�� ���Ϳ��� �̹� �ٲپ���. for html speed 2007.3.5
		if( pLine->getAnchorFlag() )
		{
			pLinkArray = pLine->getCharSetArray();
            if ( pLinkArray == BrNULL )
              break;

			nCharNum = pLinkArray->GetSize();

			for(nCol=0; nCol<nCharNum; nCol++ )
			{
				pLink = pLinkArray->getCharSet(nCol);

				/*
				if ( pLink && pLink->isTextLink() )
				{
					// Non-Breaking Space�� main���� �ٽ� space�� �ٲپ� �ش�.
					if ( pLink->getCode()==NON_BREAKING_SPACE )
					{
						// Non-Breaking Space�� CR�� �ִ� ���� space�� ���� ������.
						// BWP���� HTML�� ����� �Ϻη� ���� ���� �ڵ��̱� ������...
						if ( nCol==0 && nCharNum==2 && pLine->isBothLine() )
						{
							pLinkArray->RemoveAt(0);
						}
						else
						{
							// change code (NON_BREAKING_SPACE => SPACE)
							pLink->setCode(SPACE);

							// ������ĭ���� setting
							cNewTextAtt = *( (PoTextAtt*)pTextAttArray->GetAt(pLink->getAttrID()) );
							pLink->setAttrID(pTextAttArray->getAttrID( cNewTextAtt ));
						}
						// NON_BREAKING_SPACE�� SPACE code�� character width�� �ٸ��� ������
						// �ٽ� arrange�� �ʿ䰡 �ִ�.
						pLine->setDirtyFlag(BrTRUE);
					}
				}
				else if ( pLink && pLink->isAnchorLink() )
				*/
				if ( pLink && pLink->isAnchorLink() )
				{
					pObject = getAnchorFrame(pLink->getCode());

					if( pObject )
					{
						adjustWidthOfAnchoredFrame(pObject, pFrame);

						if( pObject->isGroup() )
							adjustWidthOfAnchoredFrameInGroup((CFrameList *)pObject->getSubFrame());
						else if( pObject->isTable() )
							adjustWidthOfAnchoredFrameInTable(pObject);
						else if( pObject->isText() )
							adjustWidthOfAnchoredFrameInText(pObject);

						// HTML���� LEFT or RIGHT align������ �ִ� ���
						// import�߿��� basic frame�� Ŀ�� �� ���� ������ ���⿡��  �ٽ� ����
					}
				}
			}
		}
		pLine = pLine->getNext();
	}
}

void BoraDoc::adjustWidthOfAnchoredFrameInGroup(CFrameList *pFrameList)
{
	CFrame *pFrame = pFrameList->getFirst();
	while(pFrame)
	{
		adjustWidthOfAnchoredFrame(pFrame, pFrame);

		if( pFrame->isGroup() )
			adjustWidthOfAnchoredFrameInGroup((CFrameList *)pFrame->getSubFrame());
		else if( pFrame->isTable() )
			adjustWidthOfAnchoredFrameInTable(pFrame);
		else if( pFrame->isText() )
			adjustWidthOfAnchoredFrameInText(pFrame);

		pFrame = pFrameList->getNext(pFrame);
	}
}

void BoraDoc::adjustWidthOfAnchoredFrameInTable(CFrame *pFrame)
{
	if ( BrNULL == pFrame || !pFrame->isTable() )
		return;

	CBCell *pCell;
	CCellList *pCellList;
	CFrame *pCellFrame;
	CBTable *pTable = (CBTable *)pFrame->getSubFrame();

	if (BrNULL == pTable)
		return;

	pCellList = pTable->getCellList();
	while ( pCellList ) {
		pCell = pCellList->getFirstCell();
		while ( pCell ) {
			pCellFrame = pCell->getFrame();
			if ( pCellFrame ) {
				adjustWidthOfAnchoredFrameInText(pCellFrame);
			}
			pCell = pCell->getNext();
		}
		pCellList = pCellList->getNext();
	}
}

// HTML���� VML data�� HTML Page layout�� ���Ե��� �ʱ� ������
// �̸� ���Խ�Ű�� ���Ͽ� VML data�� �ִ� ��ġ���� ������ �߰����� �ش�.
void BoraDoc::addEmptyLineForVML()
{
	if( g_pHtml->m_bHwpControl )
		return;

	int		nMaxEndDy = getMaxDocEndDyForSpecialFrame();
	if ( nMaxEndDy==0 )		return;

	CLine	*pLine = getFirstLine();
	if ( pLine==BrNULL )	return;

	CLine	*pLastLine;
	pLastLine = pLine->getLastLine();
	if ( pLastLine==BrNULL || pLastLine->getFrame()==BrNULL )	return;
	int		nLastLinePos = pLastLine->getFrame()->top()+pLastLine->getBasePos();

	if ( nMaxEndDy <= nLastLinePos )	return;

	int	nAddLineNum = (nMaxEndDy-nLastLinePos)/CDrawUnit::ptToTWIP(15)+1;
	if ( nAddLineNum<=0 )	return;

	CCharSet *pLink = pLastLine->getCharSet(pLastLine->getCharNum()-1);
	if ( pLink && pLink->isPageBreak() )	return;

	CLine	*pNewLine;
	CCharSetArray *pNewArray;
	CCharSet cLink;
	cLink.setAttrID(0);	// cLink.setAttrID(pLastLine->getCharSet(pLastLine->getCharNum()-1)->getAttrID());
	cLink.setCode(SOFT_ENTER);
	CLineList  *pLineList = pLastLine->getLineList();
	pLine = pLastLine;

	while ( nAddLineNum-- > 0 )
	{
		pNewLine = BrNEW CLine();
		pNewArray = BrNEW CCharSetArray();
		if ( nAddLineNum==0 )
			cLink.setCode(ASCII_CODE_CR);
		pNewArray->Add(cLink);
		pNewLine->setCharSetArray( pNewArray );
		// pNewLine->setParaID(0);
		pNewLine->setDirtyFlag(BrTRUE);
		pNewLine->setPosArrayFlag(BrFALSE);
		pLineList->insertAfter(pLine, pNewLine);
		pLine = pNewLine;
	}

	CTextProc::arrangeMarkingLines(this, pLastLine->getNext(), pLine);
}

int	BoraDoc::getMaxDocEndDyForSpecialFrame()
{
	int		nMaxEndDy = 0;
	BRect*  pRect;

	if (getBWPEngineMode() == EDITOR_PPT)
	{
		BRTHREAD_ASSERT(0); // PPT�� �� ��� ����� ����.. �������� ��� ���� �ȵ�.
		return 0;
	}

	CFrameList *pFrameList = getAFrameList();
	ASSERT_VALID(pFrameList);
	CFrame *pFrame = pFrameList->getFirst();

	//--- Scanning all Special FCS (First Item==>Last Item )
	while(pFrame)
	{
		// check float frame
		if ( !pFrame->isAnchored() )	{
			pRect = pFrame->getFrameRect();
			if ( pRect->nBottom > nMaxEndDy )	{
				nMaxEndDy = pRect->nBottom;
			}
		}
		pFrame = pFrameList->getNext(pFrame);
	}
	return nMaxEndDy;
}

#endif // IMPORT_HTML

#ifdef IMPORT_HTML
BrBOOL BoraDoc::IsHtmlInlineFrameOver()
{
	if( m_pInlineFrame == BrNULL )
		return BrFALSE;

	CTextProc::arrangeOneFrame( this , m_pInlineFrame );

	CCaret* pCaret = getCaret();
	if( pCaret )
	{
		CLine* pLine = pCaret->getLine();
		if( pLine )
		{
			CFrame* pFrame = pLine->getFrame();
			if( pFrame )
			{
				int LinePos = pLine->getBasePos() + pFrame->top();//CTextProc::arrangeOneLine( this , pLine , BrTRUE );
				if( LinePos > m_nInlineFrameHeight + m_pInlineFrame->top() )
					return BrTRUE;
			}
		}
	}

/*	if ( pLine==BrNULL )
		return BrFALSE;

	while( pLine )
	{
		if( pLine->isDirty() )
			CTextProc::arrangeOneLine( this , pLine , BrTRUE );
		if( pLine->getBasePos() >= m_nInlineFrameHeight + m_pInlineFrame->top() )
			return BrTRUE;
		pLine = pLine->getNext();
	}
*/

/*
	CTextProc::arrangeOneFrame( this , m_pInlineFrame );

	int inlineheight = m_pInlineFrame->height();
	if( m_nInlineFrameHeightMax == 0 )
	{
		if( inlineheight > m_nInlineFrameHeight )
		{
			m_nInlineFrameHeightMax  = inlineheight;
			return BrTRUE;
		}
	}
	else
	{
		if( inlineheight > m_nInlineFrameHeightMax )
		{
			return BrTRUE;
		}
	}
*/
	return BrFALSE;
}
#endif

#if defined(IMPORT_HTML) && defined(LOAD_ONE_PAGE_HTML)
// Basic Frame�� ������ ������ �ѹ� ���� ���� �ִ� ������ �Ѿ� ���� �� check
BrBOOL BoraDoc::IsReadOnePageHtml()
{
	CLine	*pLine = getFirstLine();
	if ( pLine==BrNULL )	return BrFALSE;

	CFrame	*pFrame = pLine->getFrame();
	if ( pFrame==BrNULL )	return BrFALSE;

	int		nOldRight;
	if( pFrame->isGaro() )
		nOldRight = pFrame->right();
	else
		nOldRight = pFrame->bottom();

	// basic frame�� ũ�⸦ ���� ũ��� �۰� �ؼ� arrange�Ѵ�..
	if( pFrame->isBasic() )
	{
		if( g_pHtml->is_load_from_clipboard() )
		{
			if( pFrame->isGaro() )
				pFrame->setRight(m_nOldBasicFrameRight);
			else
				pFrame->setBottom( m_nOldBasicFrameRight );
		}
		else
		{
			if( pFrame->isGaro() )
			{
				if( m_HtmlPageSize.cx != 0 )
					pFrame->setRight( m_HtmlPageSize.cx - ((m_HtmlPageSize.cx<=120) ? 0 : 120) );
				else
					pFrame->setRight(m_nOldBasicFrameRight);
			}
			else
			{
				if( m_HtmlPageSize.cy != 0 )
					pFrame->setBottom( m_HtmlPageSize.cy - ((m_HtmlPageSize.cy<=120) ? 0 : 120) );
				else
					pFrame->setBottom( m_nOldBasicFrameRight );
			}
		}
	}

	BrBOOL	bForceArrange = BrFALSE;
	while ( pLine )	{
		// ��Ȯ�� ����� ���Ͽ� arrange����...
		if ( pLine->isDirty() || bForceArrange )		{
			CTextProc::arrangeOneLine(this, pLine, BrTRUE);
			bForceArrange = BrTRUE;
		}
#ifdef	BWP_EDITOR
		if ( bForceArrange && pLine->getBasePos() >= ONE_PAGE_HTML_HGT*m_nHtmlPageCnt ) {
#else
		if ( bForceArrange && pLine->getBasePos() >= ONE_PAGE_HTML_HGT*m_nHtmlPageCnt ) {
#endif
			// ������ ������ CR�� �����ϴ� empty ������ �ƴϸ� �������� empty line�� �ϳ� ������ ������ ���ؼ�...
			CTextProc::arrangeMarkingLines(this, pLine->getNext(), BrNULL);
			pLine = pLine->getLastLine();
			int		nCharNum = pLine->getCharNum();
			if ( nCharNum>1 )	{
				CHtmlText::setCaretToFrame(this, pFrame);
#ifdef	BWP_EDITOR
				m_CmdEngine->doInsertCSTR("\n", 1, BrFALSE, BrFALSE);
#else
				m_CmdEngine->doInsertCSTR("\n", 1);
#endif
				CTextProc::arrangeMarkingLines(this, pLine, BrNULL);
			}

#ifdef	BWP_EDITOR
			m_nHtmlPageCnt++;
#else
			m_nHtmlPageCnt++;
#endif

			if( pFrame->isBasic() )
			{
				if( pFrame->isGaro() )
					pFrame->setRight(nOldRight/*g_pAppStatic->m_nHtmlVirtualFrameRight*/);
				else
					pFrame->setBottom(nOldRight/*g_pAppStatic->m_nHtmlVirtualFrameRight*/);
			}

			return BrTRUE;
		}
		pLine = pLine->getNext();
	}

	if( pFrame->isBasic() )
	{
		if( pFrame->isGaro() )
			pFrame->setRight(nOldRight/*g_pAppStatic->m_nHtmlVirtualFrameRight*/);
		else
			pFrame->setBottom(nOldRight/*g_pAppStatic->m_nHtmlVirtualFrameRight*/);
	}

	return BrFALSE;
}
#endif	// LOAD_ONE_PAGE_HTML


#if defined(IMPORT_HTML) && defined(LOAD_ONE_PAGE_HTML)
// html�� �Ϻθ� �о� ���� ��� �̸� BMV Data�� �� ����� �� �������� BWP Data�� ���� ������...
BrBOOL BoraDoc::ClearBasicLines()
{
	if (getBWPEngineMode() == EDITOR_PPT)
	{
		BRTHREAD_ASSERT(0); // PPT�� �� ��� ����� ����.. �������� ��� ���� �ȵ�.
		return BrFALSE;
	}

	getAFrameList()->removeAll();

	// BrDELETE all lines except last line
	CLine * pNext;
	CLine	*pLine = getFirstLine();
	if ( pLine==BrNULL )	return BrFALSE;
	CLineList	*pLineList = pLine->getLineList();

	CLine	*pLast = pLine->getLastLine();
	pLast = pLast->getPrev();

	// ������ ���� ������ �� ��ǥ�� ����� ���� �̸� ���� html �о� �ö� basic frame�� start y position���� setting
	int	y;
	if ( pLast )	y = pLast->getBasePos() + CTextProc::CalcLineSpace(this, pLast, BrTRUE);
	else			y = pLine->getBasePos() - pLine->getHeight();

	while ( pLine )	{
		pNext = pLine->getNext();
		if ( pNext==BrNULL )	break;
		pLineList->remove(pLine);
       pLine = pNext;
	}

	// basic frame�� ��ǥ�� �ٽ� setting
	CFrame	*pFrame = pLine->getFrame();
	pFrame->setTop(pFrame->top() + y);
	// ����� ũ�� ����...
	pFrame->setBottom(pFrame->bottom() + 100*ONE_PAGE_HTML_HGT);

	m_Caret->setCaretStatus(BR_CARET_OFF);

	return BrTRUE;
}
#endif	// LOAD_ONE_PAGE_HTML

#if defined(IMPORT_HTML) && defined(LOAD_ONE_PAGE_HTML) && defined(BWP_EDITOR)
BrBOOL BoraDoc::SetDoneBMVFlag(BrBOOL bDone)
{
	if (getBWPEngineMode() == EDITOR_PPT)
	{
		BRTHREAD_ASSERT(0); // PPT�� �� ��� ����� ����.. �������� ��� ���� �ȵ�.
		return BrFALSE;
	}
	// set bDoneBMV flag to all anchored frames
	CFrame *pFrame = getAFrameList()->getFirst();
	while ( pFrame )	{
		pFrame->setDoneBMV(bDone);
		pFrame = getAFrameList()->getNext(pFrame);
	}

	// set bDoneBMV flag to all lines except last line
	CLine	*pNext;
	CLine	*pLine = getFirstLine();
	if ( pLine==BrNULL )	return BrFALSE;

	while ( pLine )	{
		pNext = pLine->getNext();
		if ( pNext==BrNULL )	break;
		pLine->setDoneBMV(bDone);
		pLine = pNext;
	}

	setSetDoneBMV(bDone);

	return BrTRUE;
}
#endif	// LOAD_ONE_PAGE_HTML


void BoraDoc::ArrangeAllPage()
{
	if (EDITOR_PPT == m_nBWPEngineMode) {
		BRTHREAD_ASSERT(0);
		return;
	}

	setArrangeDuringImport(BrTRUE);
	ArrangeAnchorFrameList(m_AFrameList);               // Arrange anchor frames at basic frame
	ArrangeAnchorFrameList(m_AFrameList4HeaderFooter);  // Arrange anchor frames at header/footer
	ArrangeTypesetFrameList();                          // Arrange typeset frames
	ArrangeHeaderFooter();                              // Arrange header/footer frames
	ArrangeBatangPage();                                // Arrange batang(master) pages
	ArrangeWordMemo();                                  // Arrange Word Memo Frames
	setArrangeDuringImport(BrFALSE);
}


void BoraDoc::ArrangeAnchorFrameList(CFrameList* frame_list)
{
	CFrame* frame = frame_list? frame_list->getFirst(): BrNULL;
	while (frame) {
		ArrangeAnchorFrame(frame->getPage(), frame);
		frame = frame_list->getNext(frame);
	}
}


void BoraDoc::ArrangeAnchorFrame(CPage* page, CFrame* frame)
{
	if (BrNULL == page || BrNULL == frame)
		return;

	// if it has already arranged, no need checking arrange
	if (frame->getChkArrangeFlag() && g_BoraThreadAtom.m_nSaveStatus != SAVE_STATUS_PROGRESS)
		return;

	switch (frame->GetClass()) {
#ifdef DANDONG_SMARTART
		case DIAGRAMXENTRY:  FALLTHROUGH;
#endif  // DANDONG_SMARTART
		case FLOATFRAME: {
			BrShape* shape = frame->getBorder();
			//2013. 11.15 ������. TextArea�� doc�� ppt�� �ٸ� ��찡 �־ �߰�.
			if (shape)
				shape->setTextMargin(frame->getFrameRect(), isFromWordType());
			ArrangeTextFrame(frame);
			break;
		}
		case HEADFRAME:  FALLTHROUGH;
		case FOOTFRAME:  FALLTHROUGH;
		case CELLFRAME: {
			ArrangeTextFrame(frame);
			break;
		}
		case TABLEFRAME: {
			if (BrFALSE == frame->isAnchored())
				ArrangeTableFrame(page, frame);
			break;
		}
#ifdef DANDONG_SMARTART //[2011.12.12][������][TID:1275] �ܵ� SmartArt Export Merge
		case DIAGRAMXFRAME:  FALLTHROUGH;
#endif  // DANDONG_SMARTART
		case GROUPFRAME: {
			CFrameList* frame_list = dynamic_cast<CFrameList*>(frame->getSubFrame());
			ArrangeAnchorFrameList(frame_list);
			break;
		}
	}
	frame->setChkArrangeFlag(BrTRUE);
}


void BoraDoc::ArrangeTextFrame(CFrame* frame)
{
	PO_THREAD_TRY_BLOCK {
		shorten_text_frame_post_processor::scoped_callstack_atomic_t scoped_callstack_lock;
		// frame rearrange
		CLineList* line_list = dynamic_cast<CLineList*>(frame->getSubFrame());
		CLine* line = line_list? line_list->getFirst(): BrNULL;
		if (BrNULL == line)
			return;
		BrBOOL is_dirty = line->isDirty() ||
			                BrFALSE == line->getFlagOfPosArray() ||
			                0 == line->GetCharSetArrSize();
		if (frame->isHeaderFooter() && is_dirty)
			CTextProc::arrangeAndExpandFrame(this, line, BrNULL, EXPAND, 0);
		else if (frame->isSpecial())
			frame::text::Layout::arrange(frame);
		else
			ArrangeLines(line, line_list->getLast());
	}
	PO_THREAD_CATCH_BLOCK {
		if (shorten_text_frame_post_processor::callstack_locked > 0)
			std::atomic_fetch_sub(&shorten_text_frame_post_processor::callstack_locked, 1); // IMPORTANT!
	}
	PO_THREAD_END
}


void BoraDoc::ArrangeLines(CLine* start, CLine* finish)
{
	BrAtomicOp
	for (CLine* line = start; BrTRUE; line = line->getNext()) {
		// check dirty line
		if (line->isDirty() || BrFALSE == line->getFlagOfPosArray() || 0 == line->GetCharSetArrSize()) {
			CFrame* frame = line->getFrame();
			if (frame && frame->isHeaderFooter()) {
				CTextProc::arrangeAndExpandFrame(this, line->getFirstLine(), BrNULL, EXPAND, 0);
			}
			else {
				CPage* page = frame->getPage();
				BrINT num = page? page->getPageNum(): frame->getPageNum();
				CTextProc::arrangeMarkingLines(this, line, finish, BrFALSE, num + 1, BrTRUE);
			}
			break;
		}
		if (line == finish)
			break;
	}
}


void BoraDoc::ArrangeTableFrame(CPage* page, CFrame* frame)
{
	if (BrNULL == frame || BrFALSE == frame->isTable())
		return;

	CBTable* table = dynamic_cast<CBTable*>(frame->getSubFrame());
	CCellList* cell_list = table? table->getCellList(): BrNULL;
	if (BrNULL == cell_list || BrNULL == cell_list->getFirstCell())
		return;

	while (cell_list) {
		CBCell* cell = cell_list->getFirstCell();
		while (cell) {
			CFrame* cell_frame = cell->getFrame();
			if (cell_frame)
				ArrangeAnchorFrame(page, cell_frame);
			cell = cell->getNext();
		}
		cell_list = cell_list->getNext();
	}
}


// import �߿� page�� �þ�鼭 Header, Footer� floating frame�� anchor�Ǿ� �ִ� ���
// ��ġ�� �� �� ��Ƽ� ����.
void BoraDoc::ArrangeTypesetFrameList(BrINT prev_page_num/*=0*/)
{
	if (EDITOR_PPT == m_nBWPEngineMode) {
		BRTHREAD_ASSERT(0);
		return;
	}

	const BrINT total_page = getTotalPage();
	for (BrINT i = prev_page_num + 1; i <= total_page; ++i) {
#ifdef BWP_EDITOR
		CPage* page = getEditingPageArray()->getPage(i);
#else  // BWP_EDITOR
		CPage* page = getPageArray()->getPage(i);
#endif  // BWP_EDITOR
		if (page)
			ArrangeAnchorFrameList(page->getTFrameList());
	}
}


// [2012.11.26][TID:7609] Header/Footer ����ȭ - Check Arranging
// is_only_false_frame == BrTRUE�̸�, pFrame->getChkArrangeFlag() == BrFALSE�� Frame�� Arrange
void BoraDoc::ArrangeHeaderFooter(BrBOOL is_only_false_frame)
{
	setArrangeHf(BrTRUE);

	// Typeset Header/Footer
	if (isFromHwp()) {
		ArrangeHwpHeaderFooter(is_only_false_frame);
		return;
	}

	auto ArrangeHFs = [&](BrINT count, std::function<CHeaderFooter* (BrINT)> GetHF) {
		for (BrINT i = 0; i < count; i++)
			ArrangeWordHeaderFooter(GetHF(i), is_only_false_frame);
	};

#ifdef SUPPORT_ODT_HEADER_FOOTER
	// PageStyle Header/Footer
	if (isFromOdt()) {
		auto GetHF = [&](BrINT i) {
			CPageStyle* page_style = m_PageStyleArray->at(i);
			return page_style? page_style->getHeaderFooter(): BrNULL;
		};
		ArrangeHFs(m_PageStyleArray->size(), GetHF);
		return;
	}
#endif  // SUPPORT_ODT_HEADER_FOOTER

	// Section Header/Footer
	auto GetHF = [&](BrINT i) {
		CLine* line = SectionLineVector.GetAt(i);
		CSectionInfomation* section_info = line? line->getSectionInformation(): BrNULL;
		return section_info? section_info->getHeaderFooter(): BrNULL;
	};
	ArrangeHFs(SectionLineVector.size(), GetHF);
}


//[2014.01.14][TID:22783] HWP �Ӹ���/�ٴڱ� ����
void BoraDoc::ArrangeHwpHeaderFooter(BrBOOL is_only_false_frame)
{
	if (BrFALSE == isFromHwp())
		return;

	BVector<CFrame> frame_arr;
	getAllHeaderFooterFrames(frame_arr);

	auto IsEqualLeftRight = [](CFrame* f, BrINT l, BrINT r) {
		return f->left() == l && f->right() == r;
	};

	for (BrINT i = 0, size = frame_arr.size(); i < size; ++i) {
		CFrame* frame = frame_arr[i];
		if (BrNULL == frame || BrFALSE == frame->isHeaderFooter())
			continue;

		// Section ������ŭ ������ Header/Footer Frame�� ����� (Width�� �ٸ� Header/Footer ó���ϱ� ����)
		BrBOOL is_created = BrFALSE;

		for (BrINT j = 0, count = SectionLineVector.size(); j < count; ++j) {
			CLine* line = SectionLineVector[j];
			CSectionInfomation* section_info = line? line->getSectionInformation(): BrNULL;
			if (BrNULL == section_info)
				continue;

			const BrINT page_width = section_info->getPageWidth();
			const BrINT page_height = section_info->getPageHeight();

			const BrRect& margin = section_info->getPageMargin();
			const BrINT gutter_margin = section_info->getGutterMargin();
			BrINT left = margin.left + (m_bGutterAtTop? 0: gutter_margin);
			BrINT right = page_width - margin.right;

			if (0 == j) {  // First Section
				if (is_only_false_frame && frame->getChkArrangeFlag())
					continue;

				BRect* rect = frame->getFrameRect();
				rect->SetLeft(left);
				rect->SetRight(right);
				//[2013.03.20][TID:26126] Page Layout(Page Direction) ����� Header/Footer ��ġ �ٽ� ���
				if (frame->isHeader()) {
					rect->SetTop(margin.top);
					rect->SetBottom(rect->Top() + section_info->getHeaderMargin());
				}
				else if (frame->isFooter()) {
					rect->SetBottom(page_height - margin.bottom);
					rect->SetTop(rect->Bottom() - section_info->getFooterMargin());
				}
				is_created = BrTRUE;
			}
			else {  // Second Section ~
				// Width�� �ٸ� Header/Footer ó��
				if (IsEqualLeftRight(frame, left, right))
					continue;

				// Org header/footer frame�� m_pFrameList�� new CFrameList�� �޾� �ݴϴ�.
				CFrameList* frame_list = frame->getFrameList();
				if (BrNULL == frame_list) {
					frame_list = BrNEW CFrameList();
					frame_list->setParentFrame(frame);
					frame->setFrameList(frame_list);
				}

				// Width�� ���� Header/Footer Frame�� �̹� �����Ѵٸ�
				// ���ο� ������ header/footer Frame�� ������ �ʽ��ϴ�.
				BrBOOL is_equal_width = BrFALSE;
				CFrame* frm = frame_list->getFirst();
				while (frm) {
					if (IsEqualLeftRight(frm, left, right)) {
						is_equal_width = BrTRUE;
						break;
					}
					frm = frame_list->getNext(frm);
				}
				if (is_equal_width)
					continue;

				BrRect gutter = {gutter_margin, 0, 0, 0};
				CHeaderFooter* header_footer = section_info->getHeaderFooter();  // ZPD-4080
				BrBOOL is_header = frame->isHeader();
				CFrame* blank_frame = (is_header || frame->isFooter())?
				            m_HeaderFooterEngine->MakeBlankFrame(is_header, page_width, page_height,
				                                                       margin, gutter, header_footer):
				            BrNULL;
				if (BrNULL == blank_frame)
					continue;

				blank_frame->setHeaderFooterType(frame->getHeaderFooterType());

				// ���ο� ������ Header/Footer Frame�� ���� ��ٸ�, Org frame�� m_pFrameList�� �޾� �ݴϴ�
				frame_list->insertAtTail(blank_frame);

				blank_frame->updatePage(line->getPage());
				blank_frame->deleteAllLines();  //��� Character�� �����ؾ� frame�� blank_frame���� ���ϼ��� ������
				blank_frame->setChkArrangeFlag(BrTRUE);
				is_created = BrTRUE;
			}
		}

		if (is_created) {
			CPage* page = getHeaderFooterStartPage(frame);
			if (BrNULL == page)
				page = m_PageArray->GetFirst();
			frame->updatePage(page);
			frame->setChkArrangeFlag(BrTRUE);
			CLine* first_line = frame->getFirstLine();
			if (first_line) {
				first_line->setDirtyFlag(BrTRUE);
				first_line->setDirtyFromNextLine();
			}
			ArrangeTextFrame(frame);  // SRG-55
		}
	}
}


// Ticket 30282, ODT header/footer ����
void BoraDoc::ArrangeWordHeaderFooter(CHeaderFooter* header_footer, BrBOOL is_only_false_frame)
{
	if (BrNULL == header_footer)
		return;

	BrINT parent_id = header_footer->parent_id();

	CPageStyle* page_style = header_footer->page_style();
	CSectionInfomation* section_info = header_footer->section_info();
	if (BrNULL == page_style && BrNULL == section_info)
		return;

	CLine* line = BrNULL;
	if (section_info) {
		BRTHREAD_ASSERT(0 <= parent_id && parent_id < SectionLineVector.size());
		if (0 <= parent_id && parent_id < SectionLineVector.size())
			line = SectionLineVector.at(parent_id);
	}

	// ODT ������ ���� ���� ó�� �߰�
	if (isFromOdt()) {
#ifdef SUPPORT_ODT_HEADER_FOOTER
		BRTHREAD_ASSERT(page_style);
		if (BrNULL == page_style)
			return;

		BRTHREAD_ASSERT(page_style->getPageStyleID() != -1);
		if (page_style->getPageStyleID() == -1)
			return;
#endif  // SUPPORT_ODT_HEADER_FOOTER
	}

	BrINT left = 0;
	BrINT right = 0;
	if (section_info) {
		const BrRect& margin = section_info->getPageMargin();
		left = margin.left + (m_bGutterAtTop? 0: section_info->getGutterMargin());
		right = section_info->getPageWidth() - margin.right;
	}
	else if (page_style) {
		const BrRect& margin = page_style->getMargin();
		left = margin.left;// + (!m_bGutterAtTop ? page_style->m_nGutterMar : 0);
		right = page_style->getPageWidth() - margin.right;
	}

	const BrRect& header_margin = header_footer->getHeaderMargin();
	BrINT header_left  = left + header_margin.left;
	BrINT header_right = right - header_margin.right;

	const BrRect& footer_margin = header_footer->getFooterMargin();
	BrINT footer_left  = left + footer_margin.left;
	BrINT footer_right = right - footer_margin.right;

	BrINT header_top = header_margin.top;
	BrINT footer_bottom = 0;
	if (page_style) {
		header_top = page_style->getMarginTop();
		footer_bottom = page_style->getPageHeight() - page_style->getMarginBottom();
	}
	else if (section_info) {
		footer_bottom = section_info->getPageHeight() - footer_margin.bottom;
	}

	// �ϴ� ���� ���������� 10pt�� minimum height�� ���� XPD-8809
	BrINT default_h = getArrangeDuringImport()? DEF_FONT_SIZE_IN_TEXT: getDefaultTextAtt()->getHanFSize();
	const BrINT min_h = default_h + 1;

	for (BrINT i = 0; i < HDR_FTR_MAX; ++i) {
		if (section_info) {
			BRTHREAD_ASSERT(0 <= parent_id && parent_id < SectionLineVector.size());
			if (0 <= parent_id && parent_id < SectionLineVector.size())
				line = SectionLineVector.at(parent_id);
		}

		BrHdrFtrIdx index = static_cast<BrHdrFtrIdx>(i);
		CFrame* frame = header_footer->GetFrame(index);
		if (BrNULL == frame)
			continue;

		// if it has already arranged, no need checking arrange
		if (is_only_false_frame && frame->getChkArrangeFlag())
			continue;

		// set page
		CPage* page = getHeaderFooterStartPage(frame);  // XPD-8305
		if (BrNULL == page && line)
			page = line->getPage();
		if (BrNULL == page && page_style)
			page = getPageArray()->GetFirst();  //�ӽ� ���� ó�� for ODT Header/Footer. 2014.12.08
		frame->updatePage(page);

		BrBOOL is_blank = frame->isBlankHeaderFooter();

		//[2013.03.20][TID:26126] Page Layout(Page Direction) ����� Header/Footer ��ġ �ٽ� ���
		BRect* rect = frame->getFrameRect();
		if (frame->isHeader()) {
			BrINT header_bottom = header_top;
			if (BrFALSE == isFromOdt() || header_footer->isHeaderAutoHeight())
				header_bottom += header_footer->getHeaderMinHgt();
			else
				header_bottom += header_top + header_footer->getHeaderHgt();  // header_top ???
			//[2014.02.12][TID:22443] �� Frame�� �ƴϸ� �ּ� ���̸� �������� ����
			if (BrFALSE == is_blank && header_top == header_bottom)
				header_bottom += min_h;
			rect->setRect(header_left, header_top, header_right, header_bottom);
			frame->setRunMargin(header_margin);
		}
		else if (frame->isFooter()) {
			BrINT footer_top = footer_bottom;
			if (BrFALSE == isFromOdt() || header_footer->isFooterAutoHeight())
				footer_top -= header_footer->getFooterMinHgt();
			else
				footer_top -= header_footer->getFooterHgt();
			if (BrFALSE == is_blank && footer_top == footer_bottom)
				footer_top -= min_h;
			rect->setRect(footer_left, footer_top, footer_right, footer_bottom);
			frame->setRunMargin(footer_margin);
		}

		if (BrFALSE == header_footer->IsLinked(index) || 0 == parent_id) {
			// NOTE! WPD-4522 frame->getChkArrangeFlag()
			//       �̰� üũ�ؾ� ��ȯ ditry �Ǿ� ���� �� ���ѷ����� ������ �ʴ´�.
			// �����丮�� �𸣴� export ���� ���� getChkArrangeFlag�� ������ �ѹ��� �ϵ��� �Ѵ�.
			if (BrFALSE == getArrangeDuringExport() || BrFALSE == frame->getChkArrangeFlag()) {
				CLine* first_line = frame->getFirstLine();
				if (first_line) {
					first_line->setDirtyFlag(BrTRUE);
					first_line->setDirtyFromNextLine();
				}
				ArrangeTextFrame(frame);  // ZPD-6122
			}
		}
		else {
			if (is_blank || frame->getFirstLine()) {  // LQQ-8432
				//���� �Ӹ���/�ٴڱۿ� ����� ��� LinkHead �Ӹ���/�ٴڱ� Arrange
				CFrame* link_frame = getLinkHeadHeaderFooter(frame);
				if (link_frame && link_frame->getChkArrangeFlag() &&
				    link_frame != frame && link_frame->width() != frame->width()) {
					CLine* first_line = link_frame->getFirstLine();
					if (first_line)
						first_line->setDirtyFlag(BrTRUE);
					ArrangeTextFrame(link_frame);
				}
			}
		}
		frame->setChkArrangeFlag(BrTRUE);
	}
}


// [2013.06.24][TID:26102] �ѱ� ������ ������ ����
void BoraDoc::ArrangeBatangPage()
{
	// A. Check Arrange Flag for batang pages
	// B. Arrange for anchor frames
	// C. Arrange for basic frames

	const BrINT total = m_BatangPageArray->getTotalPageNum();
	for (BrINT i = 1; i <= total; ++i) {
		CPage* page = m_BatangPageArray->getPage(i);
		if (BrNULL == page || BrFALSE == page->isBatangPage() || page->getChkArrangeFlag())
			continue;
		ArrangeAnchorFrameList(page->getPageAFrameList());
		CTextProc::arrangeMarkingLines(this, page->getFirstLine(), BrNULL);
		page->setChkArrangeFlag(BrTRUE);
	}
}


void BoraDoc::ArrangeWordMemo()
{
	if (BrFALSE == isFromDoc() && BrFALSE == isFromOdt())
		return;

	CFrame* frame = m_WordMemoFrameList->getFirst();
	while (frame) {
		CPage* page = frame->getPage();
		ArrangeAnchorFrame(page, frame);
		if (frame == m_WordMemoFrameList->getLast()) {
			resetMemoFrameListPosition(page);
			break;
		}
		frame = m_WordMemoFrameList->getNext(frame);
		if (page != frame->getPage())
			resetMemoFrameListPosition(page);
	}
}


void BoraDoc::ChkArrangeForCurPage(BrINT nPgNum)
{
	if (getBWPEngineMode() == EDITOR_PPT)
	{
		BRTHREAD_ASSERT(0); //
		return;
	}

	if ( isFinishLoading() && isFinishArrange() )	return;

	if ( getDirtyPage()!=0 && getDirtyPage()<nPgNum )	{
		ChkArrangeForCurPage(getDirtyPage(), nPgNum);
		return;
	}

#ifdef	BWP_EDITOR
	CPage *pPage = getEditingPageArray()->getPage(nPgNum);
#else
	CPage *pPage = getPageArray()->getPage(nPgNum);
#endif
	if ( !pPage )	return;

	ChkArrangeForSpecialFrameList(pPage);
	ChkArrangeForTFrameList(pPage);

	if ( getDirtyPage()!=0 && getDirtyPage()<=nPgNum )	{
		CLine *pLine = pPage->getFirstLine();
		pLine = CTextProc::arrangeMarkingLines(this, pLine, BrNULL, BrFALSE, nPgNum);
		if ( pLine )	{
			setDirtyPage(nPgNum+1);
			ResetPageOfAnchorObject(pPage);
		}
		else			{
			setDirtyPage(0);
			setFinishArrange(BrTRUE);
			//getCmdEngine()->setDocEndCoord();
		}
	}
	else if ( nPgNum >= getTotalPage() )	{
		setDirtyPage(0);
		setFinishArrange(BrTRUE);
		//getCmdEngine()->setDocEndCoord();
	}
}


void BoraDoc::ChkArrangeForCurPage(BrINT nSPgNum, BrINT nEPgNum)
{
	if (getBWPEngineMode() == EDITOR_PPT) {
		BRTHREAD_ASSERT(0); //
		return;
	}

	if (isFinishLoading() && isFinishArrange())
		return;

	CPage* pPage = BrNULL;

	// check special frame
	CFrameList* pFList = getAFrameList();
	CFrame* pFrame = pFList->getFirst();
	while (pFrame != BrNULL) {
		pPage = pFrame->getPage();
		if (pPage && pPage->getPageNum() >= nSPgNum && pPage->getPageNum() <= nEPgNum) {
			ArrangeAnchorFrame(pFrame->getPage(), pFrame);
		}
		pFrame = pFList->getNext(pFrame);
	}

	CLine* pLine = BrNULL;
	for (int nPgNum = nSPgNum; nPgNum <= nEPgNum; nPgNum++) {
#ifdef	BWP_EDITOR
		pPage = getEditingPageArray()->getPage(nPgNum);
#else
		pPage = getPageArray()->getPage(nPgNum);
#endif
		if (!pPage)	continue;

		if (pLine == BrNULL)	pLine = pPage->getFirstLine();

		pFList = pPage->getTFrameList();
		pFrame = pFList->getFirst();
		while (pFrame != BrNULL) {
			ArrangeAnchorFrame(pPage, pFrame);
			pFrame = pFList->getNext(pFrame);
		}
	}

	if (getDirtyPage() != 0 && getDirtyPage() <= nEPgNum) {
#ifdef	BWP_EDITOR
		pPage = getEditingPageArray()->getPage(nSPgNum);
#else
		pPage = getPageArray()->getPage(nSPgNum);
#endif
		if (pPage) {
			pLine = pPage->getFirstLine();
			if (pLine) {
				pLine = CTextProc::arrangeMarkingLines(this, pLine, BrNULL, BrFALSE, nEPgNum);
				if (pLine) {
					setDirtyPage(nEPgNum + 1);
					ResetPageOfAnchorObject(pPage);
				}
				else {
					setDirtyPage(0);
					setFinishArrange(BrTRUE);
					//getCmdEngine()->setDocEndCoord();
#ifndef SUPPORT_PAGELAYOUT_BG_ARRANGE
					getCmdEngine()->updateScreenAndPage();		// ZPD-16708
#endif //SUPPORT_PAGELAYOUT_BG_ARRANGE
				}
			}
			else   // CNZ-4108
			{
				if (nSPgNum + 1 <= getPageArray()->size())  // OFF-23212
				{
					setDirtyPage(nSPgNum + 1);
					ResetPageOfAnchorObject(pPage);
				}
				else {
					setDirtyPage(0);
					setFinishArrange(BrTRUE);
				}
			}
		}
#ifndef SUPPORT_PAGELAYOUT_BG_ARRANGE // ZPD-27500
		else {
			setDirtyPage(0);
			setFinishArrange(BrTRUE);
		}
#endif // SUPPORT_PAGELAYOUT_BG_ARRANGE
	}
	else if (nEPgNum >= getTotalPage()) {
		setDirtyPage(0);
		setFinishArrange(BrTRUE);
		//getCmdEngine()->setDocEndCoord();
#ifndef SUPPORT_PAGELAYOUT_BG_ARRANGE
		getCmdEngine()->updateScreenAndPage();		// ZPD-16708
#endif // SUPPORT_PAGELAYOUT_BG_ARRANGE
	}

	// [RGD-360][TGB-121][CNZ-4483] ���� �̽� ����
	if (pPage && pPage->getPageNum() == 1 && g_pAppStatic->bReDrawFirstPage) {
		onDraw(getPainter(), getPainter()->pDC);
		g_pAppStatic->bReDrawFirstPage = BrFALSE;
	}
}


void BoraDoc::ChkArrangeForSpecialFrameList(CPage* pPage)
{
	if (getBWPEngineMode() == EDITOR_PPT) {
		BRTHREAD_ASSERT(0); //
		return;
	}

	if (!pPage)	return;

	BRect rcOrg, rcDest;

	CFrameList* pFList = getAFrameList();
	CFrame* pFrame = pFList->getFirst();
	while (pFrame != BrNULL) {
		if (pPage == pFrame->getPage()) {
			rcOrg = pFrame->getFrameRect();
			ArrangeAnchorFrame(pPage, pFrame);
			rcDest = pFrame->getFrameRect();
			if (pFrame->getRAType() && rcOrg.getHeight() != rcDest.getHeight()) {
				setDirtyPage(pPage->getPageNum());
			}
		}
		pFrame = pFList->getNext(pFrame);
	}
}


// import ���Ŀ� ���߿� page�� ���ϴ� ���� ���� ���Ͽ� importOnePage() ���Ŀ� call
void BoraDoc::ChkArrangeForSpecialFrameList()
{
	if (getBWPEngineMode() == EDITOR_PPT) {
		BRTHREAD_ASSERT(0); //
		return;
	}
	setCheckingSpecial(BrTRUE);
	CFrameList* pFList = getAFrameList();
	CFrame* pFrame = pFList->getFirst();
	while (pFrame != BrNULL) {
		if (!pFrame->getChkArrangeFlag() && !pFrame->isTable() && (pFrame->isAnchored() || pFrame->getRAType() != NO_RUN_AROUND))	ArrangeAnchorFrame(pFrame->getPage(), pFrame);
		pFrame = pFList->getNext(pFrame);
	}
	setCheckingSpecial(BrFALSE);

	setCheckingSpecial(BrTRUE);
	pFList = getAFrameList4HeaderFooter();
	pFrame = pFList->getFirst();
	while (pFrame != BrNULL) {
		if (!pFrame->getChkArrangeFlag() && !pFrame->isTable() && (pFrame->isAnchored() || pFrame->getRAType() != NO_RUN_AROUND))
			ArrangeAnchorFrame(pFrame->getPage(), pFrame);
		pFrame = pFList->getNext(pFrame);
	}
	setCheckingSpecial(BrFALSE);
}


void BoraDoc::ChkArrangeForTFrameList(CPage* pPage)
{
	if (!pPage)	return;

	BRect rcOrg, rcDest;

	CFrameList* pFList = pPage->getTFrameList();
	CFrame* pFrame = pFList->getFirst();
	while (pFrame != BrNULL) {
		rcOrg = pFrame->getFrameRect();
		ArrangeAnchorFrame(pPage, pFrame);
		rcDest = pFrame->getFrameRect();
		if (rcOrg.getHeight() != rcDest.getHeight()) {
			setDirtyPage(pPage->getPageNum());
		}
		pFrame = pFList->getNext(pFrame);
	}
}


// �� �������� arrange�ϸ鼭 ���� �������� �ִ� frame�� ���� �������� �Ѿ� ������ arrange�� ���� �ʾƼ� ���� ��������
// display�Ǵ� ������ ���� ���Ͽ� �߰�....
void BoraDoc::ResetPageOfAnchorObject(CPage *pPage)
{
	if (getBWPEngineMode() == EDITOR_PPT)
	{
		BRTHREAD_ASSERT(0); //
		return;
	}
	if ( !pPage )	return;

	// check special frame
	CFrameList *pFList = getAFrameList();
	CFrame *pFrame = pFList->getFirst();
	CLine *pLine;
	CPage *pLinePage;

    while(IsValidObject(pFrame)){
		if (pPage == pFrame->getPage())
		{
			pLine = pFrame->getAnchorLine();
			if (IsValidObject(pLine))
			{
				pLinePage = pLine->getPage();
				if (pLinePage && pLinePage != pPage)
				{
					if (pFrame->isAnchored() || !pFrame->isTable() || !pFrame->getTable()->getNext()) // split floating table �� ��� line page�� �ٸ� ��� ���� WPD-1489
						pFrame->updatePage(pLinePage, NESTALL);
				}
			}
		}
        pFrame = pFList->getNext(pFrame);
    }
}

#ifdef	BWP_EDITOR
void BoraDoc::InvalidateRect(BRect *lprc, BrBOOL bInClientRect)
{
	if ( g_pAppStatic->bImportProc )	return;
	if ( getBWPEngineMode()!=EDITOR_WORD && getBWPEngineMode()!=EDITOR_PPT  )	return;
	if ( m_bOnDraw )		return;

	 //BgLoad�� ������ ���� �����ִ� page�� �ƴϰ� ������ invalidateRect�� setting�� ���ָ� �ȵ�.
	// if(B_IsPageBgLoad())
	//	return;

	BRect clientRect = getClientArea();
	bool bShowDebug = g_pBInterfaceHandle->IsShowDebugInfo();
	if (BrNULL == lprc || bShowDebug )
    {
		m_rcInvaldateRect = clientRect;
		DocFlagEx.flag.m_bInvalidateFlag = BrTRUE;
		getPainter()->pDC->setClipRect(BrNULL);
        return;
    }

	if ( DocFlagEx.flag.m_bInvalidateFlag == BrTRUE )
	{
		if ( lprc )
		{
			m_rcInvaldateRect.Union(*lprc);
			if (bInClientRect)
				m_rcInvaldateRect = m_rcInvaldateRect.Intersection(clientRect);

			if (m_rcInvaldateRect.nLeft > m_rcInvaldateRect.nRight || m_rcInvaldateRect.nTop > m_rcInvaldateRect.nBottom)
				DocFlagEx.flag.m_bInvalidateFlag = BrFALSE;
			else
				DocFlagEx.flag.m_bInvalidateFlag = BrTRUE;
		}
		else
		{
			m_rcInvaldateRect = clientRect;
			DocFlagEx.flag.m_bInvalidateFlag = BrFALSE;
		}
	}
	else //if( DocFlagEx.flag.m_bInvalidateFlag == BrFALSE )
	{
		if ( lprc )
		{
			m_rcInvaldateRect = *lprc;
			if (bInClientRect)
				m_rcInvaldateRect = m_rcInvaldateRect.Intersection(clientRect);

			if (m_rcInvaldateRect.nLeft > m_rcInvaldateRect.nRight || m_rcInvaldateRect.nTop > m_rcInvaldateRect.nBottom)
				DocFlagEx.flag.m_bInvalidateFlag = BrFALSE;
			else
				DocFlagEx.flag.m_bInvalidateFlag = BrTRUE;
		}
		else
		{
			m_rcInvaldateRect = clientRect;
			DocFlagEx.flag.m_bInvalidateFlag = BrFALSE;
		}
	}

	if (DocFlagEx.flag.m_bInvalidateFlag == BrFALSE
		|| (m_rcInvaldateRect.getWidth() == gnLCDWidth && m_rcInvaldateRect.getHeight() == gnLCDHeight))
	{
		getPainter()->pDC->setClipRect(BrNULL);
	}


}
#endif	// BWP_EDITOR

#ifdef	BWP_EDITOR
// check whether it is in client area
void BoraDoc::ChkInvalidateRect(BRect& rRect)
{
	 //BgLoad�� ������ ���� �����ִ� page�� �ƴϰ� ������ invalidateRect�� setting�� ���ָ� �ȵ�.
	if(B_IsPageBgLoad())
		return;

	if ( DocFlagEx.flag.m_bInvalidateFlag )	{
		m_rcInvaldateRect.IntersectRectEx(m_rcInvaldateRect, rRect);
	}
	else	{
		m_rcInvaldateRect = rRect;
		DocFlagEx.flag.m_bInvalidateFlag = BrTRUE;
	}
}
#endif	// BWP_EDITOR

#ifdef	BWP_EDITOR
BRect BoraDoc::getClientArea()
{
	BRect	rcTemp;

    rcTemp.nLeft=rcTemp.nTop=0;
    Painter *pPainter = m_CmdEngine->getCurPainter();

	if ( pPainter )
	{
		if (g_pAppStatic->isPrtPreview() && (g_pAppStatic->getPrtWidth() != -1 && g_pAppStatic->getPrtHeight() != -1))
		{
			rcTemp.nRight = g_pAppStatic->getPrtWidth();
			rcTemp.nBottom =g_pAppStatic->getPrtHeight();

				if( pPainter->pDC && pPainter->pDC->isExportMode() )
				{
					BrEXPORT_INFO sInfo = {0};
					pPainter->pDC->getExport( &sInfo );
					rcTemp.Move( -sInfo.nPosX , -sInfo.nPosY  );
				}

			return rcTemp;
		}

		if (m_bUseDCClientArea && pPainter->pDC && pPainter->pDC->m_pBitmap)
			pPainter->pDC->m_pBitmap->getSize((BrINT32*)&rcTemp.nRight, (BrINT32*)&rcTemp.nBottom);
		else if (pPainter->pageImg.m_PageBitmap.getDib())
			pPainter->pageImg.m_PageBitmap.getSize((BrINT32*)&rcTemp.nRight, (BrINT32*)&rcTemp.nBottom);
		else
			pPainter->pageImg.m_ScreenBitmap.getSize((BrINT32*)&rcTemp.nRight, (BrINT32*)&rcTemp.nBottom);
    }
	else
		rcTemp.nRight=rcTemp.nBottom=0;

	return rcTemp;
}
#endif	// BWP_EDITOR

#ifdef	BWP_EDITOR
BrBOOL BoraDoc::IsInInvalidateRect(BRect& rRect, BrBOOL *pUnder, BrBOOL bFullCheck)
{
	if (m_CmdEngine->isCurOperation(ACTMAKETHUMBNAIL))
        return BrTRUE;

	if ( pUnder )
		*pUnder = BrFALSE;

	if (bFullCheck)
	{
		if (!pUnder && !DocFlagEx.flag.m_bInvalidateFlag && (DocFlagEx.flag.m_bHorClipRectFlag || DocFlagEx.flag.m_bVerClipRectFlag))
		{
			if (DocFlagEx.flag.m_bHorClipRectFlag)
			{
				if (m_rcHorClipRect.IsIntersect(rRect))
					return BrTRUE;
			}

			if (DocFlagEx.flag.m_bVerClipRectFlag)
			{
				if (m_rcVerClipRect.IsIntersect(rRect))
					return BrTRUE;
			}

			return BrFALSE;
		}

		BRect rcClientRect = getClientArea();
		if (DocFlagEx.flag.m_bInvalidateFlag && !m_rcInvaldateRect.IsEmpty())
		{
			rcClientRect = rcClientRect.GetIntersection(m_rcInvaldateRect);
			if (rcClientRect.nLeft == rcClientRect.nRight || rcClientRect.nTop == rcClientRect.nBottom)
				return BrFALSE;
		}

		if ( pUnder )	{
			if ( rRect.nTop > rcClientRect.nBottom )
				*pUnder = BrTRUE;
		}

		if (rcClientRect.IsIntersect(&rRect))
			return BrTRUE;
		else
			return BrFALSE;
	}
	else
	{
		if ( DocFlagEx.flag.m_bInvalidateFlag && !m_rcInvaldateRect.IsEmpty() )	{
			// drawing���� clip region�� x���� �������� �ʱ� ������...
			// if ( m_rcInvaldateRect.IsIntersect(&rRect) )
			//	return BrTRUE;
			BrINT32 y1 = BrMAX(m_rcInvaldateRect.nTop, rRect.nTop);
			BrINT32 y2 = BrMIN(m_rcInvaldateRect.nBottom, rRect.nBottom);
			if ( pUnder )	{
				if ( rRect.nTop > m_rcInvaldateRect.nBottom )
					*pUnder = BrTRUE;
			}

			if((y2 - y1) >= 0)
				return BrTRUE;
			else
				return BrFALSE;
		}
		else	{
			BRect rcClientRect = getClientArea();
			BrINT32 y1 = BrMAX(rcClientRect.nTop, rRect.nTop);
			BrINT32 y2 = BrMIN(rcClientRect.nBottom, rRect.nBottom);

			if ( pUnder )	{
				if ( rRect.nTop > rcClientRect.nBottom )
					*pUnder = BrTRUE;
			}

			if((y2 - y1) >= 0)
				return BrTRUE;
			else
				return BrFALSE;
		}
	}
}
#endif	// BWP_EDITOR

#ifdef	BWP_EDITOR
BrBOOL BoraDoc::isInvalidateRectOutsideOfPage()
{
	if ( !DocFlagEx.flag.m_bInvalidateFlag || m_rcInvaldateRect.IsEmpty() )
		return BrFALSE;

	CPage *pPage = m_CmdEngine->getCurrentPage();
	if ( !pPage )	return BrFALSE;

	BRect  rcPage;
	rcPage.setRect(0, 0, pPage->width(), pPage->height());
	m_CmdEngine->page2Logical(pPage, rcPage);

	return !rcPage.IsInside(m_rcInvaldateRect);
}
#endif	// BWP_EDITOR

#ifdef SUPPORT_SECTION_DEBUG
//[2012.09.24][TID:7609][��ȸ��]Section Debugging - BoraDoc::showDocInfo()
void BoraDoc::showDocInfo()
{
	showSectionInfo();

	CPageArray *pPageArray = getEditingPageArray();
	int nStartPage = 1;
	int nEndPage = pPageArray->size();

	for(int n = nStartPage; n <= nEndPage; n++)
	{
		CPage* pPage = pPageArray->getPage(n);
		pPage->showPageInfo();
	}
}

void BoraDoc::showSectionInfo()
{
	BrINT nSectionLine = SectionLineVector.size();
	BTrace("[Section Line Number:%d]\n", nSectionLine);

	for(int i=0 ; i<nSectionLine ; i++)
	{
		CLine* pSectionLine = (CLine*)SectionLineVector.GetAt(i);
		//pSectionLine->showCharacters();

		CSectionInfomation* pSectionInfo = pSectionLine->getSectionInformation();
		pSectionInfo->showSectionInfo();
	}
}
#endif//SUPPORT_SECTION_DEBUG


void BoraDoc::GetDocumentSizeforViewer(BrBOOL bContine, BrINT32 *nWidth, BrINT32 *nHeight)
{
	CCmdEngine *pCmdEngine = getCmdEngine();
	if (bContine)
	{
		pCmdEngine->getDocumentSizeforViewer();
		*nWidth = pCmdEngine->getDocWidthforViewer();
		*nHeight = pCmdEngine->getDocHeightforViewer();
	}
	else
	{
		*nWidth = pCmdEngine->getDocEndDx();
		*nHeight = pCmdEngine->getDocEndDy();
	}

}

#ifdef BWP_EDITOR
/* getBoundary() ���� arrange�Ǵ� ��� �ֽ��ϴ�. */
void BoraDoc::UpdateAllViews(CFrame *pFrame, BrINT nDefMargin )
{
	BRect	rc;

	if (!pFrame)
	{
		rc.setRect(0, 0, getLCDWidth(), getLCDHeight());
		InvalidateRect(&rc);
		return;
	}

	if ( getBWPEngineMode()!=EDITOR_WORD && getBWPEngineMode()!=EDITOR_PPT )	return;

	CPage* pPage = pFrame->getPage();
	if (!pPage || pPage->getPageNum() < 1)
		return;

	//pFrame->getBoundary(rc, 2);
	//2->4(MARGIN_BORDER_FULL); [2012.11.19][inkkim] 3D �� image effect ���� refresh�� ����
	rc = *pFrame->getFrameRect();
	BRect rcBound = rc;
	pFrame->getBoundary(rcBound, MARGIN_BORDER_FULL, BrTRUE);
	rc.Union(rcBound);

	m_CmdEngine->page2Logical(pPage, rc);

	//--- frame boundary ���� ó���� ���⼭ �����Ѵ�.
	rc.InflateRect(nDefMargin, nDefMargin);
	InvalidateRect(&rc);
}
#endif // BWP_EDITOR

#ifdef BWP_EDITOR
void BoraDoc::UpdateAllViews(CPage *pPage, BRect &rc1)
{
	if ( getBWPEngineMode()!=EDITOR_WORD && getBWPEngineMode()!=EDITOR_PPT )	return;

	BRect	rc = rc1;
	if( pPage )
	{
		m_CmdEngine->page2Logical(pPage, rc);
		rc.InflateRect(1, 1);
	}
	else
	{
		rc.setRect(0, 0, getLCDWidth()/*pPage->width()*/, getLCDHeight()/*pPage->height()*/);
		// m_CmdEngine->page2Logical(pPage, rc);
	}

	InvalidateRect(&rc);
}
#endif // BWP_EDITOR

#ifdef BWP_EDITOR
// filter������ ������ normal page���� data�� ����� ������...
// web mode���� one page �� loading�ϴ� ���� web page�� �����´�.
void BoraDoc::moveAllLinesToWebPage()
{
	CLine		*pLine, *pNext;
	CLineList	*pLineList = BrNULL;

	CPage  *pPage = getWebPageArray()->getPage(1);
	if ( pPage )	pLineList = pPage->getFirstLineList();
	if ( pLineList )	{
		pLine = getFirstLineOfNormalPage();
		while ( pLine )
		{
			pNext = pLine->getNext();
			if ( pLineList!=pLine->getLineList() )	{
				pLine->getLineList()->unLink(pLine);
				pLineList->insertAtTail( pLine );
			}
			pLine = pNext;
		}
	}
}
#endif // BWP_EDITOR

#ifdef BWP_EDITOR
// background�� web mode���� basic frame�� arrange�ϴ� function
void BoraDoc::backgroundRearrange()
{
	if ( isFinishArrangeForWeb() )	return;

	CLine	*pLine = getFirstLine();
	if ( !pLine )	return;

	pLine = pLine->getLastNoDirtyLine();
	if ( !pLine )	return;

	CTextProc::arrangeMarkingLines(this, pLine->getNext(), NULL);
}
#endif // BWP_EDITOR

#if defined(BWP_EDITOR) || defined(PPT_EDITOR)
void BoraDoc::clearImageCache(BrBOOL bClearRawImage, BrBOOL bResetImageLoader)
{
	if (getBWPEngineMode() == EDITOR_WORD)
	{
		getAFrameList()->clearImageCache(bClearRawImage, bResetImageLoader);
		getAFrameList4HeaderFooter()->clearImageCache(bClearRawImage, bResetImageLoader);
		getMstAFrameList()->clearImageCache(bClearRawImage, bResetImageLoader);
	}
	else
	{
		//Master Page Clear
		for (int i = 0 ; i < m_MasterLayoutArray.size() ; i++)
		{
			CPageArray *pPageArray = m_MasterLayoutArray.at(i);
			if (pPageArray) {
				for (int i = 0 ; i < pPageArray->size() ; i++) {
					CPage *pPage = pPageArray->at(i);
					if (pPage)
						pPage->getPageAFrameList()->clearImageCache(bClearRawImage, bResetImageLoader);
				}
			}
		}
	}

	m_MstPageArray->clearImageCache(bClearRawImage, bResetImageLoader);
	m_PageArray->clearImageCache(bClearRawImage, bResetImageLoader);
	m_WebPageArray->clearImageCache(bClearRawImage, bResetImageLoader);
}

void BoraDoc::resetPageImageCache()
{
    CPage *pPage;

    // normal page
    BrINT i, nSize = m_PageArray->GetSize();
    for (i = 0; i < nSize; i++)
    {
        pPage = (CPage *)m_PageArray->GetAt(i);
        if (pPage)
            pPage->setImageCachedFlag(BrFALSE);
    }

    // master page
    nSize = m_MstPageArray->GetSize();
    for (i = 0; i < nSize; i++)
    {
        pPage = (CPage *)m_MstPageArray->GetAt(i);
        if (pPage)
            pPage->setImageCachedFlag(BrFALSE);
    }

	for(BrINT nIdx = 0; nIdx<m_MasterLayoutArray.size(); nIdx++)
	{
		nSize = m_MasterLayoutArray.at(nIdx)->size();
		for (i = 0; i < nSize; i++)
		{
			pPage = (CPage*)m_MasterLayoutArray.at(nIdx)->at(i);
			if (pPage)
				pPage->setImageCachedFlag(BrFALSE);
		}
	}

    // web page
    nSize = m_WebPageArray->GetSize();
    for (i = 0; i < nSize; i++)
    {
        pPage = (CPage *)m_WebPageArray->GetAt(i);
        if (pPage)
            pPage->setImageCachedFlag(BrFALSE);
    }
}

void BoraDoc::setCacheThumbnailImage(PrBitmap* p)
{
	if (m_pCacheThumbnailImage)
		BR_SAFE_DELETE(m_pCacheThumbnailImage);

	m_pCacheThumbnailImage = p;
}
#endif

#ifdef PPT_EDITOR
BrBOOL BoraDoc::findModfiedMasterPageInfo(BrINT32 nMasterID, BrINT32 eLayoutType)
{
	//�ߺ� �˻�
	nMasterID = (nMasterID & 0x0000ffff);
	for (BrINT i = 0 ; m_bModifiedMasterPageInfoArray->size() ; i++)
	{
		LayoutInfo *pInfo = m_bModifiedMasterPageInfoArray->at(i);
		if (pInfo->eLayoutType == eLayoutType && (pInfo->nMasterID & 0x0000ffff) == nMasterID)
			return BrTRUE;
	}
	return BrFALSE;
}

void BoraDoc::createPPTTemplate(BrSlideTemplateType eTemplatePPT)
{
	CFrame *pFrame = BrNULL;
	CPage *pPage = m_PageArray->getPage(1);

	CPageArray *pMstPageArray = m_MasterLayoutArray.at(0);
	if (!pMstPageArray)
		return;
	BrINT nLayoutPageNum = 0;

	switch (eTemplatePPT) {
		case BR_SLIDE_TEMPLATE_TITLE: 					nLayoutPageNum = 2; 	break;
		case BR_SLIDE_TEMPLATE_TITLE_OBJECT:  			nLayoutPageNum = 3; 	break;
		case BR_SLIDE_TEMPLATE_SECTION_HEADER:  		nLayoutPageNum = 4; 	break;
		case BR_SLIDE_TEMPLATE_TWO_OBJECTS:  			nLayoutPageNum = 5; 	break;
		case BR_SLIDE_TEMPLATE_TWO_TEXT_TWO_OBJECTS:  	nLayoutPageNum = 6;		break;
		case BR_SLIDE_TEMPLATE_TITLE_ONLY:  			nLayoutPageNum = 7; 	break;
		case BR_SLIDE_TEMPLATE_BLANK:  					nLayoutPageNum = 8; 	break;
		case BR_SLIDE_TEMPLATE_TITLE_OBJECT_CAPTION:  	nLayoutPageNum = 9; 	break;
		case BR_SLIDE_TEMPLATE_VERTICALTEXT:  			nLayoutPageNum = 11;	break;
		case BR_SLIDE_TEMPLATE_VERTICALTITLE_TEXT:  	nLayoutPageNum = 12;	break;
		case BR_SLIDE_TEMPLATE_PICTURE_CAPTION:  		nLayoutPageNum = 10; 	break; //PICTURE_CAPTION�� ���� ����
	}

	CPage *pLayoutPage = pMstPageArray->getPage(nLayoutPageNum);
	CFrameList *pMstFrameList = BrNULL;
	pMstFrameList = getAFrameList(pLayoutPage);
	CFrame *pNewSlideFrame = BrNULL;
	CFrame *pMstFrame = pMstFrameList->getFirst();

	pPage->setMasterID(pLayoutPage->getMasterID());
#ifdef SEPERATE_MASTERID
	pPage->setLayoutID(pLayoutPage->getLayoutID());
#endif //SEPERATE_MASTERID
	pPage->setMstPageNum(nLayoutPageNum);
	pPage->setApplyMasterFlag(BrTRUE);
	pPage->setSchemeMasterFlag(BrTRUE);
	pPage->setRefThemeID(pLayoutPage->getRefThemeID());
	pPage->setLayout(pLayoutPage->getLayout());


	while (pMstFrame)
	{
		BrINT32 nPlaceHolderType = pMstFrame->getPlaceHolderType();
		if (pMstFrame->getPage() == pLayoutPage && nPlaceHolderType > 0
			&& (nPlaceHolderType != PLACEHOLDER_TYPE_DATE)
			&& (nPlaceHolderType != PLACEHOLDER_TYPE_FOOTER)
			&& (nPlaceHolderType != PLACEHOLDER_TYPE_SLIDE_NUMBER))
		{
			BrTrace("pFrame->getPlaceHolderType() %d" , pMstFrame->getPlaceHolderType());
			pNewSlideFrame = PODuplication::CopyFrame(pMstFrame, BrNULL, BrNULL, BrFALSE);
			if (pNewSlideFrame)
			{
				pNewSlideFrame->updatePage(pPage);
				pNewSlideFrame->setPageNum(pPage->getPageNum());
				pNewSlideFrame->setPlaceHolderIndex(pMstFrame->getPlaceHolderIndex());
				pNewSlideFrame->UpdateID();

				// Master�� �޷� �ִ�  PlaceHolderText�� �����.
				getCmdEngine()->MasterPHTextAttrToSlidePHTextAttrCopy(pNewSlideFrame);
				// Object Default Name �߰� (Placeholder)
				BString strName;
				pNewSlideFrame->setNameForSelectionPane(strName);

				getAFrameList(pPage)->insertAtTail(pNewSlideFrame);

#ifdef SUPPORT_PPT_TEXT_STYLE
				CLine* pMstLine = pMstFrame->getFirstLine();
				BrINT nMstStyleID = pMstLine->getStyleID();

				CLine* pLine = pNewSlideFrame->getFirstLine();
				if (pLine)
				{
					CSlideTextStyle* pSlideTextStyle = BrNEW CSlideTextStyle;
					PoTextAtt textAtt;
					PoParaAtt paraAtt;

					BrINT nNewStyleID = 0;

					textAtt.setTextMaskBits(0);
					textAtt.setTextMaskBitsExt(0);
					paraAtt.SetMaskBit(0);

					pSlideTextStyle->setTextAtt(&textAtt);
					pSlideTextStyle->setParaAtt(&paraAtt);
					pSlideTextStyle->setBaseStyleID(nMstStyleID);

					nNewStyleID = CSlideTextStyle::getTextStyleID(*pSlideTextStyle);
					pLine->setStyleID(nNewStyleID);
				}
#endif

			}
		}
		pMstFrame = pMstFrameList->getNext(pMstFrame);
	}

	initISlideIDInfo(0);
	InsertSlideIDInfo(1, 256);

	resetPageThemeColor(pPage);
	getCaret()->setCaretStatus(BR_CARET_OFF);
}

// �������� �����̵� ������ �߿��� ���� �����͸� ����ϴ� �������� ��� return
// return �� arr�� �߰��� ���� arrPage���� ���� ��
// arrPage size�� 0�� �ɶ����� ��� ȣ�� �ϸ� ���� �����͸� ����ϴ� ������ ��ȣ ���� ����
BArray<BrINT> BoraDoc::getPageNumArray_SameMaster(BArray<BrINT>* arrPage)
{
	// �����ϴ� ������ ����Ʈ�߿��� ������ �����͸� ������ �������鸸 ��󳻼� ����
	BArray<BrINT> arrCopiedPageNum; //������ �����Ϳ� �ش��ϴ� ������ ��ȣ ����
	BArray<BrINT> arrMasterID; //���� ������ ID����
	for( int nIdx = 0; nIdx < arrPage->GetSize(); nIdx++)
	{
		CPage *pSrcPage = BrNULL;
		BrINT nPageNum = arrPage->at(nIdx);
		CPageArray *pPageArray = theBWordDoc->getPageArray();
		pSrcPage = pPageArray->getPage(nPageNum);
		//�������� ������ ������ read
		if (BrNULL == pSrcPage)
			pSrcPage = HandsPointer_ReadSlide_PPT_BWP(gpPaint, nPageNum, nPageNum);

		if(pSrcPage)
		{
			//������ idx�� ã��
#ifdef SEPERATE_MASTERID
			BrINT nFindIndex = theBWordDoc->findSlideMasterIndex(pSrcPage->getMasterID());
#else //SEPERATE_MASTERID
			BrINT nFindIndex = theBWordDoc->findSlideMasterIndex(pSrcPage->getMasterID() & 0x0000ffff);
#endif //SEPERATE_MASTERID

			if(arrCopiedPageNum.GetSize() == 0) { //ó������ �ϴ� insert
				arrCopiedPageNum.Add(nPageNum); //������ ������ ID�� ������ page�� ADD
				arrMasterID.Add(nFindIndex); //���� ������ ID�� �����ϱ� ���ؼ� ADD
				arrPage->RemoveAt(nIdx); //�߰� �ϰ� ���� ������ �Ǵ� ���������� ����
				nIdx--;
			}
			else {
				BrINT nRet = BSearch< BrINT > ::SearchNInsert(arrMasterID, nFindIndex);//���� ���������� Ȯ��
				if(nRet != -1) {  //������ �����ϴ� ������idx�� �ִ�
					arrCopiedPageNum.Add(nPageNum);
					arrPage->RemoveAt(nIdx);
					nIdx--;
				}
			}
		}
	}

	return arrCopiedPageNum;
}

#ifdef USE_HUNSPELL
CSpellCheckManager* BoraDoc::getSpellCheckManager()
{
	if(m_pSpellCheckManager==BrNULL)
		m_pSpellCheckManager = BrNEW CSpellCheckManager();

	return m_pSpellCheckManager;
}
#endif //USE_HUNSPELL

BrBOOL BoraDoc::syncSlidePaperSize( CPage* pDstPage )
{
	if(!pDstPage)
		return BrFALSE;

	BrSize* pCurPaperSize = getSlideSize();
	CPaperSize* pDstPaperSize = pDstPage->getPaperSize();

	if (pCurPaperSize->cx != pDstPaperSize->width() ||
		pCurPaperSize->cy != pDstPaperSize->height())
	{
		// Pageũ�� ����
		BrFLOAT fRatioX =  (BrFLOAT)pCurPaperSize->cx / pDstPaperSize->width();
		BrFLOAT fRatioY =  (BrFLOAT)pCurPaperSize->cy / pDstPaperSize->height();
		BrFLOAT fRatioText = 1.0;

		if(fRatioX < 1.0 || fRatioY < 1.0 )
		{
			if(fRatioX < fRatioY)
				fRatioText = fRatioX;
			else
				fRatioText = fRatioY;
		}
		else if((fRatioX > 1.0) && (fRatioX == fRatioY))
			fRatioText = fRatioX;

		//BTrace("%s[%d] fRatioX = %f || fRa-tioY = %f", __FUNCTION__, __LINE__, fRatioX, fRatioY);

		////////// �����Ӽ� ���
		CCmdEngine *pCmdEngine = getCmdEngine();
		CFrameSet *pOrgFrameSet = pCmdEngine->getFrameSet();
		CFrameSet frameSet; //�����Ӽ� ���
		frameSet.removeAll();
		CTableEngine *pTableEngine = pCmdEngine->getTableEngine();
		CBackupMarkingData pMarkingData;
		BrBOOL bIsCellMarked = BrFALSE;
		CBTable *pTable = BrNULL;

		if(pTableEngine && pTableEngine->isCellMarked())
		{
			pTableEngine->getMarker()->saveMarkingData(&pMarkingData);
			pTableEngine->getMarker()->clearMarking();
			pTable = pTableEngine->getTable();
			bIsCellMarked = BrTRUE;
			frameSet.insertAllUnique(pOrgFrameSet);

			if (pOrgFrameSet && pTable && !pOrgFrameSet->isSelected(pTable->getFrame()))
				pOrgFrameSet->insertTableFrame(pTable->getFrame());
		}
		else
		{
			if(pOrgFrameSet != BrNULL)
			{
				frameSet.insertAllUnique(pOrgFrameSet);
				pOrgFrameSet->removeAll();
			}
		}

		m_Caret->saveCaretEx();
		m_Caret->setCaretStatus(BR_CARET_OFF);
		/////////// �����Ӽ� ���

		PPT_PAPER_CHANGE mode = PPT_PAPER_CHANGE_NORMAL;

		if(fRatioX == fRatioY)
			mode = PPT_PAPER_CHANGE_DIRECTION;

		CPage* pPage = getPageArray()->getPage(1);
		if(!pPage)
			return BrFALSE;

		BrINT nSizeID = pPage->getPaperSize()->getSizeID();
		getCmdEngine()->setPPTPaperLayoutForPage(pDstPage, -1, pCurPaperSize->cx, pCurPaperSize->cy,
			nSizeID, fRatioX, fRatioY, mode, BrNULL);


		pCmdEngine->changeFontParaResizeRatio(pOrgFrameSet, fRatioText, BrFALSE);

		//��Ʈ�� �Ķ� �Ӽ� ���� ��������
		//�����Ӽ� ����
		if(pOrgFrameSet != BrNULL)
		{
			pOrgFrameSet->removeAll();
			pOrgFrameSet->insertAllUnique(&frameSet);
		}

		m_Caret->restoreCaretEx();
		if(bIsCellMarked)
		{
			pTableEngine->setTable(pTable);
			pTableEngine->getMarker()->restoreMarkingData(&pMarkingData);
		}
		//�����Ӽ� ����

		return BrTRUE;
	}

	return BrTRUE;
}

// Photo Album
#ifdef PPT_EDITOR
void BoraDoc::setTextOnPhotoAlbumTemplate(const BString &title, const BString &author)
{
	CPageArray *page_array = getEditingPageArray();
	CPage *page = page_array->getPage(1);  // first page
	CFrameList *framelist = getAFrameList(page);

	CFrame *title_frame = framelist->getFirst();
	setTextOnTextBoxFrame(title_frame, title);

	CFrame *author_frame = framelist->getNext(title_frame);
	setTextOnTextBoxFrame(author_frame, author);
}

void BoraDoc::setTextOnTextBoxFrame(CFrame *frame, const BString &text)
{
	m_Caret->update(frame, BrFALSE);
	BrUINT length = text.length();
	for (BrUINT i = 0; i < length; ++i) {
		BrDWORD code = static_cast<BrDWORD>(text.at(i));
		m_Caret->insert(code, LINKTYPE::STANDARD, 0, BrFALSE, BrFALSE);
	}
}
#endif // PPT_EDITOR

void BoraDoc::initImportPageNumInfo(BrDWORD dwPages)
{
	if (getEditMasterType() != EDIT_MASTER_NONE && getEditMasterType() != EDIT_SLIDE_NOTE)
		return;

	m_ImportPageNumInfo.resize(dwPages);
    BrDWORD n, *pData = (BrDWORD *)m_ImportPageNumInfo.data();
    for (n = 0; n < dwPages; n++)
        pData[n] = n + 1;
}

void BoraDoc::updateImportPageNumInfo(BrDWORD dwDocPage, BrINT32 nVal)
{
	if (getEditMasterType() != EDIT_MASTER_NONE && getEditMasterType() != EDIT_SLIDE_NOTE)
		return;

	BrDWORD dwSize = m_ImportPageNumInfo.size();
    if (0 == dwSize)
        return;

    BrDWORD n, *pData = (BrDWORD *)m_ImportPageNumInfo.data();
    for (n = 0; n < dwSize; n++)
    {
        if (dwDocPage <= pData[n])
            pData[n] = pData[n] + nVal;
    }
}

void BoraDoc::setImportPageNumInfo(BrDWORD dwPage, BrDWORD dwNewNum)
{
	if (getEditMasterType() != EDIT_MASTER_NONE && getEditMasterType() != EDIT_SLIDE_NOTE)
		return;

	if (0 == m_ImportPageNumInfo.size())
        return;

    m_ImportPageNumInfo.SetAt(dwPage - 1, dwNewNum);
}

BrDWORD BoraDoc::getImportPageNumInfo(BrDWORD dwPage)
{
	if (getEditMasterType() != EDIT_MASTER_NONE && getEditMasterType() != EDIT_SLIDE_NOTE)
		return 0;

	if (0 == m_ImportPageNumInfo.size())
        return 0;

    return m_ImportPageNumInfo.at(dwPage);
}

BrDWORD BoraDoc::getRealImportPageNumInfo(BrDWORD dwDocPageNum)
{
	BrDWORD n = 0;
    CPage *pPage = m_PageArray->getPage(dwDocPageNum);

    if (pPage)
    {
        n = pPage->getOrgPPTSlideNum();
        if (0 < n)
            return n;
    }

    BrDWORD dwSize = m_ImportPageNumInfo.size();
    if (0 == dwSize)
        return 0;

    BrDWORD *pData = (BrDWORD *)m_ImportPageNumInfo.data();
    for (n = 0; n < dwSize; n++)
    {
        if (dwDocPageNum == pData[n])
            return n + 1;
    }

    return 0;
}

BrDWORD BoraDoc::getFirstAppealImportPageNumInfo(BrDWORD dwDocPageNum)
{
    BrDWORD dwSize = m_ImportPageNumInfo.size();
    if (0 == dwSize)
        return 0;

    BrDWORD n, *pData = (BrDWORD *)m_ImportPageNumInfo.data();
    for (n = 0; n < dwSize; n++)
    {
        if (dwDocPageNum <= pData[n])
            return n + 1;
    }

    return 0;
}

void BoraDoc::initISlideIDInfo(BrDWORD dwPages)
{
	if (getEditMasterType() != EDIT_MASTER_NONE && getEditMasterType() != EDIT_SLIDE_NOTE)
		return;

	m_SlideIDinfo.resize(dwPages);
	BrDWORD n, *pData = (BrDWORD *)m_SlideIDinfo.data();
	for (n = 0; n < dwPages; n++)
		pData[n] = 0;
}

void BoraDoc::setSlideIDInfo(BrDWORD dwPage, BrDWORD dwSlideID)
{
	if (getEditMasterType() != EDIT_MASTER_NONE && getEditMasterType() != EDIT_SLIDE_NOTE)
		return;

	if (0 == m_SlideIDinfo.size())
		return;

#ifdef USE_COLLABORATION
	CollaborationProvider *pProvider = g_pCollaborationProvider;
	if(pProvider)
		pProvider->sendCLBControlStatusToUI( pProvider->getCurrentEvent()->pFunc, BR_COLLABORATION_CONTROL_THUMBNAIL_DRAG_CANCEL );
#endif //#ifdef USE_COLLABORATION

	m_SlideIDinfo.SetAt(dwPage - 1, dwSlideID);
}

BrDWORD BoraDoc::getSlideIDInfo(BrDWORD dwPage)
{
// 	if (getEditMasterType()!=EDIT_MASTER_NONE)
// 		return 0;

	if(dwPage < 1)
		return 0;

	if (0 == m_SlideIDinfo.size() || dwPage > m_SlideIDinfo.size())
	{
		SET_EDIT_WARNING_LOG(kPoWarnAccessArrayOverFlowedIndex, ErrMsg("getSlideIDInfo FAILURE : SlideIDInfoSize:[%d] PageNum:[%d]", m_SlideIDinfo.size(), dwPage));
		BRTHREAD_ASSERT(0); //���� data ���� ũ�� �䱸�� ��� �Դϴ�.
		return 0;
	}

	return m_SlideIDinfo.at(dwPage-1);
}

void BoraDoc::addSlideIDInfo(BrDWORD dwSlideID)
{
	if (getEditMasterType() != EDIT_MASTER_NONE && getEditMasterType() != EDIT_SLIDE_NOTE)
		return;

#ifdef USE_COLLABORATION
	CollaborationProvider *pProvider = g_pCollaborationProvider;
	if(pProvider)
		pProvider->sendCLBControlStatusToUI( pProvider->getCurrentEvent()->pFunc, BR_COLLABORATION_CONTROL_THUMBNAIL_DRAG_CANCEL );
#endif //#ifdef USE_COLLABORATION

	m_SlideIDinfo.Add(dwSlideID);
}

void BoraDoc::deleteSlideIDInfo(BrDWORD dwPage)
{
	if (getEditMasterType() != EDIT_MASTER_NONE && getEditMasterType() != EDIT_SLIDE_NOTE)
		return;

	if (0 == m_SlideIDinfo.size())
		return ;

#ifdef USE_COLLABORATION
	CollaborationProvider *pProvider = g_pCollaborationProvider;
	if(pProvider)
		pProvider->sendCLBControlStatusToUI( pProvider->getCurrentEvent()->pFunc, BR_COLLABORATION_CONTROL_THUMBNAIL_DRAG_CANCEL );
#endif //#ifdef USE_COLLABORATION

	m_SlideIDinfo.RemoveAt(dwPage - 1);
}

void BoraDoc::InsertSlideIDInfo(BrDWORD dwPage, BrDWORD dwSlideID)
{
	if (getEditMasterType() != EDIT_MASTER_NONE && getEditMasterType() != EDIT_SLIDE_NOTE)
		return;

	//AOM-39289
	if (m_nDocType == BORA_DOCTYPE_PPT)
		return;

#ifdef USE_COLLABORATION
	CollaborationProvider *pProvider = g_pCollaborationProvider;
	if(pProvider)
		pProvider->sendCLBControlStatusToUI( pProvider->getCurrentEvent()->pFunc, BR_COLLABORATION_CONTROL_THUMBNAIL_DRAG_CANCEL );
#endif //#ifdef USE_COLLABORATION

	m_SlideIDinfo.InsertAt(dwPage - 1, dwSlideID);
}

void BoraDoc::changeSlideIDInfo(BrDWORD dwSrcPage, BrDWORD dwDstPage)
{
	if (getEditMasterType() != EDIT_MASTER_NONE && getEditMasterType() != EDIT_SLIDE_NOTE)
		return;

	if (1 > m_SlideIDinfo.size())
		return;

#ifdef USE_COLLABORATION
	CollaborationProvider *pProvider = g_pCollaborationProvider;
	if(pProvider)
		pProvider->sendCLBControlStatusToUI( pProvider->getCurrentEvent()->pFunc, BR_COLLABORATION_CONTROL_THUMBNAIL_DRAG_CANCEL );
#endif //#ifdef USE_COLLABORATION

	BrINT nSrcID = m_SlideIDinfo.at(dwSrcPage - 1);
	m_SlideIDinfo.RemoveAt(dwSrcPage - 1);
	m_SlideIDinfo.InsertAt(dwDstPage - 1, nSrcID);
}


BrDWORD BoraDoc::getSlideIDMaxInfo()
{
	if (getEditMasterType() != EDIT_MASTER_NONE && getEditMasterType() != EDIT_SLIDE_NOTE)
		return -1;

	if (1 > m_SlideIDinfo.size())
		return -1;

	BrDWORD n, *pData = (BrDWORD *)m_SlideIDinfo.data();
	BrDWORD nMax = 0;
	for (n = 0; n < m_SlideIDinfo.size(); n++)
	{
		if(nMax < pData[n])
			nMax = pData[n];
	}
	return nMax;
}

BrDWORD BoraDoc::getSlideIDPageIndex(BrDWORD dwSlidID)
{
	if (getEditMasterType() != EDIT_MASTER_NONE && getEditMasterType() != EDIT_SLIDE_NOTE)
		return 0;

	if (0 == m_SlideIDinfo.size())
		return 0;

	BrDWORD n, *pData = (BrDWORD *)m_SlideIDinfo.data();

	for (n = 0; n < m_SlideIDinfo.size(); n++)
	{
		if(pData[n] == dwSlidID)
			return n+1;	//Array Index�� �ƴ� Page Number�� Return �մϴ�.
	}
	return 0;
}

BrINT32 BoraDoc::getSlideIDSize()
{
// 	if (getEditMasterType()!=EDIT_MASTER_NONE)
// 		return -1;

	return m_SlideIDinfo.size();
}

BrINT32 BoraDoc::getSlideSectionID(BrINT nCurPagNum)
{
	if(!m_SlideSectionArray)
		return 0;

	int pCurSectioID = 0;

	for(int i = 0; i<m_SlideSectionArray->size();i++)
	{
		SlideSection *pTempSection = m_SlideSectionArray->at(i);
		pCurSectioID = pTempSection->getID(nCurPagNum);
		if(pCurSectioID != 0)
		{
			return pCurSectioID;
		}
	}
	return 0;
}

SlideSection* BoraDoc::getSlideSection(BrINT nCurPagNum)
{
	if(!m_SlideSectionArray)
		return 0;

	int pCurSectioID = 0;

	for(int i = 0; i<m_SlideSectionArray->size();i++)
	{
		SlideSection *pTempSection = m_SlideSectionArray->at(i);
		pCurSectioID = pTempSection->getID(nCurPagNum);
		if(pCurSectioID != 0)
		{
			return pTempSection;
		}
	}
	return 0;
}


void BoraDoc::InsertSlideSection(BrINT nSectionID,SlideSection *nSlideSection)
{
	m_SlideSectionArray->InsertAt(nSectionID-1,nSlideSection);

	for(int i = 0; i < m_SlideSectionArray->size(); i++)
	{
		SlideSection *pSection = m_SlideSectionArray->at(i);
		pSection->m_nID = i+1;
	}
}
void BoraDoc::RemoveSlideSection(BrINT nSectionID,BrINT nPrevEndPageNum)
{
	SlideSection *pCurSection = m_SlideSectionArray->at(nSectionID-1);
	if(m_SlideSectionArray->size() > 1)
	{
		SlideSection *pSection = BrNULL;
		if(nSectionID-1 == 0)
		{
			pSection = m_SlideSectionArray->at(nSectionID); // NextSection
			if(pCurSection->getPageCount() != 0)
				pSection->setStartPage(pCurSection->getStartPage());
		}
		else
		{
			pSection = m_SlideSectionArray->at(nSectionID-2); // PrevSection
			if(pSection->getPageCount() == 0)
			{
				pSection->setStartPage(pCurSection->getStartPage());
				pSection->setEndPage(pCurSection->getEndPage());
			}
			else
			{
				if(pCurSection->getPageCount() != 0)
				{
					if(pSection->m_nStartPageNum == 0)
						pSection->setEndPage(pCurSection->getStartPage());
					pSection->setEndPage(pCurSection->getEndPage());
				}
			}

		}
	}
	m_SlideSectionArray->RemoveAt(nSectionID-1);

	for(int i = 0; i < m_SlideSectionArray->size(); i++)
	{
		SlideSection *pSection = m_SlideSectionArray->at(i);
		pSection->m_nID = i+1;
	}
}

#endif // PPT_EDITOR


#ifdef BWP_EDITOR
// panning, flicking���� fillSolidRect()�� ȿ�������� �ϱ� ���Ͽ� �ٽ� �������
void BoraDoc::fillSolidRectWithClip(Painter *pPainter, BrINT32 x1, BrINT32 y1, BrINT32 x2, BrINT32 y2, BrCOLORREF color)
{
	if ( x1<0 )
	{
		if ( x2<0 ) return;
		x1 = 0;

	}
	if ( x2>getLCDWidth() )
	{
		if ( x1>getLCDWidth() ) return;
		x2 = getLCDWidth();
	}

	if ( y1<0 )
	{
		if ( y2<0 ) return;
		y1 = 0;
	}
	if ( y2>getLCDHeight() )
	{
		if ( y1>getLCDHeight() ) return;
		y2 = getLCDHeight();
	}

	if ( getHorClipRectFlag() || getVerClipRectFlag() )
	{
		BRect	rcVFinal, rcHFinal, rcDraw;
		if ( getHorClipRectFlag() )
		{
			rcDraw.init4(x1, y1, x2, y2);
			if ( rcHFinal.IntersectRect(rcDraw, m_rcHorClipRect) )
				//pPainter->pDC->fillSolidRect(rcHFinal.nLeft, rcHFinal.nTop, rcHFinal.nRight, rcHFinal.nBottom, GetBrRValue(color), GetBrGValue(color), GetBrBValue(color));
				pPainter->drawPageBG(rcHFinal.nLeft, rcHFinal.nTop, rcHFinal.nRight, rcHFinal.nBottom, color);
#ifdef _DEBUG
			// BTrace("HorRect : left=%d, top=%d, right=%d, bottom=%d, color=%x", rcDraw.nLeft, rcDraw.nTop, rcDraw.nRight, rcDraw.nBottom, color);
#endif // _DEBUG
		}
		if ( getVerClipRectFlag() )
		{
			rcDraw.init4(x1, y1, x2, y2);
			if ( rcVFinal.IntersectRect(rcDraw, m_rcVerClipRect) )
			{
				if ( getHorClipRectFlag() && !rcHFinal.IsEmpty() )
				{
					// left/bottom, right/bottom
					if ( rcVFinal.nBottom==rcHFinal.nBottom && rcVFinal.nTop<rcHFinal.nTop && rcVFinal.nLeft>=rcHFinal.nLeft && rcVFinal.nRight<=rcHFinal.nRight )
						rcVFinal.nBottom = rcHFinal.nTop;
					// right/top, left/top
					if ( rcVFinal.nTop==rcHFinal.nTop && rcVFinal.nBottom<rcHFinal.nBottom && rcVFinal.nLeft>=rcHFinal.nLeft && rcVFinal.nRight<=rcHFinal.nRight )
						rcVFinal.nTop = rcHFinal.nBottom;
				}
				//pPainter->pDC->fillSolidRect(rcVFinal.nLeft, rcVFinal.nTop, rcVFinal.nRight, rcVFinal.nBottom, GetBrRValue(color), GetBrGValue(color), GetBrBValue(color));
				pPainter->drawPageBG(rcVFinal.nLeft, rcVFinal.nTop, rcVFinal.nRight, rcVFinal.nBottom, color);
			}
#ifdef _DEBUG
			// BTrace("VerRect : left=%d, top=%d, right=%d, bottom=%d, color=%x", rcDraw.nLeft, rcDraw.nTop, rcDraw.nRight, rcDraw.nBottom, color);
#endif // _DEBUG
		}

	}
	else
	{
		//pPainter->pDC->fillSolidRect(x1, y1, x2, y2, GetBrRValue(color), GetBrGValue(color), GetBrBValue(color));
		pPainter->drawPageBG(x1, y1, x2, y2, color);
	}
}
#endif // BWP_EDITOR

#if defined(BWP_EDITOR) && defined(PPT_EDITOR)
void BoraDoc::adjustCreatePasteTextFramePos()
{
    CFrame *pFrame = m_Caret->getLineFrame();
    if (!pFrame)
        return;

    pFrame->setOnceStretchFlag(BrTRUE);
    CTextProc::shortenTextFrame(pFrame->getPage(), pFrame);

    BRect *pRect = pFrame->getFrameRect();
    BrINT nHeight = pRect->getHeight();
    BrINT nPageHeight = pFrame->getPage()->height();

    if (nPageHeight > nHeight)
    {
        pRect->nTop = (nPageHeight - nHeight) / 2;
        pRect->nBottom = pRect->nTop + nHeight;
    }
}

//[2012.12.10][TID:11065][�����]�����̵尡 ���� ��� �Ӹ� �ƴ϶� ��Ȳ�� ���� �� �����̵� ������ �Լ��ε� ����ϱ� ���� ����.
void BoraDoc::createEmptyPageForPPT(BrINT32 a_nPageNum)
{
	//if (1 < m_PageArray->size() && m_PageArray->at(0))
	//	return;

	CPage *pPageNew = BrNEW CPage();
	if (pPageNew==BrNULL || pPageNew->getPaperSize()==BrNULL || pPageNew->getColumn()==BrNULL)
		return;

	//�ش� �������� Created�� ����
	pPageNew->setCreated(BrTRUE);
	CPaperSize *pPaperSize = pPageNew->getPaperSize();

	pPaperSize->m_nWidth = m_slideSize.cx;
	pPaperSize->m_nHeight = m_slideSize.cy;
	pPaperSize->setDirection(LANDSCAPE);

	pPageNew->setLayout(LAYOUT_TYPE_TITLE_SUBTITLE);

	m_PageArray->SetAt(a_nPageNum - 1, pPageNew);
	pPageNew->setPageArray(m_PageArray);
}

void BoraDoc::resetPenFlagForSlideShow()
{
	if (getBWPEngineMode() == EDITOR_WORD || getPageArray() == BrNULL)
		return;

	for (int i = 0 ; i < getPageArray()->size(); i++)
	{
		CPage *pPage = getPageArray()->at(i);
		if (pPage)
		{
			CFrameList *pFrameList = getAFrameList(pPage);
			if (pFrameList)
			{
				CFrame *pFrame = pFrameList->getFirst();
				while (pFrame)
				{
					if (pFrame->getNewPenAfterSlideShow())
						pFrame->setNewPenAfterSlideShow(BrFALSE);
					pFrame = pFrameList->getNext(pFrame);
				}
			}
		}
	}
}

void BoraDoc::deletePenDataForViewTogether()
{
	CFrame *pNext = BrNULL;
	CFrame *pFrame = BrNULL;
	CFrameList *pFrameList = BrNULL;

	if (getBWPEngineMode() == EDITOR_PPT)
	{
		for (int i = 0 ; i < getPageArray()->size() ; i++)
		{
			CPage *pPage = getPageArray()->at(i);
			if (pPage) {
				pFrameList = getAFrameList(pPage);
				pFrame = pFrameList->getFirst();
				while ( pFrame )
				{
					if ( pFrame->getPenAfterViewToghther() )
					{
						pNext = pFrameList->getNext(pFrame);
						pFrameList->remove(pFrame);
						pFrame = pNext;
					}
					else
						pFrame = pFrameList->getNext(pFrame);

				}
			}
		}
		return;
	}

	CPage *pPage = theBWordDoc->getPageArray()->getPage(0);
	pFrameList = getAFrameList(pPage);
	pFrame = pFrameList->getFirst();

	while ( pFrame )
	{
		if ( pFrame->getPenAfterViewToghther() )
		{
			pNext = pFrameList->getNext(pFrame);
			pFrameList->remove(pFrame);
			pFrame = pNext;
		}
		else
			pFrame = pFrameList->getNext(pFrame);
	}

}

void BoraDoc::resetFlagForViewTogether()
{
	CFrame *pFrame = BrNULL;
	CFrameList *pFrameList = BrNULL;
	if (getBWPEngineMode() == EDITOR_PPT)
	{
		for (int i = 0 ; i < getPageArray()->size() ; i++)
		{
			CPage *pPage = getPageArray()->at(i);
			if (pPage)
			{
				pFrameList =  getAFrameList(pPage);
				pFrame =  pFrameList->getFirst();
				while ( pFrame )
				{
					if ( pFrame->getPenAfterViewToghther() )
						pFrame->setPenAfterViewTogether(BrFALSE);
					pFrame = pFrameList->getNext(pFrame);
				}
			}
		}
		return;
	}

	pFrameList =  isEditMasterPage() ? getMstAFrameList() : getAFrameList();
	pFrame =  pFrameList->getFirst();
	while ( pFrame )
	{
		if ( pFrame->getPenAfterViewToghther() )
			pFrame->setPenAfterViewTogether(BrFALSE);
		pFrame = pFrameList->getNext(pFrame);
	}
}

BrBOOL BoraDoc::isPenDataForSlideShow(BrINT nPageNum)
{
	if (getBWPEngineMode() == EDITOR_WORD)
		return BrFALSE;

	BrINT nStartPage = 0;
	BrINT nEndPage =0;
	if (nPageNum == 0)
	{
		nStartPage = 0;
		nEndPage = getPageArray()->size()-1;
	}else {
		nStartPage = nPageNum-1;
		nEndPage = nPageNum-1;
	}
	for (int i = nStartPage ; i <= nEndPage ; i++)
	{
		CPage *pPage = getPageArray()->at(i);
		if (pPage) {
			CFrameList *pFrameList = getAFrameList(pPage);
			if(!pFrameList)
				return BrFALSE;
			CFrame *pFrame = pFrameList->getFirst();
			while ( pFrame )
			{
				//nPageNum�� 0�̸� ��ü �������� ���ؼ� üũ
				if ( pFrame->getNewPenAfterSlideShow())
					return BrTRUE;
				pFrame = pFrameList->getNext(pFrame);
			}
		}
	}
	return BrFALSE;
}

void BoraDoc::deletePenDataForSlideShow()
{
	if (getBWPEngineMode() == EDITOR_WORD)
		return;

	CFrame *pNext = BrNULL;
	CFrame *pFrame = BrNULL;
	CFrameList *pFrameList = BrNULL;
	for (int i = 0 ; i < getPageArray()->size() ; i++)
	{
		CPage *pPage = getPageArray()->at(i);
		if (pPage) {
			pFrameList = getAFrameList(pPage);
			pFrame = pFrameList->getFirst();
			while ( pFrame )
			{
				if ( pFrame->getNewPenAfterSlideShow() )
				{
					pNext = pFrameList->getNext(pFrame);
					pFrameList->remove(pFrame);
					pFrame = pNext;
				}
				else
				{
					pFrame = pFrameList->getNext(pFrame);
				}
			}
		}
	}
}

void BoraDoc::savePenDataForSlideShow()
{
	if (!m_CmdEngine->isSlideShow())
		return;

	for (int i = 0 ; i < getPageArray()->size() ; i++)
	{
		CPage *pPage = getPageArray()->at(i);
		if (pPage) {
			CFrameList *pFrameList = getAFrameList(pPage);
			CFrame *pFrame = pFrameList->getFirst();
			while ( pFrame )
			{
				if (pFrame->getNewPenAfterSlideShow())
					pFrame->setCreated(BrTRUE);
				pFrame = pFrameList->getNext(pFrame);
			}
		}
	}
}

void BoraDoc::resetPenFlagForFreeDraw()
{
	CFrame *pFrame = BrNULL;
	CFrameList *pFrameList = BrNULL;
	if (getBWPEngineMode() == EDITOR_PPT)
	{
		for (int i = 0 ; i < getPageArray()->size() ; i++)
		{
			CPage *pPage = getPageArray()->at(i);
			if (pPage)
			{
				pFrameList =  getAFrameList(pPage);
				pFrame =  pFrameList->getFirst();
				while ( pFrame )
				{
					if ( pFrame->isNewPenData() )
						pFrame->setNewPenData(BrFALSE);
					pFrame = pFrameList->getNext(pFrame);
				}
			}
		}
		return;
	}

	pFrameList =  isEditMasterPage() ? getMstAFrameList() : getAFrameList();
	pFrame =  pFrameList->getFirst();
	while ( pFrame )
	{
		if ( pFrame->isNewPenData() )
			pFrame->setNewPenData(BrFALSE);
		pFrame = pFrameList->getNext(pFrame);
	}
}

BrBOOL BoraDoc::isPenDataForFreeDraw()
{

	CFrame *pFrame = BrNULL;
	CFrameList *pFrameList = BrNULL;

	if (getBWPEngineMode() == EDITOR_PPT)
	{
		for (int i = 0 ; i < getPageArray()->size() ; i++)
		{
			CPage *pPage = getPageArray()->at(i);
			if (pPage)
			{
				pFrameList =  getAFrameList(pPage);
				pFrame =  pFrameList->getFirst();

				while ( pFrame )
				{
					//131014 hizoa tiket 17938
					if ( pFrame->isInfraPenDraw() )
						return BrTRUE;
					pFrame = pFrameList->getNext(pFrame);
				}
			}
		}
		return BrFALSE;
	}

	pFrameList =  isEditMasterPage() ? getMstAFrameList() : getAFrameList();
	pFrame =  pFrameList->getFirst();

	while ( pFrame )
	{
		//131014 hizoa tiket 17938
		if ( pFrame->isInfraPenDraw() )
			return BrTRUE;
		pFrame = pFrameList->getNext(pFrame);
	}
	return BrFALSE;
}

void BoraDoc::deletePenDataForFreeDraw()
{
	CFrame *pFrame = BrNULL;
	CFrame *pNext = BrNULL;
	CFrameList *pFrameList = BrNULL;

	if (getBWPEngineMode() == EDITOR_PPT)
	{
		for (int i = 0 ; i < getPageArray()->size() ; i++)
		{
			CPage *pPage = getPageArray()->at(i);
			if (pPage)
			{
				pFrameList =  getAFrameList(pPage);
				pFrame =  pFrameList->getFirst();

				while ( pFrame )
				{
					if ( pFrame->isNewPenData() )
					{
						pNext = pFrameList->getNext(pFrame);
						pFrameList->remove(pFrame);
						pFrame = pNext;
					}
					else
					{
						pFrame = pFrameList->getNext(pFrame);
					}
				}
			}
		}
		return;
	}

	pFrameList =  isEditMasterPage() ? getMstAFrameList() : getAFrameList();
	pFrame =  pFrameList->getFirst();
	while ( pFrame )
	{
		if ( pFrame->isNewPenData() )
		{
			pNext = pFrameList->getNext(pFrame);
			pFrameList->remove(pFrame);
			pFrame = pNext;
		}
		else
		{
			pFrame = pFrameList->getNext(pFrame);
		}
	}
}

void BoraDoc::setPlaceHolderArray()
{
	CCmdEngine* pCmdEngine = getCmdEngine();
	if(!pCmdEngine)
		return;

	auto& aSringArray = getPlaceHolderStringArray();

	if(aSringArray.size() > 0)
		return;

	for(int i = 0; i < 49; i++)
	{
		BrUSHORT dispText[128] = {0};
		BString aString;
		pCmdEngine->getResString((BrResStringID)i, dispText, 128);
		aString = dispText;
		aSringArray.Add(aString);
	}
}
BString BoraDoc::getPlaceHolderIndexString(BrINT a_nIndex)
{
	auto& aSringArray = getPlaceHolderStringArray();
	if(aSringArray.size() < 1)
	{
		BString s_emptyString;
		return s_emptyString;
	}
	return aSringArray.at(a_nIndex);
}
#endif // defined(BWP_EDITOR) && defined(PPT_EDITOR)

#ifdef BIDI_SUPPORT
BrBOOL BoraDoc::isBidiSameCharSetType(CCharSet *pCharSet1, CCharSet *pCharSet2)
{
    if (!pCharSet1 || !pCharSet2)
        return BrFALSE;

    BrWORD wID1 = pCharSet1->getAttrID();
    BrWORD wID2 = pCharSet2->getAttrID();

    if (wID1 == wID2)
        return BrTRUE;


    const PoTextAtt *pAtt1 = GetTextAttr(wID1);
    const PoTextAtt *pAtt2 = GetTextAttr(wID2);

    if (pAtt1->getEngFontID() != pAtt2->getEngFontID() || pAtt1->getEngFSize() != pAtt2->getEngFSize() ||
        pAtt1->getBold() != pAtt2->getBold() || pAtt1->getItalic() != pAtt2->getItalic() ||
        pAtt1->getSubscript() != pAtt2->getSubscript() || pAtt1->getSuperscript() != pAtt2->getSuperscript())
        return BrFALSE;

    return BrTRUE;
}

BrBOOL BoraDoc::isBidiCharSet(CCharSet *pLink)
{
    if (!pLink)
        return BrFALSE;

    const PoTextAtt *pTextAtt = GetTextAttr(pLink->getAttrID());
    if (pTextAtt)
        return pTextAtt->getBiDi();
    else
        return BrFALSE;
}
#endif // BIDI_SUPPORT

int	BoraDoc::getWordCount(CFrameList *pFrameList, BrBOOL bNeedCalc)//[2012.07.31][TID:8236][�����] word �ܾ� ��
{
	if(BrFALSE  == bNeedCalc)
		return m_nWordCount;

	int nWordCount = 0;
	int nCharCount = 0;

	CLine *pLine  = getFirstLine();
	CCharSet *pCharSet = BrNULL;

	BrBOOL bWordStart = BrFALSE;
	while(pLine)
	{
		nCharCount = pLine->getCharNum();
		for(int i = 0; i< nCharCount; i++)
		{
			pCharSet = pLine->getCharSet(i);
			if( pCharSet->isTextLink())
			{
				if(pCharSet->isWhiteCharacterLinkForFinding (BrTRUE))
				{
					if(bWordStart)
					{
						nWordCount ++;
						bWordStart = BrFALSE;
					}
				}else
				{
					if(!bWordStart)
					{
						bWordStart = BrTRUE;
					}
				}
			}
			else if( pCharSet->isImageBulletLink() )
			{
				if(bWordStart)
				{
					nWordCount ++;
					bWordStart = BrFALSE;
				}
			}
			else if(pCharSet->isAnchorLink())
			{
				CFrame* pFrame = BrNULL;
				if(pFrameList && pCharSet->isAnchorLink() )
					pFrame = pFrameList->getFrame( pCharSet->getCode());

				if( pFrame )
				{
					int in_frame_cnt = pFrame->extractWordCount();

					if( in_frame_cnt > 0 )
					{
						nWordCount+=in_frame_cnt;
					}
				}
			}
		}

		pLine = pLine->getNext();
		bWordStart = BrFALSE;
		if(BrNULL == pLine)
			break;
	}

	return nWordCount;
}

CBrSummaryData* BoraDoc::getSummaryData()
{
	if(!m_pSummaryData)
		m_pSummaryData = BrNEW	CBrSummaryData();

	return m_pSummaryData;
}

BrBOOL BoraDoc::getSummaryData(BrCHAR * szTitle,  int szTitleSize, BrCHAR * szAuthor, int szAuthorSize, BrCHAR * szModifiedBy, int szModifiedBySize, BrINT *page, BrINT *words, BrBOOL * bSavePreview, BrCHAR* szAppName, int szAppNameSize)
{
	if(!m_pSummaryData)
		m_pSummaryData = BrNEW	CBrSummaryData();

	memset(szTitle, 0, szTitleSize);
	memset(szAuthor, 0, szAuthorSize);
	memset(szModifiedBy, 0, szModifiedBySize);
	memset(szAppName, 0, szAppNameSize);


	BString* strTmp;
	strTmp = m_pSummaryData->getTitle();
	if(strTmp)
	{
		BrWideCharToMultiByte(CP_UTF8, (BrLPCWSTR) strTmp->unicode(), strTmp->length(), szTitle, szTitleSize);
	}

	strTmp = m_pSummaryData->getAuthor();
	if(strTmp)
	{
		BrWideCharToMultiByte(CP_UTF8, (BrLPCWSTR)strTmp->unicode(), strTmp->length(), szAuthor, szAuthorSize);
	}


	strTmp = m_pSummaryData->getLastAuthor();
	if(strTmp)
	{
		BrWideCharToMultiByte(CP_UTF8, (BrLPCWSTR) strTmp->unicode(), strTmp->length(), szModifiedBy, szModifiedBySize);
	}

	strTmp = m_pSummaryData->getAppName();
	if(strTmp)
	{
		BrWideCharToMultiByte(CP_UTF8, (BrLPCWSTR) strTmp->unicode(), strTmp->length(), szAppName, szAppNameSize);
	}

	*words =  m_pSummaryData->getWordCnt();
	*page  =  m_pSummaryData->getPageCnt();
	*bSavePreview = m_pSummaryData->getSavePreview();

	int current_words = 0;

	if (getBWPEngineMode() == EDITOR_PPT) {
		for (int i = 0 ; i < getPageArray()->size(); i++) {
			CPage *pPage = getPageArray()->at(i);
			if (pPage) {
				current_words += getWordCount(getAFrameList(pPage), BrTRUE);
			}
		}
	}else {
		BrWordCountStatistics WordCountStatistics = {0,};
		if(CTextProc::UpdateLineWordCount(&WordCountStatistics, BrNULL, BrNULL, BrTRUE))
			current_words = WordCountStatistics.nWordCnt;
		else
			current_words = getWordCount(getAFrameList(), BrTRUE);
	}

	if(current_words != *words)
	{
		if(getBWPEngineMode() == EDITOR_WORD)
			*words =  current_words;
	}

	int current_pages =  getTotalPages();
	if(current_pages  !=  *page )
	{
		*page  = current_pages;
	}


	return BrTRUE;

}

BrBOOL BoraDoc::setSummaryData(BrINT nMask, BrCHAR *szTitle, BrCHAR *szAuthor, BrCHAR *szModifiedBy, BrCHAR *szAppName, BrBOOL bSavePreview)
{
	if (!m_pSummaryData)
		m_pSummaryData = BrNEW CBrSummaryData();

	BrWCHAR* wStrFind = BrNULL;
	UINT size = 0;
	if (szTitle && (nMask & BR_SUMMARY_TITLE))
	{
		if (BrStrLen(szTitle) == 0)
			m_pSummaryData->removeTitle();
		else
		{
			size = (BrStrLen(szTitle) + 1) * BrSizeOf(BrWCHAR);
			wStrFind = (BrWCHAR*)BrMalloc(size);
			if (wStrFind)
			{
				memset(wStrFind, 0, size);
				size = toUnicodeSlimEDITOR(szTitle, BrStrLen(szTitle), wStrFind);

				BString strTitle;
				for (int j = 0; j < (int)size; j++)
					strTitle += BChar(wStrFind[j]);

				BrFree(wStrFind);

				m_pSummaryData->setTitle(&strTitle);
			}
		}
		setModifiedFlag(BrTRUE);
	}

	if (szAuthor && (nMask & BR_SUMMARY_AUTHOR))
	{
		if (BrStrLen(szAuthor) == 0)
			m_pSummaryData->removeAuthor();
		else
		{
			size = (BrStrLen(szAuthor) + 1) * BrSizeOf(BrWCHAR);
			wStrFind = (BrWCHAR*)BrMalloc(size);
			if (wStrFind)
			{
				memset(wStrFind, 0, size);
				size = toUnicodeSlimEDITOR(szAuthor, BrStrLen(szAuthor), wStrFind);

				BString strAuthor;
				for (int j = 0; j < (int)size; j++)
					strAuthor += BChar(wStrFind[j]);

				BrFree(wStrFind);

				m_pSummaryData->setAuthor(&strAuthor);
			}
		}
		setModifiedFlag(BrTRUE);
	}

	if (szModifiedBy && (nMask & BR_SUMMARY_MODIFIED_BY))
	{
		size = (BrStrLen(szModifiedBy) + 1) * BrSizeOf(BrWCHAR);
		wStrFind = (BrWCHAR*)BrMalloc(size);
		if (wStrFind)
		{

			memset(wStrFind, 0, size);
			size = toUnicodeSlimEDITOR(szModifiedBy, BrStrLen(szModifiedBy), wStrFind);

			BString strModified;
			for (int j = 0; j < (int)size; j++)
				strModified += BChar(wStrFind[j]);

			BrFree(wStrFind);

			m_pSummaryData->setLastAuthor(&strModified);
		}
		setModifiedFlag(BrTRUE);
	}

	if (szAppName && (nMask & BR_SUMMARY_APPNAME))
	{
		if (BrStrLen(szAppName) == 0)
			m_pSummaryData->removeAppName();
		else
		{
			size = (BrStrLen(szAppName) + 1) * BrSizeOf(BrWCHAR);
			wStrFind = (BrWCHAR*)BrMalloc(size);
			if (wStrFind)
			{
				memset(wStrFind, 0, size);
				size = toUnicodeSlimEDITOR(szAppName, BrStrLen(szAppName), wStrFind);

				BString strAppName;
				for (int j = 0; j < (int)size; j++)
					strAppName += BChar(wStrFind[j]);

				BrFree(wStrFind);

				m_pSummaryData->setAppName(&strAppName);
			}
		}
		setModifiedFlag(BrTRUE);
	}

	if (nMask & BR_SUMMARY_SAVE_PREVIEW)
	{
		m_pSummaryData->setSavePreview(bSavePreview);
		setModifiedFlag(BrTRUE);
	}

	return BrTRUE;

}

RevisionEngine* BoraDoc::getRevisionEngine()
{
	return m_CmdEngine ? m_CmdEngine->getRevisionEngine() : BrNULL;
}

BrBOOL BoraDoc::getTrackEnabled()
{
	return isSupportedRevision() && getRevisionEngine()->getTrackEnabled();
}

BrBOOL BoraDoc::canDrawRevisionFrame()
{
	return m_RevisionFrameList->getFirst()
		&& getRevisionEngine()->getReviewMode() == ReviewMode::ALL_MARKUP
		&& getRevisionEngine()->getFormatShowState();
}

BrBOOL BoraDoc::canDrawMemoFrame()
{
	return m_WordMemoFrameList->getFirst()
		&& isShowMemo()
		&& isMemoModeFrame()
		&& getRevisionEngine()->getMemoShowState();
}

void BoraDoc::setMemoMode(BrINT eMode)
{
	switch (eMode)
	{
	case 0:
		m_MemoEventManager->setMemoMode(memo_mode::FRAME);
		break;
	case 1:
		m_MemoEventManager->setMemoMode(memo_mode::SIMPLE);
		break;
	default:
		m_MemoEventManager->setMemoMode(memo_mode::NORMAL);
		break;
	}
}

BrBOOL BoraDoc::isMemoModeSimple()
{
	return m_MemoEventManager->getMemoMode() == memo_mode::SIMPLE;
}

BrBOOL BoraDoc::isMemoModeFrame()
{
	return m_MemoEventManager->getMemoMode() == memo_mode::FRAME;
}

BrBOOL BoraDoc::setDocPropertiesInfo(LPDOCPROPERTIESINFO pDocProperties)
{
	if(!pDocProperties)
		return BrFALSE;
	if(!m_pDocPropertiesInfo)
		m_pDocPropertiesInfo = BrNEW BArray<LPDOCPROPERTIESINFO>;

	if(!m_pDocPropertiesInfo)
		return BrFALSE;

	enumDocPropertiesValueType propertiesValueType = DOC_PROPERTIES_VT_BOOL;

	if( getDocType() == BORA_DOCTYPE_PPT)
		propertiesValueType = DOC_PROPERTIES_VT_BLOB;

	if(!pDocProperties->fmtid || !pDocProperties->name || !pDocProperties->text
		|| (pDocProperties->vt < DOC_PROPERTIES_VT_NONE || pDocProperties->vt > propertiesValueType ))
		return BrFALSE;

	m_pDocPropertiesInfo->Add(pDocProperties);

	return BrTRUE;
}

BArray<LPDOCPROPERTIESINFO>* BoraDoc::getDocPropertiesInfo()
{
	if(!m_pDocPropertiesInfo)
		return BrNULL;
	return m_pDocPropertiesInfo;
}

BrINT BoraDoc::getTotalDocPropertiesInfo()
{
	if(!m_pDocPropertiesInfo)
		return 0;
	return m_pDocPropertiesInfo->size();
}

BrINT BoraDoc::getRulerbarInfo( BrINT *pPageLeftLogical , BrINT *pTextLeftPos,  BrINT *pTextRightPos, BrINT *pPageRightPos, BrINT *pPageRightLogical )
{
	CCaret* pCaret = theBWordDoc->getCaret();

	*pPageLeftLogical = *pTextLeftPos= *pTextRightPos= *pPageRightPos= *pPageRightLogical = 0;

	int nPageWidth = 0;
	int mode = IsEditorMode(gpPaint);
	BrINT nMemoID = -1;
#ifdef PPT_EDITOR
	if( mode == EDITOR_PPT )
	{
		BrSize* pSize = BrNULL;
		if( isEditMasterHandout() || isEditMasterNote() || isEditSlideNote() )
			pSize = theBWordDoc->getSlideNotePaperSize();
		else
			pSize = theBWordDoc->getSlideSize();

		nPageWidth = pSize->cx;
	}
#endif //PPT_EDITOR
	if( pCaret && ( pCaret->isCaretNormal() || pCaret->isCaretMarking() ) )
	{
		CFrame* pFrame = pCaret->getLineFrame();

		if( pFrame )
		{
			CPage * pPage = pFrame->getPage();

			if( pPage )
			{
				CCmdEngine *pCE = theBWordDoc->getCmdEngine();

				if( mode == EDITOR_WORD )
					nPageWidth = pPage->width();
#ifdef WINDOWS_8
				*pPageLeftLogical = pCE->page2LogicalXMultiple1000( pPage , 0 );
				*pPageRightPos = nPageWidth;
				*pPageRightLogical = pCE->page2LogicalXMultiple1000( pPage , nPageWidth );
#else
				*pPageLeftLogical = pCE->page2LogicalX( pPage , 0 );
				*pPageRightPos = nPageWidth;
				*pPageRightLogical = pCE->page2LogicalX( pPage , nPageWidth );
#endif // WINDOWS_8
				if(pFrame->isSero() && mode == EDITOR_PPT)
				{
					CLine *pLine = pFrame->getFirstLine();
					BRect rcTextMark;
					rcTextMark.init1();

					if(pLine)
					{
						CTextProc::getMarkingArea(theBWordDoc, pFrame, pLine, 0, pLine->getCharNum()-1, rcTextMark);
						pLine = pLine->getNext();
					}

					while(pLine)
					{
						BRect rcLineMark;
						CTextProc::getMarkingArea(theBWordDoc, pFrame, pLine, 0, pLine->getCharNum()-1, rcLineMark);
						rcTextMark.Union(rcLineMark);
						pLine = pLine->getNext();
					}

					if(!pFrame->isContainParentMemoFrame(nMemoID))
					{
						*pTextLeftPos = rcTextMark.Left();
						*pTextRightPos = rcTextMark.Right();
					}
				}
				else
				{
					BRect* pRc = pFrame->getFrameRect();
					if(!pFrame->isContainParentMemoFrame(nMemoID))
					{
						*pTextLeftPos = pRc->Left() + pFrame->getBorderMarginLeft();
						*pTextRightPos = pRc->Right() - pFrame->getBorderMarginRight();
					}
				}
				return 1;
			}
		}
	}
	else
	{
		if( mode == EDITOR_PPT )
		{
			CCmdEngine *pCE = theBWordDoc->getCmdEngine();
			CPage * pPage = pCE->getCurrentPage();

			if( pPage == BrNULL )
			{
				CPageArray* pageArray = theBWordDoc->getEditingPageArray();
				if( pageArray )
				{
					pPage = pageArray->getPage(1);
				}
			}

			if( pPage )
			{
#ifdef WINDOWS_8
				*pPageLeftLogical = pCE->page2LogicalXMultiple1000( pPage , 0 );
				*pPageRightPos = nPageWidth;
				*pPageRightLogical = pCE->page2LogicalXMultiple1000( pPage , nPageWidth );
#else
				*pPageLeftLogical = pCE->page2LogicalX( pPage , 0 );
				*pPageRightPos = nPageWidth;
				*pPageRightLogical = pCE->page2LogicalX( pPage , nPageWidth );
#endif
				return 3;
			}

			return 0;
		}

		//���� �����϶� ó��.
		CTableEngine *pTableEngine = getCmdEngine()->getTableEngine();
		CMarkingCellsMgr *pMarker = pTableEngine->getMarker();

		if(pTableEngine->getTable()!=BrNULL && pTableEngine->isCellMarked())
		{
			CObArray *pFrameSetArray = pTableEngine->getMarker()->getMarkingFrameSets();
#ifdef	TABLE_SELECT_METHOD_1
			CBCell *pCell = BrNULL;
			if(isFromHwp())
				pCell = pMarker->getEndCell();

			CFrame *pFrame = BrNULL;
			if(pCell)
			{
				pFrame = pCell->getFrame();
			}
			else
			{
				if(pFrameSetArray->GetSize() > 0)
				{
					CFrameSet *pFrameSet = (CFrameSet *)pFrameSetArray->GetAt(0);
					pFrame = pFrameSet->getFirstFrame();
				}
			}
#else
			pFrame = pCell->getFrame();
#endif // TABLE_SELECT_METHOD_1
			CPage * pPage = BrNULL;
			if(pFrame)
				pPage = pFrame->getPage();

			if( pPage )
			{
				CCmdEngine *pCE = theBWordDoc->getCmdEngine();

				nPageWidth = pPage->width();
#ifdef WINDOWS_8
				*pPageLeftLogical = pCE->page2LogicalXMultiple1000( pPage , 0 );
				*pPageRightPos = nPageWidth;
				*pPageRightLogical = pCE->page2LogicalXMultiple1000( pPage , nPageWidth );
#else
				*pPageLeftLogical = pCE->page2LogicalX( pPage , 0 );
				*pPageRightPos = nPageWidth;
				*pPageRightLogical = pCE->page2LogicalX( pPage , nPageWidth );
#endif

				BRect rc;
				if(pFrame && !pFrame->isContainParentMemoFrame(nMemoID))//�޸� �������� ������ ���� �Ƚ�����
				{
					rc.CopyRect(pFrame->getFrameRect());
					rc.Left() = rc.Left() + pFrame->getBorderMarginLeft();
					rc.Right() = rc.Right() - pFrame->getBorderMarginRight();
					*pTextLeftPos = rc.Left();
					*pTextRightPos = rc.Right();
					return 2;//selected
				}
			}
		}

		CFrameSet* pFrameSet = getCmdEngine()->getFrameSet();
		int set_size = pFrameSet->getTotalElements();

		if( set_size == 1)//MistY - 2013.03.15 0025837 ���߼��� ����
		{
			CFrame *pFrame = pFrameSet->getFirst()->getFrame();
			if(pFrame->GetClass() == PICTUREFRAME && pFrame->getAnchorLine())
				pFrame = pFrame->getAnchorLine()->getFrame();

			CPage * pPage = pFrame ? pFrame->getPage() : BrNULL;
			if( pPage )
			{
				CCmdEngine *pCE = theBWordDoc->getCmdEngine();

				nPageWidth = pPage->width();
#ifdef WINDOWS_8
				*pPageLeftLogical = pCE->page2LogicalXMultiple1000( pPage , 0 );
				*pPageRightPos = nPageWidth;
				*pPageRightLogical = pCE->page2LogicalXMultiple1000( pPage , nPageWidth );
#else
				*pPageLeftLogical = pCE->page2LogicalX( pPage , 0 );
				*pPageRightPos = nPageWidth;
				*pPageRightLogical = pCE->page2LogicalX( pPage , nPageWidth );
#endif
				//�޸� �������� ������ ���� �Ƚ�����
				if(!pFrame->isContainParentMemoFrame(nMemoID))
				{
					BRect* pRc = pFrame->getFrameRect();

					*pTextLeftPos = pRc->Left() + pFrame->getBorderMarginLeft();
					*pTextRightPos = pRc->Right() - pFrame->getBorderMarginRight();
				}

				return 2;//selected
			}
		}
		else if( set_size > 1 ) //open // pg���� return
		{
			CFrame *pFrame = pFrameSet->getFirst()->getFrame();
			CPage * pPage = pFrame->getPage();
			if( pPage )
			{
				CCmdEngine *pCE = theBWordDoc->getCmdEngine();

				nPageWidth = pPage->width();
#ifdef WINDOWS_8
				*pPageLeftLogical = pCE->page2LogicalXMultiple1000( pPage , 0 );
				*pPageRightPos = nPageWidth;
				*pPageRightLogical = pCE->page2LogicalXMultiple1000( pPage , nPageWidth );
#else
				*pPageLeftLogical = pCE->page2LogicalX( pPage , 0 );
				*pPageRightPos = nPageWidth;
				*pPageRightLogical = pCE->page2LogicalX( pPage , nPageWidth );
#endif
				CFrame *pBasicFrame = pPage->getFirstBasic();
				if( pBasicFrame && !pBasicFrame->isContainParentMemoFrame(nMemoID))
				{
					BRect* pRc = pBasicFrame->getFrameRect();

					*pTextLeftPos = pRc->Left() + pBasicFrame->getBorderMarginLeft();
					*pTextRightPos = pRc->Right() - pBasicFrame->getBorderMarginRight();

					return 2;//selected
				}
			}
		}
		else
		{
			//���õ� ��ü�� ����
			CCmdEngine *pCE = theBWordDoc->getCmdEngine();
			CPage * pPage = pCE->getCurrentPage();
			if( pPage )
			{
				nPageWidth = pPage->width();
#ifdef WINDOWS_8
				*pPageLeftLogical = pCE->page2LogicalXMultiple1000( pPage , 0 );
				*pPageRightPos = nPageWidth;
				*pPageRightLogical = pCE->page2LogicalXMultiple1000( pPage , nPageWidth );
#else
				*pPageLeftLogical = pCE->page2LogicalX( pPage , 0 );
				*pPageRightPos = nPageWidth;
				*pPageRightLogical = pCE->page2LogicalX( pPage , nPageWidth );
#endif
				CFrame *pBasicFrame = pPage->getFirstBasic();
				if( pBasicFrame && !pBasicFrame->isContainParentMemoFrame(nMemoID))
				{
					BRect* pRc = pBasicFrame->getFrameRect();

					*pTextLeftPos = pRc->Left() + pBasicFrame->getBorderMarginLeft();
					*pTextRightPos = pRc->Right() - pBasicFrame->getBorderMarginRight();

					return 2;//selected
				}
			}
		}
	}


	return 0;
}

BrINT BoraDoc::getRulerbarInfoVertical( BrINT *pPageTopLogical , BrINT *pTextTopPos,  BrINT *pTextBottomPos, BrINT *pPageBottomPos, BrINT *pPageBottomLogical )
{
	CCaret* pCaret = theBWordDoc->getCaret();

	*pPageTopLogical = *pTextTopPos= *pTextBottomPos= *pPageBottomPos= *pPageBottomLogical = 0;

	int nPageHeight = 0;
	int mode = IsEditorMode(gpPaint);
	BrINT nMemoID = -1;
#ifdef PPT_EDITOR
	if( mode == EDITOR_PPT )
	{
		BrSize* pSize = BrNULL;
		if( isEditMasterHandout() || isEditMasterNote() || isEditSlideNote())
			pSize = theBWordDoc->getSlideNotePaperSize();
		else
			pSize = theBWordDoc->getSlideSize();

		nPageHeight = pSize->cy;
	}
#endif //PPT_EDITOR
	if( pCaret && ( pCaret->isCaretNormal() || pCaret->isCaretMarking() ) )
	{
		CFrame* pFrame = pCaret->getLineFrame();

		if( pFrame )
		{
			CPage * pPage = pFrame->getPage();

			if( pPage )
			{
				CCmdEngine *pCE = theBWordDoc->getCmdEngine();

				if( mode == EDITOR_WORD )
					nPageHeight = pPage->height();
#ifdef WINDOWS_8
				*pPageTopLogical = pCE->page2LogicalYMultiple1000( pPage , 0 );
				*pPageBottomPos = nPageHeight;
				*pPageBottomLogical = pCE->page2LogicalYMultiple1000( pPage , nPageHeight );
#else
				*pPageTopLogical = pCE->page2LogicalY( pPage , 0 );
				*pPageBottomPos = nPageHeight;
				*pPageBottomLogical = pCE->page2LogicalY( pPage , nPageHeight );
#endif
				if(pFrame->isGaro() && mode == EDITOR_PPT)
				{
					CLine *pLine = pFrame->getFirstLine();
					BRect rcTextMark;
					rcTextMark.init1();

					if(pLine)
					{
						CTextProc::getMarkingArea(theBWordDoc, pFrame, pLine, 0, pLine->getCharNum()-1, rcTextMark);
						pLine = pLine->getNext();
					}

					while(pLine)
					{
						BRect rcLineMark;
						CTextProc::getMarkingArea(theBWordDoc, pFrame, pLine, 0, pLine->getCharNum()-1, rcLineMark);
						rcTextMark.Union(rcLineMark);
						pLine = pLine->getNext();
					}

					if(!pFrame->isContainParentMemoFrame(nMemoID))
					{
						*pTextTopPos = rcTextMark.Top();
						*pTextBottomPos = rcTextMark.Bottom();
					}
				}
				else
				{
					if(!pFrame->isContainParentMemoFrame(nMemoID))
					{
						BRect* pRc = pFrame->getFrameRect();

						*pTextTopPos = pRc->Top() + pFrame->getBorderMarginTop();
						*pTextBottomPos = pRc->Bottom() - pFrame->getBorderMarginBottom();
					}
				}
				return 1;
			}
		}
	}
	else
	{
		if( mode == EDITOR_PPT )
		{
			CCmdEngine *pCE = theBWordDoc->getCmdEngine();
			CPage * pPage = pCE->getCurrentPage();

			if( pPage == BrNULL )
			{
				CPageArray* pageArray = theBWordDoc->getEditingPageArray();
				if( pageArray )
				{
					CPage* pPage = pageArray->getPage(1);
				}
			}

			if( pPage )
			{
#ifdef WINDOWS_8
				*pPageTopLogical = pCE->page2LogicalYMultiple1000( pPage , 0 );
				*pPageBottomPos = nPageHeight;
				*pPageBottomLogical = pCE->page2LogicalYMultiple1000( pPage , nPageHeight );
#else
				*pPageTopLogical = pCE->page2LogicalY( pPage , 0 );
				*pPageBottomPos = nPageHeight;
				*pPageBottomLogical = pCE->page2LogicalY( pPage , nPageHeight );
#endif
				return 3;
			}

			return 0;
		}

		//���� �����϶� ó��.

		CTableEngine *pTableEngine = getCmdEngine()->getTableEngine();
		CMarkingCellsMgr  *pMarker = pTableEngine->getMarker();

		if(pTableEngine->getTable()!=BrNULL && pTableEngine->isCellMarked())
		{
			CObArray *pFrameSetArray = pTableEngine->getMarker()->getMarkingFrameSets();
			CBCell *pCell = pMarker->getEndCell();

			CFrame *pFrame = BrNULL;
#ifdef	TABLE_SELECT_METHOD_1
			if(pCell)
			{
				pFrame = pCell->getFrame();
			}
			else
			{
				if(pFrameSetArray->GetSize() > 0)
				{
					CFrameSet *pFrameSet = (CFrameSet *)pFrameSetArray->GetAt(0);
					pFrame = pFrameSet->getFirstFrame();
				}
			}
#else
			pFrame = pCell->getFrame();
#endif // TABLE_SELECT_METHOD_1
			CPage * pPage = BrNULL;
			if(pFrame)
				pPage = pFrame->getPage();

			if( pPage )
			{
				CCmdEngine *pCE = theBWordDoc->getCmdEngine();

				nPageHeight = pPage->height();
#ifdef WINDOWS_8
				*pPageTopLogical = pCE->page2LogicalYMultiple1000( pPage , 0 );
				*pPageBottomPos = nPageHeight;
				*pPageBottomLogical = pCE->page2LogicalYMultiple1000( pPage , nPageHeight );
#else
				*pPageTopLogical = pCE->page2LogicalY( pPage , 0 );
				*pPageBottomPos = nPageHeight;
				*pPageBottomLogical = pCE->page2LogicalY( pPage , nPageHeight );
#endif
				BRect rc;
				if(pFrame && !pFrame->isContainParentMemoFrame(nMemoID))
				{
					rc.CopyRect(pFrame->getFrameRect());
					rc.Top() = rc.Top() + pFrame->getBorderMarginTop();
					rc.Bottom() = rc.Bottom() - pFrame->getBorderMarginBottom();
					*pTextTopPos = rc.Top();
					*pTextBottomPos = rc.Bottom();
					return 2;//selected
				}
			}
		}

		CFrameSet* pFrameSet = getCmdEngine()->getFrameSet();
		int set_size = pFrameSet->getTotalElements();

		if( set_size == 1)//MistY - 2013.03.15 0025837 ���߼��� ����
		{
			CFrame *pFrame = pFrameSet->getFirst()->getFrame();
			CPage * pPage = pFrame->getPage();
			if( pPage )
			{
				CCmdEngine *pCE = theBWordDoc->getCmdEngine();

				nPageHeight = pPage->height();
#ifdef WINDOWS_8
				*pPageTopLogical = pCE->page2LogicalYMultiple1000( pPage , 0 );
				*pPageBottomPos = nPageHeight;
				*pPageBottomLogical = pCE->page2LogicalYMultiple1000( pPage , nPageHeight );
#else
				*pPageTopLogical = pCE->page2LogicalY( pPage , 0 );
				*pPageBottomPos = nPageHeight;
				*pPageBottomLogical = pCE->page2LogicalY( pPage , nPageHeight );
#endif

				if(!pFrame->isContainParentMemoFrame(nMemoID))
				{
					BRect* pRc = pFrame->getFrameRect();

					*pTextTopPos = pRc->Top() + pFrame->getBorderMarginTop();
					*pTextBottomPos = pRc->Bottom() - pFrame->getBorderMarginBottom();
				}
				return 2;//selected
			}
		}
		else if( set_size > 1 ) //open // pg���� return
		{
			CFrame *pFrame = pFrameSet->getFirst()->getFrame();
			CPage * pPage = pFrame->getPage();
			if( pPage )
			{
				CCmdEngine *pCE = theBWordDoc->getCmdEngine();

				nPageHeight = pPage->height();
#ifdef WINDOWS_8
				*pPageTopLogical = pCE->page2LogicalYMultiple1000( pPage , 0 );
				*pPageBottomPos = nPageHeight;
				*pPageBottomLogical = pCE->page2LogicalYMultiple1000( pPage , nPageHeight );
#else
				*pPageTopLogical = pCE->page2LogicalY( pPage , 0 );
				*pPageBottomPos = nPageHeight;
				*pPageBottomLogical = pCE->page2LogicalY( pPage , nPageHeight );
#endif
				CFrame *pBasicFrame = pPage->getFirstBasic();
				if( pBasicFrame && !pFrame->isContainParentMemoFrame(nMemoID))
				{
					BRect* pRc = pBasicFrame->getFrameRect();

					*pTextTopPos = pRc->Top() + pBasicFrame->getBorderMarginTop();
					*pTextBottomPos = pRc->Bottom() - pBasicFrame->getBorderMarginBottom();

					return 2;//selected
				}
			}
		}
		else
		{
			//���õ� ��ü�� ����
			CCmdEngine *pCE = theBWordDoc->getCmdEngine();
			CPage * pPage = pCE->getCurrentPage();
			if( pPage )
			{
				nPageHeight = pPage->height();
#ifdef WINDOWS_8
				*pPageTopLogical = pCE->page2LogicalYMultiple1000( pPage , 0 );
				*pPageBottomPos = nPageHeight;
				*pPageBottomLogical = pCE->page2LogicalYMultiple1000( pPage , nPageHeight );
#else
				*pPageTopLogical = pCE->page2LogicalY( pPage , 0 );
				*pPageBottomPos = nPageHeight;
				*pPageBottomLogical = pCE->page2LogicalY( pPage , nPageHeight );
#endif
				CFrame *pBasicFrame = pPage->getFirstBasic();
				if( pBasicFrame && !pBasicFrame->isContainParentMemoFrame(nMemoID))
				{
					BRect* pRc = pBasicFrame->getFrameRect();

					*pTextTopPos = pRc->Top() + pBasicFrame->getBorderMarginTop();
					*pTextBottomPos = pRc->Bottom() - pBasicFrame->getBorderMarginBottom();

					return 2;//selected
				}
			}
		}
	}


	return 0;
}

#ifdef USE_RULERBAR//[2012.10.30][MistY][TID:#7674] RulerBar ����
BrBOOL BoraDoc::OnDrawRulerbar(Painter *pPainter,  BrDC *pDC)
{
	int nPageLeftLogical , nTextLeftPos,  nTextRightPos, nPageRightPos, nPageRightLogical;

	BrINT nRet = getRulerbarInfo(&nPageLeftLogical , &nTextLeftPos,  &nTextRightPos, &nPageRightPos, &nPageRightLogical);

	if( !nRet)
		return BrFALSE;

	if(!m_pHRuler)
		m_pHRuler = BrNEW CRulerBar;

	CPage *pPage = BrNULL;
	CCaret* pCaret = theBWordDoc->getCaret();

	if( pCaret && ( pCaret->isCaretNormal() || pCaret->isCaretMarking() ) )
	{
		CFrame* pFrame = pCaret->getLineFrame();

		if( pFrame )
			pPage = pFrame->getPage();
	}
	else
	{
		CFrameSet* pFrameSet = getCmdEngine()->getFrameSet();
		if(pFrameSet->getTotalElements() != 0)
		{
			CFrame *pFrame = pFrameSet->getFirst()->getFrame();
			pPage = pFrame->getPage();
		}
		else
		{
			if(getBWPEngineMode() == EDITOR_PPT)
			{
				BrINT nPageNum = getCmdEngine()->getCurPageNum();
				pPage = getEditingPage(nPageNum);
			}
			else
			{
				CFrame *pBasicFrame = getFirstLine()->getFrame();
				pPage = pBasicFrame->getPage();
			}
		}
	}

	if( !pPage )
		return BrFALSE;

	int w, h;
	pDC->getBitmap()->getSize(&w, &h);

	if( m_pHRuler )
	{
		m_pHRuler->setRulerbarBitmapSize(w,h);

		if(nRet)//caret live
		{
 			pDC->fillSolidRect( 0, 0,w,h,RGB_LTGRAY);
 			pDC->fillSolidRect( nPageLeftLogical,0,nPageRightLogical,h,RULERBAR_BG_COLOR);
 			pDC->fillSolidRect(getCmdEngine()->page2LogicalX( pPage, nTextLeftPos ),0,
 				getCmdEngine()->page2LogicalX( pPage, nTextRightPos ), h,RULERBAR_CENTER_COLOR);
 			pDC->fillSolidRect(nPageLeftLogical,h - 8 + 0.5,
 				nPageRightLogical,h - 0.5,RULERBAR_UNIT_LINEGAP_COLOR);

			m_pHRuler->setRulerbarPgInfo(nPageLeftLogical , nTextLeftPos,  nTextRightPos, nPageRightPos, nPageRightLogical );
			m_pHRuler->drawRulerbar( pDC);

			return BrTRUE;
		}
		return BrFALSE;
	}
	return BrFALSE;
}

BrBOOL BoraDoc::OnDrawRulerbarVertical(Painter *pPainter,  BrDC *pDC)
{
	int nPageTopLogical , nTextTopPos,  nTextBottomPos, nPageBottomPos, nPageBottomLogical;

	BrINT nRet = getRulerbarInfoVertical(&nPageTopLogical , &nTextTopPos,  &nTextBottomPos, &nPageBottomPos, &nPageBottomLogical);

	if( !nRet)
		return BrFALSE;

	if(!m_pVRuler)
		m_pVRuler = BrNEW CRulerBar;

	CPage *pPage = BrNULL;
	CCaret* pCaret = theBWordDoc->getCaret();

	if( pCaret && ( pCaret->isCaretNormal() || pCaret->isCaretMarking() ) )
	{
		CFrame* pFrame = pCaret->getLineFrame();

		if( pFrame )
			pPage = pFrame->getPage();
	}
	else
	{
		CFrameSet* pFrameSet = getCmdEngine()->getFrameSet();
		if(pFrameSet->getTotalElements() != 0)
		{
			CFrame *pFrame = pFrameSet->getFirst()->getFrame();
			pPage = pFrame->getPage();
		}
		else
		{
			if(getBWPEngineMode() == EDITOR_PPT)
			{
				BrINT nPageNum = getCmdEngine()->getCurPageNum();
				pPage = getEditingPage(nPageNum);
			}
			else
			{
				CFrame *pBasicFrame = getFirstLine()->getFrame();
				pPage = pBasicFrame->getPage();
			}
		}
	}

	if( !pPage )
		return BrFALSE;

	int w, h;
	pDC->getBitmap()->getSize(&w, &h);

	if( m_pVRuler )
	{
		m_pVRuler->setRulerbarBitmapSize(w,h);

		if(nRet)//caret live
		{
			pDC->fillSolidRect( 0, 0,w,h,RGB_LTGRAY);
			pDC->fillSolidRect( 0, nPageTopLogical, w,nPageBottomLogical,RULERBAR_BG_COLOR);
			pDC->fillSolidRect(0, getCmdEngine()->page2LogicalY( pPage, nTextTopPos ),
				w,getCmdEngine()->page2LogicalY( pPage, nTextBottomPos ), RULERBAR_CENTER_COLOR);
			pDC->fillSolidRect(w - 8 + 0.5,nPageTopLogical,
				w- 0.5, nPageBottomLogical,RULERBAR_UNIT_LINEGAP_COLOR);

			m_pVRuler->setRulerbarPgInfoVertical(nPageTopLogical , nTextTopPos,  nTextBottomPos, nPageBottomPos, nPageBottomLogical );
			m_pVRuler->drawRulerbarVertical( pDC);

			return BrTRUE;
		}
		return BrFALSE;
	}
	return BrFALSE;
}
#endif//USE_RULERBAR

BrBOOL BoraDoc::IsDrawingPenMode()
{
	if(m_CmdEngine->getMode() == PENDRAW)
	{
		if((m_nPenMode >= BR_INK_MODE && m_nPenMode <= BR_ERASE_MODE) || m_nPenMode == BR_CALLIGRAPHY_MODE)
			return BrTRUE;
	}
	else if(m_CmdEngine->getMode() == FREEDRAW)
	{
		if(m_nPenMode == BR_INK_MODE)
			return BrTRUE;
	}
	return BrFALSE;
}

BrBOOL BoraDoc::IsErasePenMode()
{
	if(m_CmdEngine->getMode() == PENDRAW)
	{
		return BrFALSE;
	}
	else if(m_CmdEngine->getMode() == FREEDRAW)
	{
		if(m_nPenMode == BR_ERASE_MODE)
			return BrTRUE;
	}
	return BrFALSE;
}

// memo_id == -1 �̸� ������ ó�� �޸� ���̵� ���� �մϴ�.
BrINT32 BoraDoc::getMemoLocation(int memo_id, CLocation& sloc, CLocation& eloc)
{
	return m_MemoEventManager->getMemoLocation(memo_id, sloc, eloc);
}

BrINT BoraDoc::getDrawingMemoReference() { return m_MemoEventManager->getDrawingMemoReference(); };
//loc��ġ������ �޸��� ������ �����Ͽ� m_nDrawingMemoReference�� currentMemo���� ������ ����.
void BoraDoc::setDrawingMemoReference(BrINT nNewReference)
{
	m_MemoEventManager->setDrawingMemoReference(nNewReference);
}

BrBOOL	BoraDoc::isShowMemo()
{
	return m_MemoEventManager->isShowMemo();
}
void	BoraDoc::setShowMemo(BrBOOL b)
{
	m_MemoEventManager->setShowMemo(b);
}

BrINT	BoraDoc::getScreenMemoMode()
{
	return m_MemoEventManager->getScreenMemoMode();
}
void	BoraDoc::setScreenMemoMode(BrINT nMemoMode)
{
	m_MemoEventManager->setScreenMemoMode(nMemoMode);
}

int BoraDoc::getScreenCurrentID()
{
	return m_MemoEventManager->getScreenCurrentID();
}
void BoraDoc::setScreenCurrentID(int nID)
{
	m_MemoEventManager->setScreenCurrentID(nID);
}

BrBOOL BoraDoc::isInCurrentMemo()
{
	return m_MemoEventManager->isInCurrentMemo();
};

void BoraDoc::setInCurrentMemo(BrBOOL bIn)
{
	m_MemoEventManager->setInCurrentMemo(bIn);
};

int		BoraDoc::getDisableCurMemoID() { return m_MemoEventManager->getDisableCurMemoID(); }
void	BoraDoc::setDisableCurMemoID(int nID) { m_MemoEventManager->setDisableCurMemoID(nID); }
int		BoraDoc::getInsertMemoPageNum() { return m_MemoEventManager->getInsertMemoPageNum(); }
void	BoraDoc::setInsertMemoPageNum(int nPageNum) { m_MemoEventManager->setInsertMemoPageNum(nPageNum); }
void	BoraDoc::setMemoeFrameXPosition(CFrame* frame) { m_MemoEventManager->setMemoeFrameXPosition(frame); }

CFrameList* BoraDoc::getAFrameList(CPage *pPage, BrBOOL bCheckHeaderFooter /* = BrFALSE*/)
{
	if (getBWPEngineMode() == EDITOR_PPT)
	{
		if (!pPage) {
			BRTHREAD_ASSERT(0);
			//#pragma message("�̺κ��� �ɸ��� Eddy or Woody���� ���� �ּ���~")
			return BrNULL;
		}
		return pPage->getPageAFrameList();
	}

	if (isEditMasterPage())
		return m_MstAFrameList;

	if(bCheckHeaderFooter)
	{
		CHeaderFooterEngine* pHeaderFooterEngine = theBWordDoc->getHeaderFooterEngine();
		if(EDITOR_WORD == theBWordDoc->getBWPEngineMode() && pHeaderFooterEngine && pHeaderFooterEngine->is_edit_mode())
			return theBWordDoc->getAFrameList4HeaderFooter();
	}

	return m_AFrameList;
}

CFrameList* BoraDoc::getWordMemoFrameList() {
	return m_WordMemoFrameList;
}

CFrameList* BoraDoc::getRevisionFrameList()	{
	return m_RevisionFrameList;
}

CFrameList* BoraDoc::getInkFrameList() {
	return m_InkFrameList;
}

CFrameList* BoraDoc::getAFrameList4HeaderFooter() {
	return m_AFrameList4HeaderFooter;
}

CFrameList* BoraDoc::getBgFrameList() {
	return m_BgFrameList;
}

CFrameList* BoraDoc::getBulletImageList() {
	return m_BulletImageFrameList;
}

CFrameList* BoraDoc::getMstAFrameList()
{
	if (getBWPEngineMode() == EDITOR_PPT)
	{
		//PO6.0���ʹ� MasAFrameList�� ����.
		//Page�� AFrameList�� ������ ��
		BRTHREAD_ASSERT(0);
		return BrNULL;
	}

	return m_MstAFrameList;
}

//pAFrameList: pFrame parent frame list
CFrame*	BoraDoc::getAnchorFrame(BrWORD id, CFrameList **pAFrameList)
{
	CFrame *pFound = BrNULL;
	CFrameList *pFrameList = BrNULL;

	if (getBWPEngineMode() == EDITOR_PPT)
	{
		CPage *pCurPage = getCmdEngine() ? getCmdEngine()->getCurrentPage() : BrNULL;
		if(pCurPage)
		{
#ifdef SUPPORT_NOTEMASTER_EDIT
			if(m_nDocType == BORA_DOCTYPE_PPTX && pCurPage->getPageType() == SLIDE_PAGE && getNoteDrawMode(pCurPage))
			{
				pCurPage = pCurPage->getNoteSlidePage();
				if(!pCurPage)
					return BrNULL;
			}
#endif
			pFrameList = getAFrameList(pCurPage);
			if(pFrameList)
				pFound = pFrameList->getFrame(id);

			if(!pFound)
			{	//��� ������ �˻�
				pFrameList = pCurPage->getTFrameList();
				if(pFrameList)
					pFound = pFrameList->getFrame(id);
			}
		}

		if(!pFound)
		{
			CPage *pPage = BrNULL;
			for (int i = 1 ; i <= getPageArray()->size() ; i++)
			{
				pPage = getPageArray()->getPage(i);
				if (pPage)
				{
					pFrameList = getAFrameList(pPage);
					if(!pFrameList)
						break;
					else
					{
						pFound = pFrameList->getFrame(id);
						if (pFound)
							break;
					}
				}

				if(pPage)
				{
					//��� ������ �˻�
					pFrameList = pPage->getTFrameList();
					if(!pFrameList)
						break;
					else
					{
						pFound = pFrameList->getFrame(id);
						if (pFound)
							break;
					}
				}
			}
		}

		//������ ������ Ž��
		if(!pFound)
		{
			CPage *pPage = BrNULL;
			BrINT nMasterCnt = m_MasterLayoutArray.size();
			CPageArray *pPageArray = BrNULL;
			BrINT nPageArrCnt = 0;
			for(int i = 0; i < nMasterCnt && !pFound; i++)
			{
				pPageArray = m_MasterLayoutArray.at(i);
				if(pPageArray)
				{
					nPageArrCnt = pPageArray->size();
					for(int j = 1; j <= nPageArrCnt && !pFound; j++)
					{
						pPage = pPageArray->getPage(j);
						if (pPage) {
							pFrameList = getAFrameList(pPage);
							if(!pFrameList)
								break;
							else
							{
								pFound = pFrameList->getFrame(id);
								if (pFound)
									break;
							}

							if(pPage)
							{
								//��� ������ �˻�
								pFrameList = pPage->getTFrameList();
								if(!pFrameList)
									break;
								else
								{
									pFound = pFrameList->getFrame(id);
									if (pFound)
										break;
								}
							}
						}
					}
				}
			}
		}
#ifdef SUPPORT_NOTEMASTER_EDIT
		if(!pFound)
		{
			if(pCurPage && pCurPage->getPageType() == NOTEMASTER_PAGE)
			{
				CPPTNoteMaster *pNM = theBWordDoc->getPPTNoteMaster();
				CPage* pPage = pCurPage->getNoteSlidePage();
				if(!pPage)
					pPage = pNM->GetNotePage(pCurPage->getPageNum());
				if(pPage)
				{
					pFrameList = pPage->getAnchorFrameList();
					if(pFrameList)
						pFound = pFrameList->getFrame(id);

					if(!pFound)
					{	//��� ������ �˻�
						pFrameList = pPage->getTFrameList();
						if(pFrameList)
							pFound = pFrameList->getFrame(id);
					}
				}
			}
		}
#endif//#ifdef SUPPORT_NOTEMASTER_EDIT
	}
	else
	{
		pFrameList  = getAFrameList();
		if(pFrameList)
		{
			pFound = pFrameList->getFrame(id);
		}

		//for word header/footer anchor frame
		if(!pFound)
		{
			pFrameList = getAFrameList4HeaderFooter();
			pFound = pFrameList->getFrame(id);
		}

		//Ticket 26102, for hwp batang page
		if(!pFound && isFromHwp())
		{
			CPage *pPage = BrNULL;
			BrINT nTotalPageNum = m_BatangPageArray->getTotalPageNum();
			for(BrINT nPageNum = 1; nPageNum <= nTotalPageNum; nPageNum++)
			{
				pPage = m_BatangPageArray->getPage(nPageNum);
				if(pPage)
				{
					pFrameList = pPage->getPageAFrameList();
					if( !pFrameList )
						break;
					pFound = pFrameList->getFrame(id);
					if(pFound)
						break;
				}
			}
		}
	}

	if(pFound && pAFrameList)
		*pAFrameList = pFrameList;

	return pFound;
}

void BoraDoc::RemoveHeaderFrame(BrWORD id) //id == frame id
{
	if(!isFromHwp() || !m_pHeaderArray)
		return;

	for(BrINT i = 0; i < m_pHeaderArray->size(); i++)
	{
		CFrame *pFrame = m_pHeaderArray->at(i);
		if(pFrame && pFrame->getID() == id) {
			m_pHeaderArray->RemoveAtFast(i);
			BR_SAFE_DELETE(pFrame);
			i--;
		}
	}

	return;
}

void BoraDoc::RemoveFooterFrame(BrWORD id)	//id == frame id
{
	if(!isFromHwp() || !m_pFooterArray)
		return;

	for(BrINT i = 0; i < m_pFooterArray->size(); i++)
	{
		CFrame *pFrame = m_pFooterArray->at(i);
		if(pFrame && pFrame->getID() == id) {
			m_pFooterArray->RemoveAtFast(i);
			BR_SAFE_DELETE(pFrame);
			i--;
		}
	}

	return;
}

//for HWP header/footer
CFrame*	BoraDoc::getHeaderFrame(BrWORD id)	//id == frame id
{
	if(!isFromHwp() || !m_pHeaderArray)
		return BrNULL;

	for(BrINT i = 0; i < m_pHeaderArray->size(); i++)
	{
		CFrame *pFrame = m_pHeaderArray->at(i);
		if(pFrame && pFrame->getID() == id)
			return pFrame;
	}

	return BrNULL;
}
//for HWP header/footer
CFrame*	BoraDoc::getFooterFrame(BrWORD id)	//id == frame id
{
	if(!isFromHwp() || !m_pFooterArray)
		return BrNULL;

	for(BrINT i = 0; i < m_pFooterArray->size(); i++)
	{
		CFrame *pFrame = m_pFooterArray->at(i);
		if(pFrame && pFrame->getID() == id)
			return pFrame;
	}

	return BrNULL;
}
CBulletArray* BoraDoc::getBulletArray()   {
	return m_BulletArray;
}

int BoraDoc::setBulletImageFrame(CFrame *pFrame)
{
	int nSize = m_BulletImageFrameList->getTotalFrame();
	m_BulletImageFrameList->insertAtTail(pFrame);
	return (nSize+1);
}

CFrame*	BoraDoc::getBulletImageFrame(BrWORD wIndex)
{
	if( wIndex <= 0 || wIndex > m_BulletImageFrameList->getTotalFrame())
		return BrNULL;

	CFrame *pFrame = m_BulletImageFrameList->getFrameByIndex(wIndex-1);
	return pFrame;
}

#ifdef IMPORT_HWP
CPageCtrlArray* BoraDoc::getPageCtrlArray()
{
	if (!m_pPageCtrlArray)
		m_pPageCtrlArray = BrNEW CPageCtrlArray();
	return m_pPageCtrlArray;
}
#endif

#ifdef USE_HWP_CONTROL
//CClickhereArray* BoraDoc::getClickHereHandler()
//{
//	if (!m_pClickhereArray)
//	{
//		m_pClickhereArray = BrNEW CClickhereArray();
//
//		BrUSHORT wLocalFont[] = {0xB9D1, 0xc740, 0x20, 0xace0, 0xb515, 0x00}; 	//���� ����
//
//		PoTextAtt oTextAttr;
//		oTextAttr.setHanFSize(m_pClickhereArray->getCodeSize());
//		oTextAttr.setEngFSize(m_pClickhereArray->getCodeSize());
//		oTextAttr.setHanFontID((BrWORD)getFontArray()->getFontID(wLocalFont));
//
//		m_pClickhereArray->setBeginEndAttrID(theBWordDoc->getTextAttHandler()->insertTextAtt(oTextAttr));
//		m_pClickhereArray->setBeginEndTextWidth(CTextProc::getTextLinkWidth(this, &oTextAttr, m_pClickhereArray->getBeginCode()));
//	}
//	return m_pClickhereArray;
//}

clickhere::ClickHereHandler* BoraDoc::getClickHereHandler()
{
    if (!m_pClickHereHandler)
    {
        clickhere::ClickHereHandler* handler = BrNEW clickhere::ClickHereHandler(this);

        BrUSHORT wLocalFont[] = {0xB9D1, 0xc740, 0x20, 0xace0, 0xb515, 0x00}; 	//���� ����

        PoTextAtt oTextAttr;
        oTextAttr.setHanFSize(clickhere::ClickHereHandler::FIELD_WIDTH);
        oTextAttr.setEngFSize(clickhere::ClickHereHandler::FIELD_WIDTH);
        oTextAttr.setHanFontID((BrWORD)getFontArray()->getFontID(wLocalFont));

        BrINT clickhere_text_attr_id = theBWordDoc->getTextAttHandler()->insertTextAtt(oTextAttr);
        BrINT clickhere_open_close_text_width = CTextProc::getTextLinkWidth(this, &oTextAttr, clickhere::ClickHereHandler::OPEN_CODE);

        handler->UpdateClickHereAttrID(clickhere_text_attr_id);
        handler->UpdateClickHereTextWidth(clickhere_open_close_text_width);

        m_pClickHereHandler = handler;
    }
    return m_pClickHereHandler;
}
#endif // USE_HWP_CONTROL

void BoraDoc::setAuthor(BString &strAuthor, bool bSetSummary)
{
	m_strAuthor = strAuthor;
	if(bSetSummary && m_pSummaryData && m_pSummaryData->getAuthor() == BrNULL)
		m_pSummaryData->setAuthor(&strAuthor);
}

CPageArray*	BoraDoc::getCurrentScreenLayoutPageArr()
{
	BrINT nMasterIndex  = -1;
	BrINT nPageNum		= -1;

	CCmdEngine *pCmdEngine = getCmdEngine();
	getMasterIndexPageNum(&nMasterIndex, &nPageNum);

	if (nMasterIndex == -1 || nPageNum == -1)
		return BrNULL;

	CPageArray *pPageArray = m_MasterLayoutArray.at(nMasterIndex);

	if (!pPageArray)
		return BrNULL;

	return pPageArray;
}

CPage*	BoraDoc::getCurrentScreenLayoutPage()
{
	BrINT nMasterIndex  = -1;
	BrINT nPageNum		= -1;

	CCmdEngine *pCmdEngine = getCmdEngine();
	getMasterIndexPageNum(&nMasterIndex, &nPageNum);

	if (nMasterIndex == -1 || nPageNum == -1)
		return BrNULL;

	CPageArray *pPageArray = m_MasterLayoutArray.at(nMasterIndex);

	if (!pPageArray)
		return BrNULL;

	return pPageArray->getPage(nPageNum);
}

void BoraDoc::getMasterIndexPageNum(BrINT *pMasterIndex, BrINT *pPageNum)
{
	int nMasterPageCnt = m_MasterLayoutArray.size();
	int nPrevMasterTotalPage = 0;
	int nStartPage = m_CmdEngine->getCurPageNum();

	//int nStartPage = m_CmdEngine->getScrStartPage();

	for (int i = 0; i < nMasterPageCnt ;i++) {
		if (nStartPage <= (m_MasterLayoutArray.at(i)->size() + nPrevMasterTotalPage)) {
			*pMasterIndex = i;
			nStartPage -= nPrevMasterTotalPage;
			*pPageNum = nStartPage;
			break;
		}
		nPrevMasterTotalPage += m_MasterLayoutArray.at(i)->size();
	}

}

CPage* BoraDoc::getPageByPageNum(BrINT nPageNum, BrBOOL bNullPageRead)
{
	if(nPageNum<1)
		return BrNULL;

	BrINT nEditMasterType = getEditMasterType();
	if(isEditMasterPage())
	{
		int nMasterPageCnt = m_MasterLayoutArray.size();
		int nPrevMasterTotalPage = 0;
		for (int i = 0; i < nMasterPageCnt ;i++) {
			CPageArray *pMasterArraay = m_MasterLayoutArray.at(i);
			BrINT nSize = pMasterArraay->size();
			if(nPageNum <= (nSize + nPrevMasterTotalPage)) {
				if(bNullPageRead && !pMasterArraay->at(nPageNum - nPrevMasterTotalPage -1) )
				{
					readMasterLayoutPage(i);
				}
				return pMasterArraay->at(nPageNum - nPrevMasterTotalPage -1);
			}
			nPrevMasterTotalPage += nSize;
		}
	}

	BrBOOL bEditSlidePage = BrFALSE;
#ifndef SUPPORT_NOTEMASTER_EDIT
	if ( nEditMasterType == EDIT_MASTER_NONE)
#else
	if ((nEditMasterType == EDIT_MASTER_NONE) || (EDIT_MASTER_NOTE == nEditMasterType))
#endif
		bEditSlidePage = BrTRUE;

	CPageArray *pPageArray = getEditingPageArray();
	BrINT nPgSz = 0;
	if(pPageArray)
	{
		nPgSz = pPageArray->GetSize();
		if(nPgSz >= nPageNum)
		{
			if(bEditSlidePage && bNullPageRead && !pPageArray->at(nPageNum -1))
				HandsPointer_ReadSlide_PPT_BWP(getPainter(), nPageNum, nPageNum);
			CPage *pRetPage = pPageArray->at(nPageNum -1);
#ifdef SUPPORT_NOTEMASTER_EDIT
			if(pRetPage && getNoteDrawMode(pRetPage) && pRetPage->getPageType() == SLIDE_PAGE)
				pRetPage = pRetPage->getNoteSlidePage();
#endif
			return pRetPage;
		}
	}

	return BrNULL;
}

BrBOOL BoraDoc::IsUsedLayoutPage(CPage *pLayoutPage)
{
	if (pLayoutPage && pLayoutPage->getPageType() == LAYOUT_PAGE)
	{
#ifdef SEPERATE_MASTERID
		BrUINT nMasterID = pLayoutPage->getMasterID();
		BrUINT nLayoutID = pLayoutPage->getLayoutID();
#else //SEPERATE_MASTERID
		BrINT nMasterID = pLayoutPage->getMasterID();
#endif //SEPERATE_MASTERID

		for (BrINT i = 0; i < getPageArray()->size(); i++)
		{
			CPage *pSlidePage = getPageArray()->at(i);
			if (pSlidePage && pSlidePage->getPageType() == SLIDE_PAGE)
			{
#ifdef SEPERATE_MASTERID
				if (pSlidePage->getMasterID() == nMasterID && pSlidePage->getLayoutID() == nLayoutID)
#else //SEPERATE_MASTERID
				if (pSlidePage->getMasterID() == nMasterID)
#endif //SEPERATE_MASTERID
					return BrTRUE;
			}
		}
	}
	return BrFALSE;
}

BrBOOL BoraDoc::IsUsedLayoutPage(BrINT nMasterIndex, BrINT nLayoutPageNum)
{
	CPageArray *pMstPageArray = m_MasterLayoutArray.at(nMasterIndex);
	Painter *pPainter = gpPaint;
	if (pMstPageArray)
	{
		CPage *pLayoutPage = pMstPageArray->getPage(nLayoutPageNum);
		if (pLayoutPage && pLayoutPage->getPageType() == LAYOUT_PAGE)
		{
#ifdef SEPERATE_MASTERID
			BrUINT nMasterID = pLayoutPage->getMasterID();
			BrUINT nLayoutID = pLayoutPage->getLayoutID();
#else //SEPERATE_MASTERID
			BrINT nMasterID = pLayoutPage->getMasterID();
#endif //SEPERATE_MASTERID

			BrINT nSize = getPageArray()->size();
			for (BrINT i = 0; i < nSize; i++)
			{
				CPage *pSlidePage = getPageArray()->at(i);
				if(!pSlidePage)
				{
					getCmdEngine()->checkCacheData(pPainter);
					pPainter->m_nPageCaching = STOP_PAGE_CACHING;
					pSlidePage = HandsPointer_ReadSlide_PPT_BWP(pPainter, i+1, i+1, BrFALSE);
				}

				if (pSlidePage && pSlidePage->getPageType() == SLIDE_PAGE)
				{
#ifdef SEPERATE_MASTERID
					if (pSlidePage->getMasterID() == nMasterID && pSlidePage->getLayoutID() == nLayoutID)
#else //SEPERATE_MASTERID
					if (pSlidePage->getMasterID() == nMasterID)
#endif //SEPERATE_MASTERID
						return BrTRUE;
				}
			}
		}
	}
	return BrFALSE;
}

BrBYTE BoraDoc::setMasterPreserve(BrINT nMasterIndex, BrBOOL bPreserve)
{
	if (!isEditMasterPage())
		return BrFALSE;

	if (nMasterIndex == -1)
	{
		BrINT nPageNum		= -1;
		getMasterIndexPageNum(&nMasterIndex, &nPageNum);
	}

	CPageArray *pMstPageArray = m_MasterLayoutArray.at(nMasterIndex);
	if (pMstPageArray)
	{
#ifdef SEPERATE_MASTERID
		BrUINT nMasterID = pMstPageArray->at(0)->getMasterID();
#else //SEPERATE_MASTERID
		BrINT nMasterID = (pMstPageArray->at(0)->getMasterID() & 0x0000ffff);
#endif //SEPERATE_MASTERID

		if (pMstPageArray->isPPTMasterPreserve() && !bPreserve)
		{
			pMstPageArray->setPPTMasterPreserve(bPreserve);
			for (BrINT i = 0 ; i < getPageArray()->size() ; i++) {
				CPage *pSlidePage = getPageArray()->at(i);
				if (pSlidePage)
				{
					if (BR_EQUAL_MASTERID(pSlidePage->getMasterID(), nMasterID))
						return 1; //�ش� �����Ͱ� slidePage���� ��� �ϰ� ���� ��
				}
			}
			return 2; // �ش� �����ʹ� ��� �Ǵ� ���� ���� ������ ���̾�α� â ����
		}
		pMstPageArray->setPPTMasterPreserve(bPreserve);
	}

	return 1;

}

BrBOOL BoraDoc::duplicateMasterLayout()
{
	BrINT nMasterIndex  = -1;
	BrINT nPageNum		= -1;

	CCmdEngine *pCmdEngine = getCmdEngine();
	getMasterIndexPageNum(&nMasterIndex, &nPageNum);

	if (nMasterIndex == -1 || nPageNum == -1)
		return BrFALSE;

	CPage *pNewPage = BrNULL;
	CPageArray *pPageArray = m_MasterLayoutArray.at(nMasterIndex);

	if (!pPageArray)
		return BrFALSE;

	CPage *pPage =pPageArray->at(nPageNum-1);

	if (pPage) {
		pNewPage = pPage->BrCopy(BrNULL);

		if(pNewPage == BrNULL)
			return BrFALSE;

		pPageArray->insertNext(nPageNum, pNewPage);
	}

#ifdef BWP_UNDO
	CUndoEngine *pUndoEngine = getUndoEngine();
	if (pUndoEngine) {
		BrBOOL bPrevContinue = pUndoEngine->setContinueFlag(BrTRUE);
		POUndoRedo::SlideMasterPageCreate *pData = pUndoEngine->makeUndoCreatePage(getCmdEngine(), pNewPage);
		if (pData) {
			pData->m_MasterBaseData.m_nMasterIndex = nMasterIndex;
			pData->m_MasterBaseData.m_bMasterPageType = LAYOUT_PAGE;
			pData->m_MasterBaseData.m_nLayoutIndex = nPageNum+1;
			pUndoEngine->storeUndoData(ActionCreatePage, pData);
		}
		CKeyValue<BrINT, BArray<BrINT> > masterPageSet;
		stPair<BrINT, BArray<BrINT> > *pagePair = BrNEW stPair<BrINT, BArray<BrINT> >;
		pagePair->Key = nMasterIndex;
		pagePair->Value.Add(nPageNum+1);
		masterPageSet.insertPair(pagePair);
		updateSlidePageThumbnailCallback(&masterPageSet, BrNULL, Bora_ppt_masterfunc_laytout_duplicate);
		pUndoEngine->setContinueFlag(bPrevContinue);
	}
#endif
	arrangeMasterLayoutID();
	arrangeMasterPageNum();

	return BrFALSE;
}

BrBYTE BoraDoc::deleteLayoutPage(BrINT nMasterIndex, BrINT nLayoutPageNum)
{
	if (m_MasterLayoutArray.size() < 1)
		return 0;

	if (nMasterIndex == -1 || nLayoutPageNum == -1)
		return 0;

	if(IsUsedLayoutPage(nMasterIndex, nLayoutPageNum))
		return 0;

	CPageArray *pPageArray = m_MasterLayoutArray.at(nMasterIndex);

	if (!pPageArray)
		return 0;

	CPage *pLayoutPage =pPageArray->at(nLayoutPageNum-1);

	if(pLayoutPage == BrNULL) {
		readMasterLayoutPage(nMasterIndex);
		pLayoutPage = pPageArray->at(nLayoutPageNum-1);
	}

	if (pLayoutPage)
	{
		if (pLayoutPage->getPageType() == 0x01)
			return -1;	// MasterPage Delete �ٸ� �̺�Ʈ�� ����ؼ� ������ ��

		if (pPageArray->size() <= 1)
			return -2;	// MasterPage�� �������� ������ �ʴ´�.

		int nCurPageNum = getCmdEngine()->getCurrentPageNum(BrTRUE);
		if (nCurPageNum == getEditingTotalPage())
		{
			getCmdEngine()->setCurPageNum(nCurPageNum-1);
			getPainter()->doc.m_nCurPage = nCurPageNum-1;
		}

#ifdef SEPERATE_MASTERID
		BrUINT* pMaxLayoutID = pPageArray->getMaxLayoutID();
#else //SEPERATE_MASTERID
		BrINT* pMaxLayoutID = pPageArray->getMaxLayoutID();
#endif //SEPERATE_MASTERID

		(*pMaxLayoutID)--; //[�̻�ȣ] layout�� �����Ǿ����ϱ� max���� �����������

#ifdef BWP_UNDO
		CUndoEngine *pUndoEngine = getUndoEngine();
		BrBOOL bPrevContinue = pUndoEngine->setContinueFlag(BrTRUE);
		POUndoRedo::SlideMasterPageDelete *pData = pUndoEngine->makeUndoDeletePages(getCmdEngine(), nLayoutPageNum, nMasterIndex, nLayoutPageNum);
		if (pData)
		{
			pData->m_MasterBaseData.m_bMasterPageType = pLayoutPage->getPageType();
			pUndoEngine->storeUndoData(ActionDeletePages, pData);

			for(BrINT32 i = nMasterIndex; i < m_MasterLayoutArray.size(); i++)
			{
				CPageArray *pPageArray = m_MasterLayoutArray.at(i);
				pPageArray->getPage(1)->setModifiedMasterLayoutPage(BrTRUE);
			}
		}

		CKeyValue<BrINT, BArray<BrINT> > masterPageSet;
		stPair<BrINT, BArray<BrINT> > *pagePair = BrNEW stPair<BrINT, BArray<BrINT> >;
		pagePair->Key = nMasterIndex;
		pagePair->Value.Add(nLayoutPageNum);
		masterPageSet.insertPair(pagePair);
		updateSlidePageThumbnailCallback(&masterPageSet, BrNULL, Bora_ppt_masterfunc_laytout_delete, nCurPageNum);
		pUndoEngine->setContinueFlag(bPrevContinue);
#else
		pPageArray->Delete(nPageNum, 1, BrTRUE);
#endif //BWP_UNDO
		arrangeMasterLayoutID();
		arrangeMasterPageNum();

		return 1;
	}
	return 0;
}

BrBYTE BoraDoc::deleteLayoutPage()
{
	BrINT nMasterIndex  = -1;
	BrINT nPageNum		= -1;

	CCmdEngine *pCmdEngine = getCmdEngine();
	getMasterIndexPageNum(&nMasterIndex, &nPageNum);

	return deleteLayoutPage(nMasterIndex, nPageNum);
}

BrBOOL BoraDoc::modifyMasterTitle(BrCHAR *szTitle)
{
	BrINT nMasterIndex  = -1;
	BrINT nPageNum		= -1;
	getMasterIndexPageNum(&nMasterIndex, &nPageNum);

	if (nMasterIndex == -1 || nPageNum == -1)
		return BrFALSE;

	CPageArray *pPageArray = m_MasterLayoutArray.at(nMasterIndex);

	if (!pPageArray)
		return BrFALSE;

	CPage *pPage =pPageArray->at(nPageNum-1);
	if (pPage)
	{
#ifdef BWP_UNDO
		CUndoEngine *pUndoEngine = getUndoEngine();
		if (pUndoEngine)
		{
			POUndoRedo::SlideMasterRename *pData = pUndoEngine->makeUndoMasterPageRename(getCmdEngine(), nMasterIndex, nPageNum,  pPage->getMasterName());
			if(pData)
			{
				if (pPage->getPageType() == MASTER_PAGE)
				{
					CThemeAtt *pCurrentTheme = m_pTheme->getUserTheme(pPage->getRefThemeID());
					if (pCurrentTheme){
						pData->setThemeName(pCurrentTheme->getName());
					}
				}
				pUndoEngine->storeUndoData(ActionMasterRename, pData);
			}
		}
#endif
		if (pPage->getPageType() == MASTER_PAGE)
		{
			CThemeAtt *pCurrentTheme = m_pTheme->getUserTheme(pPage->getRefThemeID());
			if (pCurrentTheme){
				pCurrentTheme->setName(szTitle);
			}
		}

		BString strTitle;
		BrWCHAR  *wStr = BrNULL;
		UINT size = (BrStrLen(szTitle)+1) *BrSizeOf(BrWCHAR);
		wStr = (BrWCHAR*)BrMalloc(size);

		if ( wStr != BrNULL)
		{
			memset( wStr, 0 ,  size  );
			size = toUnicodeSlimEDITOR(szTitle, BrStrLen(szTitle), wStr);

			for (int j = 0; j < (int)size ; j++)
				strTitle += BChar(wStr[j]);

			BrFree(wStr);
			pPage->setMasterName(strTitle);
		}
		pPage->setModifiedMasterLayoutPage(BrTRUE);
	}

	return BrTRUE;
}

BrBOOL	BoraDoc::setMasterHideBackGround(CPage *pPage, BrINT nMasterIndex, BrINT nPageNum, BrBOOL b)
{
	if(pPage == BrNULL)
		return BrFALSE;

#ifdef BWP_UNDO
	CUndoEngine *pUndoEngine = getUndoEngine();
	if (pUndoEngine)
	{
		POUndoRedo::SlideMasterBGHide *pData = pUndoEngine->makeUndoMasterBGHide(getCmdEngine(), nMasterIndex, nPageNum,
			pPage->getPageType(), pPage->isMasterHideBackGround());
		if(pData)
		{
			pData->m_bPageType = pPage->getPageType();
			pData->m_nPageNum = pPage->getPageNum();
			pUndoEngine->storeUndoData(ActionMasterBGHide, pData);
		}
	}
#endif	// BWP_UNDO

	if (pPage)
	{
		pPage->setMasterHideBackGround(b);
		pPage->setObjectMasterFlag(!b);
	}

	pPage->setModifiedSlideLayout(BrTRUE);

	return BrTRUE;
}

BrBOOL	BoraDoc::setMasterHideBackGround(BrBOOL b, BrBOOL bPageBg)
{
	CPage* pPage = BrNULL;
	BrINT nMasterIndex  = -1;
	BrINT nPageNum		= -1;
	CCmdEngine *pCmdEngine = getCmdEngine();
	if(!pCmdEngine)
			return BrFALSE;

	BrBOOL bTest = BrFALSE;
	if(bPageBg)
	{
		CPage* pCurPage = pCmdEngine->getCurrentPage();

		if(!pCurPage)
			return BrFALSE;

		pPage = pCmdEngine->getCurrentPage();
		//pPage = getLayoutPage(pCurPage->getMasterID(), (pCurPage->getMasterID() & 0xffff0000));
	}
	else
	{
		if (isEditMasterPage())
		{
			getMasterIndexPageNum(&nMasterIndex, &nPageNum);

			if (nMasterIndex == -1 || nPageNum == -1)
				return BrFALSE;

			CPageArray *pPageArray = m_MasterLayoutArray.at(nMasterIndex);

			if (!pPageArray)
				return BrFALSE;
			pPage = pPageArray->getPage(nPageNum);
		}else
		{
			int nEditMasterType = getEditMasterType();
			if (nEditMasterType == EDIT_MASTER_HANDOUT || nEditMasterType == EDIT_MASTER_NOTE)
				return BrFALSE;

			BrBOOL bExecuteByCommand = BrFALSE;
#ifdef USE_COLLABORATION
			CollaborationProvider *pProvider = g_pCollaborationProvider;
			if(pProvider && pProvider->getFlag(eBR_CLB_PROVIDER_FLAG_EXECUTE_BY_COMMAND))
				bExecuteByCommand = BrTRUE;
#endif //#ifdef USE_COLLABORATION
			BrPPTSlidePageListInfo stPageListInfo = {0,};

			BrBOOL bRet = BrTRUE;
			// ���� ������ ���� ������ ������ �������� �ʽ��ϴ�.
			if(bExecuteByCommand)
				stPageListInfo.nPageCnt = 1;
			else
				stPageListInfo.nPageCnt = BGetPageListCount();

			if(stPageListInfo.nPageCnt > 0)
			{
				stPageListInfo.pPageList = (BrINT*)BrMalloc(BrSizeOf(BrINT) * stPageListInfo.nPageCnt);
				memset(stPageListInfo.pPageList , 0, BrSizeOf(BrINT)*stPageListInfo.nPageCnt);

				BGetPageList(stPageListInfo.nPageCnt,stPageListInfo.pPageList);

#ifdef WINDOWS_8
				BArray<BrINT32> pageNumArray;
				pageNumArray.RemoveAll();
#endif
#ifdef BWP_UNDO
				CUndoEngine *pUndoEngine = getUndoEngine();
				BrBOOL bContinue = BrFALSE;
				if (pUndoEngine)
					bContinue = pUndoEngine->setContinueFlag(BrTRUE);
#endif
				for(int i = 0; i < stPageListInfo.nPageCnt; i++)
				{
					BrINT32 nPageNum = stPageListInfo.pPageList[i];
					CPage *pEditPage = theBWordDoc->getPageByPageNum(nPageNum);
					BrBOOL nResult = setMasterHideBackGround(pEditPage, -1, nPageNum, b);
					if(!nResult)
						bRet = nResult;
#ifndef WINDOWS_8
				}
#else
					pageNumArray.Add(nPageNum);
				}
				// UI�� ������ ���ֱ� ���ؼ� �߰�
				//stPageListInfo.nAction = Bora_ppt_slidePage_redraw_list_info;
				SendBaseResultCallback(0, Bora_ppt_slidePage_redraw_list_info, 0, g_pUIPROCESS_CBFUNC, &stPageListInfo, true);
				RedrawSlidePageCallBackNotify(&stPageListInfo);
#endif
#ifdef BWP_UNDO
				if (pUndoEngine)
					pUndoEngine->setContinueFlag(bContinue);
#endif
				return bRet;
			}
		}
	}

	if(!pPage)
		return BrFALSE;

	setMasterHideBackGround(pPage, nMasterIndex, nPageNum, b);
	return BrTRUE;
}

BrINT	BoraDoc::getMasterHideBackGround()
{

	CPage *pPage = BrNULL;
	BrINT nMasterIndex  = -1;
	BrINT nPageNum		= -1;
	if (isEditMasterPage()) {
		getMasterIndexPageNum(&nMasterIndex, &nPageNum);

		if (nMasterIndex == -1 || nPageNum == -1)
			return -1;

		CPageArray *pPageArray = m_MasterLayoutArray.at(nMasterIndex);

		if (!pPageArray)
			return -1;

		pPage = pPageArray->getPage(nPageNum);
	}else {
		pPage = getCmdEngine()->getCurrentPage();
	}

	if (pPage)
		return pPage->isMasterHideBackGround();

	return -1;
}

BrINT	BoraDoc::getLayoutElement()
{
	if (!isEditMasterPage())
		return 0;

	BrINT nMasterIndex  = -1;
	BrINT nPageNum		= -1;
	getMasterIndexPageNum(&nMasterIndex, &nPageNum);


	if (nMasterIndex == -1 || nPageNum == -1)
		return BrFALSE;

	CPageArray *pPageArray = m_MasterLayoutArray.at(nMasterIndex);

	if (!pPageArray)
		return BrFALSE;

	CPage *pPage = BrNULL;
	pPage = pPageArray->getPage(nPageNum);

	if (!pPage)
		return 0;

	if (pPage->getPageType() != LAYOUT_PAGE)
		return 0;
	BrINT nRet = 0x00;

	BrINT nHolderType = 0;
	BrBOOL 	bPlaceHolderType_Title = BrFALSE;
	BrBOOL	bPlaceHolderType_Footers = BrFALSE;
	CFrameList *pMasterFrameList = pPage->getPageAFrameList();

	if (pMasterFrameList)
	{
		CFrame *pFrame = pMasterFrameList->getFirst();
		while(pFrame)
		{
			if (pFrame->getPage() == pPage)
			{
				if (pFrame->getPlaceHolderType() == PLACEHOLDER_TYPE_DATE ||
				    pFrame->getPlaceHolderType()== PLACEHOLDER_TYPE_FOOTER ||
				    pFrame->getPlaceHolderType() == PLACEHOLDER_TYPE_SLIDE_NUMBER)
				     bPlaceHolderType_Footers = BrTRUE;
				else if (pFrame->getPlaceHolderType() == PLACEHOLDER_TYPE_TITLE ||
						 pFrame->getPlaceHolderType()== PLACEHOLDER_TYPE_CENTER_TITLE)
				     bPlaceHolderType_Title = BrTRUE;
			}
			pFrame = pMasterFrameList->getNext(pFrame);
		}
	}
	if (bPlaceHolderType_Footers)
		nRet |= BR_PPT_LAYOUT_ELEMENT_FOOTERS;

	if (bPlaceHolderType_Title)
		nRet |=  BR_PPT_LAYOUT_ELEMENT_TITLE;

	return nRet;

}


BrINT	BoraDoc::setLayoutElementCreate(BrINT nType)
{
	if (!isEditMasterPage())
		return -1;

	BrINT nMasterIndex  = -1;
	BrINT nPageNum		= -1;
	getMasterIndexPageNum(&nMasterIndex, &nPageNum);

	if (nMasterIndex == -1 || nPageNum == -1)
		return BrFALSE;

	CPageArray *pPageArray = m_MasterLayoutArray.at(nMasterIndex);

	if (!pPageArray)
		return BrFALSE;

	CPage *pPage = BrNULL;
	pPage = pPageArray->getPage(nPageNum);

	if (!pPage)
		return -1;
	if (pPage->getPageType() != LAYOUT_PAGE)
		return -1;

	BrINT nLayoutValue = getLayoutElement();
	if ((nLayoutValue &BR_PPT_LAYOUT_ELEMENT_FOOTERS) == BR_PPT_LAYOUT_ELEMENT_FOOTERS && nType == BR_PPT_MASTER_FUNC_LAYOUT_FOOTER)
		return -3;

	if ((nLayoutValue &BR_PPT_LAYOUT_ELEMENT_TITLE) == BR_PPT_LAYOUT_ELEMENT_TITLE && nType == BR_PPT_MASTER_FUNC_LAYOUT_TITLE)
		return -2;

	CFrame *pFirstFrame = BrNULL;
	CFrameList *pFrameList = getAFrameList(pPage);

#ifdef BWP_UNDO
	CUndoEngine *pUndoEngine = theBWordDoc->getUndoEngine();
	pUndoEngine->setContinueFlag(BrTRUE);
#endif
	BArray<CFrame*>		m_aryFrame;
	if (nType ==BR_PPT_MASTER_FUNC_LAYOUT_FOOTER)
	{
		pFirstFrame = CTextProc::createTextPlaceHolderFrame(this, pPage, PLACEHOLDER_SLIDE_NUMBER);
		pPage->setFooterObjectArrangeToMaster(pPage->getPageArray(), pFirstFrame);
		pFrameList->insertAtTail(pFirstFrame);
		m_aryFrame.Add(pFirstFrame);

		pFirstFrame = CTextProc::createTextPlaceHolderFrame(this, pPage, PLACEHOLDER_DATE);
		pPage->setFooterObjectArrangeToMaster(pPage->getPageArray(), pFirstFrame);
		pFrameList->insertAtTail(pFirstFrame);
		m_aryFrame.Add(pFirstFrame);

		pFirstFrame = CTextProc::createTextPlaceHolderFrame(this, pPage, PLACEHOLDER_FOOTER);
		pPage->setFooterObjectArrangeToMaster(pPage->getPageArray(), pFirstFrame);
		pFrameList->insertAtTail(pFirstFrame);
		m_aryFrame.Add(pFirstFrame);

	} else if (nType == BR_PPT_MASTER_FUNC_LAYOUT_TITLE) {
  		pFirstFrame = CTextProc::createTextPlaceHolderFrame(this, pPage, PLACEHOLDER_TITLE);
		pPage->setFooterObjectArrangeToMaster(pPage->getPageArray(), pFirstFrame);
		pFrameList->insertAtTail(pFirstFrame);
		m_aryFrame.Add(pFirstFrame);
 	}

	for (int i = 0 ; i < m_aryFrame.size() ; i++)
	{
		CFrame *pFrame = m_aryFrame.at(i);
#ifdef BWP_UNDO
	    	// undo data
	        if (!g_pAppStatic->bProtectUndo)
	        {
	            CUndoEngine    *pUndoEngine = getUndoEngine();
			    POUndoRedo::MakeFrame *pUndoData = pUndoEngine->makeUndoCreateFrame(getCmdEngine(), pFrame, BrTRUE);

			    if (pUndoData)
				    pUndoEngine->storeUndoData(ActionCreateFrame, pUndoData);
	        }
#endif
	}
	pPage->setModifiedSlideLayout(BrTRUE);
#ifdef BWP_UNDO
	pUndoEngine->setContinueFlag(BrFALSE);
#endif
	m_aryFrame.RemoveAll();
	return 1;
}

BrINT	BoraDoc::setLayoutElementDlelete(BrINT nType)
{
	if (!isEditMasterPage())
		return -1;

	BrINT nMasterIndex  = -1;
	BrINT nPageNum		= -1;
	getMasterIndexPageNum(&nMasterIndex, &nPageNum);


	if (nMasterIndex == -1 || nPageNum == -1)
		return BrFALSE;

	CPageArray *pPageArray = m_MasterLayoutArray.at(nMasterIndex);

	if (!pPageArray)
		return BrFALSE;

	CPage *pPage = BrNULL;
	pPage = pPageArray->getPage(nPageNum);

	if (!pPage)
		return -1;

	if (pPage->getPageType() != LAYOUT_PAGE)
		return -1;
#ifdef BWP_UNDO
	CUndoEngine *pUndoEngine = theBWordDoc->getUndoEngine();
	pUndoEngine->setContinueFlag(BrTRUE);
#endif

	BrINT nHolderType = 0;
	BArray<CFrame*>		m_aryFrame;
	CFrameList *pMasterFrameList = pPage->getPageAFrameList();
	if (pMasterFrameList) {
		CFrame *pFrame = pMasterFrameList->getFirst();
		while(pFrame)
		{
			if (nType == BR_PPT_MASTER_FUNC_LAYOUT_FOOTER && pFrame->getPage() == pPage)
			{
				if (pFrame->getPlaceHolderType() == PLACEHOLDER_TYPE_DATE)
					m_aryFrame.Add(pFrame);
				else if (pFrame->getPlaceHolderType()== PLACEHOLDER_TYPE_FOOTER)
					m_aryFrame.Add(pFrame);
				else if (pFrame->getPlaceHolderType() == PLACEHOLDER_TYPE_SLIDE_NUMBER)
					m_aryFrame.Add(pFrame);
			}
			else if (nType == BR_PPT_MASTER_FUNC_LAYOUT_TITLE && pFrame->getPage() == pPage)
			{
				if (pFrame->getPlaceHolderType() == PLACEHOLDER_TYPE_TITLE ||
					pFrame->getPlaceHolderType() == PLACEHOLDER_TYPE_CENTER_TITLE)
					m_aryFrame.Add(pFrame);
			}

			pFrame = pMasterFrameList->getNext(pFrame);
		}
	}

	for (int i = 0 ; i < m_aryFrame.size() ; i++)
	{
		CFrame *pFrame = m_aryFrame.at(i);
#ifdef BWP_UNDO
		if(!g_pAppStatic->bProtectUndo)
		{
			POUndoRedo::ChangeFrameAttr *pData = pUndoEngine->makeUndoChangeFrameAttr(getCmdEngine(), pFrame);
			if(pData)
				pUndoEngine->storeUndoData(ActionChangeFrameAttr, pData);
		}

		CFrameSet frameSet;
		frameSet.insertAtTail(pFrame);
		POUndoRedo::ClearFrame *pData = pUndoEngine->makeUndoClearFrame(&frameSet);
		if(pData!=NULL) {
			//pData->m_pAFrameList = pAFrameList;
			//pData->m_pBookMarkArray  = pBookMarkArray;
			pUndoEngine->storeUndoData(ActionClearFrame, pData);
		}else
			pMasterFrameList->remove(pFrame);
#endif
	}
#ifdef BWP_UNDO
	pUndoEngine->setContinueFlag(BrFALSE);
#endif
	m_aryFrame.RemoveAll();
	pPage->setModifiedSlideLayout(BrTRUE);
	return BrTRUE;
}

BrBOOL	BoraDoc::setMasterElement(BrINT nElement)
{
	BrINT nMasterIndex  = -1;
	BrINT nPageNum		= -1;
	getMasterIndexPageNum(&nMasterIndex, &nPageNum);

	if (nMasterIndex == -1 || nPageNum == -1)
		return BrFALSE;

	CPageArray *pPageArray = m_MasterLayoutArray.at(nMasterIndex);

	if (!pPageArray)
		return BrFALSE;

#ifdef BWP_UNDO
	CUndoEngine *pUndoEngine = theBWordDoc->getUndoEngine();
	pUndoEngine->setContinueFlag(BrTRUE);
#endif

	if ((BR_PPT_MASTER_ELEMENT_TILTE & nElement))
		pPageArray->setPPTMasterTitle(BrTRUE);
	else
		pPageArray->setPPTMasterTitle(BrFALSE);

	if ((BR_PPT_MASTER_ELEMENT_TEXT & nElement))
		pPageArray->setPPTMasterText(BrTRUE);
	else
		pPageArray->setPPTMasterText(BrFALSE);
	BrINT nMstIdx = 0;
	CSlideCmdManager cSlideCmdMgr;
	CPage *pCurPg = m_CmdEngine->getCurrentPage();
	if(pCurPg)
	{
		CPage *pMstPg = cSlideCmdMgr.getCurPageMasterInfo(pCurPg,nMstIdx);
		if(pMstPg)
		{	//ref. UI �� none �Ѱ���, default ������ ������ �߰��ؾ��ϴ��� �����!
			if ((BR_PPT_MASTER_ELEMENT_DATE & nElement))
				pMstPg->SetPPTHeaderFooterInfo_Date(BrTRUE);//pPageArray->setPPTMasterDate(BrTRUE);
			else
				pMstPg->SetPPTHeaderFooterInfo_Date(BrFALSE);//pPageArray->setPPTMasterDate(BrFALSE);

			if ((BR_PPT_MASTER_ELEMENT_PAGENUM & nElement))
				pMstPg->SetPPTHeaderFooterInfo_SldNum(BrTRUE);//pPageArray->setPPTMasterPageNumber(BrTRUE);
			else
				pMstPg->SetPPTHeaderFooterInfo_SldNum(BrFALSE);//pPageArray->setPPTMasterPageNumber(BrFALSE);

			if ((BR_PPT_MASTER_ELEMENT_FOOTER & nElement))
				pMstPg->SetPPTHeaderFooterInfo_Footer(BrTRUE);//pPageArray->setPPTMasterFooter(BrTRUE);
			else
				pMstPg->SetPPTHeaderFooterInfo_Footer(BrFALSE);//pPageArray->setPPTMasterFooter(BrFALSE);
		}
	}

	BrTrace("%s[%d] getPPTMasterPageFlag() = %x", __FUNCTION__, __LINE__, pPageArray->getPPTMasterPageFlag());
	CFrame *pNewFrame = BrNULL;
	CFrameList *pMasterFrameList = BrNULL;
	pMasterFrameList = getAFrameList(pPageArray->getPage(nPageNum));

	CPage *pPage = pPageArray->getPage(1);
	BArray<CFrame*>		m_aryFrame;
	BrINT nExistFrameElement = 0x00; //���� �ϴ� Frame check
	if (pPage)
	{
		CPage *pMstPage = BrNULL;
		CFrame *pTempFrame = pMasterFrameList->getFirst();
		if(pTempFrame)
			pMstPage = pTempFrame->getPage();
		while(pTempFrame)
		{
			if (pMstPage->getPageType() == MASTER_PAGE)
			{
				if (pTempFrame->getPlaceHolderType() == PLACEHOLDER_TYPE_DATE)
				{
					if(!pMstPage->GetPPTHeaderFooterInfo_Date())
						m_aryFrame.Add(pTempFrame);

					nExistFrameElement |= BR_PPT_MASTER_ELEMENT_DATE;
				}
				else if (pTempFrame->getPlaceHolderType() == PLACEHOLDER_TYPE_FOOTER)
				{
					if(!pMstPage->GetPPTHeaderFooterInfo_Footer())
						m_aryFrame.Add(pTempFrame);

					nExistFrameElement |= BR_PPT_MASTER_ELEMENT_FOOTER;
				}
				else if (pTempFrame->getPlaceHolderType() == PLACEHOLDER_TYPE_SLIDE_NUMBER)
				{
					if(!pMstPage->GetPPTHeaderFooterInfo_SldNum())
						m_aryFrame.Add(pTempFrame);

					nExistFrameElement |= BR_PPT_MASTER_ELEMENT_PAGENUM;
				}
				else if (pTempFrame->getPlaceHolderType() == PLACEHOLDER_TYPE_TITLE)
				{
					if (!pPageArray->isPPTMasterTitle())
						m_aryFrame.Add(pTempFrame);

					nExistFrameElement |= BR_PPT_MASTER_ELEMENT_TILTE;
				}
				else if (pTempFrame->getPlaceHolderType() == PLACEHOLDER_TYPE_BODY)
				{
					if (!pPageArray->isPPTMasterText())
						m_aryFrame.Add(pTempFrame);

					nExistFrameElement |= BR_PPT_MASTER_ELEMENT_TEXT;
				}
			}

			if (pMasterFrameList->getLast() == pTempFrame)
				break;

			pTempFrame = pTempFrame->getNext();
		}

		for (int i = 0 ; i < m_aryFrame.size() ; i++)
		{
			CFrame *pFrame = m_aryFrame.at(i);
#ifdef BWP_UNDO
			if(!g_pAppStatic->bProtectUndo)
			{
				POUndoRedo::ChangeFrameAttr *pData = pUndoEngine->makeUndoChangeFrameAttr(getCmdEngine(), pFrame);
				if(pData)
					pUndoEngine->storeUndoData(ActionChangeFrameAttr, pData);
			}

			CFrameSet frameSet;
			frameSet.insertAtTail(pFrame);
			POUndoRedo::ClearFrame *pData = pUndoEngine->makeUndoClearFrame(&frameSet);
			if(pData!=NULL) {
				//pData->m_pAFrameList = pAFrameList;
				//pData->m_pBookMarkArray  = pBookMarkArray;
				pUndoEngine->storeUndoData(ActionClearFrame, pData);
			}else
				pMasterFrameList->remove(pFrame);
#endif
		}

		m_aryFrame.RemoveAll();

		if ((nExistFrameElement & BR_PPT_MASTER_ELEMENT_TEXT) ==0x00 && pPageArray->isPPTMasterText()) {
			pNewFrame = CTextProc::createTextPlaceHolderFrame(this, pPage, PLACEHOLDER_UNDER_TITLE);
			pMasterFrameList->insertAtTail(pNewFrame);
			m_aryFrame.Add(pNewFrame);
		}

		if ((nExistFrameElement & BR_PPT_MASTER_ELEMENT_TILTE) == 0x00 && pPageArray->isPPTMasterTitle()) {
			pNewFrame = CTextProc::createTextPlaceHolderFrame(this, pPage, PLACEHOLDER_TITLE);
			pMasterFrameList->insertAtTail(pNewFrame);
			m_aryFrame.Add(pNewFrame);
		}
		if ((nExistFrameElement & BR_PPT_MASTER_ELEMENT_PAGENUM) == 0x00 && pPage->GetPPTHeaderFooterInfo_SldNum())
		{
			pNewFrame = CTextProc::createTextPlaceHolderFrame(this, pPage, PLACEHOLDER_SLIDE_NUMBER);
			pMasterFrameList->insertAtTail(pNewFrame);
			m_aryFrame.Add(pNewFrame);
		}
		if ((nExistFrameElement & BR_PPT_MASTER_ELEMENT_FOOTER) == 0x00 && pPage->GetPPTHeaderFooterInfo_Footer())
		{
			pNewFrame = CTextProc::createTextPlaceHolderFrame(this, pPage, PLACEHOLDER_FOOTER);
			pMasterFrameList->insertAtTail(pNewFrame);
			m_aryFrame.Add(pNewFrame);
		}

		if ((nExistFrameElement & BR_PPT_MASTER_ELEMENT_DATE) == 0x00 && pPage->GetPPTHeaderFooterInfo_Date())
		{
			pNewFrame = CTextProc::createTextPlaceHolderFrame(this, pPage, PLACEHOLDER_DATE);
			pMasterFrameList->insertAtTail(pNewFrame);
			m_aryFrame.Add(pNewFrame);
		}

		for (int i = 0 ; i < m_aryFrame.size() ; i++)
		{
			CFrame *pFrame = m_aryFrame.at(i);
			POUndoRedo::MakeFrame *pUndoData = pUndoEngine->makeUndoCreateFrame(getCmdEngine(), pFrame, BrTRUE);
			if (pUndoData)
				pUndoEngine->storeUndoData(ActionCreateFrame, pUndoData);
		}
		pPage->setModifiedSlideLayout(BrTRUE);

	}

#ifdef BWP_UNDO
	pUndoEngine->setContinueFlag(BrFALSE);
#endif
	return BrTRUE;
}

BrBOOL BoraDoc::deleteMasterPage(BrINT nMasterIndex)
{
	BrINT nPageNum		= -1;

	CCmdEngine *pCmdEngine = getCmdEngine();

	if (!isEditMasterPage())
		return BrFALSE;

	BrINT nMastersCount = m_MasterLayoutArray.size();
	if ( nMastersCount <= 1)
		return BrFALSE;

	if (nMasterIndex <0 || nMasterIndex > (nMastersCount-1))
		return BrFALSE;

	readMasterLayoutPage(nMasterIndex);

	CPageArray *pDelMstPageArray = m_MasterLayoutArray.at(nMasterIndex);


	if (!pDelMstPageArray)
		return BrFALSE;

	BRUINT nMstArraySize = pDelMstPageArray->size();
	//POD-4187
	//for(int nLayoutPageNum=1; nLayoutPageNum<=nMstArraySize; nLayoutPageNum++)
	//{
	//	if(IsUsedLayoutPage(nMasterIndex, nLayoutPageNum))
	//		return 0;
	//}

#ifdef SEPERATE_MASTERID
	BrUINT nDeleteMasterID = pDelMstPageArray->at(0)->getMasterID();
#else //SEPERATE_MASTERID
	BrINT nDeleteMasterID = (pDelMstPageArray->at(0)->getMasterID() & 0x0000fffff);
#endif //SEPERATE_MASTERID

	BrINT nStandardMasterIdx = nMasterIndex+1;
	if (nMasterIndex == (nMastersCount-1)) // ������ Master ����
	{
		nStandardMasterIdx = nMasterIndex-1;
	}

	BrBOOL bChange = 0;
	for (BrINT i = 0 ; i < getPageArray()->size(); i++)
	{
		CPage *pSlidePage = getPageArray()->at(i);
		if (pSlidePage)
		{
			if (BR_EQUAL_MASTERID(pSlidePage->getMasterID(),nDeleteMasterID))
				bChange = BrTRUE;
		}
	}

	if (!bChange) {
#ifdef BWP_UNDO
		CUndoEngine *pUndoEngine = getUndoEngine();
		if (pUndoEngine)
		{
			BrBOOL bPrevContinue = pUndoEngine->setContinueFlag(BrTRUE);
			POUndoRedo::SlideMasterDelete *pUndoData =  pUndoEngine->makeUndoPPTMasterDelete(this, nMasterIndex, nDeleteMasterID);
			if (pUndoData)
			{
				pUndoData->m_pMasterPageArray = pDelMstPageArray;
				pUndoEngine->storeUndoData(ActionPPTMasterDelete, (CUndoCommand*)pUndoData);
			}

			//���� ����� �׺���̼� ����
			CKeyValue<BrINT, BArray<BrINT> > masterPageSet;
			stPair<BrINT, BArray<BrINT> > *pagePair = BrNEW stPair<BrINT, BArray<BrINT> >;
			pagePair->Key = nMasterIndex;
			for(int i = 0; i < nMstArraySize; i++)
				pagePair->Value.Add(i+1);
			masterPageSet.insertPair(pagePair);
			CPage *pMasterPage = pDelMstPageArray->at(0);
			nPageNum = 1;
			if(pMasterPage)
				nPageNum = pMasterPage->getPageNum();
			updateSlidePageThumbnailCallback(&masterPageSet, BrNULL, Bora_ppt_masterfunc_master_delete, nPageNum);

			pUndoEngine->setContinueFlag(bPrevContinue);
		}
#endif
		m_MasterLayoutArray.RemoveAt(nMasterIndex);
		if (m_MasterLayoutArray.size() <= nMasterIndex)
		{
			BrINT nTotalPageNum = 0;
			for (BrINT i = 0 ; i < m_MasterLayoutArray.size() ; i++) {
				CPageArray *pMstPageArray = m_MasterLayoutArray.at(i);
				if (pMstPageArray) {
					nTotalPageNum +=pMstPageArray->GetSize();
				}
			}

			if (nTotalPageNum == 0)
				nTotalPageNum = 1;
				m_CmdEngine->setCurPageNum(nTotalPageNum);
		}
		arrangeMasterPageNum();
		return BrTRUE;
	}

	readMasterLayoutPage(nStandardMasterIdx);
	CPageArray *pChangeMasterPageArray = m_MasterLayoutArray.at(nStandardMasterIdx);

	if (!pChangeMasterPageArray)
		return BrFALSE;

	BArray<BrINT> changeSlideNums;
	changeSlideNums.RemoveAll();

	for (BrINT i = 0 ; i < getPageArray()->size(); i++)
	{
		CPage *pSlidePage = getPageArray()->at(i);
		if (pSlidePage)
		{
			if (BR_EQUAL_MASTERID(pSlidePage->getMasterID(), nDeleteMasterID))
				changeSlideNums.Add(pSlidePage->getPageNum());
		}
	}

#ifdef BWP_UNDO
	CUndoEngine *pUndoEngine = getUndoEngine();
	if (pUndoEngine)
	{
		//POD-4187
		BrBOOL bPrev = pUndoEngine->setContinueFlag(BrTRUE);
		pCmdEngine->changeMasterPageArrayofSlidePage(pChangeMasterPageArray, &changeSlideNums);

		POUndoRedo::SlideMasterDelete *pUndoData =  pUndoEngine->makeUndoPPTMasterDelete(this, nMasterIndex, nDeleteMasterID);
		if (pUndoData)
		{
			pUndoData->m_pMasterPageArray = pDelMstPageArray;
			pUndoData->m_changeSlideNums = changeSlideNums;
			pUndoData->m_bLayoutChange  = BrTRUE;
			pUndoEngine->storeUndoData(ActionPPTMasterDelete, (CUndoCommand*)pUndoData);
		}
		pUndoEngine->setContinueFlag(bPrev);
	}
#endif

	m_MasterLayoutArray.RemoveAt(nMasterIndex);

	if (m_MasterLayoutArray.size() <= nMasterIndex)
	{
		BrINT nTotalPageNum = 0;
		for (BrINT i = 0 ; i < m_MasterLayoutArray.size() ; i++) {
			CPageArray *pMstPageArray = m_MasterLayoutArray.at(i);
			if (pMstPageArray) {
				nTotalPageNum +=pMstPageArray->GetSize();
			}
		}

		if (nTotalPageNum == 0)
			nTotalPageNum = 1;
		m_CmdEngine->setCurPageNum(nTotalPageNum);
	}
	arrangeMasterPageNum();

	return BrTRUE;
}

BrBOOL	BoraDoc::insertLayoutPage()
{
	BrINT nMasterIndex  = -1;
	BrINT nPageNum		= -1;

	if (!isEditMasterPage())
		return BrFALSE;

	getMasterIndexPageNum(&nMasterIndex, &nPageNum);

	if (nMasterIndex == -1 || nPageNum == -1)
		return BrFALSE;

	CPageArray *pPageArray = m_MasterLayoutArray.at(nMasterIndex);

	if (!pPageArray)
		return BrFALSE;

	CPage *pNewPage = BrNEW CPage(pPageArray);

	if (!pNewPage)
		return BrFALSE;

	//Master ������ ���� �� �о�� ��
	//�߰��� PageIndex�� ������ �Ǹ� layoutPage�� ������ ���� ������ ������ �߻�
	BrINT nPageArraySize = pPageArray->size();

	readMasterLayoutPage(nMasterIndex);

	pNewPage->getPaperSize()->setWidth(m_slideSize.cx);
	pNewPage->getPaperSize()->setHeight(m_slideSize.cy);
	pNewPage->setPageType(LAYOUT_PAGE);

	//BrINT nLayoutID = pPageArray->makeMaxLayoutID();
	//pNewPage->setMasterID(nLayoutID << 16 | (pPageArray->at(0)->getMasterID() & 0x0000ffff));

	BString layoutName = getMasterName(BR_RESSTR_LAYOUT_NAME_CUSTOM);
	for (BrINT i = 0 ; i < nPageArraySize; i++)
	{
		CPage *pPageLayout = pPageArray->at(i);
		BString pageName = pPageLayout->getMasterName();
		if(pageName.compare(layoutName) == 0)
		{
			CTextProc::PPTLayoutPageRename(layoutName, pPageArray);
		}
	}

	pNewPage->setMasterName(layoutName);

	BrINT nInsertPageNum = nPageNum+1;
	if(getCurrentScreenLayoutPage() && getCurrentScreenLayoutPage()->getPageType() == MASTER_PAGE)
	{
		pPageArray->Add(pNewPage);
		nInsertPageNum = pPageArray->size();
	}
	else
		pPageArray->insertNext(nPageNum, pNewPage, BrFALSE);

	pNewPage->setPageNum(nInsertPageNum);
	pNewPage->setLayout(LAYOUT_TYPE_USERDRAWN);
	pNewPage->setMasterName(getMasterName(BR_RESSTR_LAYOUT_NAME_CUSTOM));
	arrangeMasterLayoutID(BrTRUE);
	CTextProc::createDefaultPPTLayoutFrames(this, pNewPage, BR_SLIDE_TEMPLATE_TITLE_ONLY, BrTRUE);

#ifdef BWP_UNDO
	CUndoEngine *pUndoEngine = getUndoEngine();

	if (pUndoEngine)
	{
		BrBOOL bPrevContinue = pUndoEngine->setContinueFlag(BrTRUE);
		POUndoRedo::SlideMasterPageCreate *pData = pUndoEngine->makeUndoCreatePage(getCmdEngine(), pNewPage);
		if (pData) {
			pData->m_MasterBaseData.m_nMasterIndex = nMasterIndex;
			pData->m_MasterBaseData.m_bMasterPageType = LAYOUT_PAGE;
			pData->m_MasterBaseData.m_nLayoutIndex = nInsertPageNum;
			pUndoEngine->storeUndoData(ActionCreatePage, pData);
		}

		//���� ����� �׺���̼� ����
		CKeyValue<BrINT, BArray<BrINT> > masterPageSet;
		stPair<BrINT, BArray<BrINT> > *pagePair = BrNEW stPair<BrINT, BArray<BrINT> >;
		pagePair->Key = nMasterIndex;
		pagePair->Value.Add(nInsertPageNum);
		masterPageSet.insertPair(pagePair);
		updateSlidePageThumbnailCallback(&masterPageSet, BrNULL, Bora_ppt_masterfunc_laytout_insert, getPainter()->doc.m_nCurPage);
		pUndoEngine->setContinueFlag(bPrevContinue);
	}
#endif
	arrangeMasterPageNum();
	pNewPage->setCreated(BrTRUE);
	getCmdEngine()->setCurPageNum(pNewPage->getPageNum());
	getPainter()->doc.m_nCurPage = pNewPage->getPageNum();
	return BrTRUE;
}

BString	BoraDoc::getMasterName(BrINT eStrID)
{
	BString str;
	BrUSHORT dispText[128] = {0};
	BrINT nLen = 128;

	nLen = BrGetResString(eStrID, dispText, nLen);
	if (0 < nLen)
	{
		str.setUnicode((const BChar *)dispText, nLen);
	}else
	{
		switch (eStrID)
		{
			case BR_RESSTR_MASTER_NAME_OFFICE_THEME:
				str = "Office Theme";
				break;
			case BR_RESSTR_LAYOUT_NAME_TITLE: // Office Theme Layout Name 1 - ���� �����̵�
				str = "Title Slide";
				break;
			case BR_RESSTR_LAYOUT_NAME_OBJ: // Office Theme Layout Name 2 - ���� �� ����
				str = "Title and content";
				break;
			case BR_RESSTR_LAYOUT_NAME_SECHEAD: // Office Theme Layout Name 3 - ���� �Ӹ���
				str = "Section headers";
				break;
			case BR_RESSTR_LAYOUT_NAME_TWOOBJ: // Office Theme Layout Name 4 - ������ 2��
				str = "Two Object";
				break;
			case BR_RESSTR_LAYOUT_NAME_TWOTXTWOOBJ: // Office Theme Layout Name 5 - ��
				str = "two Text Two Object";
				break;
			case BR_RESSTR_LAYOUT_NAME_TITLEONLY: // Office Theme Layout Name 6 - ����
				str = "Title Only";
				break;
			case BR_RESSTR_LAYOUT_NAME_BLANK: // Office Theme Layout Name 7 - �� ȭ��
				str = "Blank";
				break;
			case BR_RESSTR_LAYOUT_NAME_OBJTX: // Office Theme Layout Name 8 - ĸ�� �ִ� ������
				str = "Caption and Contents";
				break;
			case BR_RESSTR_LAYOUT_NAME_PICTX: // Office Theme Layout Name 9 - ĸ�� �ִ� �׸�
				str = "Caption and Image";
				break;
			case BR_RESSTR_LAYOUT_NAME_VERTX:// Office Theme Layout Name 10- ���� �� ���� �ؽ�Ʈ
				str = "Title and Sero Text";
				break;
			case BR_RESSTR_LAYOUT_NAME_VERTITLEANDTX:// Office Theme Layout Name 11- ���� ���� �� �ؽ�Ʈ
				str = "Sero Title and Text";
				break;
			case BR_RESSTR_MASTER_NAME_USER_DESIGN:
				str = "User_Degin";
				break;
			case BR_RESSTR_LAYOUT_NAME_CUSTOM:
				str = "Custom Layout";
				break;
		}
	}

	return str;
}

CFrame*	BoraDoc::InsertPlaceHolder(BrUINT nType, BrINT nPosX, BrINT nPoxY, BrINT nWidth, BrINT nHeight, BrINT *nErrorCode)
{
	BrINT nMasterIndex  = -1;
	BrINT nPageNum		= -1;
	CFrame *pFrame		= BrNULL;
	getMasterIndexPageNum(&nMasterIndex, &nPageNum);

	if (nMasterIndex == -1 || nPageNum == -1)
		return BrNULL;

	CPageArray *pPageArray = m_MasterLayoutArray.at(nMasterIndex);

	if (!pPageArray)
		return BrNULL;

	CPage *pPage =pPageArray->at(nPageNum-1);

	if (!pPage)
		return BrNULL;

	if (pPage->getPageType() == MASTER_PAGE)
	{
		*nErrorCode = -2;
		return BrNULL;
	}

	CFrameList *pFrameList = BrNULL;
	pFrameList = getAFrameList(pPage);
	BrTrace("%s[%d] nType = %d || nPageNum = %d", __FUNCTION__, __LINE__, nType, nPageNum);

	PLACEHOLDER_TYPE nPlaceHolderType = PLACEHOLDER_NONE;
	if (nType == PLACEHOLDER_TYPE_GUI_CONTENT)
		nPlaceHolderType = PLACEHOLDER_OBJECT;
	else if (nType == PLACEHOLDER_TYPE_GUI_SERO_CONTENT)
		nPlaceHolderType = PLACEHOLDER_SERO_OBJECT;
	else if (nType == PLACEHOLDER_TYPE_GUI_TEXT)
		nPlaceHolderType = PLACEHOLDER_UNDER_TITLE;
	else if (nType == PLACEHOLDER_TYPE_GUI_SERO_TEXT)
		nPlaceHolderType = PLACEHOLDER_SEROTEXT_UNDER_SEROTITLE;
	else if (nType == PLACEHOLDER_TYPE_GUI_IMAGE)
		nPlaceHolderType = PLACEHOLDER_IMAGE_WITH_CAPTION;
	else if (nType == PLACEHOLDER_TYPE_GUI_CHART)
		nPlaceHolderType = PLACEHOLDER_CHART_OBJECT;
	else if (nType == PLACEHOLDER_TYPE_GUI_TABLE)
		nPlaceHolderType = PLACEHOLDER_TABLE_OBJECT;
	else if (nType == PLACEHOLDER_TYPE_GUI_CAMERA)
		nPlaceHolderType = PLACEHOLDER_CAMERA;
	else if (nType == PLACEHOLDER_TYPE_GUI_MEDIA)
		nPlaceHolderType = PLACEHOLDER_MEDIA;
	else if (nType == PLACEHOLDER_TYPE_GUI_ONLINE_IMAGE)
		nPlaceHolderType = PLACEHOLDER_ONLINE_IMAGE;
	/*
	else if (nType == PLACEHOLDER_TYPE_GUI_SMART_ART)
	{
		pFrame = CTextProc::createTextPlaceHolderFrame(this, pPage, PLACEHOLDER_SMARTART_OBJECT);
		pFrameList->insertAtTail(pFrame);
	}*/
	else {
		BRTHREAD_ASSERT(0);
	}

	pFrame = CTextProc::createTextPlaceHolderFrame(this, pPage, nPlaceHolderType);
	pFrameList->insertAtTail(pFrame);

	if (nPlaceHolderType == PLACEHOLDER_IMAGE_WITH_CAPTION || nPlaceHolderType == PLACEHOLDER_ONLINE_IMAGE || nPlaceHolderType == PLACEHOLDER_MEDIA) //ZPD-11938 �̵�� �����Ͽ� ������ ���� �� �̹��� ���� �Ǿ����
		pFrame->setBlankImageFrame(BrTRUE);

	if (nPosX < 0 || nPoxY < 0)
	{
		BRect rect(300,300,3000,2000);
		pFrame->setFrameRect(rect);
	}else
	{
		BRect rect(nPosX, nPoxY, nPosX+ nWidth , nPoxY + nHeight);
		pFrame->setFrameRect(rect);
	}

	CTextProc::arrangeOneFrame(this, pFrame);
#ifdef BWP_UNDO
	// undo data
	if (!g_pAppStatic->bProtectUndo)
	{
		CUndoEngine    *pUndoEngine = getUndoEngine();
		POUndoRedo::MakeFrame *pUndoData = pUndoEngine->makeUndoCreateFrame(getCmdEngine(), pFrame, BrTRUE);

		if (pUndoData)
			pUndoEngine->storeUndoData(ActionCreateFrame, pUndoData);
	}
#endif //BWP_UNDO
	if (pFrame->getPage()->getPageType() == MASTER_PAGE)
		pFrame->setMasterHolderRelation(MASTER_PAGE_ALL_RELATION | LAYOUT_PAGE_ALL_RELATION);
	else if (pFrame->getPage()->getPageType() == LAYOUT_PAGE)
		pFrame->setMasterHolderRelation(LAYOUT_PAGE_ALL_RELATION);

	pFrame->setPlaceHolderIndex(pPage->getMaxPlaceHolderIndex());

	pPage->setModifiedFrame(BrTRUE);
	return pFrame;



}
BrBOOL	BoraDoc::createDefaultMasterLayout(BrBOOL bUndo)
{
	CPage *pNewPage = BrNULL;
	CPageArray *pBasicMasterPageArray = BrNEW CPageArray(this);

	if (!pBasicMasterPageArray)
		return BrFALSE;

	BrINT nIndex = m_MasterLayoutArray.size();
	BrINT nStartPageNum = 1;
	for (int i = 0 ; i< m_MasterLayoutArray.size() ; i++)
	{
		nStartPageNum += m_MasterLayoutArray.at(i)->size();
	}

	BString newMasterName;


	CPage *pNewMasterPage = pBasicMasterPageArray->at(0);
	if (!pNewMasterPage)
		return BrFALSE;

	BrINT nThemeID;
	if (bUndo) // New�� �ƴ� ��� MasterIndex �߰��ϴ� �����
		nThemeID = ((CThemeBase*)theBWordDoc->m_pTheme)->insertThemeScheme();
	else
		nThemeID = 1;

	//Master Layout Create
	pNewMasterPage->getPaperSize()->setWidth(m_slideSize.cx);
	pNewMasterPage->getPaperSize()->setHeight(m_slideSize.cy);
	pNewMasterPage->getPaperSize()->setSizeID(m_PPTPaperID);
	pNewMasterPage->getPaperSize()->setDirection(LANDSCAPE);
	pNewMasterPage->setPageNum(nStartPageNum++);
	pNewMasterPage->setMstPageNum(1);
	pNewMasterPage->setPageType(MASTER_PAGE);
	pNewMasterPage->setMasterID(makeMaxMasterID());
	pNewMasterPage->setRefThemeID(nThemeID);

	theBWordDoc->resetPageThemeColor(pNewMasterPage);

	if (bUndo)
		newMasterName = getMasterName(BR_RESSTR_MASTER_NAME_USER_DESIGN);
	else
		newMasterName = getMasterName(BR_RESSTR_MASTER_NAME_OFFICE_THEME);

	// Master Name �ߺ� üũ
	BrBOOL bFindMasterName = BrFALSE;
	for (int i = 0 ; i< m_MasterLayoutArray.size() ; i++)
	{
		CPageArray *pTempMasterPageArray = m_MasterLayoutArray.at(i);
		if(pTempMasterPageArray) {
			CPage *pTempMasterPage = pTempMasterPageArray->at(0);
			if (pTempMasterPage) {
				if (pTempMasterPage->getMasterName() == newMasterName)
				{
					int nOffset = newMasterName.findRev("_")+1;
					if(nOffset > 0)
					{
						BString num = newMasterName.right(newMasterName.length()-nOffset);
						if(num.isNumber())
						{
							BrINT nDigit = BrAtoi(num)+1;
							BString strDigit;
							strDigit.setNum(nDigit);

							newMasterName.remove(nOffset,newMasterName.length()-nOffset);
							newMasterName.append(strDigit);
						}
						else
						{
							BString strDigit;
							strDigit.setNum(1);
							newMasterName.append("_").append(strDigit);
						}
					}
					else
					{
						BString strDigit;
						strDigit.setNum(1);
						newMasterName.append("_").append(strDigit);
					}
					i = -1; //������ �̸� �ִ��� ó������ �ٽ� ��
				}
			}
		}
	}

	theBWordDoc->m_pTheme->getUserTheme(nThemeID)->setName(&newMasterName);
	pNewMasterPage->setMasterName(newMasterName);
	pNewMasterPage->setCreated(BrTRUE);

#ifdef BWP_IMG_VIEWER_SLIDE
	if (getFilterMode() != FILTER_IMAGE)
#endif //BWP_IMG_VIEWER_SLIDE
	{
		CTextProc::createDefaultPPTLayoutFrames(this, pNewMasterPage, BR_SLIDE_TEMPLATE_MASTER_LAYOUT, BrTRUE);
		//Default BGFrame ����

		CFrameList* pTFrameList = pNewMasterPage->getTFrameList();
		if (pTFrameList)
		{
			CFrame* pFrame = pTFrameList->getFirst();
			BrBOOL bNoBackground = BrTRUE;
			while (pFrame != BrNULL)
			{
				if (pFrame->isBackgroundFrame())
				{
					bNoBackground = BrFALSE;
					pFrame->setUnderBasic(BrTRUE);
					break;
				}
				pFrame = pTFrameList->getNext(pFrame);
			}

			if (bNoBackground == BrTRUE) //Background Frame�� ���� ��� ���� ����
				pFrame = CTextProc::createBackgroundFrame(this, pNewMasterPage, BrRGB(255, 255, 255));
		}

		BrSlideTemplateType temp[] = { BR_SLIDE_TEMPLATE_TITLE, BR_SLIDE_TEMPLATE_TITLE_OBJECT, BR_SLIDE_TEMPLATE_SECTION_HEADER,
									  BR_SLIDE_TEMPLATE_TWO_OBJECTS, BR_SLIDE_TEMPLATE_TWO_TEXT_TWO_OBJECTS, BR_SLIDE_TEMPLATE_TITLE_ONLY,
									  BR_SLIDE_TEMPLATE_BLANK, BR_SLIDE_TEMPLATE_TITLE_OBJECT_CAPTION,BR_SLIDE_TEMPLATE_PICTURE_CAPTION,
									  BR_SLIDE_TEMPLATE_VERTICALTEXT, BR_SLIDE_TEMPLATE_VERTICALTITLE_TEXT };

		theBWordDoc->setCreatingMasterPage(pNewMasterPage);

		for (int i = 0; i < 11; i++) {
			pNewPage = BrNEW CPage(pBasicMasterPageArray);
			if (!pNewPage) {
				theBWordDoc->setCreatingMasterPage(BrNULL);
				return BrFALSE;
			}
			pNewPage->getPaperSize()->setWidth(m_slideSize.cx);
			pNewPage->getPaperSize()->setHeight(m_slideSize.cy);
			pNewPage->getPaperSize()->setSizeID(m_PPTPaperID);
			pNewPage->getPaperSize()->setDirection(LANDSCAPE);
			pNewPage->setPageNum(nStartPageNum++);
			pNewPage->setMstPageNum(1);
			pNewPage->setPageType(LAYOUT_PAGE);

#ifdef SEPERATE_MASTERID
			pNewPage->setMasterID(pNewMasterPage->getMasterID());
			pNewPage->setLayoutID(i + 1);
#else //SEPERATE_MASTERID
			pNewPage->setMasterID(pNewMasterPage->getMasterID() + ((i + 1) * 0x10000));
#endif //SEPERATE_MASTERID
			pNewPage->setMasterName(getMasterName(BR_RESSTR_LAYOUT_NAME_TITLE + i));
			pNewPage->setCreated(BrTRUE);
			CTextProc::createDefaultPPTLayoutFrames(this, pNewPage, temp[i], BrTRUE);
			pBasicMasterPageArray->Add(pNewPage);
			pBasicMasterPageArray->makeMaxLayoutID();
			pNewPage->setMasterBGUsed(BrTRUE);
			pNewPage->setRefThemeID(nThemeID);
			theBWordDoc->resetPageThemeColor(pNewPage);

		}
	}
#ifdef BWP_IMG_VIEWER_SLIDE
	else
	{
		CPage* pLayoutPage = BrNEW CPage(pBasicMasterPageArray);
		pLayoutPage->setDuplicated(BrFALSE);

		CTextProc::createDefaultPPTLayoutFrames(theBWordDoc, pLayoutPage, BR_SLIDE_TEMPLATE_BLANK, BrTRUE);


		if (pBasicMasterPageArray->size() == 1)
			pBasicMasterPageArray->Add(pLayoutPage);

		pLayoutPage->setPageType(LAYOUT_PAGE);
		pLayoutPage->setOrgPPTSlideNum(0);
		pLayoutPage->setPageNum(nStartPageNum++);
#ifdef SEPERATE_MASTERID
		pLayoutPage->setMasterID(pNewMasterPage->getMasterID());
		pLayoutPage->setLayoutID(1);
#else //SEPERATE_MASTERID
		pLayoutPage->setMasterID(pNewMasterPage->getMasterID() + (0x10000 * 1));
#endif //SEPERATE_MASTERID
		pLayoutPage->setCreated(BrTRUE);

		BSize aSlidesPageSize(19200, 10800);
		theBWordDoc->setSlideSize(aSlidesPageSize);
		theBWordDoc->setPPTPaperID(PPT_PAPER_WIDE);
		CPaperSize* pPapaerSize = pLayoutPage->getPaperSize();
		pPapaerSize->setWidth(19200);
		pPapaerSize->setHeight(10800);
	}
#endif //BWP_IMG_VIEWER_SLIDE

	//ZPD-3488[Slide] �����̵� ������ ���� �� ���� ��ư�� ���� �Ǿ� �ְ� ���� �˾����� ���� �� ���� �ȵ�.
	// New�����϶��� Default�� False��
	if (bUndo)
		pBasicMasterPageArray->setPPTMasterPreserve(BrTRUE);
	else
		pBasicMasterPageArray->setPPTMasterPreserve(BrFALSE);

	BrINT nMaster_Index = 0;
	BrINT nPageNum = 0;
	BrINT nCurrentPageNum = m_CmdEngine->getCurrentPageNum();
	getMasterIndexPageNum(&nMaster_Index, &nPageNum);

	if (m_MasterLayoutArray.size() < 1)
		m_MasterLayoutArray.Add( pBasicMasterPageArray);
	else
	{
		m_MasterLayoutArray.InsertAt( nMaster_Index+1 , pBasicMasterPageArray);
		//PageNum re-setting
		arrangeMasterPageNum();
		//���� Page ���ϱ�
		//BTrace("%s[%d] pBasicMasterPageArray->at(0)->getPageNum() = %d",__FUNCTION__, __LINE__, pBasicMasterPageArray->at(0)->getPageNum());
		if (pBasicMasterPageArray->at(0))
			m_CmdEngine->setCurPageNum(pBasicMasterPageArray->at(0)->getPageNum());
		getPainter()->doc.m_nCurPage = m_CmdEngine->getCurPageNum();
	}
#ifdef BWP_UNDO
	if (bUndo) {
		CUndoEngine *pUndoEngine = getUndoEngine();
		if (pUndoEngine) {
			BrBOOL bPrevContinue = pUndoEngine->setContinueFlag(BrTRUE);
			POUndoRedo::SlideMasterMakePageArray *pData = pUndoEngine->makeUndoCreateMasterPageArray(getCmdEngine(), pBasicMasterPageArray);
			if (pData) {
				pUndoEngine->storeUndoData(ActionCreateMasterPage, pData);
			}

			//���� ����� �׺���̼� ����
			if(getEditMasterType() == EDIT_MASTER_SLIDE)
			{
				BrINT32 nMstArraySize = pBasicMasterPageArray->GetSize();
				CKeyValue<BrINT, BArray<BrINT> > masterPageSet;
				stPair<BrINT, BArray<BrINT> > *pagePair = BrNEW stPair<BrINT, BArray<BrINT> >;
				pagePair->Key = nMaster_Index+1;
				for(int i = 0; i < nMstArraySize; i++)
					pagePair->Value.Add(i+1);
				masterPageSet.insertPair(pagePair);
				updateSlidePageThumbnailCallback(&masterPageSet, BrNULL, Bora_ppt_masterfunc_master_insert, nCurrentPageNum);
			}
			pUndoEngine->setContinueFlag(bPrevContinue);
		}
	}
#endif
	theBWordDoc->setCreatingMasterPage(BrNULL);

	return BrTRUE;
}

void BoraDoc::onDrawForEditMaster(Painter *pPainter, BrDC *pDC)
{
	//[2013.02.19][TID:#13197][�鿵��]PPT & PPTX �ܸ� �ӵ� ������ ���� ��� ������ ����
#ifdef SUPPORT_PPT_TIME_PROFILE
	PROFILE_BEGIN((BrINT32)this, 0);
#endif //SUPPORT_PPT_TIME_PROFILE

	BRect   rcPage, tmpRect, rcPageGap, rcTemp;
	CPage   *pPage = BrNULL;

	int n = 0;
	int nStartPage = m_CmdEngine->getScrStartPage();
	int nEndPage = m_CmdEngine->getScrEndPage();

	CPageArray *pPageArray = BrNULL;
	int nPrevMasterTotalPage = 0;
	int nMasterPageIndex = -1;
	int nMasterPageCnt = -1;

	getMasterIndexPageNum(&nMasterPageIndex, &nMasterPageCnt);
	if (nMasterPageIndex == -1 || nMasterPageCnt == -1) {
		BRTHREAD_ASSERT(0);
		return;
	}

	pPageArray  = m_MasterLayoutArray.at(nMasterPageIndex);
	nStartPage = nEndPage = nMasterPageCnt;

	if( nStartPage < 1 )
		nStartPage = 1;

	if( nEndPage > (int)pPageArray->GetSize() )
		nEndPage = pPageArray->GetSize();

	//--- set Coordinate Conversion Factors
	CDrawUnit dUnit;
	m_CmdEngine->setDrawUnit(dUnit);
	dUnit.setDrawOption(DRAW_ALL);
	BrBOOL bDrawPage;

	m_bOnDraw = BrTRUE;
	n = nStartPage;

	m_MemoEventManager->setDrawingMemoReference(-1); //-1�̸� �ٽ� ����ϴ� �ӹ��� ����.
	readMasterLayoutPage(nMasterPageIndex);

	PO_THREAD_TRY_BLOCK {
		for( n = nStartPage; n <= nEndPage; n++)
		{
			pPage = pPageArray->getPage(n);

			if( pPage )
			{
				rcPage.setRect(0, 0, pPage->width(), pPage->height());
				m_CmdEngine->page2Logical(pPage, rcPage);
				dUnit.setPageStart(rcPage.nLeft, rcPage.nTop);

				bDrawPage = BrTRUE;

				BRect rcEraseBkgnd;
				rcEraseBkgnd.SetEmpty();
				BrCOLORREF color;
				color = getPaperColor();

				if(getInvalidateFlag())
				{
					if (tmpRect.IntersectRect(rcPage, m_rcInvaldateRect))
					{
						if (rcPage.nTop < m_rcInvaldateRect.nTop)
						{
							rcEraseBkgnd = m_rcInvaldateRect;
							if(rcPage.nRight < m_rcInvaldateRect.nRight)
								rcEraseBkgnd.nRight = rcPage.nRight;
							if(rcPage.nBottom < m_rcInvaldateRect.nBottom)
								rcEraseBkgnd.nBottom = rcPage.nBottom;
							if(rcPage.nLeft > m_rcInvaldateRect.nLeft)
								rcEraseBkgnd.nLeft = rcPage.nLeft;

							pDC->fillSolidRect(rcEraseBkgnd.nLeft, rcEraseBkgnd.nTop,
								rcEraseBkgnd.nRight, rcEraseBkgnd.nBottom, color);
						}else if ( rcPage.nTop < m_rcInvaldateRect.nBottom)
						{
							rcEraseBkgnd = m_rcInvaldateRect;

							rcEraseBkgnd.nTop = rcPage.nTop;
							if(rcPage.nRight < m_rcInvaldateRect.nRight)
								rcEraseBkgnd.nRight = rcPage.nRight;
							if(rcPage.nBottom < m_rcInvaldateRect.nBottom)
								rcEraseBkgnd.nBottom = rcPage.nBottom;
							if(rcPage.nLeft > m_rcInvaldateRect.nLeft)
								rcEraseBkgnd.nLeft = rcPage.nLeft;

							pDC->fillSolidRect(rcEraseBkgnd.nLeft, rcEraseBkgnd.nTop,
								rcEraseBkgnd.nRight, rcEraseBkgnd.nBottom, color);
						}
						else
						{
							pDC->fillSolidRect(rcPage.nLeft, rcPage.nTop, rcPage.nRight, rcPage.nBottom, color);
						}
					}
					else
						bDrawPage = BrFALSE;
				}
				else
				{
					fillSolidRectWithClip(pPainter, rcPage.nLeft, rcPage.nTop, rcPage.nRight, rcPage.nBottom, color);
				}

				if (bDrawPage)
					drawPageEdge(pPainter, pDC, rcPage, pPage, n);

				if (bDrawPage)
				{
					setPageDrawing(BrTRUE, pPage);
					pPage->onDrawForEditMaster(pPainter, pDC, dUnit);
					setPageDrawing(BrFALSE);
				}
			}
#ifdef PPT_EDITOR
			else if (EDITOR_PPT == getBWPEngineMode())
			{
				rcPage.setRect(0, 0, m_slideSize.cx, m_slideSize.cy);
				m_CmdEngine->page2Logical(n, rcPage);
				pDC->fillSolidRect(rcPage.nLeft, rcPage.nTop, rcPage.nRight, rcPage.nBottom, RGB_WHITE);

				if(pPage)
					drawPageEdge(pPainter, pDC, rcPage, pPage, n);

				BString str = "Loading...";

				PoTextAtt textAtt;
				textAtt.setEngFSize(400);

				CTextDraw::DrawSlideText(pDC, this, &str, &textAtt, CENTER, MIDDLE_ARRANGE, 0, &rcPage, BrTRUE);

				m_CmdEngine->setNeedValidateScreen(BrTRUE);
				m_CmdEngine->setJustUpdateScreen(BrTRUE);
			}
#if defined(WIN32) && defined(_DEBUG)
			if (pPage) {
				BString str = "";
				char buffer[10], *pBuf;
				if (pPage->getPageType() == MASTER_PAGE) {
					str = "Debug Master Page";
#ifdef SEPERATE_MASTERID
					pBuf = BrItoa(pPage->getMasterID(), buffer,10);
#else //SEPERATE_MASTERID
					pBuf = BrItoa(pPage->getMasterID() & 0x0000ffff, buffer,10);
#endif //SEPERATE_MASTERID
					str += BString(pBuf);
					str += BString("(")  + pPage->getMasterName() + BString(")");
					pBuf = BrItoa(pPage->getPageNum(), buffer,10);
					str += BString("(")  +  pBuf + BString(")");
				}
				else if (pPage->getPageType() == LAYOUT_PAGE) {
					str = "Debug Master Page";
#ifdef SEPERATE_MASTERID
					pBuf = BrItoa(pPage->getLayoutID(), buffer,10);
#else //SEPERATE_MASTERID
					pBuf = BrItoa(pPage->getMasterID() & 0x0000ffff , buffer,10);
#endif //SEPERATE_MASTERID

					str += BString(pBuf);

					str += "  Layout Page";
#ifdef SEPERATE_MASTERID
					pBuf = BrItoa(pPage->getLayoutID(), buffer,10);
#else //SEPERATE_MASTERID
					pBuf = BrItoa((pPage->getMasterID() & 0xffff0000) >> 16, buffer,10);
#endif //SEPERATE_MASTERID
					str += BString(pBuf);
					str += BString("(")  + pPage->getMasterName() + BString(")");
					pBuf = BrItoa(pPage->getPageNum(), buffer,10);
					str += BString("(")  +  pBuf + BString(")");
				}
				else
					str = "Normal Page";

				PoTextAtt textAtt;
				textAtt.setEngFSize(400);
				textAtt.setTextColor(0xff00ff);
				rcPage.nTop = 0;
				CTextDraw::DrawSlideText(pDC, this, &str, &textAtt, LEFT, TOP_ARRANGE, 0, &rcPage, BrTRUE);
			}
#endif
#endif // PPT_EDITOR
		}
	} PO_THREAD_CATCH_BLOCK {
		n++;
		for ( ; n <= nEndPage; n++)
		{
			pPage = pPageArray->getPage(n);
			if (pPage)
			{
				rcPage.setRect(0, 0, pPage->width(), pPage->height());
				m_CmdEngine->page2Logical(pPage, rcPage);
				dUnit.setPageStart(rcPage.nLeft, rcPage.nTop);

				BRect rcEraseBkgnd;
				rcEraseBkgnd.SetEmpty();
				BrCOLORREF color;
				color = getPaperColor();

				if(getInvalidateFlag())
				{
					if (tmpRect.IntersectRect(rcPage, m_rcInvaldateRect))
					{
						if (rcPage.nTop < m_rcInvaldateRect.nTop)
						{
							rcEraseBkgnd = m_rcInvaldateRect;
							if(rcPage.nRight < m_rcInvaldateRect.nRight)
								rcEraseBkgnd.nRight = rcPage.nRight;
							if(rcPage.nBottom < m_rcInvaldateRect.nBottom)
								rcEraseBkgnd.nBottom = rcPage.nBottom;
							if(rcPage.nLeft > m_rcInvaldateRect.nLeft)
								rcEraseBkgnd.nLeft = rcPage.nLeft;

							pDC->fillSolidRect(rcEraseBkgnd.nLeft, rcEraseBkgnd.nTop,
								rcEraseBkgnd.nRight, rcEraseBkgnd.nBottom, color);
						}else if ( rcPage.nTop < m_rcInvaldateRect.nBottom)
						{
							rcEraseBkgnd = m_rcInvaldateRect;

							rcEraseBkgnd.nTop = rcPage.nTop;
							if(rcPage.nRight < m_rcInvaldateRect.nRight)
								rcEraseBkgnd.nRight = rcPage.nRight;
							if(rcPage.nBottom < m_rcInvaldateRect.nBottom)
								rcEraseBkgnd.nBottom = rcPage.nBottom;
							if(rcPage.nLeft > m_rcInvaldateRect.nLeft)
								rcEraseBkgnd.nLeft = rcPage.nLeft;

							pDC->fillSolidRect(rcEraseBkgnd.nLeft, rcEraseBkgnd.nTop,
								rcEraseBkgnd.nRight, rcEraseBkgnd.nBottom, color);
						}
						else
						{
							pDC->fillSolidRect(rcPage.nLeft, rcPage.nTop, rcPage.nRight, rcPage.nBottom, color);
						}
					}
				}
				else
					fillSolidRectWithClip(pPainter, rcPage.nLeft, rcPage.nTop, rcPage.nRight, rcPage.nBottom, color);
			}
		}

		m_bOnDraw = BrFALSE;
	} PO_THREAD_END
	m_bOnDraw = BrFALSE;

	//[2013.02.19][TID:#13197][�鿵��]PPT & PPTX �ܸ� �ӵ� ������ ���� ��� ������ ����
#ifdef SUPPORT_PPT_TIME_PROFILE
	PROFILE_END((BrINT32)this, 0);
#endif //SUPPORT_PPT_TIME_PROFILE

}

CPageArray* BoraDoc::findMasterPageArray(CPageArray* a_pArray)
{
	BrINT nArraySize = m_MasterLayoutArray.size();

	for(BrINT idx = 0; idx<nArraySize; idx++)
	{
		CPageArray* pPageArray = m_MasterLayoutArray.at(idx);
		if(pPageArray == a_pArray)
			return m_MasterLayoutArray.at(idx);
	}

	return BrNULL;
}

#ifdef SEPERATE_MASTERID
CPageArray* BoraDoc::findMasterPageArray(BrUINT a_nMasterID)
#else //SEPERATE_MASTERID
CPageArray* BoraDoc::findMasterPageArray(BrINT a_nMasterID)
#endif //SEPERATE_MASTERID
{
	BrINT nArraySize = m_MasterLayoutArray.size();

	for(BrINT idx = 0; idx<nArraySize; idx++)
	{
		CPageArray* pPageArray = m_MasterLayoutArray.at(idx);
		if(pPageArray && pPageArray->at(0))
		{
#ifdef SEPERATE_MASTERID
			if (pPageArray->at(0)->getMasterID() == a_nMasterID)
#else //SEPERATE_MASTERID
			if (BR_EQUAL_MASTERID(pPageArray->at(0)->getMasterID(), a_nMasterID))
#endif //SEPERATE_MASTERID
				return m_MasterLayoutArray.at(idx);
		}

	}
	return BrNULL;
}
#ifdef SEPERATE_MASTERID
BrINT BoraDoc::findSlideMasterIndex(BrUINT a_nMasterID)
{
	BArray<CPageArray*> pMasterLayoutArray;

	if (getCmdEngine()->isSlideShowInteractiveMode())
		pMasterLayoutArray = m_pCurMasterLayoutArray;
	else
		pMasterLayoutArray = m_MasterLayoutArray;

	if (!pMasterLayoutArray)
		return -1;

	BrINT nArraySize = pMasterLayoutArray.size();

	for(BrINT idx = 0; idx<nArraySize; idx++)
	{
		CPageArray* pPageArray = pMasterLayoutArray.at(idx);
		CPage* pMasterPage = pPageArray->at(0);

		if(pMasterPage)
		{
			BrUINT nSrcMasterID = pMasterPage->getMasterID();
			BrUINT nDstMasterID = a_nMasterID;

			if (nSrcMasterID == nDstMasterID)
				return idx;
		}
	}

	return -1;
}
#else //SEPERATE_MASTERID
BrINT BoraDoc::findSlideMasterIndex(BrINT a_nMasterID)
{
	BArray<CPageArray*> pMasterLayoutArray;
	if (getCmdEngine()->isSlideShowInteractiveMode())
		pMasterLayoutArray = m_pCurMasterLayoutArray;
	else
		pMasterLayoutArray = m_MasterLayoutArray;

	if (!pMasterLayoutArray)
		return -1;

	BrINT nArraySize = pMasterLayoutArray.size();

	for(BrINT idx = 0; idx<nArraySize; idx++)
	{
		CPageArray* pPageArray = pMasterLayoutArray.at(idx);
		CPage* pMasterPage = pPageArray->at(0);

		if(pMasterPage)
		{
			BrINT nSrcMasterID = pMasterPage->getMasterID()&0x0000ffff;
			BrINT nDstMasterID = a_nMasterID & 0x0000ffff;

			if (nSrcMasterID == nDstMasterID)
				return idx;
		}
	}
	//BRTHREAD_ASSERT(0);
	return -1;
}
#endif //SEPERATE_MASTERID

CPage* BoraDoc::findOutlineLayoutPage(CPageArray* pMstPageArray)
{
	CPage *pNewLayoutPage = BrNULL;

	for (BrINT i = 0 ; i < pMstPageArray->size() ; i++)
	{
		CPage *pTempPage = pMstPageArray->at(i);
		if (pTempPage && pTempPage->isPPTOutLinePage()) {
			return pTempPage;
		}
	}

	pNewLayoutPage = BrNEW CPage(pMstPageArray);

	for (BrINT i = 0 ; i < getMasterLayoutArray()->size(); i++)
		readMasterLayoutPage(i);

	pNewLayoutPage->getPaperSize()->setWidth(getSlideSize()->cx);
	pNewLayoutPage->getPaperSize()->setHeight(getSlideSize()->cy);
	pNewLayoutPage->setPageType(LAYOUT_PAGE);

#ifdef SEPERATE_MASTERID
	BrUINT nMasterID = pMstPageArray->at(0)->getMasterID();
	BrUINT nLayoutID = pMstPageArray->makeMaxLayoutID();
	pNewLayoutPage->setMasterID(nMasterID);
	pNewLayoutPage->setLayoutID(nLayoutID);
#else //SEPERATE_MASTERID
	BrINT nMasterID = pMstPageArray->at(0)->getMasterID();
	BrINT nLayoutID = pMstPageArray->makeMaxLayoutID();
	pNewLayoutPage->setMasterID(nMasterID | (nLayoutID << 16));
#endif //SEPERATE_MASTERID

	pNewLayoutPage->setCreated(BrTRUE);

	CTextProc::createDefaultPPTLayoutFrames(this, pNewLayoutPage, BR_SLIDE_TEMPLATE_TITLE_OBJECT, BrTRUE);

	pNewLayoutPage->setMasterName(getMasterName(BR_SLIDE_TEMPLATE_TITLE_ONLY));
	pNewLayoutPage->setPageNum(pMstPageArray->GetSize()+1);
	pNewLayoutPage->setPPTOutLinePage(BrTRUE);
	pMstPageArray->Add(pNewLayoutPage);

	return pNewLayoutPage;
}
#ifdef SEPERATE_MASTERID
BrINT BoraDoc::findSlideLayoutIndex(BrUINT a_nLayoutID, BrINT a_nMasterIndex)
#else //SEPERATE_MASTERID
BrINT BoraDoc::findSlideLayoutIndex(BrINT a_nLayoutID, BrINT a_nMasterIndex)
#endif //SEPERATE_MASTERID
{
	if(a_nMasterIndex < 0)
		return -1;

	BArray<CPageArray*> pMasterLayoutArray;
	if (getCmdEngine()->isSlideShowInteractiveMode())
		pMasterLayoutArray = m_pCurMasterLayoutArray;
	else
		pMasterLayoutArray = m_MasterLayoutArray;

	if (!pMasterLayoutArray)
		return -1;

	BrINT nArraySize = pMasterLayoutArray.at(a_nMasterIndex)->size();
	for(BrINT idx = 0; idx<nArraySize; idx++)
	{
		CPage* page = pMasterLayoutArray.at(a_nMasterIndex)->at(idx);
#ifdef SEPERATE_MASTERID
		if(page && (page->getLayoutID() == a_nLayoutID))
#else //SEPERATE_MASTERID
		if(page && (((page->getMasterID()&0xffff0000) >> 16) == ((a_nLayoutID&0xffff0000) >> 16)))
#endif //SEPERATE_MASTERID
			return idx;
	}

	//BRTHREAD_ASSERT(0);
	return -1;
}

#ifdef SEPERATE_MASTERID
BrINT BoraDoc::findSlideLayoutPageNumber(BrUINT a_nMasterID, BrUINT32 a_nLayoutID)
#else //SEPERATE_MASTERID
BrINT BoraDoc::findSlideLayoutPageNumber(BrINT a_nMasterID)
#endif //SEPERATE_MASTERID
{
	BrINT nPageNumber = 1;
	CPage *pMasterPage = BrNULL;

	for(BrINT nMasterIdx=0; nMasterIdx<m_MasterLayoutArray.size(); nMasterIdx++)
	{
		pMasterPage = m_MasterLayoutArray.at(nMasterIdx)->at(0);

#ifdef SEPERATE_MASTERID
		if(pMasterPage && pMasterPage->getMasterID() == a_nMasterID)
#else //SEPERATE_MASTERID
		if(pMasterPage && (pMasterPage->getMasterID()&0x0000ffff) == (a_nMasterID&0x0000ffff))
#endif //SEPERATE_MASTERID
		{
			CPageArray* pLayoutArray = pMasterPage->getPageArray();
			if(!pLayoutArray)
				return 0;

			for(BrINT nLayoutIdx = 1; nLayoutIdx<pLayoutArray->size(); nLayoutIdx++)
			{
				CPage* pPage = pLayoutArray->at(nLayoutIdx);
				if(pPage)
				{
#ifdef SEPERATE_MASTERID
					if (pPage->getLayoutID() == a_nLayoutID)
#else //SEPERATE_MASTERID
					if ((pPage->getMasterID()&0xffff0000) == (a_nMasterID&0xffff0000))
#endif //SEPERATE_MASTERID

						return nPageNumber;
				}

				nPageNumber++;
			}
		}
		else
			nPageNumber += m_MasterLayoutArray.at(nMasterIdx)->size()-1;
	}

	return 0;
}

#ifdef SEPERATE_MASTERID
BrINT BoraDoc::getMasterPageArrayIdx(BrUINT a_nMasterID)
#else //SEPERATE_MASTERID
BrINT BoraDoc::getMasterPageArrayIdx(BrINT a_nMasterID)
#endif //SEPERATE_MASTERID
{
	BrINT nArraySize = m_MasterLayoutArray.size();

	for(BrINT idx = 0; idx<nArraySize; idx++)
	{
		CPage* pMasterPage = m_MasterLayoutArray.at(idx)->at(0);
		if(pMasterPage)
		{
#ifdef SEPERATE_MASTERID
			BrUINT nSrcMasterID = pMasterPage->getMasterID();
			BrUINT nDstMasterID = a_nMasterID;
#else //SEPERATE_MASTERID
			BrINT nSrcMasterID = pMasterPage->getMasterID()&0x0000ffff;
			BrINT nDstMasterID = a_nMasterID & 0x0000ffff;
#endif //SEPERATE_MASTERID

			if (nSrcMasterID == nDstMasterID)
				return idx;
		}
	}

	return -1;
}

#ifdef SEPERATE_MASTERID
CPage* BoraDoc::getMasterPage(BrUINT a_nMasterID)
#else //SEPERATE_MASTERID
CPage* BoraDoc::getMasterPage(BrINT a_nMasterID)
#endif //SEPERATE_MASTERID
{
	BArray<CPageArray*> pMasterLayoutArray;
	if (getCmdEngine()->isSlideShowInteractiveMode())
		pMasterLayoutArray = m_pCurMasterLayoutArray;
	else
		pMasterLayoutArray = m_MasterLayoutArray;

	if (!pMasterLayoutArray)
		return BrNULL;

	BrINT nArraySize = pMasterLayoutArray.size();

	for(BrINT idx = 0; idx<nArraySize; idx++)
	{
		CPageArray* pOneMasterLayoutArray = BrNULL;
		pOneMasterLayoutArray = pMasterLayoutArray.at(idx);
		if(!pOneMasterLayoutArray)
			continue;

		CPage* pMasterPage = pOneMasterLayoutArray->at(0);

		if(pMasterPage)
		{
#ifdef SEPERATE_MASTERID
			BrUINT nSrcMasterID = pMasterPage->getMasterID();
			BrUINT nDstMasterID = a_nMasterID;
#else //SEPERATE_MASTERID
			BrINT nSrcMasterID = pMasterPage->getMasterID()&0x0000ffff;
			BrINT nDstMasterID = a_nMasterID & 0x0000ffff;
#endif //SEPERATE_MASTERID

			if (nSrcMasterID == nDstMasterID)
				return pMasterLayoutArray.at(idx)->at(0);
		}
	}

	return BrNULL;
}

#ifdef SEPERATE_MASTERID
CPage* BoraDoc::getLayoutPage(BrUINT a_nMasterID, BrUINT a_nLayoutID)
#else //SEPERATE_MASTERID
CPage* BoraDoc::getLayoutPage(BrINT a_nMasterID, BrINT a_nLayoutID)
#endif //SEPERATE_MASTERID
{
	BrINT nMasterIdx = 0;

	BArray<CPageArray*> pMasterLayoutArray;
	if (getCmdEngine()->isSlideShowInteractiveMode())
		pMasterLayoutArray = m_pCurMasterLayoutArray;
	else
		pMasterLayoutArray = m_MasterLayoutArray;

	if (!pMasterLayoutArray)
		return BrNULL;


	BrINT nMasterArraySize = pMasterLayoutArray.size();
#ifndef SEPERATE_MASTERID
	a_nMasterID &= 0x0000ffff;
	a_nLayoutID &= 0xffff0000;
#endif //SEPERATE_MASTERID

	CPage *pMasterPage = getMasterPage(a_nMasterID);

	if (pMasterPage)
	{
		CPageArray* pLayoutArray = pMasterPage->getPageArray();
		if (pLayoutArray)
		{
			BrINT nLayoutArraySize = pLayoutArray->size();
			for(BrINT layoutIdx = 1; layoutIdx<nLayoutArraySize; layoutIdx++)
			{
				CPage* pPage = pLayoutArray->at(layoutIdx);
				if(pPage)
				{
#ifdef SEPERATE_MASTERID
					if ((pPage->getLayoutID()) == a_nLayoutID)
#else //SEPERATE_MASTERID
					if ((pPage->getMasterID() & 0xffff0000) == a_nLayoutID)
#endif //SEPERATE_MASTERID
						return pLayoutArray->at(layoutIdx);
				}
			}
		}
	}

	return BrNULL;
}

void	BoraDoc::readMasterLayoutPage(BrINT nMasterIndex)
{
	if(nMasterIndex < 0)
		return;

	//Read Master Page. ������ Page�� ���� �о Layout Max���� �����
	for (int i = 0 ; i < m_MasterLayoutArray.size(); i++)
	{
		CPageArray *pMasterPageArray = m_MasterLayoutArray.at(i);
		if (pMasterPageArray  && pMasterPageArray->size() > 0)
		{
			CPage *pMasterPage =  pMasterPageArray->at(0);
			if (!pMasterPage)
			{
#ifdef IMPORT_PPTX
				((ptxDocument*)(mp_doc))->ReadPptxSlideLayouts(i, 1);
#endif //IMPORT_PPTX
			}
		}
	}

	if(m_MasterLayoutArray.GetSize() > 0)
	{
		CPageArray *pMasterPageArray = m_MasterLayoutArray.at(nMasterIndex);
		if (pMasterPageArray) {
			BrINT nLayoutTotalCnt = pMasterPageArray->size();
			for (BrINT nLayoutNum = 2 ; nLayoutNum <= nLayoutTotalCnt; nLayoutNum++)
			{
				CPage *pPage = pMasterPageArray->getPage(nLayoutNum);
				if (!pPage)
				{
					// Read PPT Layout Page;
#ifdef IMPORT_PPTX
					((ptxDocument*)(mp_doc))->ReadPptxSlideLayouts(nMasterIndex, nLayoutNum);
#endif //IMPORT_PPTX
				}
			}
		}
	}
}

void	BoraDoc::arrangeMasterLayoutID(BrBOOL bArrangeSlide)
{
	//[�̻�ȣ] layout�� �߰��ǰų� �����Ǿ����� masterID�� �ٽ� ����
	CPageArray *pSlidePageArray = getPageArray();
	BrINT nSlidePageSize = 0;
	if(pSlidePageArray)
		nSlidePageSize = pSlidePageArray->GetSize();
	CPage *pSlide = BrNULL;
	Painter* pPainter = gpPaint;
	BArray<BrINT> arrangedPageIdxArr;
	BrINT nMasterArraySize = m_MasterLayoutArray.size();
	for (int i = 0 ; i < nMasterArraySize; i++)
	{
		CPageArray *pPageArray = m_MasterLayoutArray.at(i);
		if (pPageArray) {
			//layout page�� �������
			BrINT nLayoutSize = pPageArray->size();
			for (int nCnt = 1 ; nCnt < nLayoutSize ; nCnt++)
			{
				CPage *pPage = pPageArray->at(nCnt);
				if (pPage)
				{
#ifdef SEPERATE_MASTERID
					if(pSlidePageArray && bArrangeSlide) //layout page insert�� ��� �����ϴ� �����̵尡 �����Ƿ� �����̵� Ž�� �ʿ����.
					{
						BrINT nMasterID = pPage->getMasterID();
						for(int j = 0; j < nSlidePageSize; j++)
						{
							pSlide = pSlidePageArray->at(j);
							if(!pSlide)
							{
								getCmdEngine()->checkCacheData(pPainter);
								pPainter->m_nPageCaching = STOP_PAGE_CACHING;
								pSlide = HandsPointer_ReadSlide_PPT_BWP(pPainter, j+1, j+1, BrFALSE);
							}

							if(pSlide && pSlide->getMasterID() == pPage->getMasterID() && pSlide->getLayoutID() == pPage->getLayoutID() && !arrangedPageIdxArr.contains(j))
							{
								pSlide->setMasterID(pPageArray->at(0)->getMasterID());
								pSlide->setLayoutID(nCnt);
								pSlide->setModifiedMasterLayoutPage(BrTRUE);
								BrINT nMaster = pSlide->getMasterID();
								//BTrace("@@@@@ slidnum : %d, masterID : %x, J: %d", nCnt, nMaster, j);
								arrangedPageIdxArr.Add(j);
							}
						}
					}

					pPage->setMasterID(pPageArray->at(0)->getMasterID());
					pPage->setLayoutID(nCnt);
#else //SEPERATE_MASTERID
					if(pSlidePageArray && bArrangeSlide) //layout page insert�� ��� �����ϴ� �����̵尡 �����Ƿ� �����̵� Ž�� �ʿ����.
					{
						BrINT nMasterID = pPage->getMasterID();
						for(int j = 0; j < nSlidePageSize; j++)
						{
							pSlide = pSlidePageArray->at(j);
							if(!pSlide)
							{
								getCmdEngine()->checkCacheData(pPainter);
								pPainter->m_nPageCaching = STOP_PAGE_CACHING;
								pSlide = HandsPointer_ReadSlide_PPT_BWP(pPainter, j+1, j+1, BrFALSE);
							}

							if(pSlide && pSlide->getMasterID() == pPage->getMasterID() && !arrangedPageIdxArr.contains(j))
							{
								pSlide->setMasterID(nCnt << 16 | (pPageArray->at(0)->getMasterID() & 0x0000ffff));
								pSlide->setModifiedMasterLayoutPage(BrTRUE);
								BrINT nMaster = pSlide->getMasterID();
								//BTrace("@@@@@ slidnum : %d, masterID : %x, J: %d", nCnt, nMaster, j);
								arrangedPageIdxArr.Add(j);
							}
						}
					}
					pPage->setMasterID(nCnt << 16 | (pPageArray->at(0)->getMasterID() & 0x0000ffff));
#endif //SEPERATE_MASTERID
				}
			}
		}
	}
}

void	BoraDoc::arrangeMasterPageNum()
{
	BrINT nNewTotalPageNum = 0;
	for (int i = 0 ; i < m_MasterLayoutArray.size(); i++)
	{
		CPageArray *pPageArray = m_MasterLayoutArray.at(i);
		if (pPageArray) {
			for (int nCnt = 0 ; nCnt < pPageArray->size() ; nCnt++) {
				CPage *pPage = pPageArray->at(nCnt);
				++nNewTotalPageNum;
				if (pPage) {
					pPage->setPageNum(nNewTotalPageNum);
				}
			}
		}
	}
}
CHandoutMaster*	BoraDoc::getHandoutMaster() {
	return m_HandoutMaster;
}
#ifdef PPT_EDITOR
CNoteMaster*	BoraDoc::getNoteMaster() {
	return m_NoteMaster;
}
CPPTNoteMaster*	BoraDoc::getPPTNoteMaster() {
	return m_PPTNoteMaster;
}
CWordMultiPagePrint*	BoraDoc::getWordMultiPagePrint(){
	return m_WordMultiPagePrint;
}
#endif //PPT_EDITOR
void BoraDoc::SetGrayMode( BrINT mode )
{
	if( m_nGrayMode != mode )
	{
		//thumbnail update needed
		CPageArray* pPA = getPageArray();
		int count = getTotalPage();
		for( int i = 1 ; i<=count ; i++ )
		{
			CPage* pPage = pPA->getPage(i);
			if( pPage )
			{
#ifdef USE_PPT_NOTEMASTER
				if(m_nBWPEngineMode == EDITOR_PPT && getNoteDrawMode(pPage) && pPage->getPageType() == SLIDE_PAGE)
				{
					CPage *pNotePage = pPage->getNoteSlidePage();
					pNotePage->updateSldImgPlaceHolderFlag(pNotePage);
				}
				else
#endif
				pPage->setThumbnailModified( BrTRUE );
			}
		}

		m_nGrayMode = mode;
	}
}

void	BoraDoc::setIncPageNum(BrINT n)
{
#ifdef  USE_HWP_CONTROL
	BRCONTEXT
	//����� ���� ����.
	if(Brcontext.m_GeneralValue.bSyncMode)
		m_nIncPageNum = 1000;
	else if(g_pBInterfaceHandle->getDocumentValidattionMode())
		m_nIncPageNum = USHRT_MAX;
	else
#endif	//USE_HWP_CONTROL
		m_nIncPageNum = n;
}


BrBOOL BoraDoc::IsMarkAsFinal()
{
	return BrFALSE;
}

void BoraDoc::SetMarkAsFinal(BrBOOL b)
{

}

#ifdef PPT_EDITOR
BrSize* BoraDoc::getSlideSize()
{
	return &m_slideSize;
}

void BoraDoc::setDrawMarginLine(BrUINT16 flag)
{
	if(flag & BR_DRAW_MARGINLINE_PAGE)
	{
		if(m_drawMarginLineFlag & BR_DRAW_MARGINLINE_PAGE)
			m_drawMarginLineFlag ^= BR_DRAW_MARGINLINE_PAGE;
		else
			m_drawMarginLineFlag |= BR_DRAW_MARGINLINE_PAGE;
	}
	if(flag & BR_DRAW_MARGINLINE_MARGIN)
	{
		if(m_drawMarginLineFlag & BR_DRAW_MARGINLINE_MARGIN)
			m_drawMarginLineFlag ^= BR_DRAW_MARGINLINE_MARGIN;
		else
			m_drawMarginLineFlag |= BR_DRAW_MARGINLINE_MARGIN;
	}
}

BrSize* BoraDoc::getSlideNotePaperSize()
{
	return &m_slideNotePaperSize;
}

#endif //PPT_EDITOR
void BoraDoc::resetPageBGColor(CPage* pPage, BrINT nThemeId)
{
	if(pPage)
	{
		CFrameList *pFrameList = pPage->getPageAFrameList(); //getTFrameList();
		if(pFrameList)
		{
			CFrame *pFrame = pFrameList->getFirst();
			while(pFrame != BrNULL)
			{

				if(pFrame->isGroup())
				{
					CFrameList *pList = (CFrameList *)pFrame->getSubFrame();
					CFrame *pSubFrame = pList->getFirst();
					while(pSubFrame != BrNULL)
					{
						if(pSubFrame->getBorder() != BrNULL)
						{
							pSubFrame->getBorder()->resetThemeColor(nThemeId);
							pSubFrame->clearImageCache();
						}
						pSubFrame = pList->getNext(pSubFrame);

					}
				}else
				{
					if(pFrame->getBorder() != BrNULL)
					{
						pFrame->getBorder()->resetThemeColor(nThemeId);
						pFrame->clearImageCache();
					}
				}


				pFrame = pFrameList->getNext(pFrame);
			}
		}
	}
}

void BoraDoc::resetThemeColor(BrINT nThemeId)
{	//��� ���������� ���� �׸� ID�� �������� ã�Ƽ� �귯�� reset

	if( getBWPEngineMode() == EDITOR_PPT )
	{//ppt �� �����Ǿ�� �Ѵ�
		//�׸�ID 0�� ��� ���� �������� �׸� ID
		if(nThemeId == 0)
			nThemeId = theBWordDoc->getCmdEngine()->getCurrentPage()->getRefThemeID();

#ifdef SEPERATE_MASTERID
		BrUINT nMasterID = 1;
#else //SEPERATE_MASTERID
		BrINT nMasterID = 1;
#endif //SEPERATE_MASTERID

		BrINT nPageArrSize = theBWordDoc->getPageArray()->GetSize();
		CPageArray* pPageArray = theBWordDoc->getPageArray();
		CPage* pPage = BrNULL;
		for(int i=0; i<nPageArrSize; i++)
		{
			pPage = pPageArray->at(i);
			if(pPage && pPage->getRefThemeID() == nThemeId)
			{
#ifdef SEPERATE_MASTERID
				nMasterID = pPage->getMasterID();
#else //SEPERATE_MASTERID
				nMasterID = pPage->getMasterID() & 0x0000ffff;
#endif //SEPERATE_MASTERID
				resetPageThemeColor(pPage);
				pPage->setThumbnailModified(BrTRUE);

				//Bitmap cache clear
				CFrameList *pFrameList = pPage->getAnchorFrameList();
				CFrame *pTempFrame = pFrameList->getFirst();
				while (pTempFrame) {
					pTempFrame->clearImageCache();
					pTempFrame = pFrameList->getNext(pTempFrame);
				}

				resetWordArtThemeColor(pFrameList);
			}
		}
		//������ ������
		pPage = getMasterPage(nMasterID);
		CPPTNoteMaster* pNM = getPPTNoteMaster();
		CPage* pNoteMasterPage = pNM->GetNoteMasterPage();
		if(pNoteMasterPage)
			pNoteMasterPage->updateSldImgPlaceHolderFlag(pNoteMasterPage);

		//���̾ƿ� ������
		CPageArray* pMasterPageArray = findMasterPageArray(nMasterID);
		if(pMasterPageArray)
		{
			for(BrINT nPageNum=1; nPageNum<= pMasterPageArray->size(); nPageNum++)
			{
				CPage *pLayoutPage = pMasterPageArray->getPage(nPageNum);
				if(pLayoutPage && pLayoutPage->getPageType() == LAYOUT_PAGE)
				{
					resetPageThemeColor(pLayoutPage);
					resetWordArtThemeColor(pLayoutPage->getAnchorFrameList());
				}
			}
		}
	}
	else
	{
		//Bitmap cache clear
		BrINT nPageArrSize = theBWordDoc->getPageArray()->GetSize();
		CPageArray* pPageArray = theBWordDoc->getPageArray();
		CPage* pPage = BrNULL;
		for(int i=0; i<nPageArrSize; i++)
		{
			pPage = pPageArray->at(i);
			if(pPage)
			{
				CFrameList *pBframeList = pPage->getBFrameList();
				if(pBframeList)
					resetWordArtThemeColor(pBframeList);
			}
		}

		CFrameList *pFrameList = getAFrameList();
		CFrame *pTempFrame = pFrameList->getFirst();
		while (pTempFrame) {
			pTempFrame->clearImageCache();
			pTempFrame = pFrameList->getNext(pTempFrame);
		}
		resetWordArtThemeColor(pFrameList);

	}

	//Para Color & Text Color Reset
	//[2013-12-31][M-46476][20hoon]
	const PoParaAtt* pParaAtt = BrNULL;
	const PoTextAtt* pTextAtt = BrNULL;
	CBorderLineInfo* pBorderLineInfo = BrNULL;

	BrINT paraAttArrSize = m_ParaAttHandler->getParaAttArraySize();
	for(BrINT i = 0; i < paraAttArrSize - 1; i++)
	{
		pParaAtt = m_ParaAttHandler->getParaAtt(i);

		pParaAtt->getShadingFillColor().resetThemeRGBColor();
		pParaAtt->getShadingPatternColor().resetThemeRGBColor();

		if( pParaAtt->isSettedParaBorderLineInfo() == BrTRUE )
		{
			pBorderLineInfo = pParaAtt->getParaBorderLineInfo();
			if(pBorderLineInfo)
			{
				if(pBorderLineInfo->getTopBorderLine()!=BrNULL && pBorderLineInfo->getTopBorderLine()->getBorderLineArtStyle() != BR_ART_BORDER_NONE)
					pBorderLineInfo->getTopBorderLine()->getBorderLineColor()->resetThemeRGBColor();

				if(pBorderLineInfo->getBottomBorderLine()!=BrNULL && pBorderLineInfo->getBottomBorderLine()->getBorderLineArtStyle() != BR_ART_BORDER_NONE)
					pBorderLineInfo->getBottomBorderLine()->getBorderLineColor()->resetThemeRGBColor();

				if(pBorderLineInfo->getLeftBorderLine()!=BrNULL && pBorderLineInfo->getLeftBorderLine()->getBorderLineArtStyle() != BR_ART_BORDER_NONE)
					pBorderLineInfo->getLeftBorderLine()->getBorderLineColor()->resetThemeRGBColor();

				if(pBorderLineInfo->getRightBorderLine()!=BrNULL && pBorderLineInfo->getRightBorderLine()->getBorderLineArtStyle() != BR_ART_BORDER_NONE)
					pBorderLineInfo->getRightBorderLine()->getBorderLineColor()->resetThemeRGBColor();

				if(pBorderLineInfo->getBetweenBorderLine()!=BrNULL && pBorderLineInfo->getBetweenBorderLine()->getBorderLineArtStyle() != BR_ART_BORDER_NONE)
					pBorderLineInfo->getBetweenBorderLine()->getBorderLineColor()->resetThemeRGBColor();
			}
		}
	}

	for(BrINT i=0;i<m_TextAttHandler->getTextAttArraySize();i++)
	{
		pTextAtt = m_TextAttHandler->getTextAtt(i);
		if(pTextAtt!=BrNULL)
		{
			pTextAtt->getShadingFillColor().resetThemeRGBColor();
			pTextAtt->getShadingPatternColor().resetThemeRGBColor();
			pTextAtt->getBackColor().resetThemeRGBColor();
			pTextAtt->getUnderlineColor().resetThemeRGBColor();
			pTextAtt->getTextColor().resetThemeRGBColor();

			pBorderLineInfo = pTextAtt->getTextBorderLineInfo();
			if(pBorderLineInfo!=BrNULL)
			{
				BrColor* pBorderAllColor = const_cast<BrColor*>((pBorderLineInfo)->getAllBorderLineColor());
                if (pBorderAllColor)
                  pBorderAllColor->resetThemeRGBColor();
			}
		}
	}
}

void BoraDoc::resetPageThemeColor(CPage *pPage /*= BrNULL*/, BrBOOL isUndo /*= BrFALSE*/)
{
	//�Ķ���ͷ� �Ѿ��� �������� �÷�����.
	//�׸� ���̵�� ��ü ������ ���� �ϱ� ���ؼ� resetThemeColor(BrINT nThemeId); �Լ� ���
	//theBWordDoc->getDefaultGrapAtt()->resetThemeColor();
	CFrameList *pFrameList = BrNULL;
	BrINT nThemeId  = 1;
	if( getBWPEngineMode() == EDITOR_WORD )
		pFrameList = theBWordDoc->getAFrameList();
	else
	{//PPT
		if (pPage == BrNULL)
			pPage = getCmdEngine()->getCurrentPage();

		if (!pPage) // Curerent Page�� ������ return
			return;
		pFrameList = pPage->getPageAFrameList();
		nThemeId = pPage->getRefThemeID();
	}

#ifdef USE_HWP_CONTROL
	theBWordDoc->getDefaultGrapAtt()->resetThemeColor(nThemeId);
#endif//#ifdef USE_HWP_CONTROL
	if (pFrameList) {
		resetWordArtThemeColor(pFrameList);
		CFrame *pFrame = pFrameList->getFirst();

		while(pFrame != BrNULL)
		{
			if(pFrame->isGroup())
			{
				CFrameList *pList = (CFrameList *)pFrame->getSubFrame();
				CFrame *pSubFrame = pList->getFirst();
				while(pSubFrame != BrNULL)
				{
					if(pSubFrame->getBorder() != BrNULL)
						pSubFrame->getBorder()->resetThemeColor(nThemeId);
					pSubFrame = pList->getNext(pSubFrame);
				}
			}else
			{
				if(pFrame->getBorder() != BrNULL)
					pFrame->getBorder()->resetThemeColor(nThemeId);
			}


			pFrame = pFrameList->getNext(pFrame);
		}
	}

	//��� ����. ����ȵǵ� ���� �۵� �ϴ� ��.
	BrBOOL retVal = BrFALSE;

	//�����̵� ������ ��� ����
	if (pPage == BrNULL)
		pPage = getCmdEngine()->getCurrentPage();

	resetPageBGColor(pPage, nThemeId);

	if(m_nDocType==BORA_DOCTYPE_PPTX)//misty - 2014.01.17
	{
		//���̾ƿ� ������ ��� ����
		if(pPage != BrNULL)
		{
#ifdef SEPERATE_MASTERID
			pPage = getLayoutPage(pPage->getMasterID(), pPage->getLayoutID());
#else //SEPERATE_MASTERID
			pPage = getLayoutPage((pPage->getMasterID() & 0x0000ffff), (pPage->getMasterID() & 0xffff0000));
#endif //SEPERATE_MASTERID

			resetPageBGColor(pPage, nThemeId);
		}

		//������ ������ ��� ����
		if(pPage != BrNULL)
		{
#ifdef SEPERATE_MASTERID
			pPage = getMasterPage(pPage->getMasterID());
#else //SEPERATE_MASTERID
			pPage = getMasterPage((pPage->getMasterID() & 0x0000ffff));
#endif //SEPERATE_MASTERID

			resetPageBGColor(pPage, nThemeId);
		}
	}

#if 0
	//���� ��� ����
	pPage->resetBackgroundFrame();

	//������ ������
	//pPage->getMasterID(); //0xffff0000 LayoutID , 0x0000fffff MasterID

	CPage *pMasterPage = getMasterPage((pPage->getMasterID() & 0x0000fffff));
	CPage *pLayoutPage = getLayoutPage((pPage->getMasterID() & 0x0000fffff), (pPage->getMasterID() & 0xffff0000));

	for (BrINT i = 0 ; i < m_MasterLayoutArray.size(); i++)
	{
		CPageArray *pPageArray = m_MasterLayoutArray.at(i);
		if (pPageArray) {
			for (BrINT idx = 0 ; i < pPageArray->GetSize(); i++)
			{
				CPage *pSlidePage = pPageArray->at(idx);
				if (pSlidePage) {
					pSlidePage->getPageAFrameList();
				}
			}
		}
	}
#endif
}


void BoraDoc::resetWordArtThemeColor(CFrameList *pFrameList)
{
	//CFrameList* pFrameList = pPage->getAnchorFrameList();
	if(pFrameList == BrNULL)
		return;

	CFrame* pFrame = pFrameList->getFirst();

	CBTable* pTable = BrNULL;
	CCellList* pCellList = BrNULL;
	CBCell* pCell = BrNULL;

	CFrame* pCellFrame = BrNULL;
	while (pFrame)
	{
		if (pFrame->isTable())
		{
			pTable = (CBTable *)pFrame->getSubFrame();
			if (pTable)
			{
				pCellList =  pTable->getFirstCellList();

				while(pCellList)
				{
					pCell = pCellList->getFirstCell();
					while (pCell)
					{
						pCellFrame = pCell->getFrame();

						if(pCellFrame && pCellFrame->isText())
						{
							if(pCellFrame->getFirstLine())
							{
								CLine* pLine = pCellFrame->getFirstLine();
								while (pLine)
								{
									if(pLine->getWordArtBitmapArray() && pLine->getWordArtBitmapArray()->GetSize() > 0)
										pLine->clearBitmapCache();
									pLine = pLine->getNext();
								}
							}
							pCellFrame->setModifiedAttribute(BrTRUE);
						}
						pCell = pCell->getNext();
					}//end while pCell
					pCellList = pCellList->getNext();
				}//end while pCellList
			}
		}
		else if(pFrame && pFrame->isText())
		{
			if(pFrame->getFirstLine())
			{
				CLine* pLine = pFrame->getFirstLine();
				while (pLine)
				{
					if(pLine->getWordArtBitmapArray() && pLine->getWordArtBitmapArray()->GetSize() > 0)
						pLine->clearBitmapCache();
					pLine = pLine->getNext();
				}
			}
			pFrame->setModifiedAttribute(BrTRUE);
		}

		pFrame = pFrameList->getNext(pFrame);
	}//end while
}

void BoraDoc::resetChartThemeColor()
{
	CPage *pPage = BrNULL;
	BrINT nThemeId = 1;
	if( getBWPEngineMode() == EDITOR_PPT )
	{//ppt �� �����Ǿ�� �Ѵ�
		//�׸�ID 0�� ��� ���� �������� �׸� ID
		nThemeId = theBWordDoc->getCmdEngine()->getCurrentPage()->getRefThemeID();

#ifdef SEPERATE_MASTERID
		BrUINT nMasterID = 1;
#else //SEPERATE_MASTERID
		BrINT nMasterID = 1;
#endif //SEPERATE_MASTERID

		BrINT nPageArrSize = theBWordDoc->getPageArray()->GetSize();
		CPageArray* pPageArray = theBWordDoc->getPageArray();
		CPage* pPage = BrNULL;
		for(int i=0; i<nPageArrSize; i++)
		{
			pPage = pPageArray->at(i);
			if(pPage && pPage->getRefThemeID() == nThemeId)
			{
#ifdef SEPERATE_MASTERID
				nMasterID = pPage->getMasterID();
#else //SEPERATE_MASTERID
				nMasterID = pPage->getMasterID() & 0x0000ffff;
#endif //SEPERATE_MASTERID

				resetPageChartThemeColor(pPage);
				pPage->setThumbnailModified(BrTRUE);

				//Bitmap cache clear
				CFrameList *pFrameList = pPage->getAnchorFrameList();
				CFrame *pTempFrame = pFrameList->getFirst();
				while (pTempFrame) {
					pTempFrame->clearImageCache();
					pTempFrame = pFrameList->getNext(pTempFrame);
				}
			}
		}
		//������ ������
		pPage = getMasterPage(nMasterID);
		resetPageChartThemeColor(pPage);

		//���̾ƿ� ������
		CPageArray* pMasterPageArray = findMasterPageArray(nMasterID);
		if(pMasterPageArray)
		{
			for(BrINT nPageNum=1; nPageNum<= pMasterPageArray->size(); nPageNum++)
			{
				CPage *pLayoutPage = pMasterPageArray->getPage(nPageNum);
				if(pLayoutPage && pLayoutPage->getPageType() == LAYOUT_PAGE)
				{
					resetPageChartThemeColor(pLayoutPage);
				}
			}
		}
	}
	else
	{
		//Bitmap cache clear
		CFrameList *pFrameList = getAFrameList();
		CFrame *pTempFrame = pFrameList->getFirst();
		while (pTempFrame) {
			pTempFrame->clearImageCache();

			//��Ʈ �׸� �� ���� ���� �۾�
			if(pTempFrame->isChart()) {
				CBWPChart* pChart = (CBWPChart*)pTempFrame;

				if(pChart->getShapeChart() == BrNULL)
					pChart->ReadEmbedChart();

				if(!g_pAppStatic->bProtectUndo)
				{
					CCmdEngine* pCmdEngine = theBWordDoc->getCmdEngine();
					CUndoEngine *pUndoEngine = pCmdEngine->getUndoEngine();
					BrBOOL bPreContinue = pUndoEngine->setContinueFlag(BrTRUE);
					POUndoRedo::ChartColorTheme *pUndoData = pUndoEngine->makeUndoChartColorTheme(pChart);
					if( pUndoData!=BrNULL )
						pUndoEngine->storeUndoData(ActionChartColorTheme, pUndoData);

					pUndoEngine->setContinueFlag(bPreContinue);
				}

				BrChartColorThemeEvent pChartColorChange;
				memset(&pChartColorChange, 0, BrSizeOf(BrChartColorThemeEvent));
				pChartColorChange.nColorType = BR_Chart_Theme_Color;
				pChartColorChange.nThemeID = nThemeId;
				pChart->setChartColorTheme_BWP(&pChartColorChange);
			}

			pTempFrame = pFrameList->getNext(pTempFrame);
		}
	}
}

void BoraDoc::resetPageChartThemeColor(CPage *pPage)
{
	CFrameList *pFrameList = BrNULL;
	BrINT nThemeId  = 1;
	if( getBWPEngineMode() == EDITOR_WORD )
		pFrameList = theBWordDoc->getAFrameList();
	else if(getBWPEngineMode() == EDITOR_PPT)
	{//PPT
		if (pPage == BrNULL && theBWordDoc->getCmdEngine())
			pPage = theBWordDoc->getCmdEngine()->getCurrentPage();

		if (pPage) // Curerent Page�� ������ return
		{
			pFrameList = pPage->getPageAFrameList();
			nThemeId = pPage->getRefThemeID();
		}
	}


	//��Ʈ �׸� �� ���� ���� �۾�
	if (pPage && pFrameList) {
		CFrame *pFrame = pFrameList->getFirst();

		while(pFrame != BrNULL)
		{
			if(pFrame->isChart()) {
				CBWPChart* pChart = (CBWPChart*)pFrame;
				if(pChart->getShapeChart() == BrNULL)
					pChart->ReadEmbedChart();

				if(pChart->getShapeChart() == BrNULL)
					continue;
				//BrChartThemeColorType eChartThemeColorType = poChart_getChartThemeColor_I(pChart->getShapeChart());
				CCmdEngine* pCmdEngine = theBWordDoc->getCmdEngine();
				CUndoEngine *pUndoEngine = pCmdEngine->getUndoEngine();

				if(!g_pAppStatic->bProtectUndo)
				{
					POUndoRedo::ChartColorTheme *pUndoData = pUndoEngine->makeUndoChartColorTheme(pChart);
					if( pUndoData!=BrNULL )
						pUndoEngine->storeUndoData(ActionChartColorTheme, pUndoData);
				}

				BrChartColorThemeEvent pChartColorChange;
				memset(&pChartColorChange, 0, BrSizeOf(BrChartColorThemeEvent));
				pChartColorChange.nColorType = BR_Chart_Theme_Color;
				pChartColorChange.nThemeID = nThemeId;
				pChart->setChartColorTheme_BWP(&pChartColorChange);
			}
			pFrame = pFrameList->getNext(pFrame);
		}//end while
	}
}

int BoraDoc::getCurrentMemoId()
{
	return m_MemoEventManager->getCurrentMemoId();
}

void BoraDoc::setCurrentMemoId(int nID, bool bUpdateFrameSet)
{
	m_MemoEventManager->setCurrentMemoId(nID, bUpdateFrameSet);
}

void BoraDoc::setOutlineModeAttr()
{
	if( -1 == m_OutlineLayout.m_nTextAtt)
	{
		PoTextAtt cOTextAtt;
		cOTextAtt.setHanFontID(m_FontArray->getFontID("Times New Roman"));
		m_OutlineLayout.m_nTextAtt = theBWordDoc->getTextAttHandler()->insertTextAtt(cOTextAtt);
		m_OutlineLayout.m_pParaAtt->setLineSpace(100);
	}
}
// ret : text box info exist
// nNum ->	 0 : don't care, n : col count
// nSpace -> -1 : don't care, n : space value
// nRTL ->   -1 : don't care, 0 : no rtl, 1 : rtl mode
BrBOOL BoraDoc::getTextBoxColumnInfo(BrINT &nNum, BrINT &nSpace, BrINT &nRTL)
{
#ifdef PPT_EDITOR_ERROR
	if (BR_CARET_OFF != m_Caret->getCaretStatus())
	{
		CFrame *pFrame = m_Caret->getLineFrame();
		if (FLOATFRAME != pFrame->GetClass())
			return BrFALSE;

		CFrameList *pFrameList = pFrame->getFrameList();
		if (!pFrameList)
			return BrFALSE;

		CFrameSet frameSet;
		if (pFrame->isMultiTextCol())
		{
			CFrame *pParentFrame = (CFrame *)pFrameList->getParent();
			if (pFrameList != (CFrameList *)pParentFrame)
			{
				if (FLOATFRAMECOLUMN == pParentFrame->GetClass())
					pFrame = pParentFrame;
			}
		}

		frameSet.insertAtTail(pFrame);

		return frameSet.getTextBoxColumnInfo(nNum, nSpace, nRTL);
	}
#endif //PPT_EDITOR_ERROR
	return m_FrameSet->getTextBoxColumnInfo(nNum, nSpace, nRTL);
}


void BoraDoc::SetHeaderType(BrBYTE header_type)
{
	m_bHeaderType = header_type;
	m_bFooterType = 0;
}


void BoraDoc::SetFooterType(BrBYTE footer_type)
{
	m_bHeaderType = 0;
	m_bFooterType = footer_type;
}


//[�̻�ȣ] Doc(NumArr)�� �׿�(BulletArray) �����ؼ� �����
CBullet * BoraDoc::getBulletExt( BrINT a_nBulletID )
{
	CBullet* pDocBullet = BrNULL;
	if( theBWordDoc->getDocType() == BORA_DOCTYPE_DOCX ) //docx�ΰ�츸 numArray ���µ�?
	{
		CBrNumArray* pNumArr = getNumArray();
		CBrNum* pNum = pNumArr->getNum(a_nBulletID);
		if(pNum)
			pDocBullet = pNum->getBullet();
	}
	else
	{
		CBulletArray *pDocBulletArray = getBulletArray();
		pDocBullet = pDocBulletArray->getBullet(a_nBulletID - 1);  //???????????????
	}

	return pDocBullet;
}
CBrNumArray* BoraDoc::getNumArray()	{
	return m_NumArray;
}

#ifdef DOCX_DOCUMENT_PROTECTION
BrBOOL BoraDoc::unlockDocumentProtection()
{
	if(m_pEditProtector )
	{
		BR_SAFE_DELETE(m_pEditProtector);
		return BrTRUE;
	}
	else
		return BrFALSE;
}

BrBYTE BoraDoc::getWordEditRestriction()
{
	if(!m_pEditProtector)
		return eWSTDocProtect_none;

	if(m_pEditProtector->getEnforcement() == 0)
		return eWSTDocProtect_none;

	return m_pEditProtector->getProtectionMode();
}

BrBOOL	BoraDoc::isLockTrackChanges()
{
	if(m_pEditProtector)
		return strcmp(m_pEditProtector->getEdit(), "trackedChanges")?BrFALSE:BrTRUE;
	else return BrFALSE;
}

BrBOOL	BoraDoc::setTrackChangeLockPassword(BrCHAR *szPasswd)
{
	BString strEditProtectPassword;
	strEditProtectPassword.setMultiByte(CP_ACP, szPasswd);

	if(BrNULL == m_pEditProtector)
		m_pEditProtector = BrNEW CDocxDocumentProtector();

	if(isLockTrackChanges())
		return m_pEditProtector->verify(strEditProtectPassword);
	else
		return m_pEditProtector->generateProtectionAttribute(eWSTDocProtect_trackedChanges, 0, strEditProtectPassword);
}
CDocxDocumentProtector *BoraDoc::getDocumentProtector()
{
	if(BrNULL == m_pEditProtector)
		m_pEditProtector = BrNEW CDocxDocumentProtector();

	return m_pEditProtector;
}
#endif //DOCX_DOCUMENT_PROTECTION
#ifdef SUPPORT_OOXML_PROTECTION
OOXMLWriteProtector *BoraDoc::getDocumentWriteProtector()
{
	if(BrNULL == m_pDocumentWriteProtector)
		m_pDocumentWriteProtector = BrNEW OOXMLWriteProtector();

	return m_pDocumentWriteProtector;
}

BrBOOL	BoraDoc::isWritePasswordVerified()
{
	OOXMLWriteProtector * pWriteProtector = getDocumentWriteProtector();

	if ( pWriteProtector ){
		if ( pWriteProtector->isVerified() )
			return BrTRUE;
	}

	return BrFALSE;
}
#endif


#ifdef SUPPORT_MOBILE_VIEW_MODE
// Mobile View Mode�� ���Ͽ� floating frame���� ��� anchor ��Ű�ų� �Ǵ� �ٽ� floating���� �����ϴ� method
void BoraDoc::anchorAllFloatingFrames(BrBOOL bAnchor)
{
	CFrameList *pFrameList = getAFrameList();
	CFrame *pFrame = pFrameList->getFirst();

	//CTextProc::resetAnchorPositionCache();

	// get all floating objects anchored
	if ( bAnchor )
	{
		while ( pFrame )
		{
			if ( !pFrame->isAnchored() )
			{
				pFrame->setOrgAnchorFlag(BrFALSE);
				if (pFrame->isHWPCaptionTextFrame()) //[CLT-1551] HWP Caption�� ����
				{
					pFrame = pFrameList->getNext(pFrame);
					continue;
				}

				pFrame->setAnchorFlag(BrTRUE);

				// ���� ���⼭ arrange �� �ʿ� ���� NPC-8283
				//if ( pFrame->isSpecial() )
				//{
				//	CTextProc::resetAnchorPositionCache(); // add 2011-2-1
				//	CTextProc::updateParentOfAnchor(this, pFrame);
				//}
			}
			else
			{
				pFrame->setOrgAnchorFlag(BrTRUE);
			}
			pFrame = pFrameList->getNext(pFrame);
		}
	}
	else
	{
		while ( pFrame )
		{
			if ( !pFrame->isOrgAnchored() )
			{
				pFrame->setAnchorFlag(BrFALSE);
			}
			pFrame = pFrameList->getNext(pFrame);
		}
	}
}



#endif // SUPPORT_MOBILE_VIEW_MODE


BrINT BoraDoc::getStyleIndex()
{
	BrINT32 nStyleIdx = -1;

	CCmdEngine *pCmdEngine = getCmdEngine();
	if (!pCmdEngine)		return nStyleIdx;

	CCaret *pCaret = getCaret();
	if (!pCaret)	return nStyleIdx;

	CTableEngine *pTableEngine = pCmdEngine->getTableEngine();
	CFrameSet *pFrameSet = pCmdEngine->getFrameSet();
	CElement *pElement = pFrameSet->getFirst();

	if ( pTableEngine && pTableEngine->isCellMarked()) //���� ���õ� ����
	{
		CLine *pFirstLine = BrNULL;
		CLine *pLastLine = BrNULL;

		CBCell* pCell  = BrNULL;
		CFrame* pCellFrame = BrNULL;

		CElement *pElement = BrNULL;
		CFrameSet *pFrameSet = BrNULL;
		//CBTable *pTable = pTableEngine->getTable();

		// if (pTable->isSplit())
		// 	pTableEngine->updateCellMarkingForActionTable();

		CObArray *pFrameSetArray = pTableEngine->getMarker()->getMarkingFrameSets();
		int i, nSize = pFrameSetArray->size();
		CLine *pFirstLineToPrevFrame = BrNULL;

		BrBOOL bMultiStyle = BrFALSE;
		BrINT32 nTmpStyleIdx = -2;
		for (i = 0; i < nSize; i++)
		{
			pFrameSet = (CFrameSet *)pFrameSetArray->GetAt(i);
			pElement = pFrameSet->getFirst();
			while (BrNULL != pElement)
			{
				pCellFrame = pElement->getFrame();
				if(pCellFrame)
					pCell = pCellFrame->getCell();
				else
					pCell  = BrNULL;

				if (pCell && pCell->getSplitType() <= SPLIT_START)
				{
					pFirstLine = CTableProc::getFirstLineOfCell(this, pCell);
					pLastLine = CTableProc::getLastLineOfCell(this, pCell);

					if ((BrNULL == pFirstLine) && (BrNULL == pLastLine))
						return -1;
					else if( pFirstLine && (BrNULL == pLastLine))
					{
						pLastLine  = pFirstLine;
					}

					//������ ��Ÿ�� ID
					nStyleIdx = pCmdEngine->getStyleTypeIDFromLine(pFirstLine, pLastLine, 0, pLastLine->getCharNum());
					if( (nTmpStyleIdx > -2) && (nStyleIdx != nTmpStyleIdx) )
					{
						bMultiStyle = BrTRUE;
						return -1;
					}

					nTmpStyleIdx = nStyleIdx;
				}
				pElement = pFrameSet->getNext(pElement);
			}
		}
	}
	else if (pCaret->isCaretNormal())
	{
		CLine *pLine = pCaret->getLine();
		if (pLine)
		{
			PoParaAttInterfaceHandler* paraAttInterfaceHandler = m_ParaAttHandler->getParaAttInterfaceHandler();
			if(paraAttInterfaceHandler && paraAttInterfaceHandler->getParaAttToGet().isSettedParaStyleID())
				nStyleIdx = paraAttInterfaceHandler->getParaAttToGet().getParaStyleID();

			PoTextAttInterfaceHandler* textAttInterfaceHandler = m_TextAttHandler->getInterfaceHandler();
			if(textAttInterfaceHandler && textAttInterfaceHandler->getTextAttToGet().isSettedStyleID())
			{
				BrINT textStyleID = textAttInterfaceHandler->getTextAttToGet().getStyleID();
				if(textStyleID > -1)
				{
					CStyleAttBase* pStyle = theBWordDoc->getStyleAttArray()->getAttr(textStyleID);
					if(pStyle && (nStyleIdx < 0 || !pStyle->getStyleName().contains("Normal")))
						nStyleIdx = textStyleID;
				}
			}
			/*
			//[ZPD-8043][2015-02-13][sangdon]:ĳ���� ���� ��� ��Ÿ�� ID ����
			//[ZPD-16525][2015-09-08]:ĳ���� ��ġ�� �� ���ڿ� ĳ���� ��Ÿ�� ID�� �ٸ� ���
			if ( (nStyleIdx < 0) || (nStyleIdx != pCaret->getTextAttr()->getStyleID()) )
			{
				//ĳ���� �ؽ�Ʈ �Ӽ��� StyleID ����
				pTextAtt = pCaret->getTextAttr();
				if (pTextAtt && pTextAtt->getStyleID() > -1)
					nStyleIdx = pTextAtt->getStyleID();
			}
			*/
		}
	}
	else if (pCaret->isCaretMarking())
	{
		nStyleIdx = pCmdEngine->getStyleTypeIDFromLine(pCaret->getSLine(), pCaret->getLine(), pCaret->getSCol(), pCaret->getCol());
	}
	else if( pFrameSet && pElement )
	{
		if (pElement)
		{
			CFrame * pFrame = pElement->getFrame();
			if ( pFrame )
			{
				if (pFrame->isTable() )	//���̺� ���õ� ����
				{
					CBTable *pTable = pFrame->getTable();
					if (BRNULL == pTable)
						return -1;

					BrBOOL bMultiStyle = BrFALSE;
					BrINT32 nTmpStyleIdx = -2;
					CLine *pFirstLineToPrevFrame = BrNULL;
					CLine *pFirstLine = BrNULL;
					CLine *pLastLine = BrNULL;

					CCellList *pCellList = pTable->getFirstCellList();
					while (pCellList)
					{
						CBCell *pCell = pCellList->getFirstCell();
						while(pCell)
						{
							if (pCell && pCell->getSplitType() <= SPLIT_START)
							{
								pFirstLine = CTableProc::getFirstLineOfCell(this, pCell);
								pLastLine = CTableProc::getLastLineOfCell(this, pCell);

								if ((BrNULL == pFirstLine) && (BrNULL == pLastLine))
									return -1;
								else if( pFirstLine && (BrNULL == pLastLine))
									pLastLine  = pFirstLine;

								//������ ��Ÿ�� ID
								nStyleIdx = pCmdEngine->getStyleTypeIDFromLine(pFirstLine, pLastLine, 0, pLastLine->getCharNum());
								if( (nTmpStyleIdx > -2) && (nStyleIdx != nTmpStyleIdx) )
								{
									bMultiStyle = BrTRUE;
									return -1;
								}

								nTmpStyleIdx = nStyleIdx;
							}
							pCell = pCell->getNext();
						}
						pCellList = pCellList->getNext(BrTRUE);
					}
				}
				else
				{
					CLine	*pTmpLine = BrNULL;
					while( pElement!=BrNULL )
					{
						pFrame = pElement->getFrame();
						if( pFrame!=BrNULL && pFrame->isText() )
						{
							if (!pCmdEngine->isCompareStyleForFrame(pFrame))
								return nStyleIdx;

							pTmpLine = pFrame->getFirstLine();
							break;

						}
						pElement = pFrameSet->getNext(pElement);
					}

					const PoParaAtt* pParaAtt = BrNULL;
					while(pTmpLine!=BrNULL)
					{
						BrINT nParaIdx = pTmpLine->getParaID();
						pParaAtt = m_ParaAttHandler->getParaAtt(nParaIdx);

						if ((nStyleIdx > -1) && (nStyleIdx != pParaAtt->getParaStyleID()))
							nStyleIdx = NO_SELECT_STYLE;	//������ ��Ÿ�� ����(�ܶ� ��Ÿ�� 2�� �̻�)

						nStyleIdx = pParaAtt->getParaStyleID();

						pTmpLine = pTmpLine->getNext();
					}
				}
			}
		}
	}

	return nStyleIdx;

}

static inline bool compareFrameYPos(const CFrame* szMid, const CFrame* szInput)
{
	return szMid->getFrameRect().nTop < szInput->getFrameRect().nTop;
}

BObArray<CFrame *> *BoraDoc::getPrevFloatingFrameInBaseFrame(CFrame *pCurFrame, CLine *pLine, BrWORD wCol, BrBOOL bNextBase, CByteArray &cPreFlagArray)
{
	if (!pCurFrame || !pLine)
		return BrNULL;

	CFrame *pBaseFrame = pLine->getFrame();
	if (!pBaseFrame)
		return BrNULL;

	FrameTypes eFrameType = pBaseFrame->GetClass();
	CPage *pPage = pBaseFrame->getPage();
	CFrameList *pFrameList, *pTmpFrameList;
	CFrame *pTmpFrame, *pNextFrame;

	if (bNextBase && (FIXFRAME == eFrameType || NOTEFRAME == eFrameType))
	{
		pFrameList = pBaseFrame->getFrameList();
		pNextFrame = pFrameList->getNext(pBaseFrame);
		if (pNextFrame)
		{
			if (pNextFrame->GetClass() == eFrameType)
				pBaseFrame = pNextFrame;
		}
		else
		{
			pPage = pPage->getPageArray()->getPage(pPage->getPageNum() + 1);
			if (pPage)
			{
				pNextFrame = BrNULL;
				if (FIXFRAME == eFrameType)
				{
					pFrameList = pPage->getBFrameList();
					pNextFrame = pFrameList->getFirst();
				}
				else // Note
				{
					pTmpFrame = pPage->getFirstNoteFrame();
					if (pTmpFrame)
					{
						pFrameList = pTmpFrame->getFrameList();
						pTmpFrame = pFrameList->getFirst();;
						while (pTmpFrame)
						{
							if (pTmpFrame->isNote())
							{
								pNextFrame = pTmpFrame;
								break;
							}

							pTmpFrame = pFrameList->getNext(pTmpFrame);
						}
					}
				}

				if (pNextFrame)
					pBaseFrame = pNextFrame;
			}
		}
	}

	pFrameList = pCurFrame->getFrameList();
	if (!pFrameList)
		return BrNULL;

	BrBOOL bInsert;
	BrINT i, nID, nFrameIDIndex, nFrameIDCnt, nSize = 0;
	BRect rcFrameArea, *pRect, *pBaseRect = pBaseFrame->getFrameRect();
	CPage *pTmpPage;
	CCharSet *pCharSet;
	CCharSetArray *pCharSetArray;
	CLine *pALine, *pTmpLine, *pPrev = pLine->getPrevInFrame();
	CFrame *pPrevFrame, *pFrame, *pTmpBaseFrame;
	BObArray<CFrame*> *pFloatingFrameArray = BrNEW BObArray<CFrame*>;
	BObArray<CFrame*>::iterator it = pFloatingFrameArray->end();

	pPage = pBaseFrame->getPage();
	nFrameIDCnt = pPage->getFrameIDCnt();

	// ZPD-27043, ZPD-26557, ZPD-23537, IAC-2764
	for (nFrameIDIndex = 0; nFrameIDIndex < nFrameIDCnt; nFrameIDIndex++)
	{
		pFrame = pFrameList->getTopLevelFrame(pPage->getFrameID(nFrameIDIndex));
		if (pFrame && pCurFrame != pFrame && !pFrame->isAnchored() && pFrame->getRAType() != NO_RUN_AROUND && pFrame->getPage() == pPage) // frame page Ȯ�� �ʿ� XPD-7001
		{
			pTmpBaseFrame  = pFrame->getBaseFrame();
			if (!IsValidObject(pTmpBaseFrame) || (pTmpBaseFrame->GetClass() != eFrameType) ||
				((CELLFRAME == eFrameType || FLOATFRAME == eFrameType) && pBaseFrame != pTmpBaseFrame)) // WPD-3892
				continue;

			pALine = pFrame->getAnchorLine();
			pRect = pFrame->getFrameRect();
			if (pBaseRect->IsIntersect(pRect))
			{
				if (!pALine)
				{
					if (pFrame->isTable())
					{
						CBTable *pTable = pFrame->getTable()->getFirstTable();
						if (!pTable)
							continue;

						pPrevFrame = pTable->getFrame();
						if (!pPrevFrame)
							continue;

						pTmpLine = pPrevFrame->getAnchorLine();
						if (!pTmpLine || pTmpLine->isDirty())
							continue;
					}

					it = std::upper_bound(pFloatingFrameArray->begin(), pFloatingFrameArray->end(), pFrame, compareFrameYPos);
					auto index = std::distance(pFloatingFrameArray->begin(), it);
					if (index >= 0 && index <= pFloatingFrameArray->size())
					{
						pFloatingFrameArray->InsertAt_(index, pFrame);
						cPreFlagArray.InsertAt(index, 1);
					}
					//pFloatingFrameArray->Add(pFrame);
					//cPreFlagArray.Add(1);
				}
				else
				{
					bInsert = BrFALSE;
					if (pALine == pLine && pFrame->getAnchorCol() < wCol)
					{
						pCharSetArray = pLine->getCharSetArray();
						i = wCol - 1;
						nID = pFrame->getID();
						pCharSet = pCharSetArray->getCharSet(i);

						if (pCharSet)
						{
							for (i; i >= 0; i--)
							{
								if (pCharSet->isAnchorLink() && pCharSet->getCode() == (BrWORD)nID)
								{
									it = std::upper_bound(pFloatingFrameArray->begin(), pFloatingFrameArray->end(), pFrame, compareFrameYPos);
									auto index = std::distance(pFloatingFrameArray->begin(), it);
									if (index >= 0 && index <= pFloatingFrameArray->size())
									{
										pFloatingFrameArray->InsertAt_(index, pFrame);
										cPreFlagArray.InsertAt(index, 1);
									}
									//pFloatingFrameArray->Add(pFrame);
									//cPreFlagArray.Add(1);
									bInsert = BrTRUE;
									break;
								}

								pCharSet--;
							}
						}
					}

					if (!bInsert  && IsValidObject(pALine))
					{
						pTmpFrame = pALine->getFrame();
						if (pTmpFrame == pBaseFrame)
						{
							pTmpLine = pPrev;
							while (pTmpLine)
							{
								if (pTmpLine == pALine)
								{
									it = std::upper_bound(pFloatingFrameArray->begin(), pFloatingFrameArray->end(), pFrame, compareFrameYPos);
									auto index = std::distance(pFloatingFrameArray->begin(), it);
									if (index >= 0 && index <= pFloatingFrameArray->size())
									{
										pFloatingFrameArray->InsertAt_(index, pFrame);
										cPreFlagArray.InsertAt(index, 1);
									}
									//pFloatingFrameArray->Add(pFrame);
									//cPreFlagArray.Add(1);
									bInsert = BrTRUE;
									break;
								}

								pTmpLine = pTmpLine->getPrevInFrame();
							}

							if (!bInsert) // ZPD-26557
							{
								BrBYTE bVerticalRelative = pFrame->getVerticalRelative();
								BrBYTE bHorizontalRelative = pFrame->getHorizontalRelative();

								if (RT_PARAGRAPH != bVerticalRelative || RT_PARAGRAPH != bHorizontalRelative) // �켱 Page���� ó��
								{
									BrBYTE	bAlignment;
									BrINT nTop, nLeft, nDistance;

									pFrame->getFrameArea(&rcFrameArea);
									nTop = rcFrameArea.nTop;
									nLeft = rcFrameArea.nLeft;

									if (RT_PARAGRAPH != bVerticalRelative)
									{
										nDistance = (BrINT)(pFrame->getVerticalDistance() * 14400.0f / 254.0f + 0.5f);
										switch (bVerticalRelative)
										{
										case RT_PAGE:
											bAlignment = pFrame->getVerticalAlignment();
											switch(bAlignment)
											{
											case ALG_TOP:		nTop = nDistance;	break;
											case ALG_CENTER:	nTop = (pPage->height() - rcFrameArea.getHeight()) / 2 + nDistance; break;
											case ALG_BOTTOM:	nTop = pPage->height() - rcFrameArea.getHeight() - nDistance; break;
											}
										}
									}

									if (RT_PARAGRAPH != bHorizontalRelative)
									{
										nDistance = (BrINT)(pFrame->getHorizontalDistance() * 14400.0f / 254.0f + 0.5f);
										switch (bHorizontalRelative)
										{
										case RT_PAGE:
											bAlignment = pFrame->getHorizontalAlignment();
											switch(bAlignment)
											{
											case ALG_LEFT:
											case ALG_INSIDE:	nLeft = nDistance;	break;
											case ALG_CENTER:	nLeft = (pPage->width() - rcFrameArea.getWidth()) / 2 + nDistance; break;
											case ALG_RIGHT:
											case ALG_OUTSIDE:	nLeft = pPage->width() - rcFrameArea.getWidth() - nDistance; break;
											}
										}
									}

									if (nTop != rcFrameArea.nTop || nLeft != rcFrameArea.nLeft)
										CTextProc::moveFrame(this, pPage, pFrame, nLeft - rcFrameArea.nLeft, nTop - rcFrameArea.nTop, BrFALSE);
								}
							}
						}
						else if (IsValidObject(pTmpFrame))	//[ZPD-21389] Anchor Frame ���� ���� ��, Crash
						{
							pTmpPage = pTmpFrame->getPage();
							if (IsValidObject(pTmpPage))
							{
								if (pTmpPage->getPageNum() < pPage->getPageNum())
									bInsert = BrTRUE;
								else if (pTmpPage == pPage)
								{
									if (pBaseFrame->isCell())
									{
										if (pTmpBaseFrame == pBaseFrame)
											bInsert = BrTRUE;
									}
									else
									{
										pTmpFrameList = pBaseFrame->getFrameList();
										if (pTmpFrameList)
										{
											pPrevFrame = pTmpFrameList->getPrev(pBaseFrame);
											while (pPrevFrame)
											{
												if (pTmpFrame == pPrevFrame)
												{
													bInsert = BrTRUE;
													break;
												}

												pPrevFrame = pTmpFrameList->getPrev(pPrevFrame);
											}
										}
									}
								}

								if (bInsert)
								{
									it = std::upper_bound(pFloatingFrameArray->begin(), pFloatingFrameArray->end(), pFrame, compareFrameYPos);
									auto index = std::distance(pFloatingFrameArray->begin(), it);
									if (index >= 0 && index <= pFloatingFrameArray->size())
									{
										pFloatingFrameArray->InsertAt_(index, pFrame);
										cPreFlagArray.InsertAt(index, 1);
									}
									//pFloatingFrameArray->Add(pFrame);
									//cPreFlagArray.Add(1);
								}
							}
						}
					}

					if (!bInsert && pFrame->getVerticalRelative() != RT_PARAGRAPH)
					{
						pFrame->getFrameArea(&rcFrameArea);
						if (rcFrameArea.getHeight() < pBaseRect->getHeight()) // ZPD-32657 ���� base���� move ���� check
						{
							it = std::upper_bound(pFloatingFrameArray->begin(), pFloatingFrameArray->end(), pFrame, compareFrameYPos);
							auto index = std::distance(pFloatingFrameArray->begin(), it);
							if (index >= 0 && index <= pFloatingFrameArray->size())
							{
								pFloatingFrameArray->InsertAt_(index, pFrame);
								cPreFlagArray.InsertAt(index, 0);
							}
							//pFloatingFrameArray->Add(pFrame);
							//cPreFlagArray.Add(0);
						}
					}
				}
			}
		}
	}

	if (0 == pFloatingFrameArray->size())
	{
		BrDELETE pFloatingFrameArray;
		return BrNULL;
	}

	return pFloatingFrameArray;
}

void BoraDoc::resetMemoFrameListPosition(CPage* pPage)
{
	m_MemoEventManager->resetMemoFrameListPosition(pPage);
}

BrBOOL BoraDoc::isExportWordMemo(EBrDCType sDCType)
{
	return m_MemoEventManager->isExportWordMemo(sDCType);
}

#ifdef USE_COLLABORATION
CMakeCollborationJSon* BoraDoc::getMakeCollaborationJson()
{
	CMakeCollborationJSon* pMakeCollaborationJson = BrNULL;

	if(BrGetCollaborationMode() == BR_COLLABORATION_COLLABORATION_MODE)
	{
		CollaborationProvider* pProvider = g_pCollaborationProvider;
		BWPCommonCollaborationManager* pCLBManager = BrNULL;

		if(pProvider!=BrNULL)
		{
			pCLBManager = (BWPCommonCollaborationManager*)pProvider->getCollaborationManager();
			if(pCLBManager!=BrNULL)
			{
				pMakeCollaborationJson = pCLBManager->getMakeCollborationJSon();
			}
		}

	}

	 return pMakeCollaborationJson;
}
#endif //USE_COLLABORATION

BrINT BoraDoc::getMaxUniqueID()
{
	if (getBWPEngineMode() != EDITOR_WORD)
		return 0;

	BrINT nMaxSpid = 0;

	CFrameList *pAFrameList = getAFrameList();
	if (pAFrameList!=BrNULL)
		nMaxSpid = BrMAX(nMaxSpid, pAFrameList->getMaxUniqueID());

	CFrameList *pHFFrameList = getAFrameList4HeaderFooter();
	if(pHFFrameList != BrNULL)
		nMaxSpid = BrMAX(nMaxSpid, pHFFrameList->getMaxUniqueID());

	return nMaxSpid;
}

void BoraDoc::intSpidGenerator(BrINT a_nDocType)
{
	if(m_pSpidGenerator == BrNULL)
	{
		switch(a_nDocType)
		{
		case BORA_DOCTYPE_DOCX:
			m_pSpidGenerator = BrNEW CSPIDGeneratorDocx();
			break;
		case BORA_DOCTYPE_DOC:
			//pInstance = BrNEW CSPIDGeneratorDoc();
			break;
		case BORA_DOCTYPE_PPT:
		case BORA_DOCTYPE_PPTX:
			m_pSpidGenerator = BrNEW CSPIDGeneratorPptx();
			break;
		case BORA_DOCTYPE_HWP:
			m_pSpidGenerator = BrNEW CSPIDGeneratorHwp();
			break;
		default:
			break;
		}
	}
}

ISPIDGeneratorBase* BoraDoc::getSpidGenerator() {
	return m_pSpidGenerator;
}

#ifdef SUPPORT_MAIL_MERGE
CMailMerge& BoraDoc::getMailMerge() {
	return *m_MailMerge;
}
#endif
CMailMergeDoc& BoraDoc::getMailMergeDoc() {
	return *m_MailMergeDoc;
}

BrBYTE BoraDoc::getNoteDrawMode(CPage *pPage)
{
	if(m_nBWPEngineMode != EDITOR_PPT)
		return BrFALSE;

	BrBYTE bRet = 0;
	BrBOOL bPPTX =  (m_nDocType	== BORA_DOCTYPE_PPTX) ? BrTRUE : BrFALSE;
	BrINT nPgEditModeType = DocFlagEx2.flag.m_EditMasterType;

	if(g_pAppStatic->isPrtPreview() &&  g_BoraThreadAtom.m_nPPTHandoutType == 11)
		return 1;//�μ� ��� - �����̵� ��Ʈ

	if(bPPTX && nPgEditModeType ==  EDIT_SLIDE_NOTE && !m_bThumbnailDraw && !g_pAppStatic->isPrtPreview())
		return 1;//��Ʈ ��� //misty - 2016.10.28 - pptx �� ����.

	//��Ʈ ������ ���
	return bRet;
}

BrBOOL BoraDoc::changeSlideEditMode(BrBYTE bEditChgType,BrBOOL bChgPrevMode/*BrFALSE*/)
{/*bChgPrevMode : BrTRUE : UndoEngine*/
	if(m_nDocType != BORA_DOCTYPE_PPTX)
		return BrFALSE;

	BRCONTEXT
	Painter* pPainter = gpPaint;
	//backup var
	LPSLIDENOTEHANDOUT_SCREENINFO pBwpBackupScrInfo = &m_SlideNoteHandout_ScreenInfo;
	//setting var
	CPage *pEditWantPg = BrNULL;
	BrINT nBackupScreenBeforePgNum = -1,nWantPgNum = 0;
	BrBOOL bChgZoom = (DocFlagEx2.flag.m_EditMasterType != bEditChgType) ? BrTRUE : BrFALSE;//pBwpBackupScrInfo->nZoomScale == 0 );
	BrBOOL bFirst = (pBwpBackupScrInfo->nZoomScale == 0 );

	BrINT nSetScrOffsetDx = 0, nSetScrOffsetDy = 0;
	BrINT nSetScrOrgDx = 0, nSetScrOrgDy = 0;
	BrINT nSetCurPgNum = 0, nSetZoomScale = 0, nSetZoomMode = SETZOOM_WHOLEPAGE;
	BrINT nSetEditType = EDIT_MASTER_NONE ,nSetScrPgMode = SCREENPAGEMODE_BASIC;
	BrINT nSetPtViewX = 0, nSetPtViewY = 0;
	CPageArray *pSetPageArray = BrNULL;
	SlideViewType eSetSlideLastViewType = enNoneView;

//1step. Mgr / Drawing config Data <Backup>!!
	//BTrace("CurEditViewType [%d] ChgEditViewType[%d] ",DocFlagEx2.flag.m_EditMasterType,bEditChgType);
//2step. New Set Data ���
	if(!bChgPrevMode)
	{//none -> notemst
		//Not NoteMstMode-> NoteMode case
		int nOldZoomScale = pBwpBackupScrInfo->nZoomScale;
		int nOldOffsetPtX = pBwpBackupScrInfo->nOffsetPtX, nOldOffsetPtY =  pBwpBackupScrInfo->nOffsetPtY;
		int nOldScrOffsetDx = pBwpBackupScrInfo->nScrOffsetDx, nOldScrOffsetDy = pBwpBackupScrInfo->nScrOffsetDy;
		int nOldScrOrgDx = pBwpBackupScrInfo->nScrOrgDx, nOldScrOrgDy = pBwpBackupScrInfo->nScrOrgDy;

		//Not NoteMstMode-> NoteMode case
		//���� ���� backup
		pBwpBackupScrInfo->nEditContinueMode = (pPainter->m_bEditContinueMode == BrTRUE ? 1:0);
		pBwpBackupScrInfo->nMinZoom = Brcontext.m_ViewerConfig.nMinZoom;
		pBwpBackupScrInfo->nZoomScale = pPainter->getZoomScale();
		pBwpBackupScrInfo->nOffsetPtX = pPainter->offset.m_ptView.x;
		pBwpBackupScrInfo->nOffsetPtY =  pPainter->offset.m_ptView.y;
		m_MasterScreenBeforePageNum = pBwpBackupScrInfo->nCurPage;
		pBwpBackupScrInfo->nCurPage = pPainter->doc.m_nCurPage;

		pBwpBackupScrInfo->nScreenPageMode = m_CmdEngine->getScreenPageMode();
		pBwpBackupScrInfo->nEditMasterType = DocFlagEx2.flag.m_EditMasterType;

		pBwpBackupScrInfo->nScrOffsetDx = m_CmdEngine->getScrOffsetDx();
		pBwpBackupScrInfo->nScrOffsetDy = m_CmdEngine->getScrOffsetDy();
		pBwpBackupScrInfo->nScrOrgDx = m_CmdEngine->getScrOrgDx();
		pBwpBackupScrInfo->nScrOrgDy = m_CmdEngine->getScrOrgDy();


		if(bChgZoom)
		{
			nSetZoomMode = SETZOOM_WHOLEPAGE;
// 			BrINT nFitWidthZoom =  0;//GetPageZoomScale_BWP(pPainter, SETZOOM_WHOLEPAGE);
// 			if (nFitWidthZoom < Brcontext.m_ViewerConfig.nMinZoom)
// 				Brcontext.m_ViewerConfig.nMinZoom = nFitWidthZoom;
			//HandsPointer_setZoom_Painter_BWP_I(pPainter, nFitWidthZoom);
		}
		else
		{
			nSetZoomScale = nOldZoomScale;//	HandsPointer_setZoom_Painter_BWP_I(pPainter, nOldZoomScale );
		}
		//new ����

		nSetEditType = bEditChgType;

		nSetPtViewX = (bFirst ? 0 : nOldOffsetPtX);
		nSetPtViewY = (bFirst ? 0 : nOldOffsetPtY);
		nSetScrOffsetDx = (bFirst ? 0 : nOldScrOffsetDx);
		nSetScrOffsetDy = (bFirst ? 0 : nOldScrOffsetDy);
		nSetScrOrgDx = (bFirst ? 0 : nOldScrOrgDx);
		nSetScrOrgDy = (bFirst ? 0 : nOldScrOrgDy);
		nSetScrPgMode = SCREENPAGEMODE_BASIC;
		//nSetScrPage = (pPainter->doc.m_nCurPage, pPainter->doc.m_nCurPage);
		nSetCurPgNum = 1;

		switch(bEditChgType)
		{
		case EDIT_MASTER_NOTE://Note Mst Mode
			eSetSlideLastViewType = enNotesMasterView;
			pSetPageArray = m_PPTNoteMaster->GetNoteMasterPageArray();
			break;
		case EDIT_SLIDE_NOTE://Note Mode
			eSetSlideLastViewType = enNotesView;
			pSetPageArray = m_PageArray;
			if(DocFlagEx2.flag.m_EditMasterType == EDIT_MASTER_NOTE)
				nSetCurPgNum = m_MasterScreenBeforePageNum;
			else
				nSetCurPgNum = pPainter->doc.m_nCurPage;
			break;
		case EDIT_MASTER_SLIDE://Master Mode	 noteMasterEditMode -> clk ��
			{
				eSetSlideLastViewType = enSlideMasterView;
				if(m_MasterLayoutArray.size())
					pSetPageArray = m_MasterLayoutArray.at(0);
			}
			break;

		case EDIT_MASTER_NONE:
		default://finish
			{
				eSetSlideLastViewType = enSlideView;
				pSetPageArray = m_PageArray;
				if(DocFlagEx2.flag.m_EditMasterType == EDIT_SLIDE_NOTE)
					nSetCurPgNum =  pPainter->doc.m_nCurPage;
				else
					nSetCurPgNum = m_MasterScreenBeforePageNum;
				//pSetPageArray = getEditingPageArray();
			}
			break;
		}
	}
	else
	{
		//NoteMstMode-> Not  NoteMode case
//���� ���� backup(new ������ data)
		int nCurZoomScale = pPainter->getZoomScale();
		int nCurOffsetPtX = pPainter->offset.m_ptView.x, nCurOffsetPtY =  pPainter->offset.m_ptView.y;
		int nCurScrOffsetDx = m_CmdEngine->getScrOffsetDx(), nCurScrOffsetDy =  m_CmdEngine->getScrOffsetDy();
		int nCurScrOrgDx =  m_CmdEngine->getScrOrgDx(),nCurScrOrgDy =  m_CmdEngine->getScrOrgDy();


		//init engine
		//���� backup ���� backup
		nSetScrPgMode = pBwpBackupScrInfo->nScreenPageMode;
		nSetEditType = pBwpBackupScrInfo->nEditMasterType ;
		nSetZoomScale = pBwpBackupScrInfo->nZoomScale;
		nSetCurPgNum = pBwpBackupScrInfo->nCurPage;
		/*
		Mst Mode �� ���� �� ,,���� cur page �� layout page
		�Ϲ� Mode �� ���� �� ,, ���� cur page?
		*/
		//nSetCurPgNum = m_MasterScreenBeforePageNum;

		nSetPtViewX = pBwpBackupScrInfo->nOffsetPtX;
		nSetPtViewY = pBwpBackupScrInfo->nOffsetPtY;
		nSetScrOffsetDx = pBwpBackupScrInfo->nScrOffsetDx;
		nSetScrOffsetDy = pBwpBackupScrInfo->nScrOffsetDy;
		nSetScrOrgDx = pBwpBackupScrInfo->nScrOrgDx;
		nSetScrOrgDy = pBwpBackupScrInfo->nScrOrgDy;
		nSetScrPgMode = SCREENPAGEMODE_BASIC;

		nSetCurPgNum = pBwpBackupScrInfo->nCurPage;
//		m_MasterScreenBeforePageNum = pPainter->doc.m_nCurPage;

		switch(nSetEditType)
		{
		case EDIT_MASTER_NOTE://Note Mst Mode
			pSetPageArray = m_PPTNoteMaster->GetNoteMasterPageArray();
			break;
		case EDIT_SLIDE_NOTE://Note Mode
			pSetPageArray = m_PageArray;
			break;
#if 0
		case EDIT_MASTER_SLIDE://Master Mode
			pSetPageArray = getEditingPageArray();
			break;
		case EDIT_MASTER_NONE:
			pSetPageArray = getEditingPageArray();
#endif
		default://finish
			pSetPageArray = m_PageArray;
			break;
		}

		pBwpBackupScrInfo->nOffsetPtX = nCurOffsetPtX;
		pBwpBackupScrInfo->nOffsetPtY =  nCurOffsetPtY;
		pBwpBackupScrInfo->nScrOffsetDx =  nCurScrOffsetDx;
		pBwpBackupScrInfo->nScrOffsetDy =  nCurScrOffsetDy;
		pBwpBackupScrInfo->nScrOrgDx =  nCurScrOrgDx;
		pBwpBackupScrInfo->nScrOrgDy =  nCurScrOrgDy;
		pBwpBackupScrInfo->nZoomScale =  nCurZoomScale;
	}

	if(!pSetPageArray)
		return BrFALSE;
//3step. Engine Edit Mgr config Data !!<Init>!!
	//3-1. interface engine data init
	pPainter->offset.m_ptView.x = 0;
	pPainter->offset.m_ptView.y = 0;
	pPainter->doc.m_nCurPage = 1;
	pPainter->doc.m_pDoc->m_DocProperty.m_nCurPage = 1;
	pPainter->m_bEditContinueMode = BrFALSE;

	//3-2.bwp engine data init
	DocFlagEx2.flag.m_EditMasterType = EDIT_MASTER_NONE;

	m_CmdEngine->getFrameSet()->removeAll();
	m_CmdEngine->getMouse()->init();
	m_CmdEngine->getPrevMouse()->init();
	m_CmdEngine->setArrowMode();//XPD-6678
	m_CmdEngine->setCurOperation(ACTNONE);
	BModeChange(ARROW, TEXTEDIT, m_nPenMode, (BrINT)ACTNONE);

	m_CmdEngine->setScreenPageMode(SCREENPAGEMODE_BASIC);


	m_CmdEngine->setScrOffsetDx(0);
	m_CmdEngine->setScrOffsetDy(0);
	m_CmdEngine->setScrOrgDx(0);
	m_CmdEngine->setScrOrgDy(0);

	m_Caret->setCaretStatus( BR_CARET_OFF );
	m_Caret->hide();

	InvalidateRect(BrNULL);

//4step. New ���� (bPrev true : ���� backup ����,  false new edit mode ����)

	//HandsPointer_setZoom_Painter_BWP_I(pPainter, nSetZoomScale );
	pPainter->doc.m_nCurPage = nSetCurPgNum;
	pPainter->doc.m_pDoc->m_DocProperty.m_nCurPage = nSetCurPgNum;
	if (nSetCurPgNum <= 0)//default
		nSetCurPgNum = 1;

	DocFlagEx2.flag.m_EditMasterType = nSetEditType;
	m_enSlideLastViewType = eSetSlideLastViewType;
	m_CmdEngine->setScreenPageMode( nSetScrPgMode);

	m_PPTNoteMaster->ChangeZoomInfo(gpPaint,nSetZoomScale,nSetZoomMode);
	m_CmdEngine->setWorkOrgCoord(pSetPageArray,1);
	m_CmdEngine->setDocEndCoord();
	m_CmdEngine->setScrPage(nSetCurPgNum, nSetCurPgNum);
	m_CmdEngine->setCurPageNum(nSetCurPgNum);
#if 1//misty -0 11.30
	m_CmdEngine->setCenteringDoc(&pPainter->offset.m_ptView);
	m_CmdEngine->setScrOffset(pPainter->offset.m_ptView.x,pPainter->offset.m_ptView.y);
#else
	pPainter->offset.m_ptView.x = nSetPtViewX;
	pPainter->offset.m_ptView.y = nSetPtViewY;
	m_CmdEngine->setScrOffsetDx(nSetScrOffsetDx);
	m_CmdEngine->setScrOffsetDy(nSetScrOffsetDy);
	m_CmdEngine->setScrOrgDx(nSetScrOrgDx);
	m_CmdEngine->setScrOrgDy(nSetScrOrgDy);
#endif

	BInterfaceHandle * pHandle = g_pBInterfaceHandle;
	if(!pHandle)
		return 0;

	if(pHandle)
	{
		UIPROCESS_CB pCallback= pHandle->m_pUIPROCESS_CBFUNC;
		if(pCallback)
		{
			SlideViewType eEditViewType =  enNoneView;
			switch(DocFlagEx2.flag.m_EditMasterType)
			{
			case EDIT_MASTER_SLIDE:
				eEditViewType = enSlideMasterView;
				break;
			case EDIT_MASTER_HANDOUT:
				eEditViewType = enHandoutMasterView;
				break;
			case EDIT_MASTER_NOTE:
				eEditViewType = enNotesMasterView;
				break;
			case EDIT_SLIDE_NOTE:
				eEditViewType = enNotesView;
				break;
			default:
					eEditViewType = enSlideView;
					break;
			}
			SendBaseResultCallback(0, Bora_ppt_slideEditViewType ,0,pCallback,&eEditViewType);
		}
	}

	return BrTRUE;
}

BrBOOL BoraDoc::getEnableCentering()
{
	BrBOOL bCentering = BrTRUE;
	CPage *pPage = getEditingPage(getPainter()->doc.m_nCurPage);
#ifndef NOT_SUPPORT_SCROLL_CNETERING_PPT
	if(pPage && theBWordDoc->getBWPEngineMode() == EDITOR_PPT && !m_CmdEngine->isContinuePage())
	{
		//POD-3332
//		BrBYTE bPgType = pPage->getPageType();
//		if(bPgType == NOTE_PAGE || bPgType == NOTEMASTER_PAGE || getNoteDrawMode(pPage))
//			return BrTRUE;//��Ʈ & ��Ʈ������ ������ centering ���� �߻� �� Misty ���� �ּ���.
//#ifdef SUPPORT_NOTEMASTER_EDIT
//		if(bPgType == NOTE_PAGE || bPgType == NOTEMASTER_PAGE || getNoteDrawMode(pPage))
//			return BrTRUE;//��Ʈ & ��Ʈ������ ������ centering ���� �߻� �� Misty ���� �ּ���.
//#endif
		CFrameList* pFrameList = pPage->getAnchorFrameList();
		if(pFrameList)
		{
			BRect rPageFrameRect;
			BRect rcPage;
			rcPage.setRect(0, 0, pPage->width(), pPage->height());
			//getCmdEngine()->page2Logical(pPage, rcPage);
			pFrameList->getFrameListRectForPPTScroll(rPageFrameRect, BrTRUE); //POD-3332
			//getCmdEngine()->page2Logical(pPage, rPageFrameRect);
			if(!(rcPage.IsInside(&rPageFrameRect)) && (getPainter()->m_bDrawFirst == BrFALSE))
				bCentering = BrFALSE;
		}
	}
#endif // NOT_SUPPORT_SCROLL_CNETERING_PPT
	return bCentering;
}

CFrame* BoraDoc::makeShpaeEffectThumbnailFrame(byte bClass)
{
	CPage *pPage = m_PageArray->getPage(1); // AOM-36981, WPD-1710
	if(bClass == GROUPFRAME)
	{
		if(!m_ShapeGroupThumbnailFrame)
			m_ShapeGroupThumbnailFrame = createFrame(bClass);

		m_ShapeGroupThumbnailFrame->setPage(pPage);
		return m_ShapeGroupThumbnailFrame;
	}
	else
	{
		if(!m_ShapeThumbnailFrame)
			m_ShapeThumbnailFrame = createFrame(bClass);

		m_ShapeThumbnailFrame->setPage(pPage);
		return m_ShapeThumbnailFrame;
	}
}
#ifdef SUPPORT_SHOW_HWP_TYPESET
BrBOOL BoraDoc::isShowHWPTypeSetMode()
{
	if ( isFromHwp() && getCmdEngine()->getEditSymbolShowState().bHWPTypeSet )
		return BrTRUE;
	else
		return BrFALSE;
}
BrBOOL BoraDoc::isShowHWPTypeSetModeEx()
{
	return isFromHwp() && isShowTypeSetMode();
}

BrBOOL BoraDoc::isShowTypeSetMode()
{
	return getCmdEngine()->getEditSymbolShowState().bHWPTypeSet && !isThumbnailDraw() && !g_pAppStatic->isPrtPreview() && !getEditProtect() && !getViewTogetherMode() && !isExportMode();
}

BrBOOL BoraDoc::isShowODTTypeSetMode() {
	return isFromOdt() && isShowTypeSetMode();
}
#endif //SUPPORT_SHOW_HWP_TYPESET

#ifdef USE_PDFEXPORT_TEXTBOX
int compare(const void* a, const void* b)
{
	return (*(int*)a - *(int*)b);
}

void BoraDoc::setExportPDFAnnotList(BrINT nCount, BrINT* pPDFAnnotIDArray)
{
	BR_SAFE_FREE(m_pExportPDFAnnotList);

	m_nExportPDFAnnotCount = nCount;
	m_pExportPDFAnnotList = pPDFAnnotIDArray;

	qsort(m_pExportPDFAnnotList, m_nExportPDFAnnotCount, sizeof(int), compare);

	return;
}

BrBOOL BoraDoc::isExportPDFAnnot(BrINT shapeID)
{
	BrBOOL ret = BrFALSE;
	
	if(m_pExportPDFAnnotList)
		ret = bsearch(&shapeID, m_pExportPDFAnnotList, m_nExportPDFAnnotCount, sizeof(int), compare) != BrNULL;

	return ret;
}
#endif // USE_PDFEXPORT_TEXTBOX

CLine *BoraDoc::getFirstFootNoteLine()
{
	CPage *pPage = getPageArray()->GetFirst();

	while(pPage)
	{
		CFrameList *pTFrameList = pPage->getTFrameList();
		if(pTFrameList)
		{
			CFrame *pFFrame = pTFrameList->getFirst();
			while(pFFrame)
			{
				if(pFFrame->getFirstLine())
					return pFFrame->getFirstLine();

				pFFrame = pTFrameList->getNext(pFFrame);
			}
		}

		pPage = pPage->getNext();
	}

	return BrNULL;
}
CLine *BoraDoc::getFirstEndNoteLine()
{
	CLine *pLine = getLastLine();
	CLine *pPrev = BrNULL;

	if(pLine && pLine->getNoteLineNum() < 1)
		return BrNULL;

	while(pLine)
	{
		pPrev = pLine->getPrev();

		if(pPrev && pPrev->getNoteLineNum() < 1)
			return pLine;

		pLine = pPrev;
	}

	return BrNULL;
}

const PoParaAtt* BoraDoc::getDefaultParaAtt()
{
	return m_ParaAttHandler->getDefaultAttr();
}
BrGrapAttDefault* BoraDoc::getDefaultGrapAtt() {
	return m_GrapAtt;
}

PoTextAtt* BoraDoc::getDefaultTextAtt() {
	return m_TextAttHandler->getDefaultAttr();
}
BrINT BoraDoc::getDefaultParaAttID() {
	return m_ParaAttHandler->getDefaultAttrID();
}
BrWORD BoraDoc::getDefaultTextAttID() {
	return m_TextAttHandler->getDefaultAttrID();
}
void BoraDoc::setDefaultTextAtt(PoTextAtt &rTA) {
	m_TextAttHandler->setDefaultAttr(rTA);
}

BrWORD BoraDoc::GetTextAttrID( PoTextAtt& textAtt ) {
	return m_TextAttHandler->insertTextAtt( textAtt );
}; //���� ���� ���Ǿ doc ����Լ��� ����.
BrWORD BoraDoc::GetTextAttrID( PoTextAtt& textAtt, BrWORD wHighSurrogate )
{
	if(wHighSurrogate != 0 || textAtt.isSettedHighSurrogate())
	{
		PoTextAtt newTextAtt(textAtt);
		newTextAtt.setHighSurrogate(wHighSurrogate);
		return m_TextAttHandler->insertTextAtt(newTextAtt);
	}
	return m_TextAttHandler->insertTextAtt(textAtt);
}; //���� ���� ���Ǿ doc ����Լ��� ����.
const PoTextAtt* BoraDoc::GetTextAttr( BrWORD id ) {
	return m_TextAttHandler->getTextAtt(id);
}; // ������� null return��

BrBOOL	BoraDoc::isEditProtect()
{
	BrBOOL bRet = BrFALSE;
	if(getEditProtect())
		bRet = BrTRUE;

	if( g_pAppStatic->m_bViewerEditMemo )
	{
		CCaret *pCaret = getCaret();
		if( pCaret && pCaret->getLine() )
		{
			CFrame *pFrame = pCaret->getLineFrame();
			if(pFrame && pFrame->isWordMemoFrame())
				bRet = BrFALSE;
		}
	}
	return bRet;
}

CFontArray* BoraDoc::getFontArray()     {
	return m_FontArray;
}
BrLPWORD BoraDoc::getFaceName(int wID) {
	return m_FontArray->getFaceName(wID);
}

BFont& BoraDoc::getBFontDummyInstance()
{
	if (!m_BFont)
		m_BFont = BrNEW BFont();
	else
		m_BFont->Reset();

	return *m_BFont;
}

void BoraDoc::setAttHandlerUpdateFlag()
{
	m_TextAttHandler->setUpdateFlag();
	m_ParaAttHandler->setUpdateFlag();
}
CFieldArray* BoraDoc::getFieldArray()
{
	return m_FieldArray;
}
CPageStyleArray* BoraDoc::getPageStyleArray()	{
	return m_PageStyleArray;
}
CODTPageRefArray* BoraDoc::getODTPageRefArray()	{
	return m_ODTPageRefArray;
}
CSectionStyleArray* BoraDoc::getSectionStyleArray()	{
	return m_SectionStyleArray;
}
CODTSectionRefArray* BoraDoc::getODTSectionRefArray()	{
	return m_ODTSectionRefArray;
}

TextAttMergeSlideEngine* BoraDoc::getTextAttMergeSlideEngine() {
	return m_TextAttMergeSlideEngine;
}

ParaAttMergeSlideEngine* BoraDoc::getParaAttMergeSlideEngine() {
	return m_ParaAttMergeSlideEngine;
}

void	BoraDoc::setCurRevisionFrameID(BrWORD nID)
{
	//if(getRevisionEngine()->getReviewMode() == ReviewMode::ALL_MARKUP)
		m_nCurRevisionFrameID = nID;
}

void    BoraDoc::makeNormalDotmStyleArray()
{
	if (!m_NormalDotmStyleArray)
		m_NormalDotmStyleArray = BrNEW CStyleAttArray();
}

CPageArray* BoraDoc::getMasterThemeArray()
{
	if (!m_pMasterThemeArray)
	{
		SET_EDIT_WARNING_LOG(kPoWarnMissingThemeFile, "getMasterThemeArray(), m_pMasterThemeArray null");
		BRTHREAD_ASSERT(0);
	}
	return m_pMasterThemeArray;
}
#endif//#ifdef BWP_EDITOR
