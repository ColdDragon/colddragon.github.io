﻿#include <OfficePreCompBWP.hpp>

#ifdef BWP_EDITOR
#include "iterator/bwCharsetIterator.h"
#include "bwBorderLineInfo.h"
#include "bwTextDraw.h"
#include "bwTextProc.h"
#include "bwField.h"
#include "bwFindReplace.h"
#include "bwFieldEq.h"
#include "bwFieldHyper.h"
#include "bwFEEngine.h"
#include "BrTheme.h"
#ifdef REMOVE_HYPER_LINK_ATTRIBUTE
#include "brexportdc.h"
#endif  // REMOVE_HYPER_LINK_ATTRIBUTE
#ifdef USE_HWP_CONTROL
#include "Hwp50/BodyText/ControlData/Clickhere/ClickHere.h"
#include "Hwp50/BodyText/ControlData/Clickhere/ClickHereHandler.h"
#endif  // USE_HWP_CONTROL
#include "Hwp50/BodyText/ControlData/PageCtrl/Hwp50PageCtrl.h"
#include "BrLocaleLanguageInterface.h"
#include "BrShapeMagicNumber.h"
#ifdef DANDONG_SMARTART
// [DanDong2] [2014.03.31] SmartArt문자렬편집시 서체크기자동계산
#include "bwSmartArtEntry.h"
#include "bwSmartArt.h"
#endif
#include "brshapecmdengine.h"
#ifdef USE_HUNSPELL
#include "brSpellCheckManager.h"
#endif
#ifdef USE_COLLABORATION
#include "CollaborationProvider.h"
#endif
#ifdef SUPPORT_HWP_CAPTION
#include "bwHWPCaption.h"
#endif  // SUPPORT_HWP_CAPTION
#include "LowVision/LowVisionEngine.h"
#include "BrShapeProxy.h"
#include "bwFieldArray.h"
#include "bwHeaderFooterEngine.h"
#include "bfontex.h"
#ifdef SUPPORT_GRAPHIC_STYLE
#include "brstyle.h"
#endif
#include "MemoEventManager.h"


#ifdef _DEBUG
static std::u16string g_tdraw_buf;
#endif  // _DEBUG


inline BrBOOL IsHwpSymbol(BoraDoc* document, BrWORD uc)
{
	return document->isFromHwp() && (IsSymbolChar(uc) || IsHalfFullSymbol(uc)) && !IsPunctuation(uc);
}


#ifdef PPT_EDITOR
BrBOOL CTextDraw::DrawSlideText(BrDC* dc, BoraDoc* document, BString* pStr, const PoTextAtt* pTextAtt,
                                BrBYTE bHAlign, BrBYTE bVAlign, BrBYTE bDirection, BRect* pRect,
                                BrBOOL bAdjustFonSizeInRect)
{
	if (!dc || !pStr || !pRect)
		return BrFALSE;

	BrINT	nWidth, nHeight, nFSize, sx = 0, sy = 0;
	BFont	newBFont, * oldBFont;
	BrBOOL bBold, bUnderline, bStrikeout;
	BrCOLORREF dwColor;
	CCmdEngine* pCmdEngine = document->getCmdEngine();

	bBold = bUnderline = bStrikeout = BrFALSE;
	nWidth = pRect->getWidth();
	nHeight = pRect->getHeight();

	if (!pTextAtt) {
		nFSize = 12 * 20;
		dwColor = RGB_BLACK;
	}
	else {
		BrWORD wFontID;
		const BChar* pChar = pStr->unicode();
		BrWORD wCode = pChar->unicode();
#ifdef SUPPORT_THEME_FONT
		BrINT nThemeID = theBWordDoc->getThemeID();
		THEME_FONT_SCRIPT themeFontScript = theBWordDoc->m_pTheme->getUserFontScheme(nThemeID)->getFontGroup(wCode);
		BrBOOL isThemeFont = BrFALSE;
		if (themeFontScript == THEME_FONT_LATIN && pTextAtt->getThemeAscii()) {
			//글자가 라틴 영역일 때 라틴 테마값이 있는 경우 테마 폰트 사용.
			isThemeFont = BrTRUE;
			nFSize = pTextAtt->getEngFSize();
		}
		else if (themeFontScript == THEME_FONT_EA && pTextAtt->getThemeEastAsia()) {
			isThemeFont = BrTRUE;
			nFSize = pTextAtt->getHanFSize();
		}
		else if (themeFontScript == THEME_FONT_CS && pTextAtt->getThemeCs()) {
			isThemeFont = BrTRUE;
			nFSize = pTextAtt->getHanFSize(); //
		}

		if (isThemeFont) {
			wFontID = document->m_pTheme->getCurrentThemeFontID(pTextAtt, wCode);
		}
		else
#endif  // SUPPORT_THEME_FONT
		{
			if (IsHwpSymbol(document, wCode)) {
				nFSize = pTextAtt->getHanFSize();
				wFontID = pTextAtt->getSymbolFontID();
			}
			else if (document->isFromHwp() && IS_HANGUL_JAMO(wCode)) {
				nFSize = pTextAtt->getHanFSize();
				wFontID = CTextProc::ConvertOldHanFontId(pTextAtt->getHanFontID());
			}
			else if (IsFullWidthChar(wCode)) {  // if (IS_MODERN_KOREAN(wCode) || IS_HANJA(wCode))
				nFSize = pTextAtt->getHanFSize();
				wFontID = pTextAtt->getHanFontID();
			}
			else {
				nFSize = pTextAtt->getEngFSize();
				wFontID = pTextAtt->getEngFontID();
			}
		}

		CFontArray* pFontArray = document->getFontArray();
		BrLPWORD pFaceName = pFontArray->getFaceName(wFontID);
		if (pFaceName)
			newBFont.setFontName(pFaceName, CUtil::WcsLen(pFaceName));

		if (pTextAtt->getBold()) {
			newBFont.setBold(BrTRUE);
			bBold = BrTRUE;
		}
		if (pTextAtt->getItalic())
			newBFont.setItalic(BrTRUE);
		if (pTextAtt->getUnderline()) {
			newBFont.setFontUnderline(BrTRUE);
			bUnderline = BrTRUE;
		}
		if (pTextAtt->getStrikeout() || pTextAtt->getDStrikeout())
			newBFont.setFontStrikeout(BrTRUE);
		if (pTextAtt->getSubscript() || pTextAtt->getSuperscript())
			newBFont.setFontSize((BrINT)(nFSize * PO_TEXTATT_BASE::superSubScriptSizeRatio));
		if (pTextAtt->getOutline())
			newBFont.setFontOutline(BrTRUE);
		if (pTextAtt->isNormalizeH())
			newBFont.setCharEqualHeight(BrTRUE);
		if (pTextAtt->getEmboss())
			newBFont.setFontEmboss(BrTRUE);
		if (pTextAtt->getEngrave())
			newBFont.setFontEngrave(BrTRUE);
		dwColor = pTextAtt->getTextColor().getColor();
	}

	newBFont.setFontWidthRatio(100);
	newBFont.setFontColor(dwColor);

	BrINT nStringWidth, nStringHeight;
	if (bAdjustFonSizeInRect) {
		// string width/height 구하는 함수(getBStringNoRotatedWidthExact, getCharAscent등)가
		// 일본어 폰트등은 매우 느리므로 될 수 있으면 사용하지 말것
		// font size 클수록 함수가 느려지므로 100pt base로 생성하여 비율로 처리한다.(한국어, 중국어, 영어 이외)

		BrBOOL bCheck = BrFALSE;
		BrINT32 nLocale = PoGetLocale();

		if (BR_LOCALE_KOREAN == nLocale ||
		    BR_LOCALE_US_ENGLISH == nLocale ||
		    BR_LOCALE_S_CHINESE == nLocale ||
		    BR_LOCALE_T_CHINESE_TW == nLocale ||
		    BR_LOCALE_T_CHINESE_HK == nLocale ||
		    BR_LOCALE_ENGLISH_AUSTRAILIA == nLocale ||
		    BR_LOCALE_ENGLISH_CANADA == nLocale ||
		    BR_LOCALE_ENGLISH_IRELAND == nLocale ||
		    BR_LOCALE_UK_ENGLISH == nLocale) {
			nFSize = pCmdEngine->distanceDoc2LogicalY(nFSize);
		}
		else {
			nFSize = 100;
			bCheck = BrTRUE;
		}

		newBFont.setFontSize(nFSize);
		nStringWidth = newBFont.getBStringNoRotatedWidthExact(pStr); // return value 확인 필요
		nStringHeight = newBFont.getCharAscent(); // newBFont.getFontCharHeight();

		BrINT nWdt, nHgt;
		if (bDirection) {
			nHgt = nWidth;
			nWdt = nHeight;

#ifdef SUPPORT_PLACEHOLDER_TEXT
			BrBOOL bSeroText = BrFALSE;
			if (pStr->length() > 0) {
				if (pStr->at(0).latin1() > 0 && pStr->at(0).latin1() <= 127)
					bSeroText = BrFALSE;
				else
					bSeroText = BrTRUE;
			}
			if (BR_LOCALE_KOREAN == nLocale ||
			    BR_LOCALE_S_CHINESE == nLocale ||
			    BR_LOCALE_T_CHINESE_TW == nLocale ||
			    BR_LOCALE_T_CHINESE_HK == nLocale)
				newBFont.SetPlaceHolderText(bSeroText);
			else if (BR_LOCALE_JAPANESE == nLocale)
				newBFont.SetPlaceHolderText(BrFALSE);
			else
				newBFont.SetPlaceHolderText(BrFALSE);
#endif
		}
		else {
			nWdt = nWidth;
			nHgt = nHeight;
#ifdef SUPPORT_PLACEHOLDER_TEXT
			newBFont.SetPlaceHolderText(BrFALSE);
#endif
		}

		if (bCheck || nStringWidth > nWdt || nStringHeight > nHgt) {
			BrFLOAT fWRatio = (nStringWidth)?((BrFLOAT)nWdt / (BrFLOAT)nStringWidth):1;
			BrFLOAT fHRatio = (nStringHeight)?((BrFLOAT)nHgt / (BrFLOAT)nStringHeight):1;
			if (fWRatio < fHRatio) {
				nFSize = nFSize * fWRatio;
				nStringWidth *= fWRatio;
				nStringHeight *= fWRatio;
			}
			else {
				nFSize = nFSize * fHRatio;
				nStringWidth *= fHRatio;
				nStringHeight *= fHRatio;
			}
			newBFont.setFontSize(nFSize);
		}
	}
	else {
		nFSize = pCmdEngine->distanceDoc2LogicalY(nFSize);
		newBFont.setFontSize(nFSize);
		nStringWidth = newBFont.getBStringNoRotatedWidthExact(pStr); // return value 확인 필요
		nStringHeight = newBFont.getCharAscent(); // newBFont.getFontCharHeight();
	}

	if (bDirection) {  // sero
		newBFont.setFontRotate(90);
		switch (bHAlign) {
			case LEFT:        sy = pRect->nTop + 2;                           break;
			case CENTER:      sy = pRect->nTop + (nHeight - nStringWidth)/2;  break;
			case RIGHT:       sy = pRect->nBottom - nStringWidth - 2;         break;
			case DISTRIBUTE:  sy = pRect->nTop;                               break;
			default:          sy = pRect->nTop + 2;                           break;
		}
		switch (bVAlign) {
			case TOP_ARRANGE:     sx = pRect->nRight - nStringHeight - 2;          break;
			case MIDDLE_ARRANGE:  sx = pRect->nLeft + (nWidth - nStringHeight)/2;  break;
			case BOTTOM_ARRANGE:  sx = pRect->nLeft - nStringHeight - 2;           break;
			default:              sx = pRect->nRight - nStringHeight - 2;          break;
		}
	}
	else {  // garo
		newBFont.setFontRotate(0);
		switch (bHAlign) {
			case LEFT:        sx = pRect->nLeft + 2;                          break;
			case CENTER:      sx = pRect->nLeft + (nWidth - nStringWidth)/2;  break;
			case RIGHT:       sx = pRect->nRight - nStringWidth - 2;          break;
			case DISTRIBUTE:  sx = pRect->nLeft;                              break;
			default:          sx = pRect->nLeft + 2;                          break;
		}
		switch (bVAlign) {
			case TOP_ARRANGE:     sy = pRect->nTop + 2;                            break;
			case MIDDLE_ARRANGE:  sy = pRect->nTop + (nHeight - nStringHeight)/2;  break;
			case BOTTOM_ARRANGE:  sy = pRect->nBottom - nStringHeight - 2;         break;
			default:              sy = pRect->nTop + 2;                            break;
		}
	}

	oldBFont = dc->setFont(&newBFont);

// 	font.setFontRotate(nRotateAngle);
//	dc->drawChars(&current_str, lastPos.getX(), lastPos.getY(), 0);
//	font.setFontRotate(0);

	BrWORD* pGapX = BrNULL;
	if (DISTRIBUTE == bHAlign) {
		BrINT i, nSpace, nGap, nLen = pStr->length();
		const BChar* pUniData = pStr->unicode();

		nSpace = 0;
		for (i = 0; i < nLen; i++) {
			if (pUniData[i].isSpace())
				nSpace++;
		}

		if (0 < nSpace)
			nSpace--;

		nGap = nWidth / (nLen - nSpace);

		pGapX = (BrWORD*)BrMalloc(BrSizeOf(BrWORD) * nLen);
		for (i = 0; i < nLen; i++)
			pGapX[i] = nGap;
	}

	dc->drawChars(pStr, sx, sy, pGapX);

	if (pGapX)
		BrFree(pGapX);

	dc->setFont(oldBFont);

	BrINT nLineLength = sx + nStringWidth;

	if (bBold)
		nLineLength += 5;
	BrCOLORREF dwOldColor = dc->setPenColor(dwColor);
	if (pTextAtt) {
		if (bUnderline) {
			//hnsong:2012-05-02 PO5.0 개발항목(Underline Style)
			BrCOLORREF dwOldPenColor = dc->setPenColor((pTextAtt->getUnderlineColor()).getColor());
			dc->drawLine(sx, sy + nStringHeight + 2, nLineLength, sy + nStringHeight + 2);
			dc->setPenColor(dwOldPenColor);
		}

		if (pTextAtt->getStrikeout()) {
			dc->drawLine(sx, sy + nStringHeight / 2, nLineLength, sy + nStringHeight / 2);
		}
		else if (pTextAtt->getDStrikeout()) {
			//hnsong:2012-06-16 PO5.0 개발항목(Double Strike)
			dc->drawLine(sx, sy + nStringHeight / 2 - 2, nLineLength, sy + nStringHeight / 2 - 2);
			dc->drawLine(sx, sy + nStringHeight / 2 + 2, nLineLength, sy + nStringHeight / 2 + 2);
		}
	}

	dc->setPenColor(dwOldColor);

#ifdef SUPPORT_PLACEHOLDER_TEXT
	newBFont.SetPlaceHolderText(BrFALSE);
#endif  // SUPPORT_PLACEHOLDER_TEXT

	return BrTRUE;
}
#endif  // PPT_EDITOR


void CTextDraw::DrawTextFrame(Painter* painter, BrDC* dc, CDrawUnit& du,
                              CFrame* pFrame, BrBOOL bNeedPreprocess)
{
	// BRTHREAD_STOPWATCH;
	//[2012.09.18][TID:7609][김회영]Section Debugging - CTextDraw::DrawTextFrame()
#ifdef SUPPORT_SECTION_DEBUG
	//pFrame->showCharacters();
#endif//SUPPORT_SECTION_DEBUG

	if (IsValidObject(pFrame) == BrFALSE || pFrame->isLine())
		return;

	// qDebug("draw text line_frame");
	BRect rcDraw;
	BrINT sx, sy, nPrevY = 0, y, nUpLineSp;
	BrINT nWidth;
	BrINT nBandCount;
	BrINT nChkInWorkArea;
	BrINT nMaxDescent = 0;
	BrBOOL bUnder;
	CCaret* pCaret;
	BrBYTE nOldMode = eNoneExtMode;
	BrRect orgClipRect, clipRect;
	BrBOOL bSetClip = BrFALSE;

	BoraDoc* document = theBWordDoc;
	if (document == BrNULL)
		return;

	pCaret = document->getCaret();

	PO_THREAD_TRY_BLOCK {
		BRect rcFrame(pFrame->getFrameRect());
		if (pFrame->GetClass() == FLOATFRAME && (pFrame->isDoNotRotateText()) && ((pFrame->GetRotation() >= 45 && pFrame->GetRotation() < 135) || (pFrame->GetRotation() >= 225 && pFrame->GetRotation() < 315))) {
			BrUtil::SwapPosAndWH(rcFrame);
		}
#ifdef DANDONG_SMARTART_EDIT
		// [2015.08.18] 회전된 SmartArt자식도형에서 Caret설정시 본문표시위치가 틀리는 오유의 대책
		// 자식도형의 autoTxRot속성이 upr이고 회전각도가 있다면 회전된 도형의 령역을 기준으로 본문표시위치가 결정되여야 한다.
		// 왜냐하면 자식도형의 autoTxRot속성이 upr이고 회전각도가 있을 때 본문편집상태를 위해 도형각도를 0도로 설정하지 않기때문이다.
		else if (pFrame->GetClass() == DIAGRAMXENTRY && pFrame->GetRotation() != 0) {
			CSmartArtEntry* pEntry = (CSmartArtEntry*)pFrame;
			if (pEntry->GetAutoTxRotationType() == eSmartArtUprATRot && rcFrame != pEntry->m_rcRotateFrame) { // 도형의 원본크기와 본문의 놓임방향에 따르는 도형크기가 다르다면
				rcFrame = pEntry->m_rcRotateFrame;
			}
		}
		// [2016.03.24] Slide에서 SmartArt도형에 대하여 Ungroup적용하고 본문이 있는 자식도형을 선택한 이후
		// 도형안의 본문이 회전되여 표시되는 오유의 수정(ZPD-26729)
		if (pFrame->GetClass() == FLOATFRAME && pFrame->isDoNotRotateText() && pFrame->GetClassOrg() == DIAGRAMXENTRY && pFrame->GetRotation() != 0) {
			CSmartArtEntry* pEntry = (CSmartArtEntry*)pFrame;
			if (pEntry->GetAutoTxRotationType() == eSmartArtUprATRot) {
				rcFrame = pEntry->m_rcRotateFrame;
			}
		}
#endif  // DANDONG_SMARTART_EDIT

		if (document->isFromHwp() && pFrame->GetRotation() != 0)
			BrDrawUnit::getContainerRect(pFrame->getFrameRect(), pFrame->GetRotation(), rcFrame);

		if (((rcFrame.nRight - rcFrame.nLeft) < 1 ||
		    (rcFrame.nBottom - rcFrame.nTop) < 1) && document->getBWPEngineMode() == EDITOR_WORD) // ZPD-13720
		{
			return;
		}

		CPage* pPage = pFrame->getPage();
		BrINT   nTotalPage = document->getEditingTotalPage();

		if (bNeedPreprocess) {
			if (BrFALSE == CTextProc::preprocessDrawTextFrame(document, pFrame))
				return;
		}

		CLineList* pLineList = (CLineList*)pFrame->getSubFrame();
		if (pLineList == BrNULL)
			return;

		CLine* pLine = pLineList->getFirst();

		if (pLine == BrNULL
			|| pLine->isOverflow()
			|| pLine->isDirty()
			|| pLine->getFlagOfPosArray() == BrFALSE) {
			return;
		}

		PoParaAttHandler* para_att_h = theBWordDoc->getParaAttHandler();
#ifdef SUPPORT_TABLET_VIEW_MODE
		BrINT nCurPageNum = 0;
		if (document->isTabletViewMode() && pFrame->isBasic() && document->getStartLineForEBook()) {
			CLine* pSLine = document->getStartLineForEBook();

			if (pSLine) {
				nCurPageNum = pSLine->getPgNumForEBook();
				if (!pSLine->getFrame()->isBasic())
					pSLine = pSLine->getFrame()->getAnchorLine();
				if (pSLine && pSLine->getFrame()->isBasic())
					pLine = pSLine;
			}
		}
#endif  // SUPPORT_TABLET_VIEW_MODE

		nOldMode = dc->setExportMode(eDirectExtMode);
		CCmdEngine* pCmdEngine = document->getCmdEngine();

		pFrame->setExistParaDecoLine(BrFALSE);

		DrawParaDecoBackground(dc, du, pFrame);

		// Frame 단위로 clip rect를 지정 (ZPD-9648, ZPD-9634)
		// Rotation 이 있는 프레임은 무시하자 XPD-1893, Rotation line_frame 다시 시도 WPD-1166
		// table cell 처리 update XPD-5914
			// if ( (document->isFromWordType() || document->isFromHwp()) && (pFrame->isCell() || pFrame->GetClass()==FLOATFRAME) && pFrame->GetRotation()==0)
		if (pFrame->isCell() || ((FLOATFRAME == pFrame->GetClass() && (document->isFromMSWordType() || document->isFromHwp())) /*&& 0 == pFrame->GetRotation()*/)) {
			//BrBOOL bAffectParentClip = BrFALSE;
			BrBOOL bOdtTopParentClip = BrFALSE;
			BRect rcTmpFrame = rcFrame;
#ifdef SUPPORT_HWP_CAPTION
			if (pFrame->isHWPCaptionTextFrame() && pFrame->getHWPCaption() && pFrame->getHWPCaptionOrgFrame() && pFrame->getHWPCaptionOrgFrame()->getTextWrapEnumType() == BR_TEXT_WRAP_INLINE_WITH_LINE) {
				CFrame* pRootCaptionFrame = pFrame->getHWPCaption()->getRootCaptionFrame();
				CFrame* pTmpFrame = pRootCaptionFrame->getAnchorFrame();
				if (pTmpFrame && pTmpFrame->isCell())
					rcTmpFrame = *pTmpFrame->getFrameRect();
				else
					rcTmpFrame = *pRootCaptionFrame->getFrameRect();
				//BrDrawUnit::getContainerRect(pRootCaptionFrame->getFrameRect(), pRootCaptionFrame->GetRotation(), rcTmpFrame);
			}
#endif  // SUPPORT_HWP_CAPTION

			// [AOM-51819]
			CLine* anchor_line = pFrame->getAnchorLine();

			// hwp에서 parent special text line_frame 에 floating된 anchor line_frame 인 경우 parent clip 을 고려 OFF-9416
			if (document->isFromHwp()
				&& !pFrame->isAnchored() && IsValidObject(anchor_line)
				&& pFrame->isWordMemoFrame() == BrFALSE)  //CSP-6773 메모 프레임은 anchor line 이 도형 안에 있어도 그려준다.
			{
				CFrame* pParentFrame = pFrame->getAnchorLine()->getFrame();
				if (pParentFrame && pParentFrame->isSpecial() && pParentFrame->GetRotation() == 0) {
					rcTmpFrame.Intersection(pParentFrame->getFrameRect());
					//bAffectParentClip = BrTRUE;
				}
			}
			else if (document->isFromOdt() && pFrame->getCell()) {
				CFrame* pTableParentFrame = pFrame->getCell()->getTable()->getFrame()->getAnchorFrame();
				if (pTableParentFrame && pTableParentFrame->isShape() && pTableParentFrame->isODTFrame() && pTableParentFrame->getVerticalAlignment() == ALG_TOP) {
					if (rcTmpFrame.nTop <= pTableParentFrame->getFrameRect()->nTop)
						bOdtTopParentClip = BrTRUE;
				}
			}
			else if (document->isFromDoc() && pFrame->GetClass() == FLOATFRAME) {
				// BorderMarginWithText 가 있는 경우 그에 맞게 clip rect 조정 XPD-17249
				BRect   rcMargin = pFrame->getBorderMarginWithText();
				if (rcMargin.nBottom)
					rcTmpFrame.nBottom -= rcMargin.nBottom;
			}

			dc->getClipRect(orgClipRect);

#ifdef SUPPORT_SHOW_HWP_TYPESET
			if (!(document->isShowHWPTypeSetMode() && (pFrame->isCell() || pFrame->GetClass() == FLOATFRAME)))
#endif  // SUPPORT_SHOW_HWP_TYPESET
			{
				// 글자 넘치는 부분을 clip region에 포함 HEJ-1620, odt만 적용 LQQ-6998
				if (document->isFromOdt() && pLine->getPosArray().size() > pLine->getCharNum() && pLine->getPosArray().at(pLine->getCharNum()) > rcTmpFrame.getWidth())
					rcTmpFrame.nRight += pLine->getPosArray().at(pLine->getCharNum()) - rcTmpFrame.getWidth();
			}

			du.doc2Logical(rcTmpFrame);

			if (pFrame->isFrameForm()) // WPD-3581
				rcTmpFrame.InflateRect(2, 2);

			if (!isExportMode())//[IAC-2765] PDF 내보내기 용 clipRect는 dc->getExport에 있는 line_frame 데이터 더해야 되서, dc->getClipRect 값으로 가공하면 안 됨.
			{
				//if ( !bAffectParentClip )	rcTmpFrame.nRight += DEF_MARGIN_PIX; //XPD-6524 렌더링 Cell을 초과하여 텍스트 나타남 주석 처리	// ZPD-26867
				if (bOdtTopParentClip) //HEJ-1214 (XPD-15434 : 원복 후 수정) ODT 의 Table이 글틀에 삽입 밑 Top 정렬인 경우, Parent Top 보다 Table Top 이 동일 라인으로, 1px 적게 cliprect 설정하여 그려주도록 함.
				{
					BrLONG nSaveTop = rcTmpFrame.nTop - 1;
					if (orgClipRect.right && orgClipRect.bottom)
						rcTmpFrame.Intersection(orgClipRect);
					orgClipRect.top = nSaveTop;
				}
				else if (orgClipRect.right && orgClipRect.bottom) {
					if (pFrame->isCell() && document->isFromMSWordType() && orgClipRect.right < rcTmpFrame.nLeft) //[POD-4988] 설정된 ClipRect 가 현재 Draw 영역의 가로에 맞지 않을때, Draw할 필요 없기 때문에 return 처리. 일단 해당 이슈 case 위치에만 조건 추가.
						return;

					rcTmpFrame.Intersection(orgClipRect);
				}
			}

			// HWP parent special line_frame left/top 부터 표시 되어짐, XPD-12076
			if (document->isFromHwp() && pFrame->isSpecial()) {
				rcTmpFrame.nLeft--;
				rcTmpFrame.nTop--;
			}

			clipRect = rcTmpFrame.getBrRect();
			if (pFrame->isCell() && pFrame->getDirection() != GARO && document->getBWPEngineMode() == EDITOR_PPT) {
				if (pFrame->isTextFlowBottomToTop())
					clipRect.right = getLCDWidth();
				else
					clipRect.left = 0;
			}

			dc->setClipRect(&clipRect);
			bSetClip = BrTRUE;
		}

		if (pFrame->isGaro() || (pFrame->isCell() && document->isViewOutlineMode())) {
			nWidth = du.doc2LogicalDX((rcFrame.nRight - rcFrame.nLeft), BrFALSE);
			// web mode에서 뒤쪽의 입력 속도 개선 CSP-775
#ifdef SUPPORT_TABLET_VIEW_MODE
			if (!document->isTabletViewMode() || nCurPageNum == 0)
#endif  // SUPPORT_TABLET_VIEW_MODE
			{
				if (document->isViewWebMode() && pFrame->isBasic()) {
					CLine* pTmpLine = pCmdEngine->GetStartLineOnScreen(pLine);
					if (pTmpLine) {
						pLine = pTmpLine;
						pTmpLine = pTmpLine->getPrev();
						if (pTmpLine)
							pLine = pTmpLine;
					}
				}
			}

			//cash로 사용될 temp textatt
			BrINT32 mergedParaAttID = 0;
			const PoParaAtt* mergedParaAtt = BrNULL;
			BrBOOL is_draw_sep_line = BrFALSE;

			while (pLine) {
				//////////////////////////////////////////////////////////////////////////
				//paraAtt 병합
				if (theBWordDoc->getDocType() == BORA_DOCTYPE_PPTX || theBWordDoc->getBWPEngineMode() == EDITOR_PPT) {
					mergedParaAttID = para_att_h->getMergedParaAttID(pLine->getParaID(), pLine);
					mergedParaAtt = para_att_h->getParaAtt(mergedParaAttID);
					pLine->setParaID(mergedParaAttID);
				}
				else {
					mergedParaAtt = para_att_h->getMergedParaAtt(pLine->getParaID());
				}

				if (CTextProc::isNoDisplayBullet(document, pLine)) {
					pLine = pLineList->getNextInFrame(pLine);
					mergedParaAttID = 0;
					continue;
				}

				if (document->isViewOutlineMode()) {
					BrBOOL bSkipLine = BrFALSE;
					const PoParaAtt* pParaAtt = para_att_h->getMergedParaAtt(pLine->getParaID(), pLine);
					if (document->isOutlineFirstLine() && 0 == pParaAtt->getOutlineLevel() && BrFALSE == pLine->isStartLine()) //본문인 경우만 사용
					{
						bSkipLine = BrTRUE;
					}

					if (!bSkipLine && BR_OUTLINE_SHOW_LEVEL_ALL != document->getShowLevel() &&
						(0 == pParaAtt->getOutlineLevel() || (pParaAtt->getOutlineLevel() > document->getShowLevel()))) {
						bSkipLine = BrTRUE;
					}

					if (bSkipLine) {
						pLine = pLine->getLastLineOfPara()->getNext();
						continue;
					}
				}

#ifdef USE_TEXTANIMATION_COUTDEV
				//Slide Show 이후 Page에서 도형이 보이지 않는 오유수정
				if (!pCmdEngine->isSlideShow())
					pLine->setIsShow(BrTRUE);
				//[2013.01.25][SlideEffect][Animation] add paragraph show flags
				if (!pCmdEngine->isSlideShowEditorPageDraw() && !pLine->getIsShow() && !pCmdEngine->isCurOperation(ACTMAKETHUMBNAIL)) {
					pLine = pLineList->getNextInFrame(pLine);
					continue;
				}
#endif//USE_TEXTANIMATION_COUTDEV
				//--- Check Clip Region -------------------------------------------
				// Get Invalidate Area of Line (page coordinate)
				if (!CTextProc::getInvalidateArea(document, pFrame, pLine, rcDraw))
					break;

				// logical coordinate
				du.doc2Logical(rcDraw);
				// rcDraw.InflateRect(1,1);

				// Check clip region	[dwchun : 2012.09.07] : PDF Export시 Clip region을 체크하면 안됨
				if (!document->isTabletViewMode() && !dc->isExportMode() && !document->IsInInvalidateRect(rcDraw, &bUnder) && (pPage == BrNULL || pPage->getPageType() != NOTEMASTER_PAGE) && pFrame->GetRotation() == 0) {
					// if current line is under clip region, stop drawing
					// [XPD-17349] Cell에 Image가 있으며, 그 뒤로 Line이 존재 함. 이때 상위는 화면에 들어오지 않아, bUnder 가 true인데, 실제 image는 다음 Line에도 존재 할수 있음.
					// Cell인 경우는 다음 Line을 계속 체크하도록 함.
					if (bUnder && pFrame->isCell() == BrFALSE) {
						if (pFrame->getExistParaDecoLine()) // 2011-9-11 함수가 끝나게  되면 Para Boreder를 그리지 않아서 여기서도 호출
							DrawParaDecoLine(dc, du, pFrame);
						if (nOldMode != eNoneExtMode)
							dc->setExportMode(nOldMode);
						break;
					}

					pLine = pLineList->getNextInFrame(pLine);
					continue;
				}
				//-----------------------------------------------------------------

				if (pLine->isDirty() == BrFALSE && pLine->getFlagOfPosArray()) {
					if (!CTextProc::getArrangeArea(document, pFrame, pLine, rcDraw)) {
						pLine = pLineList->getNextInFrame(pLine);
						continue;
					}

					// 현재 line이 Working Area안에 존재하는지를 check
					if (BrFALSE == document->isViewPrintMode() && pPage && pPage->getFrameDraw() == BrFALSE)	// check FrametoDIB
					{
#ifdef SUPPORT_TABLET_VIEW_MODE
						if (!document->isTabletViewMode())
#endif  // SUPPORT_TABLET_VIEW_MODE
						{
							nChkInWorkArea = document->getCmdEngine()->isInWorkArea(pPage, rcDraw);
							if (nChkInWorkArea == UP_WORK_AREA) {		// up working area
								pLine = pLineList->getNextInFrame(pLine);
								continue;
							}
							// down, left or right working area
							else if (nChkInWorkArea == DOWN_WORK_AREA || /*nChkInWorkArea==LEFT_WORK_AREA ||*/		// table등이 basic line_frame 보다 훨씬 크게 잡혀 있어서...
								nChkInWorkArea == RIGHT_WORK_AREA) {
								break;
							}
						}
#ifdef SUPPORT_TABLET_VIEW_MODE
						// check line of next page
						if (document->isTabletViewMode() && document->getStartLineForEBook() != pLine && nCurPageNum > 0 && pLine->getPgNumForEBook() > nCurPageNum) {
							break;
						}
#endif  // SUPPORT_TABLET_VIEW_MODE
					}

					nBandCount = CTextProc::makeRearrangeBand(document, pPage, pFrame, pLine, rcDraw, BrTRUE, pLine->getTableFlag() != 0);
					if (nBandCount < 1) {
						nBandCount = CTextProc::makeDefaultBand(rcDraw.nLeft, rcDraw.nRight);
					}

					y = pLine->getBasePos();
#ifdef SUPPORT_SHOW_LINESPACE
					BrINT nMarkingPos = sy;
#endif SUPPORT_SHOW_LINESPACE

					// marking 위치 때문에 수정
					// /*if ( !document->isFromHwp() )*/	sy += CTextProc::CalcLineSpace(document, pLine, BrTRUE)/2;
					if (!document->isFromHwp()) {
						// For PPT
						if (document->isFromSlideType()) {
#ifdef DANDONG_SMARTART
							// [DanDong2] [2014.07.17] SmartArt에서 Word와 PPT에 따라 본문들의 paragraph가 달라지는 오유수정
							// PPT에서 line spacing이 서체에 따라 변경되지 못하고 서체크기에만 의존해서 계산되기때문이다.
							// 따라서 PPT에서 스마트아트인 경우에는 Word에서와 같이 paragraph를 계산하게 한다.
							if (pFrame != BrNULL && pFrame->GetClass() == DIAGRAMXENTRY
									// [2016.03.24] Slide에서 SmartArt도형에 대하여 Ungroup적용하고 본문이 있는 자식도형을 선택한 이후
									// 도형안의 본문이 회전되여 표시되는 오유의 수정(ZPD-26729)
									|| (pFrame->GetClass() == FLOATFRAME && pFrame->GetClassOrg() == DIAGRAMXENTRY && pFrame->isDoNotRotateText())
									) {
										BrINT nLineSp = CTextProc::CalcLineSpace(document, pLine, BrTRUE);
										if (nLineSp <= 0)
											y += nLineSp;
										else
											y += pLine->getDisplayLineSp(document);
								}
								else
#endif  // DANDONG_SMARTART
								{
									if (pLine->getLineSp() <= 0)		// XPD-17502
										y += pLine->getLineSp();
									else
										y += pLine->getLineSp() * 0.6/*0.8*/;	// AOM-174
								}
							}
						// For Word
						else {
							BrINT nLineSp = CTextProc::CalcLineSpace(document, pLine, BrTRUE);
							if (nLineSp <= 0)
								y += nLineSp;
							else
								y += pLine->getDisplayLineSp(document);
						}
					}
					//else
					//{
					// sy += CTextProc::CalcLineSpace(document, pLine, BrTRUE)*0.1;
					//}

					// if (document->getBWPEngineMode() == EDITOR_WORD && lprcFrame->nBottom < sy && pFrame->isCell())  // M16443 2012-10-26
					//     break;

					// line space 에 따라 Line 위쪽으로 띄우는 공간
					nUpLineSp = y - pLine->getBasePos();

					BPoint ptRc(rcFrame.nLeft, rcFrame.nTop);
					du.doc2Logical(ptRc, BrTRUE); //line_frame rect의 left/top logical 좌표

					BPoint ptLine(0, y);
					du.doc2Logical(ptLine, BrTRUE);
					ptLine.y -= du.getOffset().y; //line height logical 크기

					sx = ptRc.x;
					sy = ptRc.y + ptLine.y;

#ifdef SUPPORT_SHOW_LINESPACE
					BrINT nTmpLineSp = CTextProc::CalcLineSpace(document, pLine, BrTRUE);
					BrDOUBLE yTmp = du.doc2LogicalY(nMarkingPos + nTmpLineSp, BrTRUE);

					dc->setPenColor(BrRGB(255,0,0));
					//dc->moveTo(0, du.doc2LogicalY(nMarkingPos + CTextProc::CalcLineSpace(document, pLine, BrTRUE), BrTRUE));
					//dc->lineTo(1024, du.doc2LogicalY(nMarkingPos +CTextProc::CalcLineSpace(document, pLine, BrTRUE), BrTRUE));
					dc->moveTo(0, yTmp);
					dc->lineTo(1024, yTmp);
#endif SUPPORT_SHOW_LINESPACE

					if (document->getBWPEngineMode() == EDITOR_WORD)
						DrawBackgroundOfGaroOneLine(dc, du, pFrame, pLine, sx, sy, nBandCount, nUpLineSp);

#ifdef BWP_EDITOR
					if (pCaret->isCaretNormal() && pCaret->getCompLen())
						DrawCompBackgroundOfGaroOneLine(dc, du, pFrame, pLine, sx, sy, nBandCount);
#endif  // BWP_EDITOR

					CheckMultiMarkFindOfOneLineForSeekList(BrTRUE, document, dc, du, pFrame, pLine, sx, sy);

					document->getCmdEngine()->m_bBwpDrawForeground = TEXT_NO_FOREGROUND;

					//[dwchun : 2011.07.15] : 한 라인에 폰트의 크기가 상이한 경우, 해당 라인에서 가장 큰 Descent값을 구해 DrawGaroCharSet으로 넘겨준다.
					//						라인의 폰트 크기가 동일할 경우 연산 하지 않음
					nMaxDescent = CTextProc::getMaxDescentOfCurLine(document, pLine);
					//[dwchun : End]

					if (pFrame->isBasic()) //For LineNumber
						DrawGaroLineNumber(dc, du, pLine, nMaxDescent, sy);

					// 라인 단위로 clip rect를 지정 (NPC-5161)
					/*
					if ( (document->isFromWordType() || document->isFromHwp()) && !pLine->getTableFlag() && pFrame->isCell() )
					{
						dc->getClipRect(orgClipRect);

						du.doc2Logical(rcDraw);
						if ( orgClipRect.right && orgClipRect.bottom )
							rcDraw.Intersection(orgClipRect);
						clipRect = rcDraw.getBrRect();
						dc->setClipRect(&clipRect);
					}
					*/

					DrawGaroOneLine(painter, dc, du, pFrame, pLine, sx, sy, nWidth, nBandCount, nMaxDescent, *mergedParaAtt);
					/*
					if ( (document->isFromWordType() || document->isFromHwp()) && !pLine->getTableFlag() && pFrame->isCell() )
						dc->setClipRect(&orgClipRect);
					*/

					if (document->isSupportedRevision() && /*BrFALSE == document->isViewWebMode() &&*/
						  BrFALSE == document->isViewOutlineMode() && (painter->pDC) && !painter->pDC->isExportMode()
					) {
						BrRect curClipRect, prevClipRect;
						if (pFrame->isCell() || pFrame->GetClass() == FLOATFRAME) {
							dc->getClipRect(curClipRect);
							prevClipRect = curClipRect;
							curClipRect.left = 0;
							dc->setClipRect(&curClipRect);
						}
						document->getRevisionEngine()->drawGaroRevisionIndicator(dc, du, pLine, sy, nPrevY);
						nPrevY = sy;
						if (pFrame->isCell() || pFrame->GetClass() == FLOATFRAME)
							dc->setClipRect(&prevClipRect);
					}

						// Docx 문서에서 export 시 같은 글자 2번 그리는 문제
					if (!isExportMode())
						if (pLine->isRedraw())
							DrawGaroOneLine(painter, dc, du, pFrame, pLine, sx, sy, nWidth, nBandCount, nMaxDescent, *mergedParaAtt, -1, -1, BrFALSE);

					if (document->getRevisionEngine()->getMemoShowState() == BrTRUE)
						document->getCmdEngine()->m_bBwpDrawForeground |= TEXT_MEMO_ICON_FOREGROUND;

#ifdef SUPPORT_HIDDEN_TEXT
					if (document->getCmdEngine()->IsShowEditSymbol() || document->getCmdEngine()->getEditSymbolShowState().bHiddenText)
						document->getCmdEngine()->m_bBwpDrawForeground |= TEXT_DOTLINE_HIDDEN_TEXT;
#endif  // SUPPORT_HIDDEN_TEXT
					if (document->getCmdEngine()->m_bBwpDrawForeground != 0
						|| document->getRevisionEngine()->canDrawRevisionViewMode()) {
						DrawForegroundOfGaroOneLine(painter, dc, du, pFrame, pLine, sx, sy, nBandCount, nMaxDescent, nUpLineSp);
					}

					// [WPD-6592]
					CLine *next_line = pLine->getNextInFrame();
					BrBOOL is_last_basic = pLine->getNoteLineNum() == 0 && next_line && next_line->getNoteLineNum();

					if (!is_draw_sep_line && (pLine->getNoteLineNum() > 0 || is_last_basic)) {
#ifndef SUPPORT_ADVANCE_FENOTELINE
						CLine *note_line = is_last_basic ? next_line : pLine;
						DrawFENoteLine(dc, du, note_line);
						is_draw_sep_line = BrTRUE;
#else
						CLine *pPrevLine = pLine->getPrev();
						BrBOOL bDiff = pPrevLine && pPrevLine->getFrame() != pLine->getFrame() ? BrTRUE : BrFALSE;

						if ((pPrevLine && pPrevLine->getNoteLineNum() == 0) || bDiff) {
							CLine *pOrgPrevLine = pPrevLine;
							pPrevLine = pPrevLine->getPrev();
							int pos_y = 0;

							if (pPrevLine == BrNULL || pPrevLine->getNoteLineNum() == 0 || bDiff) {
								if (bDiff && pPrevLine && pPrevLine->getNoteLineNum() != 0) {
									pos_y = rcFrame.Top();
								}
								else if (pOrgPrevLine) {
									pos_y = rcFrame.Top() + pOrgPrevLine->getBasePos() + pOrgPrevLine->getLineSp();
								}
								else {
									const PoParaAtt *paraAtt = para_att_h->getMergedParaAtt(pLine->getParaID(), pLine);

									//pos_y = rcFrame.Top() + pLine->getBasePos() - (pLine->getAscent());
									pos_y = rcFrame.Top() + pLine->getBasePos() + CTextProc::CalcLineSpace(document, pLine);

									if (!(pFrame->getArrangePos() != TOP_ARRANGE && pFrame->getFirstLine() == pLine)) {
										if (document->isFromWordType())
											pos_y -= 0x20;
										//pos_y -= para_att->getFrontParaSpace(pLine);
										else
											pos_y -= paraAtt->getFrontParaSpace(pLine);
									}
								}
							}
							DrawTypesetLine(dc, du, pFrame, 0, pos_y);		// DLE-103
							is_draw_sep_line = BrTRUE;
						}
#endif
					}

					pLine->setDisplayFlag(BrFALSE);
				}

				pLine = pLineList->getNextInFrame(pLine);
			}
		}
		else {  //if(!pFrame->isGaro())
			BrINT nPrevX = 0;
			nWidth = du.doc2LogicalDY((rcFrame.nBottom - rcFrame.nTop), BrFALSE);
			while (pLine != BrNULL) {
				if (CTextProc::isNoDisplayBullet(document, pLine)) {
					pLine = pLineList->getNextInFrame(pLine);
					continue;
				}

#ifdef USE_TEXTANIMATION_COUTDEV
				//Slide Show 이후 Page에서 도형이 보이지 않는 오유수정
				if (!pCmdEngine->isSlideShow())
					pLine->setIsShow(BrTRUE);
				//[2013.01.25][SlideEffect][Animation] add paragraph show flags
				if (!pCmdEngine->isSlideShowEditorPageDraw() && !pLine->getIsShow()) {
					pLine = pLineList->getNextInFrame(pLine);
					continue;
				}
#endif  // USE_TEXTANIMATION_COUTDEV
				//--- Check Clip Region -------------------------------------------
				// Get Invalidate Area of Line (page coordinate)
				if (!CTextProc::getInvalidateArea(document, pFrame, pLine, rcDraw))
					break;

				// logical coordinate
				du.doc2Logical(rcDraw);
				rcDraw.InflateRect(1,1);
				// Check clip region
				if (!document->IsInInvalidateRect(rcDraw)) {
					pLine = pLineList->getNextInFrame(pLine);
					continue;
				}
				//-----------------------------------------------------------------

				if (pLine->isDirty() == BrFALSE && pLine->getFlagOfPosArray()) {
					if (!CTextProc::getArrangeArea(document, pFrame, pLine, rcDraw)) {
						pLine = pLineList->getNextInFrame(pLine);
						continue;
					}
					nBandCount = CTextProc::makeRearrangeBand(document, pPage, pFrame, pLine, rcDraw, BrTRUE, pLine->getTableFlag() != 0);
					if (nBandCount < 1) {
						nBandCount = CTextProc::makeDefaultBand(rcDraw.nTop, rcDraw.nBottom);
					}

					if (pFrame->isTextFlowLeftToRight())
						sx = rcFrame.nLeft + pLine->getBasePos() - pLine->getHeight();		// SRG-1146
					else
						sx = rcFrame.nRight - pLine->getBasePos();

					// Default를 MS-Word 방식으로 한다. 하지만 HWP에서는 옛날 방식으로..
					// if ( !document->isFromHwp() )
					if (!document->isFromHwp()) {  // TID : 5810 2012-04-18
						BrINT nLineSp = CTextProc::CalcLineSpace(document, pLine, BrTRUE);
						if (pFrame->isTextFlowLeftToRight())
							sx += nLineSp / 2;
						else
							sx -= nLineSp / 2;
					}

					if (pFrame->isTextFlowBottomToTop())
						sy = rcFrame.nBottom;
					else
						sy = rcFrame.nTop;

					BPoint pt(sx, sy);
					du.doc2Logical(pt, BrTRUE);
					sx = pt.x;
					sy = pt.y;

					if (document->getBWPEngineMode() == EDITOR_WORD)
						DrawBackgroundOfSeroOneLine(dc, du, pFrame, pLine, sx, sy, nBandCount);

					CheckMultiMarkFindOfOneLineForSeekList(BrFALSE, document, dc, du, pFrame, pLine, sx, sy);

					if (pFrame->isBasic())
						DrawSeroLineNumber(dc, du, pLine, sx, sy);

					document->getCmdEngine()->m_bBwpDrawForeground = TEXT_NO_FOREGROUND;
					//[ZPD-988][2014.8.26]메모 show 일때 memo_icon 그리는 모드 on
					if (document->getRevisionEngine()->getMemoShowState())
						document->getCmdEngine()->m_bBwpDrawForeground |= TEXT_MEMO_ICON_FOREGROUND;
					DrawSeroOneLine(painter, dc, du, pFrame, pLine, sx, sy, nWidth, nBandCount);
					// Docx 문서에서 export 시 같은 글자 2번 그리는 문제
					if (!isExportMode())
					if (pLine->isRedraw())
						DrawSeroOneLine(painter, dc, du, pFrame, pLine, sx, sy, nWidth, nBandCount, BrFALSE);

					if (document->getCmdEngine()->m_bBwpDrawForeground != 0)
						DrawForegroundOfSeroOneLine(painter, dc, du, pFrame, pLine, sx, sy, nBandCount);

					if (BrFALSE == document->isViewOutlineMode() /*&& BrFALSE == document->isViewWebMode()*/
						&& document->isFromDoc() && !painter->pDC->isExportMode()) {
						document->getRevisionEngine()->drawSeroRevisionIndicator(dc, du, pLine, sx, nPrevX);
						nPrevX = sx;
					}

					if (pLine->getNoteLineNum() > 0) {
						CLine* pPrevLine = pLine->getPrev();
						if (pPrevLine && pPrevLine->getNoteLineNum() == 0) {
							CLine* pOrgPrevLine = pPrevLine;
							pPrevLine = pPrevLine->getPrev();
							if (pPrevLine == BrNULL || pPrevLine->getNoteLineNum() == 0) {  // 미주 영역에 표가 있는 경우 그려지는 문제 수정 [BNE-6527][johnkim][2014.09.12]
								if (pOrgPrevLine) {
									sx = rcFrame.Right() - pOrgPrevLine->getBasePos() - pOrgPrevLine->getLineSp();
								}
								else {
									const PoParaAtt* paraAtt = para_att_h->getMergedParaAtt(pLine->getParaID(), pLine);

									sx = rcFrame.Top() - pLine->getBasePos() + (pLine->getAscent());

									if (!(pFrame->getArrangePos() != TOP_ARRANGE && pFrame->getFirstLine() == pLine)) {
										if (document->isFromWordType())
											sx += 0x20;
										//sy -= para_att->getFrontParaSpace(pLine);
										else
											sx += paraAtt->getFrontParaSpace(pLine);
									}
								}
	#ifndef SUPPORT_ADVANCE_FENOTELINE
								DrawFENoteLine(dc, du, pLine);
	#else
								DrawTypesetLine(dc, du, pFrame, sx, 0);
	#endif
							}
						}
					}
					pLine->setDisplayFlag(BrFALSE);
				}
				pLine = pLineList->getNextInFrame(pLine);
			}
		}

	if (bSetClip)
		dc->setClipRect(&orgClipRect);

		if (pFrame->getExistParaDecoLine())
			DrawParaDecoLine(dc, du, pFrame);
		//[2012.09.05][inkkim] deco line까지는 direct export시킴. otherwise, export DC의 bitmap으로 덮어짐
		if (nOldMode != eNoneExtMode)
			dc->setExportMode(nOldMode);

		if (nTotalPage != document->getEditingTotalPage())
			document->InvalidateRect(BrNULL);
	} PO_THREAD_CATCH_BLOCK {
		if (nOldMode != eNoneExtMode)
			dc->setExportMode(nOldMode);
	} PO_THREAD_END
}


void CTextDraw::DrawShading(BrDC* dc, BRect* area, BrCOLORREF fill,
                            BrCOLORREF pattern, BrINT pattern_style)
{
	BrBmvBrush brushForShading, *oldBrushForShading;
	BrBmvPen penForShading, *oldpenForShading;
	BrINT nPatternStyleForPen;
	BrBOOL bIsCommonPattern = BrTRUE;

	if (fill == NONE_COLOR_BITS && pattern == NONE_COLOR_BITS)
		return;

	if (fill == NONE_COLOR_BITS && pattern_style == -1)
		return;

	if (pattern_style == BR_SHADING_PATTERN_STYLE_100_PER) {
		nPatternStyleForPen = BR_SHADING_PATTERN_STYLE_5_PER;
		fill = pattern;
		bIsCommonPattern = BrFALSE;
	}
	else if (pattern_style == BR_SHADING_PATTERN_STYLE_ERASE) {
		nPatternStyleForPen = BR_SHADING_PATTERN_STYLE_5_PER;
		pattern = fill;
		bIsCommonPattern = BrFALSE;
	}
	else if ((fill == NONE_COLOR_BITS || fill == RGB_WHITE || (fill | 0xff000000) == RGB_WHITE) &&
	    (pattern == RGB_BLACK || (0xff000000 | pattern) == RGB_BLACK)) {
		BrDOUBLE dPer = CTextDraw::ShadingPatternStylePercent(pattern_style);
		if (dPer == -1) {
			bIsCommonPattern = BrTRUE;
		}
		else {
			dPer = (BrDOUBLE)1.0 - dPer;
			if (fill == NONE_COLOR_BITS)
				fill = RGB_WHITE;

			pattern = BrRGB(((BrBYTE)(GetRValue(fill) * dPer)),
			                ((BrBYTE)(GetGValue(fill) * dPer)),
			                ((BrBYTE)(GetBValue(fill) * dPer)));
			fill = pattern;

			nPatternStyleForPen = BR_SHADING_PATTERN_STYLE_5_PER;
			bIsCommonPattern = BrFALSE;
		}
	}

	if (bIsCommonPattern) {
		nPatternStyleForPen = ShadingPatternStyleForDCBrush(pattern_style);
		if (nPatternStyleForPen == -1) //Getting Pattern Style is fail.
			return;
		if (fill == NONE_COLOR_BITS)
			fill = RGB_WHITE;
	}

	penForShading.createPen(eNullPen, 0, 0, 0, 0);
	oldpenForShading = dc->setPen(&penForShading);

	brushForShading.createPatternBrush((LPBYTE)&g_bPatterns[nPatternStyleForPen * 8], fill, pattern);
	oldBrushForShading = dc->setBrush(&brushForShading);

	dc->fillRect(area->nLeft, area->nTop, area->nRight, area->nBottom);
	dc->setBrush(oldBrushForShading);
	dc->setPen(oldpenForShading);
}


BrINT CTextDraw::ShadingPatternStyleForDCBrush(BrINT shading_pattern_style)
{
	switch (shading_pattern_style) {
		case BR_SHADING_PATTERN_STYLE_2_5_PER:              FALLTHROUGH;
		case BR_SHADING_PATTERN_STYLE_5_PER:                return 0;
		case BR_SHADING_PATTERN_STYLE_7_5_PER:              FALLTHROUGH;
		case BR_SHADING_PATTERN_STYLE_10_PER:               FALLTHROUGH;
		case BR_SHADING_PATTERN_STYLE_12_5_PER:             FALLTHROUGH;
		case BR_SHADING_PATTERN_STYLE_15_PER:               return 1;
		case BR_SHADING_PATTERN_STYLE_20_PER:               return 2;
		case BR_SHADING_PATTERN_STYLE_25_PER:               return 3;
		case BR_SHADING_PATTERN_STYLE_30_PER:               return 4;
		case BR_SHADING_PATTERN_STYLE_35_PER:               FALLTHROUGH;
		case BR_SHADING_PATTERN_STYLE_37_5_PER:             return 54;
		case BR_SHADING_PATTERN_STYLE_40_PER:               FALLTHROUGH;
		case BR_SHADING_PATTERN_STYLE_45_PER:               return 5;
		case BR_SHADING_PATTERN_STYLE_50_PER:               FALLTHROUGH;
		case BR_SHADING_PATTERN_STYLE_55_PER:               return 6;
		case BR_SHADING_PATTERN_STYLE_60_PER:               FALLTHROUGH;
		case BR_SHADING_PATTERN_STYLE_62_5_PER:             FALLTHROUGH;
		case BR_SHADING_PATTERN_STYLE_65_PER:               return 25;
		case BR_SHADING_PATTERN_STYLE_70_PER:               return 7;
		case BR_SHADING_PATTERN_STYLE_75_PER:               return 26;
		case BR_SHADING_PATTERN_STYLE_80_PER:               return 27;
		case BR_SHADING_PATTERN_STYLE_85_PER:               FALLTHROUGH;
		case BR_SHADING_PATTERN_STYLE_87_5_PER:             return 55;
		case BR_SHADING_PATTERN_STYLE_90_PER:               FALLTHROUGH;
		case BR_SHADING_PATTERN_STYLE_95_PER:               return 28;
		case BR_SHADING_PATTERN_STYLE_DK_HORIZONTAL:        return 9;
		case BR_SHADING_PATTERN_STYLE_DK_VERTICAL:          return 10;
		case BR_SHADING_PATTERN_STYLE_DK_DOWN_DIAGONAL:     return 38;
		case BR_SHADING_PATTERN_STYLE_DK_UP_DIAGONAL:       return 39;
		case BR_SHADING_PATTERN_STYLE_DK_GRID:              return 13;
		case BR_SHADING_PATTERN_STYLE_DK_TRELLIS:           return 14;
		case BR_SHADING_PATTERN_STYLE_LIGHT_HORIZONTAL:     return 15;
		case BR_SHADING_PATTERN_STYLE_LIGHT_VERTICAL:       return 16;
		case BR_SHADING_PATTERN_STYLE_LIGHT_DOWN_DIAGONAL:  return 17;
		case BR_SHADING_PATTERN_STYLE_LIGHT_UP_DIAGONAL:    return 18;
		case BR_SHADING_PATTERN_STYLE_LIGHT_GRID:           return 19;
		case BR_SHADING_PATTERN_STYLE_LIGHT_TRELLIS:        return 20;
	}
	return -1;
}


#ifndef SUPPORT_ADVANCE_FENOTELINE
void CTextDraw::DrawFENoteLine(BrDC* dc, CDrawUnit& du, CLine* pLine)
{
	if (pLine == BrNULL)
		return;
	
	CFrame *pFrame = pLine->getFrame();
	if (pFrame->bottom() == pFrame->top())
		return;

	// check all endnote is deleted
	CLine *item_line = pLine;
	while (item_line) {
		if (!item_line->isDeletedRev())
			break;
		item_line = item_line->getNext();
	}
	
	if (!item_line)
		return;

	if (!(pLine->getFrame() && !pLine->isDirty()) && pLine->getNoteLineNum() > 0)
		return;

	if (!(pLine->getFrame()->isBasic() || pLine->getFrame()->isNote()))
		return;

	if (pLine->getNoteLineNum() > 1 && pLine->getPrev() && pLine->getPrev()->getFrame() == pLine->getFrame())
		return;

	if (theBWordDoc->isFromHwp() && pLine->isEndNoteLine()) {
		if (pLine->getPrev() && pLine->getPrev()->getNoteLineNum() > 0 && pLine->getPage()->getFirstLine() == pLine)
			return;
	}

	if ((theBWordDoc->isFromHwp() || theBWordDoc->isFromOdt()) && pLine->isEndNoteFirstLine() && pLine->getPage()->getFirstLine() == pLine)
		return;

	BoraDoc* document = theBWordDoc;
	CNote* pNote = BrNULL;

	BPoint sPt, ePt;
	BRect* pRect = pFrame->getFrameRect();
	BrINT nMargin, nLen, nAdaptColLen;
#ifdef SIMPLE_NOTE
	BrBorderLineStyle separateLineStyle = BORDER_LINE_STYLE_None;
	BrINT nSeparateLineColor = RGB_BLACK;
	BrINT nSeparateLineThickness = 1;
#else
	CDrawLine* pDrawLine = BrNULL;
#endif
	CSectionInfomation* pSecInfo = BrNULL;
	BrBOOL isEndNote = BrFALSE;
	CLine* pSecLine = BrNULL;

	pNote = document->getFEEngine()->noteInfoForSep(pLine);
	if (!pNote)
		return;

	if (pLine->getFrame()->isBasic())	// 미주
	{
		isEndNote = BrTRUE;
	}

	nAdaptColLen = pRect->Right() - pRect->Left();
#ifdef SIMPLE_NOTE
	if (pNote->getSeparateLineStyle() != BORDER_LINE_STYLE_None)
#else
	if (pNote->isSeparateLine())
#endif
	{
		nMargin = pNote->getLineThickness() / 2 + pNote->getLineBottomMargin();
		nLen = pNote->getLineLen(pSecInfo);
		BrINT nFrameWidth = pFrame->right() - pFrame->left();
		if (pFrame->getDirection() != PORTRAIT)
			nFrameWidth = pFrame->bottom() - pFrame->top();

		if (document->isFromDoc() && isEndNote) {
			CPage* pCurPage = pLine->getPage();
			if (pCurPage && pCurPage->getPrev()) {
				CPage* pPrev = pCurPage->getPrev();
				if (pPrev && pPrev->getLastLine() && pPrev->getLastLine()->isEndNoteLine())
					nLen = nFrameWidth;
			}
		}

		if (document->isFromHwp()) {
			if (nFrameWidth < nLen)
				nLen = nFrameWidth;
		}
		else {
			if (nFrameWidth < nLen)
				nLen = nFrameWidth * 0.8f;
		}

		BrINT pos = 0;
		if (isEndNote)
			pos = pLine->getBasePos() - pLine->getHeight();

		if (pFrame->getDirection() == PORTRAIT) {

			sPt.y = ePt.y = pRect->Top() - nMargin + pos;

			if (document->isBidiFlag()) {
				ePt.x = pRect->Right();
				sPt.x = ePt.x - nLen;
			}
			else {
				sPt.x = pRect->Left();
				ePt.x = sPt.x + nLen;
			}
		}
		else {
			sPt.x = ePt.x = pRect->Right() + nMargin - pos;

			if (document->isBidiFlag()) {
				ePt.x = pRect->Bottom();
				sPt.x = ePt.x - nLen;
			}
			else {
				sPt.y = pRect->Top();
				ePt.y = sPt.y + nLen;
			}
		}

#ifdef SIMPLE_NOTE
		separateLineStyle = pNote->getSeparateLineStyle();
		nSeparateLineColor = pNote->getColor();
		nSeparateLineThickness = pNote->getLineThickness();
#else
		pDrawLine = pNote->getDrawLine();
#endif
	}

	BPoint sp(0, 0), ep;
	ep.x = ePt.x - sPt.x;
	ep.y = ePt.y - sPt.y;

#ifdef SIMPLE_NOTE
	if (separateLineStyle != BORDER_LINE_STYLE_None)
#else
	if (pDrawLine)
#endif
	{
		BrBYTE nOldMode = dc->setExportMode(eDirectExtMode);
		BPoint offset;
		BRect rect(sPt.x, sPt.y, ePt.x, ePt.y);

		du.doc2LogicalD(rect, true);
		du.doc2LogicalD(sp, true);
		du.doc2LogicalD(ep, true);

		// HEJ-1568 word문서 메모 있는 경우 pdf export 및 print시 offset 계산에 오류가 있어 수정
		if (dc->getExportMode() == ePDFExtDCType) {
			offset = du.getOffset();
			sp.Offset(rect.nLeft + offset.x, rect.nTop + offset.y);
			ep.Offset(rect.nLeft + offset.x, rect.nTop + offset.y);
		}
		else {
			du.getPageStart(offset);
			sp.Offset(rect.nLeft - offset.x, rect.nTop - offset.y);
			ep.Offset(rect.nLeft - offset.x, rect.nTop - offset.y);
		}

		if (document->isFromHwp()) {
#ifdef SIMPLE_NOTE
			BrINT nWidth = twips2DeviceX(nSeparateLineThickness, du.getZoomFactor(), du.getXResolution());
			if (nWidth < 1)
				nWidth = 1;
			BrINT style = BrUtil::BrBorderLineStyle2Engine(separateLineStyle);
			BrDrawObj::drawLine(dc, sp.x, sp.y, ep.x, ep.y, style, nWidth, nSeparateLineColor);
#else
			BrINT nWidth = twips2DeviceX(pDrawLine->getLineWidth(), du.getZoomFactor(), du.getXResolution());
			CCUtil::drawLine(dc, sp.x, sp.y, ep.x, ep.y, nWidth, pDrawLine->getLineColor(), pDrawLine->getLineStyle(), pDrawLine->getDashStyle());
#endif
		}
		else
			CCUtil::drawLine(dc, sp.x, sp.y, ep.x, ep.y, 1, RGB_BLACK);

		//[2012.09.13][inkkim] direct export 설정
		if (nOldMode != eNoneExtMode)
			dc->setExportMode(nOldMode);
	}
}
#else
void CTextDraw::DrawTypesetLine(BrDC* dc, CDrawUnit& du, CFrame* pFrame, BrINT sx, BrINT sy)
{
	if (BrNULL == pFrame)
		return;

	CPage* pPage = pFrame->getPage();
	if (BrNULL == pPage)
		return;

	//[2012.09.13][inkkim] direct export 설정
	BrBYTE nOldMode = dc->setExportMode(eDirectExtMode);

	BPoint sPt, ePt;
	BRect* pRect = pFrame->getFrameRect();
	BYTE bClass = pFrame->GetClass();
	CColumn* pColumn = pPage->getColumn();
	// BYTE bDirection = pColumn->getDirection();
	BrINT nMargin, nLen, nAdaptColLen;
	CDrawLine* pDrawLine = BrNULL;
	BoraDoc* document = theBWordDoc;

	if (NOTEFRAME == bClass || FIXFRAME == bClass) {
		CTypesetInfo* pTypesetInfo = document->getTypesetInfo();
		CNote* pNoteOpt = BrNULL;
		CSectionInfomation* pSecInfo = BrNULL;
		if (document->isFromHwp()) {
			if (pFrame->getPage()->getSectionLine())
				pSecInfo = pFrame->getPage()->getSectionLine()->getSectionInformation();
			if (pSecInfo && (NOTEFRAME == bClass))
				pNoteOpt = pSecInfo->getFootNote();
			else if (pSecInfo)
				pNoteOpt = pSecInfo->getEndNote();
			else
				return;
		}
		else
			pNoteOpt = (NOTEFRAME == bClass)? pTypesetInfo->getFootnoteOption(): pTypesetInfo->getEndnoteOption();

		nAdaptColLen = pRect->Right() - pRect->Left();
		if (pNoteOpt->isSeparateLine()) {
			nMargin = pNoteOpt->getLineThickness() / 2 + pNoteOpt->getLineTopMargin();
			nLen = pNoteOpt->getLineLen(pSecInfo);

			/*nLen = pNoteOpt->isAdaptColSize()? nAdaptColLen: pNoteOpt->getLineLen();*/

			BrINT nFrameWidth = pFrame->right() - pFrame->left();
			if (document->isFromHwp()) {
				if (nFrameWidth < nLen)
					nLen = nFrameWidth;
			}
			else {
				if (nFrameWidth < nLen)
					nLen = nFrameWidth * 0.8f;
			}


			if (pFrame->getDirection() == PORTRAIT) {
				if (sy != 0)
					sPt.y = ePt.y = sy + nMargin;
				else
					sPt.y = ePt.y = pRect->Top() - nMargin;

				if (document->isBidiFlag()) {
					ePt.x = pRect->Right();
					sPt.x = ePt.x - nLen;
				}
				else {
					sPt.x = pRect->Left();
					ePt.x = sPt.x + nLen;
				}
			}
			else {
				if (sx != 0)
					sPt.x = ePt.x = sx - nMargin;
				else
					sPt.x = ePt.x = pRect->Right() + nMargin;

				if (document->isBidiFlag()) {
					ePt.x = pRect->Bottom();
					sPt.x = ePt.x - nLen;
				}
				else {
					sPt.y = pRect->Top();
					ePt.y = sPt.y + nLen;
				}
			}

			pDrawLine = pNoteOpt->getDrawLine();
		}
		else {
			if (nOldMode != eNoneExtMode)
				dc->setExportMode(nOldMode);
			return;
		}
	}

	BPoint sp(0, 0), ep;
	ep.x = ePt.x - sPt.x;
	ep.y = ePt.y - sPt.y;

	if (pDrawLine) {
		//기존 bwDrawLine->draw() 내에서 pen 컬러값 셋팅이 불가능하여 CUtil의 drawLine 사용
		BPoint offset;

		//pDrawLine->setCoordinate(sp, ep);

		BRect rect(sPt.x, sPt.y, ePt.x, ePt.y);

		du.doc2LogicalD(rect, true);
		du.doc2LogicalD(sp, true);
		du.doc2LogicalD(ep, true);

		du.getPageStart(offset);
		sp.Offset(rect.nLeft - offset.x, rect.nTop - offset.y);
		ep.Offset(rect.nLeft - offset.x, rect.nTop - offset.y);

		if (document->isFromHwp()) {
			BrINT nWidth = twips2DeviceX(pDrawLine->getLineWidth(), du.getZoomFactor(), du.getXResolution());
			CCUtil::drawLine(dc, sp.x, sp.y, ep.x, ep.y, nWidth, pDrawLine->getLineColor(), pDrawLine->getLineStyle(), pDrawLine->getDashStyle());
		}
		else
			CCUtil::drawLine(dc, sp.x, sp.y, ep.x, ep.y, 1, RGB_BLACK);
		//pDrawLine->draw(painter, dc, rect, du, BrFALSE);
	}

	//[2012.09.13][inkkim] direct export 설정
	if (nOldMode != eNoneExtMode)
		dc->setExportMode(nOldMode);
}
#endif


void CTextDraw::DrawParaDecoBackground(BrDC* dc, CDrawUnit& du, CFrame* pFrame)
{
	BoraDoc* document = theBWordDoc;
	if (document == BrNULL || pFrame == BrNULL)
		return;
	if (document->isViewOutlineMode())
		return;

	//저시력자용 색상 모드 지원
	BrCOLORREF nLowVisionTextColor = NONE_COLOR_BITS;
	BrCOLORREF nLowVisionBackColor = NONE_COLOR_BITS;
	if (document->getCmdEngine()->GetLowVisionEngine() && document->getCmdEngine()->GetLowVisionEngine()->IsLowVisionColorMode(nLowVisionTextColor, nLowVisionBackColor))
		return;

	CLine* pELine;

	CLineList* pLineList = (CLineList*)pFrame->getSubFrame();
	CLine* pSLine = pLineList->getFirst();
	PoParaAttHandler* para_att_h = document->getParaAttHandler();
	while (pSLine != BrNULL) {
		pSLine = ParaDecoBackgroundStartLine(para_att_h, pFrame, pLineList, pSLine);
		if (pSLine == BrNULL)
			return;

		pELine = ParaDecoBackgroundEndLine(para_att_h, pFrame, pLineList, pSLine);
		if (pELine == BrNULL)
			return;

		BRect rcLine1;
		BRect rcLine2;
		BRect rcDraw;

		if (CalcParaDecoDrawArea(document, pFrame, pSLine, rcLine1) &&
		    CalcParaDecoDrawArea(document, pFrame, pELine, rcLine2)) {
			const PoParaAtt* paraAtt = para_att_h->getParaAtt(pELine->getParaID());

			rcDraw.UnionRect(rcLine1, rcLine2);

			//[2014-02-04][M-46530][T-23576][20hoon] //단락 테두리가 없으면, Left, Right에 2.0pt에 더해져서 단락음영 그려짐
			if (pFrame->isBasic()) //2014-09-11 //20hoon //Basic 프레임일때만, 위의 사항 적용합니다.
			{
				if (document->isFromHwp() && pFrame->getPage() && rcDraw.nRight + 5 > pFrame->getPage()->width())
					rcDraw.nRight -= 30;
				else {
					/*
					if ( paraAtt->isSettedParaBorderLineInfo() )
					{
						CBorderLineInfo* pBorderLineInfo = paraAtt->getParaBorderLineInfo();
						if (pBorderLineInfo && pBorderLineInfo->getLeftBorderLine())
							rcDraw.nLeft -= 40;

						if (pBorderLineInfo && pBorderLineInfo->getRightBorderLine())
							rcDraw.nRight += 40;
							}
					*/
				}
			}

			du.doc2Logical(rcDraw, BrTRUE);

			//[2013-10-07][T-17832][20hoon]
			DrawShading(dc, &rcDraw, paraAtt->getShadingFillColor().getColor(),
			            paraAtt->getShadingPatternColor().getColor(),
			            paraAtt->getShadingPatternStyle());
		}
		pSLine = pLineList->getNextInFrame(pELine);
	}
}


CLine* CTextDraw::ParaDecoBackgroundStartLine(PoParaAttHandler* para_att_h, CFrame* pFrame,
                                              CLineList* pLineList, CLine* pLine)
{
	const PoParaAtt* pParaAtt = BrNULL;
	if (para_att_h == BrNULL)
		return BrNULL;

	while (pLine) {
		if (pLine->isOverflow() || pLine->isDirty())
			break;

		pParaAtt = para_att_h->getMergedParaAtt(pLine->getParaID(), pLine);

		//CSP-1796 //20hoon SectionBreak만 있는 라인은 파라음영, 파라 테두리 랜더링에서 제외합니다.
		//Page Break만 있는 라인도 파라음영, 파라 테두리 랜더링에서 제외
		if ((pLine->isSectionBreak() == BrTRUE && pLine->isOnlyCR() == BrTRUE) ||
		    (pLine->isPageOrColBreak() == BrTRUE && pLine->isOnlyCR() == BrTRUE)) {
			pLine = pLineList->getNextInFrame(pLine);
			continue;
		}

		if (!pFrame->getExistParaDecoLine() && pParaAtt->getParaBorderLineInfo())
			pFrame->setExistParaDecoLine(BrTRUE);

		if (pParaAtt->isNeedToDrawShading() == BrTRUE)
			return pLine;

		pLine = pLineList->getNextInFrame(pLine);
	}

	return BrNULL;
}


CLine* CTextDraw::ParaDecoBackgroundEndLine(PoParaAttHandler* para_att_h, CFrame* pFrame,
                                            CLineList* pLineList, CLine* pLine)
{
	BrINT nParaID;

	BrINT nSaveID = pLine->getParaID();
	const PoParaAtt* paraAtt = para_att_h->getParaAtt(nSaveID);

	//[2013-10-07][T-17832 ][20hoon]
	//BYTE bFillPattern= pParaAtt->getBorder().m_bFillPattern; //old
	//BrCOLORREF dwFillColor = pParaAtt->getBorder().m_FillColor.getColor();  //old
	//BrCOLORREF dwBackColor = pParaAtt->getBorder().m_BackColor.getColor();  //old
	BrCHAR bFillPattern = paraAtt->getShadingPatternStyle();
	BrCOLORREF dwFillColor = paraAtt->getShadingFillColor().getColor();
	BrCOLORREF dwBackColor = paraAtt->getShadingPatternColor().getColor();
	BrINT nParaLeftMargin = paraAtt->getLeftMargin();
	BrINT nParaRightMargin = paraAtt->getRightMargin();

	CLine* pSaveLine = pLine;
	pLine = pLineList->getNextInFrame(pLine);
	while (pLine != BrNULL) {
		if (pLine->isOverflow() || pLine->isDirty())
			break;
		nParaID = pLine->getParaID();

		//CSP-1796 //20hoon SectionBreak만 있는 라인은 파라음영, 파라 테두리 랜더링에서 제외합니다.
		//Page Break만 있는 라인도 파라음영, 파라 테두리 랜더링에서 제외
		if ((pLine->isSectionBreak() == BrTRUE && pLine->isOnlyCR() == BrTRUE) ||
		    (pLine->isPageOrColBreak() == BrTRUE && pLine->isOnlyCR() == BrTRUE)
		) {
			pLine = pLineList->getNextInFrame(pLine);
			break;
		}


		if (nParaID != nSaveID) {
			paraAtt = para_att_h->getMergedParaAtt(pLine->getParaID(), pLine);

			if (!pFrame->getExistParaDecoLine() && paraAtt->getParaBorderLineInfo())
				pFrame->setExistParaDecoLine(BrTRUE);

			//[2013-10-07][T-17832][20hoon]
			if (bFillPattern != paraAtt->getShadingPatternStyle() ||
			    dwFillColor != paraAtt->getShadingFillColor().getColor() ||
			    dwBackColor != paraAtt->getShadingPatternColor().getColor() ||
			    nParaLeftMargin != paraAtt->getLeftMargin() ||
			    //M-44519 //20hoon //단락 인덴트가 다르면 파라 음영을 이어서 그리지 않습니다.
			    nParaRightMargin != paraAtt->getRightMargin()) {
				break;
			}
		}
		pSaveLine = pLine;
		pLine = pLineList->getNextInFrame(pLine);
	}
	return pSaveLine;
}


BrBOOL CTextDraw::CalcParaDecoDrawArea(BoraDoc* document, CFrame* pFrame, CLine* pLine, BRect& rcDraw)
{
	rcDraw.setRect(0, 0, 0, 0);
	if (document == BrNULL || pFrame == BrNULL || pLine == BrNULL)
		return BrFALSE;

	BrINT nBaseLine = pLine->getBasePos();
	if (nBaseLine == OVER_FRAME || nBaseLine == 0)
		return BrFALSE;

	BRect rcFrame = pFrame->getFrameRect();
	//[XPD-4634][2016-07-03]도형 회전시 테두리 위치 오류 수정.
	if (document->isFromHwp() && pFrame->GetRotation() != 0)
		BrDrawUnit::getContainerRect(pFrame->getFrameRect(), pFrame->GetRotation(), rcFrame);

	BrINT nLineTop;
	BrINT nLineHgt;
	PoParaAttHandler* para_att_h = theBWordDoc->getParaAttHandler();
	const PoParaAtt* pParaAtt = para_att_h->getMergedParaAtt(pLine->getParaID(), pLine);

	BrINT nLineSp = pParaAtt->getLineSpace(pLine, BrTRUE, BrFALSE);
	// ODT에서는 단락 음영의 마지막 라인에서는 Line Sp를 포함시키지 않음 HEJ-1453
	if (nLineSp > 0 && document->isFromOdt() && pLine->getNextInFrame() == BrNULL)
		nLineSp = pLine->getDisplayLineSp(document);

	//[RGD-406][2014-06-16][20hoon] 헤더/푸터도 본문과 같은 루틴을 타게 수정
	if (pFrame->isBasic() || pFrame->isHeader() || pFrame->isFooter()) {
		CLine* pNextLine = BrNULL;
		CLine* pPrevLine = BrNULL;
		const PoParaAtt* pNextLineParaAtt = BrNULL;
		const PoParaAtt* pPrevLineParaAtt = BrNULL;

		nLineTop = nBaseLine - pLine->getAscent();
		nLineHgt = pLine->getHeight() + nLineSp;// + DEF_MARGIN_TWIP; //[M-25742] hnsong:2013-07-02  아래 라인스페이스에 걸쳐진다!

		//LINESP_UNIT_FIX, LINESP_UNIT_ATLEAST 등일때 line space가 마이너스인 경우 보정 //[CDT-3083] DOC, DOCX로 한정
		if (nLineSp < 0 && document->isFromDoc() && (pParaAtt->getLineSpaceUnit() == LINESP_UNIT_FIX || pParaAtt->getLineSpaceUnit() == LINESP_UNIT_ATLEAST))
			nLineHgt += nLineSp - DEF_MARGIN_TWIP / 2;

		BrBOOL bFrontSpace = BrFALSE;
		BrBOOL bBackSpace = BrFALSE;

		//2013-12-05 AM //[M-45359][M-44519][20hoon]
		pNextLine = pLine->getLastLineOfPara();
		if (pNextLine != BrNULL) {
			pNextLine = pNextLine->getNextInFrame();
			if (pNextLine != BrNULL) {
				pNextLineParaAtt = document->getParaAttHandler()->getParaAtt(pNextLine->getParaID());
				//M-44519 //20hoon //단락 인덴트가 다르면 파라 음영을 이어서 그리지 않습니다.
				if (pNextLineParaAtt->isNeedToDrawShading() && pParaAtt->canCombineDeco(*pNextLineParaAtt))
					bBackSpace = BrTRUE;
			}
		}

		pPrevLine = pLine->getPrevInFrame();
		if (pPrevLine != BrNULL && pLine->isStartLine() == BrTRUE) {
			pPrevLineParaAtt = document->getParaAttHandler()->getParaAtt(pPrevLine->getParaID());

			//M-44519 //20hoon //단락 인덴트가 다르면 파라 음영을 이어서 그리지 않습니다.
			if (pPrevLineParaAtt->isNeedToDrawShading() && pParaAtt->canCombineDeco(*pPrevLineParaAtt))
				bFrontSpace = BrTRUE;
		}

		if (bFrontSpace || (getDocType() == BORA_DOCTYPE_HWP && pLine->isStartLine() && !pParaAtt->getIgnoreParaMargin())) {
			nLineTop -= pParaAtt->getFrontParaSpace(pLine);
			nLineHgt += pParaAtt->getFrontParaSpace(pLine);
		}
		if (bBackSpace || (getDocType() == BORA_DOCTYPE_HWP && pLine->isEndLine() && !pParaAtt->getIgnoreParaMargin())) {
			nLineHgt += pParaAtt->getBackParaSpace(pLine);
		}
	}
	else {  //프레임이 도형일때...
		nLineTop = nBaseLine - pLine->getAscent();
		nLineHgt = pLine->getHeight() + pParaAtt->getLineSpace(pLine);

		//ZPD-30453 아래를 하지 않아야 단락 테두리가 제대로 그려짐.
		//if( pLine->isStartLine() )
		//{
		//	if( ! (pFrame->getArrangePos()!=TOP_ARRANGE && pFrame->getFirstLine()==pLine) )
		//	{
		//		nLineTop -= pParaAtt->getFrontParaSpace(pLine);
		//		nLineHgt += pParaAtt->getFrontParaSpace(pLine);
		//	}
		//}
		//if( pLine->isEndLine() )
		//{
		//	if( pFrame->getLastLine() != pLine )
		//		nLineHgt += pParaAtt->getBackParaSpace(pLine);
		//}


		if (nLineSp < 0)
			nLineHgt += nLineSp;

		if (document->isFromWordType() && !pFrame->isTable() && !pFrame->isCell()) {
			// bottom
			// Special Text Frame의 마지막 라인인 경우 bottom을 text frame의 끝으로 처리한다.
			if (pFrame->getBorderStyle() == SHAPE_Rectangle ||
					pFrame->getBorderStyle() == SHAPE_HostControl ||
					pFrame->getBorderStyle() == SHAPE_TextBox) {
				if (pLine->getNext() == BrNULL && pParaAtt->isSettedParaBorderLineInfo()) {
					CBorderLineInfo* pBorderLineInfo = pParaAtt->getParaBorderLineInfo();
					BrINT nTmpLineHgt = nLineHgt;
					if (pFrame->isGaro()) {
						nTmpLineHgt = (rcFrame.nBottom - pFrame->getBorderMarginBottom()) - (nLineTop + rcFrame.nTop);
						if (pBorderLineInfo && pBorderLineInfo->getBottomBorderLine())
							nTmpLineHgt -= (pBorderLineInfo->getBottomBorderLine()->getBorderLineSpace() + pBorderLineInfo->getBottomBorderLine()->getBorderLineWidth());
					}
					else if (pFrame->isSero()) {
						nTmpLineHgt = (rcFrame.nRight - pFrame->getBorderMarginLeft()) - (nLineTop + rcFrame.nLeft);
						if (pBorderLineInfo && pBorderLineInfo->getLeftBorderLine())
							nTmpLineHgt -= (pBorderLineInfo->getLeftBorderLine()->getBorderLineSpace() + pBorderLineInfo->getLeftBorderLine()->getBorderLineWidth());
					}
					if (nTmpLineHgt > nLineHgt)
						nLineHgt = nTmpLineHgt;
				}
			}
		}
	}

	CBorderLineInfo* pBorderLineInfo = BrNULL;
	if (pParaAtt->isSettedParaBorderLineInfo())
		pBorderLineInfo = pParaAtt->getParaBorderLineInfo();

	if (pFrame->isGaro() == BrTRUE) {
		//ZPD-29140:도형 내분에서 텍스트 편집 영역만큼만 테두리 작히도록 수정.
		BRect rcBorderMarginWithText = pFrame->getBorderMarginWithText();
		rcFrame.Left() += rcBorderMarginWithText.Left();
		rcFrame.Right() -= rcBorderMarginWithText.Right();

		// word memo frame에서는 left margin, right margin을 정렬에서 고려하지 않기 때문에 동일하게 적용 POD-2216
		if ((getDocType() == BORA_DOCTYPE_HWP && !pParaAtt->getIgnoreParaMargin()) || pFrame->isWordMemoFrame()) {
			rcDraw.nLeft = rcFrame.nLeft;
			rcDraw.nRight = rcFrame.nRight;
		}
		else {
			rcDraw.nLeft = rcFrame.nLeft + pParaAtt->getLeftMargin();
			rcDraw.nRight = rcFrame.nRight - pParaAtt->getRightMargin();
		}
		rcDraw.nTop = rcFrame.nTop + nLineTop;
		rcDraw.nBottom = rcDraw.nTop + nLineHgt;

		if (pBorderLineInfo) {
			if (pBorderLineInfo->getLeftBorderLine() && pBorderLineInfo->getLeftBorderLine()->getBorderLineArtStyle() != BR_ART_BORDER_NONE)
				rcDraw.nLeft -= pBorderLineInfo->getLeftBorderLine()->getBorderLineSpace() + pBorderLineInfo->getLeftBorderLine()->getBorderLineWidth() / 2;

			if (pBorderLineInfo->getRightBorderLine() && pBorderLineInfo->getRightBorderLine()->getBorderLineArtStyle() != BR_ART_BORDER_NONE)
				rcDraw.nRight += pBorderLineInfo->getRightBorderLine()->getBorderLineSpace() + pBorderLineInfo->getRightBorderLine()->getBorderLineWidth() / 2;

			if (pFrame->isBasic() && pFrame->getFrameRect()->Bottom() == rcDraw.nBottom && pBorderLineInfo->getBottomBorderLine())
				rcDraw.nBottom -= pBorderLineInfo->getBottomBorderLine()->getBorderLineWidth();
		}

		//[2013-11-13][20hoon]
		if (pLine->isStartLine() || pLine->isEndLine()) {
			//ZPD-909 //2014-10-09 //20hoon
			//HWP는 위와 아래의 테두리를 따로 줄수 있으므로, 위와 아래의 테두리 굵기를 따로 구한다.
			BrINT max_border_top = CTextProc::FindMaxBorderLineWidth(pLine, BR_BORDER_LINE_POS_TOP);
			BrINT max_border_bottom = CTextProc::FindMaxBorderLineWidth(pLine, BR_BORDER_LINE_POS_BOTTOM);

			if (pLine->isStartLine()) {
				if (pBorderLineInfo && pBorderLineInfo->getTopBorderLine() && pBorderLineInfo->getTopBorderLine()->getBorderLineArtStyle() != BR_ART_BORDER_NONE) {
					if (document->getDocType() == BORA_DOCTYPE_HWP)
						rcDraw.nTop -= pBorderLineInfo->getTopBorderLine()->getBorderLineSpace();	//ZPD-16500 확대 시 단란 테두리 위/아래 라인이 겹침
					else
						rcDraw.nTop -= (pBorderLineInfo->getTopBorderLine()->getBorderLineSpace() + pBorderLineInfo->getTopBorderLine()->getBorderLineWidth() / 2);
				}
				rcDraw.nTop -= max_border_top;
			}
			if (pLine->isEndLine()) {
				if (pBorderLineInfo && pBorderLineInfo->getBottomBorderLine() && pBorderLineInfo->getBottomBorderLine()->getBorderLineArtStyle() != BR_ART_BORDER_NONE) {
					if (document->getDocType() == BORA_DOCTYPE_HWP)
						rcDraw.nBottom += pBorderLineInfo->getBottomBorderLine()->getBorderLineSpace();	//ZPD-16500 확대 시 단란 테두리 위/아래 라인이 겹침
					else
						rcDraw.nBottom += (pBorderLineInfo->getBottomBorderLine()->getBorderLineSpace() - pBorderLineInfo->getBottomBorderLine()->getBorderLineWidth() / 2);	// WPD-1226
				}
				rcDraw.nBottom += max_border_bottom;
			}
		}

		//ZPD-24862 셀에 단락음영 적용 후 음영이 셀 영역을 벗어나지 않게
		if (pFrame->isTable() || pFrame->isCell()) {
			if (pBorderLineInfo) {
				if (pLine == pFrame->getLastLine() && (rcDraw.nBottom > rcFrame.nBottom) && pBorderLineInfo->getBottomBorderLine())
					rcDraw.nBottom = rcFrame.nBottom - pBorderLineInfo->getBottomBorderLine()->getBorderLineWidth();

				if (pLine == pFrame->getFirstLine() && (rcDraw.nTop < rcFrame.nTop) && pBorderLineInfo->getTopBorderLine())
					rcDraw.nTop = rcFrame.nTop + pBorderLineInfo->getTopBorderLine()->getBorderLineWidth();

				if (rcFrame.nLeft > rcDraw.nLeft && pBorderLineInfo->getLeftBorderLine())
					rcDraw.nLeft = rcFrame.nLeft + pBorderLineInfo->getLeftBorderLine()->getBorderLineWidth();

				if (rcFrame.nRight < rcDraw.nRight && pBorderLineInfo->getRightBorderLine())
					rcDraw.nRight = rcFrame.nRight - pBorderLineInfo->getRightBorderLine()->getBorderLineWidth();
			}
		}

	}
	else if (pFrame->isSero() == BrTRUE) {
		//ZPD-29140:도형 내분에서 텍스트 편집 영역만큼만 테두리 작히도록 수정.
		BRect rcBorderMarginWithText = pFrame->getBorderMarginWithText();
		rcFrame.nTop += rcBorderMarginWithText.Top();
		rcFrame.nBottom -= rcBorderMarginWithText.Bottom();

		if (getDocType() == BORA_DOCTYPE_HWP && pParaAtt->getIgnoreParaMargin()) {
			rcDraw.nTop = rcFrame.nTop + pParaAtt->getLeftMargin();
			rcDraw.nBottom = rcFrame.nBottom - pParaAtt->getRightMargin();
		}
		else {
			rcDraw.nTop = rcFrame.nTop;
			rcDraw.nBottom = rcFrame.nBottom;
		}
		rcDraw.nRight = rcFrame.nRight - nLineTop;
		rcDraw.nLeft = rcDraw.nRight - nLineHgt;

		if (pBorderLineInfo) {
			if (pBorderLineInfo->getLeftBorderLine())
				rcDraw.nTop -= pBorderLineInfo->getLeftBorderLine()->getBorderLineSpace() + pBorderLineInfo->getLeftBorderLine()->getBorderLineWidth() / 2;

			if (pBorderLineInfo->getRightBorderLine())
				rcDraw.nBottom += pBorderLineInfo->getRightBorderLine()->getBorderLineSpace() + pBorderLineInfo->getRightBorderLine()->getBorderLineWidth() / 2;

			if (pBorderLineInfo->getBottomBorderLine())
				rcDraw.nLeft -= pBorderLineInfo->getBottomBorderLine()->getBorderLineSpace() + pBorderLineInfo->getBottomBorderLine()->getBorderLineWidth();

			if (pBorderLineInfo->getTopBorderLine())
				rcDraw.nRight += pBorderLineInfo->getTopBorderLine()->getBorderLineWidth() / 2;

			//[M-47248][20hoon]
			if (pFrame->isBasic() && rcFrame.nLeft == rcDraw.nLeft && pBorderLineInfo->getBottomBorderLine())
				rcDraw.nLeft += pBorderLineInfo->getBottomBorderLine()->getBorderLineWidth();

			//[2013-11-13][20hoon]
			if (pLine->isStartLine() && pBorderLineInfo->getTopBorderLine()) {
				rcDraw.nRight += (pBorderLineInfo->getTopBorderLine()->getBorderLineSpace() + (pBorderLineInfo->getTopBorderLine()->getBorderLineWidth() / 2));
				rcDraw.nRight += CTextProc::FindMaxBorderLineWidth(pLine);
			}
		}
	}

	rcDraw.NormalizeRect();
	return BrTRUE;
}


void CTextDraw::DrawParaDecoLine(BrDC* dc, CDrawUnit& du, CFrame* pFrame)
{
	BoraDoc* document = theBWordDoc;
	if (document == BrNULL || pFrame == BrNULL)
		return;

	const PoParaAtt* paraAtt = BrNULL;
	CLine* pELine;
	BRect rcLine1;
	BRect rcLine2;
	BRect rcDraw;
	BRect rcPageBorder;
	BRect rcInnerPageBorder;
	BrBOOL bAlignBordersAndEdge = BrFALSE;

	PoParaAttHandler* para_att_h = document->getParaAttHandler();
	if (!para_att_h)
		return;

	CPage* pPage = pFrame->getPage();
	CLineList* pLineList = (CLineList*)pFrame->getSubFrame();

	CLine* pSLine = pLineList->getFirst();

	if (pFrame->isBasic() && document->isAlignBordersAndEdges()) {
		bAlignBordersAndEdge = BrTRUE;
		pPage->getBorderBoundary(rcPageBorder, &rcInnerPageBorder);
	}

	while (pSLine != BrNULL) {
		pSLine = ParaDecoStartLine(para_att_h, pLineList, pSLine);
		if (pSLine == BrNULL)
			return;

		pELine = ParaDecoEndLine(para_att_h, pLineList, pSLine);
		if (pELine == BrNULL)
			return;

		if (CalcParaDecoDrawArea(document, pFrame, pSLine, rcLine1) &&
		    CalcParaDecoDrawArea(document, pFrame, pELine, rcLine2)) {
			paraAtt = para_att_h->getMergedParaAtt(pELine->getParaID(), pELine);

			rcDraw.UnionRect(rcLine1, rcLine2);

			// 단락 테두리와 표 모서리를 페이지 테두리에 맞춤
			du.doc2Logical(rcDraw, BrTRUE);

			if (paraAtt->isSettedParaBorderLineInfo() == BrTRUE) {
				CBorderLineInfo* pBorderLineInfo = paraAtt->getParaBorderLineInfo();
				if (pBorderLineInfo) {

					BRect rcFrameRect = pFrame->getFrameRect();
					du.doc2Logical(rcFrameRect, BrTRUE);

					BrCHAR nDrawLineBits = DRAW_LINE_APPLYALL;
					if (pFrame->isGaro()) {
						if (pBorderLineInfo->getTopBorderLine() && (pBorderLineInfo->getTopBorderLine()->getBorderLineArtStyle() != BR_ART_BORDER_NONE)
								&& (pFrame->isBasic() && pELine->isEndLine() && !pELine->isBothLine() && !pSLine->isStartLine()))	//[ZPD-6075][2015-01-06][sangdon] 페이지에 걸쳐 있는 단락의 경우 양쪽 페이지에 모두 테두리가 표시됨
							nDrawLineBits = nDrawLineBits & ~DRAW_TOP_LINE_MASK;

						if (pBorderLineInfo->getBottomBorderLine() && pBorderLineInfo->getBottomBorderLine()->getBorderLineArtStyle() != BR_ART_BORDER_NONE) {
							if ((pBorderLineInfo->getBottomBorderLine()->getBorderLineArtStyle() != BR_ART_BORDER_NONE)
									&& (pFrame->isBasic() && pSLine->isStartLine() && !pSLine->isBothLine() && !pELine->isEndLine()))	//[ZPD-6075][2015-01-06][sangdon] 페이지에 걸쳐 있는 단락의 경우 양쪽 페이지에 모두 테두리가 표시됨
								nDrawLineBits = nDrawLineBits & ~DRAW_BOTTOM_LINE_MASK;

							//[ERH-120]도형에서는 단락의 테두리가 도형밖을 넘어가면 그리지 않음.
							if (pFrame->isSpecial() && !pFrame->isWordMemoFrame() && (rcDraw.nBottom + du.doc2LogicalY(pBorderLineInfo->getBottomBorderLine()->getBorderLineWidth(), BrFALSE) > rcFrameRect.Bottom())) // word memo frame은 예외 POD-2216
								nDrawLineBits = nDrawLineBits & ~DRAW_BOTTOM_LINE_MASK;
						}
					}
					else if (pFrame->isSero()) {
						if (pBorderLineInfo->getRightBorderLine() && (pBorderLineInfo->getRightBorderLine()->getBorderLineArtStyle() != BR_ART_BORDER_NONE)
								&& (pFrame->isBasic() && pELine->isEndLine() && !pELine->isBothLine() && !pSLine->isStartLine()))	//[ZPD-6075][2015-01-06][sangdon] 페이지에 걸쳐 있는 단락의 경우 양쪽 페이지에 모두 테두리가 표시됨
							nDrawLineBits = nDrawLineBits & ~DRAW_RIGHT_LINE_MASK;

						if (pBorderLineInfo->getLeftBorderLine() && (pBorderLineInfo->getLeftBorderLine()->getBorderLineArtStyle() != BR_ART_BORDER_NONE)
								&& (pFrame->isBasic() && pSLine->isStartLine() && !pSLine->isBothLine() && !pELine->isEndLine()))	//[ZPD-6075][2015-01-06][sangdon] 페이지에 걸쳐 있는 단락의 경우 양쪽 페이지에 모두 테두리가 표시됨
							nDrawLineBits = nDrawLineBits & ~DRAW_LEFT_LINE_MASK;
					}

					pBorderLineInfo->drawParaLineBorder(dc, du, rcDraw, BrFALSE, pFrame->isGaro(), nDrawLineBits);

					if (pBorderLineInfo->getBetweenBorderLine() && (pBorderLineInfo->getBetweenBorderLine()->getBorderLineArtStyle() != BR_ART_BORDER_NONE)) {
						DrawParaDecoBetweenLine(dc, du, pFrame, pSLine, pELine, pBorderLineInfo);
					}
				}
			}
		}
		pSLine = pLineList->getNextInFrame(pELine);
	}
}


CLine* CTextDraw::ParaDecoStartLine(PoParaAttHandler* para_att_h, CLineList* pLineList, CLine* pLine)
{
	const PoParaAtt* paraAtt = BrNULL;
	while (pLine != BrNULL) {
		if (pLine->isOverflow() || pLine->isDirty())
			break;
		paraAtt = para_att_h->getParaAtt(pLine->getParaID());

		//CSP-1796 //20hoon SectionBreak만 있는 라인은 파라음영, 파라 테두리 랜더링에서 제외합니다.
		//Page Break만 있는 라인도 파라음영, 파라 테두리 랜더링에서 제외
		if ((pLine->isSectionBreak() == BrTRUE && pLine->isOnlyCR() == BrTRUE) ||
				(pLine->isPageOrColBreak() == BrTRUE && pLine->isOnlyCR() == BrTRUE)
				) {
			pLine = pLineList->getNextInFrame(pLine);
			continue;
		}

		if (paraAtt->getParaBorderLineInfo()) {
			if (pLine->getAscent() != 0 || !pLine->getRevisionShowLine(theBWordDoc))
				return pLine;
		}

		pLine = pLineList->getNextInFrame(pLine);
	}
	return BrNULL;
}


CLine* CTextDraw::ParaDecoEndLine(PoParaAttHandler* para_att_h, CLineList* pLineList, CLine* pLine)
{
	if (BrNULL == pLineList || BrNULL == pLine)
		return BrNULL;

	BrINT nSaveID = pLine->getParaID();
	const PoParaAtt* prev_para_att = para_att_h->getParaAtt(nSaveID);

	BoraDoc* document = theBWordDoc;
	const BrBOOL is_hwp = document->isFromHwp();
	const BrBOOL is_odt = document->isFromOdt();

	CLine* pSaveLine = pLine;
	while (pLine) {
		if (pLine->isOverflow() || pLine->isDirty())
			break;

		//CSP-1796 //20hoon SectionBreak만 있는 라인은 파라음영, 파라 테두리 랜더링에서 제외합니다.
		//Page Break만 있는 라인도 파라음영, 파라 테두리 랜더링에서 제외
		if (pLine->isOnlyCR() && (pLine->isSectionBreak() || pLine->isPageOrColBreak())) {
			pLine = pLineList->getNextInFrame(pLine);
			break;
		}

		BrINT nParaID = pLine->getParaID();
		const PoParaAtt* next_para_att = para_att_h->getMergedParaAtt(nParaID, pLine);
		if (BrNULL == next_para_att)
			break;

		if (next_para_att->isSettedParaBorderLineInfo() == BrFALSE)
			break;

		const BrBOOL is_connect = next_para_att->getConnectParaBorder();
		const BrBOOL is_end_line = pLine->isEndLine();
		if (is_odt && BrFALSE == is_connect && is_end_line) {
			pSaveLine = pLine;
			break;
		}

		if (nParaID != nSaveID) {
			if (is_hwp) {
				if (BrFALSE == is_connect &&
						(is_end_line || BrFALSE == prev_para_att->canCombineDeco(*next_para_att)))
					break;
			}
			else {
				if (BrFALSE == prev_para_att->canCombineDeco(*next_para_att))
					break;
			}
		}

		pSaveLine = pLine;

		if (is_hwp && BrFALSE == is_connect && is_end_line)
			break;

		pLine = pLineList->getNextInFrame(pLine);
	}

	return pSaveLine;
}


void CTextDraw::DrawParaDecoBetweenLine(BrDC* dc, CDrawUnit& du, CFrame* pFrame,
                                        CLine* pSLine, CLine* pELine,
                                        CBorderLineInfo* pBorderLineInfo)
{
	BoraDoc* document = theBWordDoc;
	if (document == BrNULL || pFrame == BrNULL || pSLine == BrNULL || pELine == BrNULL)
		return;
	if (pBorderLineInfo == BrNULL || pBorderLineInfo->getBetweenBorderLine() == BrNULL)
		return;

	BRect rcDraw;
	BRect rcPageBorder;
	BRect rcInnerPageBorder;
	CPage* pPage = pFrame->getPage();

	// 단락 테두리와 표 모서리를 페이지 테두리에 맞춤
	BrBOOL bAlignBordersAndEdge = BrFALSE;
	if (pFrame->isBasic() && document->isAlignBordersAndEdges()) {
		bAlignBordersAndEdge = BrTRUE;
		pPage->getBorderBoundary(rcPageBorder, &rcInnerPageBorder);
	}

	CLineList* pLineList = (CLineList*)pFrame->getSubFrame();

	CLine* pLine = pSLine;
	while (pLine != BrNULL) {
		if (pLine == pELine)
			break;

		//2014-08-03  //ZPD-148 //20hoon //파라의 마지막 라인에서는 가운데 라인을 긋습니다.
		if (pLine == pLine->getLastLineOfPara()) {
			if (CalcParaDecoDrawArea(document, pFrame, pLine, rcDraw) && pLineList->getNextInFrame(pLine) != BrNULL) {
				if (bAlignBordersAndEdge) {
					if (rcInnerPageBorder.nLeft <= rcDraw.nLeft && BrABS(rcInnerPageBorder.nLeft - rcDraw.nLeft) <= document->getAlignBordersAndEdgesGap())
						rcDraw.nLeft = rcInnerPageBorder.nLeft;

					if (rcInnerPageBorder.nRight >= rcDraw.nRight && BrABS(rcInnerPageBorder.nRight - rcDraw.nRight) <= document->getAlignBordersAndEdgesGap())
						rcDraw.nRight = rcInnerPageBorder.nRight;
				}

				du.doc2Logical(rcDraw, BrTRUE);

				pBorderLineInfo->drawBetweenLineBorder(dc, du, rcDraw, BrFALSE, pFrame->isGaro());
			}
		}

		pLine = pLineList->getNextInFrame(pLine);
	}
}


void CTextDraw::DrawBackgroundOfGaroOneLine(BrDC* dc, CDrawUnit& du, CFrame* pFrame, CLine* pLine,
                                            BrINT sx, BrINT sy, BrINT nBandCount, BrINT nUpLineSp)
{
	BoraDoc* document = theBWordDoc;
	if (document == BrNULL || pFrame == BrNULL || pLine == BrNULL)
		return;

	PoTextAttHandler* text_att_h = document->getTextAttHandler();
	if (text_att_h == BrNULL)
		return;
	PoParaAttHandler* para_att_h = document->getParaAttHandler();
	if (para_att_h == BrNULL)
		return;

	CCharSetArray* pLinkArray = pLine->getCharSetArray();
	if (pLinkArray == BrNULL)
		return;
	BrINT nCharNum = pLinkArray->size();
	CLongArray& cPosArray = pLine->getPosArray();
	if (nCharNum == 0 || (BrINT)cPosArray.size() < nCharNum + 1 || (nCharNum == 1 && pLine->isEndLine())) {
		if (!document->isInCurrentMemo())
			return;
	}

	const PoTextAtt* pTextAtt = BrNULL;
	CCharSet* pLink;
	BrCOLORREF dwBackColor = 0;
	BrCOLORREF dwOldBackColor = NONE_COLOR_BITS;
	BrINT nBandStart, nBandEnd, nFrameStart;
	BRect rcFill;
	BRect rcIconMemo;
	BrBOOL bNeedDrawBackground = BrFALSE;

	//[T-16745]20hoon  draw Shading
	BRect rcFillForTextShading;

	BrCOLORREF dwTextShadingFillColor = NONE_COLOR_BITS;
	BrCOLORREF dwTextShadingPatternColor = NONE_COLOR_BITS;
	BrINT cTextShadingPatternStyle = BR_SHADING_PATTERN_STYLE_ERASE;
	BrCOLORREF dwOldTextShadingFillColor = NONE_COLOR_BITS;
	BrCOLORREF dwOldTextShadingPatternColor = NONE_COLOR_BITS;
	BrINT cOldTextShadingPatternStyle = BR_SHADING_PATTERN_STYLE_ERASE;
	auto IsDiffShading = [&]() {
		return dwOldTextShadingFillColor != dwTextShadingFillColor ||
			dwOldTextShadingPatternColor != dwTextShadingPatternColor ||
			cOldTextShadingPatternStyle != cTextShadingPatternStyle;
	};
	auto BackupShading = [&]() {
		dwOldTextShadingFillColor = dwTextShadingFillColor;
		dwOldTextShadingPatternColor = dwTextShadingPatternColor;
		cOldTextShadingPatternStyle = cTextShadingPatternStyle;
	};

	if (pLine->getStatus(LINE_FIELD) != 0) {
		CLocation location;
		location.setLocation(pLine, 0);
	}

	BrBmvBrush brush;

	// 텍스트 강조색 원칙
	// MS-Word : 줄 간격을 포함하여 칠한다. 단 배수인 경우는 1줄 이상인 경우 1줄까지만 칠함
	// HWP, ODT : 줄 간격을 무시하고 순수하게 글자 영역만 칠함
	//BrINT nDownLineSp, nLineSp;
	BrINT nLineSp = du.doc2LogicalDY(CTextProc::CalcLineSpace(document, pLine), BrFALSE);
	// Line Space가 마이너스일 때는 반으로 나누지 말아야 한다 ZPD-28970
	// if ( nLineSp>0 )	nLineSp = nLineSp/2;
	if (nLineSp > 1 && !document->isFromMSWordType()) {  // HWP, ODT
		// nLineSp = 1;	// #2094	//[ZPD-20705]MS Word가 아닐 경우만
		nUpLineSp = 1;
	}
	else {
		// drawTextFrame()에서 LineSp를 고려하여 띄운 값을 사용 SRG-2371
		nUpLineSp = du.doc2LogicalDY(nUpLineSp, BrFALSE);
	}
	if (du.doc2LogicalDY(pLine->getAscent() * 1.3, BrFALSE) < du.doc2LogicalDY(pLine->getAscent(), BrFALSE) + nUpLineSp)
		rcFill.nTop = sy - du.doc2LogicalDY(pLine->getAscent() * 1.3, BrFALSE);
	else
		rcFill.nTop = sy - du.doc2LogicalDY(pLine->getAscent(), BrFALSE) - nUpLineSp;

	rcFill.nBottom = sy + du.doc2LogicalDY(pLine->getHeightWithoutAnchor() * 0.3, BrFALSE);// + nUpLineSp - nDownLineSp;// sy + nDownLineSp; //[SRG-2371]수정사항 중 [XPD-18599] 문제를 야기하는 라인 삭제
	//2014-07-22 T-27729 20hoon
	//글자 속성 - 고급 - 위치기능을 설정하면 하이라이트 영역 및 음영 영역을 늘려준다.
	rcFill.nBottom += du.doc2LogicalDY(pLine->getMaxHgtUnderBasePos(), BrFALSE);

	// line_frame 바깥쪽 그리지 말자 SRG-316
	BrINT nFrameTop = du.doc2LogicalY(pFrame->top());
	if (rcFill.nTop < nFrameTop)
		rcFill.nTop = nFrameTop;

	rcFillForTextShading.nTop = rcFill.nTop;
	rcFillForTextShading.nBottom = rcFill.nBottom;

	BrINT nCol = 0;
	nFrameStart = pFrame->left();
	//BYTE bSubType;

	//ZPD-7580	//20hoon //2015-01-07 // 라인의 배경을 클립영역안에 들었을때만 그린다.
	//클립영역을 보지 않고 무조건 그리면,
	//ZPD-7580 이슈처럼 글자는 다시 그리지 않는데, 음영만 다시 그려서 글자가 보이지 않는 현상 발생 !!
//   if( !dc->isExportMode() )
//   {
// 		BrINT nCharNum= pLine->getCharNum();
// 	  if(pLine!=BrNULL && nCharNum>=1)
// 	  {
// 		  BrLONG* pLastCharPos =  pLine->getPosArray().GetAt(nCharNum-1);
// 		  if(pLastCharPos!=BrNULL)
// 		  {
// 			  BrINT nLastCharSetPos =   sx + du.doc2LogicalDX(*(pLastCharPos), BrTRUE);
// 			  if ( !IsClipRegion(sx, rcFill.nTop, rcFill.nBottom-rcFill.nTop,nLastCharSetPos-sx) )
// 			  {
// 				  return;
// 			  }
// 		  }
// 	  }
//   }

#ifdef BIDI_SUPPORT
	BRect rcBidiFill, rcChar;
	BRect rcBidiFillForTextShading;
	const PoParaAtt* paraAtt = para_att_h->getMergedParaAtt(pLine->getParaID(), pLine);
	BrBOOL bInitBidi, bBidi = pLine->hasBidi() || paraAtt->getBiDi();
	BrBOOL bInitBidiForTextShading;

	bInitBidi = BrFALSE;
	rcBidiFill.nTop = rcFill.nTop;
	rcBidiFill.nBottom = rcFill.nBottom;

	bInitBidiForTextShading = BrFALSE;
	rcBidiFillForTextShading.nTop = rcFillForTextShading.nTop;
	rcBidiFillForTextShading.nBottom = rcFillForTextShading.nBottom;
#endif  // BIDI_SUPPORT

	BrINT nMemoReference = 0;
	BrBOOL bMemoProc = BrFALSE;

	const BrBOOL is_hwp = (BORA_DOCTYPE_HWP == getDocType());

	auto& AvailArea = GetAvailAreaMatrix();
	for (BrINT nBand = 0; nBand < nBandCount; nBand++) {
		nBandStart = AvailArea[nBand][0] - nFrameStart;
		nBandEnd = AvailArea[nBand][1] - nFrameStart;

		if (cPosArray[nCol] > nBandEnd)
			continue;

		if (cPosArray[nCol] < nBandStart)
			rcFillForTextShading.nLeft = rcFill.nLeft = sx + du.doc2LogicalDX(nBandStart, BrFALSE);
		else
			rcFillForTextShading.nLeft = rcFill.nLeft = sx + du.doc2LogicalDX(cPosArray[nCol], BrFALSE);

		for (; nCol < nCharNum; nCol++) {
			pLink = pLinkArray->getCharSet(nCol);
			//[ZPD-25526] text link가 아닌 경우 처리(테스트 해본 경우에 대해서만 우선 처리)
			if (pLink == BrNULL || pLink->isLinkNode() && !pLink->isMemoLink())
				continue;
#ifdef SUPPORT_SHOW_HWP_TYPESET
			if (document->isFromHwp() &&
			    !document->isShowHWPTypeSetMode() &&
			    CTextProc::isHWPTypeSetSymbol(document, pLink, BrFALSE) &&  // WPD-3611
			    !pLink->isMemoLink())  // CAM-7801, CAM-7802
				continue;
#endif  // SUPPORT_SHOW_HWP_TYPESET

			rcFillForTextShading.nRight = rcFill.nRight = sx + du.doc2LogicalDX(cPosArray[nCol], BrFALSE);

			bMemoProc = BrFALSE;

			if (document->isMemoModeFrame() == BrFALSE) {
				ConfigureDrawingMemoInfo(nMemoReference, rcFill, rcIconMemo, dwBackColor, bMemoProc,
				                         pFrame, pLine, nCol, sx, du, BrFALSE);
			}

			if (BrFALSE == bMemoProc) {
				pTextAtt = text_att_h->getTextAtt(pLink->getAttrID());
				if (BrNULL == pTextAtt)
					continue;

				BrBOOL is_draw_background = CheckDrawBackground(pLink, pTextAtt, document);
				if (is_hwp) {
					BrBOOL is_draw_bg = ConfigureHWPBgColor(dwBackColor, dwTextShadingFillColor,
					                                        dwTextShadingPatternColor, cTextShadingPatternStyle,
					                                        is_draw_background, pLink, pTextAtt, pLine, document);
					if (is_draw_bg)
						bNeedDrawBackground = BrTRUE;
				}
				else {
					dwBackColor = TakeBackColor(is_draw_background, pLink, pTextAtt, pLine, document);

					/****************************
					*   set Text Shading Color *
					*****************************/
					if (is_draw_background && !pLink->isCROrSoftEnterLink() && !pTextAtt->getBackFlag() && !pLink->isBulletLink()) {
						if (bNeedDrawBackground == BrFALSE)
							bNeedDrawBackground = BrTRUE;

						dwTextShadingFillColor = pTextAtt->getShadingFillColor().getColor();
						dwTextShadingPatternColor = pTextAtt->getShadingPatternColor().getColor();
						cTextShadingPatternStyle = pTextAtt->getShadingPatternStyle();
					}
					else {
						dwTextShadingFillColor = NONE_COLOR_BITS;
						dwTextShadingPatternColor = NONE_COLOR_BITS;
						cTextShadingPatternStyle = BR_SHADING_PATTERN_STYLE_ERASE;
					}
				}
			}

#ifdef BIDI_SUPPORT
			if (bBidi) {
				BrBOOL bDrawFill = BrFALSE;
				BrBOOL bDrawFillForTextShading = BrFALSE;

				/*********************
				draw shading
				*********************/

				if (!(cTextShadingPatternStyle == BR_SHADING_PATTERN_STYLE_ERASE && dwTextShadingFillColor == NONE_COLOR_BITS)) {
					rcChar.nLeft = cPosArray[nCol];
					rcChar.nRight = 0x0fffffff;
					for (BrINT i = 0; i <= nCharNum; ++i) {
						BrINT nTmp = cPosArray[i];
						if (rcChar.nLeft < nTmp && nTmp < rcChar.nRight)
							rcChar.nRight = nTmp;
					}

					if (rcChar.nRight == 0x0fffffff)
						rcChar.nRight = rcChar.nLeft;

					if (bInitBidiForTextShading && IsDiffShading()) {
						rcBidiFillForTextShading.nLeft = sx + du.doc2LogicalDX(rcBidiFillForTextShading.nLeft, BrFALSE);
						rcBidiFillForTextShading.nRight = sx + du.doc2LogicalDX(rcBidiFillForTextShading.nRight, BrFALSE);

						DrawShading(dc, &rcBidiFillForTextShading, dwOldTextShadingFillColor,
						            dwOldTextShadingPatternColor, cOldTextShadingPatternStyle);
						bNeedDrawBackground = BrFALSE;
						bInitBidiForTextShading = BrFALSE;
					}

					if (!bInitBidiForTextShading) {
						rcBidiFillForTextShading.nLeft = rcChar.nLeft;
						rcBidiFillForTextShading.nRight = rcChar.nRight;
						bInitBidiForTextShading = BrTRUE;
					}
					else if (rcChar.nLeft == rcBidiFillForTextShading.nRight)
						rcBidiFillForTextShading.nRight = rcChar.nRight;
					else if (rcChar.nRight == rcBidiFillForTextShading.nLeft)
						rcBidiFillForTextShading.nLeft = rcChar.nLeft;
					else
						bDrawFillForTextShading = BrTRUE;

					if (bDrawFillForTextShading || nCol == nCharNum - 1) {
						rcBidiFillForTextShading.nLeft = sx + du.doc2LogicalDX(rcBidiFillForTextShading.nLeft, BrFALSE);
						rcBidiFillForTextShading.nRight = sx + du.doc2LogicalDX(rcBidiFillForTextShading.nRight, BrFALSE);

						DrawShading(dc, &rcBidiFillForTextShading, dwOldTextShadingFillColor,
						            dwOldTextShadingPatternColor, cOldTextShadingPatternStyle);
						bNeedDrawBackground = BrFALSE;

						rcBidiFillForTextShading.nLeft = rcChar.nLeft;
						rcBidiFillForTextShading.nRight = rcChar.nRight;
					}

					BackupShading();
				}
				else if (!(cOldTextShadingPatternStyle == BR_SHADING_PATTERN_STYLE_ERASE && dwOldTextShadingFillColor == NONE_COLOR_BITS)) {
					rcBidiFillForTextShading.nLeft = sx + du.doc2LogicalDX(rcBidiFillForTextShading.nLeft, BrFALSE);
					rcBidiFillForTextShading.nRight = sx + du.doc2LogicalDX(rcBidiFillForTextShading.nRight, BrFALSE);
					DrawShading(dc, &rcBidiFillForTextShading, dwOldTextShadingFillColor,
					            dwOldTextShadingPatternColor, cOldTextShadingPatternStyle);
					bNeedDrawBackground = BrFALSE;
					bInitBidiForTextShading = BrFALSE;
				}

				/*******************************
				draw backgorund or HighLight
				*******************************/

				if (pFrame) {
					BrINT gray_mode = document->GetGrayMode();
					if (GRAY_MODE_COLOR != gray_mode) {
						dwBackColor = BrColor::getBwColor(gray_mode, pFrame->getFrameColorMode(), dwBackColor, GRAY_MODE_APPLY_TEXT);
#ifdef SUPPORT_NIGHT_VIEW_MODE
						if (document->isNightViewMode())
							dwBackColor = BrXORColor(dwBackColor);
#endif  // SUPPORT_NIGHT_VIEW_MODE
					}
				}

				if (dwBackColor != NONE_COLOR_BITS) {
					rcChar.nLeft = cPosArray[nCol];
					rcChar.nRight = 0x0fffffff;
					for (BrINT i = 0; i <= nCharNum; ++i) {
						BrINT nTmp = cPosArray[i];
						if (rcChar.nLeft < nTmp && nTmp < rcChar.nRight)
							rcChar.nRight = nTmp;
					}

					if (rcChar.nRight == 0x0fffffff)
						rcChar.nRight = rcChar.nLeft;

					if (bInitBidi && dwBackColor != dwOldBackColor) {
						rcBidiFill.nLeft = sx + du.doc2LogicalDX(rcBidiFill.nLeft, BrFALSE);
						rcBidiFill.nRight = sx + du.doc2LogicalDX(rcBidiFill.nRight, BrFALSE);
						DrawFillRect(dc, brush, rcBidiFill, dwOldBackColor);
						bInitBidi = BrFALSE;
					}

					if (!bInitBidi) {
						rcBidiFill.nLeft = rcChar.nLeft;
						rcBidiFill.nRight = rcChar.nRight;
						bInitBidi = BrTRUE;
					}
					else if (rcChar.nLeft == rcBidiFill.nRight)
						rcBidiFill.nRight = rcChar.nRight;
					else if (rcChar.nRight == rcBidiFill.nLeft)
						rcBidiFill.nLeft = rcChar.nLeft;
					else
						bDrawFill = BrTRUE;

					if (bDrawFill || nCol == nCharNum - 1) {
						rcBidiFill.nLeft = sx + du.doc2LogicalDX(rcBidiFill.nLeft, BrFALSE);
						rcBidiFill.nRight = sx + du.doc2LogicalDX(rcBidiFill.nRight, BrFALSE);
						DrawFillRect(dc, brush, rcBidiFill, dwOldBackColor);
						rcBidiFill.nLeft = rcChar.nLeft;
						rcBidiFill.nRight = rcChar.nRight;
					}

					dwOldBackColor = dwBackColor;
				}
				else if (dwOldBackColor != NONE_COLOR_BITS) {
					rcBidiFill.nLeft = sx + du.doc2LogicalDX(rcBidiFill.nLeft, BrFALSE);
					rcBidiFill.nRight = sx + du.doc2LogicalDX(rcBidiFill.nRight, BrFALSE);
					DrawFillRect(dc, brush, rcBidiFill, dwOldBackColor);
					bInitBidi = BrFALSE;
				}

				continue;
			}
#endif  // BIDI_SUPPORT

			if (is_hwp) {
				FillHorizontalBackground(dwOldBackColor, rcFill, dwBackColor, brush, dc);
				dwBackColor = GrayColor(dwBackColor, document, pFrame);
				if (IsDiffShading()) {
					DrawHorizontalShading(rcFillForTextShading, bNeedDrawBackground, dc,
					                      dwOldTextShadingFillColor, dwOldTextShadingPatternColor,
					                      cOldTextShadingPatternStyle);
					BackupShading();
				}
			}
			else {
				if (IsDiffShading()) {
					DrawHorizontalShading(rcFillForTextShading, bNeedDrawBackground, dc,
					                      dwOldTextShadingFillColor, dwOldTextShadingPatternColor,
					                      cOldTextShadingPatternStyle);
					BackupShading();
				}
				dwBackColor = GrayColor(dwBackColor, document, pFrame);
				FillHorizontalBackground(dwOldBackColor, rcFill, dwBackColor, brush, dc);
			}

			if (nBandEnd < cPosArray[nCol + 1]) {
				//[XPD-17475]한글자의 너비보다 작게 도형 너비가 잡히는 경우에 텍스트 음영이 작게보여 글자의 위치로 해줌.
				if (pFrame->isBasic())
					rcFillForTextShading.nRight = rcFill.nRight = sx + du.doc2LogicalDX(nBandEnd, BrFALSE);
				else
					rcFillForTextShading.nRight = rcFill.nRight = sx + du.doc2LogicalDX(cPosArray[nCol + 1], BrFALSE);

				//[2013-08-26][T-16745]20hoon draw shading;
				if (!(cTextShadingPatternStyle == BR_SHADING_PATTERN_STYLE_ERASE && dwTextShadingFillColor == NONE_COLOR_BITS)) {
					DrawShading(dc, &rcFillForTextShading, dwTextShadingFillColor,
					            dwTextShadingPatternColor, cTextShadingPatternStyle);
					bNeedDrawBackground = BrFALSE;
					BackupShading();
				}

				//Memo Link가 BandEnd보다 크게 존재하는 경우가 있음
				if (nCol < nCharNum - 1 && document->isInCurrentMemo()) {
					for (; nCol < nCharNum; nCol++) {
						CCharSet* pMemoLink = pLinkArray->getCharSet(nCol);
						if (pMemoLink->isMemoEndLink()) {
							rcIconMemo = rcFill;
							rcIconMemo.nRight = sx + du.doc2LogicalDX(cPosArray[nCol], BrFALSE);

							if (document->isInCurrentMemo() && pMemoLink->getCode() == document->getCurrentMemoId())
								document->setInCurrentMemo(BrFALSE);

							if (rcIconMemo.Left() < getLCDWidth() && rcIconMemo.Top() < getLCDHeight() &&
									rcIconMemo.Right() > 0 && rcIconMemo.Bottom() > 0) {
								//BandEnd 보다 작은 경우, 메모 하이라이트를 PosArray값에 맞춰 늘려준다.
								rcFill.nRight = rcIconMemo.nRight;
								document->setScreenMemoMode(document->getScreenMemoMode() | BR_SCREEN_EXIST_MEMO);
							}
							nMemoReference = 0;
							document->setDrawingMemoReference(nMemoReference);
							break;
						}
					}
				}

				if (dwBackColor != NONE_COLOR_BITS)
					DrawFillRect(dc, brush, rcFill, dwBackColor);
				break;
			}
			else if (nCol == nCharNum - 1) {
				rcFill.nRight = sx + du.doc2LogicalDX(cPosArray[nCol + 1], BrFALSE);
				rcFillForTextShading.nRight = rcFill.nRight;

				//[2013-08-26][T-16745]20hoon draw shading;
				if (!(cTextShadingPatternStyle == BR_SHADING_PATTERN_STYLE_ERASE && dwTextShadingFillColor == NONE_COLOR_BITS)) {
					DrawShading(dc, &rcFillForTextShading, dwTextShadingFillColor,
					            dwTextShadingPatternColor, cTextShadingPatternStyle);
					bNeedDrawBackground = BrFALSE;
					BackupShading();
				}

				if (dwBackColor != NONE_COLOR_BITS)
					DrawFillRect(dc, brush, rcFill, dwBackColor);
			}
			CCharSet* pNextLink = pLine->getCharSet(nCol + 1);
			BrBOOL bDrawChars = BrFALSE;
			if (pNextLink &&
			    (pLink->getTextAtt()->getShadingPatternColor().getColor() != NONE_COLOR_BITS &&
			      (pNextLink->getTextAtt()->getShadingPatternColor().getColor() == NONE_COLOR_BITS ||
			        pNextLink == pLine->getLastLink() ||
			        pNextLink->isCROrSoftEnterLink()))) {
				bDrawChars = BrTRUE;
			}
			else if (nCol + 1 == pLine->getCharNum() &&
			    pLink->getTextAtt()->getShadingPatternColor().getColor() != NONE_COLOR_BITS) {
				bDrawChars = BrTRUE;
			}

			if (bNeedDrawBackground && bDrawChars) {
				rcFill.nRight = sx + du.doc2LogicalDX(cPosArray[nCol + 1], BrFALSE);
				rcFillForTextShading.nRight = rcFill.nRight;
				//BTrace("rcFill.nLeft = %d, rcFill.nTop = %d, rcFill.nRight = %d, rcFill.nBottom = %d", rcFill.nLeft, rcFill.nTop, rcFill.nRight, rcFill.nBottom);

				DrawShading(dc, &rcFillForTextShading, dwTextShadingFillColor,
				            dwTextShadingPatternColor, cTextShadingPatternStyle);
				bNeedDrawBackground = BrFALSE;
				BackupShading();

				if (dwBackColor != NONE_COLOR_BITS)
					DrawFillRect(dc, brush, rcFill, dwBackColor);
			}
		}
	}

#ifdef USE_TOUCHED_WORD_MARKING_FOR_BWP
	CCmdEngine* pCmdEngine = document->getCmdEngine();
	if (document->getEditProtect() && pCmdEngine->pWordMarking == pLine) {
		rcFill.nLeft = sx + du.doc2LogicalDX(cPosArray[pCmdEngine->nStartWordMark], BrFALSE);
		rcFill.nRight = sx + du.doc2LogicalDX(cPosArray[pCmdEngine->nEndWordMark], BrFALSE);
		BrBYTE nOldAlphaValue = dc->setAlphaValue(127);
		BrBmvBrush brush;
		DrawFillRect(dc, brush, rcFill, SEARCH_MARK_ALL_COLOR);
		dc->setAlphaValue(nOldAlphaValue);
	}
#endif  // USE_TOUCHED_WORD_MARKING_FOR_BWP
}


void CTextDraw::ConfigureDrawingMemoInfo(BrINT& nMemoReference, BRect& rcFill, BRect& rcIconMemo,
                                         BrCOLORREF& dwBackColor, BrBOOL& bMemoProc,
                                         CFrame* pFrame, CLine* pLine, BrINT nCol,
                                         BrINT sx, CDrawUnit& du, BrBOOL is_vertical)
{
	BoraDoc* document = theBWordDoc;

	if (document->isShowMemo() == BrFALSE || document->getMemoArray()->getSize() == 0 || g_pAppStatic->isPrtPreview())
		return;

	CCharSetArray* pLinkArray = pLine->getCharSetArray();
	CCharSet* pLink = pLinkArray->getCharSet(nCol);

	if (pLink->isMemoLink() == BrFALSE && document->isInCurrentMemo() == BrFALSE)
		return;

	//pLink가 currentMemo영역에 속하는지 체크
	if (document->getCurrentMemoId() == pLink->getCode() && pLink->isMemoStartLink())
		document->setInCurrentMemo(BrTRUE);

	nMemoReference = document->getDrawingMemoReference();

	if (pLink->isMemoStartLink()) {
		//메모의 표시
		if (document->getCurrentMemoId() == pLink->getCode()) {
			document->setInCurrentMemo(BrTRUE);
			document->getMemoEventManager()->setSelctedMemoRect(rcFill);
			
		}
		document->setDrawingMemoReference(nMemoReference + 1);
		nMemoReference++;
	}

	if (nMemoReference > 0) {
		if (document->getRevisionEngine()->getReviewMode() == ReviewMode::ALL_MARKUP) {
			dwBackColor = MEMO_LINK_COLOR;
			bMemoProc = BrTRUE;
		}
	}
	if (document->isInCurrentMemo()) {
		dwBackColor = MEMO_LINK_SELECTED_COLOR;
		bMemoProc = BrTRUE;
	}

	if (pLink->isMemoEndLink()) {
		rcIconMemo = rcFill;
		CLongArray& cPosArray = pLine->getPosArray();
		rcIconMemo.nRight = sx + du.doc2LogicalDX(cPosArray[nCol], BrFALSE);

		if (document->isInCurrentMemo() && pLink->getCode() == document->getCurrentMemoId()) {
			BRect* rt = document->getMemoEventManager()->getSelectedMemoRect();
			rt->Union(rcFill);

			document->setInCurrentMemo(BrFALSE);
		}

		if ((rcIconMemo.Left() < getLCDWidth() && rcIconMemo.Top() < getLCDHeight()) &&
			(rcIconMemo.Right() > 0 && rcIconMemo.Bottom() > 0))
			document->setScreenMemoMode(document->getScreenMemoMode() | BR_SCREEN_EXIST_MEMO);
		document->setDrawingMemoReference(nMemoReference - 1);
	}
}

BrBOOL CTextDraw::CheckDrawBackground(CCharSet* charset, const PoTextAtt* text_att, BoraDoc* document)
{
	// Anchored Table은 Background 를 적용하지 않는다.
	if (charset->isAnchorLink()) {
		CFrame* frame = charset->getFrame(document);
		if (frame) {
			if (frame->isTable() /*&& line_frame->isAnchored()*/)	//[ZPD-22577]테이블 노드기만 하면 배경색을 그리지 말자.
				return BrFALSE;
			//[2014-02-05][M-52190][20hoon]글자처럼 취급된 이미지나 도형 뒤에 배경색을 그리지 않습니다.
			if ((frame->isSpecial() || frame->isImage()) && frame->isAnchored())
				return BrFALSE;
		}
		//if ( !document->isShowMemo() && document->isInCurrentMemoId() == BrFALSE ) //document->getStartMemoID() == -1 )
		// return BrFALSE;
	}
	else if (text_att->isDestConCur()) {
		return BrFALSE;
	}

	return BrTRUE;
}


// Return value
//   whether it is need to draw background
BrBOOL CTextDraw::ConfigureHWPBgColor(BrCOLORREF& back_color, BrCOLORREF& shading_fill,
                                      BrCOLORREF& shading_pattern, BrINT& shading_pattern_style,
                                      BrBOOL is_draw_bg, const CCharSet* charset,
                                      const PoTextAtt* text_att, CLine* line, BoraDoc* document)
{
	if (BrFALSE == is_draw_bg || charset->isCRLink()) {
		back_color = NONE_COLOR_BITS;
		shading_fill = NONE_COLOR_BITS;
		shading_pattern = NONE_COLOR_BITS;
		shading_pattern_style = BR_SHADING_PATTERN_STYLE_ERASE;
		return BrFALSE;
	}

	if (text_att->getBorderFillFaceColor() != NONE_COLOR_BITS) {
		shading_fill = text_att->getBorderFillFaceColor();
		back_color = NONE_COLOR_BITS;	//HWP는 배경이 우선 순위가 제일 높다
	}
	else {
		back_color = TakeBackColor(is_draw_bg, charset, text_att, line, document);

		if (text_att->getBackFlag() || charset->isBulletLink())
			shading_fill = back_color;
		else
			shading_fill = text_att->getShadingFillColor().getColor();
	}

	BrCOLORREF shading_pattern_color = text_att->getShadingPatternColor().getColor();
	if (NONE_COLOR_BITS == shading_pattern_color) {
		shading_pattern = NONE_COLOR_BITS;
		shading_pattern_style = BR_SHADING_PATTERN_STYLE_ERASE;
	}
	else {
		shading_pattern = shading_pattern_color;
		shading_pattern_style = text_att->getShadingPatternStyle();
	}

	return BrTRUE;
}


BrCOLORREF CTextDraw::TakeBackColor(BrBOOL is_draw_bg, const CCharSet* charset,
                                    const PoTextAtt* text_att, CLine* line, BoraDoc* document)
{
	if (BrFALSE == is_draw_bg || charset->isCRLink() || charset->isSoftEnterLink())
		return NONE_COLOR_BITS;

	BrBOOL is_reverse = text_att->getReverse();
	if (BrFALSE == is_reverse && BrFALSE == text_att->getBackFlag())
		return NONE_COLOR_BITS;

	BrCOLORREF back_color;
	// for word header/footer dim color
	CFrame* frame = line? line->getFrame(): BrNULL;
	if (frame && frame->isDimColorDraw()) {
#ifdef NEW_DIM_COLOR
		back_color = is_reverse? text_att->getDimTextColor():
		                         text_att->getDimBackColor();
#else
		back_color = is_reverse? MakeTextDimColor(text_att, line):
		                         MakeBackDimColor(text_att);
#endif
	}
	else {
		back_color = is_reverse? text_att->getTextColor().getColor():
		                         text_att->getBackColor().getColor();
	}

#ifdef SUPPORT_NIGHT_VIEW_MODE
	if (document->isNightViewMode())
		return BrXORColor(back_color);
#endif  // SUPPORT_NIGHT_VIEW_MODE

	return back_color;
}


#ifndef NEW_DIM_COLOR
BrCOLORREF CTextDraw::MakeTextDimColor(const PoTextAtt* text_att, CLine* line)
{
	if (BrFALSE == text_att->isSettedOldTextColor()) {
		BrCOLORREF color = CTextDraw::AutoTextColor(line, text_att);
		PoTextAtt* non_const_text_att = const_cast<PoTextAtt*>(text_att);  // WHAT THE ...
		non_const_text_att->setOldTextColor(BrUtil::BrightenColor(color));
	}
	return text_att->getOldTextColor();
}


BrCOLORREF CTextDraw::MakeBackDimColor(const PoTextAtt* text_att)
{
	if (BrFALSE == text_att->isSettedOldBackColor()) {
		BrCOLORREF color = text_att->getBackColor().getColor();
		PoTextAtt* non_const_text_att = const_cast<PoTextAtt*>(text_att);  // WHAT THE ...
		non_const_text_att->setOldBackColor(BrUtil::BrightenColor(color));
	}
	return text_att->getOldBackColor();
}
#endif  // NEW_DIM_COLOR


void CTextDraw::DrawFillRect(BrDC* dc, BrBmvBrush& brush, const BRect& rect, BrCOLORREF color)
{
	brush.createSolidBrush(color);
	BrBmvBrush* old_brush = dc->setBrush(&brush);
	dc->fillRect(rect.nLeft, rect.nTop, rect.nRight, rect.nBottom);
	dc->setBrush(old_brush);
}


void CTextDraw::FillHorizontalBackground(BrCOLORREF& prev_back, BRect& rect, BrCOLORREF back,
                                         BrBmvBrush& brush, BrDC* dc)
{
	if (back == prev_back)
		return;

	if (NONE_COLOR_BITS != prev_back) {
		if (rect.nLeft == rect.nRight) // Multi Marking이 Normal Caret인 상태에서 추가 할때
			rect.nRight += 2;
		else
			rect.nRight--;	//[ZPD-10763][2015-07-02]텍스트 강조 색이 글자 테두리를 넘어가서 줄임.
		DrawFillRect(dc, brush, rect, prev_back);
	}
	rect.nLeft = rect.nRight;
	prev_back = back;
}


BrCOLORREF CTextDraw::GrayColor(BrCOLORREF back_color, BoraDoc* document, CFrame* frame)
{
	if (BrNULL == frame || (document->isFromHwp() && frame->isCell()))
		return back_color;

	BrINT gray_mode = document->GetGrayMode();
	if (GRAY_MODE_COLOR == gray_mode)
		return back_color;

	BrColorMode color_mode = frame->getFrameColorMode();
	back_color = BrColor::getBwColor(gray_mode, color_mode, back_color, GRAY_MODE_APPLY_TEXT);
#ifdef SUPPORT_NIGHT_VIEW_MODE
	if (document->isNightViewMode())
		back_color = BrXORColor(back_color);
#endif  // SUPPORT_NIGHT_VIEW_MODE
	return back_color;
}


//[T-16745]20hoon  draw Shading
void CTextDraw::DrawHorizontalShading(BRect& rect, BrBOOL& is_need_draw_bg, BrDC* dc,
                                      BrCOLORREF fill, BrCOLORREF pattern, BrINT pattern_style)
{
	if (BR_SHADING_PATTERN_STYLE_ERASE != pattern_style || NONE_COLOR_BITS != fill) {
		// Multi Marking이 Normal Caret인 상태에서 추가 할때
		if (rect.nLeft == rect.nRight)
			rect.nRight += 2;
		DrawShading(dc, &rect, fill, pattern, pattern_style);
		is_need_draw_bg = BrFALSE;
	}

	rect.nLeft = rect.nRight;
}


// 일본어등을 처리할 때 composition background color를 처리하기 위한 code
void CTextDraw::DrawCompBackgroundOfGaroOneLine(BrDC* dc, CDrawUnit& du, CFrame* pFrame,
                                                CLine* pLine, BrINT sx, BrINT sy, BrINT nBandCount)
{
	BoraDoc* document = theBWordDoc;
	if (document == BrNULL || pFrame == BrNULL || pLine == BrNULL)
		return;

	CCaret* pCaret = document->getCaret();
	if (!pCaret->isCaretNormal() || pCaret->getFrame() == BrNULL || pCaret->getCompLen() < 1 || pCaret->m_bApplyCompBack == BrFALSE)
		return;

	if (pCaret->getFrame() == pFrame || (pCaret->getFrame()->isBasic() && pFrame->isBasic()) || (pCaret->getFrame()->isCell() && pFrame->isCell())) {
		BRect rcFill;
		CLongArray& cPosArray = pLine->getPosArray();
		BrINT nFrameStart;
		BrINT nSCol, nECol;
		BrBmvBrush brush;

		nFrameStart = pFrame->left();

		CCharSetArray* pLinkArray = pLine->getCharSetArray();
		if (pLinkArray == BrNULL)
			return;

		BrINT nCharNum = pLinkArray->size();
		if (nCharNum == 0 || (BrINT)cPosArray.size() < nCharNum + 1 || (nCharNum == 1 && pLine->isEndLine()))
			return;

		BrINT nLineSp = du.doc2LogicalDY(CTextProc::CalcLineSpace(document, pLine), BrFALSE) / 2;
		rcFill.nTop = sy - du.doc2LogicalDY(pLine->getAscent(), BrFALSE) - nLineSp;
		rcFill.nBottom = sy + nLineSp;

		if (pCaret->m_nStColForComp1 < pCaret->m_nEndColForComp1 && (pCaret->m_nStColForComp1 >= 0 && pCaret->m_nStColForComp1 < pCaret->getCompLen()) && (pCaret->m_nEndColForComp1 > 0 && pCaret->m_nEndColForComp1 <= pCaret->getCompLen())) {
			if (FindCompositionBgCol(pCaret->getLine(), pCaret->getCol(), pCaret->getCompLen(), pCaret->m_nStColForComp1, pCaret->m_nEndColForComp1, pLine, nSCol, nECol)) {
				if (nSCol >= 0 && nSCol < nECol && nECol <= pLine->getCharNum()) {
					rcFill.nLeft = sx + du.doc2LogicalDX(cPosArray[nSCol], BrFALSE);
					rcFill.nRight = sx + du.doc2LogicalDX(cPosArray[nECol], BrFALSE);
					DrawFillRect(dc, brush, rcFill, pCaret->m_dwColorForComp1);
				}
			}
		}

		if (pCaret->m_nStColForComp2 < pCaret->m_nEndColForComp2 && (pCaret->m_nStColForComp2 >= 0 && pCaret->m_nStColForComp2 < pCaret->getCompLen()) && (pCaret->m_nEndColForComp2 > 0 && pCaret->m_nEndColForComp2 <= pCaret->getCompLen())) {
			if (FindCompositionBgCol(pCaret->getLine(), pCaret->getCol(), pCaret->getCompLen(), pCaret->m_nStColForComp2, pCaret->m_nEndColForComp2, pLine, nSCol, nECol)) {
				if (nSCol >= 0 && nSCol < nECol && nECol <= pLine->getCharNum()) {
					rcFill.nLeft = sx + du.doc2LogicalDX(cPosArray[nSCol], BrFALSE);
					rcFill.nRight = sx + du.doc2LogicalDX(cPosArray[nECol], BrFALSE);
					DrawFillRect(dc, brush, rcFill, pCaret->m_dwColorForComp2);
				}
			}
		}
	}
}


// 일본어 등을 처리할 때 composition background color를 처리하기 위한 index를 구하기 위한 code
BrBOOL CTextDraw::FindCompositionBgCol(CLine* pCaretLine, BrINT nCaretCol, BrINT nCompLen,
                                       BrINT nStColForComp, BrINT nEndColForComp,
                                       CLine* pLine, BrINT& nSCol, BrINT& nECol)
{
	if (!pCaretLine || !pLine)
		return BrFALSE;

	BrINT nSIndex, nEIndex, nCol, nTotalIndex = 0;
	nSIndex = nCompLen - nStColForComp;
	nEIndex = nCompLen - nEndColForComp;

	nCol = nCaretCol;
	while (pCaretLine) {
		if (pLine == pCaretLine) {
			// set end column
			if (nEIndex < nTotalIndex)
				nECol = nCol;
			else if (nEIndex >= nTotalIndex && nEIndex <= (nTotalIndex + nCol))
				nECol = nCol - (nEIndex - nTotalIndex);
			else
				break;

			// set start column
			if (nSIndex > (nTotalIndex + nCol))
				nSCol = 0;
			else if (nSIndex >= nTotalIndex && nSIndex <= (nTotalIndex + nCol))
				nSCol = nCol - (nSIndex - nTotalIndex);
			else
				break;

			return BrTRUE;
		}
		nTotalIndex += nCol;
		if (nTotalIndex > nSIndex)
			break;

		pCaretLine = pCaretLine->getPrev();
		if (pCaretLine)
			nCol = pCaretLine->getCharNum();
	}
	return BrFALSE;
}


void CTextDraw::DrawForegroundOfGaroOneLine(Painter* painter, BrDC* dc, CDrawUnit& du, CFrame* pFrame,
                                            CLine* pLine, BrINT sx, BrINT sy, BrINT nBandCount,
                                            BrINT nMaxDescent, BrINT nUpLineSp)
{
	BoraDoc* document = theBWordDoc;
	if (document == BrNULL || pFrame == BrNULL || pLine == BrNULL)
		return;

	BRect rcFrame(pFrame->getFrameRect());
	if (document->isFromHwp() && pFrame->GetRotation() != 0)
		BrDrawUnit::getContainerRect(rcFrame, pFrame->GetRotation(), rcFrame);

	CLongArray& cPosArray = pLine->getPosArray();

	document->getMemoEventManager()->drawMemoIcon(painter, dc, du, pFrame, pLine, sx, sy, nBandCount, document, cPosArray, rcFrame);

#ifdef USE_PDFEXPORT_TEXTBOX
	if (dc->getDCType() == ePDFExtDCType && pFrame->isShape() && theBWordDoc->isExportPDFAnnot(pFrame->getID()))
	{
		return;
	}
#endif

	DrawGaroUnderline(painter, dc, du, pFrame, pLine, sx, sy, nBandCount, nMaxDescent, nUpLineSp);
	DrawGaroStrikeline(painter, dc, du, pFrame, pLine, sx, sy, nBandCount, nMaxDescent);


#ifdef _SPELLCHECKER
	//-------------------------------------------------------------------------
	// draw run-time spell check error text.
	// 밑줄쫙 : 빨간 물결선
	//-------------------------------------------------------------------------
	if (document->isSpellCheckMode() && (document->getCmdEngine()->m_bBwpDrawForeground & TEXT_WRONG_SPELL) && !document->getCmdEngine()->isSkipSpellCheck()) {
		//--- get current line's character node position array
		// CLongArray     &cPosArray = pLine->getPosArray();     // Frame Coordinate
		PoTextAttHandler* text_att_h = BrNULL;
		const PoTextAtt* pTextAtt = BrNULL;
		CCharSetArray* pLinkArray;
		CCharSet* pNode;
		// BrCOLORREF        hlink_color;    // display color
		BrINT    lBandStart, lBandEnd;
		BrINT    dx, dy;     // display position. device logical
		BrINT    x1, x2;
		BrINT    lLineHgt;   // logical
		BrINT    lOneWid;    // logical
		BrINT     wCol, wCharNum;
		BrWORD    nWidth;     // Underline/ Strikeout line width (logical)
		BrWORD    wCode;
		BrINT i;
		BrCOLORREF color1, color2, color3;

		text_att_h = document->getTextAttHandler();
		if (!text_att_h)
			return;

		//--- processing one line.
		pLinkArray = pLine->getCharSetArray();
		if (!pLinkArray || pLinkArray->GetSize() == 0)
			return;
		wCharNum = pLinkArray->GetSize();
		if (cPosArray.size() < wCharNum + 1)
			return;

		nWidth = 1;         // 2 ???
		lLineHgt = du.doc2LogicalY(pLine->getAscent(), BrFALSE);


#ifdef USE_HUNSPELL
		CSpellCheckManager* pSpellCheckManagaer = BrNULL;
		pSpellCheckManagaer = theBWordDoc->getSpellCheckManager();
		if (pSpellCheckManagaer != BrNULL) {
			BrCOLORREF underLineColor = pSpellCheckManagaer->getUnderLineColor().getColor();
			color1 = underLineColor;
			color2 = underLineColor;
			color3 = underLineColor;

			BrDOUBLE h, s, l;
			RGBtoHSL(GetBrRValue(underLineColor), GetBrGValue(underLineColor), GetBrBValue(underLineColor), h, s, l);

			if ((l * 255) < 204)
				color1 = BrColor::getColorbyHSTL(underLineColor, 160000, 66000, BRCOLOR_ATTRVAL_NONE);

			if ((l * 255) > 55)
				color2 = BrColor::getColorbyHSTL(underLineColor, 115000, BRCOLOR_ATTRVAL_NONE, 30000);

			color3 = underLineColor;
		}
		else
#endif  // USE_HUNSPELL
		{
			color1 = RGB_LIGHT_RED_SPELL;
			color2 = RGB_DARK_RED_SPELL;
			color3 = RGB_MID_RED_SPELL;
		}

		//--- Bands loop ---------------------------------------------
		pNode = pLinkArray->getCharSet(0);
		wCol = 0;
		auto& AvailArea = GetAvailAreaMatrix();
		for (BrINT nBand = 0; nBand < nBandCount; nBand++) {
			lBandStart = AvailArea[nBand][0] - rcFrame.nLeft;
			lBandEnd = AvailArea[nBand][1] - rcFrame.nLeft;

			if (cPosArray[wCol] > lBandEnd)
				continue;   // can't put in this band

			//--- character node loop ---------------------------------------------
			for ( ; wCol < wCharNum; wCol++) {
				// ASSERT (pNode);
				//--- General Character Node
				wCode = pNode->getCode();
				if (pNode->isTextLink() && !CTextProc::isCRCode(wCode)) {
					pTextAtt = text_att_h->getTextAtt(pNode->getAttrID());
					// ASSERT(text_att);
					if (pNode && wCode != ASCII_CODE_SPACE && /*document->m_bCheckSpellFlag &&*/ pNode->getWrongSpell()) {
						x1 = cPosArray[wCol];
						x2 = cPosArray[wCol + 1];
						if (x2 > lBandEnd) x2 = lBandEnd;
						if (x2 > x1) {
							dx = sx + du.doc2LogicalX(x1, BrFALSE);
							dy = sy;
							//--- distance to the next character (logical)
							lOneWid = du.doc2LogicalX(x2 - x1, BrFALSE) + 1;
							//-------------------------------------------------
							/*
							// 일단은 빨간선 !
							hlink_color = RGB_RED;
							// DrawLine(dc->m_hDC, dx, dy, dx+lOneWid, dy, nWidth, hlink_color);
							// 일단 한글식의 밑줄 쫙
							for ( i=0; i<lOneWid; i++ )	{
								switch ( (dx+i)%3 )	{
								case 0:
									dc->setPixel(dx+i, dy+1, hlink_color);
									break;
								case 1:
									dc->setPixel(dx+i, dy, hlink_color);
									break;
								case 2:
									break;
								}
							}
							*/
							// 일단 한글식의 밑줄 쫙
							for (i = 0; i < lOneWid; i++) {
								switch ((dx + i) % 4) {
									case 0:
									case 1:
										dc->setPixel(dx + i, dy - 1, color1);
										dc->setPixel(dx + i, dy, color2);
										dc->setPixel(dx + i, dy + 1, color3);
										break;
									case 2:
									case 3:
										dc->setPixel(dx + i, dy, color3);
										dc->setPixel(dx + i, dy + 1, color2);
										dc->setPixel(dx + i, dy + 2, color1);
										break;
								}
							}
							//-------------------------------------------------
						}
					}
				}
				if (wCol == wCharNum - 1)
					break;

				//--- increase character node
				pNode++;

				//--- splited by run around line_frame,
				//    break CHARNODE LOOP for next CHARNODE in next BAND
				if (lBandEnd < cPosArray[wCol + 1]) {
					wCol++;
					break;
				}
			}
			if (wCol == wCharNum - 1)
				break;
		}
	}
#endif  // _SPELLCHECKER

	DrawParaTabVerticalBar(painter, dc, du, pLine, sx, sy, BrTRUE);
}


void CTextDraw::DrawGaroUnderline(Painter* painter, BrDC* dc, CDrawUnit& du, CFrame* pFrame,
                                  CLine* pLine, BrINT sx, BrINT sy, BrINT nBandCount, BrINT nMaxDescent,
                                  BrINT nUpLineSp)
{
	BoraDoc* document = theBWordDoc;
	if (document == BrNULL || pFrame == BrNULL || pLine == BrNULL)
		return;

	const BrINT frame_left = HorizontalDecoFrameLeft(document->isFromHwp(), pFrame);

	CLongArray& cPosArray = pLine->getPosArray();

	CCmdEngine* pCmdEngine = document->getCmdEngine();

	RevisionEngine* revision_engine = document->getRevisionEngine();
	BrBOOL bShowRevision = revision_engine->getReviewMode() == ReviewMode::ALL_MARKUP;

#ifdef SUPPORT_HIDDEN_TEXT
	BrBOOL bShowHiddenText = (pCmdEngine->m_bBwpDrawForeground & TEXT_DOTLINE_HIDDEN_TEXT) != 0;
#else  // SUPPORT_HIDDEN_TEXT
	BrBOOL bShowHiddenText = BrFALSE;
#endif  // SUPPORT_HIDDEN_TEXT

	if ((pCmdEngine->m_bBwpDrawForeground & TEXT_UNDERLINE_FOREGROUND) == 0 &&
	    BrFALSE == bShowRevision && BrFALSE == bShowHiddenText)
		return;

	const PoTextAtt* pTextAtt = BrNULL;

	CCharSet* pLink = BrNULL;
	BrCOLORREF dwColor = NONE_COLOR_BITS;

	BrINT dx, dy;
	BrINT x1, x2;
	BrINT lOneWidth = 0, lOneHeight = 0, nOrgOneHeight = 0;
	BrWORD wCode;

	PoTextAttHandler* text_att_h = document->getTextAttHandler();
	PoParaAttHandler* para_att_h = document->getParaAttHandler();
	if (BrNULL == text_att_h || BrNULL == para_att_h)
		return;

	CCharSetArray* pLinkArray = pLine->getCharSetArray();
	if (pLinkArray == BrNULL || pLinkArray->size() == 0)
		return;
	BrINT nCharNum = pLinkArray->size();
	if ((BrINT)cPosArray.size() < nCharNum + 1)
		return;

#if defined(USE_HYPERLINK_DRAW_FOR_BWP) || defined(USE_HYPERLINK_TOUCH_FOR_BWP)
	BYTE bSubType;
	BRect rcDraw;
	BrINT nLineSp = du.doc2LogicalDY(CTextProc::CalcLineSpace(document, pLine), BrFALSE) / 2;
#ifdef USE_HYPERLINK_DRAW_FOR_BWP
	PrBitmap sBitmap;
	BrBYTE nAlpha;
#endif  // USE_HYPERLINK_DRAW_FOR_BWP
#endif  // USE_HYPERLINK_DRAW_FOR_BWP || USE_HYPERLINK_TOUCH_FOR_BWP

#ifdef USE_TEXTANIMATION_COUTDEV
	const BrBOOL is_ani_flag = pFrame->getTextAnimationFlag();
	const BrINT ani_base_pos = is_ani_flag? pFrame->getTextAnimationBasePos(): 0;
#else  // USE_TEXTANIMATION_COUTDEV
	const BrINT ani_base_pos = 0;
#endif  // USE_TEXTANIMATION_COUTDEV

	BrINT nWidth = 1;
	BrINT nLineHgt = du.doc2LogicalDY((pLine->getAnchorFlag())?pLine->getHeightWithoutAnchor():pLine->getAscent(), BrFALSE);
	BrINT nCol = 0;

	BYTE bTextFlow = pFrame->getTextFlow();

	BrBOOL bUnderline = BrFALSE;
	BrINT32 nSx, nSy, nDx, nDy, dwUnderlineColor, nUnderlineY, nPrevUnderlineY, nUnderWidth, nUnderDist;
	BrINT nPrevVerticalPos = 0;
	nSx = nSy = nDx = nDy = dwUnderlineColor = nUnderlineY = nPrevUnderlineY = nUnderWidth = nUnderDist = 0;
	BrBOOL bStartRTL = BrFALSE;
	BrBOOL bShowTextWrap = (pFrame->isWrapNone() == BrFALSE && pLine->isLastSpace());
	BrBOOL isUnderline = BrFALSE, isStrikeOut = BrFALSE;
	PoTextAtt textAttForUnderline;
	BrINT nStartCharIndexOfTextBorder = -1;
	BrBOOL bIsTextBorderEnd = BrFALSE;
	BrBOOL bIsBandEnd = BrFALSE;
	BrINT nBorderEndCol = 0;
	BrBOOL bAllSpace = BrTRUE;

	auto& AvailArea = GetAvailAreaMatrix();
	for (BrINT nBand = 0; nBand < nBandCount; nBand++) {
		const auto& area = AvailArea[nBand];
		BrINT nBandStart = area[0] - frame_left;
		BrINT nBandEnd = area[1] - frame_left;

		//[2013.08.19] Underline 제대로 표시되지 않는 오유수정
		//cPosArray에 있는 text좌표는 원본 Frame내에서의 좌표이다.
		//line_frame clone한 경우에는 pFrame->getTextAnimationBasePos()를 덜어야
		//새 frame내에서의 좌표가 된다.
		if (nBandEnd < cPosArray[nCol] - ani_base_pos)
			continue;

		nStartCharIndexOfTextBorder = -1;

		//MS는 라인에서 가장 큰 글자로 밑줄 선을 사용한다.
		nUnderWidth = du.doc2LogicalDY(pLine->getHeightWithoutAnchor(BrFALSE) / 20, BrFALSE);
		if (nUnderWidth < 1)
			nUnderWidth = 1;

		BrBOOL bFoundFirstSpace = BrFALSE;
		if (document->getDocType() != BORA_DOCTYPE_HWP)
			nCharNum = FindUnderlineTrailSpaceStopPos(pLinkArray);

		BrRect frameRct = {sx, sy , sx, sy};
		BrBOOL isHyperLink = BrFALSE;

		for ( ; nCol < nCharNum; nCol++) {
			pLink = pLinkArray->getCharSet(nCol);

			const BrBOOL bDrawRevisionUnderLine = revision_engine->canDrawRevisionUnderLine(pLink);

			CFrame* pAnchoredFrame = BrNULL;
			if (pLink->isAnchorLink())
				pAnchoredFrame = pLink->getFrame(document);

			wCode = pLink->getCode();
			if ((pLink->isTextLink() && !CTextProc::isCRCode(wCode)) ||
			    pLink->isTypesetLink() ||
			    pLink->isFieldExLink() ||
			    //XRF-3269 //20hoon //2014-11-04 //글자 처럼 취급된 도형에도 밑줄 적용합니다.
			    (pLink->isAnchorLink() && pAnchoredFrame && pAnchoredFrame->isAnchored() && !pAnchoredFrame->isTable())) {
				pTextAtt = text_att_h->getTextAtt(pLink->getAttrID());
				isUnderline = pTextAtt->getUnderline();
				isStrikeOut = pTextAtt->getStrikeout() || pTextAtt->getDStrikeout();
				if (bAllSpace && !pLink->isSpace())
					bAllSpace = BrFALSE;

				BrBOOL bUnderlineAttr = isUnderline && pTextAtt->getUnderlineStyle() > UNDERLINE_STYLE_NONE;

				//[ZPD-10506][2015-04-11][sangdon]:PPT에서 하이퍼링크 때도 동일 처리
				BrBOOL bSlideHyperLink = pLink->isFieldLink() && document->isFromSlideType() && IsHyperlinkColorNode(document, pLine, nCol);
				if (bSlideHyperLink)
					bUnderlineAttr = isUnderline = !(pLink->isSpace() && pLine->isHyperLastSpaceInLine(nCol));

#ifdef REMOVE_HYPER_LINK_ATTRIBUTE
				if (IsRemoveHyperlinkAttr(painter, pTextAtt))
					bUnderlineAttr = BrFALSE;
#endif  // REMOVE_HYPER_LINK_ATTRIBUTE
				//[ERH-277]Underline과 UnderlineStyle이 동시에 있을 경우만 언더라인 그려지도록 수정.
				if (document->isFromWordType() && !bUnderlineAttr)
					isUnderline = BrFALSE;
				if (pLink->isBulletLink())
					isUnderline = BrFALSE;
#ifdef PPT_EDITOR
				if (document->getBWPEngineMode() == EDITOR_PPT && wCode == ASCII_CODE_SPACE && bShowTextWrap == BrTRUE && pLine->getSpaceStatus() <= nCol)
					break;
#endif  // PPT_EDITOR
				nWidth = du.doc2LogicalDY(pTextAtt->getHanFSize() / 20, BrFALSE);
				if (nWidth < 1)
					nWidth = 1;

				if (isUnderline || isStrikeOut || pLink->isFieldLink() || bDrawRevisionUnderLine
#ifdef SUPPORT_HIDDEN_TEXT
						|| pTextAtt->getHiddenText()
#endif  // SUPPORT_HIDDEN_TEXT
				) {
					BrBOOL is_normal_rtl = HorizontalCoordinates(x1, x2, bStartRTL, pLine, nCol, ani_base_pos,
					                                             bUnderline, wCode, nBandEnd);
					if (x1 < x2 || bStartRTL) {
						dx = HorizontalLogicalX(du, is_normal_rtl, bStartRTL, sx, x1, x2, nDx);
						dy = sy;

						dwColor = FindUnderlineColor(bSlideHyperLink, bUnderlineAttr, pTextAtt, pLine);

						lOneWidth = du.doc2LogicalDX(x2 - x1, BrFALSE) + 1;

						lOneHeight = du.doc2LogicalDY((pLink->isTwoByteCode())? pTextAtt->getHanFSize(): pTextAtt->getEngFSize(), BrFALSE);
						if (pTextAtt->getSuperscript() || pTextAtt->getSubscript()) {
							nOrgOneHeight = lOneHeight;
							lOneHeight = (BrINT)(lOneHeight * PO_TEXTATT_BASE::superSubScriptSizeRatio);
							if (pTextAtt->getSubscript()) {
								dy -= ((nLineHgt >> 1) >> 1) + (lOneHeight >> 1); //아래 첨자 글자의 Top 좌표
							}
							else {
								dy = dy - nLineHgt + lOneHeight/*-LineOneDescent(document, pLine, nCol)*/; //위 첨자 글자의 Bottom 좌표 (#7663)(2012.7.10)

								if (bUnderlineAttr) //[M-43557][hnsong:2014-01-28] 밑줄 위치 수정
								{
									BrBOOL bSet = BrFALSE;
									CCharSet* pPrevChar = pLinkArray->getCharSet(nCol - 1);
									if (BrFALSE == bUnderline) {
										bSet = BrTRUE;
									}
									else if (BrNULL != pPrevChar) {  // T16522 [8/12/2013 swseo]
										const PoTextAtt* pPrevTextAtt = text_att_h->getTextAtt(pPrevChar->getAttrID());
										if (pPrevTextAtt && pPrevTextAtt->getUnderline() && pTextAtt->getUnderlineStyle() != pPrevTextAtt->getUnderlineStyle())
											bSet = BrTRUE;
									}

									if (bSet)
										nUnderlineY = dy;
								}
								dy += (nLineHgt - nOrgOneHeight);	// IOS #27579 (2013.4.15)
							}
						}

						BrINT verticalPos = pTextAtt->getTextVerticalPos();
						if (isUnderline) {
							if (bTextFlow == TEXTFLOW_GARO) {  //글자의 아래에 Underline을 그려줌
								if ((pTextAtt->getSubscript()) != 0)
									dy += lOneHeight - LineOneDescent(document, pLine, nCol);

								// Superscript를 제외하고 descent를 고려해서 underline을 그려준다.
								if ((pTextAtt->getSuperscript()) == 0) {

									//[ELH-561][2015-03-10][sangdon]:표 내부 글자에 밑줄 이중선 적용시 표 밖으로 밑줄이 나가서 보정
									if ((document->isFromHwp() || document->isFromWordType()) &&
									    pFrame->isCell() && pLine->isEndLine()) {
										BRect rcFrame = *(pFrame->getFrameRect());
										rcFrame = du.doc2Logical(&rcFrame);
										if (rcFrame.nBottom - nWidth < dy)
											dy = rcFrame.nBottom - nWidth;

										switch (pTextAtt->getUnderlineStyle()) {
											case UNDERLINE_STYLE_DOUBLE:
											case UNDERLINE_STYLE_WAVYDOUBLE:
											//case UNDERLINE_STYLE_ROUNDDOT:
											case UNDERLINE_STYLE_THINTHICK:
											case UNDERLINE_STYLE_THICKTHIN:
											case UNDERLINE_STYLE_TRIPLE:
												dy -= nWidth * 1.5;
												break;
										}
									}

									//T-27729 //2014-07-30 //20hoon //글자속성 - 고급 - 위치 설정에 따라 밑줄 위치를 옮겨준다.
									dy += du.doc2LogicalDY(-BrMIN(0, verticalPos), BrFALSE);
								}
							}
							else if (bTextFlow == TEXTFLOW_GARO_ROTATE) {  //글자의 위에 Underline을 그려줌
								if ((pTextAtt->getSubscript()) == 0) {
									dy -= lOneHeight;
									dy -= nWidth * 1.5;
								}
							}
						}

						if (BrFALSE == bUnderline &&
						    (bUnderlineAttr
#ifdef SUPPORT_HIDDEN_TEXT
						      || (pTextAtt->getHiddenText() && (document->getCmdEngine()->IsShowEditSymbol() || document->getCmdEngine()->getEditSymbolShowState().bHiddenText))
#endif  // SUPPORT_HIDDEN_TEXT
						)) {
							nUnderlineY = dy;
						}
						//else if( bUnderline ==BrTRUE && text_att->getUnderline() && nPrevVerticalPos!=text_att->getTextVerticalPos() )
						//	nUnderlineY = dy;
						else if (bUnderline) {
							if (bUnderlineAttr) {
								//T-27729 //2014-07-30 //20hoon //밑줄의 높이가 달라지면 따로 그려준다.
								//ZPD-4117 //2014-11-17 //20hoon // 높이가 달라질때 따로 그려주니 사이드가 나서, Veritcal Pos 가 다를때, 따로 그리는 걸로 고칩니다.
								if (nPrevVerticalPos != verticalPos)
									nUnderlineY = dy;

								//super/sub 이고 그 앞은 꺼져잇거나
								//둘 다 같은데 스타일이 다르거나
								CCharSet* pPrevChar = pLinkArray->getCharSet(nCol - 1);
								if (pPrevChar) {
									const PoTextAtt* pPrevTextAtt = text_att_h->getTextAtt(pPrevChar->getAttrID());
									if (pPrevTextAtt && pPrevTextAtt->getUnderline() && pTextAtt->getUnderlineStyle() != pPrevTextAtt->getUnderlineStyle())
										nUnderlineY = dy;
								}
							}

							if ((textAttForUnderline.getSuperscript() && pTextAtt->getSubscript()) || (textAttForUnderline.getSubscript() && pTextAtt->getSuperscript()))
								nUnderlineY = dy;
							else if (textAttForUnderline.getSuperscript() && !pTextAtt->getSuperscript())	//[ZPD-7858][2015-01-29][sangdon]:본문 각주/미주부터 밑줄 적용시 오류 수정
								nSy = nDy = nPrevUnderlineY = nUnderlineY = dy;
						}

						if (bDrawRevisionUnderLine) {
							BrCOLORREF lineColor = revision_engine->getReviewerColor(pLink, BrTRUE);
							if (pLine) {
								if (document->GetGrayMode() != GRAY_MODE_COLOR) {
									CFrame* frm = pLine->getFrame();
									if (frm) {
										lineColor = BrColor::getBwColor(document->GetGrayMode(), frm->getFrameColorMode(), lineColor, GRAY_MODE_APPLY_TEXT);
									}
								}
							}
							if (pTextAtt->getSubscript() && pTextAtt->getUnderline() == BrFALSE)
								dy += lOneHeight;
							DrawNormalUnderline(dc, dx, dy, dx + lOneWidth, dy, nWidth, lineColor,
							                    &textAttForUnderline, pLine, nLineHgt);
						}
						else if (isUnderline
#ifdef SUPPORT_HIDDEN_TEXT
						    || (pTextAtt && (pTextAtt->getHiddenText() && (document->getCmdEngine()->IsShowEditSymbol() || document->getCmdEngine()->getEditSymbolShowState().bHiddenText)))
#endif  // SUPPORT_HIDDEN_TEXT
						) {
							//hnsong:2012-05 PO5.0 개발항목 - 밑줄의 종류 지원
							if (bUnderline) {
								//hizoa 130816 넘버링,블릿에 밑줄 생략.
								//7.0 bullet 글꼴 속성에서 underline 지원
								if (pLink->isBulletLink() && (pLink->getCode() == ASCII_CODE_TAB || pLink->getCode() == ASCII_CODE_SPACE))
									continue;
								//BrWORD단위로 밑줄 지원
								if (UNDERLINE_STYLE_WORDS == pTextAtt->getUnderlineStyle() && (ASCII_CODE_SPACE == wCode || ASCII_CODE_TAB == wCode)) {
									bUnderline = BrFALSE;
									bStartRTL = BrFALSE;
									DrawGaroUnderlineBitmap(painter, dc, nSx, nSy, nDx, nDy, frameRct, 1, nUnderWidth, dwUnderlineColor, &textAttForUnderline, pFrame, pLine, nCol, nLineHgt, nMaxDescent);
									continue;
								}

								if ((nPrevUnderlineY && nPrevUnderlineY > nUnderlineY && nSy != nPrevUnderlineY) ||
								    nSy != nUnderlineY ||
										pTextAtt->getUnderlineStyle() != textAttForUnderline.getUnderlineStyle() ||
										pTextAtt->getUnderlinePos() != textAttForUnderline.getUnderlinePos()
								) {
									bUnderline = BrFALSE;
									bStartRTL = BrFALSE;
									DrawGaroUnderlineBitmap(painter, dc, nSx, nSy, nDx, nDy, frameRct, 1, nUnderWidth, dwUnderlineColor, &textAttForUnderline, pFrame, pLine, nCol, nLineHgt, nMaxDescent, isHyperLink);
								}
								else {
									BrINT32 dwUnderColor = 0;
									dwUnderColor = ((pTextAtt->getUnderlineColor()).getColor() != NONE_COLOR_BITS)?
										(pTextAtt->getUnderlineColor()).getColor(): dwColor;

									BrGrapAtt* grapAtt = pTextAtt->isSettedGrapAtt()? pTextAtt->getGrapAtt(): BrNULL;
									BrGrapAtt* grapAttForUnderline = textAttForUnderline.isSettedGrapAtt()? textAttForUnderline.getGrapAtt(): BrNULL;

									if (dwUnderColor != dwUnderlineColor
											|| ((grapAtt && !grapAttForUnderline) || (!grapAtt && grapAttForUnderline))
											|| (!pTextAtt->equalWordArtStyle(&textAttForUnderline) && (bSlideHyperLink || (grapAtt && grapAtt->isGradient()) || (grapAttForUnderline && grapAttForUnderline->isGradient())))
											|| (!pTextAtt->hasEqualShadowAtt(&textAttForUnderline))
											|| bSlideHyperLink != isHyperLink) {
										bUnderline = BrFALSE;
										bStartRTL = BrFALSE;
										DrawGaroUnderlineBitmap(painter, dc, nSx, nSy, nDx, nDy, frameRct, 1, nUnderWidth, dwUnderlineColor, &textAttForUnderline, pFrame, pLine, nCol, nLineHgt, nMaxDescent, isHyperLink);
									}
								}
							}

							if (bUnderline) {
								if (bStartRTL)
									nDx = dx;
								else
									nDx = dx + lOneWidth;
							}
							else {
								if (!(pTextAtt->getUnderlineStyle() == UNDERLINE_STYLE_WORDS && (ASCII_CODE_SPACE == wCode || ASCII_CODE_TAB == wCode)))
									bUnderline = BrTRUE;

								textAttForUnderline = *pTextAtt;
								dwUnderlineColor = ((pTextAtt->getUnderlineColor()).getColor() == NONE_COLOR_BITS)? dwColor: pTextAtt->getUnderlineColor().getColor();

								if (pTextAtt->getSuperscript() || pTextAtt->getSubscript())
									nUnderWidth = nOrgOneHeight / 20;

								nSx = dx;
								if (bStartRTL)
									nDx = dx - lOneWidth;
								else
									nDx = dx + lOneWidth;

								nSy = nDy = nPrevUnderlineY = nUnderlineY;
								nPrevVerticalPos = verticalPos;
							}

							if (bStartRTL) {
								frameRct.left = BrMIN(frameRct.left, nDx);
								frameRct.right = BrMAX(frameRct.right, nSx);
							}
							else {
								frameRct.left = BrMIN(frameRct.left, nSx);
								frameRct.right = BrMAX(frameRct.right, nDx);
							}
						}
						else {
							nPrevUnderlineY = 0;
							nPrevVerticalPos = 0;
							if (bUnderline) {
								bUnderline = BrFALSE;
								bStartRTL = BrFALSE;
								DrawGaroUnderlineBitmap(painter, dc, nSx, nSy, nDx, nDy, frameRct, 1, nUnderWidth, dwUnderlineColor, &textAttForUnderline, pFrame, pLine, nCol, nLineHgt, nMaxDescent, isHyperLink);
							}
						}
					}

					frameRct.top = BrMIN(frameRct.top, nSy - lOneHeight);
					frameRct.bottom = BrMAX(frameRct.bottom, nDy);
				}
				else {
					if (bUnderline
#ifdef SUPPORT_HIDDEN_TEXT
							|| (pTextAtt->getHiddenText() && (document->getCmdEngine()->getEditSymbolShowState().bHiddenText || document->getCmdEngine()->IsShowEditSymbol()))
#endif  // SUPPORT_HIDDEN_TEXT
							) {
						if (bUnderline) {
							bUnderline = BrFALSE;
							bStartRTL = BrFALSE;
							BrCOLORREF lineColor = dwUnderlineColor;
							if (pLine) {
								if (document->GetGrayMode() != GRAY_MODE_COLOR) {
									CFrame* frm = pLine->getFrame();
									if (frm) {
										lineColor = BrColor::getBwColor(document->GetGrayMode(), frm->getFrameColorMode(), lineColor, GRAY_MODE_APPLY_TEXT);
									}
								}
							}
#ifdef SUPPORT_HIDDEN_TEXT
							if (textAttForUnderline.getUnderline() == BrFALSE && !isHyperLink)
								lineColor = RGB_DKGRAY;
#endif  // SUPPORT_HIDDEN_TEXT

							DrawGaroUnderlineBitmap(painter, dc, nSx, nSy, nDx, nDy, frameRct, 1/* 3 */, nUnderWidth, lineColor, &textAttForUnderline, pFrame, pLine, nCol, nLineHgt, nMaxDescent, isHyperLink);
						}
					}
				}

				isHyperLink = bSlideHyperLink;
			}
#if defined(USE_HYPERLINK_DRAW_FOR_BWP) || defined(USE_HYPERLINK_TOUCH_FOR_BWP)
			if (!g_pAppStatic->isPrtPreview() && !document->getCmdEngine()->isSlideShow() /*document->getEditProtect()*/ &&
					!document->getCmdEngine()->isSkipDecoIcon() && (bSubType = pLink->isFieldLink()) != 0) {
				x1 = cPosArray[nCol];
				x2 = cPosArray[nCol + 1];
				if (x2 > nBandEnd) x2 = nBandEnd;
				rcDraw.nLeft = sx + du.doc2LogicalDX(x1, BrFALSE);
				rcDraw.nRight = sx + du.doc2LogicalDX(x2, BrFALSE);
				rcDraw.nTop = sy - du.doc2LogicalDY(pLine->getAscent(), BrFALSE) - nLineSp;
				rcDraw.nBottom = sy + nLineSp;
#ifdef USE_HYPERLINK_TOUCH_FOR_BWP
				BrBOOL& is_draw_touched_hyperlink = dynamic_cast<Painter_BWP*>(painter)->m_bDrawTouchedHyperLink;
				if (((bSubType & START_LINK) != 0) && (painter->m_nTouchHyperLinkIndex == pLink->getCode()))
					is_draw_touched_hyperlink = BrTRUE;

				if (is_draw_touched_hyperlink) {
					BrBmvBrush brush, * pOldBrush;
					BrCOLORREF lineColor = RED_COLOR;
					if (pLine) {
						if (document->GetGrayMode() != GRAY_MODE_COLOR) {
							CFrame* pFrame = pLine->getFrame();
							if (pFrame) {
								lineColor = BrColor::getBwColor(document->GetGrayMode(), pFrame->getFrameColorMode(), lineColor, GRAY_MODE_APPLY_TEXT);
							}
						}
					}

					brush.createSolidBrush(lineColor);
					pOldBrush = dc->setBrush(&brush);

					if ((bSubType & START_LINK) != 0)
						dc->fillRect(rcDraw.nLeft, rcDraw.nTop, rcDraw.nLeft + 3, rcDraw.nBottom);
					if ((bSubType & END_LINK) != 0) {
						dc->fillRect(rcDraw.nRight - 3, rcDraw.nTop, rcDraw.nRight, rcDraw.nBottom);
						is_draw_touched_hyperlink = BrFalse;
					}

					dc->fillRect(rcDraw.nLeft, rcDraw.nTop, rcDraw.nRight, rcDraw.nTop + 3);
					dc->fillRect(rcDraw.nLeft, rcDraw.nBottom - 3, rcDraw.nRight, rcDraw.nBottom);
					dc->setBrush(pOldBrush);
				}
#endif  // USE_HYPERLINK_TOUCH_FOR_BWP
#ifdef USE_HYPERLINK_DRAW_FOR_BWP
				if ((bSubType & END_LINK) != 0) {
					CFieldHyper* pField = (CFieldHyper*)document->getFieldArray()->getField(pLink->getCode());

					if (pField && pField->getFieldType() == E_FIELD_HYPER) {
						bool bDrawLink = false;

						if (document->getBWPEngineMode() == EDITOR_WORD) {
							// 하이퍼링크아이콘표시(우선목차는제외)
							if (pField->getLinkType() == LINK_TO_URL || pField->getLinkType() == LINK_TO_EMAIL || pField->getLinkType() == LINK_TO_FILE
									|| (pField->getLinkType() == LINK_TO_BOOKMARK))
								bDrawLink = true;
						}
						else {
							if ((pField->getRunType() & LINK_RUNTYPE_MOUSE_CLICK) || (pField->getRunType() & LINK_RUNTYPE_MOUSE_OVER))
								bDrawLink = true;
						}

						if (bDrawLink) {
							nAlpha = dc->setAlphaValue(0xff);
							// 하이퍼링크 아이콘 위치 및 크기 변경
							BrDOUBLE dip_ratio = 1;
							if (document->getCmdEngine()->m_dDeviceDIP != 0) {
								dip_ratio = document->getCmdEngine()->m_dDeviceDIP / DEFAULT_DEVICE_DIP;
								if (dip_ratio < 1)
									dip_ratio = 1;
							}

							BrINT nIconSize = 12;
							nIconSize = document->getCmdEngine()->getIconSize(nIconSize);
							if (!sBitmap.isHasBitmap()) {
								PrBitmapFlag sFlag;
								sBitmap.loadImagePtr((BrUCHAR*)g_pAppStatic->g_pICO_HYPERLINK_PNG, ICO_HYPERLINK_PNG_NUM, nIconSize, nIconSize, 0, sFlag, BrNULL);
							}
							if (sBitmap.isHasBitmap())
								dc->stretchBlt(rcDraw.nRight, rcDraw.nTop - nIconSize * dip_ratio, 14, 14, &sBitmap, 0, 0, sBitmap.cx(), sBitmap.cy(), SRCCOPY);
							dc->setAlphaValue(nAlpha);
						}
					}
				}
#endif  // USE_HYPERLINK_DRAW_FOR_BWP
			}
#endif  // USE_HYPERLINK_DRAW_FOR_BWP || USE_HYPERLINK_TOUCH_FOR_BWP
			if (pLink->isAnchorLink() && bDrawRevisionUnderLine) {
				BrCOLORREF lineColor = revision_engine->getReviewerColor(pLink, BrTRUE);
				if (pLine) {
					if (document->GetGrayMode() != GRAY_MODE_COLOR) {
						CFrame* frm = pLine->getFrame();
						if (frm) {
							lineColor = BrColor::getBwColor(document->GetGrayMode(), frm->getFrameColorMode(), lineColor, GRAY_MODE_APPLY_TEXT);
						}
					}
				}
				CFrameList* pAFrameList = document->getAFrameList();

				BRect stDrawRect;
				if (pAFrameList) {
					CFrame* frm = pAFrameList->getFrame(pLink->getCode());
					if (frm && frm->isAnchored() && BrFALSE == frm->isTextBox() && revision_engine->isInsertedFrame(pLink)) {
						stDrawRect = *(frm->getFrameRect());
						stDrawRect = du.doc2Logical(&stDrawRect);
						CCUtil::drawLine(dc, stDrawRect.Left(), stDrawRect.Bottom() + 2, stDrawRect.Right(), stDrawRect.Bottom() + 2, nWidth, lineColor);
					}
				}
			}
			if (nCol == nCharNum - 1) {
				if (pTextAtt != BrNULL && pTextAtt->isSettedTextBorderLineInfo()) {
					if (nStartCharIndexOfTextBorder == -1) {
						if ((pLink->isTextLink() || pLink->isFieldLink() || pLink->isFieldExLink()) &&
								!pLink->isCROrSoftEnterLink())
							nStartCharIndexOfTextBorder = nCol;
					}

					CCharSet* pNextCharset = pLinkArray->getCharSet(nCol + 1);
					BrINT nAfterBorderWidth = 0;
					const PoTextAtt* pNextTextAtt = BrNULL;
					nBorderEndCol = nCol;

					if (pNextCharset != BrNULL) {
						pNextTextAtt = text_att_h->getTextAtt(pNextCharset->getAttrID());

						if (BrTRUE == pNextTextAtt->isSettedTextBorderLineInfo() && !pNextCharset->isBreakLink() && !pNextCharset->isCRLink()) {
							nAfterBorderWidth = pNextTextAtt->getTextBorderLineInfo()->getAllBorderLineStyleWidth();
							if (pNextTextAtt->getTextBorderLineInfo()->isShadowBorderLine())
								nAfterBorderWidth *= 2;
						}
					}
					if (nStartCharIndexOfTextBorder != -1)
						ProcessDrawTextBorderForGaro(painter, dc, du, pFrame, pTextAtt, pLine, nStartCharIndexOfTextBorder, nBorderEndCol, sx, sy, nAfterBorderWidth, BrFALSE, nMaxDescent, nUpLineSp);

					nStartCharIndexOfTextBorder = -1;
				}

				nCol++;
				break;
			}

			//BrBOOL bIsCRTextBorder = BrFALSE;
			//TextBorder 셋팅 부분에서 bullet TextAtt에도 셋팅하므로 bullet을 체크하지 않음
//			if( pLink->isBulletLink() && pLine->getLastLineOfPara()->getLastLink() )
//			{
//				CCharSet* pLastLink = pLine->getLastLineOfPara()->getLastLink();
//
//				if( pLastLink )
//				{
//					pTextAttOf4TextBorder = textAttHandler->getAttr(pLastLink->getAttrID());
//					if(pTextAttOf4TextBorder && pTextAttOf4TextBorder->isHasTextBorderLineInfo() )
//						bIsCRTextBorder = BrTRUE;
//				}
//			}

			if ((pTextAtt != BrNULL && pTextAtt->isSettedTextBorderLineInfo())) {
				nBorderEndCol = nCol;
				bIsTextBorderEnd = BrFALSE;
				bIsBandEnd = BrFALSE;

				if (nStartCharIndexOfTextBorder == -1) {
					if ((pLink->isTextLink() || pLink->isFieldLink() || pLink->isFieldExLink() || pLink->isFootnoteEndnoteLink()) &&
							!pLink->isCRLink())
						nStartCharIndexOfTextBorder = nCol;
				}

				if (nStartCharIndexOfTextBorder != -1) {
					CCharSet* pNextCharset = pLinkArray->getCharSet(nCol + 1);
					const PoTextAtt* pNextTextAtt = BrNULL;
					if (pNextCharset != BrNULL) {
						pNextTextAtt = text_att_h->getTextAtt(pNextCharset->getAttrID());

						//메모 링크 삽입 시, attID를 0로 해주므로 border에 대한 체크를 하지 않는다.
						if (pNextTextAtt != BrNULL && !pNextCharset->isMemoLink()) {
							//if(BrFALSE==text_att->isEqualTextBorder(pNextTextAtt->getTextBorder()))
							if ((BrFALSE == pTextAtt->isEqualTextBorderLineInfo(pNextTextAtt->getTextBorderLineInfo()))) {
								bIsTextBorderEnd = BrTRUE;
								//TextBorder 셋팅 부분에서 bullet TextAtt에도 셋팅하므로 bullet을 체크하지 않음
								// 									if(bIsCRTextBorder && pNextCharset->isBulletLink())
								// 										bIsTextBorderEnd = BrFALSE;
							}

						}

						if (pNextCharset->isBreakLink() || pNextCharset->isCRLink() || pNextCharset->isSoftEnterLink()) {
							bIsTextBorderEnd = BrTRUE;
						}
						else if (pLink->isBreakLink() || pLink->isCRLink() || pLink->isSoftEnterLink() /*|| pLink->isAnchorLink()*/)	//ZPD-20992 글자처럼 취급된 Frame도 TextBorder 적용
						{
							bIsTextBorderEnd = BrTRUE;
							nBorderEndCol = nCol - 1;
							if (nBorderEndCol < 0) nBorderEndCol = nCol;
						}

						if (nBandEnd <= cPosArray[nCol + 1]/*)*/) {
							//bIsTextBorderEnd = BrTRUE;
							bIsBandEnd = BrTRUE;
						}

						BRect* rcFrame = pFrame->getFrameRect();
						if (rcFrame->nRight <= cPosArray[nCol + 1]) {
							bIsTextBorderEnd = BrTRUE;
							//bIsBandEnd = BrTRUE;
						}
					}
					else {
						bIsTextBorderEnd = BrTRUE;
						bIsBandEnd = BrTRUE;
						if (nBorderEndCol < 0) nBorderEndCol = nCol;
					}
				}

				if (BrTRUE == bIsTextBorderEnd) {
					CCharSet* pNextCharset = pLinkArray->getCharSet(nBorderEndCol + 1);
					BrINT nAfterBorderWidth = 0;
					const PoTextAtt* pNextTextAtt = BrNULL;

					if (pNextCharset != BrNULL) {
						pNextTextAtt = text_att_h->getTextAtt(pNextCharset->getAttrID());

						if (pNextTextAtt->getTextBorderLineInfo() && !pNextCharset->isBreakLink() && !pNextCharset->isCRLink()) {
							nAfterBorderWidth = pNextTextAtt->getTextBorderLineInfo()->getAllBorderLineStyleWidth();
							if (pNextTextAtt->getTextBorderLineInfo()->isShadowBorderLine())
								nAfterBorderWidth *= 2;
						}
					}

					ProcessDrawTextBorderForGaro(painter, dc, du, pFrame, pTextAtt, pLine, nStartCharIndexOfTextBorder, nBorderEndCol, sx, sy, nAfterBorderWidth, bIsBandEnd, nMaxDescent, nUpLineSp, bAllSpace);
					nStartCharIndexOfTextBorder = -1;
					bIsTextBorderEnd = BrFALSE;
					bIsBandEnd = BrFALSE;
				}
			}

			//[2013.08.19] Underline 제대로 표시되지 않는 오유수정
#ifndef USE_TEXTANIMATION_COUTDEV
			if (nBandEnd < cPosArray[nCol + 1]) {
				nCol++;
				break;
			}
#else  // USE_TEXTANIMATION_COUTDEV
			if (is_ani_flag) {
				if (nBandEnd < cPosArray[nCol + 1] - ani_base_pos) {
					nCol++;
					break;
				}
			}
			else if (nBandEnd < cPosArray[nCol + 1]) {
				if (pTextAtt != BrNULL && pTextAtt->getTextBorderLineInfo()) {
					CCharSet* pNextCharset = pLinkArray->getCharSet(nCol + 1);
					BrINT nAfterBorderWidth = 0;
					const PoTextAtt* pNextTextAtt = BrNULL;
					nBorderEndCol = nCol;

					//ZPD-5157
					//20hoon //표안에서 오른쪽 맞춤시 CR이 밴드를 넘어갈때 처리
					if (nCol == 0)
						nStartCharIndexOfTextBorder = nCol;

					if (pNextCharset != BrNULL) {
						pNextTextAtt = text_att_h->getTextAtt(pNextCharset->getAttrID());

						if (pNextTextAtt->getTextBorderLineInfo() && !pNextCharset->isBreakLink() && !pNextCharset->isCRLink()) {
							nAfterBorderWidth = pNextTextAtt->getTextBorderLineInfo()->getAllBorderLineStyleWidth();
							if (pNextTextAtt->getTextBorderLineInfo()->isShadowBorderLine())
								nAfterBorderWidth *= 2;
						}
					}
					if (nStartCharIndexOfTextBorder != -1)
						ProcessDrawTextBorderForGaro(painter, dc, du, pFrame, pTextAtt, pLine, nStartCharIndexOfTextBorder, nBorderEndCol, sx, sy, nAfterBorderWidth, BrTRUE, nMaxDescent, nUpLineSp, bAllSpace);

					nStartCharIndexOfTextBorder = -1;
				}

				nCol++;
				break;
			}
#endif  // USE_TEXTANIMATION_COUTDEV
		}

		if (bUnderline) {
			bUnderline = BrFALSE;
			bStartRTL = BrFALSE;

#ifdef SUPPORT_HIDDEN_TEXT
			if (pTextAtt && pTextAtt->getUnderline() == BrFALSE && !isHyperLink)
				dwUnderlineColor = RGB_DKGRAY;
#endif  // SUPPORT_HIDDEN_TEXT

			DrawGaroUnderlineBitmap(painter, dc, nSx, nSy, nDx, nDy, frameRct, 1/* Underline */, nUnderWidth, dwUnderlineColor, &textAttForUnderline, pFrame, pLine, nCol, nLineHgt, nMaxDescent, isHyperLink);
		}

		if (nCol >= nCharNum)
			break;
	}
}


BrLONG CTextDraw::HorizontalDecoFrameLeft(BrBOOL is_hwp, CFrame* frame)
{
	BRect rect(frame->getFrameRect());
	BrINT angle = is_hwp? frame->GetRotation(): 0;
	if (angle)
		BrDrawUnit::getContainerRect(rect, angle, rect);
	return rect.Left();
}


BrINT CTextDraw::FindUnderlineTrailSpaceStopPos(CCharSetArray* pLinkArray)
{
	//  if(theBWordDoc->isulTrailSpace())	//[WPD-1946] 줄 끝 밑줄 표시 무조건 true로 처리 (기능 지원 여부 논의 후 재수정 예정)
	return pLinkArray->size();  // ???

	BrINT nStCol = pLinkArray->size();
	CCharSet* pCheckSpace = BrNULL;
	BrBOOL bFoundFirstSpace = BrFALSE;

	for (BrINT i = 0; i < pLinkArray->size(); i++) {
		pCheckSpace = pLinkArray->getCharSet(i);
		if (pCheckSpace->isCRLink())
			break;

		if (pCheckSpace->isSpace()) {
			if (BrFALSE == bFoundFirstSpace) {
				nStCol = i;
				bFoundFirstSpace = BrTRUE;
			}
		}
		else {
			bFoundFirstSpace = BrFALSE;
		}
	}

	return bFoundFirstSpace? nStCol: pLinkArray->size();
}


BrBOOL CTextDraw::IsHyperlinkColorNode(BoraDoc* document, CLine* pLine, BrINT nCol)
{
	// 캐릭터 들어올때 마다 fieldID 탐색하지 않도록 BoraDoc::m_bIsHypertext 변수 사용. [6/26/2014 hskang]
	// MOVE CTextProc::s_bIsHperText to BoraDoc::m_bIsHypertext [anesin]
	BrBOOL is_hypertext = (document && document->IsHypertext());
	if (BrNULL == document || BrNULL == pLine)
		return is_hypertext;

	if (BrFALSE == is_hypertext) {
		CLocation cLoc(pLine, nCol);
		if (cLoc.moveToStartOfField(BrTRUE, BrTRUE)) {
			CCharSet* pLink = cLoc.getCharSet();

			if (pLink && pLink->isFieldStartLink()) {
				CFieldArray* pFieldArray = document->getFieldArray();
				CField* pField = pFieldArray->getField(pLink->getCode());

				if (document->isFromSlideType() && pField) {
					BrINT run_type = dynamic_cast<CFieldHyper*>(pField)->getRunType();
					if (pField->getFieldType() == E_FIELD_HYPER &&
					    run_type & LINK_RUNTYPE_MOUSE_CLICK ||
					    run_type & LINK_RUNTYPE_MOUSE_OVER) {
						is_hypertext = BrTRUE;
						document->SetIsHypertext(BrTRUE);
					}
				}
			}
		}
	}

	//다음 문자가 field의 마지막인지 체크
	CCharSetArray* pLinkArray = pLine->getCharSetArray();
	BrINT nCharNum = pLinkArray->size();
	CCharSet* pNextLink = BrNULL;
	if (nCol + 1 < nCharNum)
		pNextLink = pLinkArray->getCharSet(nCol + 1);

	// 현재 링크의 next 링크가 fieldEndLink 라면 BoraDoc::m_bIsHypertext는 false로 변경하여
	// 필드 아이디 새로 탐색하게 함.
	if (pNextLink && pNextLink->isFieldEndLink())
		document->SetIsHypertext(BrFALSE);
	return is_hypertext;
}


#ifdef REMOVE_HYPER_LINK_ATTRIBUTE
BrBOOL CTextDraw::IsRemoveHyperlinkAttr(Painter* painter, const PoTextAtt* pTextAtt)
{
	if (!painter || !pTextAtt)
		return BrFALSE;

	BrBOOL bPdfExport = isExportMode() && painter->pDC && painter->pDC->getDCType() == ePDFExtDCType;
	if (bPdfExport) {
		BrExportDC* pExportDC = (BrExportDC*)painter->pDC;
		if (!pExportDC->getRemoveHyperLink())
			return BrFALSE;

		LINKTYPE bLinkType = pTextAtt->getLinkType();
		BrBYTE bSubType = pTextAtt->getSubType();
		if ((bLinkType == LINKTYPE::FIELD   && bSubType == INNER_FIELD  ) ||
		    (bLinkType == LINKTYPE::TYPESET && bSubType == FOOTNOTE_MARK))
			return BrTRUE;
	}
	return BrFALSE;
}
#endif  // REMOVE_HYPER_LINK_ATTRIBUTE


BrBOOL CTextDraw::HorizontalCoordinates(BrINT& x1, BrINT& x2, BrBOOL& is_start_rtl,
                                        CLine* line, BrINT col, BrINT ani_base_pos,
                                        BrBOOL is_deco_line, BrWORD code, BrINT band_end)
{
	CLongArray& pos_arr = line->getPosArray();
	x1 = pos_arr[col] - ani_base_pos;
	x2 = pos_arr[col + 1] - ani_base_pos;

	PoParaAttHandler* para_att_h = theBWordDoc->getParaAttHandler();
	const PoParaAtt* para_att = para_att_h->getMergedParaAtt(line->getParaID(), line);
	BrBOOL is_normal_rtl = (BrFALSE == is_deco_line && IsRTLChar(code) && para_att->getBiDi());

#ifdef BIDI_SUPPORT
	if (is_normal_rtl) {
		is_start_rtl = BrTRUE;
		BrINT count = line->getCharNum();
		for (BrINT i = 0, m = band_end; i <= count; i++) {
			BrINT pos = pos_arr[i];
			if (x1 < pos && pos <= m)
				x2 = m = pos;
		}
	}
#endif  // BIDI_SUPPORT

	// XPD-12646 Tablet(#7922)
	if (band_end < x2)
		x2 = band_end;

	return is_normal_rtl;
}


BrINT CTextDraw::HorizontalLogicalX(CDrawUnit& du, BrBOOL is_normal_rtl, BrBOOL is_start_rtl,
                                    BrINT sx, BrINT x1, BrINT x2, BrINT dx)
{
	if (is_normal_rtl)
		return sx + du.doc2LogicalDX(x2, BrFALSE);

	if (is_start_rtl) {
		BrINT x = sx + du.doc2LogicalDX(BrMIN(x1, x2), BrFALSE);
		return BrMIN(x, dx);
	}

	return sx + du.doc2LogicalDX(x1, BrFALSE);
}


BrINT CTextDraw::LineOneDescent(BoraDoc* document, CLine* pLine, BrINT nCol)
{
	if (!document || !pLine)
		return 0;

	CCharSetArray* pLinkArray = pLine->getCharSetArray();
	CCharSet* pLink = pLinkArray->getCharSet(nCol);
	if (!pLink || pLink->isCROrSoftEnterLink() || !pLink->isTextLink() || pLink->is4BYTE())
		return 0;

	// [dwchun : 2011.09.23]
	// : 뷰어일 때는 이 함수를 처음 한번만 호출함.
	//   따라서 Twip으로 값을 구하고 Viewer에서 Zoom비율에 따라 값을 변환할 수 있도록 수정
	const PoTextAtt* pTextAtt = document->getTextAttHandler()->getTextAtt(pLink->getAttrID());
	BrINT nFontID;
	if (IsHwpSymbol(document, pLink->getCode()))
		nFontID = pTextAtt->getSymbolFontID();
	else if (IsFullWidthChar(pLink->getCode()))
		nFontID = pTextAtt->getHanFontID();
	else
		nFontID = pTextAtt->getEngFontID();

	BrINT nFSize = pTextAtt->getHanFSize();
	if (document->getBWPEngineMode())
		nFSize = document->getCmdEngine()->distanceDoc2LogicalY(nFSize);
	if (pTextAtt->getSubscript() || pTextAtt->getSuperscript())
		nFSize *= PO_TEXTATT_BASE::superSubScriptSizeRatio;

	BFont newBFont;
	newBFont.setFontAttribute(nFSize, pTextAtt->getBold(), pTextAtt->getItalic());
	newBFont.setFontSize(nFSize, DEFAULT_TEXT_HORIZ_SCALE);
	newBFont.setFontName((BrUSHORT*)document->getFontArray()->GetAt(nFontID)->lf.lfFaceName, MAX_FONT_LEN);

	return newBFont.getCharDescent();
}


void CTextDraw::DrawNormalUnderline(BrDC* dc, BrINT sx, BrINT sy, BrINT dx, BrINT dy, BrINT width,
                                    BrINT color, const PoTextAtt* text_att, CLine* line, BrINT height)
{

	/*[ZPD-10087][2015-06-05][sangdon]:밑줄색이 자동일때 함수 호출 전 DrawForegroundOfGaroOneLine, DrawForegroundOfSeroOneLine 함수에서 계산 하도록 처리.
		//underline이 자동일때는 텍스트 색상을 according
		if (
	#ifdef SUPPORT_HIDDEN_TEXT
			text_att->getHiddenText() == BrFALSE &&
	#endif  // SUPPORT_HIDDEN_TEXT
			text_att->getUnderLineAutoColor() )
		{
			if ( text_att->getAutoColor() )
				color = AutoTextColor(line, text_att);
			else
				color = text_att->getTextColor().getColor();
		}
	*/

	if (line) {
		if (theBWordDoc->GetGrayMode() != GRAY_MODE_COLOR) {
			CFrame* pFrame = line->getFrame();
			if (pFrame) {
				color = BrColor::getBwColor(theBWordDoc->GetGrayMode(), pFrame->getFrameColorMode(), color, GRAY_MODE_APPLY_TEXT);
			}
		}
#ifdef SUPPORT_LOW_VISION_SHAPE
		if (theBWordDoc && theBWordDoc->m_pLowVisionColorModeEngine)
			color = theBWordDoc->m_pLowVisionColorModeEngine->GetTextColor();
#endif  // SUPPORT_LOW_VISION_SHAPE

		if (line->getFrame() && line->getFrame()->isBrightenColor4HeaderFooter())
			color = BrUtil::BrightenColor(color);
	}

	// check underline position for HWP
	if (theBWordDoc->isFromHwp()) {
		if (text_att != BrNULL) {
			if (text_att->getSubscript() || text_att->getSuperscript()) {
				//ZPD-2773 //2014-10-15 //20hoon
				//웟첨자/아랫첨자일때는,
				//밑줄의 위치를 조절할때 사용하는 height 를 전체 라인 높이가 아니라,
				//폰트 사이즈 ( 폰트 사이즈*0.65 --> 위첨자, 아랫첨자용 폰트 사이즈 ) 로 사용한다.
				CDrawUnit unit;
				unit.setOrg(0, 0);
				unit.setDefaultOutputOption();
				unit.setFactor(g_pAppStatic->m_nResX, g_pAppStatic->m_nResY, getPainter()->getZoomScale());
				height = unit.doc2LogicalX(text_att->getHanFSize()*PO_TEXTATT_BASE::superSubScriptSizeRatio, BrFALSE);
			}

			// 위
			if (text_att->getUnderlinePos() == BR_UNDERLINE_POS_TOP) {
				BrINT nSx = sx, nSy = sy, nEx = dx, nEy = dy;
				// GARO
				if (sy == dy) {
					nSy = sy - height;
					nEy = dy - height;
				}
				// SERO
				else if (sx == dx) {
					nSx = sx + height;
					nEx = dx + height;
				}
				CCUtil::drawUnderLine(dc, nSx, nSy, nEx, nEy, width, color, text_att->getUnderlineStyle());
			}
			// 아래
			else if (text_att->getUnderlinePos() == BR_UNDERLINE_POS_BOTTOM) {
				CCUtil::drawUnderLine(dc, sx, sy, dx, dy, width, color, text_att->getUnderlineStyle());
			}
		}
	}
	// For MS-Word
	else {
#ifdef SUPPORT_HIDDEN_TEXT
		BrINT nUnderLineStyle = 0;
		if (text_att && text_att->getHiddenText())
			nUnderLineStyle = UNDERLINE_STYLE_DOTTED;
		else {
			if (text_att)
				nUnderLineStyle = text_att->getUnderlineStyle();
			else
				nUnderLineStyle = UNDERLINE_STYLE_SINGLE;
		}
		CCUtil::drawUnderLine(dc, sx, sy, dx, dy, width, color, nUnderLineStyle, text_att? text_att->getShadow(): BrFALSE);
#else
		CCUtil::drawUnderLine(dc, sx, sy, dx, dy, width, color, text_att? text_att->getUnderlineStyle(): UNDERLINE_STYLE_SINGLE, text_att? text_att->getShadow(): BrFALSE);
#endif  // SUPPORT_HIDDEN_TEXT
	}
}


BrCOLORREF CTextDraw::AutoTextColor(CLine* line, const PoTextAtt* text_att, BrColor* auto_color)
{
	 //자동색보다 테마색이 우선순위 높음
	if (!text_att->getAutoColor() || (text_att->getTextColorTheme() && text_att->getTextColor().isTheme()))
		return text_att->getTextColor().getColor();

	if (auto_color && (auto_color->isTheme() || (NONE_COLOR_BITS != auto_color->getColor())))
		return auto_color->getColor();

	//hwp 에서는 오토칼라가 없습니다.
	if (theBWordDoc->isFromHwp())
		return RGB_BLACK;

	if (theBWordDoc->isViewOutlineMode())
		return RGB_BLACK;

	BrCOLORREF dwBackColor = RGB_WHITE;
	BrBOOL bSetBackColor = BrFALSE;
	CFrame* pFrame = BrNULL;
	//if ( text_att->getBackFlag() )
	//{
	//	dwBackColor = text_att->getBackColor();
	//	bSetBackColor = BrTRUE;
	//}
	if (line) {
		PoParaAttHandler* pParaAttHandler = theBWordDoc->getParaAttHandler();
		const PoParaAtt* pParaAtt = pParaAttHandler->getMergedParaAtt(line->getParaID(), line);

		BrCOLORREF dwTextShadingFillColor = text_att->getShadingFillColor().getColor(); //[T-16745][2013-08-28] 20hoon
		BrCOLORREF dwTextShadingPatternColor = text_att->getShadingPatternColor().getColor();//[T-16745][2013-08-28] 20hoon
		BrINT cTextShadingPatternStyle = text_att->getShadingPatternStyle();//[T-16745][2013-08-28] 20hoon

		pFrame = line->getFrame();
		if (theBWordDoc->isFromWordType() &&
		    !(cTextShadingPatternStyle == BR_SHADING_PATTERN_STYLE_ERASE && dwTextShadingFillColor == NONE_COLOR_BITS)) {
			dwBackColor = AutoShadingPatternBgColor(dwTextShadingFillColor,
			                                        dwTextShadingPatternColor,
			                                        cTextShadingPatternStyle);
			bSetBackColor = BrTRUE;
		}
		//[2013-10-07][T-17832][20hoon]
		//else if ( pParaAtt && pParaAtt->getBorder().m_FillColor.getColor() !=-1 ) //old
		//{
		//	dwBackColor = pParaAtt->getBorder().m_FillColor.getColor();
		else if (pParaAtt->isNeedToDrawShading()) {
			dwBackColor = AutoShadingPatternBgColor(pParaAtt->getShadingFillColor().getColor(),
			                                        pParaAtt->getShadingPatternColor().getColor(),
			                                        pParaAtt->getShadingPatternStyle());
			bSetBackColor = BrTRUE;
		}
		else if (pFrame && pFrame->getBorder() && pFrame->getBorder()->getFillStyle() == BMV_FILLTYPE_SOLID) {
			dwBackColor = pFrame->getBorder()->getBrushColor();
			bSetBackColor = BrTRUE;
#ifdef SUPPORT_NIGHT_VIEW_MODE
			//if (p_bCheckNightMode)
			//	*p_bCheckNightMode = BrFALSE;
#endif  // SUPPORT_NIGHT_VIEW_MODE
		}
		else if (theBWordDoc->isFromWordType() && pFrame && pFrame->isCell()) {  //UOO-4  //셀 배경색도  Autocolor에 영향을 미침, 20hoon
			CThemeAtt* pCurThemeAtt = BrNULL;
			if (theBWordDoc->isThemeUsingDoc())
				pCurThemeAtt = theBWordDoc->m_pTheme->getUserTheme(pFrame->getPage()->getRefThemeID());
			BrGrapAtt* pDrawObj = pFrame->getDrawObj();
			BrBOOL bCheckPageBackground = BrTRUE;
			if (pDrawObj) {
				const BrINT nOrgBrushStyle = pDrawObj->getFillStyle();
				pDrawObj->getBrush()->setStyle(BMV_FILLTYPE_PATTERN);
				BrFrameFill pstFrameFill;
				pstFrameFill.nFillSelector = BR_FILL_PATTERN;
				pstFrameFill.isBorderShading = BrTRUE;
				CBrGrapAttGetter grapAttGetter;
				grapAttGetter.GetGrapAttFill(pDrawObj, &pstFrameFill, pCurThemeAtt);

				BrColor fillColor
					= (pstFrameFill.stPatternFill.nPatternBackColor).nThemePaletteIndex > 0 ?
					pCurThemeAtt->getPaletteColor((pstFrameFill.stPatternFill.nPatternBackColor).nThemePaletteIndex)
					:(pstFrameFill.stPatternFill.nPatternBackColor).nColor;

				BrColor pattenColor
					= (pstFrameFill.stPatternFill.nPatternForeColor).nThemePaletteIndex > 0 ?
					pCurThemeAtt->getPaletteColor((pstFrameFill.stPatternFill.nPatternForeColor).nThemePaletteIndex)
					:(pstFrameFill.stPatternFill.nPatternForeColor).nColor;

				BrINT nPattenStyle = pstFrameFill.stPatternFill.nShadingPatternType;
				if (!(nPattenStyle == BR_SHADING_PATTERN_STYLE_ERASE && fillColor.getColor() == NONE_COLOR_BITS)) {
					dwBackColor = AutoShadingPatternBgColor(fillColor.getColor(),
					                                        pattenColor.getColor(),
					                                        nPattenStyle);
					bSetBackColor = BrTRUE;
					bCheckPageBackground = BrFALSE;
				}

				pDrawObj->setFillStyle(nOrgBrushStyle);
			}

			if (bCheckPageBackground)
				CheckPageBg(bSetBackColor, dwBackColor, pFrame->getPage());
		}
		else if (pFrame && (pFrame->isBasic() || pFrame->isHeaderFooter())) {
			CheckPageBg(bSetBackColor, dwBackColor, pFrame->getPage());
		}
	}

	if (!bSetBackColor) {
		bSetBackColor = BrTRUE;

		if (pFrame && (pFrame->isBasic() || pFrame->isCell()) && theBWordDoc->getPaperColor() != TRANSPARENT_COLOR)
			dwBackColor = theBWordDoc->getPaperColor();
		else
			dwBackColor = RGB_WHITE;
	}

	BrCOLORREF dwTextColor = text_att->getTextColor().getColor();
	if (bSetBackColor && theBWordDoc->getBWPEngineMode() != EDITOR_PPT) {
		BrINT32 red = 0x000000FF & dwBackColor;
		BrINT32 green = 0x000000FF & (dwBackColor >> 8);
		BrINT32 blue = 0x000000FF & (dwBackColor >> 16);

		BrUINT nYFore = (5036060 * red + 9886846 * green + 1920103 * blue) >> 24;
		nYFore = nYFore & 0x000000ff;

		if (nYFore > 60)
			dwTextColor = RGB_BLACK;
		else
			dwTextColor = RGB_WHITE;
	}
	return dwTextColor;
}


BrCOLORREF CTextDraw::AutoShadingPatternBgColor(BrCOLORREF fill_color, BrCOLORREF pattern_color,
                                                BrINT pattern_style)
{
	if (fill_color == NONE_COLOR_BITS)
		fill_color = RGB_WHITE;

	BrINT nYFore = (5036060*GetRValue(pattern_color) +
	                9886846*GetGValue(pattern_color) +
	                1920103*GetBValue(pattern_color)) >> 24;
	BrINT nYBack = (5036060*GetRValue(fill_color) +
	                9886846*GetGValue(fill_color) +
	                1920103*GetBValue(fill_color)) >> 24;

	nYFore = nYFore & 0x000000FF;
	nYBack = nYBack & 0x000000FF;

	BrCOLORREF dwBackColor = RGB_WHITE;
	BrDOUBLE nPct = ShadingPatternStylePercent(pattern_style);
	if (nPct != -1) {
		BrINT nYMix = (BrINT)(nYBack + ((BrINT)((nYFore - nYBack) * nPct)));
		dwBackColor = nYMix >= 60 ? RGB_WHITE : RGB_BLACK;
	}
	return dwBackColor;
}


BrDOUBLE CTextDraw::ShadingPatternStylePercent(BrINT shading_pattern_style)
{
	switch (shading_pattern_style) {
		case BR_SHADING_PATTERN_STYLE_ERASE:                return 0.00;
		case BR_SHADING_PATTERN_STYLE_2_5_PER:              return 0.025;
		case BR_SHADING_PATTERN_STYLE_5_PER:                return 0.05;
		case BR_SHADING_PATTERN_STYLE_7_5_PER:              return 0.075;
		case BR_SHADING_PATTERN_STYLE_10_PER:               return 0.10;
		case BR_SHADING_PATTERN_STYLE_12_5_PER:             return 0.125;
		case BR_SHADING_PATTERN_STYLE_15_PER:               return 0.15;
		case BR_SHADING_PATTERN_STYLE_20_PER:               return 0.20;
		case BR_SHADING_PATTERN_STYLE_25_PER:               return 0.25;
		case BR_SHADING_PATTERN_STYLE_30_PER:               return 0.30;
		case BR_SHADING_PATTERN_STYLE_35_PER:               return 0.35;
		case BR_SHADING_PATTERN_STYLE_37_5_PER:             return 0.375;
		case BR_SHADING_PATTERN_STYLE_40_PER:               return 0.40;
		case BR_SHADING_PATTERN_STYLE_45_PER:               return 0.45;
		case BR_SHADING_PATTERN_STYLE_50_PER:               return 0.50;
		case BR_SHADING_PATTERN_STYLE_55_PER:               return 0.55;
		case BR_SHADING_PATTERN_STYLE_60_PER:               return 0.60;
		case BR_SHADING_PATTERN_STYLE_62_5_PER:             return 0.625;
		case BR_SHADING_PATTERN_STYLE_65_PER:               return 0.65;
		case BR_SHADING_PATTERN_STYLE_70_PER:               return 0.70;
		case BR_SHADING_PATTERN_STYLE_75_PER:               return 0.75;
		case BR_SHADING_PATTERN_STYLE_80_PER:               return 0.80;
		case BR_SHADING_PATTERN_STYLE_85_PER:               return 0.85;
		case BR_SHADING_PATTERN_STYLE_87_5_PER:             return 0.875;
		case BR_SHADING_PATTERN_STYLE_90_PER:               return 0.90;
		case BR_SHADING_PATTERN_STYLE_95_PER:               return 0.95;
		case BR_SHADING_PATTERN_STYLE_100_PER:              return 1.0;
		case BR_SHADING_PATTERN_STYLE_DK_HORIZONTAL:        FALLTHROUGH;
		case BR_SHADING_PATTERN_STYLE_DK_VERTICAL:          FALLTHROUGH;
		case BR_SHADING_PATTERN_STYLE_DK_DOWN_DIAGONAL:     FALLTHROUGH;
		case BR_SHADING_PATTERN_STYLE_DK_UP_DIAGONAL:       FALLTHROUGH;
		case BR_SHADING_PATTERN_STYLE_DK_GRID:              FALLTHROUGH;
		case BR_SHADING_PATTERN_STYLE_DK_TRELLIS:           FALLTHROUGH;
		case BR_SHADING_PATTERN_STYLE_LIGHT_HORIZONTAL:     FALLTHROUGH;
		case BR_SHADING_PATTERN_STYLE_LIGHT_VERTICAL:       FALLTHROUGH;
		case BR_SHADING_PATTERN_STYLE_LIGHT_DOWN_DIAGONAL:  FALLTHROUGH;
		case BR_SHADING_PATTERN_STYLE_LIGHT_UP_DIAGONAL:    FALLTHROUGH;
		case BR_SHADING_PATTERN_STYLE_LIGHT_GRID:           FALLTHROUGH;
		case BR_SHADING_PATTERN_STYLE_LIGHT_TRELLIS:        return -1;
	}
	return 1;
}


void CTextDraw::CheckPageBg(BrBOOL& is_set_bg, BrCOLORREF& color, CPage* page)
{
	// 2014-07-30 //20hoon //본문일때, 페이지 배경색을 참고하여, 자동색 결정
	CCmdEngine* cmd_engine = theBWordDoc->getCmdEngine();
	BrFrameFill fill = {};
	BrFramePictureCorrection pic_correction = {};
	cmd_engine->getPageColor(page, &fill, &pic_correction);
	if (fill.nFillSelector != BR_FILL_SOLID)
		return;

	is_set_bg = BrTRUE;
	BrColorInfo& fill_color_info = fill.nSolidColor;
	BrINT fill_theme_id = fill_color_info.nThemePaletteIndex;
	if (0 == fill_theme_id) {
		color = fill_color_info.nColor;
		return;
	}

	BrINT theme_id = theBWordDoc->getThemeID();
	CThemeAtt* theme_att = theBWordDoc->m_pTheme->getUserTheme(theme_id);
	if (BrNULL == theme_att) {
		is_set_bg = BrFALSE;
		return;
	}

	BrColor pattern = theme_att->getPaletteColor(fill_theme_id);
	color = pattern.getColor();
}


void CTextDraw::ProcessDrawTextBorderForGaro(Painter* painter, BrDC* dc, CDrawUnit& du,
                                             CFrame* pFrame, const PoTextAtt* pTextAtt,
                                             CLine* pLine, BrINT nStartCharCol, BrINT nEndCharCol,
                                             BrINT sx, BrINT sy, BrINT arg_nAfterBorderWidth,
                                             BrBOOL bIsBandEnd, BrINT nMaxDescent,
                                             BrINT nUpLineSp, BrBOOL bAllSpace)
{
	if (bAllSpace && theBWordDoc->isFromDoc())  // [XPD-16585]워드에서 Space만 있을땐 Border 안 그림.
		return;
	if (nStartCharCol < 0 || pLine->getPosArray().size() <= nEndCharCol + 1)
		return;

	BrLONG* pStartPos = pLine->getPosArray().GetAt(nStartCharCol);
	BrLONG* pLastPos = pLine->getPosArray().GetAt(nEndCharCol + 1);

	BrINT nStartPos = du.doc2LogicalDX((BrINT)*pStartPos, BrFalse, painter->getZoomScale());
	BrINT nLastPos = du.doc2LogicalDX((BrINT)*pLastPos, BrFalse, painter->getZoomScale());

	CBorderLineInfo* pTextBorderLineInfo = pTextAtt->getTextBorderLineInfo();
	BrINT nLeftLineWidth = 0;
	BrINT nRightLineWidth = 0;
	BrINT nTopLineWidth = 0;
	BrINT nBottomLineWidth = 0;
	LogicalBorderWidth(nLeftLineWidth, nRightLineWidth, nTopLineWidth, nBottomLineWidth,
	                   pTextBorderLineInfo, du, painter->getZoomScale());

	//ZPD-860 //2014-08-27//20hoon //단락의 start Line 과 middle Line의 마지막 글자와 텍스트 테두리가 겹치는 현상 수정
	CCharSet* pCharSet = pLine->getLastLink();
	if (nEndCharCol + 1 == pLine->getCharNum() && pCharSet != BrNULL && pCharSet->isTextLink()) {
		nLastPos += nRightLineWidth * 2;
	}

	BrINT nAfterBorderWidth = du.doc2LogicalDX(arg_nAfterBorderWidth, BrFalse, painter->getZoomScale());

	if (bIsBandEnd) {
		CCharSet* pCharset = pLine->getCharSet(nEndCharCol);
		BrINT  nLastPrevPos = (BrINT)*pLine->getPosArray().GetAt(nEndCharCol);
		BrINT  nTextWidth = CTextProc::getTextLinkWidth(theBWordDoc, pTextAtt, pCharset->getCode(), pCharset, pLine->getCharSetArray(), nEndCharCol, BrFALSE);
		nLastPos = du.doc2LogicalDX(nLastPrevPos + nTextWidth, BrFalse, painter->getZoomScale());

		if (pTextBorderLineInfo->isShadowBorderLine())
			nLastPos += nRightLineWidth * 4;
		else
			nLastPos += nRightLineWidth * 2;

		nAfterBorderWidth = 0;
	}

	BRect rcFrameRect = pFrame->getFrameRect();
	du.doc2Logical(rcFrameRect, BrTRUE);

	BrRect rcTextBorderRect;
	if ((theBWordDoc->isFromHwp() || pFrame->getDropCapFrame() > 0) && (sx + nStartPos - nLeftLineWidth <= rcFrameRect.nLeft))
		rcTextBorderRect.left = rcFrameRect.nLeft + nLeftLineWidth;
	else
		rcTextBorderRect.left = sx + nStartPos;

	BRect rcFill;
	BrINT nDownLineSp, nLineSp;
	PoParaAtt paraAtt = *theBWordDoc->getParaAttHandler()->getMergedParaAtt(pLine->getParaID(), pLine);
	// MS-Word 에서 배수인 경우 1줄만 고려
	if (theBWordDoc->isFromDoc() && paraAtt.getLineSpaceUnit() == LINESP_UNIT_MULTIPLE && paraAtt.getLineSpace() > 1) {
		BrDOUBLE dOldSpace = paraAtt.getLineSpace();
		paraAtt.setLineSpace(1);
		nLineSp = paraAtt.getLineSpace(pLine, BrTRUE, BrFALSE);
		paraAtt.setLineSpace(dOldSpace);
	}
	else {
		nLineSp = CTextProc::CalcLineSpace(theBWordDoc, pLine);
	}
	nLineSp = du.doc2LogicalDY(nLineSp, BrFALSE);

	if (nLineSp > 1 && !theBWordDoc->isFromMSWordType())	// HWP, ODT
	{
		// nLineSp = 1;	// #2094	//[ZPD-20705]MS Word가 아닐 경우만
		nUpLineSp = 1;
		nDownLineSp = 1;
	}
	else {
		// drawTextFrame()에서 LineSp를 고려하여 띄운 값을 사용 SRG-2371
		nUpLineSp = du.doc2LogicalDY(nUpLineSp, BrFALSE);
		nDownLineSp = nLineSp - nUpLineSp;
	}

	if (du.doc2LogicalDY(pLine->getAscent() * 1.3, BrFALSE) < du.doc2LogicalDY(pLine->getAscent(), BrFALSE) + nUpLineSp)
		rcFill.nTop = sy - du.doc2LogicalDY(pLine->getAscent() * 1.3, BrFALSE);
	else
		rcFill.nTop = sy - du.doc2LogicalDY(pLine->getAscent(), BrFALSE) - nUpLineSp;

	rcFill.nBottom = sy + du.doc2LogicalDY(pLine->getHeightWithoutAnchor() * 0.3, BrFALSE);// + nUpLineSp;//sy + sy - rcFill.nTop;//sy + nDownLineSp;

	//2014-07-22 T-27729 20hoon
	//글자 속성 - 고급 - 위치기능을 설정하면 하이라이트 영역 및 음영 영역을 늘려준다.
	rcFill.nBottom += du.doc2LogicalDY(pLine->getMaxHgtUnderBasePos(), BrFALSE);

	// line_frame 바깥쪽 그리지 말자 SRG-316
	BrINT nFrameTop = du.doc2LogicalY(pFrame->top());
	if (rcFill.nTop < nFrameTop)
		rcFill.nTop = nFrameTop;

	rcTextBorderRect.top = rcFill.nTop;
	rcTextBorderRect.bottom = rcFill.nBottom > rcFrameRect.nBottom? rcFrameRect.nBottom - nAfterBorderWidth: rcFill.nBottom;	//Cell에서 아래 테두리가 그려지지 않아 보정함.

	//[2015-11-10]테두리 모서리를 CLIP으로 그리도록 수정.
	if (nStartCharCol == nEndCharCol) {
		rcTextBorderRect.right = sx + nLastPos;
	}
	else {
		if (theBWordDoc->isFromHwp() && (nEndCharCol == pLine->getCharSetArray()->size() - 1) && (sx + nLastPos >= rcFrameRect.nRight)) {
			rcTextBorderRect.right = rcFrameRect.nRight - nAfterBorderWidth;
		}
		else
			rcTextBorderRect.right = sx + nLastPos - nAfterBorderWidth;
	}

	if (nRightLineWidth > 1)
		rcTextBorderRect.right -= nRightLineWidth;	//끝 부분 보정.

	pTextBorderLineInfo->drawTextLineBorder(dc, du, rcTextBorderRect, BrFALSE);
}


void CTextDraw::DrawGaroUnderlineBitmap(Painter* painter, BrDC* dc, BrINT sx, BrINT sy,
                                        BrINT dx, BrINT dy, const BrRect& rect, BrINT nTextLine,
                                        BrINT line_w, COLORREF color, PoTextAtt* text_att,
                                        CFrame* pFrame, CLine* line, BrINT nCol, BrINT line_h,
                                        BrINT nMaxDescent, BrBOOL isHyperLink)
{
	BrGrapAtt* grapAtt = UpdateUnderlineStyle(text_att, isHyperLink, color);

	if (grapAtt && !(grapAtt->getPen()->isNull() && !grapAtt->isPictured() && !grapAtt->isGradient())) {
		BrShapeProxy shape(SHAPE_TextPlainText);
		ConfigUnderlineShape(shape, grapAtt);

		BrBYTE nOldMode = dc->setExportMode(eDirectExtMode);

		BrPoint offset, left_top;// = du.getOffset();
		ConfigUnderlinePoints(offset, left_top, rect);

		DrawUnderline(painter, dc, sx, sy, dx, dy, offset, line_w,
		              line_h, color, text_att, line, shape, BrTRUE);

		//shape.getPolygon()->translate(-boundrect.Left()-width, -boundrect.Top()+textAttForStrikeline.getHanFSize()/2-boundrect.getHeight()/2);
		//shape.getPolygon()->translate(rect.left, rect.top);
		shape.getPolygon()->translate(
			CDrawUnit::cvtLogical2DocX(offset.x, painter->m_iResX, painter->getZoomScale()),
			CDrawUnit::cvtLogical2DocY(offset.y, painter->m_iResY, painter->getZoomScale())
		);

		offset = left_top;

		shape.getPolygon()->translate(
			-CDrawUnit::cvtLogical2DocX(offset.x, painter->m_iResX, painter->getZoomScale()),
			-CDrawUnit::cvtLogical2DocY(offset.y, painter->m_iResY, painter->getZoomScale())
		);

		BRect boundrect = shape.getPolygon()->boundingRect();

		BString qStrBuffer(" ");
		BRCHAREFFECTINFO charInfo = {BRect(0,0,0,0), 0,0,0,0,0,0,0,0, nTextLine};
		charInfo.nWidth = twips2DeviceX(boundrect.nRight, painter->getZoomScale(), painter->m_iResX); //dc->m_pFont->getCharBitmapWidth(qStrBuffer.at(0));
		charInfo.rcFrame = line->getFrame()? line->getFrame()->getFrameRect(): BRect(0,0,0,0);
		charInfo.nDescent = nMaxDescent;
		charInfo.nCharLineW = BrMAX(charInfo.nDescent * 0.5, 2);
		charInfo.nHeight = BrABS(rect.top - rect.bottom) + charInfo.nDescent;	//[2014. 4. 11] ejjeong. 맑은 고딕 g, j가 잘리는 문제로 여유있게 잡음
		charInfo.nFontHeight = line_h;
		charInfo.nCHExtraHeight = charInfo.nFontHeight *0.15;

		// [JIRA] XRF-3224 Doc과 ppt의 반사효과가 영역이 다르게 잡히는데 그 원인으로 Doc의 문단 계산 방법이 다른 것으로 추정
		// 따라서 Default LineSpace인 1.0으로 계산하여 (Font마다 다름) ppt와의 차이를 보정해 줌.
		// extraHead에 더해지는 값이므로 아래쪽 Bottom Descent 영역 계산에 Side 없다고 보고, 이 값들은 ChunkFillBitmap의 Size에 반영해야 함.
		if (pFrame && !text_att->isWaPolygon()) {
			BrShape* pShape = pFrame->getBorder();
			if (pShape) {
				const PoParaAtt* paraAtt = theBWordDoc->getParaAttHandler()->getMergedParaAtt(line->getParaID(), line);
				// word 세로쓰기 고도화 관련. 270도 회전시엔 크기를 늘리지 말자
				if (theBWordDoc->isFromDoc() && pFrame->getTextFlow() != TEXTFLOW_SERO_270) {
					BrINT nLineSp = line->getLineSpForMultiple(1.0, paraAtt->isFixLineNum(), !(theBWordDoc->isFromDoc() && paraAtt->getBulletID()));
					nLineSp = twips2DeviceX(nLineSp, painter->getZoomScale(), painter->m_iResX);
					charInfo.nLineSpace = (BrDOUBLE)nLineSp/2;
				}
			}
		}
		charInfo.nHeightWithExtra = charInfo.nHeight + charInfo.nCHExtraHeight + charInfo.nLineSpace;

		auto pBitmaps = MakeTextEffect(painter, dc, text_att, line, nCol, qStrBuffer, 0,0, charInfo, &shape);
		if (pBitmaps)
			pBitmaps->draw(dc, offset, painter);
		else
			DrawNormalUnderline(dc, sx, sy, dx, dy, line_w, color, text_att, line, line_h);

		dc->setExportMode(nOldMode);
		return;
	}

	DrawNormalUnderline(dc, sx, sy, dx, dy, line_w, color, text_att, line, line_h);  // DE #32504
}


BrGrapAtt* CTextDraw::UpdateUnderlineStyle(PoTextAtt* text_att, BrBOOL is_hyperlink, COLORREF text_color)
{
	if (BrNULL == text_att || getDocType() == BORA_DOCTYPE_HWP)
		return BrNULL;

	BrGrapAtt* grap_att = text_att->getGrapAtt();
	if (is_hyperlink ||
	    (text_att->isSettedUnderlineColor() && BrFALSE == text_att->getUnderLineAutoColor())) {
		if (grap_att)
			grap_att->resetBrush();

		text_att->setTextColor(text_color);
		if (is_hyperlink)
			text_att->setUnderlineStyle(UNDERLINE_STYLE_SINGLE);
	}

	return grap_att;
}


void CTextDraw::ConfigUnderlineShape(BrShapeProxy& shape, BrGrapAtt* grap_att)
{
	shape.setOffice2007Shape(BrTRUE);
	shape.copy(*grap_att);

	shape.createFreeFormShapeAttrs();
	shape.createPolygon();

	shape.getPolygon()->resize(0);

	if (grap_att->isFillImage())  // Image 채우기인 경우 ImageInfo를 세팅한다.
		shape.setImageInfo(theBWordDoc->getImageArray());
}


void CTextDraw::ConfigUnderlinePoints(BrPoint& center, BrPoint& left_top, const BrRect& rect)
{
	center.x = (rect.left + rect.right) / 2;
	center.y = (rect.top + rect.bottom) / 2;
	left_top.x = rect.left;
	left_top.y = rect.top;
}


void CTextDraw::DrawUnderline(Painter* painter, BrDC* dc, BrINT sx, BrINT sy,
                              BrINT dx, BrINT dy, const BrPoint& center, BrINT line_width,
                              BrINT line_height, COLORREF color, PoTextAtt* text_att,
                              CLine* line, BrShapeProxy& shape, BrBOOL is_horizontal)
{
	BrBmvPen pen(eSolid, 1, color);
	BrBmvBrush brush;
	brush.createNullBrush();

	BPointArray* point_arr = shape.getPolygon();
	BArray<BrShapeSegment>& segment_arr = shape.getFreeFormShapeAttrs()->aSegments;

	BrBmvPen* old_pen = dc->setPen(&pen);
	BrBmvBrush* old_brush = dc->setBrush(&brush);
	dc->setNeedOutline(point_arr, &segment_arr, center);

	BrINT width = CDrawUnit::cvtLogical2DocY(line_width, painter->m_iResY, painter->getZoomScale());
	BrINT thick = width;
	UNDERLINE_STYLE underline_style = text_att->getHiddenText()?
	                                    UNDERLINE_STYLE_DOTTED:
	                                    static_cast<UNDERLINE_STYLE>(text_att->getUnderlineStyle());
	if (CheckWavyUnderline(thick, width, underline_style, line_width)) {
		if (underline_style == UNDERLINE_STYLE_WAVYHEAVY)
			pen.setWidth(2);
		if (text_att->getUnderlinePos() == BR_UNDERLINE_POS_BOTTOM) {
			if (is_horizontal)
				sx += line_height;
			else
				sy -= line_height;
		}
		BrBOOL is_wavy_double = (underline_style == UNDERLINE_STYLE_WAVYDOUBLE);
		if (is_horizontal)
			DrawHorizontalWavyUnderline(dc, is_wavy_double, sx, sy, dx, thick, width);
		else
			DrawVerticalWavyUnderline(dc, is_wavy_double, sx, sy, dy, thick, width);
	}
	else {
		// DE #32504
		DrawNormalUnderline(dc, sx, sy, dx, dy, line_width, color, text_att, line, line_height);
	}

	dc->setNeedOutline(BrNULL, BrNULL, center);
	dc->setPen(old_pen);
	dc->setBrush(old_brush);
}


BrBOOL CTextDraw::CheckWavyUnderline(BrINT& thick, BrINT& width, UNDERLINE_STYLE style, BrINT line_width)
{
	switch (style) {
		case UNDERLINE_STYLE_WAVY:
		case UNDERLINE_STYLE_WAVYHEAVY: {
			thick = line_width * 2;
			width = line_width * 4;
			return BrTRUE;
		}
		case UNDERLINE_STYLE_WAVYDOUBLE: {
			width = thick = line_width * 2;
			return BrTRUE;
		}
	}

	return BrFALSE;
}


void CTextDraw::DrawHorizontalWavyUnderline(BrDC* dc, BrBOOL is_wavy_double, BrINT sx, BrINT sy,
                                            BrINT dx, BrINT thick, BrINT width)
{
	BrINT y1 = sy + thick;
	BrINT y2 = sy;
	BrINT y3 = 0;
	if (is_wavy_double) {
		y2 = sy + thick/2;
		y3 = sy;
	}

	BrINT x1 = sx;
	BrINT x2 = x1 + width/2;
	BrINT x3 = x1 + width + 1;

	DCBeginPath(dc, x1, y1);
	while (x1 < dx) {
		dc->lineTo(x2 + 1, y2);
		dc->lineTo(x3, y1);

		x1 = x3;
		x2 = x1 + width/2;
		x3 = x1 + width + 1;
	}
	DCEndPath(dc);

	if (is_wavy_double) {
		x1 = sx;
		x2 = x1 + width/2;
		x3 = x1 + width + 1;

		DCBeginPath(dc, x1, y2);
		while (x1 < dx) {
			dc->lineTo(x2 + 1, y3);
			dc->lineTo(x3, y2);

			x1 = x3;
			x2 = x1 + width/2;
			x3 = x1 + width + 1;
		}
		DCEndPath(dc);
	}
}


void CTextDraw::DrawVerticalWavyUnderline(BrDC* dc, BrBOOL is_wavy_double, BrINT sx, BrINT sy,
                                          BrINT dy, BrINT thick, BrINT width)
{
	BrINT x1 = sx + thick;
	BrINT x2 = sx;
	BrINT x3 = 0;
	if (is_wavy_double) {
		x2 = sx + thick/2;
		x3 = sx;
	}

	BrINT y1 = sy;
	BrINT y2 = y1 + width/2;
	BrINT y3 = y1 + width + 1;

	DCBeginPath(dc, x2, y1);
	while (y1 < dy) {
		dc->lineTo(x1, y2 + 1);
		dc->lineTo(x2, y3);

		y1 = y3;
		y2 = y1 + width/2;
		y3 = y1 + width + 1;
	}
	DCEndPath(dc);

	if (is_wavy_double) {
		y1 = sy;
		y2 = y1 + width/2;
		y3 = y1 + width + 1;

		DCBeginPath(dc, x3, y1);
		while (y1 < dy) {
			dc->lineTo(x2, y2 + 1);
			dc->lineTo(x3, y3);

			y1 = y3;
			y2 = y1 + width/2;
			y3 = y1 + width + 1;
		}
		DCEndPath(dc);
	}
}


void CTextDraw::DCBeginPath(BrDC* dc, BrINT x, BrINT y)
{
	dc->beginPath();
	dc->moveTo(x, y);
}


void CTextDraw::DCEndPath(BrDC* dc)
{
	dc->endPath();
	dc->fillPath();
	dc->strokePath();
}


unique_ptr<BrShapeEffectBitmaps> CTextDraw::MakeTextEffect(
        Painter* painter, BrDC* dc, const PoTextAtt* pTextAtt, CLine* pLine,
        BrINT nCol, BString& qStrBuffer, BrINT sx, BrINT sy,
        BRCHAREFFECTINFO charInfo, BrShapeProxy* pShape)
{
	if (!painter || !dc || !pTextAtt || !pLine)
		return unique_ptr<BrShapeEffectBitmaps>();

	CFrame* pFrame = pLine->getFrame();

	BrWORD ch = 0;
	const BChar* pCh = qStrBuffer.unicode();
	if (pCh)
		ch = pCh->unicode();
	BrINT nFontSize = IS_MODERN_KOREAN(ch) ? pTextAtt->getHanFSize() : pTextAtt->getEngFSize();
	BoraDoc* document = theBWordDoc;
	if (pLine) {
		// drawing하는 font size scaling
		CFrame* pFrame = pLine->getFrame();
		nFontSize = pFrame ? pFrame->getAutoScaledFontSize(nFontSize) : nFontSize;
	}

	if ((pTextAtt->isWaPolygon() && pShape) || charInfo.nTextLine > 0) {  //아웃라인으로 Text 그리기
		BrBOOL bInterferingOutline = BrFALSE;
		// LQQ-8056 배경색과 글자 외곽선이 동일한 색상인데 충분히 크기가 작아서 외곽선에 의해 채우기 색상이 가려져서 글자가 안보이는 경우를 방지하기 위해 scale 하던 코드를 충분히 크기가 작은 경우 외곽선을 그리지 않도록 수정함.
		// 배경색과 동일하기때문에 draw 하지 않아도 문제는 없을 것으로 보이며 채우기 색상을 가리지않아 글자가 더 잘보일 것으로 기대됨
		BrINT nOrgLineStyle = pShape->getLineStyle();
		CFrame* pFrame = pLine->getFrame();
		UpdateCharEffectColor(painter, pTextAtt, pLine, charInfo, bInterferingOutline, pShape);

		BrINT nOrgZoomFactor = painter->getZoomScale();
		BrDOUBLE nScaleRatio = 1.;
		BrINT nOrgPenWidth = pShape->getPen()->getLineWidth();
		const BrINT OUTLINE_MIN_H = 60;

		if (bInterferingOutline)
			//nScaleRatio = 2.;
			pShape->setLineStyle(BMV_LINESTYLE_NOLINE);

		/*PC 버전에서는 Font가 작은 경우 글자가 깨져서 보인다.
		최소 Dev 60 크기를 넘지 못한 글자는 Dev 60 크기로 Zoom In 하여 draw하고 Bitmap을 원래의 크기로 Scale Down한다.
		단, Pen LineWidth도 동일한 비율로 커진다.
			- 또한 Bitmap을 키우고, Bitmap Scaler를 사용하기 때문에 성능 이슈 발생 가능함.
			- 테스트 결과 Height가 30보다 작은 경우(ms에서 100% 14 pt보다 작은 경우), 화면 한 가득 Text 채우고 모든 효과를 적용했을 때 2배의 속도 저하 발생. */
#if defined(_DESKTOP_EDITOR_WIN8_TARGET_HPP_) || defined(_MAC_POLARISOFFICE_COLLABO_HPP_) //PC에서 발생한 품질 문제로 Scale을 키워서 그린 후 크기에 맞추는 방식
		if (charInfo.nHeight < OUTLINE_MIN_H)
			nScaleRatio = (BrFLOAT)OUTLINE_MIN_H / (BrFLOAT)charInfo.nHeight;
#endif
#ifndef USE_WORDART_3D
		pShape->enable3D(BrFALSE);
#else
		if (pShape->has3DObj()) {
			const BrINT WA_3D_SUPPORT_H = 27;
			if (charInfo.nHeight <= WA_3D_SUPPORT_H)
				pShape->enable3D(BrFALSE);
			else if (charInfo.nHeight > WA_3D_SUPPORT_H && charInfo.nHeight < OUTLINE_MIN_H) //bOutlineIgnored에서 scale이 조정되지 않았을 경우
				nScaleRatio = (BrFLOAT)OUTLINE_MIN_H / (BrFLOAT)charInfo.nHeight;
		}
#endif
		if (nScaleRatio != 1.) {
			charInfo.nWidth *= nScaleRatio;  charInfo.nCHExtraHeight *= nScaleRatio;
			charInfo.nHeightWithExtra *= nScaleRatio;  charInfo.nDescent *= nScaleRatio;
			charInfo.nHeight *= nScaleRatio;
			painter->setZoomScale(nOrgZoomFactor * nScaleRatio);
			pShape->setLineStyle(nOrgLineStyle);
		}

		BrBOOL bPenFill = pTextAtt->isWaPenFill();
		BrBOOL bBrushFill = pTextAtt->isWaChunkFill();
		BRect* pLineRect = (bPenFill || bBrushFill) ? MakeCharFillRect(painter, dc, pTextAtt, pLine, pShape, charInfo, sx, sy, nCol) : BrNULL;

		//Text 3D Rotation은 적용하지 않음. 여기서는 글자 단위로 Rotation이 적용되는데
		//여러 글자인 경우 MS의 3D Rotation과 맞지 않음
		CMsod_3DStyle* pOrg3DSty = pShape->getOwn3DStyleProp();
		pShape->set3DStyleProp(BrNULL);

		BrINT nOrgPenStyle = pShape->getPen()->getLineStyle();
		BrBOOL bChangedPenStyle = BrFALSE;
		BrShapeCharBitmapDeco deco(pShape, pShape, &qStrBuffer);
		BrINT nTextFlow = pFrame->getTextFlow();
		BrINT nOrgTextFlow = nTextFlow;
		if (nTextFlow == TEXTFLOW_GARO_ROTATE && !IS_MODERN_KOREAN(ch) && !IS_HANJA(ch))
			nTextFlow = TEXTFLOW_GARO;

		if (charInfo.nTextLine == 1 || charInfo.nTextLine == 2)
			nTextFlow = TEXTFLOW_GARO;

		deco.setCharInfo(painter, charInfo.nDescent, nFontSize, nTextFlow,
		                 (nTextFlow == TEXTFLOW_SERO_270)? 0: charInfo.nCHExtraHeight,
		                 pLineRect, bPenFill, bBrushFill);
		deco.makeEffectsImage(painter, dc, &qStrBuffer, sx, sy, charInfo.nWidth,
		                      (nTextFlow == TEXTFLOW_SERO_270)? charInfo.nHeight:
		                                                        charInfo.nHeightWithExtra);
		if (pLineRect)
			BR_SAFE_DELETE(pLineRect);

		if (nScaleRatio != 1.) {
			deco.scaleBitmaps(100 / nScaleRatio);
			painter->setZoomScale(nOrgZoomFactor);
		}

		pShape->setLineStyle(nOrgLineStyle);

		pShape->set3DStyleProp(pOrg3DSty);
		//if(nOrgTextFlow == TEXTFLOW_SERO_90 || nOrgTextFlow == TEXTFLOW_SERO_270)
		//if(nOrgTextFlow == TEXTFLOW_SERO_270)
		//{
		//	BrShapeCharBitmapDeco* pCharDeco = &deco;
		//	BrShapeEffectBitmaps* pEBitmaps = applyEffectTextFlow(painter, dc, nOrgTextFlow, qStrBuffer, pCharDeco, charInfo);
		//	if(pEBitmaps && pEBitmaps->getCount() > 0)
		//		return pEBitmaps;
		//}
		return unique_ptr<BrShapeEffectBitmaps>(deco.takeBitmaps());
	}
	else if (pTextAtt->isWaEffected()) {  //비트맵으로 채우기
		//Auto Text Color Outline이 아닌 경우에도 적용되도록 수정.
		BrBOOL bInterferingOutline = BrFALSE;
		if (pShape)
			UpdateCharEffectColor(painter, pTextAtt, pLine, charInfo, bInterferingOutline, pShape);
		BrGrapAtt* pGrapAtt = pTextAtt->getGrapAtt();
		BrBrushObj* pOldBrush = pGrapAtt->getBrush();
		if (pShape && pShape->getBrush() != BrNULL)
			pGrapAtt->setBrush(pShape->getBrush());

		BrShapeCharBitmapDeco deco(pGrapAtt, BrNULL, &qStrBuffer);
		deco.setFillBitmap(pShape? pShape->getBaseFillBitmap() : BrNULL);

		CFrame* pFrame = pLine->getFrame();
		BrINT nTextFlow = pFrame->getTextFlow();
		if (nTextFlow == TEXTFLOW_GARO_ROTATE && !IS_MODERN_KOREAN(ch) && !IS_HANJA(ch))
			nTextFlow = TEXTFLOW_GARO;
		if (nTextFlow == TEXTFLOW_GARO && (ch == 'W' || ch == 'f'))
			BrShapeMagicNumber::getWidthExceptionChar(ch, charInfo.nWidth);
		BRect* pLineRect = BrNULL;

		//Outline이 없는 WordArt는 PenFill이 필요 없고 BrushFill은 baseFill로 채우므로 LineRect 사용할 필요 없음.
		deco.setCharInfo(painter, charInfo.nDescent, nFontSize, nTextFlow, charInfo.nCHExtraHeight + charInfo.nLineSpace, pLineRect, BrFALSE, BrFALSE);
		deco.makeEffectsImage(painter, dc, &qStrBuffer, sx, sy, charInfo.nWidth, charInfo.nHeightWithExtra);
		if (pOldBrush != BrNULL)
			pGrapAtt->setBrush(pOldBrush);
		return unique_ptr<BrShapeEffectBitmaps>(deco.takeBitmaps());
	}

	return unique_ptr<BrShapeEffectBitmaps>();
}


void CTextDraw::UpdateCharEffectColor(Painter* painter, const PoTextAtt* pTextAtt,
                                      CLine* pLine, BRCHAREFFECTINFO charInfo,
                                      BrBOOL& bInterferingOutline, BrShapeProxy* pShape)
{
	//auto color 처리: 2014. 6. 19 ejjeong. Modified
#ifndef SUPPORT_IMAGE_BRUSH
	BrColor colorOrg(pShape->getBrushColorObj());
#else
	BrColor colorOrg;
	if (pShape->getBrushColorObj() != BrNULL)
		colorOrg = *pShape->getBrushColorObj();
#endif  // SUPPORT_IMAGE_BRUSH

#ifdef REMOVE_HYPER_LINK_ATTRIBUTE
	BrBOOL bRemoveHyperLink = BrFALSE;
	if (IsRemoveHyperlinkAttr(painter, pTextAtt))
		bRemoveHyperLink = BrTRUE;
#endif  // REMOVE_HYPER_LINK_ATTRIBUTE

	BrINT nFillStyleOrg = pShape->getFillStyle();
	BoraDoc* document = theBWordDoc;
	const BrSHORT nDocType = document->getDocType();
	const BrBOOL isDML = nDocType == BORA_DOCTYPE_PPTX || (nDocType == BORA_DOCTYPE_DOCX && document->getCompatibilityModeVersion() >= eCOMPATIBILITY_V14);
	if (!isDML) {
		BrGrapAtt* pGrapAtt = pTextAtt->getGrapAtt();
		BrColor color = pTextAtt->getTextColor();
		BrBOOL bShadow = pGrapAtt->isDMLShadow() || pGrapAtt->isVMLShadow();
#ifdef REMOVE_HYPER_LINK_ATTRIBUTE
		BrCOLORREF textColor = bRemoveHyperLink ? BLACK_COLOR : color.getColor();
#else
		BrCOLORREF textColor = color.getColor();
#endif  // REMOVE_HYPER_LINK_ATTRIBUTE

		//VML font 그림자 설정 시 채우기는 텍스트 색상
		if (bShadow && pShape->getBrush()) {
			pShape->setFillStyle(BMV_FILLTYPE_SOLID);
			pShape->setBrushColor(textColor);
		}

		//VML font 윤곽선 설정 시 선은 텍스트 색상
		if (pTextAtt->getOutline()) {
			if (pShape->getBrush()) {
				//채우기는 ODF는 흰색, HWP와 MS VML은 채우기 없음
				BrBOOL bODF = nDocType == BORA_DOCTYPE_ODT || nDocType == BORA_DOCTYPE_ODP;
				if (bODF || (bShadow && getDocType() == BORA_DOCTYPE_HWP)) {
					pShape->setFillStyle(BMV_FILLTYPE_SOLID);
					pShape->setBrushColor(WHITE_COLOR);
				}
				else {
					pShape->setFillStyle(BMV_FILLTYPE_NOFILL);
				}
			}

			pShape->setLineColor(textColor);

			BrThemePenObj* shapePen = pShape->getPen();
			if (document->isFromHwp() && shapePen && shapePen->getLineWidth() > PO_TEXTATT_BASE::outlineWidthNormal) {
				const BrINT32 width = Device2twips(2, painter->getZoomScale(), painter->m_iResX);
				shapePen->setLineWidth(width);
			}
		}
	}
	else {
		BrCOLORREF color = NONE_COLOR_BITS;
#ifdef REMOVE_HYPER_LINK_ATTRIBUTE
		if (bRemoveHyperLink)
			color = BLACK_COLOR;
		else
#endif  // REMOVE_HYPER_LINK_ATTRIBUTE
			if (pTextAtt->getAutoColor()) {
				BrColor* pFontColor = pLine ? ShapeQuickStyleTextAutoColor(pLine->getFrame()) : BrNULL;
				color = AutoTextColor(pLine, pTextAtt, pFontColor);

				//[EMO-2301][minseob] 캐럿에 있는 글자 색상으로 변경
				CCaret* pCaret = document->getCaret();
				if (pCaret != BrNULL && pCaret->isCaretNormal() && !pCaret->getTextAttr()->getAutoColor())
					color = AutoTextColor(pLine, pTextAtt);

			}
			else {
				BrGrapAtt* pGrapAtt = pTextAtt->getGrapAtt();
				if (pGrapAtt != BrNULL) {
					BrThemeBrushObj* pBrushObj = pGrapAtt->getBrush();
					if (pBrushObj != BrNULL)
						color = pBrushObj->getForeColor();
				}
				else
					color = pTextAtt->getTextColor().getColor();
			}

		BrBOOL bVMLOutline = pTextAtt->getOutline() && !pShape->isUnitMsDml();
		BrBOOL bNullBrush = pShape->isNullBrush();
		if (charInfo.nTextLine == 1 /* Underline */ && pTextAtt->isSettedUnderlineColor() && pTextAtt->getUnderlineColor() != NONE_COLOR_BITS) {
			pShape->setFillStyle(BMV_FILLTYPE_SOLID);
			pShape->setBrushColor(pTextAtt->getUnderlineColor());
		}
		else if (bVMLOutline) {//[MQP-10710] VML 방식의 font 윤곽선 설정 시 채우기는 없음, 선은 텍스트 색상
			pShape->setFillStyle(BMV_FILLTYPE_NOFILL);
			pShape->setLineColor(color);
		}
		else if (bNullBrush) {
#ifndef SUPPORT_IMAGE_BRUSH
			pShape->getBrushColorObj().reset();
#else
			if (pShape->getBrushColorObj() != BrNULL)
				pShape->getBrushColorObj()->reset();
#endif  // SUPPORT_IMAGE_BRUSH
			if (nFillStyleOrg == BMV_FILLTYPE_NOFILL && getDocType() == BORA_DOCTYPE_DOCX) {
				pShape->setFillStyle(nFillStyleOrg);
			}
			else {
				pShape->setFillStyle(BMV_FILLTYPE_SOLID);
				pShape->setBrushColor(color);
				pShape->getBrush()->setTransparent(pTextAtt->getGrapAtt()->getBrushTransparency());
			}
		}
	}

	if (pLine) {
		CFrame* pFrame = pLine->getFrame();
		if (pFrame) {
			BrCOLORREF bgColor = NONE_COLOR_BITS;
			BrCOLORREF bgHighlight = pTextAtt->getBackColor().getColor() & 0x00FFFFFF;
			BrCOLORREF bgShading = pTextAtt->getShadingFillColor().getColor() & 0x00FFFFFF;
			BrCOLORREF bgPaperColor = document->getPaperColor() & 0x00FFFFFF;

			if ((bgHighlight != NONE_COLOR_BITS && bgHighlight != TRANSPARENT_COLOR) && bgHighlight != bgPaperColor)
				bgColor = bgHighlight;
			else if ((bgShading != NONE_COLOR_BITS || bgHighlight != TRANSPARENT_COLOR) && bgHighlight != bgPaperColor)
				bgColor = bgShading;
			else if (pFrame->getBorder()
							 && !pFrame->getBorder()->isNullBrush() && !pShape->isNullBrush())
				bgColor = pFrame->getBorder()->getBrushColor();
			else
				bgColor = bgPaperColor;

			BrINT nFontLineW = BrShapeMagicNumber::getFontLineWidth(charInfo.nDescent);
			//BrINT nShapeLineW = twips2DeviceX(pShape->getLineWidth(), painter->getZoomScale(), painter->m_iResX) ;
			if ((nFontLineW <= 1 /*|| nFontLineW < nShapeLineW*/) &&
			    bgColor == pShape->getLineColor() && !pShape->getBrush()->isNoFill()) {
				bInterferingOutline = BrTRUE;
			}
		}
	}
}


BrColor* CTextDraw::ShapeQuickStyleTextAutoColor(CFrame* pFrame)
{
#ifdef SUPPORT_GRAPHIC_STYLE
	if (pFrame && theBWordDoc) {
		BrINT nShapeStyleID = pFrame->getShapeStyleID();
		CBrGraphicStyle* pGraphicStyle = theBWordDoc->getGraphicStyle();
		if (pGraphicStyle) {
			CBrShapeStyle* pShapeStyle = pGraphicStyle->getGraphicStyle(BrTRUE, nShapeStyleID);
			if (pShapeStyle) {
				CBrStyle* pFontStyle = pShapeStyle->getFontRef();
				return pFontStyle->getBrColor();
			}
		}
	}
#endif
	return BrNULL;
};


BRect* CTextDraw::MakeCharFillRect(Painter* painter, BrDC* dc, const PoTextAtt* pTextAtt,
                                   CLine* pLine, BrShapeProxy* pShape, BRCHAREFFECTINFO charInfo,
                                   BrINT sx, BrINT sy, BrINT nCol)
{
	BRect* pLineRect = BrNULL;
	BRect rcLine(0, 0, 0, 0);
	BRect lineFill(0, 0, 0, 0);

	BrINT nLastCharId = pLine->getCharSetArray()->GetSize() - 1;
	BrINT nHeightTwip = Device2twips(charInfo.nFontHeight, painter->getZoomScale(), painter->m_iResY);
	BrINT nPosYTwip = Device2twips(sy, painter->getZoomScale(), painter->m_iResY);

	CCharSet chLast = *pLine->getCharSetArray()->GetAt(nLastCharId);
	BrINT nLastCharWidth = dc->m_pFont->getCharWidth(chLast.getCode());
	if (dc->m_pFont->getFontAtts_Italic())
		nLastCharWidth += 0.25 * charInfo.nFontHeight;
	BrINT nWidthTwip = Device2twips(nLastCharWidth, painter->getZoomScale(), painter->m_iResX);
	BrINT32 nLastCharPos = *pLine->getPosArray().GetAt(nLastCharId);
	BrINT32 nLineEndPos = nLastCharPos + nWidthTwip;

	rcLine.nLeft = *pLine->getPosArray().GetAt(0);
	rcLine.nTop = nPosYTwip;
	rcLine.nRight = nLineEndPos;
	rcLine.nBottom = rcLine.nTop + nHeightTwip;

	BrINT nFillPos = *pLine->getPosArray().GetAt(nCol) - *pLine->getPosArray().GetAt(0);
	BrINT nFillPosDev = twips2DeviceX(nFillPos, painter->getZoomScale(), painter->m_iResX);

	BrINT32 nFillWidth = Device2twips(charInfo.nWidth, painter->getZoomScale(), painter->m_iResX);
	rcLine.Move(-rcLine.TopLeft());

	BrINT nBodyHieght = Device2twips(dc->m_pFont->getCharAscent() + dc->m_pFont->getCharDescent(), painter->getZoomScale(), painter->m_iResY);
	BrINT nExHeight = Device2twips(charInfo.nCHExtraHeight, painter->getZoomScale(), painter->m_iResY);
	lineFill.nLeft = rcLine.nLeft - nFillPos;
	lineFill.nTop = -1 * nExHeight;
	lineFill.nRight = rcLine.nRight - (nFillPos + nFillWidth);
	lineFill.nRight = lineFill.nRight > 0 ? lineFill.nRight : 0;
	lineFill.nBottom = -1 * (rcLine.GetHeight() - nBodyHieght + nExHeight);

	pLineRect = BrNEW BRect(lineFill);

	if (pTextAtt->getGrapAtt()->isFillImage()) {
		//Image 채우기인 경우 ImageInfo를 세팅한다.
		BrImageArray* pImageArray = theBWordDoc->getImageArray();
		pShape->setImageInfo(pImageArray);
	}
	return pLineRect;
}


BrShapeEffectBitmaps* CTextDraw::ApplyEffectTextFlow(
        Painter* painter, BrDC* dc, BrINT nTextFlow, BString& qStrBuffer,
        BrShapeCharBitmapDeco* pCharDeco, BRCHAREFFECTINFO charInfo)
{
	BrShapeEffectBitmaps* pEBitmaps = pCharDeco->takeBitmaps();
	if (!pEBitmaps)
		return BrNULL;

	pEBitmaps->compressBitmap();

	if (nTextFlow == TEXTFLOW_SERO_90) {
		if ((pEBitmaps->getBitmap(0) != BrNULL) && ((pEBitmaps->getBitmap(0)->m_pBitmap != BrNULL))) {
			BrScopedPtr<PrBitmap> pTemp(pEBitmaps->getBitmap(0)->m_pBitmap->rotate(90));
			pEBitmaps->getBitmap(0)->m_pBitmap.swap(pTemp);

			BRect effectOuterFrame(pEBitmaps->getBitmap(0)->getBoundary().TopLeft(), pEBitmaps->getBitmap(0)->getBoundary().BottomRight());
			BrRect2D orgBoundDev(0, 0, charInfo.nWidth, charInfo.nHeight);

			BRect orgBound(device2milliTwipsFrame(painter, orgBoundDev).TopLeft(),
			               device2milliTwipsFrame(painter, orgBoundDev).BottomRight());
			BRect outerGap(orgBound.nLeft - effectOuterFrame.nLeft,
			               orgBound.nTop - effectOuterFrame.nTop,
			               effectOuterFrame.nRight - orgBound.nRight,
			               effectOuterFrame.nBottom - orgBound.nBottom);

			//90도 회전
			BRect centerRc(-1, -1, 1, 1);
			BRect ct(device2milliTwipsFrame(painter, centerRc).TopLeft(),
			         device2milliTwipsFrame(painter, centerRc).BottomRight());
			BrDrawUnit::rotateRectangle(90, ct, orgBound);
			BPoint ptHeight(0, charInfo.nHeight);
			BrINT mHeight = device2milliTwips(painter, ptHeight).y;
			//회전했으므로 각각의 위치에 맞는 부분을 더하고 빼줌
			BrRect2D newOuter(orgBound.nLeft - outerGap.nBottom,
			                  orgBound.nTop - outerGap.nLeft,
			                  orgBound.nRight + outerGap.nTop,
			                  orgBound.nBottom + outerGap.nRight);
			newOuter.pt1.x += mHeight;
			newOuter.pt2.x += mHeight;

			pEBitmaps->getBitmap(0)->outer_frame = newOuter;
			return pEBitmaps;
		}
	}
	else if (nTextFlow == TEXTFLOW_SERO_270) {
		if ((pEBitmaps->getBitmap(0) != BrNULL) && ((pEBitmaps->getBitmap(0)->m_pBitmap != BrNULL))) {
			BrScopedPtr<PrBitmap> pTemp(pEBitmaps->getBitmap(0)->m_pBitmap->rotate(-90));
			pEBitmaps->getBitmap(0)->m_pBitmap.swap(pTemp);

			BRect effectOuterFrame(pEBitmaps->getBitmap(0)->getBoundary().TopLeft(),
			                       pEBitmaps->getBitmap(0)->getBoundary().BottomRight());
			BrRect2D orgBoundDev(0, 0, charInfo.nWidth, charInfo.nHeight);

			BRect orgBound(device2milliTwipsFrame(painter, orgBoundDev).TopLeft(),
			               device2milliTwipsFrame(painter, orgBoundDev).BottomRight());
			BRect outerGap(orgBound.nLeft - effectOuterFrame.nLeft,
			               orgBound.nTop - effectOuterFrame.nTop,
			               effectOuterFrame.nRight - orgBound.nRight,
			               effectOuterFrame.nBottom - orgBound.nBottom);

			//원본 Bound 270도 회전
			BRect centerRc(-1, -1, 1, 1);
			BRect ct(device2milliTwipsFrame(painter, centerRc).TopLeft(),
			         device2milliTwipsFrame(painter, centerRc).BottomRight());
			BrDrawUnit::rotateRectangle(90, ct, orgBound);

			BPoint ptDescent(0, charInfo.nDescent);
			BrINT mDescent = device2milliTwips(painter, ptDescent).y;

			//회전했으므로 각각의 위치에 맞는 부분을 더하고 빼줌
			BrRect2D newOuter(orgBound.nLeft - outerGap.nTop,
			                  orgBound.nTop - outerGap.nRight,
			                  orgBound.nRight + outerGap.nBottom,
			                  orgBound.nBottom + outerGap.nLeft);

			newOuter.pt1.x += mDescent;
			newOuter.pt2.x += mDescent;

			pEBitmaps->getBitmap(0)->outer_frame = newOuter;
		}
	}
	return pEBitmaps;
}


void CTextDraw::DrawGaroStrikeline(Painter* painter, BrDC* dc, CDrawUnit& du, CFrame* pFrame,
                                   CLine* pLine, BrINT sx, BrINT sy, BrINT nBandCount, BrINT nMaxDescent)
{
	BoraDoc* document = theBWordDoc;
	if (document == BrNULL || pFrame == BrNULL || pLine == BrNULL)
		return;

	PoTextAttHandler* text_att_h = document->getTextAttHandler();
	PoParaAttHandler* para_att_h = document->getParaAttHandler();
	if (BrNULL == text_att_h || BrNULL == para_att_h)
		return;

	RevisionEngine* revision_engine = document->getRevisionEngine();
	BrBOOL bShowRevision = revision_engine->getReviewMode() == ReviewMode::ALL_MARKUP;

	if ((document->getCmdEngine()->m_bBwpDrawForeground & TEXT_UNDERLINE_FOREGROUND) == 0 && BrFALSE == bShowRevision)
		return;

	const BrINT frame_left = HorizontalDecoFrameLeft(document->isFromHwp(), pFrame);

	const PoTextAtt* pTextAtt = BrNULL;
	CCharSet* pLink = BrNULL;
	BrCOLORREF dwColor = NONE_COLOR_BITS;

	BrINT dx, dy;
	BrINT x1, x2;
	BrINT nOneWidth, nOneHeight, nOrgOneHeight;
	BrBOOL isStrikeOut = BrFALSE;
	BrWORD wCode;

	CCharSetArray* pLinkArray = pLine->getCharSetArray();
	if (pLinkArray == BrNULL || pLinkArray->size() == 0)
		return;
	BrINT nCharNum = pLinkArray->size();

	CLongArray& cPosArray = pLine->getPosArray();
	if ((BrINT)cPosArray.size() < nCharNum + 1)
		return;

#ifdef USE_TEXTANIMATION_COUTDEV
	const BrINT ani_base_pos = pFrame->getTextAnimationFlag()? pFrame->getTextAnimationBasePos(): 0;
#else  // USE_TEXTANIMATION_COUTDEV
	const BrINT ani_base_pos = 0;
#endif  // USE_TEXTANIMATION_COUTDEV

	BrINT nWidth = 1;
	BrINT nLineHgt = du.doc2LogicalDY((pLine->getAnchorFlag())?pLine->getHeightWithoutAnchor():pLine->getAscent(), BrFALSE);
	BrINT nCol = 0;

	BrINT32 strikedy;
	BrINT32 nStrikeWidth = 1;
	BrBOOL bStrikeline = BrFALSE;
	const PoTextAtt* pTextAttForStrikeline = BrNULL;
	BrINT32 nStrikeSx = 0, nStrikeSy = 0, nStrikeDx = 0, nStrikeDy = 0, dwStrikelineColor = 0, nStrikelineY = 0, nPrevStrikelineY = 0;
	BrINT  nPrevVerticalPos = 0;
	BrBOOL bStartRTL = BrFALSE;
	BrBOOL bShowTextWrap = pFrame->isWrapNone() == BrFALSE && pLine->isLastSpace() == BrTRUE;
	CFrame* pAnchoredFrame = BrNULL;
	BrBOOL bDrawRevisionStrike = BrFALSE;

	auto& AvailArea = GetAvailAreaMatrix();
	for (BrINT nBand = 0; nBand < nBandCount; nBand++) {
		const auto& area = AvailArea[nBand];
		BrINT nBandStart = area[0] - frame_left;
		BrINT nBandEnd = area[1] - frame_left;

		//[2013.08.19] Underline 제대로 표시되지 않는 오유수정
		//cPosArray에 있는 text좌표는 원본 Frame내에서의 좌표이다.
		//line_frame clone한 경우에는 pFrame->getTextAnimationBasePos()를 덜어야
		//새 frame내에서의 좌표가 된다.
		if (nBandEnd < cPosArray[nCol] - ani_base_pos)
			continue;

		BrRect frameRct = {sx, sy , sx, sy};
		BrBOOL isHyperLink = BrFALSE;

		nCharNum = FindUnderlineTrailSpaceStopPos(pLinkArray);
		for ( ; nCol < nCharNum; nCol++) {
			pLink = pLinkArray->getCharSet(nCol);
			bDrawRevisionStrike = revision_engine->canDrawRevisionStrike(pLink);

			if (pLink->isAnchorLink())
				pAnchoredFrame = pLink->getFrame(document);

			wCode = pLink->getCode();
			if ((pLink->isTextLink() && !CTextProc::isCRCode(wCode))
			    || pLink->isTypesetLink()
			    || pLink->isFieldExLink()
			    || (pLink->isAnchorLink() && pAnchoredFrame != BrNULL && pAnchoredFrame->isAnchored() && !pAnchoredFrame->isTable())) 	//XRF-3269 //20hoon //2014-11-04 //글자 처럼 취급된 도형에도 밑줄 적용합니다.
			{
				pTextAtt = text_att_h->getTextAtt(pLink->getAttrID());
				isStrikeOut = pTextAtt->getStrikeout() || pTextAtt->getDStrikeout();

				BrBOOL bSlideHyperLink = pLink->isFieldLink() && document->isFromSlideType() && IsHyperlinkColorNode(document, pLine, nCol);

#ifdef PPT_EDITOR
				if (document->getBWPEngineMode() == EDITOR_PPT && wCode == ASCII_CODE_SPACE && bShowTextWrap == BrTRUE && pLine->getSpaceStatus() <= nCol)
					break;
#endif  // PPT_EDITOR
				BrINT fontSize = pFrame->getAutoScaledFontSize(pTextAtt->getHanFSize(), BrFALSE);
				nWidth = BrMAX(du.doc2LogicalDY(TWIPtoPT(fontSize), BrFALSE), 1);

				if (isStrikeOut || bDrawRevisionStrike) {
					BrBOOL is_normal_rtl = HorizontalCoordinates(x1, x2, bStartRTL, pLine, nCol, ani_base_pos,
					                                             bStrikeline, wCode, nBandEnd);
					if (x1 < x2 || bStartRTL) {
						dx = HorizontalLogicalX(du, is_normal_rtl, bStartRTL, sx, x1, x2, nStrikeDx);
						dy = sy;

						dwColor = FindStrikelineColor(bSlideHyperLink, pTextAtt, pLine);

						nOneWidth = du.doc2LogicalDX(x2 - x1, BrFALSE) + 1;

						BrINT fontSize = pFrame->getAutoScaledFontSize(pLink->isTwoByteCode()? pTextAtt->getHanFSize(): pTextAtt->getEngFSize(), BrFALSE);	//[XPD-11434]
						nOneHeight = du.doc2LogicalDY(fontSize, BrFALSE);

						if (pLine->getFrame()->isWordMemoFrame()) {
							PoTextAtt* pDefaultAtt = document->getDefaultTextAtt();
							nOneHeight = du.doc2LogicalDY((pLink->isTwoByteCode())? pDefaultAtt->getHanFSize():
																							 pDefaultAtt->getEngFSize(), BrFALSE);

							nWidth = du.doc2LogicalDY(pDefaultAtt->getHanFSize() / 20, BrFALSE);
							if (nWidth < 1)
								nWidth = 1;
						}

						if (pTextAtt->getSuperscript() || pTextAtt->getSubscript()) {
							nOrgOneHeight = nOneHeight;
							nOneHeight = (BrINT)(nOneHeight * PO_TEXTATT_BASE::superSubScriptSizeRatio);
							nWidth = (BrINT)(nWidth * PO_TEXTATT_BASE::superSubScriptSizeRatio);
							if (pTextAtt->getSubscript()) {
								dy -= ((nLineHgt >> 1) >> 1) + (nOneHeight >> 1); //아래 첨자 글자의 Top 좌표
							}
							else {
								dy = dy - nLineHgt + nOneHeight/*-LineOneDescent(document, pLine, nCol)*/; //위 첨자 글자의 Bottom 좌표 (#7663)(2012.7.10)

								dy += (nLineHgt - nOrgOneHeight);	// IOS #27579 (2013.4.15)
							}
						}

						frameRct.top = BrMIN(frameRct.top, sy - nOneHeight);
						frameRct.bottom = BrMAX(frameRct.bottom, sy - nOneHeight);

						if (isStrikeOut || bDrawRevisionStrike) {
							strikedy = dy;
							BrBYTE bTextFlow = pFrame->getTextFlow();
							if (bTextFlow == TEXTFLOW_GARO) //Line이 아닌 글자의 가운데에 취소선을 그려줌
							{
								if (pTextAtt->getSuperscript()) {
									// (#7867)(2012.7.16)
									strikedy -= (nOneHeight >> 1) + LineOneDescent(document, pLine, nCol) / 2;	// nOneHeight * 0.30;	// nLineHgt>>1;
								}
								else if (pTextAtt->getSubscript()) {
									strikedy += (nOneHeight >> 1) + LineOneDescent(document, pLine, nCol) / 2;	// nOneHeight * 0.30;	// nLineHgt>>1;
								}
								else {
									//[ZPD-19370]원문자와 함게 취소선이 있을 경우 폰트 크기가 같으면 높이가 같아야함. LineOneDescent 함수 막음.
									//strikedy -= nMaxDescent - LineOneDescent(document, pLine, nCol);
									strikedy -= nMaxDescent + BrINT32(nOneHeight * 0.3);
								}
							}
							else if (bTextFlow == TEXTFLOW_GARO_ROTATE)
								strikedy -= nOneHeight >> 1;

							if (pTextAtt->isSettedTextVerticalPos())
								strikedy -= du.doc2LogicalDY(pTextAtt->getTextVerticalPos(), BrFALSE);

							nStrikelineY = strikedy;
						}

						if (isStrikeOut || bDrawRevisionStrike) {
							if (bDrawRevisionStrike) {
								BrCOLORREF lineColor = revision_engine->getReviewerColor(pLink);
								if (pLine) {
									if (document->GetGrayMode() != GRAY_MODE_COLOR) {
										CFrame* frm = pLine->getFrame();
										if (frm) {
											lineColor = BrColor::getBwColor(document->GetGrayMode(), frm->getFrameColorMode(), lineColor, GRAY_MODE_APPLY_TEXT);
										}
									}
								}
								if (!pTextAtt->getStrikeout()) {
									BrRect frameRct = {nStrikeSx, sy - (nMaxDescent + nOneHeight) ,nStrikeDx, dy};
									CCUtil::drawLine(dc, dx, nStrikelineY, dx + nOneWidth, nStrikelineY, nWidth, lineColor);
									continue;
								}
							}

							if (bStrikeline && !bDrawRevisionStrike) {
								if ((nPrevStrikelineY && nPrevStrikelineY > nStrikelineY&& nStrikeSy != nPrevStrikelineY) || (nStrikeSy != nStrikelineY)
										|| (pTextAtt->getStrikeout() ^ pTextAttForStrikeline->getStrikeout()) || (pTextAtt->getDStrikeout() ^ pTextAttForStrikeline->getDStrikeout())
										|| (pTextAtt->getStrikeStyle() != pTextAttForStrikeline->getStrikeStyle()))	//ZPD-26603 선종류 다르면
								{
									bStrikeline = BrFALSE;
									bStartRTL = BrFALSE;
									DrawStrikethrough(painter, dc, du, pFrame, pLine, nStrikeSx, nStrikeSy,
									                  nStrikeDx, nStrikeDy, nStrikeWidth, dwStrikelineColor,
									                  pTextAttForStrikeline, frameRct, nLineHgt, isHyperLink);
								}
								else {
									BrGrapAtt* grapAtt = pTextAtt->isSettedGrapAtt()? pTextAtt->getGrapAtt(): BrNULL;
									BrGrapAtt* grapAttForStrikeline = pTextAttForStrikeline->isSettedGrapAtt()? pTextAttForStrikeline->getGrapAtt(): BrNULL;
									if (dwColor != dwStrikelineColor
											|| ((grapAtt && !grapAttForStrikeline) || (!grapAtt && grapAttForStrikeline))
											|| (!pTextAtt->equalWordArtStyle(pTextAttForStrikeline) && (isHyperLink || (grapAtt && grapAtt->isGradient()) || (grapAttForStrikeline && grapAttForStrikeline->isGradient())))
											|| (!pTextAtt->hasEqualShadowAtt(pTextAttForStrikeline))
											|| bSlideHyperLink != isHyperLink) {
										bStrikeline = BrFALSE;
										bStartRTL = BrFALSE;
										DrawStrikethrough(painter, dc, du, pFrame, pLine, nStrikeSx, nStrikeSy,
										                  nStrikeDx, nStrikeDy, nStrikeWidth, dwStrikelineColor,
										                  pTextAttForStrikeline, frameRct, nLineHgt, isHyperLink);
									}
								}
							}

							if (bStrikeline) {
								if (bStartRTL)
									nStrikeDx = dx;
								else
									nStrikeDx = dx + nOneWidth;
							}
							else {
								bStrikeline = BrTRUE;
								pTextAttForStrikeline = pTextAtt;

								dwStrikelineColor = FixStrikethroughColor(document->isFromSlideType(), document, pLine,
								                                          nCol, pTextAtt, dwColor, painter, pFrame);
#ifdef SUPPORT_LOW_VISION_SHAPE
								if (document->m_pLowVisionColorModeEngine)
									dwStrikelineColor = document->m_pLowVisionColorModeEngine->GetTextColor();
#endif  // SUPPORT_LOW_VISION_SHAPE

								nStrikeSx = dx;
								if (bStartRTL)
									nStrikeDx = dx - nOneWidth;
								else
									nStrikeDx = dx + nOneWidth;

								nStrikeSy = nStrikeDy = nPrevStrikelineY = nStrikelineY;

								nStrikeWidth = nWidth;
							}
						}
						else {
							nPrevStrikelineY = 0;
							if (bStrikeline) {
								bStrikeline = BrFALSE;
								bStartRTL = BrFALSE;
								DrawStrikethrough(painter, dc, du, pFrame, pLine, nStrikeSx, nStrikeSy,
								                  nStrikeDx, nStrikeDy, nStrikeWidth, dwStrikelineColor,
								                  pTextAttForStrikeline, frameRct, nLineHgt, isHyperLink);
							}
						}

						frameRct.left = BrMIN(frameRct.left, nStrikeSx);
						frameRct.right = BrMAX(frameRct.right, nStrikeDx);
					}
				}
				else {
					if (bStrikeline) {
						bStrikeline = BrFALSE;
						bStartRTL = BrFALSE;
						DrawStrikethrough(painter, dc, du, pFrame, pLine, nStrikeSx, nStrikeSy,
						                  nStrikeDx, nStrikeDy, nStrikeWidth, dwStrikelineColor,
						                  pTextAttForStrikeline, frameRct, nLineHgt);
					}
				}

				isHyperLink = bSlideHyperLink;
			}
			if (nBandEnd < cPosArray[nCol + 1] - ani_base_pos) {
				nCol++;
				break;
			}
		}

		if (bStrikeline) {
			bStrikeline = BrFALSE;
			bStartRTL = BrFALSE;

			DrawStrikethrough(painter, dc, du, pFrame, pLine, nStrikeSx, nStrikeSy,
			                  nStrikeDx, nStrikeDy, nStrikeWidth, dwStrikelineColor,
			                  pTextAttForStrikeline, frameRct, nLineHgt, isHyperLink);

			if (!document->isFromHwp()) {
				if (pLine->getAnchorFlag()) {
					CCharSetArray* pCharSetArr = pLine->getCharSetArray();
					CCharSet* pCharSet = BrNULL;

					for (BrINT i = 0; i < pCharSetArr->GetSize(); i++) {
						pCharSet = pCharSetArr->GetAt(i);

						if (pCharSet->isAnchorLink()) {
							CFrame* frm = document->getAnchorFrame(pCharSet->getCode());
							if (frm && frm->isAnchored())
								frm->draw(getPainter(), dc, du);
						}
					}
				}
			}
		}

		if (nCol == nCharNum - 1)
			break;
	}
}


void CTextDraw::DrawBackgroundOfSeroOneLine(BrDC* dc, CDrawUnit& du, CFrame* pFrame,
                                            CLine* pLine, BrINT sx, BrINT sy, BrINT nBandCount)
{
	BoraDoc* document = theBWordDoc;
	if (document == BrNULL || pFrame == BrNULL || pLine == BrNULL)
		return;

	BrCOLORREF back_color = 0;
	BrCOLORREF prev_back_color = NONE_COLOR_BITS;
	BRect rect_fill;
	BrBOOL bIconMemo = BrFALSE;
	BRect rcIconMemo;

	//[T-16745]20hoon  draw Shading
	BRect rect_shading;
	BrCOLORREF shading_pattern = NONE_COLOR_BITS;
	BrCOLORREF shading_fill = NONE_COLOR_BITS;
	BrINT shading_pattern_style = BR_SHADING_PATTERN_STYLE_ERASE;
	BrCOLORREF prev_pattern = NONE_COLOR_BITS;
	BrCOLORREF prev_fill = NONE_COLOR_BITS;
	BrINT prev_pattern_style = BR_SHADING_PATTERN_STYLE_ERASE;

	PoTextAttHandler* text_att_h = document->getTextAttHandler();
	if (BrNULL == text_att_h)
		return;

	CLongArray& pos_arr = pLine->getPosArray();
	CCharSetArray* charset_arr = pLine->getCharSetArray();
	BrINT count = charset_arr? charset_arr->size(): 0;
	if (0 == count || (BrINT)pos_arr.size() < count + 1)
		return;

	if (pLine->getStatus(LINE_FIELD) != 0) {
		CLocation location;
		location.setLocation(pLine, 0);
	}

	BrINT nLineSp = du.doc2LogicalDX(CTextProc::CalcLineSpace(document, pLine), BrFALSE) / 2;
	if (pFrame->isTextFlowLeftToRight()) {
		rect_fill.nLeft = sx - nLineSp;		//[LQQ-6086]모든 텍스트 270도 회전일때 하이라이트 위치 오류 수정.
		rect_fill.nRight = sx + du.doc2LogicalDX(pLine->getAscent(), BrFALSE);

		rect_shading.nLeft = rect_fill.nLeft;
		rect_shading.nRight = rect_fill.nRight;
	}
	else {
		if (document->isFromHwp()) {
			rect_fill.nLeft = sx;
			rect_fill.nRight = sx + du.doc2LogicalDX(pLine->getAscent(), BrFALSE);
		}
		else {
			rect_fill.nLeft = sx - nLineSp;
			rect_fill.nRight = sx + du.doc2LogicalDX(pLine->getAscent(), BrFALSE) + nLineSp;
		}

		rect_shading.nLeft = rect_fill.nLeft;
		rect_shading.nRight = rect_fill.nRight;
	}

	//[SGC-269] bidi에 관련된 부분이 없어 배경색이 제대로 출력되지 않아 bidi 추가
#ifdef BIDI_SUPPORT
	const PoParaAtt* para_att = document->getParaAttHandler()->getMergedParaAtt(pLine->getParaID(), pLine);
	BrBOOL is_bidi = (pLine->hasBidi() || para_att->getBiDi());
	BrBOOL is_bidi_init = BrFALSE;
	BRect rect_bidi_fill, rect_char;
	rect_bidi_fill.nLeft = rect_fill.nLeft;
	rect_bidi_fill.nRight = rect_fill.nRight;
#endif  // BIDI_SUPPORT
	BrINT nMemoReference = 0;
	BrBOOL bMemoProc = BrFALSE;

	BrINT col = 0;
	BrINT frame_top = pFrame->top();
	const BrBOOL is_textflow_btm2top = pFrame->isTextFlowBottomToTop();
	const BrBOOL is_hwp = (getDocType() == BORA_DOCTYPE_HWP);

	auto& AvailArea = GetAvailAreaMatrix();
	for (BrINT nBand = 0; nBand < nBandCount; nBand++) {
		BrINT nBandStart = AvailArea[nBand][0] - frame_top;
		BrINT nBandEnd = AvailArea[nBand][1] - frame_top;

		BrINT pos = pos_arr[col];
		if (pos > nBandEnd)
			continue;

		if (is_textflow_btm2top) {
			if (pos < nBandStart) {
				rect_fill.nBottom = sy - du.doc2LogicalDY(nBandStart, BrFALSE);
				rect_shading.nBottom = sy - du.doc2LogicalDY(nBandStart, BrFALSE);
			}
			else {
				rect_fill.nBottom = sy - du.doc2LogicalDY(pos, BrFALSE);
				rect_shading.nBottom = sy - du.doc2LogicalDY(nBandStart, BrFALSE);
			}
		}
		else {
			if (pos < nBandStart) {
				rect_fill.nTop = sy + du.doc2LogicalDY(nBandStart, BrFALSE);
				rect_shading.nTop = sy + du.doc2LogicalDY(nBandStart, BrFALSE);
			}
			else {
				rect_fill.nTop = sy + du.doc2LogicalDY(pos, BrFALSE);
				rect_shading.nTop = sy + du.doc2LogicalDY(pos, BrFALSE);
			}
		}

		for (; col < count; ++col) {
			CCharSet* charset = charset_arr->getCharSet(col);

			BrINT pos1 = pos_arr[col];
			if (is_textflow_btm2top) {
				rect_fill.nTop = sy - du.doc2LogicalDY(pos1, BrFALSE);
				rect_shading.nTop = sy - du.doc2LogicalDY(pos1, BrFALSE);
			}
			else {
				rect_fill.nBottom = sy + du.doc2LogicalDY(pos1, BrFALSE);
				rect_shading.nBottom = sy + du.doc2LogicalDY(pos1, BrFALSE);
			}

			bIconMemo = BrFALSE;
			bMemoProc = BrFALSE;

			if (document->isMemoModeFrame() == BrFALSE && document->isMemoModeSimple() == BrFALSE) {
				ConfigureDrawingMemoInfo(nMemoReference, rect_fill, rcIconMemo, back_color, bMemoProc,
				                         pFrame, pLine, col, sx, du, BrTRUE);
			}

			if (BrFALSE == bMemoProc) {
				const PoTextAtt* text_att = text_att_h->getTextAtt(charset->getAttrID());
				if (BrNULL == text_att)
					continue;

				BrBOOL is_draw_background = CheckDrawBackground(charset, text_att, document);
				if (is_hwp) {
					ConfigureHWPBgColor(back_color, shading_fill,
					                    shading_pattern, shading_pattern_style,
					                    is_draw_background, charset, text_att, pLine, document);
				}
				else {
					back_color = TakeBackColor(is_draw_background, charset, text_att, pLine, document);

					/****************************
					*   set Text Shading Color *
					*****************************/
					if (is_draw_background && BrFALSE == charset->isCROrSoftEnterLink() &&
							BrFALSE == text_att->getBackFlag() && BrFALSE == charset->isBulletLink()) {
						shading_fill = text_att->getBorderFillFaceColor() == NONE_COLOR_BITS?
						                             text_att->getShadingFillColor().getColor():
						                             text_att->getBorderFillFaceColor();
						shading_pattern = text_att->getShadingPatternColor().getColor();
						shading_pattern_style = text_att->getShadingPatternStyle();
					}
					else {
						shading_fill = NONE_COLOR_BITS;
						shading_pattern = NONE_COLOR_BITS;
						shading_pattern_style = BR_SHADING_PATTERN_STYLE_ERASE;
					}
				}
			}

			BrBmvBrush brush;
			//[SGC-269] bidi에 관련된 부분이 없어 배경색이 제대로 출력되지 않아 bidi 추가
#ifdef BIDI_SUPPORT
			if (is_bidi) {
				BrBOOL is_draw_fill = BrFALSE;
				if (pFrame) {
					if (document->GetGrayMode() != GRAY_MODE_COLOR) {
						back_color = BrColor::getBwColor(document->GetGrayMode(), pFrame->getFrameColorMode(), back_color, GRAY_MODE_APPLY_TEXT);
#ifdef SUPPORT_NIGHT_VIEW_MODE
						if (document->isNightViewMode())
							back_color = BrXORColor(back_color);
#endif  // SUPPORT_NIGHT_VIEW_MODE
					}
				}

				if (back_color != NONE_COLOR_BITS) {
					rect_char.nTop = pos1;
					rect_char.nBottom = 0x0FFFFFFF;
					for (BrINT i = 0; i <= count; i++) {
						BrINT position = pos_arr[i];
						if (rect_char.nTop < position && position < rect_char.nBottom)
							rect_char.nBottom = position;
					}

					if (rect_char.nBottom == 0x0FFFFFFF)
						rect_char.nBottom = rect_char.nTop;

					if (is_bidi_init && back_color != prev_back_color) {
						rect_bidi_fill.nTop = sy + du.doc2LogicalDX(rect_bidi_fill.nTop, BrFALSE);
						rect_bidi_fill.nBottom = sy + du.doc2LogicalDX(rect_bidi_fill.nBottom, BrFALSE);
						DrawFillRect(dc, brush, rect_bidi_fill, prev_back_color);
						is_bidi_init = BrFALSE;
					}

					if (BrFALSE == is_bidi_init) {
						rect_bidi_fill.nTop = rect_char.nTop;
						rect_bidi_fill.nBottom = rect_char.nBottom;
						is_bidi_init = BrTRUE;
					}
					else if (rect_char.nTop == rect_bidi_fill.nBottom) {
						rect_bidi_fill.nBottom = rect_char.nBottom;
					}
					else if (rect_char.nBottom == rect_bidi_fill.nTop) {
						rect_bidi_fill.nTop = rect_char.nTop;
					}
					else {
						is_draw_fill = BrTRUE;
					}

					if (is_draw_fill || col == count - 1) {
						rect_bidi_fill.nTop = sy + du.doc2LogicalDX(rect_bidi_fill.nTop, BrFALSE);
						rect_bidi_fill.nBottom = sy + du.doc2LogicalDX(rect_bidi_fill.nBottom, BrFALSE);
						DrawFillRect(dc, brush, rect_bidi_fill, prev_back_color);
						rect_bidi_fill.nTop = rect_char.nTop;
						rect_bidi_fill.nBottom = rect_char.nBottom;
					}

					prev_back_color = back_color;
				}
				else if (prev_back_color != NONE_COLOR_BITS) {
					rect_bidi_fill.nTop = sy + du.doc2LogicalDX(rect_bidi_fill.nTop, BrFALSE);
					rect_bidi_fill.nBottom = sy + du.doc2LogicalDX(rect_bidi_fill.nBottom, BrFALSE);
					DrawFillRect(dc, brush, rect_bidi_fill, prev_back_color);
					is_bidi_init = BrFALSE;
				}
				continue;
			}
#endif  // BIDI_SUPPORT

			if (is_hwp) {
				FillVerticalBackground(prev_back_color, rect_fill, back_color, brush, dc, is_textflow_btm2top);
				DrawVerticalShading(prev_fill, shading_fill,
				                    prev_pattern, shading_pattern,
				                    prev_pattern_style, shading_pattern_style,
				                    rect_shading, dc, is_textflow_btm2top);
			}
			else {
				//[T-16745]20hoon  draw Shading
				DrawVerticalShading(prev_fill, shading_fill,
				                    prev_pattern, shading_pattern,
				                    prev_pattern_style, shading_pattern_style,
				                    rect_shading, dc, is_textflow_btm2top);
				FillVerticalBackground(prev_back_color, rect_fill, back_color, brush, dc, is_textflow_btm2top);
			}

			BrINT pos2 = pos_arr[col + 1];
			if (nBandEnd < pos2) {
				DrawVerticalShadingFillBg(rect_fill, rect_shading, prev_fill, shading_fill,
				                          prev_pattern, shading_pattern, prev_pattern_style,
				                          shading_pattern_style, prev_back_color, back_color,
				                          sy, nBandEnd, is_textflow_btm2top, dc, du, brush);
				break;
			}
			if (col == count - 1) {
				DrawVerticalShadingFillBg(rect_fill, rect_shading, prev_fill, shading_fill,
				                          prev_pattern, shading_pattern, prev_pattern_style,
				                          shading_pattern_style, prev_back_color, back_color,
				                          sy, pos2, is_textflow_btm2top, dc, du, brush);
			}
		}
	}

#ifdef USE_TOUCHED_WORD_MARKING_FOR_BWP
	CCmdEngine* cmd_engine = document->getCmdEngine();
	if (document->getEditProtect() && cmd_engine->pWordMarking == pLine) {
		if (is_textflow_btm2top) {
			rect_fill.nTop = sy - du.doc2LogicalDX(pos_arr[cmd_engine->nEndWordMark], BrFALSE);
			rect_fill.nBottom = sy - du.doc2LogicalDX(pos_arr[cmd_engine->nStartWordMark], BrFALSE);
		}
		else {
			rect_fill.nTop = sy + du.doc2LogicalDX(pos_arr[cmd_engine->nStartWordMark], BrFALSE);
			rect_fill.nBottom = sy + du.doc2LogicalDX(pos_arr[cmd_engine->nEndWordMark], BrFALSE);
		}
		BrBYTE nOldAlphaValue = dc->setAlphaValue(127);
		BrBmvBrush brush;
		DrawFillRect(dc, brush, rect_fill, SEARCH_MARK_ALL_COLOR);
		dc->setAlphaValue(nOldAlphaValue);
	}
#endif  // USE_TOUCHED_WORD_MARKING_FOR_BWP
}


void CTextDraw::FillVerticalBackground(BrCOLORREF& prev_back, BRect& rect, BrCOLORREF back,
                                       BrBmvBrush& brush, BrDC* dc, BrBOOL is_textflow_btm2top)
{
	if (back == prev_back)
		return;

	if (NONE_COLOR_BITS != prev_back)
		DrawFillRect(dc, brush, rect, prev_back);

	if (is_textflow_btm2top)
		rect.nBottom = rect.nTop;
	else
		rect.nTop = rect.nBottom;

	prev_back = back;
}


void CTextDraw::DrawVerticalShading(BrCOLORREF& prev_fill, BrCOLORREF shading_fill,
                                    BrCOLORREF& prev_pattern, BrCOLORREF shading_pattern,
                                    BrINT& prev_pattern_style, BrINT shading_pattern_style,
                                    BRect& rect, BrDC* dc, BrBOOL is_textflow_btm2top)
{
	if (shading_fill == prev_fill &&
	    shading_pattern == prev_pattern &&
	    shading_pattern_style == prev_pattern_style)
		return;

	if (BR_SHADING_PATTERN_STYLE_ERASE != prev_pattern_style || NONE_COLOR_BITS != prev_fill) {
		// Multi Marking이 Normal Caret인 상태에서 추가 할때
		if (rect.nBottom == rect.nTop)
			rect.nBottom += 2;
		DrawShading(dc, &rect, prev_fill, prev_pattern, prev_pattern_style);
	}

	AssignShading(prev_fill,    prev_pattern,    prev_pattern_style,
	              shading_fill, shading_pattern, shading_pattern_style);

	if (is_textflow_btm2top)
		rect.nBottom = rect.nTop;
	else
		rect.nTop = rect.nBottom;
}


void CTextDraw::DrawVerticalShadingFillBg(BRect& rect_fill, BRect& rect_shading,
                                          BrCOLORREF& prev_fill, BrCOLORREF shading_fill,
                                          BrCOLORREF& prev_pattern, BrCOLORREF shading_pattern,
                                          BrINT& prev_pattern_style, BrINT shading_pattern_style,
                                          BrCOLORREF& prev_back, BrCOLORREF back,
                                          BrINT sy, BrINT y, BrBOOL is_textflow_btm2top,
                                          BrDC* dc, CDrawUnit& du, BrBmvBrush& brush)
{
	if (is_textflow_btm2top) {
		rect_fill.nTop = sy - du.doc2LogicalDY(y, BrFALSE);
		rect_shading.nTop = rect_fill.nTop;
	}
	else {
		rect_fill.nBottom = sy + du.doc2LogicalDY(y, BrFALSE);
		rect_shading.nBottom = rect_fill.nBottom;
	}

	//[2013-08-26][T-16745]20hoon draw shading;
	if (BR_SHADING_PATTERN_STYLE_ERASE != shading_pattern_style || NONE_COLOR_BITS != shading_fill) {
		DrawShading(dc, &rect_shading, shading_fill, shading_pattern, shading_pattern_style);
		AssignShading(prev_fill, prev_pattern, prev_pattern_style,
		              shading_fill, shading_pattern, shading_pattern_style);
	}

	if (NONE_COLOR_BITS != prev_back) {
		DrawFillRect(dc, brush, rect_fill, back);
		prev_back = back;
	}
}


void CTextDraw::DrawVerticalTextDecoration(Painter* painter, BrDC* dc, CDrawUnit& du,
                                           CFrame* frame, CLine* line, BrINT x, BrINT y,
                                           BrINT band_count)
{
	BoraDoc* document = theBWordDoc;
	if (BrNULL == document || BrNULL == frame || BrNULL == line)
		return;

	if (BrNULL == document->getTextAttHandler())
		return;

	CCharSetArray* charset_arr = line->getCharSetArray();
	BrINT count = charset_arr? charset_arr->size(): 0;
	if (0 == count)
		return;

	BrINT pos_count = line->getPosArray().size();
	if (pos_count < count + 1)
		return;

	BrBYTE draw_fg = document->getCmdEngine()->m_bBwpDrawForeground;
	if (draw_fg & TEXT_UNDERLINE_FOREGROUND) {
		DrawSeroUnderline(painter, dc, du, document, frame, line, x, y, band_count);
		DrawSeroStrikeline(painter, dc, du, document, frame, line, x, y, band_count);
	}
}


void CTextDraw::DrawSeroUnderline(Painter* painter, BrDC* dc, CDrawUnit& du, BoraDoc* document,
                                  CFrame* pFrame, CLine* pLine, BrINT sx, BrINT sy, BrINT nBandCount)
{
	const BrLONG frame_top = pFrame->top();
	CLongArray& cPosArray = pLine->getPosArray();
	const PoTextAtt* pTextAtt = BrNULL;
	CCharSet* pLink = BrNULL;
	PoTextAttHandler* text_att_h = document->getTextAttHandler();
	BrINT nLineWid = du.doc2LogicalDX(pLine->getAscent(), BrFALSE);
	CCharSetArray* pLinkArray = pLine->getCharSetArray();

#if defined(USE_HYPERLINK_DRAW_FOR_BWP) || defined(USE_HYPERLINK_TOUCH_FOR_BWP)
	BrINT nLineSp = du.doc2LogicalDY(pLine->getAscent(), BrFALSE);
	PrBitmap sBitmap;
#endif  // USE_HYPERLINK_DRAW_FOR_BWP || USE_HYPERLINK_TOUCH_FOR_BWP

	BrINT nLineHgt = du.doc2LogicalDY((pLine->getAnchorFlag())?pLine->getHeightWithoutAnchor():pLine->getAscent(), BrFALSE);
	BrINT nCol = 0;
	BrBOOL bUnderline = BrFALSE;
	BrINT32 nSx, nSy, nDx, nDy, nLineWidth, dwUnderlineColor;
	nSx = nSy = nDx = nDy = nLineWidth = dwUnderlineColor = 0;

	BrINT nStartCharIndexOfTextBorder = -1;
	BrBOOL bAllSpace = BrTRUE;

	BrBOOL bShowTextWrap = (BrFALSE == pFrame->isWrapNone() && pLine->isLastSpace());
	PoTextAtt textAttForUnderline;
	BrINT nMaxDescent = CTextProc::getMaxDescentOfCurLine(document, pLine);
	BrINT nPrevVerticalPos = 0;

	BYTE bTextFlow = pFrame->getTextFlow();
	BrBOOL bTextFlowBTT = pFrame->isTextFlowBottomToTop();
	BrBOOL isUnderline = BrFALSE, isStrikeOut = BrFALSE;

	auto& AvailArea = GetAvailAreaMatrix();
	for (BrINT nBand = 0; nBand < nBandCount; nBand++) {
		BrINT nBandStart = AvailArea[nBand][0] - frame_top;
		BrINT nBandEnd = AvailArea[nBand][1] - frame_top;

		if (cPosArray[nCol] > nBandEnd)
			continue;

		nStartCharIndexOfTextBorder = -1;

		BrBOOL bFoundFirstSpace = BrFALSE;
		BrINT nCharNum = FindUnderlineTrailSpaceStopPos(pLinkArray);

		BrRect frameRct = {sx, sy, sx, sy};
		BrBOOL isHyperLink = BrFALSE;

		for (; nCol < nCharNum; nCol++) {
			pLink = pLinkArray->getCharSet(nCol);
			if (pLink == BrNULL)
				continue;

			BrWORD wCode = pLink->getCode();
			if (0 == pLink->isTypesetLink() && (BrFALSE == pLink->isTextLink() || CTextProc::isCRCode(wCode)))
				continue;

#ifdef PPT_EDITOR
			if (document->getBWPEngineMode() == EDITOR_PPT && wCode == ASCII_CODE_SPACE &&
					bShowTextWrap && pLine->getSpaceStatus() <= nCol)
				break;
#endif  // PPT_EDITOR

			pTextAtt = text_att_h->getTextAtt(pLink->getAttrID());

			isUnderline = pTextAtt->getUnderline();
			isStrikeOut = pTextAtt->getStrikeout() || pTextAtt->getDStrikeout();

			if (bAllSpace && !pLink->isSpace())
				bAllSpace = BrFALSE;

			BrBOOL bSlideHyperLink = pLink->isFieldLink() && document->isFromSlideType() && IsHyperlinkColorNode(document, pLine, nCol);
			if (bSlideHyperLink)
				isUnderline = !(pLink->isSpace() && pLine->isHyperLastSpaceInLine(nCol));

#ifdef REMOVE_HYPER_LINK_ATTRIBUTE
			if (IsRemoveHyperlinkAttr(painter, pTextAtt))
				isUnderline = BrFALSE;
#endif  // REMOVE_HYPER_LINK_ATTRIBUTE

			if (pLink->isBulletLink())// && (pLink->getCode() == ASCII_CODE_TAB || pLink->getCode() == ASCII_CODE_SPACE))
				isUnderline = BrFALSE;

			if (isUnderline || isStrikeOut) {
				BrINT dx = sx;
				BrINT dy, nOneHeight, nOneWidth, nWidth;
				BrBOOL is_config = ConfigVerticalCharPos(dy, nOneHeight, nOneWidth, nWidth, sy,
				                                         cPosArray, nCol, nBandEnd,
				                                         du, document, pFrame, pLink, pTextAtt);
				if (is_config) {
					BrBOOL is_hyper_underline = pTextAtt->isSettedUnderlineColor();  // ???
					BrCOLORREF dwColor = FindUnderlineColor(bSlideHyperLink, is_hyper_underline, pTextAtt, pLine);

					dx = CalculateLinePos(bTextFlow, pTextAtt->getSubscript(), pTextAtt->getSuperscript(),
					                      dx, nLineWid, nOneWidth, nMaxDescent);

					BrINT verticalPos = pTextAtt->isSettedTextVerticalPos()? pTextAtt->getTextVerticalPos(): 0;
					switch (bTextFlow) {
						case TEXTFLOW_SERO_90:
							dx += du.doc2LogicalDX(verticalPos, BrFALSE) - nMaxDescent;
							break;
						case TEXTFLOW_SERO_270:
							dx -= du.doc2LogicalDX(verticalPos, BrFALSE) - nMaxDescent;
							break;
						case TEXTFLOW_SERO:
						default:
							dx += du.doc2LogicalDX(BrMAX(verticalPos, 0), BrFALSE);
							break;
					}

					if (pTextAtt->getSuperscript() || pTextAtt->getSubscript())
						nOneWidth = (BrINT)(nOneWidth * 0.55);

					if (isUnderline) {
						//hnsong:2012-05 PO5.0 개발항목 - 밑줄의 종류 지원
						//BrWORD단위로 밑줄 지원
						if (bUnderline) {
							if (UNDERLINE_STYLE_WORDS == pTextAtt->getUnderlineStyle() && (ASCII_CODE_SPACE == wCode || ASCII_CODE_TAB == wCode)) {
								bUnderline = BrFALSE;
								DrawSeroUnderlineBitmap(painter, dc, nSx, nSy, nDx, nDy, frameRct, 1, nLineWidth,
								                        dwUnderlineColor, &textAttForUnderline, pFrame, pLine,
								                        nCol, nLineHgt, nMaxDescent, isHyperLink);
								continue;
							}

							if (pTextAtt->getUnderlineStyle() != textAttForUnderline.getUnderlineStyle() ||
							    pTextAtt->getUnderlinePos() != textAttForUnderline.getUnderlinePos() ||
							    nPrevVerticalPos != verticalPos
							) {
								bUnderline = BrFALSE;
								DrawSeroUnderlineBitmap(painter, dc, nSx, nSy, nDx, nDy, frameRct, 1, nLineWidth,
								                        dwUnderlineColor, &textAttForUnderline, pFrame, pLine,
								                        nCol, nLineHgt, nMaxDescent, isHyperLink);
							}
							else {
								BrINT32 dwUnderColor = (pTextAtt->getUnderlineColor().getColor() != NONE_COLOR_BITS)? pTextAtt->getUnderlineColor().getColor(): dwColor;
								BrGrapAtt* grapAtt = pTextAtt->isSettedGrapAtt()? pTextAtt->getGrapAtt(): BrNULL;
								BrGrapAtt* grapAttForUnderline = textAttForUnderline.isSettedGrapAtt()? textAttForUnderline.getGrapAtt(): BrNULL;

								if (dwUnderColor != dwUnderlineColor ||
								    ((grapAtt && !grapAttForUnderline) || (!grapAtt && grapAttForUnderline)) ||
								    (!pTextAtt->equalWordArtStyle(&textAttForUnderline) && (isHyperLink || (grapAtt && grapAtt->isGradient()) || (grapAttForUnderline && grapAttForUnderline->isGradient()))) ||
								    (!pTextAtt->hasEqualShadowAtt(&textAttForUnderline)) ||
								    bSlideHyperLink != isHyperLink) {
									bUnderline = BrFALSE;
									DrawSeroUnderlineBitmap(painter, dc, nSx, nSy, nDx, nDy, frameRct, 1, nLineWidth,
									                        dwUnderlineColor, &textAttForUnderline, pFrame, pLine,
									                        nCol, nLineHgt, nMaxDescent, isHyperLink);
								}
							}
						}

						if (BrFALSE == bUnderline) {
							if (!(pTextAtt->getUnderlineStyle() == UNDERLINE_STYLE_WORDS && (ASCII_CODE_SPACE == wCode || ASCII_CODE_TAB == wCode)))
								bUnderline = BrTRUE;

							dwUnderlineColor = (pTextAtt->getUnderlineColor().getColor() != NONE_COLOR_BITS)? pTextAtt->getUnderlineColor().getColor(): dwColor;

							nLineWidth = du.doc2LogicalDY(pTextAtt->getHanFSize() / 20, BrFALSE);
							textAttForUnderline = *pTextAtt;
							nPrevVerticalPos = verticalPos;

							nSx = nDx = dx;
							nSy = dy;
							frameRct.left = frameRct.right = dx;

							if (bTextFlowBTT) {
								nDy = dy - nOneHeight;
								frameRct.top = nDy;
								frameRct.bottom = nSy;
							}
							else {
								nDy = dy + nOneHeight;
								frameRct.top = nSy;
								frameRct.bottom = nDy;
							}
						}
						else {
							if (bTextFlowBTT)
								nDy = dy - nOneHeight;
							else
								nDy = dy + nOneHeight;
						}
					}
					else {
						if (bUnderline) {
							bUnderline = BrFALSE;
							DrawSeroUnderlineBitmap(painter, dc, nSx, nSy, nDx, nDy, frameRct, 1, nWidth,
							                        dwUnderlineColor, &textAttForUnderline, pFrame, pLine,
							                        nCol, nLineHgt, nMaxDescent, isHyperLink);
						}
					}
//				// Field Node이면 Underline을 처리해 준다.
//				if ( pLink->isFieldLink() && document->isFromSlideType() && !pLink->isMemoLink())
//					DrawNormalUnderline(dc, dx, dy, dx, dy+nOneHeight, nWidth, ((hlink_color | 0xff000000) == RGB_BLACK)?HYPER_LINK_COLOR:hlink_color, text_att, pLine, nLineHgt);
				}

				if (bTextFlowBTT) {
					frameRct.top = BrMIN(frameRct.top, nDy);
					frameRct.bottom = BrMAX(frameRct.bottom, nSy);
				}
				else {
					frameRct.top = BrMIN(frameRct.top, nSy);
					frameRct.bottom = BrMAX(frameRct.bottom, nDy);
				}

			}
			else {
				if (bUnderline
#ifdef SUPPORT_HIDDEN_TEXT
						|| (pTextAtt->getHiddenText() && (document->getCmdEngine()->getEditSymbolShowState().bHiddenText || document->getCmdEngine()->IsShowEditSymbol()))
#endif  // SUPPORT_HIDDEN_TEXT
						) {
					if (bUnderline) {
						bUnderline = BrFALSE;

#ifdef SUPPORT_HIDDEN_TEXT
						if (pTextAtt->getUnderline() == BrFALSE && !isHyperLink)
							dwUnderlineColor = RGB_DKGRAY;
#endif  // SUPPORT_HIDDEN_TEXT

						pTextAtt = text_att_h->getTextAtt(pLink->getAttrID());

						DrawSeroUnderlineBitmap(painter, dc, nSx, nSy, nDx, nDy, frameRct, 1, nLineWidth,
						                        dwUnderlineColor, &textAttForUnderline, pFrame, pLine,
						                        nCol, nLineHgt, nMaxDescent, isHyperLink);
					}
				}
			}

			isHyperLink = bSlideHyperLink;

#if defined(USE_HYPERLINK_DRAW_FOR_BWP) || defined(USE_HYPERLINK_TOUCH_FOR_BWP)
			BrBOOL bTextFlowLTR = pFrame->isTextFlowLeftToRight();
			DrawSeroHyperlink(painter, dc, du, pLink, cPosArray, nCol, nBandEnd,
			                  bTextFlowLTR, bTextFlowBTT, sx, sy, nLineSp, sBitmap);
#endif  // USE_HYPERLINK_DRAW_FOR_BWP || USE_HYPERLINK_TOUCH_FOR_BWP

			if (nCol == nCharNum - 1) {
				if (pTextAtt->isSettedTextBorderLineInfo()) {
					if (nStartCharIndexOfTextBorder == -1) {
						if (pLink->isTextLink() &&
								!pLink->isCRLink() &&
								!pLink->isAnchorLink() &&
								cPosArray[nCol] >= nBandStart)
							nStartCharIndexOfTextBorder = nCol;
					}

					if (nStartCharIndexOfTextBorder != -1)
						ProcessDrawTextBorderForSero(painter, dc, du, pFrame, pTextAtt, pLine, nStartCharIndexOfTextBorder, nCol, sx, sy, BrFALSE, bAllSpace);

					nStartCharIndexOfTextBorder = -1;
				}

				nCol++;
				break;
			}

			if (pTextAtt->isSettedTextBorderLineInfo()) {
				BrBOOL bIsTextBorderEnd = BrFALSE;
				BrBOOL bIsBandEnd = BrFALSE;

				if (nStartCharIndexOfTextBorder == -1) {
					if (pLink->isTextLink() &&
					    !pLink->isCRLink() &&
					    !pLink->isAnchorLink() &&
					    cPosArray[nCol] >= nBandStart)
						nStartCharIndexOfTextBorder = nCol;
				}
				// else
				if (nStartCharIndexOfTextBorder != -1) {
					CCharSet* pNextCharset = pLinkArray->getCharSet(nCol + 1);
					const PoTextAtt* nextTextAtt = BrNULL;
					if (pNextCharset != BrNULL) {
						nextTextAtt = text_att_h->getTextAtt(pNextCharset->getAttrID());
						if (BrFALSE == pTextAtt->isEqualTextBorderLineInfo(nextTextAtt->getTextBorderLineInfo()))
							bIsTextBorderEnd = BrTRUE;

						if (pNextCharset->isBreakLink() || pNextCharset->isCRLink() || pNextCharset->isSoftEnterLink() || pNextCharset->isAnchorLink()) {
							bIsTextBorderEnd = BrTRUE;
						}

						if (nBandEnd <= cPosArray[nCol + 1]/*)*/) {
							bIsTextBorderEnd = BrTRUE;
							bIsBandEnd = BrTRUE;
						}

					}
					else {
						bIsTextBorderEnd = BrTRUE;
						bIsBandEnd = BrTRUE;
					}
				}
				if (BrTRUE == bIsTextBorderEnd) {
					ProcessDrawTextBorderForSero(painter, dc, du, pFrame, pTextAtt, pLine, nStartCharIndexOfTextBorder, nCol, sx, sy, bIsBandEnd, bAllSpace);
					nStartCharIndexOfTextBorder = -1;
				}
			}

			if (nBandEnd < cPosArray[nCol + 1]) {
				nCol++;
				break;
			}
		}

		if (bUnderline) {
			bUnderline = BrFALSE;

#ifdef SUPPORT_HIDDEN_TEXT
			if (pTextAtt->getUnderline() == BrFALSE && !isHyperLink)
				dwUnderlineColor = RGB_DKGRAY;
#endif  // SUPPORT_HIDDEN_TEXT

			pTextAtt = text_att_h->getTextAtt(pLink->getAttrID());

			DrawSeroUnderlineBitmap(painter, dc, nSx, nSy, nDx, nDy, frameRct, 1, nLineWidth,
			                        dwUnderlineColor, &textAttForUnderline, pFrame, pLine, nCol,
			                        nLineHgt, nMaxDescent, isHyperLink);
		}

		if (nCol == nCharNum - 1)
			break;
	}
}


void CTextDraw::DrawSeroUnderlineBitmap(Painter* painter, BrDC* dc, BrINT sx, BrINT sy,
                                        BrINT dx, BrINT dy, const BrRect& rect, BrINT nTextLine,
                                        BrINT line_w, COLORREF color, PoTextAtt* text_att,
                                        CFrame* pFrame, CLine* line, BrINT nCol, BrINT line_h,
                                        BrINT nMaxDescent, BrBOOL isHyperLink)
{
	BrGrapAtt* grapAtt = UpdateUnderlineStyle(text_att, isHyperLink, color);

	if (grapAtt && !(grapAtt->getPen()->isNull() && !grapAtt->isPictured() && !grapAtt->isGradient())) {
		if (sy > dy)
			BrSwap(sy, dy);

		BrShapeProxy shape(SHAPE_TextPlainText);
		ConfigUnderlineShape(shape, grapAtt);

		BrBYTE nOldMode = dc->setExportMode(eDirectExtMode);

		BrPoint offset, left_top;// = du.getOffset();
		ConfigUnderlinePoints(offset, left_top, rect);

		DrawUnderline(painter, dc, sx, sy, dx, dy, offset, line_w,
		              line_h, color, text_att, line, shape, BrFALSE);

		BrBYTE textFlow = pFrame? pFrame->getTextFlow(): 0xff;
		BPointArray* polygon = shape.getPolygon();
		/*
		BrINT16 rotatePoint = 0;
		if (textFlow == TEXTFLOW_SERO || textFlow == TEXTFLOW_SERO_90)
			rotatePoint = 270;
		if (textFlow == TEXTFLOW_SERO_270)
			rotatePoint = 90;

		if (rotatePoint > 0) {
			polygon->SetRotatePoints(rotatePoint);

			rect.left -= offset.x;
			rect.top -= offset.y;
			rect.right -= offset.x;
			rect.bottom -= offset.y;

			BrRect tmp = rect;

			rect.left = tmp.top;
			rect.top = tmp.left;
			rect.right = tmp.bottom;
			rect.bottom = tmp.right;

			rect.left += offset.x;
			rect.top += offset.y;
			rect.right += offset.x;
			rect.bottom += offset.y;
		}
		*/

		//polygon->translate(-boundrect.Left()-width, -boundrect.Top()+textAttForStrikeline.getHanFSize()/2-boundrect.getHeight()/2);
		//polygon->translate(rect.left, rect.top);
		polygon->translate(
			CDrawUnit::cvtLogical2DocX(offset.x, painter->m_iResX, painter->getZoomScale()),
			CDrawUnit::cvtLogical2DocY(offset.y, painter->m_iResY, painter->getZoomScale())
		);

		offset = left_top;

		polygon->translate(
			-CDrawUnit::cvtLogical2DocX(offset.x, painter->m_iResX, painter->getZoomScale()),
			-CDrawUnit::cvtLogical2DocY(offset.y, painter->m_iResY, painter->getZoomScale())
		);

		BRect boundrect = polygon->boundingRect();

		BString qStrBuffer(" ");
		BRCHAREFFECTINFO charInfo = {BRect(0,0,0,0), 0,0,0,0,0,0,0,0, 1/* Underline */};
		charInfo.nWidth = twips2DeviceX(boundrect.nRight, painter->getZoomScale(), painter->m_iResX); //dc->m_pFont->getCharBitmapWidth(qStrBuffer.at(0));
		charInfo.rcFrame = line->getFrame()? line->getFrame()->getFrameRect(): BRect(0, 0, 0, 0);
		charInfo.nDescent = nMaxDescent; //dc->m_pFont->getCharDescent();
		charInfo.nCharLineW = BrMAX(charInfo.nDescent * 0.5, 2);
		charInfo.nFontHeight = line_h; //dc->m_pFont->getFontCharHeight();
		charInfo.nHeight = BrABS(rect.top - rect.bottom); //dc->m_pFont->getCharHeight() + charInfo.nDescent;	//[2014. 4. 11] ejjeong. 맑은 고딕 g, j가 잘리는 문제로 여유있게 잡음

		// [JIRA] XRF-3224 Doc과 ppt의 반사효과가 영역이 다르게 잡히는데 그 원인으로 Doc의 문단 계산 방법이 다른 것으로 추정
		// 따라서 Default LineSpace인 1.0으로 계산하여 (Font마다 다름) ppt와의 차이를 보정해 줌.
		// extraHead에 더해지는 값이므로 아래쪽 Bottom Descent 영역 계산에 Side 없다고 보고, 이 값들은 ChunkFillBitmap의 Size에 반영해야 함.
		if (pFrame && !text_att->isWaPolygon()) {
			BrShape* pShape = pFrame->getBorder();
			if (pShape) {
//				const PoParaAtt* paraAtt = theBWordDoc->getParaAttHandler()->getMergedParaAtt(line->getParaID(), line);
//				// word 세로쓰기 고도화 관련. 270도 회전시엔 크기를 늘리지 말자
// 				if (theBWordDoc->isFromDoc() && pFrame->getTextFlow() != TEXTFLOW_SERO_270)
// 				{
// 					BrINT nLineSp = line->getLineSpForMultiple(1.0, paraAtt->isFixLineNum(), (theBWordDoc->isFromDoc()&&paraAtt->getBulletID())?BrFALSE:BrTRUE);
// 					nLineSp = twips2DeviceX(nLineSp, painter->getZoomScale(), painter->m_iResX);
// 					charInfo.nLineSpace = (BrDOUBLE)nLineSp/2;
//				}
			}
		}
		charInfo.nHeightWithExtra = charInfo.nHeight + charInfo.nCHExtraHeight + charInfo.nLineSpace;

		auto pBitmaps = MakeTextEffect(painter, dc, text_att, line, nCol,
		                               qStrBuffer, 0, 0, charInfo, &shape);
		if (pBitmaps) {
			BrShapeBitmap* reflect = pBitmaps->getBitmap(eShapeBitmapType::esDIBSHAPE_Reflect);
			if (reflect) {
				if (textFlow == TEXTFLOW_SERO) {
					BrVector2 btmTwip(0, charInfo.nDescent);
					btmTwip = device2milliTwips(painter, btmTwip);
					if (line->getCharSetArray()->GetSize() > 2)
						reflect->translate_offset.x += btmTwip.y * 1;
					reflect->translate_offset.x += btmTwip.y * 3.3;
				}
				else if (textFlow == TEXTFLOW_SERO_90) {
					BrVector2 btmTwip(0, charInfo.nDescent);
					btmTwip = device2milliTwips(painter, btmTwip);
					if (line->getCharSetArray()->GetSize() > 2)
						reflect->translate_offset.x += btmTwip.y * .7;
				}
				else if (textFlow == TEXTFLOW_SERO_270) {
					BrVector2 btmTwip(0, charInfo.nDescent);
					btmTwip = device2milliTwips(painter, btmTwip);
					if (line->getCharSetArray()->GetSize() > 2)
						reflect->translate_offset.x -= btmTwip.y * .7;
				}
			}
			pBitmaps->draw(dc, offset, painter);
		}
		else {
			DrawNormalUnderline(dc, sx, sy, dx, dy, line_w, color, text_att, line, line_h);
		}

		dc->setExportMode(nOldMode);
		return;
	}

	DrawNormalUnderline(dc, sx, sy, dx, dy, line_w, color, text_att, line, line_h);
}


#if defined(USE_HYPERLINK_DRAW_FOR_BWP) || defined(USE_HYPERLINK_TOUCH_FOR_BWP)
void CTextDraw::DrawSeroHyperlink(Painter* painter, BrDC* dc, CDrawUnit& du, CCharSet* charset,
                                  const CLongArray& cPosArray, BrINT col, BrINT nBandEnd,
                                  BrBOOL bTextFlowLTR, BrBOOL bTextFlowBTT, BrINT sx, BrINT sy,
                                  BrINT nLineSp, PrBitmap& sBitmap)
{
	BYTE sub_type = charset->isFieldLink();
	if (theBWordDoc->getCmdEngine()->isSlideShow() || 0 == sub_type)
		return;

	BrINT y1 = cPosArray[col];
	BrINT y2 = cPosArray[col + 1];
	if (nBandEnd < y2)
		y2 = nBandEnd;

	BRect rcDraw;
	if (bTextFlowLTR) {
		rcDraw.nLeft = sx - nLineSp;
		rcDraw.nRight = sx;
	}
	else {
		rcDraw.nLeft = sx;
		rcDraw.nRight = sx + nLineSp;
	}
	if (bTextFlowBTT) {
		rcDraw.nTop = sy - du.doc2LogicalDX(y2, BrFALSE);
		rcDraw.nBottom = sy - du.doc2LogicalDX(y1, BrFALSE);
	}
	else {
		rcDraw.nTop = sy + du.doc2LogicalDX(y1, BrFALSE);
		rcDraw.nBottom = sy + du.doc2LogicalDX(y2, BrFALSE);
	}

#ifdef USE_HYPERLINK_TOUCH_FOR_BWP
	BrBOOL& is_draw_touched_hyperlink = dynamic_cast<Painter_BWP*>(painter)->m_bDrawTouchedHyperLink;
	if (((sub_type & START_LINK) != 0) && (painter->m_nTouchHyperLinkIndex == charset->getCode()))
		is_draw_touched_hyperlink = BrTRUE;

	if (is_draw_touched_hyperlink) {
		BrBmvBrush brush, * pOldBrush;
		brush.createSolidBrush(RED_COLOR);
		pOldBrush = dc->setBrush(&brush);

		if ((sub_type & START_LINK) != 0)
			dc->fillRect(rcDraw.nLeft, rcDraw.nTop, rcDraw.nRight, rcDraw.nTop + 3);
		if ((sub_type & END_LINK) != 0) {
			dc->fillRect(rcDraw.nLeft, rcDraw.nBottom - 3, rcDraw.nRight, rcDraw.nBottom);
			is_draw_touched_hyperlink = BrFalse;
		}

		dc->fillRect(rcDraw.nLeft, rcDraw.nTop, rcDraw.nLeft + 3, rcDraw.nBottom);
		dc->fillRect(rcDraw.nRight - 3, rcDraw.nTop, rcDraw.nRight, rcDraw.nBottom);
		dc->setBrush(pOldBrush);
	}
#endif  // USE_HYPERLINK_TOUCH_FOR_BWP

#ifdef USE_HYPERLINK_DRAW_FOR_BWP
	if (0 == (sub_type & END_LINK))
		return;

	CFieldHyper* pField = (CFieldHyper*)theBWordDoc->getFieldArray()->getField(charset->getCode());
	if (BrNULL == pField || E_FIELD_HYPER != pField->getFieldType())
		return;

	// 하이퍼링크 아이콘 표시( 우선 목차는 제외 )
	BrINT link_type = pField->getLinkType();
	if (link_type == LINK_TO_URL ||
	    link_type == LINK_TO_EMAIL ||
	    link_type == LINK_TO_FILE ||
	    link_type == LINK_TO_BOOKMARK) {
		BrBYTE alpha = dc->setAlphaValue(0xff);

		BrDOUBLE dip_ratio = 1;
		if (theBWordDoc->getCmdEngine()->m_dDeviceDIP != 0) {
			dip_ratio = theBWordDoc->getCmdEngine()->m_dDeviceDIP / DEFAULT_DEVICE_DIP;
			if (dip_ratio < 1)
				dip_ratio = 1;
		}
		// 하이퍼링크 아이콘 위치 및 크기 변경
		BrINT nIconSize = theBWordDoc->getCmdEngine()->getIconSize(12);
		if (!sBitmap.isHasBitmap()) {
			PrBitmapFlag sFlag;
			sBitmap.loadImagePtr((BrUCHAR*)g_pAppStatic->g_pICO_HYPERLINK_PNG, ICO_HYPERLINK_PNG_NUM,
			                     nIconSize, nIconSize, 0, sFlag, BrNULL);
		}
		if (sBitmap.isHasBitmap())
			dc->stretchBlt(rcDraw.nRight + 2 * dip_ratio, rcDraw.nTop, 14, 14,
			                &sBitmap, 0, 0, sBitmap.cx(), sBitmap.cy(), SRCCOPY);
		dc->setAlphaValue(alpha);
	}
#endif  // USE_HYPERLINK_DRAW_FOR_BWP
}
#endif  // USE_HYPERLINK_DRAW_FOR_BWP || USE_HYPERLINK_TOUCH_FOR_BWP


void CTextDraw::ProcessDrawTextBorderForSero(Painter* painter, BrDC* dc, CDrawUnit& du,
                                             CFrame* pFrame, const PoTextAtt* pTextAtt, CLine* pLine,
                                             BrINT nStartCharCol, BrINT nEndCharCol, BrINT sx, BrINT sy,
                                             BrBOOL bIsBandEnd, BrBOOL bAllSpace)
{
	if (bAllSpace && theBWordDoc->isFromDoc())  // [XPD-16585]워드에서 Space만 있을땐 Border 안 그림.
		return;

	CLongArray& pos_arr = pLine->getPosArray();
	if (nStartCharCol < 0 || pos_arr.size() <= nEndCharCol + 1)
		return;

	BrLONG* pStartPos = pos_arr.GetAt(nStartCharCol);
	BrLONG* pLastPos = pos_arr.GetAt(nEndCharCol + 1);
	const BrINT zoom_scale = painter->getZoomScale();

	BrINT nStartPos = du.doc2LogicalDY((BrINT)*pStartPos, BrFALSE, zoom_scale);
	BrINT nLastPos = du.doc2LogicalDY((BrINT)*pLastPos, BrFALSE, zoom_scale);

	BrINT nLeftLineWidth = 0;
	BrINT nRightLineWidth = 0;
	BrINT nTopLineWidth = 0;
	BrINT nBottomLineWidth = 0;
	CBorderLineInfo* border_info = pTextAtt->getTextBorderLineInfo();
	LogicalBorderWidth(nLeftLineWidth, nRightLineWidth, nTopLineWidth, nBottomLineWidth,
	                   border_info, du, zoom_scale);

	//ZPD-860 //2014-08-27//20hoon //단락의 start Line 과 middle Line의 마지막 글자와 텍스트 테두리가 겹치는 현상 수정
	CCharSet* pCharSet = pLine->getLastLink();
	if (nEndCharCol + 1 == pLine->getCharNum() && pCharSet && pCharSet->isTextLink())
		nLastPos += nBottomLineWidth*2;

	BrINT nLineSp = du.doc2LogicalDY(CTextProc::CalcLineSpace(theBWordDoc, pLine), BrFALSE)/2;

	BrRect rcTextBorderRect;
	if (pFrame->isTextFlowBottomToTop()) {
		rcTextBorderRect.top = sy - nLastPos - nTopLineWidth;
		rcTextBorderRect.bottom = sy - nStartPos;
	}
	else {
		rcTextBorderRect.top = sy + nStartPos - nTopLineWidth;
		rcTextBorderRect.bottom = sy + nLastPos;
	}

	BrINT height = du.doc2LogicalDX(pLine->getHeight(), BrFALSE, zoom_scale);
	if (theBWordDoc->isFromHwp()) {
		rcTextBorderRect.left = sx;
		rcTextBorderRect.right = sx + height;
	}
	else {
		BYTE bTextFlow = pFrame->getTextFlow();
		BrFLOAT ratio = (TEXTFLOW_SERO == bTextFlow)? 0.75: 1;
		rcTextBorderRect.left = sx - nLineSp*ratio;
		rcTextBorderRect.right = sx + height + nLineSp;
	}

	DrawSeroTextBorder(dc, painter, rcTextBorderRect, border_info, du);
}


void CTextDraw::LogicalBorderWidth(BrINT& left, BrINT& right, BrINT& top, BrINT& bottom,
                                   const CBorderLineInfo* border_info,
                                   const CDrawUnit& du, BrINT zoom_scale)
{
	auto CalcHalfWidth = [&](BrINT width) {
		BrINT half_width = du.doc2LogicalDX(width, BrFALSE, zoom_scale) / 2;
		return (0 < half_width)? half_width: 1;  // 20hoon 각 width들이 계산 결과가 0이되는 것을 방지
	};

	if (border_info->isAllBorderSame()) {
		bottom = top = right = left = CalcHalfWidth(border_info->getAllBorderLineStyleWidth());
		return;
	}

	left   = CalcHalfWidth(border_info->getLeftBorderLineStyleWidth());
	right  = CalcHalfWidth(border_info->getRightBorderLineStyleWidth());
	bottom = CalcHalfWidth(border_info->getBottomBorderLineStyleWidth());
	top    = CalcHalfWidth(border_info->getTopBorderLineStyleWidth());
}


void CTextDraw::DrawSeroTextBorder(BrDC* dc, Painter* painter, const BrRect& rect,
                                   CBorderLineInfo* border_info, CDrawUnit& du)
{
	if (BrNULL == border_info)
		return;

	const BrINT zoom_scale = painter->getZoomScale();
	BrLONG left   = rect.left;
	BrLONG right  = rect.right;
	BrLONG top    = rect.top;
	BrLONG bottom = rect.bottom;
	if (BrNULL == border_info->getAllBorderLine()) {
		DrawTextBorder(dc, zoom_scale, border_info, du, left, right, top, bottom);
		return;
	}

	BrBmvPen pen;
	border_info->getPenForAllBorderLineDraw(du, &pen);
	BrINT w = du.doc2LogicalDX(border_info->getAllBorderLineStyleWidth(),BrFALSE, zoom_scale);
	if (0 == w)  // 2014-08-06 20hoon 줌아웃을 너무 하면 너무 얇아서 0으로 나올수도 있다.
		w = 1;
	BrINT hw = w/2;  // half width

	const BrBOOL is_shadow = border_info->isShadowBorderLine();
	if (is_shadow)
		bottom -= w;

	BrBmvBrush brush;
	brush.createNullBrush();

	BrBmvBrush* old_brush = dc->setBrush(&brush);
	BrBmvPen* old_pen = dc->setPen(&pen);

	dc->drawLine(left - w,   top,    right + w,  top);
	dc->drawLine(right + hw, top,    right + hw, bottom);
	dc->drawLine(right + w,  bottom, left - w,   bottom);
	dc->drawLine(left - hw,  bottom, left - hw,  top);

	if (is_shadow) {
		top    += hw;
		bottom += w;
		right  += w*1.5;
		left   += w;

		pen.createPen(BMV_DASHSTYLE_SOLID, w, 0, 0, 0);
		pen.setLineStyle(BMV_LINESTYLE_SIMPLE);
		dc->setPen(&pen);

		dc->drawLine(right,      top,    right,    bottom);
		dc->drawLine(right + hw, bottom, left - w, bottom);
	}

	dc->setPen(old_pen);
	dc->setBrush(old_brush);
}


void CTextDraw::DrawTextBorder(BrDC* dc, BrINT scale, CBorderLineInfo* border_info, CDrawUnit& du,
                               BrLONG left, BrLONG right, BrLONG top, BrLONG bottom)
{
	BrINT w = 0;
	BrBmvPen pen;
	BrBmvPen* old_pen = dc->setPen(&pen);

	CBorderLine* border_left   = border_info->getLeftBorderLine();
	CBorderLine* border_right  = border_info->getRightBorderLine();
	CBorderLine* border_top    = border_info->getTopBorderLine();
	CBorderLine* border_bottom = border_info->getBottomBorderLine();

	if (border_left) {
		w = UpdatePen(border_left, dc, scale, du, pen);
		dc->drawLine(left, bottom, left, top);
	}
	if (border_right) {
		w = UpdatePen(border_right, dc, scale, du, pen);
		dc->drawLine(right, top, right, bottom);
	}
	if (border_top) {
		w = UpdatePen(border_top, dc, scale, du, pen);
		dc->drawLine(left - w/2, top, right + w/2, top);
	}
	if (border_bottom) {
		w = UpdatePen(border_bottom, dc, scale, du, pen);
		dc->drawLine(right + w/2, bottom, left - w/2, bottom);
	}

	if (border_info->isShadowBorderLine()) {
		left   += w;
		right  += w;
		top    += w;
		bottom += w;

		pen.createPen(BMV_DASHSTYLE_SOLID, w, 0, 0, 0);
		pen.setLineStyle(BMV_LINESTYLE_SIMPLE);
		dc->setPen(&pen);

		dc->drawLine(right,       top,    right,      bottom);
		dc->drawLine(right + w/2, bottom, left - w/2, bottom);
	}

	dc->setPen(old_pen);
}


BrINT CTextDraw::UpdatePen(CBorderLine* border, BrDC* dc, BrINT scale, CDrawUnit& du, BrBmvPen& pen)
{
	border->getPenForBorderLineDraw(du, &pen, BrFALSE);
	BrINT width = du.doc2LogicalDX(border->getBorderLineStyleWidth(), BrFALSE, scale);
	dc->setPen(&pen);
	return width;
}


// For Underline & Strikeline
BrINT CTextDraw::CalculateLinePos(BYTE bTextFlow, BrBOOL isSub, BrBOOL isSuper, BrINT sx,
                                  BrINT nLineWid, BrINT nCharWid, BrINT nDescent)
{
	BrINT dx = sx;
	switch (bTextFlow) {
		case TEXTFLOW_GARO_ROTATE: //전자 단어 270도 회전
		{
		}
		break;
		case TEXTFLOW_SERO: //세로
		{
			dx += nLineWid;
			dx += nDescent;
		}
		break;
		case TEXTFLOW_SERO_90: //모든 텍스트 90도 회전
		{
			//아래 첨자의 경우 Line의 중간에 가장 큰 글자의 Top이 위치 & 가장 큰 글자의 중간 맞춤
			if (isSuper || isSub) {
				nCharWid = nCharWid >> 1;
				dx += ((nLineWid >> 1) >> 1) + (nCharWid >> 1); //아래 첨자의 Top = 위 첨자의 Bottom
			}
		}
		break;
		case TEXTFLOW_SERO_270: //모든 텍스트 270도 회전
		{
			//글자의 Top을 Underline 좌표로 설정
			if (isSuper || isSub) {
				nCharWid = nCharWid >> 1;
				dx -= ((nLineWid >> 1) >> 1) + (nCharWid >> 1); //아래 첨자의 Top = 위 첨자의 Bottom
			}
			dx += nLineWid;
			dx -= nDescent;
		}
		break;
		case TEXTFLOW_SERO_RTL: //세로형(오른쪽에서 왼쪽)
		{
			dx += nLineWid;
			dx += nDescent;
		}
		break;
		case TEXTFLOW_SERO_LTR: //세로형(왼쪽에서 오른쪽)
		{
			dx -= nLineWid >> 1; //글자의 Center = 아래 첨자의 Right = 위 첨자의 Left
			if (!isSuper)
				dx -= nCharWid >> 1; //글자의 Left = 아래 첨자의 Left
		}
		break;
	}
	return dx;
}


BrBOOL CTextDraw::ConfigVerticalCharPos(BrINT& y, BrINT& h, BrINT& w, BrINT& font_w, BrINT sy,
                                        const CLongArray& pos_arr, BrINT col, BrINT band_end,
                                        CDrawUnit& du, BoraDoc* document, CFrame* frame,
                                        CCharSet* charset, const PoTextAtt* text_att)
{
	BrINT y1 = pos_arr[col];
	BrINT y2 = pos_arr[col + 1];
	if (band_end < y2)
		y2 = band_end;
	if (y2 <= y1)
		return BrFALSE;

	BrINT dy1 = du.doc2LogicalDY(y1, BrFALSE);
	y = sy + (frame->isTextFlowBottomToTop()? -dy1: dy1);

	h = du.doc2LogicalDY(y2 - y1, BrFALSE) + 1;

	// 세로 쓰기일 때 0도 회전인 글자
	BrINT kor_font_size = text_att->getHanFSize();
	BrWORD uc = charset->getCode();
	if (CTextProc::isExchangeWidthAndHeight(frame->getTextFlow(), uc, text_att)) {
		BrINT width = charset->isTypesetLink()?
		                  CTextProc::getCharSetWidth(document, BrNULL, charset, GARO):
		                  CTextProc::getTextLinkWidth(document, text_att, uc, charset, BrNULL, 0, BrTRUE);
		w = du.doc2LogicalDX(width, BrFALSE);
	}
	else {
		BrINT font_size = charset->isTwoByteCode()? kor_font_size: text_att->getEngFSize();
		w = du.doc2LogicalDY(font_size, BrFALSE);
	}

	font_w = du.doc2LogicalDY(kor_font_size/20, BrFALSE);
	if (font_w < 1)
		font_w = 1;

	return BrTRUE;
}


BrCOLORREF CTextDraw::FindUnderlineColor(BrBOOL is_slide_hyperlink, BrBOOL is_hyper_underline,
                                         const PoTextAtt* text_att, CLine* line)
{
	if (text_att->isSettedUnderlineColor() && BrFALSE == text_att->getUnderLineAutoColor())
		return text_att->getUnderlineColor().getColor();
	else if (is_slide_hyperlink && text_att->getHyperlinkColorType() != PoHyperlinkColorType::PoHyperlinkTextColor)
		return ModifyColorByFrameColorMode(line, theBWordDoc->m_pTheme->getHlinkColor());
	else  {
		BrCOLORREF underlineColor = FindTextAttNLineColor(text_att, line);
		return Painter::ConvertUserConvenienceColor(underlineColor);;
	}
}


void CTextDraw::DrawSeroStrikeline(Painter* painter, BrDC* dc, CDrawUnit& du, BoraDoc* document,
                                   CFrame* pFrame, CLine* pLine, BrINT sx, BrINT sy, BrINT nBandCount)
{
	const BrLONG frame_top = pFrame->top();
	CLongArray& cPosArray = pLine->getPosArray();
	PoTextAttHandler* text_att_h = document->getTextAttHandler();
	BrINT nLineWid = du.doc2LogicalDX(pLine->getAscent(), BrFALSE);
	CCharSetArray* pLinkArray = pLine->getCharSetArray();

#if defined(USE_HYPERLINK_DRAW_FOR_BWP) || defined(USE_HYPERLINK_TOUCH_FOR_BWP)
	BrINT nLineSp = du.doc2LogicalDY(pLine->getAscent(), BrFALSE);
	PrBitmap sBitmap;
#endif  // USE_HYPERLINK_DRAW_FOR_BWP || USE_HYPERLINK_TOUCH_FOR_BWP

	BrINT nCol = 0;

	BrINT32 nStrikeWidth = 1;
	BrBOOL bStrikeline = BrFALSE;
	const PoTextAtt* pTextAttForStrikeline = BrNULL;
	BrINT32 nStrikeSx, nStrikeSy, nStrikeDx, nStrikeDy, dwStrikelineColor, nPrevStrikelineX;
	nStrikeSx = nStrikeSy = nStrikeDx = nStrikeDy = dwStrikelineColor = nPrevStrikelineX = 0;
	BrINT nPrevVerticalPos = 0;

	BrBOOL bShowTextWrap = (BrFALSE == pFrame->isWrapNone() && pLine->isLastSpace());

	BrINT nMaxDescent = CTextProc::getMaxDescentOfCurLine(document, pLine);
	BrINT nLineHgt = du.doc2LogicalDY((pLine->getAnchorFlag())?pLine->getHeightWithoutAnchor():pLine->getAscent(), BrFALSE);

	BYTE bTextFlow = pFrame->getTextFlow();
	BrBOOL bTextFlowBTT = pFrame->isTextFlowBottomToTop();
	BrBOOL isUnderline = BrFALSE, isStrikeOut = BrFALSE;

	BrRect frameRct = {sx, sy, sx, sy};
	BrBOOL isHyperLink = BrFALSE;

	auto& AvailArea = GetAvailAreaMatrix();
	for (BrINT nBand = 0; nBand < nBandCount; nBand++) {
		BrINT nBandStart = AvailArea[nBand][0] - frame_top;
		BrINT nBandEnd = AvailArea[nBand][1] - frame_top;

		if (cPosArray[nCol] > nBandEnd)
			continue;

		BrBOOL bFoundFirstSpace = BrFALSE;
		BrINT nCharNum = FindUnderlineTrailSpaceStopPos(pLinkArray);

		for (; nCol < nCharNum; nCol++) {
			CCharSet* pLink = pLinkArray->getCharSet(nCol);

			BrWORD wCode = pLink->getCode();
			if ((pLink->isTextLink() && !CTextProc::isCRCode(wCode)) || pLink->isTypesetLink() != 0) {
#ifdef PPT_EDITOR
				if (document->getBWPEngineMode() == EDITOR_PPT && wCode == ASCII_CODE_SPACE &&
				    bShowTextWrap && pLine->getSpaceStatus() <= nCol)
					break;
#endif  // PPT_EDITOR

				const PoTextAtt* pTextAtt = text_att_h->getTextAtt(pLink->getAttrID());
				isUnderline = pTextAtt->getUnderline();
				isStrikeOut = pTextAtt->getStrikeout() || pTextAtt->getDStrikeout();

				BrBOOL bSlideHyperLink = pLink->isFieldLink() && document->isFromSlideType() && IsHyperlinkColorNode(document, pLine, nCol);

				if (isUnderline || isStrikeOut) {
					BrINT dx = sx;
					BrINT dy, nOneHeight, nOneWidth, nWidth;
					BrBOOL is_config = ConfigVerticalCharPos(dy, nOneHeight, nOneWidth, nWidth, sy,
					                                         cPosArray, nCol, nBandEnd,
					                                         du, document, pFrame, pLink, pTextAtt);
					if (is_config) {
						BrCOLORREF dwColor = FindStrikelineColor(bSlideHyperLink, pTextAtt, pLine);

						BrINT curDescent = LineOneDescent(theBWordDoc, pLine, nCol);
						dx = CalculateLinePos(bTextFlow, pTextAtt->getSubscript(), pTextAtt->getSuperscript(), dx, nLineWid, nOneWidth, bTextFlow == TEXTFLOW_SERO? nMaxDescent: curDescent);

						if (pTextAtt->getSuperscript() || pTextAtt->getSubscript())
							nOneWidth = (BrINT)(nOneWidth * 0.55);

//					// Field Node이면 Underline을 처리해 준다.
//					if ( pLink->isFieldLink() )	{
//						if (!pLink->isMemoLink())
//						{
//							if(document->isFromSlideType())
//								CCUtil::drawLine(dc, dx, dy, dx, dy+nOneHeight, nWidth, (hlink_color==RGB_BLACK)?HYPER_LINK_COLOR:hlink_color);
//						}
//					}

						if (isStrikeOut) {
							if (bTextFlow == TEXTFLOW_SERO_RTL || bTextFlow == TEXTFLOW_SERO_LTR) //Underline(글자의 오른쪽&세로)
							{
								if (document->isFromHwp() && bTextFlow == TEXTFLOW_SERO_RTL) {
									dx -= g_pAppStatic->m_pFont->getCharDescent();
									dx -= (nLineWid >> 1);	//nOneWidth는 영문글자 마자 달라 nLineWid 사용.
								}
								else	//세로형
								{
									dx -= BrINT32(nOneWidth * 0.6);
									//dy += (nOneHeight>>1);
								}
							}
							else //Underline(글자의 오른쪽&세로), Strikeout(글자의 아래&가로)
							{
								if (bTextFlow == TEXTFLOW_SERO_270)		//ZPD-5111 270도 회전에서 취소선 위치 보정.
								{
									dx += g_pAppStatic->m_pFont->getCharDescent() / 2;
								}
								else {
									if (document->isFromHwp())
										dx -= g_pAppStatic->m_pFont->getCharDescent();
									else
										dx -= g_pAppStatic->m_pFont->getCharDescent() / 2;
								}

								if (bTextFlow == TEXTFLOW_SERO_90) //Underline(글자의 왼쪽&세로)
								{
									dx += BrINT32(nOneWidth * 0.4);
								}
								else //Underline(글자의 오른쪽&세로)
								{
									BrINT32 nOffset = 0;
									if (bTextFlow == TEXTFLOW_SERO)
										nOffset = nLineHgt * 0.6;
									else if (bTextFlow == TEXTFLOW_SERO_270)
										nOffset = BrINT32(nOneWidth * 0.5);
									else
										nOffset = BrINT32(nOneWidth * 0.6);

									if (pTextAtt->getSubscript())
										dx -= (nLineWid >> 1) + nOffset;
									else
										dx -= nOffset;
								}
							}

							BrINT verticalPos = pTextAtt->getTextVerticalPos();
							if (pTextAtt->isSettedTextVerticalPos()) {
								switch (bTextFlow) {
									case TEXTFLOW_SERO_270:
										dx -= du.doc2LogicalDX(verticalPos, BrFALSE);
										break;
									case TEXTFLOW_SERO:
									case TEXTFLOW_SERO_90:
									default:
										dx += du.doc2LogicalDX(verticalPos, BrFALSE);
										break;
								}
							}

							if (bStrikeline) {
								//라인의 두께가 다르면 그려준다.
								if ((nStrikeWidth != nWidth) || (nPrevStrikelineX != dx) || (nPrevVerticalPos != verticalPos)
								    || (pTextAtt->getStrikeout() ^ pTextAttForStrikeline->getStrikeout()) || (pTextAtt->getDStrikeout() ^ pTextAttForStrikeline->getDStrikeout())
								    || (pTextAtt->getStrikeStyle() != pTextAttForStrikeline->getStrikeStyle()))	//ZPD-26603 선종류 다르면
								{
									bStrikeline = BrFALSE;

									//BrRect frameRct = {sx, nStrikeSy , sx + nOneWidth, nStrikeDy};
									//BrRect frameRct = {nStrikeSx, sy-(nMaxDescent + nOneHeight) ,nStrikeDx, dy};
									DrawStrikethrough(painter, dc, du, pFrame, pLine, nStrikeSx, nStrikeSy,
									                  nStrikeDx, nStrikeDy, nStrikeWidth, dwStrikelineColor,
									                  pTextAttForStrikeline, frameRct, nLineHgt, isHyperLink);
								}
								else {
									BrGrapAtt* grapAtt = pTextAtt->isSettedGrapAtt()? pTextAtt->getGrapAtt(): BrNULL;
									BrGrapAtt* grapAttForStrikeline = pTextAttForStrikeline->isSettedGrapAtt()? pTextAttForStrikeline->getGrapAtt(): BrNULL;

									if ((dwColor != dwStrikelineColor && document->isFromWordType()) 	//ZPD-23894 글자 색이 바뀌면 취소선 색도 바뀜.
									    || ((grapAtt && !grapAttForStrikeline) || (!grapAtt && grapAttForStrikeline))
									    || (!pTextAtt->equalWordArtStyle(pTextAttForStrikeline) && (isHyperLink || (grapAtt && grapAtt->isGradient()) || (grapAttForStrikeline && grapAttForStrikeline->isGradient())))
									    || (!pTextAtt->hasEqualShadowAtt(pTextAttForStrikeline))
									    || bSlideHyperLink != isHyperLink) {
										bStrikeline = BrFALSE;
										DrawStrikethrough(painter, dc, du, pFrame, pLine, nStrikeSx, nStrikeSy,
										                  nStrikeDx, nStrikeDy, nStrikeWidth, dwStrikelineColor,
										                  pTextAttForStrikeline, frameRct, nLineHgt, isHyperLink);
									}
								}
							}

							if (bStrikeline) {
								if (bTextFlowBTT)
									nStrikeDy = dy - nOneHeight;
								else
									nStrikeDy = dy + nOneHeight;
							}
							else {
								bStrikeline = BrTRUE;
								pTextAttForStrikeline = pTextAtt;

								dwStrikelineColor = FixStrikethroughColor(document->isFromSlideType(), document, pLine,
								                                          nCol, pTextAtt, dwColor, painter, pFrame);
#ifdef SUPPORT_LOW_VISION_SHAPE
								if (theBWordDoc && theBWordDoc->m_pLowVisionColorModeEngine)
									dwColor = theBWordDoc->m_pLowVisionColorModeEngine->GetTextColor();
#endif  // SUPPORT_LOW_VISION_SHAPE

								nStrikeSx = nStrikeDx = nPrevStrikelineX = dx;
								nStrikeSy = dy;
								nPrevVerticalPos = verticalPos;
								nStrikeWidth = nWidth;

								// 270 회전 Text의 취소선 오류 수정
								if (bTextFlowBTT) {
									nStrikeDy = dy - nOneHeight;
									frameRct.top = nStrikeSy;
									frameRct.bottom = nStrikeDy;
								}
								else {
									nStrikeDy = dy + nOneHeight;
									frameRct.top = nStrikeDy;
									frameRct.bottom = nStrikeSy;
								}

								frameRct.left = BrMIN(frameRct.left, sx);
								frameRct.right = BrMAX(frameRct.right, dx);
							}
						}

						if (bTextFlowBTT) {
							frameRct.top = BrMIN(frameRct.top, nStrikeDy);
							frameRct.bottom = BrMAX(frameRct.bottom, nStrikeSy);
						}
						else {
							frameRct.top = BrMIN(frameRct.top, nStrikeSy);
							frameRct.bottom = BrMAX(frameRct.bottom, nStrikeDy);
						}
					}
				}
				else {
					if (bStrikeline
#ifdef SUPPORT_HIDDEN_TEXT
							|| (pTextAtt->getHiddenText() && (document->getCmdEngine()->getEditSymbolShowState().bHiddenText || document->getCmdEngine()->IsShowEditSymbol()))
#endif  // SUPPORT_HIDDEN_TEXT
					) {
						if (bStrikeline) {
							bStrikeline = BrFALSE;
							DrawStrikethrough(painter, dc, du, pFrame, pLine, nStrikeSx, nStrikeSy,
							                  nStrikeDx, nStrikeDy, nStrikeWidth, dwStrikelineColor,
							                  pTextAttForStrikeline, frameRct, nLineHgt, isHyperLink);
						}
					}
				}

				isHyperLink = bSlideHyperLink;
			}

#if defined(USE_HYPERLINK_DRAW_FOR_BWP) || defined(USE_HYPERLINK_TOUCH_FOR_BWP)
			BrBOOL bTextFlowLTR = pFrame->isTextFlowLeftToRight();
			DrawSeroHyperlink(painter, dc, du, pLink, cPosArray, nCol, nBandEnd,
			                  bTextFlowLTR, bTextFlowBTT, sx, sy, nLineSp, sBitmap);
#endif  // USE_HYPERLINK_DRAW_FOR_BWP || USE_HYPERLINK_TOUCH_FOR_BWP

			if (nCol == nCharNum - 1)
				break;

			if (nBandEnd < cPosArray[nCol + 1]) {
				nCol++;
				break;
			}
		}

		if (bStrikeline) {
			bStrikeline = BrFALSE;
			DrawStrikethrough(painter, dc, du, pFrame, pLine, nStrikeSx, nStrikeSy,
			                  nStrikeDx, nStrikeDy, nStrikeWidth, dwStrikelineColor,
			                  pTextAttForStrikeline, frameRct, nLineHgt, isHyperLink);
		}

		if (nCol == nCharNum - 1)
			break;
	}
}


void CTextDraw::DrawStrikethrough(Painter* painter, BrDC* dc, const CDrawUnit& du, CFrame* frame,
                                  CLine* line, BrINT sx, BrINT sy, BrINT dx, BrINT dy,
                                  BrINT width, BrINT color, const PoTextAtt* text_att,
                                  const BrRect& frame_rect, BrINT line_height, BrBOOL is_hyper)
{
	if (BrNULL == text_att)
		return;

	BoraDoc* document = theBWordDoc;
	if (document->isFromHwp()) {
		BrBYTE strike_style = text_att->getStrikeStyle();
		CCUtil::drawUnderLine(dc, sx, sy, dx, dy, width, color, strike_style);
		return;
	}

	PoTextAtt hyper_text_att(*text_att);
	BrGrapAtt* grap_att = hyper_text_att.getGrapAtt();
	if (is_hyper) {
		BrCOLORREF hyper_color = document->m_pTheme->getHlinkColor();
		CFrame* line_frame = line? line->getFrame(): BrNULL;
		BrINT gray_mode = document->GetGrayMode();
		if (line_frame && GRAY_MODE_COLOR != gray_mode) {
			BrColorMode color_mode = frame->getFrameColorMode();
			hyper_color = BrColor::getBwColor(gray_mode, color_mode, hyper_color, GRAY_MODE_APPLY_TEXT);
		}
		if (grap_att)
			grap_att->resetBrush();
		hyper_text_att.setTextColor(hyper_color);
		text_att = &hyper_text_att;
	}

	if (grap_att) {
		DrawEffectStrikethrough(painter, dc, frame, *grap_att, line, sx, sy, dx, dy,
		                        width, color, text_att, frame_rect, line_height);
		return;
	}

	BrBOOL is_brighten_hf = frame && frame->isBrightenColor4HeaderFooter();
	BrINT zoom_scale = painter->getZoomScale();
	DrawNormalStrikethrough(dc, is_brighten_hf, color, text_att, width, zoom_scale, sx, sy, dx, dy);
}


void CTextDraw::DrawEffectStrikethrough(Painter* painter, BrDC* dc, CFrame* frame, BrGrapAtt& grap_att,
                                        CLine* line, BrINT sx, BrINT sy, BrINT dx, BrINT dy,
                                        BrINT width, BrINT color, const PoTextAtt* text_att,
                                        const BrRect& frame_rect, BrINT line_height)
{
	BrPoint offset;
	offset.x = (frame_rect.left + frame_rect.right)/2;
	offset.y = (frame_rect.top + frame_rect.bottom)/2;

	BrShapeProxy shape(SHAPE_TextPlainText);
	shape.setOffice2007Shape(BrTRUE);
	shape.copy(grap_att);

	shape.createFreeFormShapeAttrs();
	BArray<BrShapeSegment>& segments = shape.getFreeFormShapeAttrs()->aSegments;

	shape.createPolygon();
	BPointArray* pt_arr = shape.getPolygon();
	pt_arr->resize(0);

	//Image 채우기인 경우 ImageInfo를 세팅한다.
	if (grap_att.isFillImage())
		shape.setImageInfo(theBWordDoc->getImageArray());

	dc->setNeedOutline(pt_arr, &segments, offset);
	BrBOOL is_brighten_hf = frame && frame->isBrightenColor4HeaderFooter();
	BrINT zoom_scale = painter->getZoomScale();
	DrawNormalStrikethrough(dc, is_brighten_hf, color, text_att, width, zoom_scale, sx, sy, dx, dy);
	dc->setNeedOutline(BrNULL, BrNULL, offset);

	BrINT res_x = painter->m_iResX;
	BrINT res_y = painter->m_iResY;

	pt_arr->translate(CDrawUnit::cvtLogical2DocX(offset.x, res_x, zoom_scale),
	                  CDrawUnit::cvtLogical2DocY(offset.y, res_y, zoom_scale));

	offset.x = frame_rect.left;
	offset.y = frame_rect.top;
	pt_arr->translate(-CDrawUnit::cvtLogical2DocX(offset.x, res_x, zoom_scale),
	                  -CDrawUnit::cvtLogical2DocY(offset.y, res_y, zoom_scale));

	BRect bound_rect = pt_arr->boundingRect();
	CFrame* line_frame = line? line->getFrame(): BrNULL;
	BrINT descent = CTextProc::getMaxDescentOfCurLine(theBWordDoc, line);

	BRCHAREFFECTINFO info = {};
	info.rcFrame = line_frame? line_frame->getFrameRect(): BRect(0, 0, 0, 0);
	info.nWidth = twips2DeviceX(bound_rect.nRight, zoom_scale, res_x);
	//[2014. 4. 11] ejjeong. 맑은 고딕 g, j가 잘리는 문제로 여유있게 잡음
	//info.nHeight = dc->m_pFont->getCharHeight() + descent;
	info.nHeight = BrABS(frame_rect.top - frame_rect.bottom);
	info.nDescent = descent;
	info.nCharLineW = BrMAX(descent*0.5, 2);
	info.nCHExtraHeight = line_height*0.15;
	info.nFontHeight = line_height;
	info.nTextLine = 2;  // Strike-out

	// [JIRA] XRF-3224 Doc과 ppt의 반사효과가 영역이 다르게 잡히는데
	// 그 원인으로 Doc의 문단 계산 방법이 다른 것으로 추정
	// 따라서 Default LineSpace인 1.0으로 계산하여 (Font마다 다름) ppt와의 차이를 보정해 줌.
	// extraHead에 더해지는 값이므로 아래쪽 Bottom Descent 영역 계산에 Side 없다고 보고,
	// 이 값들은 ChunkFillBitmap의 Size에 반영해야 함.
	//if (frame && !text_att->isWaPolygon()) {
	//	BrShape* pShape = frame->getBorder();
	//	if (pShape) {
	//		//					const PoParaAtt* paraAtt = theBWordDoc->getParaAttHandler()->getMergedParaAtt(line->getParaID(), line);
	//		//					// word 세로쓰기 고도화 관련. 270도 회전시엔 크기를 늘리지 말자
	//		// 					if(theBWordDoc->isFromDoc() && frame->getTextFlow() != TEXTFLOW_SERO_270)
	//		// 					{
	//		// 						BrINT nLineSp = line->getLineSpForMultiple(1.0, paraAtt->isFixLineNum(), (theBWordDoc->isFromDoc()&&paraAtt->getBulletID())?BrFALSE:BrTRUE);
	//		// 						nLineSp = twips2DeviceX(nLineSp, zoom_scale, res_x);
	//		// 						info.nLineSpace = (BrDOUBLE)nLineSp/2;
	//		// 					}
	//	}
	//}
	info.nHeightWithExtra = info.nHeight + info.nCHExtraHeight + info.nLineSpace;

	BString buf(" ");
	auto effect = MakeTextEffect(painter, dc, text_att, line, 0, buf, 0, 0, info, &shape);
	if (BrNULL == effect) {
		DrawNormalStrikethrough(dc, is_brighten_hf, color, text_att, width, zoom_scale, sx, sy, dx, dy);
		return;
	}

	BrShapeBitmap* reflect = effect->getBitmap(eShapeBitmapType::esDIBSHAPE_Reflect);
	if (BrNULL == reflect) {
		effect->draw(dc, offset, painter);
		return;
	}

	BrBYTE text_flow = frame? frame->getTextFlow(): 0xFF;
	switch (text_flow) {
		case TEXTFLOW_SERO: {
			BrVector2 btm_twip(0, descent);
			btm_twip = device2milliTwips(painter, btm_twip);
			auto& reflect_x = reflect->translate_offset.x;
			if (line && 2 < line->GetCharSetArrSize())
				reflect_x += btm_twip.y;
			reflect_x += btm_twip.y * 3.3;
			break;
		}
		case TEXTFLOW_SERO_90:  FALLTHROUGH;
		case TEXTFLOW_SERO_270: {
			BrVector2 btm_twip(0, descent);
			btm_twip = device2milliTwips(painter, btm_twip);
			if (line && 2 < line->GetCharSetArrSize())
				reflect->translate_offset.x -= btm_twip.y * 0.7;
			break;
		}
	}
	effect->draw(dc, offset, painter);
}

void CTextDraw::DrawNormalStrikethrough(BrDC* dc, BrBOOL is_brighten_hf, BrCOLORREF color,
                                        const PoTextAtt* text_att, BrINT width, BrINT zoom_scale,
                                        BrINT sx, BrINT sy, BrINT dx, BrINT dy)
{
	BrBmvPen* old_pen = dc->getPen();

	if (is_brighten_hf)
		color = static_cast<BrCOLORREF>(BrUtil::BrightenColor(color));

	BrBmvPen pen;
	if (text_att->getStrikeout()) {
		pen.createPen(BMV_DASHSTYLE_SOLID, width, color);
		pen.setLineStyle(BMV_LINESTYLE_SIMPLE);
	}
	else if (text_att->getDStrikeout()) {
		pen.createPen(BMV_DASHSTYLE_SOLID, width*3, color);
		pen.setLineStyle(BMV_LINESTYLE_DOUBLE);
	}
	pen.setScaleFact(zoom_scale);

	dc->setPen(&pen);
	dc->drawLine(sx, sy, dx, dy);
	dc->setPen(old_pen);
}


BrCOLORREF CTextDraw::FindStrikelineColor(BrBOOL is_slide_hyperlink,
                                          const PoTextAtt* text_att, CLine* line)
{
	if (is_slide_hyperlink) {
		BrCOLORREF hyperlink_color = theBWordDoc->m_pTheme->getHlinkColor();
		return ModifyColorByFrameColorMode(line, hyperlink_color);
	}

	return FindTextAttNLineColor(text_att, line);
}

BrCOLORREF CTextDraw::ModifyColorByFrameColorMode(CLine * line, BrCOLORREF originalColor)
{
	CFrame* frame = line? line->getFrame(): BrNULL;
	BrINT gray_mode = theBWordDoc->GetGrayMode();
	if (frame == BrNULL || gray_mode == GRAY_MODE_COLOR)
		return originalColor;

	return BrColor::getBwColor(gray_mode, frame->getFrameColorMode(), originalColor, GRAY_MODE_APPLY_TEXT);
}

BrCOLORREF CTextDraw::ModifyColorByFrameColorMode(CFrame * frame, BrCOLORREF originalColor)
{
	BrINT gray_mode = theBWordDoc->GetGrayMode();
	if (frame == BrNULL || gray_mode == GRAY_MODE_COLOR)
		return originalColor;

	return BrColor::getBwColor(gray_mode, frame->getFrameColorMode(), originalColor, GRAY_MODE_APPLY_TEXT);
}

BrCOLORREF CTextDraw::FindTextAttNLineColor(const PoTextAtt* text_att, CLine* line)
{
	if (text_att->getAutoColor()) {
		CFrame* frame = line->getFrame();
		BrColor* font_color = frame? ShapeQuickStyleTextAutoColor(frame): BrNULL;
		return AutoTextColor(line, text_att, font_color);
	}

	if (text_att->isSettedStrikeColor() && getDocType() == BORA_DOCTYPE_HWP)
		return text_att->getStrikeColor();

	BrGrapAtt* grap_att = text_att->getGrapAtt();
	if (grap_att)
		return grap_att->getBrushColor();

	return text_att->getReverse()? text_att->getBackColor().getColor():
	                               text_att->getTextColor().getColor();
}


BrCOLORREF CTextDraw::FixStrikethroughColor(BrBOOL is_field, BoraDoc* document, CLine* line, BrINT col,
                                            const PoTextAtt* text_att, BrCOLORREF strikeout_color,
                                            Painter* painter, CFrame* frame)
{
	BrCOLORREF color;
	if (is_field && document->isFromSlideType() && IsHyperlinkColorNode(document, line, col)) {
		color = document->m_pTheme->getHlinkColor();
	}
	else {
		color = text_att->getStrikeColor();
		if (NONE_COLOR_BITS == color)
			color = strikeout_color;
	}

#ifdef REMOVE_HYPER_LINK_ATTRIBUTE
	if (IsRemoveHyperlinkAttr(painter, text_att))
		color = BLACK_COLOR;
#endif  // REMOVE_HYPER_LINK_ATTRIBUTE

	BrINT gray_mode = document->GetGrayMode();
	if (GRAY_MODE_COLOR == gray_mode)
		return color;
	return BrColor::getBwColor(gray_mode, frame->getFrameColorMode(), color, GRAY_MODE_APPLY_TEXT);
}


//ZPD-2946
//20hoon //2014-10-20
//수직 막대가 Align인 Custom Tab 을 그린다
void CTextDraw::DrawParaTabVerticalBar(Painter* painter, BrDC* dc, CDrawUnit& du, CLine* pLine,
                                       BrINT nSxOfLine, BrINT nSyOfLine, BrBOOL bIsTextFlowHorizontal)
{
	if (painter == BrNULL || dc == BrNULL || pLine == BrNULL)
		return;

	BrINT nSy = 0;
	BrINT nEy = 0;
	BrINT nSx = 0;
	BrINT nEx = 0;


	BrBmvPen pen, * pOldPen = BrNULL;
	pen.createPen(BMV_DASHSTYLE_SOLID, 1, 0, 0, 0);
	pen.setLineStyle(BMV_LINESTYLE_SIMPLE);

	pOldPen = dc->setPen(&pen);

	PoParaAttHandler* para_att_h = theBWordDoc->getParaAttHandler();
	if (para_att_h != BrNULL) {
		const PoParaAtt* pObjParaAtt = para_att_h->getMergedParaAtt(pLine->getParaID(), pLine);
		if (pObjParaAtt->isSettedParaTabID()) {
			const PO_PARAATT_TAB::PoParaTab* paraTab = para_att_h->getParaTabArray()->getParaTab(pObjParaAtt->getParaTabID());
			if (paraTab && !paraTab->isEmpty()) {
				for (PO_PARAATT_TAB::tabItemIterator iter = paraTab->begin(); iter != paraTab->end(); ++iter) {
					//세로막대만 그린다 .
					if (iter->second.first == kVLine) {
						BRect rcRect;
						CTextProc::getMarkingArea(theBWordDoc, pLine->getFrame(), pLine, 0, 0, rcRect);

						if (bIsTextFlowHorizontal) //가로 쓰기
						{
							nSy = du.doc2LogicalDY(rcRect.nTop, BrTRUE, painter->getZoomScale());
							nEy = du.doc2LogicalDY(rcRect.nBottom, BrTRUE, painter->getZoomScale());
						}
						else //세로쓰기
						{
							nSx = du.doc2LogicalDX(rcRect.nLeft, BrTRUE, painter->getZoomScale());
							nEx = du.doc2LogicalDX(rcRect.nRight, BrTRUE, painter->getZoomScale());
						}


						//아래 모두 Twip
						if (bIsTextFlowHorizontal) //가로 쓰기
						{
							nSx = nEx = nSxOfLine + du.doc2LogicalDX(iter->first, BrFALSE, painter->getZoomScale());
							//nSxOfLine값이 FrameRect Left 값이므로, Line의 PosArray.at(0)값만큼 증가시켜야함.
							nSx = nEx += du.doc2LogicalDX(pLine->getPosArray().at(0), BrFALSE, painter->getZoomScale());
						}
						else //세로쓰기
						{
							nSy = nEy = nSyOfLine + du.doc2LogicalDY(iter->first, BrFALSE, painter->getZoomScale());
						}

						dc->drawLine(nSx, nSy, nEx, nEy);
					}
				}
			}
		}
	}

	dc->setPen(pOldPen);
}


void CTextDraw::DrawForegroundOfSeroOneLine(Painter* painter, BrDC* dc, CDrawUnit& du, CFrame* pFrame,
                                            CLine* pLine, BrINT sx, BrINT sy, BrINT nBandCount)
{
	BoraDoc* document = theBWordDoc;
	if (document == BrNULL || pFrame == BrNULL || pLine == BrNULL)
		return;

	BRect* lprcFrame = pFrame->getFrameRect();
	CLongArray& cPosArray = pLine->getPosArray();
	PoTextAttHandler* text_att_h = document->getTextAttHandler();
	if (!text_att_h) {
		return;
	}
	// Memo Icon Draw
	if (isExportMode() ||
	    (document->isMemoModeFrame() == BrFALSE && document->isMemoModeSimple() == BrFALSE &&
	      (document->getBWPEngineMode() == EDITOR_WORD && document->isShowMemo() && (document->getCmdEngine()->m_bBwpDrawForeground & TEXT_MEMO_ICON_FOREGROUND)))
	) {
		if (!g_pAppStatic->isPrtPreview() && !document->getCmdEngine()->isSlideShow() && !document->getCmdEngine()->isSkipDecoIcon()) {
			//--- get current line's character node position array

			CCharSetArray* pLinkArray;
			CCharSet* pNode;

			BrINT nBandStart, nBandEnd;
			BrINT wCharNum;

			//--- processing one line.
			pLinkArray = pLine->getCharSetArray();
			if (!pLinkArray || pLinkArray->GetSize() == 0)
				return;
			wCharNum = pLinkArray->GetSize();
			if (cPosArray.size() < wCharNum + 1)
				return;

			//--- Bands loop ---------------------------------------------
			BrINT y1 = 0;
			BrINT nCol = 0;
			BrINT nLineSp = du.doc2LogicalDY(pLine->getAscent(), BrFALSE);

			BYTE bTextFlow = pFrame->getTextFlow();
			BrBOOL bTextFlowLTR = pFrame->isTextFlowLeftToRight();
			BrBOOL bTextFlowBTT = pFrame->isTextFlowBottomToTop();
			auto& AvailArea = GetAvailAreaMatrix();
			for (BrINT nBand = 0; nBand < nBandCount; nBand++) {
				nBandStart = AvailArea[nBand][0] - lprcFrame->nTop;
				nBandEnd = AvailArea[nBand][1] - lprcFrame->nTop;

				if (cPosArray[nCol] > nBandEnd)
					continue;

				for (; nCol < wCharNum; nCol++) {
					pNode = pLinkArray->getCharSet(nCol);

					if (pNode && pNode->isMemoEndLink()
							//[ZPD-988][2014.8.26] 현재 메모에서만 메모 아이콘 그리던 부분 제거
							&& (document->getRevisionEngine()->isShowMemo())) {

						y1 = cPosArray[nCol];

						BPoint pt;
						if (bTextFlowLTR)
							pt.x = sx;
						else
							pt.x = sx + nLineSp;
						if (bTextFlowBTT)
							pt.y = sy - du.doc2LogicalDX(y1, BrFALSE);
						else
							pt.y = sy + du.doc2LogicalDX(y1, BrFALSE);

						BrDOUBLE dip_ratio = 1;
						if (document->getCmdEngine()->m_dDeviceDIP != 0) {
							dip_ratio = document->getCmdEngine()->m_dDeviceDIP / DEFAULT_DEVICE_DIP;
							if (dip_ratio < 1)
								dip_ratio = 1;
						}

						BrINT iconSize = g_pAppStatic->m_nMemoIconDrawSize;
						if (iconSize < 10 && iconSize > 1000)//아주 작은 경우는 배제
							iconSize = 18;

						if (document->getCmdEngine()->isCurOperation(ACTMAKETHUMBNAIL))
							iconSize = document->getCmdEngine()->getIconSize(iconSize);

						PrBitmap sBitmap;
						if (!sBitmap.isHasBitmap()) {
							PrBitmapFlag sFlag;
							sBitmap.loadImagePtr((void*)g_pAppStatic->m_pICO_MEMO_PNG_SLIDE_NORMAL, ICO_MEMO_PNG_NUM_SLIDE_NORMAL, 18, 18, 0, sFlag, BrNULL);
						}

						if (sBitmap.isHasBitmap()) {
							BSize draw_size(iconSize * dip_ratio, iconSize * dip_ratio);

							BrINT nAlpha = dc->setAlphaValue(0xff);
							dc->stretchBlt(pt.x - 8 * dip_ratio, pt.y - 8 * dip_ratio, draw_size.cx, draw_size.cy, &sBitmap, 0, 0, sBitmap.cx(), sBitmap.cy(), SRCCOPY);
							dc->setAlphaValue(nAlpha);
						}
					}

					if (nCol == wCharNum - 1)
						break;

					//--- splited by run around line_frame,
					//    break CHARNODE LOOP for next CHARNODE in next BAND
					if (nBandEnd < cPosArray[nCol + 1]) {
						nCol++;
						break;
					}
				}

				if (nCol == wCharNum - 1)
					break;
			}
		}
	}
	// End of Memo Icon Draw

	DrawVerticalTextDecoration(painter, dc, du, pFrame, pLine, sx, sy, nBandCount);

#ifdef _SPELLCHECKER
	//-------------------------------------------------------------------------
	// draw run-time spell check error text.
	// 밑줄쫙 : 빨간 물결선
	//-------------------------------------------------------------------------
	if (document->isSpellCheckMode() && (document->getCmdEngine()->m_bBwpDrawForeground & TEXT_WRONG_SPELL) && !document->getCmdEngine()->isSkipSpellCheck()) {
		const PoTextAtt* pTextAtt = BrNULL;
		CCharSetArray* pLinkArray;
		CCharSet* pNode;
		BrINT    lBandStart, lBandEnd;
		BrINT    lOneHgt;            // logical
		BrINT    dx, dy;     // display position. device logical
		BrINT    y1, y2;
		BrINT    wCol, wCharNum;
		BrWORD    wCode;

		PoTextAttHandler* text_att_h = document->getTextAttHandler();
		if (!text_att_h)
			return;

		//--- processing one line.
		pLinkArray = pLine->getCharSetArray();
		if (!pLinkArray || pLinkArray->GetSize() == 0)
			return;
		wCharNum = pLinkArray->GetSize();
		if (cPosArray.size() < wCharNum + 1)
			return;

		//--- Bands loop ---------------------------------------------
		pNode = pLinkArray->getCharSet(0);
		wCol = 0;
		auto& AvailArea = GetAvailAreaMatrix();
		for (BrINT nBand = 0; nBand < nBandCount; nBand++) {
			lBandStart = AvailArea[nBand][0] - lprcFrame->nTop;
			lBandEnd = AvailArea[nBand][1] - lprcFrame->nTop;

			if (cPosArray[wCol] > lBandEnd)
				continue;   // can't put in this band

			//--- character node loop ---------------------------------------------
			for (; wCol < wCharNum; wCol++) {
				// ASSERT (pNode);
				//--- General Character Node
				if (pNode) {
					wCode = pNode->getCode();
					if ((pNode->isTextLink() && !CTextProc::isCRCode(wCode))) {
						pTextAtt = text_att_h->getTextAtt(pNode->getAttrID());
						// ASSERT(text_att);
						if (wCode != ASCII_CODE_SPACE && /*document->m_bCheckSpellFlag &&*/ pNode->getWrongSpell()) {
							y1 = cPosArray[wCol];
							y2 = cPosArray[wCol + 1];
							if (y2 > lBandEnd)
								y2 = lBandEnd;
							if (y2 > y1) {
								lOneHgt = du.doc2LogicalY(y2 - y1, BrFALSE) + 1;
								BrBOOL bTextFlowBTT = pFrame->isTextFlowBottomToTop();
								if (bTextFlowBTT) {
									BYTE bTextFlow = pFrame->getTextFlow();
									BrINT nOneWidth = 0;
									if (CTextProc::isExchangeWidthAndHeight(bTextFlow, wCode, pTextAtt))  //세로 쓰기일 때 0도 회전인 글자
									{
										if (pNode->isTypesetLink() != 0)
											nOneWidth = CTextProc::getCharSetWidth(document, BrNULL, pNode, GARO);
										else
											nOneWidth = CTextProc::getTextLinkWidth(document, pTextAtt, pNode->getCode(), pNode, BrNULL, 0, BrTRUE);
										nOneWidth = du.doc2LogicalDX(nOneWidth, BrFALSE);
									}
									else {
										nOneWidth = du.doc2LogicalDY((pNode->isTwoByteCode())? pTextAtt->getHanFSize(): pTextAtt->getEngFSize(), BrFALSE);
									}
									BrINT nLineWid = du.doc2LogicalDX(pLine->getAscent(), BrFALSE);
									BrINT nMaxDescent = CTextProc::getMaxDescentOfCurLine(document, pLine);

									dx = sx;
									dx = CalculateLinePos(bTextFlow, pTextAtt->getSubscript(), pTextAtt->getSuperscript(), dx, nLineWid, nOneWidth, nMaxDescent);
									dy = sy - du.doc2LogicalDY(y1, BrFALSE);
									dy = dy - lOneHgt;
								}
								else {
									dx = sx;
									dy = sy + du.doc2LogicalY(y1, BrFALSE);
								}
								for (BrINT i = 0; i < lOneHgt; i++) {
									switch ((dy + i) % 4) {
										case 0:
										case 1:
											dc->setPixel(dx + 1, dy + i, RGB_LIGHT_RED_SPELL);
											dc->setPixel(dx, dy + i, RGB_DARK_RED_SPELL);
											dc->setPixel(dx - 1, dy + i, RGB_MID_RED_SPELL);
											break;
										case 2:
										case 3:
											dc->setPixel(dx, dy + i, RGB_MID_RED_SPELL);
											dc->setPixel(dx - 1, dy + i, RGB_DARK_RED_SPELL);
											dc->setPixel(dx - 2, dy + i, RGB_LIGHT_RED_SPELL);
											break;
									}
								}
							}
						}
					}
					if (wCol == wCharNum - 1)
						break;
					//--- increase character node
					pNode++;

					//--- splited by run around line_frame,
					//    break CHARNODE LOOP for next CHARNODE in next BAND
					if (lBandEnd < cPosArray[wCol + 1]) {
						wCol++;
						break;
					}
					if (wCol == wCharNum - 1)
						break;
				}
			}
		}
	}
#endif  // _SPELLCHECKER

	DrawParaTabVerticalBar(painter, dc, du, pLine, sx, sy, BrFALSE);
}


void CTextDraw::CheckMultiMarkFindOfOneLineForSeekList(
        BrBOOL is_horizontal, BoraDoc* document, BrDC* dc, CDrawUnit& du,
        CFrame* frame, CLine* line, BrINT sx, BrINT sy)
{
	if (BrNULL == g_pAppStatic)
		return;

	CSeekList* seek_list = g_pAppStatic->m_pSeekList;
	if (BrNULL == seek_list)
		return;

	BrINT count = seek_list->GetListSize();
	if (count <= 0)
		return;

	if (is_horizontal && g_pAppStatic->isPrtPreview())
		return;

	const BrBOOL is_draw = (BrFALSE == is_horizontal || seek_list->GetMarkingColor() != NONE_COLOR_BITS);

	for (BrINT i = 0; i < count; i++) {
		Search* search = seek_list->GetAt(i);
		if (BrNULL == search)
			continue;

		CLine* l = search->pStartLine;

		if (l == search->pEndLine) {
			if (l == line) {
				BrINT start = search->nStartCol;
				BrINT end   = search->nEndCol;

				if (is_draw)
					DrawMultiMarkFindOfOneLineForSeekList(is_horizontal, document, dc, du,
					                                      frame, line, sx, sy, start, end);
			}
			continue;
		}

		while (l) {
			if (l == line) {
				BrINT start = (l == search->pStartLine)? search->nStartCol: 0;
				BrINT end   = (l == search->pEndLine)?   search->nEndCol:   l->getCharNum();
				DrawMultiMarkFindOfOneLineForSeekList(is_horizontal, document, dc, du,
				                                      frame, line, sx, sy, start, end);
				break;
			}
			if (l == search->pEndLine)
				break;
			l = l->getNext();
		}
	}
}


void CTextDraw::DrawMultiMarkFindOfOneLineForSeekList(
        BrBOOL is_horizontal, BoraDoc* document, BrDC* dc, CDrawUnit& du, CFrame* frame,
        CLine* line, BrINT sx, BrINT sy, BrINT col_start, BrINT col_end)
{
	CCharSetArray* charset_arr = line->getCharSetArray();
	if (BrNULL == charset_arr)
		return;

	CLongArray& pos_arr = line->getPosArray();
	BrINT size_pos = pos_arr.size();
	BrINT count = charset_arr->size();
	if (0 == count || size_pos < count + 1 || (1 == count && line->isEndLine()))
		return;
	if (is_horizontal && (size_pos <= col_start || size_pos <= col_end))
		return;

	BrINT ascent = line->getAscent();
	BrINT logical_start = du.doc2LogicalDX(pos_arr[col_start], BrFALSE);
	BrINT logical_end   = du.doc2LogicalDX(pos_arr[col_end], BrFALSE);
	BRect rect;
	if (is_horizontal) {
		rect.nTop    = sy - du.doc2LogicalDY(ascent, BrFALSE) - 3;
		rect.nBottom = sy + 1;
		rect.nLeft   = sx + logical_start;
		rect.nRight  = sx + logical_end;
		if (rect.nLeft == rect.nRight) {
			rect.nLeft -= 1;
			rect.nRight += 1;
		}
	}
	else {
		BrINT logical_ascent = du.doc2LogicalDX(ascent, BrFALSE);
		if (frame->isTextFlowBottomToTop()) {
			rect.nRight  = sx + 1;
			rect.nLeft   = sx - logical_ascent - 3;
			rect.nTop    = sy - logical_end;
			rect.nBottom = sy - logical_start;
		}
		else {
			rect.nRight  = sx + logical_ascent + 3;
			rect.nLeft   = sx - 1;
			rect.nTop    = sy + logical_start;
			rect.nBottom = sy + logical_end;
		}
		if (rect.nTop == rect.nBottom) {
			rect.nTop -= 1;
			rect.nBottom += 1;
		}
	}

	BrBmvBrush brush;
	BrCOLORREF marking_color = g_pAppStatic->m_pSeekList->GetMarkingColor();
	if (BrFALSE == is_horizontal || NONE_COLOR_BITS == marking_color)
		marking_color = BrRGB(255, 238, 128);  // light yellow
	DrawFillRect(dc, brush, rect, marking_color);
}


void CTextDraw::DrawGaroLineNumber(BrDC* dc, CDrawUnit& du, CLine* pLine, BrINT nMaxDescent, BrINT sy)
{
	const PoParaAtt* para_att;
	CSectionInfomation* section_info;
	BrWORD num_str[NUMBER_STR_LENGTH] = {};
	BrINT count;
	if (BrFALSE == ReadyDrawLineNumber(para_att, section_info, num_str, count, pLine))
		return;

	//Line을 포함한 Frame의 Left값이 x 좌표의 기준점
	BrINT nCurPos = pLine->getFrame()->getFrameRect()->nLeft;
	if (0 == section_info->getLineDistance()) {
		if (section_info->getColumnNum() > 1) {
			//임시처리 : spec 문서에 default일 때의 값이 명시되어있지 않음.
			nCurPos -= LINENUM_SPACE;
		}
		else {
			nCurPos -= LINENUM_SPACE_ONE_COL_POS;
			//nCurPos -= theBWordDoc->getPageArray()->getPage(pLine->getPage()->getPageNum())->leftMargin()*0.25;
			//nCurPos -= nCurPos*3;
		}
	}
	else {
		//[2014-08-04][TID-28051][장석훈]줄번호 distance 반대로 적용되는 문제 수정
		//nCurPos -= theBWordDoc->getPageArray()->getPage(pLine->getPage()->getPageNum())->leftMargin();
		nCurPos -= section_info->getLineDistance();
	}

	BrRect rect = pLine->getFrame()->getDisplayRect(BrTRUE);

	nCurPos += 20;

	BRDRAWCHARINFO stDrawCharInfo = {};
	stDrawCharInfo.pDC = dc;
	stDrawCharInfo.nLineHgt = du.doc2LogicalDY(pLine->getAscent(), BrFALSE);
	stDrawCharInfo.nFlag = para_att->getVerAlign();
	stDrawCharInfo.sx = du.doc2LogicalX(nCurPos);
	stDrawCharInfo.sy = sy;

	PoTextAtt cTextAtt; //기본값 생성 10point

	BrRect backupClipRect;
	dc->getClipRect(backupClipRect);

	// WPD-713 실제 text가 위치할 영역부터 clip 하도록 수정
	BrINT nTextStartPos = nCurPos;
	for (BrINT i = count - 1; i >= 0; i--) {
		CCharSet cCharSet(num_str[i], 0, LINKTYPE::STANDARD, SUBTYPE_STANDARD_LINK);
		nTextStartPos -= CTextProc::getTextLinkWidth(theBWordDoc, &cTextAtt, num_str[i]);
	}
	rect.left = nTextStartPos;	// POD-3433

	du.doc2Logical(rect);
	SetDCClipRect(dc, rect, backupClipRect);		// WPD-1010

	for (BrINT i = count - 1; i >= 0; i--) {
		CCharSet cCharSet(num_str[i], 0, LINKTYPE::STANDARD, SUBTYPE_STANDARD_LINK);
		nCurPos -= CTextProc::getTextLinkWidth(theBWordDoc, &cTextAtt, num_str[i]);
		stDrawCharInfo.sx = du.doc2LogicalX(nCurPos);
		DrawGaroCharSet(du, stDrawCharInfo, &cCharSet, &cTextAtt);
	}

	dc->setClipRect(&backupClipRect);
}


void CTextDraw::DrawSeroLineNumber(BrDC* dc, CDrawUnit& du, CLine* pLine, BrINT sx, BrINT sy)
{
	const PoParaAtt* para_att;
	CSectionInfomation* section_info;
	BrWORD num_str[NUMBER_STR_LENGTH] = {};
	BrINT count;
	if (BrFALSE == ReadyDrawLineNumber(para_att, section_info, num_str, count, pLine))
		return;

	BrINT nCurPos = pLine->getFrame()->getFrameRect()->nTop;
	if (0 == section_info->getLineDistance()) {
		if (section_info->getColumnNum() > 1) {
			//임시처리 : spec 문서에 default일 때의 값이 명시되어있지 않음.
			nCurPos -= MMtoTWIP(3);
		}
		else {
			nCurPos -= theBWordDoc->getPageArray()->getPage(pLine->getPage()->getPageNum())->leftMargin() * 0.25;
			//nCurPos -= nCurPos*3;
		}
	}
	else {
		nCurPos -= section_info->getLineDistance();
	}

	BrRect rect = pLine->getFrame()->getDisplayRect(BrTRUE);

	BRDRAWCHARINFO stDrawCharInfo = {};
	stDrawCharInfo.pDC = dc;
	stDrawCharInfo.nLineHgt = du.doc2LogicalDY(pLine->getAscent(), BrFALSE);
	stDrawCharInfo.nFlag = para_att->getVerAlign();
	stDrawCharInfo.sx = sx;
	stDrawCharInfo.sy = du.doc2LogicalY(nCurPos);

	PoTextAtt cTextAtt; //기본값 생성 10point

	BrRect backupClipRect;
	dc->getClipRect(backupClipRect);

	du.doc2Logical(rect);
	SetDCClipRect(dc, rect, backupClipRect);

	for (BrINT i = count - 1; i >= 0; i--) {
		CCharSet cCharSet(num_str[i], 0, LINKTYPE::STANDARD, SUBTYPE_STANDARD_LINK);
		nCurPos -= CTextProc::getTextLinkWidth(theBWordDoc, &cTextAtt, num_str[i]);
		stDrawCharInfo.sy = du.doc2LogicalY(nCurPos);
		DrawSeroCharSet(du, stDrawCharInfo, pLine->getFrame(), &cCharSet, &cTextAtt, pLine);
	}

	dc->setClipRect(&backupClipRect);
}


BrBOOL CTextDraw::ReadyDrawLineNumber(const PoParaAtt*& para_att, CSectionInfomation*& section_info,
                                      BrWORD (&buffer)[NUMBER_STR_LENGTH], BrINT& length, CLine* line)
{
	para_att = theBWordDoc->getParaAttHandler()->getMergedParaAtt(line->getParaID(), line);
	if (para_att->isSupressLineNum())
		return BrFALSE;

	CLine* section_line = theBWordDoc->getPrevSectionLine(line);
	section_info = section_line? section_line->getSectionInformation(): BrNULL;
	if (BrNULL == section_info)
		return BrFALSE;

	BrINT line_count_by = section_info->getLineCountBy();
	if (line_count_by <= 0)
		return BrFALSE;

	BrINT num = line->getLineNum();
	if (-1 == num)
		return BrFALSE;

	num += section_info->getLineStartNum();
	if (num % line_count_by)  // [ZPD-4961][2014.12.04][johnkim] 줄 번호 간격 문제 수정
		return BrFALSE;

	BrCHAR buf[NUMBER_STR_LENGTH] = {};
	sprintf_s(buf, sizeof(buf), "%d", num);
	CUtil::BYTEtoWORD(buffer, (LPBYTE)buf);

	length = 0;
	while (length < NUMBER_STR_LENGTH && buf[length])
		++length;
	return BrTRUE;
}


// old clip 과 겹치는 영역을 setClip 하기 위한 method
void CTextDraw::SetDCClipRect(BrDC* dc, BrRect& new_clip, const BrRect& old_clip)
{
	BRect clip = new_clip;
	if (old_clip.right && old_clip.bottom) {
		clip.Intersection(old_clip);
		new_clip = clip.getBrRect();
	}
	dc->setClipRect(&new_clip);
}


void CTextDraw::DrawGaroCharSet(CDrawUnit& du, BRDRAWCHARINFO& rDrawCharInfo, CCharSet* pLink,
                                const PoTextAtt* pTextAtt, CLine* pLine, BrBOOL isLine,
                                BrBOOL bEffect, Painter* painter, BrBOOL bHWPTypesetSymbol,
                                BrWordArtBitmapArray* pWordArtBitmapArray, BrINT nFieldSwitchCol)
{
	BoraDoc* document = theBWordDoc;
	PoDcTextAtt* curDcTextAtt = document->getTextAttHandler()->getCurDrawingDcTextAtt();
	PoDcTextAtt* prevDcTextAtt = document->getTextAttHandler()->getPreDrawgDcTextAtt();
	RevisionEngine* revision_engine = document->getRevisionEngine();
	if (revision_engine->isRevisionHidden(pLink) &&
	    (pLink->isCRLink() == BrFALSE || pLine != pLine->getLineList()->getLast() || pLine->getFrame()->isCell() == BrFALSE))
		return;

	if (pTextAtt == BrNULL)
		return;
#ifdef SUPPORT_HIDDEN_TEXT
	if (!pLink->isCRLink() && PO_TEXTATT_ENGINE::PoTextAttEngine::canShowText(*pTextAtt) == BrFALSE)
		return;
#endif  // SUPPORT_HIDDEN_TEXT
	// overframe되는 라인의 글자를 뿌리지 말자.
	CFrame* pFrame = BrNULL;
	if (pLine && isLine == BrFALSE)		// [johnkim][2013.11.23] pLine값이drawConCurStringGaro에서 들어오는 경우 제외하기 위해 isLine 사용 (FootNote에서 pLine 사용)
		pFrame = pLine->getFrame();

#ifdef USE_PDFEXPORT_TEXTBOX
	if (rDrawCharInfo.pDC->getDCType() == ePDFExtDCType && pFrame->isShape() && theBWordDoc->isExportPDFAnnot(pFrame->getID()))
	{
		return;
	}
#endif

	if (pFrame) {
		// Frame을 벗어나는 것은 그리지 말자. XPD-10719, LQQ-6998
#ifdef SUPPORT_SHOW_HWP_TYPESET
		if ((document->isFromHwp() && pFrame->isBasic() && !pLine->getIsHWPTypeSet() && !pLink->isCRLink()) || (document->isFromMSWordType() && pFrame->isCell()))
#else
		if ((document->isFromHwp() && pFrame->isBasic() && !pLink->isCRLink()) || (document->isFromMSWordType() && pFrame->isCell()))
#endif  // SUPPORT_SHOW_HWP_TYPESET
		{
			BRect rcFrame = pFrame->getFrameRect();
			// hwp에서 right margin이 마이너스인 경우을 고려 OFF-15362
			if (pLine && document->isFromHwp()) {
				const PoParaAtt* pParaAtt = pLine->GetParaAtt();
				if (pParaAtt && pParaAtt->getRightMargin() < 0)
					rcFrame.nRight -= pParaAtt->getRightMargin();
			}
			du.doc2Logical(rcFrame);
			if (rDrawCharInfo.sx >= rcFrame.nRight)
				return;
		}

#ifdef DANDONG_SMARTART_EDIT
		// [2015.08.20] 회전된 SmartArt자식도형에서 Caret설정시 본문표시위치가 틀리는 오유의 대책
		// 자식도형의 autoTxRot속성이 upr이고 회전각도가 있다면 회전된 도형의 령역을 기준으로 본문표시위치가 결정되여야 한다.
		// 왜냐하면 자식도형의 autoTxRot속성이 upr이고 회전각도가 있을 때 본문편집상태를 위해 도형각도를 0도로 설정하지 않기때문이다.
		BrINT nHeight = pFrame->height();
		if (pFrame->GetClass() == DIAGRAMXENTRY && pFrame->GetRotation() != 0
		    // [2016.03.24] Slide에서 SmartArt도형에 대하여 Ungroup적용하고 본문이 있는 자식도형을 선택한 이후
		    // 도형안의 본문이 회전되여 표시되는 오유의 수정(ZPD-26729)
		    || (pFrame->GetClass() == FLOATFRAME && pFrame->isDoNotRotateText() && pFrame->GetClassOrg() == DIAGRAMXENTRY && pFrame->GetRotation() != 0)
		) {
			CSmartArtEntry* pEntry = (CSmartArtEntry*)pFrame;
			if (pEntry->GetAutoTxRotationType() == eSmartArtUprATRot) {
				nHeight = pEntry->m_rcRotateFrame.GetHeight();
			}
		}

		if (!document->isFromPpt() && pLine->getAnchorFlag() && (pLine->getBasePos() - pTextAtt->getHanFSize()) > nHeight)	// LQQ-5010
			return;
#else  // DANDONG_SMARTART_EDIT
		if (!document->isFromPpt() && pLine->getAnchorFlag() && (pLine->getBasePos() - pTextAtt->getHanFSize()) > pFrame->height())
			return;
#endif  // DANDONG_SMARTART_EDIT
	}

#ifdef SUPPORT_SHOW_HWP_TYPESET
	if (bHWPTypesetSymbol) {
		if (DrawCharMakeParamForHWPTypesetSymbol(du, pLink, pTextAtt, pLine, rDrawCharInfo.nCol, painter) == BrFALSE)
			return;
	}
	else
#endif  // SUPPORT_SHOW_HWP_TYPESET
	{
		if (DrawCharMakeParam(du, pLink, pTextAtt, pLine, rDrawCharInfo.nCol, painter) == BrFALSE)
			return;
	}

	if (pFrame) {
		if (document->GetGrayMode() != GRAY_MODE_COLOR) {
			curDcTextAtt->setTextColor(BrColor::getBwColor(document->GetGrayMode(), pFrame->getFrameColorMode(), curDcTextAtt->getTextColor().getColor(), GRAY_MODE_APPLY_TEXT));
			curDcTextAtt->setBackColor(BrColor::getBwColor(document->GetGrayMode(), pFrame->getFrameColorMode(), curDcTextAtt->getBackColor().getColor(), GRAY_MODE_APPLY_TEXT));
		}
	}

	BrINT sx = rDrawCharInfo.sx;
	BrINT sy = rDrawCharInfo.sy;
	BrINT nLineHgt = rDrawCharInfo.nLineHgt;
	BrDC* dc = rDrawCharInfo.pDC;
	BrINT nFSize = curDcTextAtt->getHanFSize();
	CBCell* pCell = BrNULL;
	CFrame* pTableFrame = BrNULL;
	if (!rDrawCharInfo.pDC->isExportMode()) {
		if (pFrame && pFrame->isCell()) {
			pCell = pFrame->getCell();
			pTableFrame = pCell->getTableFrame();
			if (pTableFrame && !pTableFrame->isAnchored()) {//둘러싸기
				pCell = BrNULL;
				pTableFrame = BrNULL;
			}
		}

		if (pTextAtt->getEmphasis() || pTextAtt->getTextVerticalPos() < 0) {
			if (pTextAtt->getTextVerticalPos() < 0) {
				if (!IsClipRegion(sx, sy - nLineHgt, nLineHgt * 2, nFSize, pCell))
					return;
			}
			else if (pTextAtt->getEmphasis()) {
				if (!IsClipRegion(sx, sy - nLineHgt - nLineHgt / 2, nLineHgt + nLineHgt / 2, nFSize, pCell))
					return;
			}
		}
		else if (pTextAtt->getHanExpCom() > 100)	// #30227
		{
			if (!IsClipRegion(sx, sy - nLineHgt, nLineHgt, nFSize + (BrINT)(pTextAtt->getHanExpCom() * nFSize / 100.0)))
				return;
		}
		else if (pTextAtt->isWordArtStyle()) {
		}
		else {
			if (pFrame && pFrame->getPage() && pFrame->getPage()->getPageType() == NOTEMASTER_PAGE)
				;
			else if (!IsClipRegion(sx, sy - nLineHgt, nLineHgt + rDrawCharInfo.nDescent + nLineHgt / 2, nFSize, pCell))	// CSP-4990
				return;
		}
	}

	BrBOOL bChanged = BrFALSE;
	BString qStrBuffer = *curDcTextAtt->getTextString();
	BrINT nStrLen = qStrBuffer.length();

	if (qStrBuffer.isNull())
		return;

	BrBYTE bTextFlow = TEXTFLOW_GARO;
	if (pFrame)
		bTextFlow = pFrame->getTextFlow();

	if (TEXTFLOW_GARO != bTextFlow && pFrame->isCell() && document->isViewOutlineMode())
		bTextFlow = TEXTFLOW_GARO;

	// [2015.07.24][235] Print Export 또는 PDF Export시에는 CR기호를 Drawing하지 않는다.
	if (pLink->isTextLink() && CTextProc::isCRCode(qStrBuffer[0].unicode()) && !pLink->isFieldExDummyLink()) {
		//if (document->isFromSlideType() || dc->isExportMode()) return;
		return;
	}

	BRCONTEXT;
	//if ( !document->isViewPrintMode() && !dc->isExportMode() && document->getDocType()==BORA_DOCTYPE_ASCI && Brcontext.m_GeneralValue.dwTextColorForTXT != BLACK_COLOR )	{
	if (Brcontext.m_GeneralValue.dwTextColorForTXT != BLACK_COLOR)
		curDcTextAtt->setTextColor(Brcontext.m_GeneralValue.dwTextColorForTXT);
	if (Brcontext.m_GeneralValue.dwBgColorForTXT != WHITE_COLOR)
		curDcTextAtt->setBackColor(Brcontext.m_GeneralValue.dwBgColorForTXT);
	//}

	BFont* pAppStaticFont = g_pAppStatic->m_pFont;
	BrINT rotate = CTextProc::getRotateAngle(bTextFlow, qStrBuffer[0].unicode(), pTextAtt);
	CFontArray* font_arr = document->getFontArray();
	bChanged = UpdateStaticFont(pAppStaticFont, dc, *curDcTextAtt, *prevDcTextAtt, BrTRUE,
	                            rotate, du, *pTextAtt, font_arr, pLine);

	//BrINT nCharDes = (dc->isExportMode())? 0: g_pAppStatic->m_pFont->getCharDescent();
	BrINT nCharDes = pAppStaticFont->getCharDescent();

	BrINT nFontHgt = pAppStaticFont->getCharHeight();
	if (curDcTextAtt->getSuperscript()) {
		// 현 line에 모든 글자가 superscript인 경우 제외 NPC-7149
		if (!(pLine && (nFontHgt + 1) >= du.doc2LogicalDY(pLine->getAscent(), BrFALSE)))
			sy -= (BrINT)((nFontHgt - nCharDes) * 1.7);	// nFSize;
		else
			sy -= (BrINT)((nFontHgt - nCharDes) * 1.6);
	}
	else
		sy -= nFontHgt - nCharDes;

	// adjust to maximum descent of current line
	// subscript인 경우는 Descent를 빼주지 않는다. (2012.05.31)
	if (!curDcTextAtt->getSubscript())
		sy -= rDrawCharInfo.nDescent;
	// if line has equation line_frame, consider max descent for subscript (SRG-1056)
	else if (rDrawCharInfo.nDescent > nCharDes && pLine && pLine->isEquationFrame())
		sy -= rDrawCharInfo.nDescent + (nCharDes / 2);
	else
		sy -= nCharDes / 2;

	//[2013-11-08][T-18055][20hoon]
	if (pLine && isLine == BrFALSE) {
		if (pTextAtt->getTextVerticalPos() > 0)
			sy -= /*rDrawCharInfo.nDescent+*/du.doc2LogicalY(pTextAtt->getTextVerticalPos(), BrFALSE);
		//else if (pTextAtt->getTextVerticalPos() == 0 && pLine->getDescent() > 0
			//sy -= /*rDrawCharInfo.nDescent;*/du.doc2LogicalY(pLine->getDescent(), BrFALSE);
		else if (pTextAtt->getTextVerticalPos() < 0)
			sy = sy /*- rDrawCharInfo.nDescent*/ + du.doc2LogicalY(BrABS(pTextAtt->getTextVerticalPos()), BrFALSE);
	}

	if (pTextAtt->getVOffset()) {
		sy -= du.doc2LogicalDY(pTextAtt->getVOffset(), BrFALSE);
	}
	// HWP 글자위치
	else if (document->isFromHwp() && pTextAtt->getCharPosition()) {
		sy += du.doc2LogicalDY(pTextAtt->getHanFSize() * pTextAtt->getCharPosition() / 100, BrFALSE);
	}

	// display emphasis
	if (pTextAtt->getEmphasis()) {
		if (!DrawEmphasisBitmap(painter, dc, pFrame, pLine, rDrawCharInfo.nCol, pTextAtt, sx, sy, nFontHgt, pAppStaticFont->getCharWidth(qStrBuffer.at(0).unicode()), pAppStaticFont->getTextColor()))
			DrawEmphasis(dc, pTextAtt, sx, sy, nFontHgt, pAppStaticFont->getCharWidth(qStrBuffer.at(0).unicode()), pAppStaticFont->getTextColor());
	}

	BrBOOL bUTF16 = BrFALSE;

	BrULONG nUTF16Code = 0;
	BrBOOL bExport = dc->getDCType() != eNormalDCType;
	//[14.04.21][sglee1206] Emoji 및 0x263A export 시 출력안되는 문제 수정
	if (pLink->is4BYTE() || 0x263A == pLink->getCode()) {
		bUTF16 = BrTRUE;
		if (pLink->is4BYTE())
			nUTF16Code = CUTF16Surrogate::getCode(pTextAtt->getHighSurrogate(), pLink->getCode());
		else
			nUTF16Code = pLink->getCode();
	}

	BFont* pFont = document->getCmdEngine()->getCurPainter()->pDC->m_pFont;
	BrBOOL bArabic = ConvertArabic(qStrBuffer, pFont, pLink->getCode(), pLine, rDrawCharInfo.nCol);

	if (BrFALSE == SupportLocaleCompose(pFont, qStrBuffer, pLine, rDrawCharInfo.nCol, bExport))
		return;

	if (painter == BrNULL)
		painter = gpPaint;		// PIE-1295

	BrBOOL bNoUseCharBitmap = CheckWordArtDrawText(pLine, pFrame, pTextAtt, dc->m_pFont->getCharDescent(),
	                                               painter->getZoomScale(), painter->m_iResX);

	if (pLine && pLine->getCodeIndexArray().size() != 0 && rDrawCharInfo.nCol < pLine->getCodeIndexArray().size() && !bUTF16) {
		BrINT nComposeGlyphCnt = pLine->getCodeIndexArray().at(rDrawCharInfo.nCol).nGlyphCnt;

		if (nComposeGlyphCnt > 0)		//Glyph Max Count 0xFFFF
		{
			BrINT nCurIndex = 0;

			BrINT32 nTmpWidth = 0;
			BrINT nTmpHeight = 0;
			for (BrINT t = 0; t < nComposeGlyphCnt; t++) {
				nCurIndex = pLine->getCodeIndexArray().at(rDrawCharInfo.nCol).GlyphArray[t];
				pFont->SetFontGlyphIndexValue(nCurIndex);
				//[19.12.10][sglee1206] 기존에 y offset 처리하는 방식에 오류가 있어서 수정
				nTmpHeight = pLine->getCodeIndexArray().at(rDrawCharInfo.nCol).nAdvance[t];
				if (nTmpHeight != 0)
					nTmpHeight = du.doc2LogicalDY(nTmpHeight, BrFALSE);
				nTmpWidth += dc->drawChars(&qStrBuffer, sx + nTmpWidth, sy - nTmpHeight);

				/*if(t > 0 && nTmpWidth)
					nTmpWidth = 0;*/
			}
		}
		else if (qStrBuffer.at(0).unicode() != 0) {
			if (!bExport)
				dc->drawChars(&qStrBuffer, sx, sy);
			//[17.06.08][sglee1206] PDF Export 시 이미 조합이 완료된 글자가 전달되어 Rendering과 동일한 조건으로 처리[XPD-17277]
			else if (bExport && qStrBuffer.at(0).unicode() != 0)
				dc->drawChars(&qStrBuffer, sx, sy);
		}
	} 
	else if (bArabic) {
		if (!bEffect || bNoUseCharBitmap || DrawCharBitmap(painter, dc, pLink, pTextAtt, pLine, rDrawCharInfo.nCol, qStrBuffer, sx, sy) == BrFALSE) {
			PoPixel charWidth = du.doc2LogicalDX(CTextProc::getStringWidth(document, &qStrBuffer, pTextAtt), BrFALSE);
			dc->drawChars(&qStrBuffer, sx - charWidth, sy);
		}
	}
	else if (bUTF16) {
		Draw4ByteUnicodeCharSet(pLine, dc, sx, sy, rDrawCharInfo.nCol, nUTF16Code);
	}
	else {
		CCaret* pCaret = document->getCaret();
		// slide bullet만 있는 라인에 caret이 위치한 경우, bulelt을 투명하게 그린다.
		//[221017][EMO-2073][Paul.S.Jeon] slide bullet 만 있는 라인에 caret 및 marking이 위치할 때, bullet을 투명하게 그린다.
		if (NULL == pCaret)
		{
			return;
		}
		CLine *pCaretLine = pCaret->getLine();
		CLine* pSLine = pCaret->getSLine();
		if (document->isFromSlideType() && pLink->isBulletLink()
				&& pLine && pLine->isEmptyLineBullet()
				&& ((pCaret->isCaretNormal() && pCaretLine == pLine) || pSLine == pLine)) {
			PoTextAtt cTextAtt(*pTextAtt);
			BrGrapAtt* pGrapAtt = cTextAtt.getGrapAtt();

			BrBOOL bCreateGrap = BrFALSE;
			if (!pGrapAtt) {
				pGrapAtt = BrNEW BrGrapAtt;
				bCreateGrap = BrTRUE;
				pGrapAtt->init();
				BrBrushObj* pBrushObj = pGrapAtt->getBrush();
				if (pBrushObj) {
					pBrushObj->setStyle(BMV_FILLTYPE_SOLID);
					pBrushObj->setForeColor(pTextAtt->getTextColor()); //[EMO-2301][minseob] UpdateCharEffectColor() 에서 실제로 set 되고 있음

					if (document->getDocType() == BORA_DOCTYPE_PPTX)
						pBrushObj->setTransparent((BrFLOAT)127.5);

					cTextAtt.setGrapAtt(pGrapAtt);
				}
			}
			else {
				BrBrushObj* pBrushObj = pGrapAtt->getBrush();
				if (pBrushObj) {
					BrFLOAT nTransparent = pBrushObj->getTransVal();
					nTransparent = (BrFLOAT)((nTransparent + 255) / 2);
					pBrushObj->setTransparent(nTransparent);
				}
			}
			if (!bEffect || bNoUseCharBitmap || DrawCharBitmap(painter, dc, pLink, &cTextAtt, pLine, rDrawCharInfo.nCol, qStrBuffer, sx, sy, pWordArtBitmapArray, nFieldSwitchCol) == BrFALSE)
				dc->drawChars(&qStrBuffer, sx, sy);

			if (bCreateGrap)
				cTextAtt.setGrapAtt(BrNULL);
		}
		else {
			if (!bEffect || bNoUseCharBitmap || bHWPTypesetSymbol || DrawCharBitmap(painter, dc, pLink, pTextAtt, pLine, rDrawCharInfo.nCol, qStrBuffer, sx, sy, pWordArtBitmapArray, nFieldSwitchCol) == BrFALSE) {
				if (rDrawCharInfo.bBidiPara) {
					BrBOOL isCharacterBullet = pLink->getLinkType() == LINKTYPE::STANDARD && pLink->getSubType() == BULLET_CHAR;
					if (pLink->getCode() == 0x2936 || (isCharacterBullet && rDrawCharInfo.flipInBullet)) {
						dc->drawChars(&qStrBuffer, sx, sy, BrNULL, BrFALSE, BrNULL, BrTRUE);
					} else if ((!isCharacterBullet && pTextAtt->getBiDi()) || (isCharacterBullet && rDrawCharInfo.drawLeftInBullet)) {
						if (NUMBER_MIN <= pLink->getCode() && pLink->getCode() <= NUMBER_MAX) {
							dc->drawChars(&qStrBuffer, sx, sy);
						} else {
							PoPixel charWidth = du.doc2LogicalDX(CTextProc::getStringWidth(document, &qStrBuffer, pTextAtt), BrFALSE);
							dc->drawChars(&qStrBuffer, sx - charWidth, sy);
						}
					} else {
						dc->drawChars(&qStrBuffer, sx, sy);
					}
				} else {
					if (!(NUMBER_MIN <= pLink->getCode() && pLink->getCode() <= NUMBER_MAX) && (pTextAtt->getBiDi() || (pLink->getLinkType() == LINKTYPE::STANDARD && pLink->getSubType() == BULLET_CHAR && IsRTLChar(pLink->getCode())))) {
						PoPixel charWidth = du.doc2LogicalDX(CTextProc::getStringWidth(document, &qStrBuffer, pTextAtt), BrFALSE);
						dc->drawChars(&qStrBuffer, sx - charWidth, sy);
					} else {
						dc->drawChars(&qStrBuffer, sx, sy);
					}
				}
			}
		}
	}

	pFont->ClearFontGlyphIndexValue();

	if (bChanged)
		*prevDcTextAtt = *curDcTextAtt;
}


void CTextDraw::DrawSeroCharSet(CDrawUnit& du, BRDRAWCHARINFO& rDrawCharInfo,
                                CFrame* pFrame, CCharSet* pLink, const PoTextAtt* pTextAtt,
                                CLine* pLine, Painter* painter, BrBOOL bEffect,
                                BrWordArtBitmapArray* pWordArtBitmapArray, BrINT nFieldSwitchCol)
{
	BoraDoc* document = theBWordDoc;
	if (document == BrNULL)
		return;

	RevisionEngine* revision_engine = document->getRevisionEngine();
	if (revision_engine->isRevisionHidden(pLink)) {
		if ((pLink->isCRLink() && pLine == pLine->getLineList()->getLast() && pLine->getFrame()->isCell()));
		else {
			return;
		}
	}
	PoDcTextAtt* curDcTextAtt = document->getTextAttHandler()->getCurDrawingDcTextAtt();
	PoDcTextAtt* prevDcTextAtt = document->getTextAttHandler()->getPreDrawgDcTextAtt();
	if (pTextAtt == BrNULL)
		return;

	if (DrawCharMakeParam(du, pLink, pTextAtt, pLine, rDrawCharInfo.nCol, painter) == BrFALSE)
		return;


	if (document->GetGrayMode() != GRAY_MODE_COLOR) {
		curDcTextAtt->setTextColor(BrColor::getBwColor(document->GetGrayMode(), pFrame->getFrameColorMode(), curDcTextAtt->getTextColor().getColor(), GRAY_MODE_APPLY_TEXT));
		curDcTextAtt->setBackColor(BrColor::getBwColor(document->GetGrayMode(), pFrame->getFrameColorMode(), curDcTextAtt->getBackColor().getColor(), GRAY_MODE_APPLY_TEXT));
	}

	BrBOOL bChanged = BrFALSE;
	BrINT nFSize = curDcTextAtt->getHanFSize();
	BString qStrBuffer = *curDcTextAtt->getTextString();
	if (qStrBuffer.isNull())
		return;

	BrDC* dc = rDrawCharInfo.pDC;
	BrINT sx = rDrawCharInfo.sx;
	BrINT sy = rDrawCharInfo.sy;
	BrINT nLineWid = rDrawCharInfo.nLineHgt;

	BrINT nCharWid = 0;
	if (IsRequireWidth(pFrame->getTextFlow(), curDcTextAtt->getSuperscript(), curDcTextAtt->getSubscript())) {
		if (getDocType() == BORA_DOCTYPE_HWP && pWordArtBitmapArray) {
			nCharWid = nLineWid;
		}
		else if (CTextProc::isExchangeWidthAndHeight(pFrame->getTextFlow(), qStrBuffer.at(0).unicode(), pTextAtt) == BrTRUE) //세로 쓰기일 때 0도 회전인 글자
		{
			if (pLink->isTypesetLink() != 0)
				nCharWid = CTextProc::getCharSetWidth(document, BrNULL, pLink, GARO);
			else
				nCharWid = CTextProc::getTextLinkWidth(document, pTextAtt, pLink->getCode(), pLink, BrNULL, 0, BrTRUE, BrNULL, BrNULL, BrFALSE);	// no cache because of same text_att pointer
			nCharWid = du.doc2LogicalDX(nCharWid, BrFALSE);
			if (nCharWid == 0 && pLink->getCode() == ASCII_CODE_CR)
				nCharWid = 10;		// ASCII_CODE_CR width
		}
		else {
			nCharWid = nFSize;
			if (pFrame->getTextFlow() == TEXTFLOW_SERO_270)
				nCharWid -= LineOneDescent(document, pLine, rDrawCharInfo.nCol);
		}
	}

	if (pLink->isOldHanJungsung() || pLink->isOldHanJongsung()) {
		if (pTextAtt)
			sy -= du.doc2LogicalDY(pTextAtt->getHanFSize(), BrFALSE);
		nCharWid = CTextProc::getTextLinkWidth(document, pTextAtt, 0x1100, pLink, BrNULL, 0, BrTRUE, BrNULL, BrNULL, BrFALSE);	// no cache because of same text_att pointer
		nCharWid = du.doc2LogicalDX(nCharWid, BrFALSE);
		sx += nCharWid;
	}

	sx = CTextProc::getLeftPosOfText(pFrame->getTextFlow(), sx, nLineWid, nCharWid,
	                                 qStrBuffer.at(0).unicode(), pTextAtt, rDrawCharInfo.nFlag);
	if (pTextAtt->getVOffset() != 0) {
		if (pFrame->isTextFlowLeftToRight())
			sx -= du.doc2LogicalDX(pTextAtt->getVOffset(), BrFALSE);
		else
			sx += du.doc2LogicalDX(pTextAtt->getVOffset(), BrFALSE);
	}

	// 세로쓰기에서 90도 회전하는 글자는 descent만큼 올려주자.(2012.8.13)[T-16340] Issue
	if (curDcTextAtt->getRotateValue() == 90)
		sx += g_pAppStatic->m_pFont->getCharDescent();

	// 세로쓰기에서 270도 회전하는 글자는 descent만큼 올려주자.(2012.8.13)[T-16340] Issue
	if (curDcTextAtt->getRotateValue() == 270) {
		//[16.04.04][sglee1206] PPT 계열에서는 해당 처리시 겹치는 현상이 존재함 [ZPD-24914][ZPD-26098][ZPD-26261]
		if (!(document->getDocType() == BORA_DOCTYPE_PPT || document->getDocType() == BORA_DOCTYPE_PPTX || document->getDocType() == BORA_DOCTYPE_ODP))
			sx -= g_pAppStatic->m_pFont->getCharDescent();
	}

	//CSP - 319 //2014-07-31 //20hoon
	//Ideographic full stop와 Ideographic comma 는 세로모드 일때 글자 크기만큼 밀어서 그려준다.
	//full stop도 글자 크기만큼 옆으로 밀어서 그려줍니다.
	//fullwidth full stop(0xff0e)도 동일하게 처리[NPC-3533]
	if (pFrame->getTextFlow() == TEXTFLOW_SERO && (qStrBuffer.at(0).unicode() == 0x3002 || qStrBuffer.at(0).unicode() == 0x3001 || qStrBuffer.at(0).unicode() == 0xff0e)) {
		// 글자 크기 만큼 밀면 글자 바깥으로 나가기 때문에 일본어 참조하여 반만 밀어 주는 것으로 함. ZPD-28168, ZPD-28167
		sx += nCharWid * 0.5;
	}

	/*
	 * [NDE-615][minseob] rev.86849 에서 삭제된 내용으로 인해 
	 * 텍스트 채우기 -> 그라데이션 채우기가 적용된 텍스트가 입력된 도형 렌더링시 nCol overflow 에러 발생
	*/
	if (pLink->isTextLink() && CTextProc::isCRCode(qStrBuffer.at(0)) &&
		!pLink->isFieldExDummyLink()) //[2014.08.18][ZPD-886][고준성] Hwp 포맷도 텍스트 방향이 세로일 경우 ASCII_CODE_CR출력
		// [2015.07.24][235] Print or PDF Export시에는 ASCII_CODE_CR기호를 Drawing하지 않는다.
	{
		if (document->isFromSlideType())
			return;
	}

	BrINT verticalPos = pTextAtt->getTextVerticalPos();
	if (pTextAtt->isSettedTextVerticalPos()) {
		switch (pFrame->getTextFlow()) {
			case TEXTFLOW_SERO_270:
				sx -= du.doc2LogicalDX(verticalPos, BrFALSE);
				break;
			case TEXTFLOW_SERO:
			case TEXTFLOW_SERO_90:
			default:
				sx += du.doc2LogicalDX(verticalPos, BrFALSE);
				break;
		}
	}

	curDcTextAtt->setRotateValue(CTextProc::getRotateAngle(pFrame->getTextFlow(), qStrBuffer.at(0).unicode(), pTextAtt));

	//doc, hwp는 기호 관련 font는 90도 회전하지 않는다.
	BrWORD* pFaceName = document->getFontArray()->GetAt(pTextAtt->getEngFontID())->lf.lfFaceName;
	BrBOOL no_rotate_format = document->isFromDoc() || document->isFromHwp();  // document->isFromOdt();
	if (no_rotate_format && CUtil::checkFontIsSymbolType(pFaceName) && curDcTextAtt->getRotateValue() == 90)
		curDcTextAtt->setRotateValue(0);

	// hwp bullet은 90도 회전하지 않는다.
	// Ascii 영역 밖의 코드값은 회전하지 않는다.
	if (pLink->isBulletLink()) {
		CBullet* pBullet = pLine->getBullet();
		if (document->isFromHwp()) {
			//drawEditSymbol 에서 space의 경우, charSet의 code값을 0x00B7로 변경하므로 isSpace로 체크는 불가능함
			if (!(pLink->getCode() == 0x00B7)) {
				if (pBullet && pBullet->isBulletType())
					curDcTextAtt->setRotateValue(0);
			}
		}
		//PIE-504 bullet charset도 일반 글자와 똑같음 (따로 처리할 필요 없음)
		/*else
		{
			if(pBullet && (pBullet->isOutlineType() || pBullet->isMultiOutlineType()))
			{
				if(BrFALSE == CCUtil::isAsciiChar(pLink->getCode()))
					curDcTextAtt->setRotateValue(0);
			}
		}*/
	}

	// PPT에서 세로쓰기에서 270도 회전을 하면 한글, 한자는 90도 회전을 시켜주자 ZPD-19329, WPD-3665 (flip 까지 고려), WPD-3747
	if (curDcTextAtt->getRotateValue() == 0 && document->isFromPpt() && pFrame->getTextFlow() == TEXTFLOW_SERO &&
		((pFrame->GetRotation() == 270 && !pFrame->getFlip() && !pFrame->getMirror()) || (pFrame->GetRotation() == 90 && pFrame->getFlip() && pFrame->getMirror()) || (pFrame->GetRotation() == 90 && !pFrame->getFlip() && !pFrame->getMirror()) || (pFrame->GetRotation() == 90 && pFrame->getFlip() && !pFrame->getMirror())) &&
		(IS_MODERN_KOREAN(pLink->getCode()) || IS_HANJA(pLink->getCode())))
		curDcTextAtt->setRotateValue(90);

	BFont* pAppStaticFont = g_pAppStatic->m_pFont;
	BrINT rotate = curDcTextAtt->getRotateValue();
	CFontArray* font_arr = document->getFontArray();
	bChanged = UpdateStaticFont(pAppStaticFont, dc, *curDcTextAtt, *prevDcTextAtt, BrFALSE,
	                            rotate, du, *pTextAtt, font_arr, pLine);

	if (pTextAtt->getEmphasis()) {
		if (!DrawEmphasisBitmap(painter, dc, pFrame, pLine, rDrawCharInfo.nCol, pTextAtt, sx, sy, pAppStaticFont->getCharHeight(), pAppStaticFont->getCharWidth(qStrBuffer.at(0).unicode()), pAppStaticFont->getTextColor(), BrFALSE))
			DrawEmphasis(dc, pTextAtt, sx, sy, pAppStaticFont->getCharHeight(), pAppStaticFont->getCharWidth(qStrBuffer.at(0).unicode()), pAppStaticFont->getTextColor(), BrFALSE);
	}

	// 세로쓰기는 변수가 많아서 clip check를 삭제하자 Line전체에서 하니 speed 크게 문제 없음 CAM-6599
	//if(!IsClipRegion(sx, sy, nFSize))
	//	return;

	BFont* pFont = document->getCmdEngine()->getCurPainter()->pDC->m_pFont;
	ConvertArabic(qStrBuffer, pFont, pLink->getCode(), pLine, rDrawCharInfo.nCol);

	BrBOOL bExport = dc->getDCType() != eNormalDCType;
	if (BrFALSE == SupportLocaleCompose(pFont, qStrBuffer, pLine, rDrawCharInfo.nCol, bExport))
		return;

	BrBOOL bUTF16 = BrFALSE;
	BrULONG nUTF16Code = 0;

	if (pLink->is4BYTE()) {
		bUTF16 = BrTRUE;
		nUTF16Code = CUTF16Surrogate::getCode(pTextAtt->getHighSurrogate(), pLink->getCode());
	}

	if (bUTF16) {
		Draw4ByteUnicodeCharSet(pLine, dc, sx, sy, rDrawCharInfo.nCol, nUTF16Code);
	}
	else {
		if (!bEffect || painter) {
			if (DrawCharBitmap(painter, dc, pLink, pTextAtt, pLine, rDrawCharInfo.nCol, qStrBuffer, sx, sy, pWordArtBitmapArray, nFieldSwitchCol) == BrFALSE)
				dc->drawChars(&qStrBuffer, sx, sy);
		}
		else {
			dc->drawChars(&qStrBuffer, sx, sy);
		}
	}

	pFont->ClearFontGlyphIndexValue();

	if (bChanged)
		*prevDcTextAtt = *curDcTextAtt;
}


#ifdef SUPPORT_SHOW_HWP_TYPESET
// HWP 조판부호 string 처리
BrBOOL CTextDraw::DrawCharMakeParamForHWPTypesetSymbol(
        CDrawUnit& du, CCharSet* pLink, const PoTextAtt* pTextAtt,
        CLine* pLine, BrINT nCol, Painter* painter)
{
	BoraDoc* document = theBWordDoc;

	if (document == BrNULL)
		return BrFALSE;
	if (!document->isShowHWPTypeSetMode())
		return BrFALSE;

	//--- initialize
	PoDcTextAtt* curDcTextAtt = theBWordDoc->getTextAttHandler()->getCurDrawingDcTextAtt();
	curDcTextAtt->init();

	curDcTextAtt->setHanFSize(du.doc2LogicalDY(pTextAtt->getHanFSize(), BrFALSE));
	if (pTextAtt->isSettedDStrikeout())
		curDcTextAtt->setStrikeout(pTextAtt->getStrikeout());
	if (pTextAtt->isSettedUnderline())
		curDcTextAtt->setUnderline(pTextAtt->getUnderline());
	if (pTextAtt->isSettedSuperscript())
		curDcTextAtt->setSuperscript(pTextAtt->getSuperscript());
	if (pTextAtt->isSettedSubscript())
		curDcTextAtt->setSubscript(pTextAtt->getSubscript());

	curDcTextAtt->setHanExpCom(pTextAtt->getHanExpCom());
	curDcTextAtt->setHanFontID(0);		// set default font

	if (document->getHeaderFooterEngine()->is_edit_mode())
		curDcTextAtt->setTextColor(RGB_LTSALMON);
	else
		curDcTextAtt->setTextColor(RGB_ORANGE1);

	BrHWPTypeSetSymbolIndex nIndex = CTextProc::getHWPTypesetSymbolIndex(document, pLink);
	if (nIndex >= INDEX_HWP_TYPESET_HEADER_BOTH && nIndex < INDEX_HWP_TYPESET_MAX) {
		BrINT nLen = CUtil::WcsLen(strHWPTypeSetSymbol[nIndex]);
		curDcTextAtt->getTextString()->insert(0, (const BChar*)strHWPTypeSetSymbol[nIndex], nLen);
		if (curDcTextAtt->getTextString()->isNull())
			return BrFALSE;
		return BrTRUE;
	}

	return BrFALSE;
}
#endif  // SUPPORT_SHOW_HWP_TYPESET


BrBOOL CTextDraw::DrawCharMakeParam(CDrawUnit& du, CCharSet* pLink, const PoTextAtt* pTextAtt,
                                    CLine* pLine, BrINT nCol, Painter* painter)
{
	if (!pLink)
		return BrFALSE;

	BoraDoc* document = theBWordDoc;
	if (!document)
		return BrFALSE;

	BrWORD wCode = pLink->getCode();
	BYTE bSubType = pLink->getSubType();
	BrBOOL bShowTabCR = BrFALSE;
	BrINT i = 0;
	BrBOOL bCheckNightMode = BrTRUE;

	//--- initialize
	PoDcTextAtt* curDrawingTextAtt = theBWordDoc->getTextAttHandler()->getCurDrawingDcTextAtt();
	curDrawingTextAtt->init();

	//////////////////////////////////////////////////////////////////////////
	BrINT32 nFSize = pTextAtt->getEngFSize();

	//dcParam.m_wStyle = (BrWORD)(text_att->getAttr() & (~UNDERLINE_MASK & ~STRIKEOUT_MASK));

	BrSHORT wExpCom = pTextAtt->getHanExpCom();
	BrBOOL autoColor = pTextAtt->getAutoColor();
	BrCOLORREF textColor = pTextAtt->getTextColor().getColor();
	BrCOLORREF backColor = pTextAtt->getBackColor().getColor();
	BrINT32 nFontID = pTextAtt->getHanFontID();
	BrBOOL superScript = pTextAtt->getSuperscript();
	BrBOOL subScript = pTextAtt->getSubscript();
	BrBOOL italic = pTextAtt->getItalic();
	BrBOOL bold = pTextAtt->getBold();
	BString* textString = curDrawingTextAtt->getTextString();
	textString->remove(0, textString->length());
	//////////////////////////////////////////////////////////////////////////
	// underline을 이어보이기 위하여 예외처리 XPD-16911
	typedef ::bwp::charset::iterator iterator;
	iterator cur(pLine, nCol);
	iterator next = cur;
	if (cur.validate())
		++next;
	if (wCode == 0x5f && pLine && nCol < (pLine->getCharNum() - 1) &&
			next.validate() && next->getCode() == 0x5f) // [XPD-16911] IMPORTANT! 포인터 산술연산 그냥 하지 마세요
	{
		wExpCom = (wExpCom == 0)? 110: wExpCom + 10;
	}

	BrCOLORREF   dwTextColor;
	// XPD-992 이슈로 주석처리했으나, ERH-83으로 인해 주석 해제
	if (pLine && pLine->getFrame() && pLine->getFrame()->isDimColorDraw())		//for word header/footer dim color, //[13.05.08][이정우] 본문과 머리글/바닥글이 textatt를 공유하는 경우 본문에서 잘못된 색으로 출력되는 현상 수정
	{
#ifdef NEW_DIM_COLOR
		dwTextColor = pTextAtt->getDimTextColor();
#else
		dwTextColor = MakeTextDimColor(pTextAtt, pLine);
#endif
	}
	else if (pTextAtt->getAutoColor() && !document->getCmdEngine()->isHFThumbnail()) {
		BrColor* pFontColor = pLine? ShapeQuickStyleTextAutoColor(pLine->getFrame()): BrNULL;

		//[EMO-2301][minseob] 블릿 자동 색상일 경우 스타일 색상을 따라가 글자 색상이 있을경우 글자를 따라가도록 설정
		if (pLink->isBulletLink() && pFontColor != BrNULL) {
			CCharSet* pTextLink = pLine->getCharSet(nCol + 2); //블릿, 글자 중간에 탭이 들어가 있어 +2
			if (pTextLink != BrNULL) {
				const PoTextAtt* pTextAtt = theBWordDoc->getTextAttHandler()->getTextAtt(pTextLink->getAttrID());

				if (!pTextLink->isBulletLink() && !pTextAtt->getAutoColor())
					pFontColor = BrNULL;
			}
		}

		if (pFontColor)
			dwTextColor = AutoTextColor(pLine, pTextAtt, pFontColor);
		else if (pLine && pLine->isTOCLine() && pTextAtt->getLinkType() == LINKTYPE::FIELD)	//목차 내 하이퍼링크가 Auto color일때 검정색으로 표시되도록 수정
			dwTextColor = RGB_BLACK;
		else
			dwTextColor = AutoTextColor(pLine, pTextAtt);
	}
	else if (theBWordDoc->getDocType() == BORA_DOCTYPE_PPT && pTextAtt->getEmboss())	//Mantis 21302
		dwTextColor = WHITE_COLOR;
	else {
		dwTextColor = pTextAtt->getTextColor().getColor();
	}

	dwTextColor = BrRGB2BGR(dwTextColor);
	//if(pLine && pLine->getFrame()->isHeader())
	//	BrTrace("Color : %d", dwTextColor);
	// if ( dwTextColor==0 )    dwTextColor = g_pAppConfig->getTextColor();

	BrCOLORREF dwBackColor;
	if (pLine && pLine->getFrame() && pLine->getFrame()->isDimColorDraw()) {
#ifdef NEW_DIM_COLOR
		dwBackColor = pTextAtt->getDimBackColor();
#else
		dwBackColor = MakeBackDimColor(pTextAtt);
#endif
	}
	else
		dwBackColor = pTextAtt->getBackColor().getColor();

	if (pTextAtt->getReverse()) {
		textColor = BrRGB2BGR(dwBackColor);
		backColor = dwTextColor;
	}
	else {
		RevisionEngine* revision_engine = theBWordDoc->getRevisionEngine();
		CCharSet *charset = pLine ? pLine->getCharSet(nCol) : BrNULL;
		BrBOOL check_symbol = charset && charset->isTextLink() && checkEditSymbol(charset);

		if (!check_symbol && revision_engine->canDrawRevisionColor(pLink))
			textColor = revision_engine->getReviewerColor(pLink);
		else
			textColor = dwTextColor;
		backColor = BrRGB2BGR(dwBackColor);
	}

	if (pLink->isPageNumTimeDate()) {
		BrWORD bBuffer[64];
		BrINT nBufLen = 0;
#ifdef IMPORT_HWP
		if (document->getPageCtrlArray()->size() > 1) {
			Hwp50PageNum drawingPageCtrl;
			pLine->getPage()->getPageCtrlData(&drawingPageCtrl);
			nBufLen = CTextProc::getPgNumString(document, drawingPageCtrl.getPageNum(), (BrINT)wCode, bBuffer);
		}
		else
#endif
			nBufLen = CTextProc::getPgNumString(document, g_pAppStatic->m_nCurPageNum, (BrINT)wCode, bBuffer);

		for (i = 0; i < nBufLen; i++) {
			if (bBuffer[i] == 0) {
				break;
			}
			BChar ch(bBuffer[i]);
			textString->append(ch);
		}
		nFontID = pTextAtt->getHanFontID();
		nFSize = pTextAtt->getHanFSize();
	}
	else if (pLink->isTypesetLink() > 0) {
		if (pLink->isFootnoteEndnoteLink()) {
			BrWORD bBuffer[64] = {0,};

			CFEEngine *fe = document->getFEEngine();
			superScript = fe->determineSuperscriptForDraw(pLink, superScript);
			fe->getNoteString(pLink->getCode(), bBuffer, bSubType, pLine);

			BrINT nLen = CUtil::WcsLen(bBuffer);
			textString->replace(0, textString->length(), (const BChar*)bBuffer, nLen);
			curDrawingTextAtt->setEngFontID(pTextAtt->getEngFontID());

			if (textString->isNull())
				return BrFALSE;
		}
		else {
			return BrFALSE;
		}
	}
	else if (pLink->isBookmarkLink() > 0) {
		return BrFALSE;
	}
	else {
		if (pLink->isFieldLink()) {
			if ((bSubType & START_LINK) != 0 || (bSubType & END_LINK) != 0) {
				return BrFALSE;
			}
			if (document->isFromSlideType()) {
				CLocation location(pLine, nCol);
				if (location.moveToStartOfField(BrTRUE, BrTRUE)) {
					CCharSet *link = location.getCharSet();
					CField *field = link->getField(document);
					if (field && field->getFieldType() == E_FIELD_HYPER && pTextAtt->getHyperlinkColorType() == PoHyperlinkColorType::PoHyperlinkDefaultColor) {
						textColor = document->m_pTheme->getHlinkColor();
					}
				}
			}
		}

		if (pLink->isTextLink() && CTextProc::isCRCode(wCode) && !pLink->isFieldExDummyLink()) {

			// [ZPD-17288][2015.09.09][235] Window UI환경에서 CRCode Export하지 않도록 조건 추가
			if ((BrFALSE == document->getCmdEngine()->IsShowEditSymbol() && BrFALSE == document->getCmdEngine()->getEditSymbolShowState().bCR) || (document->getCmdEngine()->GetDC() && document->getCmdEngine()->GetDC()->isExportMode()))	// AOM-48782
				return BrFALSE;

			bShowTabCR = BrTRUE;
			textString->append((wCode == SOFT_ENTER)?SOFT_ENTER:ASCII_CODE_CR);
			nFontID = 0;

			//dcParam.m_wStyle = 0;

			switch (bSubType) {
				case PAGE_BREAK:  textColor = RGB_BLUE;     break;
				case COL_BREAK:   textColor = RGB_BLUE;     break;
				default:          textColor = RGB_DK2GRAY;  break;  //ZPD-19811 RGB_DKGRAY에서 RGB_DK2GRAY로 변경
			}
		}
		//[ICF-41][2014.04.02] Myungjb 이모티콘 코드가 tab으로 처리되어 return 된 오류 처리
		//[2014.07.24][ZPD-189][고준성] 고정폭 빈 칸 글자 출력 오류 수정

		else if ((wCode == ASCII_CODE_SPACE || wCode == ASCII_CODE_TAB || wCode == NON_BREAKING_SPACE) && !pLink->isFieldExDummyLink()) {
			return BrFALSE;
		}
		else
		{
#ifdef SUPPORT_THEME_FONT
			BrINT nThemeID = theBWordDoc->getThemeID();
			THEME_FONT_SCRIPT themeFontScript = theBWordDoc->m_pTheme->getUserFontScheme(nThemeID)->getFontGroup(pLink->getCode());
			BrBOOL isThemeFont = BrFALSE;
			if (themeFontScript == THEME_FONT_LATIN && pTextAtt->getThemeAscii()) {
				isThemeFont = BrTRUE;
				dcParam.m_nFSize = pTextAtt->getEngFSize();
			}
			else if (themeFontScript == THEME_FONT_EA && pTextAtt->getThemeEastAsia()) {
				isThemeFont = BrTRUE;
				dcParam.m_nFSize = pTextAtt->getHanFSize();
			}
			else if (themeFontScript == THEME_FONT_CS && pTextAtt->getThemeCs()) {
				isThemeFont = BrTRUE;
				dcParam.m_nFSize = pTextAtt->getEngFSize();	//폰트 사이즈 변경 해야함
			}

			if (isThemeFont) {
				dcParam.m_nFontID = document->m_pTheme->getCurrentThemeFontID(pTextAtt, wCode);
			}
			else
#endif
			{
				if (IsHwpSymbol(document, wCode) || pTextAtt->isSymbol()) {
					nFSize = pTextAtt->getHanFSize();
					nFontID = pTextAtt->getSymbolFontID();
				}
				else if (document->isFromHwp() && IS_HANGUL_JAMO(wCode)) {
					nFSize = pTextAtt->getHanFSize();
					nFontID = CTextProc::ConvertOldHanFontId(pTextAtt->getHanFontID());
				} else if (document->isFromHwp() && IsPunctuation(wCode)) {
					nFSize = pTextAtt->getEngFSize();
					nFontID = pTextAtt->getEngFontID();
				}
				//[17.06.09][sglee1206] CJK Symbols and Punctuation도 EastAsianChar로 인식하여야함 [XPD-17321]
				//[18.09.03][sglee1206] CTextEngine에 Arrange 시 조건과 동일하게 Hindi 추가
				else if (CTextProc::isEastAsianChar(wCode) ||
				    IS_UCS2_CJK_Symbols_and_Punctuation(wCode) ||
				    IS_HINDI(wCode)) {
					nFSize = pTextAtt->getHanFSize();
					nFontID = pTextAtt->getHanFontID();
				}
				else {
					nFSize = pTextAtt->getEngFSize();
					nFontID = pTextAtt->getEngFontID();
				}
			}

			//if( textString->length() == 0 )
			{
				//[2012.10.30][ekaloss] bullet 기호까지 -0x20 처리 되어 비정상 출력 수정. <= hnsong:2013-07-04 bullet인지 check하는 것으로 변경
				if (!pLink->isBulletLink() && (pTextAtt->getSmallCaps() || pTextAtt->getCaps())) //소문자를 작은 대문자로, 모두 대문자로
				{
					if (!CTextProc::isWingdingTextAtt(pTextAtt)) {
						if (ALP_MIN2 <= wCode && wCode <= ALP_MAX2) {
							wCode -= 0x20;
							if (pTextAtt->getSmallCaps())
								nFSize *= 0.8;
						}
						else if (CUtil::isLatinSmallLetter(wCode)) // NRV-387
						{
							wCode--;
							if (pTextAtt->getSmallCaps())
								nFSize *= 0.8;
						}
					}
				}
				//Mentis 이슈[21678] 수정
				if (wCode == 0xf023 && CTextProc::isWingdingTextAtt(pTextAtt))
					wCode = wCode & 0x00ff;

				BChar charCode(wCode);
				textString->replace(0, textString->length(), &charCode, 1);
			}
		}
	}

	// HWP 상대크기
	nFSize = PO_TEXTATT_ENGINE::PoTextAttEngine::getRelativeFontSize(nFSize, pTextAtt);

	if (pLine) {
		CFrame* pFrame = pLine->getFrame();
		// drawing하는 font size scaling
		nFSize = pFrame? pFrame->getAutoScaledFontSize(nFSize): nFSize;
	}
	nFSize = du.doc2LogicalDY(nFSize, BrFALSE);

	if (nFSize < 2)
		nFSize = 2;

	if (pLink->isTextLink() && CTextProc::isCRCode(wCode) && !pLink->isFieldExDummyLink() && nFSize < 7)   //XPD-11562 이슈로 인해 수정 8 -> 7 new doc해도 cr이 안 보임
		return BrFALSE;

	if (bShowTabCR && (nFSize > DEF_TAB_SIZE_IN_SHOWCR_MODE))
		nFSize = DEF_TAB_SIZE_IN_SHOWCR_MODE;

#ifdef REMOVE_HYPER_LINK_ATTRIBUTE
	if (IsRemoveHyperlinkAttr(painter, pTextAtt))
		textColor = BLACK_COLOR;
#endif  // REMOVE_HYPER_LINK_ATTRIBUTE

#ifdef SUPPORT_NIGHT_VIEW_MODE
	if (document->isNightViewMode() && bCheckNightMode) {
		textColor = BrXORColor(textColor);
		backColor = BrXORColor(backColor);
	}
#endif  // SUPPORT_NIGHT_VIEW_MODE

	//저시력자용 색상 모드 지원
	BrCOLORREF nLowVisionTextColor = NONE_COLOR_BITS;
	BrCOLORREF nLowVisionBackColor = NONE_COLOR_BITS;
	if (document->getCmdEngine()->GetLowVisionEngine() && document->getCmdEngine()->GetLowVisionEngine()->IsLowVisionColorMode(nLowVisionTextColor, nLowVisionBackColor)) {
		textColor = nLowVisionTextColor;
		backColor = nLowVisionBackColor;
	}

	curDrawingTextAtt->setAutoColor(autoColor);
	curDrawingTextAtt->setHanFSize(nFSize);
	curDrawingTextAtt->setHanExpCom(wExpCom);
	curDrawingTextAtt->setTextColor(textColor);
	curDrawingTextAtt->setBackColor(backColor);
	curDrawingTextAtt->setUnderlineColor(textColor);
	curDrawingTextAtt->setHanFontID(nFontID, pTextAtt->isSymbol());
	curDrawingTextAtt->setSuperscript(superScript);
	curDrawingTextAtt->setSubscript(subScript);
	curDrawingTextAtt->setCaps(pTextAtt->getCaps());
	curDrawingTextAtt->setSmallCaps(pTextAtt->getSmallCaps());
	curDrawingTextAtt->setEmboss(pTextAtt->getEmboss());
	curDrawingTextAtt->setEngrave(pTextAtt->getEngrave());
	curDrawingTextAtt->setShadow(pTextAtt->getShadow());
	curDrawingTextAtt->setOutline(pTextAtt->getOutline());
	curDrawingTextAtt->setItalic(italic);
	curDrawingTextAtt->setBold(bold);

	return BrTRUE;
}


// check invalidate and clip region
// sx, sy : left and top position
// nHeight :  font size
// nWidth : font width
BrBOOL CTextDraw::IsClipRegion(BrINT sx, BrINT sy, BrINT nHeight, BrINT nWidth, CBCell* pCell)
{
	if (nWidth == 0)
		nWidth = nHeight;

	BRect rcDraw;
	rcDraw.nLeft = sx;
	rcDraw.nTop = sy;
	rcDraw.nRight = sx + nWidth;
	rcDraw.nBottom = sy + nHeight;

	// check double clip rectangle (x, y panning simultaneously)
	if (theBWordDoc->getHorClipRectFlag() && theBWordDoc->getVerClipRectFlag()) {
		BRect* pHorClip = theBWordDoc->getHorClipRect();
		BRect* pVerClip = theBWordDoc->getVerClipRect();
		if (pHorClip && pVerClip) {
			if (!rcDraw.IsIntersect(pHorClip) && !rcDraw.IsIntersect(pVerClip)) {
				return BrFALSE;
			}
		}
		return BrTRUE;
	}

	// Check invalidate rectangle ( including one clip rectangle )
	if (!theBWordDoc->IsInInvalidateRect(rcDraw))
		return BrFALSE;

	if (pCell && pCell->getTable()) {
		if (pCell->getTable()->isPreviewTable())
			return BrTRUE;

		if (!pCell->getDisplayRect()->IsEmpty() && !pCell->getDisplayRect()->IsNull()) {
			if (rcDraw.nLeft >= pCell->getDisplayRect()->nRight)
				return BrFALSE;

			if (rcDraw.nRight >= (pCell->getDisplayRect()->nRight + nWidth))
				return BrFALSE;

			//if( !rcDraw.IsIntersect(pCell->getDisplayRect()))
			//	return BrFALSE;
		}
	}
	return BrTRUE;
}


BrBOOL CTextDraw::IsRequireWidth(BYTE bTextFlow, const BrBOOL& isSuper, const BrBOOL& isSub)
{
	BrBOOL bRet = BrFALSE;
	switch (bTextFlow) {
		case TEXTFLOW_SERO: //세로
		case TEXTFLOW_SERO_RTL: //세로형(오른쪽에서 왼쪽)
		case TEXTFLOW_SERO_LTR: //세로형(왼쪽에서 오른쪽)
			if (!isSuper) bRet = BrTRUE;
			break;
		case TEXTFLOW_SERO_90: //모든 텍스트 90도 회전
			if ((isSuper || isSub) != 0) bRet = BrTRUE;
			break;
		case TEXTFLOW_SERO_270: //모든 텍스트 270도 회전
			bRet = BrTRUE;
			break;
	}
	return bRet;
}


BrBOOL CTextDraw::UpdateStaticFont(BFont* font, BrDC* dc, PoDcTextAtt& cur_dc_text_att,
                                   const PoDcTextAtt& prev_dc_text_att, BrBOOL is_horizontal,
                                   BrINT rotate, CDrawUnit& du, const PoTextAtt& text_att,
                                   CFontArray* font_arr, CLine* line)
{
	if (is_horizontal)
		cur_dc_text_att.setRotateValue(rotate);
	else
		font->setFontRotate(rotate);

	BrBOOL is_update = BrFALSE;
	BrCOLORREF text_color = cur_dc_text_att.getTextColor().getColor();

	if (cur_dc_text_att != prev_dc_text_att) {
		if (is_horizontal) {
			BrINT scale = du.getZoomFactor();
			BrINT16 res_x = du.getXResolution();
			BrINT16 res_y = du.getYResolution();
			font->setFontCoordinateType(eNormalCoordinate, scale, res_x, res_y);
			font->setFontWidthRatio(cur_dc_text_att.getHanExpCom());
		}
		else {
			font->setFontWidthRatio(text_att.getHanExpCom());
		}

		BrINT font_size = cur_dc_text_att.getHanFSize();
		if (cur_dc_text_att.getSuperscript() || cur_dc_text_att.getSubscript())
			font_size *= PO_TEXTATT_BASE::superSubScriptSizeRatio;
		font->setFontAttribute(font_size, text_att.getBold(), text_att.getItalic(), text_color);
		font->setFontSize(font_size, DEFAULT_TEXT_HORIZ_SCALE);

		BrUSHORT* font_name;
		if (cur_dc_text_att.isSymbol()) {
            font_name = font_arr->GetAt(cur_dc_text_att.getSymbolFontID())->lf.lfFaceName;
		} else {
            font_name = font_arr->GetAt(cur_dc_text_att.getHanFontID())->lf.lfFaceName;
		}
		font->setFontName(font_name, MAX_FONT_LEN);

		font->setFontEmboss(text_att.getEmboss());
		font->setFontEngrave(text_att.getEngrave());
		font->setFontOutline(text_att.getOutline());
		font->setCharEqualHeight(text_att.isNormalizeH());

		ColorData shadow = (text_att.getShadow() && BrFALSE == text_att.isWaEffected())? RGB_DKGRAY: -1;
		font->setFontShadow(shadow);

		font->setFontRotate(cur_dc_text_att.getRotateValue());
		is_update = BrTRUE;
	}

	if (is_update ||
			DrawCharChangedColor(cur_dc_text_att, prev_dc_text_att) ||
			font->getTextColor() != text_color) {
		BrCOLORREF auto_color = AutoTextColor(line, &cur_dc_text_att);
		font->setFontColor(GetBrRValue(auto_color), GetBrGValue(auto_color), GetBrBValue(auto_color));
		dc->setFont(font);
		return BrTRUE;
	}

	return BrFALSE;
}


BrBOOL CTextDraw::DrawCharChangedColor(const PoDcTextAtt& dcPOld, const PoDcTextAtt& dcPNew)
{
	return dcPOld.getTextColor().getColor() != dcPNew.getTextColor().getColor() ||
	       dcPOld.getBackColor().getColor() != dcPNew.getBackColor().getColor();
}


BrBOOL CTextDraw::ConvertArabic(BString& display, BFont* font,
                                BrWORD uc, CLine* line, BrINT col)
{
#ifdef BIDI_SUPPORT
	if (BrNULL == font || col <= 0)
		return BrFALSE;

	if (BrFALSE == IS_SUPPORT_RTL_CHAR(uc) && BrFALSE == IS_ARABIC_PRESENT_CHAR(uc))
		return BrFALSE;

	const CWordArray& display_code_arr = line->getDisplayCodeArray();
	BrINT size = display_code_arr.size();
	if (size <= 0)
		return BrFALSE;

	BrWORD prev_uc = (1 <= col)? display_code_arr[col - 1]: 0;
	if (0 == prev_uc)
		return BrFALSE;

	return BrTRUE;
#else  // BIDI_SUPPORT
	return BrFALSE;
#endif  // BIDI_SUPPORT
}


BrBOOL CTextDraw::DrawEmphasisBitmap(Painter* painter, BrDC* dc, CFrame* pFrame, CLine* pLine,
                                     BrINT nCol, const PoTextAtt* pTextAtt, BrINT sx, BrINT sy,
                                     BrINT nFontHgt, BrINT nFontWid, BrCOLORREF color,
                                     BrBOOL arg_bIsHorizontalDraw/*=BrTRUE*/)
{
	if (!pLine)
		return BrFALSE;

	if (pTextAtt->isConCur())	//[ZPD-5683]MS Word 2013은 윗주와 강조점이 같이 있으면 강조점을 그리지 않는다.
		return BrTRUE;

	BrGrapAtt* grapAtt = pTextAtt->getGrapAtt();
	if (!grapAtt)
		return BrFALSE;

	if (!arg_bIsHorizontalDraw || (grapAtt->isNullPen() && !pTextAtt->isWaEffected())) {
		//solid brush + null pen일 경우 bitmap 사용하지 않음
		DrawEmphasis(dc, pTextAtt, sx, sy, nFontHgt, nFontWid, grapAtt->getBrushColor());
		return BrTRUE;
	}

	BrShapeProxy shape(SHAPE_TextPlainText);
	BrBOOL bCreateAttr = shape.createFreeFormShapeAttrs();
	BrBOOL bCreatePolygon = shape.createPolygon();
	if (!bCreateAttr || !bCreatePolygon)
		return BrFALSE;

	BrBYTE oldMode = dc->setExportMode(eNormalExtMode);

	shape.setOffice2007Shape(BrTRUE);
	shape.copy(*grapAtt);
	//현재 구조에서 텍스트와 함께 그림자/반사 등의 효과를 렌더링하려면 bitmap 크기를 조정하면 되나, 오버헤드가 우려되어 제한적으로 그림자 지원
	//전체 지원 여부는 테스트 후 판단 필요
	STPercentage shadowY = shape.hasOuterShdw() ? shape.getOuterShdw().sy : 100000;
	if (shadowY != 100000)
		shape.setDrawOption(BrPROXY_OUTERSHDW, BrFALSE);
	shape.setDrawOption(BrPROXY_REFLECT, BrFALSE);
	shape.setDrawOption(BrPROXY_3DRENDERING, BrFALSE);
	shape.setDrawOption(BrPROXY_3DBEVEL_RENDERING, BrFALSE);

	shape.getPolygon()->resize(0);
	BArray<BrShapeSegment>& segments = shape.getFreeFormShapeAttrs()->aSegments;

	BrWORD fontSize = TWIPtoPT(pTextAtt->getHanFSize());
	BrPoint offset;
	offset.x = sx;
	offset.y = sy;

	unique_ptr<BrShapeEffectBitmaps> pBitmaps;
	BFont* oldFont = BrNULL;

	BrINT nEmphasisType = pTextAtt->getEmphasisType();
	switch (nEmphasisType) {
		case BR_EMPHASIS_THAIRISING:
		case BR_EMPHASIS_VETNAMDAUNGA:
		case BR_EMPHASIS_THAILOW:
		case BR_EMPHASIS_THAIHIGH:
		case BR_EMPHASIS_THAIFALLING:
		case BR_EMPHASIS_THAIMID:
		case BR_EMPHASIS_VETNAMDAUHOI:
		{
			BrWORD wCode = GetCombiningDiacriticalMarks(nEmphasisType);

			BString qStrBuffer;
			qStrBuffer.insert(0, (BChar)wCode);

			BFont newBFont;
			BRCHAREFFECTINFO charInfo = {BRect(0,0,0,0), 0,0,0,0,0,0,0,0, BrFALSE};
			charInfo.nWidth = twips2DeviceX(pTextAtt->getHanFSize() / 2, painter->getZoomScale(), painter->m_iResX);

			BrWORD wEmphasisFontName[MAX_FONT_LEN] = {0xD3F4, 0xB77C, 0xB9AC, 0xC2A4, 0xBC14, 0xD0D5, 0x00};
			newBFont.setFontName((BrUSHORT*)wEmphasisFontName, MAX_FONT_LEN);
			newBFont.setFontAttribute(nFontHgt, pTextAtt->getBold(), BrFALSE);
			newBFont.setFontSize(nFontHgt, DEFAULT_TEXT_HORIZ_SCALE);
			newBFont.setFontColor(GetBrRValue(color), GetBrGValue(color), GetBrBValue(color));
			oldFont = dc->setFont(&newBFont);

			MakeWordArtDrawInfo(painter, dc, pLine->getCharSet(nCol), pTextAtt, pLine, nCol,
			                    qStrBuffer, sx, sy, shape, charInfo, BrTRUE);
			GetEmphasisOffset(dc, nFontHgt, nFontWid, pTextAtt->getEmphasisType(),
			                  offset.x, offset.y, arg_bIsHorizontalDraw);

			pBitmaps = MakeTextEffect(painter, dc, pTextAtt, pLine, nCol, qStrBuffer, 0, 0, charInfo, &shape);
		}
		break;
		default:
		{
			dc->setNeedOutline(shape.getPolygon(), &segments, offset);
			DrawEmphasis(dc, pTextAtt, sx, sy, nFontHgt, nFontWid, color, arg_bIsHorizontalDraw);
			dc->setNeedOutline(BrNULL, BrNULL, offset);

			shape.getPolygon()->translate(
				CDrawUnit::cvtLogical2DocX(offset.x, painter->m_iResX, painter->getZoomScale()),
				CDrawUnit::cvtLogical2DocY(offset.y, painter->m_iResY, painter->getZoomScale()));

			BrPoint offset1;
			offset1.x = sx - fontSize;
			offset1.y = sy - fontSize;
			GetEmphasisOffset(dc, nFontHgt, nFontWid, pTextAtt->getEmphasisType(),
			                  offset1.x, offset1.y, arg_bIsHorizontalDraw);
			offset = offset1;

			shape.getPolygon()->translate(
				-CDrawUnit::cvtLogical2DocX(offset.x, painter->m_iResX, painter->getZoomScale()),
				-CDrawUnit::cvtLogical2DocY(offset.y, painter->m_iResY, painter->getZoomScale())
			);

			BRCHAREFFECTINFO charInfo = {BRect(0,0,0,0), 0,0,0,0,0,0,0,0, 3/* Emphasis */};
			BString qStrBuffer(" ");

			BRect boundrect = shape.getPolygon()->boundingRect();
			charInfo.nWidth = twips2DeviceX(boundrect.nRight, painter->getZoomScale(), painter->m_iResX);
			charInfo.rcFrame = pFrame ? pFrame->getFrameRect() : BRect(0, 0, 0, 0);
			charInfo.nDescent = dc->m_pFont->getCharDescent();
			charInfo.nCharLineW = BrMAX(charInfo.nDescent * 0.5, 2);
			charInfo.nHeight = dc->m_pFont->getCharHeight() + charInfo.nDescent;
			charInfo.nFontHeight = dc->m_pFont->getFontCharHeight();
			charInfo.nCHExtraHeight = dc->m_pFont->getCharHeight() * 0.15;
			charInfo.nHeightWithExtra = charInfo.nHeight + charInfo.nCHExtraHeight;

			pBitmaps = MakeTextEffect(painter, dc, pTextAtt, pLine, nCol, qStrBuffer, 0, 0, charInfo, &shape);
		}
		break;
	}

	if (!pBitmaps)
		return BrFALSE;
	pBitmaps->draw(dc, offset, painter);

	if (oldFont)
		dc->setFont(oldFont);
	dc->setExportMode(oldMode);
	return BrTRUE;
}


void CTextDraw::DrawEmphasis(BrDC* dc, const PoTextAtt* pTextAtt, BrINT sx, BrINT sy, BrINT nFontHgt,
                             BrINT nFontWid, BrCOLORREF color, BrBOOL arg_bIsHorizontalDraw)
{
	// 2007에서만 현상이라서 삭제
	// BR_EMPHASIS_KOREAHIGH, BR_EMPHASIS_KOREALOWHHIGH 속성인 경우 라인의 같은 속성 첫 글자만 적용해 준다.
	/*
	if ( pLine && (nEmphasisType==BR_EMPHASIS_KOREAHIGH || nEmphasisType==BR_EMPHASIS_KOREALOWHHIGH) )
	{
		PoTextAtt* text_att;
		CCharSet* pNode = pLine->getCharSet(nCol);
		if ( !pNode || !pNode->isTextLink() || pNode->isWhiteCharacterLink(BrTRUE) )
			return;

		nCol--;
		while ( nCol>=0 )
		{
			pNode = pLine->getCharSet(nCol);
			text_att = theBWordDoc->getTextAttHandler()->GetAt(pNode->getAttrID());
			// different emphasis
			if ( !text_att || (text_att->getEmphasisType()!=BR_EMPHASIS_KOREAHIGH && text_att->getEmphasisType()!=BR_EMPHASIS_KOREALOWHHIGH) )
				break;
			// check text character with same emphasis
			if ( pNode && pNode->isTextLink() && !pNode->isWhiteCharacterLink(BrTRUE) )
				return;
			nCol--;
		}
	}
	*/

	BrEXPORT_INFO sOldExtInfo = {0};
	dc->getExport(&sOldExtInfo);

	BrINT nEmphasisType = pTextAtt->getEmphasisType();
	switch (nEmphasisType) {
		case BR_EMPHASIS_DOT:
		case BR_EMPHASIS_COMMA:
		case BR_EMPHASIS_KOREAHIGH:
		case BR_EMPHASIS_KOREALOWHIGH:
		case BR_EMPHASIS_VETNAMDAUNANG:
		case BR_EMPHASIS_DISK:
		{
			BrBmvPen pen, * pOldPen;
			BrBmvBrush brush, * pOldBrush;

			BrINT penWidth = (nFontHgt / 10 + 2) >> 2;
			if (penWidth < 1)
				penWidth = 1;

			if (nEmphasisType == BR_EMPHASIS_COMMA) {
				pen.createPen(eSolidPen, penWidth, color);
				brush.createNullBrush();
			}
			else {
				pen.createPen(eNullPen, 0, 0);
				brush.createSolidBrush(color);
			}

			pOldPen = dc->setPen(&pen);
			pOldBrush = dc->setBrush(&brush);

			BrINT nWidth = 0;
			if (arg_bIsHorizontalDraw) {
				if (nEmphasisType == BR_EMPHASIS_KOREAHIGH || nEmphasisType == BR_EMPHASIS_KOREALOWHIGH) {
					nWidth = nFontHgt / 6;
					if (nWidth == 0)
						nWidth = 1;
				}
				else {
					nWidth = nFontHgt / 10;
					if (nWidth == 0)
						nWidth = 1;
				}
			}
			else {
				if (nEmphasisType == BR_EMPHASIS_KOREAHIGH || nEmphasisType == BR_EMPHASIS_KOREALOWHIGH) {
					nWidth = nFontHgt / 5;
					if (nWidth == 0)
						nWidth = 1;
				}
				else {
					nWidth = nFontHgt / 10;
					if (nWidth == 0)
						nWidth = 1;
				}
			}

			GetEmphasisOffset(dc, nFontHgt, nFontWid, nEmphasisType, sx, sy, arg_bIsHorizontalDraw);

			if (nEmphasisType == BR_EMPHASIS_DOT || nEmphasisType == BR_EMPHASIS_VETNAMDAUNANG || nEmphasisType == BR_EMPHASIS_KOREAHIGH || nEmphasisType == BR_EMPHASIS_COMMA) {		// solid pen
				BrBOOL bEmphasisType = (nEmphasisType == BR_EMPHASIS_COMMA);
				nWidth = bEmphasisType ? nWidth : nWidth / 2;

				if (nWidth == 0)
					nWidth = 1;

				//[2014.12.05][ZPD-5262] pdf export 시에 강조점을 이미지로 뜰 때, dc 전체의 크기가 아니라 원문자 크기만큼만 bitmap을 떠서 export 해야한다.
				//BR_EMPHASIS_COMMA 만 수정 하지만, 추후 다른 강조점들도 똑같이 적용해야 할 것. ( 중요 : bitmap 크기는 pen width를 고려하여 잡을 것 )
				//[2016.03.21][235][ZPD-27434] BR_EMPHASIS_DOT, BR_EMPHASIS_VETNAMDAUNANG, BR_EMPHASIS_KOREAHIGH 강조점에 대해서도 BR_EMPHASIS_COMMA와 같이 수정
				BRect rcDrawRect(sx - nWidth, sy - nWidth, sx + nWidth, sy + nWidth);
				BrINT nCommaHeight = (nFontHgt << 1) / 10;
				if (bEmphasisType && (nCommaHeight > rcDrawRect.getHeight())) {
					rcDrawRect.nRight = rcDrawRect.nLeft + nCommaHeight;
					rcDrawRect.nBottom = rcDrawRect.nTop + nCommaHeight;
				}

				BrINT nPenWidth = dc->m_pPen->getPenWidth();

				// [2015.12.10][235]ZPD-22620, ZPD-5262 Offset을 move하여 Drawing 후에, Export시에 실제 위치에 그려질 수 있도록 Offset을 옮기도록 수정
				dc->setBitmap2(rcDrawRect.getWidth() + (nPenWidth * 2), rcDrawRect.getHeight() + (nPenWidth * 2));
				dc->setExport(rcDrawRect.nLeft + sOldExtInfo.nPosX - nPenWidth, rcDrawRect.nTop + sOldExtInfo.nPosY - nPenWidth, rcDrawRect.nRight - rcDrawRect.nLeft, rcDrawRect.nBottom - rcDrawRect.nTop, 0);

				if (isExportMode()) {
					rcDrawRect.Move(-rcDrawRect.nLeft + nPenWidth, -rcDrawRect.nTop + nPenWidth);
					dc->enableAlphaBitmapDC(BrTRUE);
				}

				if (bEmphasisType)
					dc->frameEllipse(rcDrawRect.Left(), rcDrawRect.Top(), rcDrawRect.Right(), rcDrawRect.Bottom());
				else
					dc->fillEllipse(rcDrawRect.Left(), rcDrawRect.Top(), rcDrawRect.Right(), rcDrawRect.Bottom());

				if (isExportMode())
					dc->enableAlphaBitmapDC(BrFALSE);
			}
			else if (nEmphasisType == BR_EMPHASIS_KOREALOWHIGH) {
				nWidth = nWidth / 2;
				if (nWidth == 0)
					nWidth = 1;
				dc->fillEllipse(sx - nWidth, sy - nWidth, sx + nWidth, sy - (3 * nWidth));
				dc->fillEllipse(sx - nWidth, sy + nWidth, sx + nWidth, sy + (3 * nWidth));
			}
			else if (nEmphasisType == BR_EMPHASIS_DISK) {
				dc->fillEllipse(sx - nWidth, sy - nWidth, sx + nWidth, sy + nWidth);
			}

			dc->setBrush(pOldBrush);
			dc->setPen(pOldPen);
		}
		break;
		case BR_EMPHASIS_THAIRISING:
		case BR_EMPHASIS_VETNAMDAUNGA:
		case BR_EMPHASIS_THAILOW:
		case BR_EMPHASIS_THAIHIGH:
		case BR_EMPHASIS_THAIFALLING:
		case BR_EMPHASIS_THAIMID:
		case BR_EMPHASIS_VETNAMDAUHOI:
		{
			BrINT nWidth = 0;
			BrWORD wCode = GetCombiningDiacriticalMarks(nEmphasisType);
			if (0 == wCode)
				return;

			if (arg_bIsHorizontalDraw) {
				nWidth = nFontHgt / 10;
				if (nWidth == 0)
					nWidth = 1;
			}
			else {
				nWidth = nFontHgt / 10;
				if (nWidth == 0)
					nWidth = 1;
				return;
			}

			BFont newBFont, * oldFont;
			newBFont.setFontAttribute(nFontHgt, pTextAtt->getBold(), pTextAtt->getItalic());
			newBFont.setFontSize(nFontHgt, DEFAULT_TEXT_HORIZ_SCALE);
#ifndef WINDOWS_8
			newBFont.setFontName((BrUSHORT*)theBWordDoc->getFontArray()->GetAt(pTextAtt->getHanFontID())->lf.lfFaceName, MAX_FONT_LEN);
#else
			//[15.05.29][sglee1206] PC Version에서는 항상 폴라리스 바탕으로 처리하도록 함. SRG-1109
			BrWORD wEmphasisFontName[MAX_FONT_LEN] = {0xD3F4, 0xB77C, 0xB9AC, 0xC2A4, 0xBC14, 0xD0D5, 0x00};
			newBFont.setFontName((BrUSHORT*)wEmphasisFontName, MAX_FONT_LEN);
#endif
			// newBFont.setFontWidthRatio(cTextAtt.getHanExpCom());
			newBFont.setFontEmboss(pTextAtt->getEmboss());
			newBFont.setFontEngrave(pTextAtt->getEngrave());
			newBFont.setFontOutline(pTextAtt->getOutline());
			newBFont.setCharEqualHeight(pTextAtt->isNormalizeH());
			// newBFont.setFontRotate(0);
			newBFont.setFontColor(GetBrRValue(color), GetBrGValue(color), GetBrBValue(color));

			oldFont = dc->setFont(&newBFont);

			BString strBuffer;
			strBuffer.insert(0, (BChar)wCode);

			GetEmphasisOffset(dc, nFontHgt, nFontWid, nEmphasisType, sx, sy, arg_bIsHorizontalDraw);
			dc->drawChars(&strBuffer, sx, sy);

			dc->setFont(oldFont);
		}
		break;
		case BR_EMPHASIS_ACCENT:
		{
			BFont newBFont, * oldFont;
			newBFont.setFontAttribute(nFontHgt, pTextAtt->getBold(), pTextAtt->getItalic());
			newBFont.setFontSize(nFontHgt, DEFAULT_TEXT_HORIZ_SCALE);
			newBFont.setFontName((BrUSHORT*)L"Arial", MAX_FONT_LEN); //font는 Arial로 통일
			newBFont.setFontEmboss(pTextAtt->getEmboss());
			newBFont.setFontEngrave(pTextAtt->getEngrave());
			newBFont.setFontOutline(pTextAtt->getOutline());
			newBFont.setCharEqualHeight(pTextAtt->isNormalizeH());
			newBFont.setFontColor(GetBrRValue(color), GetBrGValue(color), GetBrBValue(color));
			newBFont.setFontRotate(180);

			oldFont = dc->setFont(&newBFont);
			BString strBuffer;
			strBuffer.insert(0, (BChar)0x02ce);

			GetEmphasisOffset(dc, nFontHgt, nFontWid, nEmphasisType, sx, sy, arg_bIsHorizontalDraw);
			dc->drawChars(&strBuffer, sx, sy);

			dc->setFont(oldFont);
		}
		break;
	}

	dc->setExport(&sOldExtInfo);
	dc->setBitmap2(-1, -1);
}


BrWORD CTextDraw::GetCombiningDiacriticalMarks(BrINT emphasis_type)
{
	switch (emphasis_type) {
		case BR_EMPHASIS_THAIRISING:    return 0x030C;  // Combining Caron
		case BR_EMPHASIS_VETNAMDAUNGA:  return 0x0303;  // Combining Tilde
		case BR_EMPHASIS_THAILOW:       return 0x0300;  // Combining Grave Accent
		case BR_EMPHASIS_THAIHIGH:      return 0x0301;  // Combining Acute Accent
		case BR_EMPHASIS_THAIFALLING:   return 0x0302;  // Combining Circumflex Accent
		case BR_EMPHASIS_THAIMID:       return 0x0304;  // Combining Macron
		case BR_EMPHASIS_VETNAMDAUHOI:  return 0x0309;  // Combining Hook Above
	}
	return 0;
}


BrBOOL CTextDraw::MakeWordArtDrawInfo(Painter* painter, BrDC* dc, CCharSet* pLink,
                                      const PoTextAtt* pTextAtt, CLine* pLine, BrINT nCol,
                                      BString& qStrBuffer, BrINT sx, BrINT sy, BrShapeProxy& shape,
                                      BRCHAREFFECTINFO& charInfo, BrBOOL isEmphasis)
{
	if (!dc || !pLink || !pTextAtt || !painter || !pLine)
		return BrFALSE;

	BoraDoc *document = theBWordDoc;
	CFrame* pFrame = pLine->getFrame();
	BrBOOL bPolygon = pTextAtt->isWaPolygon() || (pTextAtt->getOutline() && !pTextAtt->getGrapAtt()->isNullBrush());

	int total_width = 0;
	for (int i = 0; i < qStrBuffer.length(); ++i) {
		total_width += dc->m_pFont->getCharBitmapWidth(qStrBuffer.at(i).unicode());
	}

	charInfo.rcFrame = pLine->getFrame() ? pLine->getFrame()->getFrameRect() : BRect(0, 0, 0, 0);
	if (!isEmphasis)
		charInfo.nWidth = total_width;
	if (!bPolygon && pFrame && pFrame->getTextFlow() != TEXTFLOW_GARO)
		charInfo.nWidth *= 2;

	charInfo.nDescent = dc->m_pFont->getCharDescent();
	charInfo.nCharLineW = BrMAX(charInfo.nDescent * 0.5, 2);
	charInfo.nHeight = dc->m_pFont->getCharHeight() + charInfo.nDescent;	//[2014. 4. 11] ejjeong. 맑은 고딕 g, j가 잘리는 문제로 여유있게 잡음
	charInfo.nFontHeight = dc->m_pFont->getFontCharHeight();
	charInfo.nCHExtraHeight = dc->m_pFont->getCharHeight() * 0.15;
	if (dc->m_pFont->getFontAtts_Italic())
		charInfo.nWidth += 0.25 * charInfo.nFontHeight;	//italic의 shear d값은 0.25 (1<<16)>>2 / (1<<16)

	// [JIRA] XRF-3224 Doc과 ppt의 반사효과가 영역이 다르게 잡히는데 그 원인으로 Doc의 문단 계산 방법이 다른 것으로 추정
	// 따라서 Default LineSpace인 1.0으로 계산하여 (Font마다 다름) ppt와의 차이를 보정해 줌.
	// extraHead에 더해지는 값이므로 아래쪽 Bottom Descent 영역 계산에 Side 없다고 보고, 이 값들은 ChunkFillBitmap의 Size에 반영해야 함.

	// [NDE-280]
	BrWORD ch = qStrBuffer.at(0).unicode();
	if (pFrame && !pTextAtt->isWaPolygon()) {
		BrShape *pShape = pFrame->getBorder();
		if (pShape) {
			BrINT nLineSp = 0;
			const PoParaAtt *paraAtt = document->getParaAttHandler()->getMergedParaAtt(pLine->getParaID(), pLine);

			// word 세로쓰기 고도화 관련. 270도 회전시엔 크기를 늘리지 말자
			BrBYTE frameTextFlow = pFrame->getTextFlow();
			if (document->isFromDoc() && frameTextFlow != TEXTFLOW_SERO_270 && !(frameTextFlow == TEXTFLOW_GARO_ROTATE && (IS_MODERN_KOREAN(ch) || IS_HANJA(ch)))) {
				nLineSp = pLine->getLineSpForMultiple(1.0, paraAtt->isFixLineNum(), (document->isFromDoc() && paraAtt->getBulletID()) ? BrFALSE : BrTRUE);
				nLineSp = twips2DeviceX(nLineSp, painter->getZoomScale(), painter->m_iResX);
				charInfo.nLineSpace = (BrDOUBLE)nLineSp / 2;
			}
		}
	}
	charInfo.nHeightWithExtra = charInfo.nHeight + charInfo.nCHExtraHeight + charInfo.nLineSpace;

	if (!bPolygon && !pTextAtt->isWaChunkFill())
		return BrFALSE;

	shape.copy(*pTextAtt->getGrapAtt());

	//슬라이드 에서 하이퍼 링크는 fill속성(그라데이션, 패턴)무시. 하이퍼링크 색상만 적용.
	BrINT nOrgBrushStyle = shape.getBrush()->getStyle();
	if (document->getDocType() == BORA_DOCTYPE_PPTX && IsHyperlinkColorNode(document, pLine, nCol))
		shape.getBrush()->setStyle(BMV_FILLTYPE_SOLID);

	if (shape.getDashStyle() == BMV_DASHSTYLE_SOLID)
		shape.setLineCap(eRoundLineCap);

	PrBitmap *pChunkFill = pLine->getWaChunkFillBitmap(pLink->getAttrID());

	BrBOOL bisBrushFill = pTextAtt->isWaChunkFill();	//Gradation 또는 Image 채우기인 경우
	BrBOOL bWaPolygon = pTextAtt->isWaPolygon();		//도형화 WordArt
	if (bisBrushFill && !bWaPolygon && !pChunkFill) {
		pChunkFill = MakeCharGroupFillBitmap(painter, dc, pLink, pTextAtt, pLine, nCol,
			qStrBuffer, sx, sy, shape, charInfo);
	}

	shape.setBorderStyle(SHAPE_TextPlainText);

	BrBOOL bCreateAttr = shape.createFreeFormShapeAttrs();
	if (!bCreateAttr)
		return BrFALSE;

	BrBOOL bCreatePolygon = shape.createPolygon();
	if (!bCreatePolygon)
		return BrFALSE;
	shape.getPolygon()->resize(0);
	BArray<BrShapeSegment> &segments = shape.getFreeFormShapeAttrs()->aSegments;

	if (bisBrushFill && !bWaPolygon && pChunkFill) {
		UpdateCharBaseFillFromGroup(painter, dc, pLink, pTextAtt, pLine, nCol, qStrBuffer,
			sx, sy, shape, pChunkFill, charInfo);
	}

	//brush style 복원
	shape.getBrush()->setStyle(nOrgBrushStyle);

	if (!bPolygon) {
		shape.clearImage(BrTRUE);
		return BrTRUE;
	}

	BRect rcCharDev(0, 0, charInfo.nWidth, charInfo.nHeight + charInfo.nLineSpace);
	BRect rcChar;
	rcChar.nLeft = Device2twips(rcCharDev.nLeft, painter->getZoomScale(), painter->m_iResX);
	rcChar.nTop = Device2twips(rcCharDev.nTop, painter->getZoomScale(), painter->m_iResY);
	rcChar.nRight = Device2twips(rcCharDev.nRight, painter->getZoomScale(), painter->m_iResX);
	rcChar.nBottom = Device2twips(rcCharDev.nBottom - charInfo.nDescent, painter->getZoomScale(), painter->m_iResY);

	BFont font, *pOldFont = BrNULL;
	BrBOOL bBold = pTextAtt->getBold();
	BrBOOL bItalic = pTextAtt->getItalic();
	CFEEngine *fe = document->getFEEngine();
	BrBOOL superScript = fe->determineSuperscriptForDraw(pLink, pTextAtt->getSuperscript());

	//2014-10-08 //ZPD-2542 20hoon //웟첨자/아래첨자일때는 기존 폰트사이즈의 65%로 폰트 사이즈를 줄여서 그립니다.
	//윤곽선 적용후, 웟첨자/아래첨자 적용하면, 크기가 그대로여서 위가 짤리거나, 아래가 짤려서 수정합니다.
	BrINT nFontSize = (superScript || pTextAtt->getSubscript()) ? (BrINT)(pTextAtt->getHanFSize() * PO_TEXTATT_BASE::superSubScriptSizeRatio) : pTextAtt->getHanFSize();
	if (pLine) {
		// drawing하는 font size scaling
		CFrame *pFrame = pLine->getFrame();
		nFontSize = pFrame ? pFrame->getAutoScaledFontSize(nFontSize) : nFontSize;
	}
	nFontSize = PO_TEXTATT_ENGINE::PoTextAttEngine::getRelativeFontSize(nFontSize, pTextAtt);

	BrWORD nFontID = /*IS_MODERN_KOREAN(ch)*/IsFullWidthChar(pLink->getCode()) ? pTextAtt->getHanFontID() : pTextAtt->getEngFontID();

	if (isEmphasis) {
		BrWORD wEmphasisFontName[MAX_FONT_LEN] = { 0xD3F4, 0xB77C, 0xB9AC, 0xC2A4, 0xBC14, 0xD0D5, 0x00 };
		font.setFontName((BrUSHORT *)wEmphasisFontName, MAX_FONT_LEN);
		font.setFontAttribute(nFontSize, pTextAtt->getBold(), BrFALSE);
	}
	else {
		font.setFontWidthRatio(pTextAtt->getHanExpCom());
		font.setFontName(document->getFontArray()->getFaceName(nFontID), MAX_FONT_LEN);
		font.setFontAttributeEx(nFontSize, bBold, bItalic);
	}

	//[JIRA] ZPD-11864 Bullet의 Wingding Outline 가져오지 못하는 문제 수정
	//Bullet의 FontName은 Wingding이지만 Unicode가 다르다. PO 엔진에서 Wingding의 Unicode는 F0을 붙여야 함.
	BrUSHORT *pFontName = document->getFontArray()->getFaceName(nFontID);
	BrBOOL bisWingdingFont = CUtil::isWingdingFont(pFontName);
	BrBOOL bNeedRearrangePolygon = BrFALSE;

	if (shape.getPen()) {
		//1. Line이 굵고 얇게, 얇고 굵게 겹선이면 시계방향으로 재정렬해야 함.
		//2. Dash가 점선으로 이루어진 경우 Polygon 시작 위치는 좌측 상단부터이다.
		BrINT nLineStyle = shape.getPen()->getLineStyle();
		BrINT nDashStyle = shape.getPen()->getDashStyle();
		BrBOOL bThickThinLine = nLineStyle == BMV_LINESTYLE_THICKTHIN || nLineStyle == BMV_LINESTYLE_THINTHICK;
		BrBOOL bDotDash = nDashStyle != BMV_DASHSTYLE_NONE && nDashStyle != BMV_DASHSTYLE_NOLINE && nDashStyle != BMV_DASHSTYLE_SOLID;
		bNeedRearrangePolygon = bThickThinLine || bDotDash;
	}

	BrINT32 prev_width = 0;
	for (int i = 0; i < qStrBuffer.length(); ++i) {
		BrWORD ch = qStrBuffer.at(i).unicode();
		BrINT32 nBitmapWidth = dc->m_pFont->getCharBitmapWidth(ch);

		if (bPolygon) {
			pOldFont = dc->setFont(&font);

			if (bisWingdingFont)
				ch |= (BrWORD)0xF000;

			bPolygon = BrShapeUtil::getWordPoints(font, ch, rcChar, prev_width, 0, 0, *shape.getPolygon(), segments, bNeedRearrangePolygon);

			if (isEmphasis) {
				BRect boundingRect = shape.getPolygon()->boundingRect();
				BrINT dist = twips2DeviceX(boundingRect.nLeft, painter->getZoomScale(), painter->m_iResX);
				if (dist < 0)
					charInfo.nWidth = -dist;
				shape.getPolygon()->translate(CDrawUnit::cvtLogical2DocX(charInfo.nWidth, painter->m_iResX, painter->getZoomScale()), 0);
			}

			dc->setFont(pOldFont);
		}

		//prev_width += nBitmapWidth;
		prev_width += Device2twips(nBitmapWidth, painter->getZoomScale(), painter->m_iResX);
	}

	shape.clearImage(BrTRUE);
	return BrTRUE;
}


PrBitmap* CTextDraw::MakeCharGroupFillBitmap(Painter* painter, BrDC* dc, CCharSet* pLink,
                                            const PoTextAtt* pTextAtt, CLine* pLine, BrINT nCol,
                                            BString& qStrBuffer, BrINT sx, BrINT sy,
                                            BrShapeProxy& shape, BRCHAREFFECTINFO charInfo)
{
	if (!dc || !pLink || !pTextAtt || !painter)
		return BrNULL;

	BrBOOL bPolygon = pTextAtt->isWaPolygon()
		|| (pTextAtt->getOutline() && !pTextAtt->getGrapAtt()->isNullBrush());

	// [JIRA] XRF-3224 Doc과 ppt의 반사효과가 영역이 다르게 잡히는데 그 원인으로 Doc의 문단 계산 방법이 다른 것으로 추정
	// 따라서 Default LineSpace인 1.0으로 계산하여 (Font마다 다름) ppt와의 차이를 보정해 줌.
	CFrame* pFrame = pLine->getFrame();
	const PoParaAtt* paraAtt = theBWordDoc->getParaAttHandler()->getMergedParaAtt(pLine->getParaID(), pLine);

	BrDrawUnit dUnit;
	dUnit.setOrg(0, 0);
	PrBitmap* pChunkFill = BrNULL;
	BrINT nHeight = charInfo.nHeight + charInfo.nLineSpace;
	if (!bPolygon) {
		//2013. 12. 16 정의준. MS는 더 큰 CharBitmap을 가져 옴. 그 차이를 보정하기 위한 값
		//BrINT extraGap = dc->m_pFont->getCharHeight()*0.15;		//magic number 적용 전
		BrINT extraGap = BrShapeMagicNumber::getCharBottomExtraGap(dc->m_pFont->getCharHeight());
		nHeight += extraGap;
	}

	//PoParaAtt *pParaAtt = theBWordDoc->getParaAttArray()->getAttr(pLine->getParaID());
	BrINT nLineHeight = pLine->getHeight() + paraAtt->getLineSpace(pLine);

	BRect rcLine;
	BrINT nLastPosId = pLine->getPosArray().GetSize() - 1;
	BrINT nLastCharId = pLine->getCharSetArray()->GetSize() - 1;
	CCharSet wCh = *pLine->getCharSetArray()->GetAt(nLastCharId);
	if (wCh.getCode() == '\r' || wCh.getCode() == '\n')
		nLastCharId--;
	nLastCharId = BrMAX(nLastCharId, 0);
	BrINT nRightPosId = nLastCharId < nLastPosId ? nLastCharId + 1 : nLastPosId;

	BrINT nHeightTwip = Device2twips(nHeight, painter->getZoomScale(), painter->m_iResY);
	BrINT nPosYTwip = Device2twips(sy, painter->getZoomScale(), painter->m_iResY);

	CCharSet chLast = *pLine->getCharSetArray()->GetAt(nLastCharId);
	BrINT nLastCharWidth = dc->m_pFont->getCharWidth(chLast.getCode());
	if (dc->m_pFont->getFontAtts_Italic())
		nLastCharWidth += 0.25 * charInfo.nFontHeight;	//italic의 shear d값은 0.25 (1<<16)>>2 / (1<<16)
	BrINT nWidthTwip = Device2twips(nLastCharWidth, painter->getZoomScale(), painter->m_iResX);
	BrINT32 nLastCharPos = *pLine->getPosArray().GetAt(nLastCharId);
	BrINT32 nLineEndPos = nLastCharPos + nWidthTwip;

	//[JIRA] XRF-3278 Font의 크기가 커지면 A자 같이 화면을 전체 채우는 글자는 OutLine만큼이 잘린다.
	BrWORD ch = 0;
	const BChar* pCh = qStrBuffer.unicode();
	if (pCh)
		ch = pCh->unicode();
	BrINT nFontSize = IS_MODERN_KOREAN(ch) ? pTextAtt->getHanFSize() : pTextAtt->getEngFSize();
	nFontSize /= 20.;
	BPoint fontSize(nFontSize, 0);

	rcLine.nLeft = *pLine->getPosArray().GetAt(0);
	rcLine.nTop = nPosYTwip;
	rcLine.nRight = nLineEndPos;
	rcLine.nBottom = rcLine.nTop + nHeightTwip;

	//2014. 1. 20 정의준. 세로 Text Gradient 지원
	//CFrame* pFrame = pLine->getFrame();
	BrINT nTextFlow = pFrame->getTextFlow();		//정의준 text flow

	shape.setBorderStyle(SHAPE_Rectangle);
	BrImageArray* pImageArray = theBWordDoc->getImageArray();

	if ((nTextFlow == TEXTFLOW_SERO_RTL) || (nTextFlow == TEXTFLOW_SERO_LTR)) {
		//RTL, LTR은 한글자 단위로 그라데이션 들어감
		rcLine.nLeft = *pLine->getPosArray().GetAt(0);
		rcLine.nTop = nPosYTwip;
		rcLine.nRight = rcLine.nLeft + nWidthTwip;
		rcLine.nBottom = rcLine.nTop + nHeightTwip;
		pChunkFill = shape.getGroupFillBitmap(painter, dc, rcLine, dUnit, pImageArray, 0, nTextFlow);
	}
	else {
		BrINT sero_90ExtraHeight = (nTextFlow == TEXTFLOW_SERO_90) || (nTextFlow == TEXTFLOW_SERO) || (nTextFlow == TEXTFLOW_SERO_270) ? nLastCharPos + nWidthTwip : 0;
		pChunkFill = shape.getGroupFillBitmap(painter, dc, rcLine, dUnit, pImageArray, sero_90ExtraHeight, nTextFlow);
	}
	//DumpImage(pChunkFill->getDib(), -1500, 100, BrFALSE);
	pLine->addWaChunkFillBitmap(pLink->getAttrID(), pChunkFill, painter, shape.getColorMode(), shape.isNightView());

	return pChunkFill;
}


BrBOOL CTextDraw::UpdateCharBaseFillFromGroup(Painter* painter, BrDC* dc, CCharSet* pLink,
                                              const PoTextAtt* pTextAtt, CLine* pLine, BrINT nCol,
                                              BString& qStrBuffer, BrINT sx, BrINT sy,
                                              BrShapeProxy& shape, PrBitmap* pChunkFill,
                                              BRCHAREFFECTINFO charInfo)
{
	// [JIRA] XRF-3224 Doc과 ppt의 반사효과가 영역이 다르게 잡히는데 그 원인으로 Doc의 문단 계산 방법이 다른 것으로 추정
	// 따라서 Default LineSpace인 1.0으로 계산하여 (Font마다 다름) ppt와의 차이를 보정해 줌.
	CFrame* pFrame = pLine->getFrame();

	BRect rcCharDev(0, 0, charInfo.nWidth, charInfo.nHeight + charInfo.nLineSpace);

	BRect rcFill = rcCharDev;
	BrINT nFillPos = *pLine->getPosArray().GetAt(nCol) - *pLine->getPosArray().GetAt(0);
	BrINT nFillPosDev = twips2DeviceX(nFillPos, painter->getZoomScale(), painter->m_iResX);

	//CFrame* pFrame = pLine->getFrame();			//2014. 1. 20 정의준. 세로 Text Gradient 지원
	BrINT nTextFlow = pFrame->getTextFlow();		//정의준 text flow
	BrINT extraDist = BrShapeMagicNumber::getCharBottomExtraGap(dc->m_pFont->getCharHeight());

	BrWORD ch = 0;
	const BChar* pCh = qStrBuffer.unicode();
	if (pCh)
		ch = pCh->unicode();
	BrINT nFontSize = IS_MODERN_KOREAN(ch) ? pTextAtt->getHanFSize() : pTextAtt->getEngFSize();
	if (IsRTLChar(ch) && nTextFlow == TEXTFLOW_GARO) {
		//AOM-1803 RTL일 때 rcFill의 Width가 음수가 되므로 오른쪽으로 민다.
		BrINT32 nLastCol = pLine->getPosArray().GetSize() - 1;
		nFillPos += *pLine->getPosArray().GetAt(nLastCol);
		nFillPosDev = twips2DeviceX(nFillPos, painter->getZoomScale(), painter->m_iResX);
	}
	//[2014.4.20] ejjeong. TextFlow에 따른 rcFill Position 정리
	switch (nTextFlow) {
		case TEXTFLOW_SERO:
		case TEXTFLOW_SERO_90:
		{
			rcFill.InflateRect(0, 0, extraDist, 0);				//Sero Char의 경우 Extra Bottom 만큼 Width가 넓어진다
			BrDrawUnit::rotateRectangle(90, rcFill, rcFill);
			break;
		}
		case TEXTFLOW_SERO_270:
		{
			rcFill.InflateRect(0, 0, extraDist, 0);				//Sero Char의 경우 Extra Bottom 만큼 Width가 넓어진다
			//짜르는 Rect도 회전을 시켜야 회전된 Char의 BaseFill을 얻을 수 있다.

			//SERO_270은 아래에서부터 채운다.
			BrINT nLastPosId = pLine->getPosArray().GetSize() - 1;
			BrINT nLastCharId = pLine->getCharSetArray()->GetSize() - 1;
			CCharSet wCh = *pLine->getCharSetArray()->GetAt(nLastCharId);
			if (wCh.getCode() == '\r' || wCh.getCode() == '\n')
				nLastCharId--;

			nFillPos = *pLine->getPosArray().GetAt(nLastCharId - nCol) - *pLine->getPosArray().GetAt(0);
			nFillPosDev = twips2DeviceX(nFillPos, painter->getZoomScale(), painter->m_iResX);

			BrDrawUnit::rotateRectangle(270, rcFill, rcFill);
			break;
		}
		case TEXTFLOW_SERO_RTL:
		case TEXTFLOW_SERO_LTR:
			nFillPos = *pLine->getPosArray().GetAt(0) - *pLine->getPosArray().GetAt(0);
			nFillPosDev = twips2DeviceX(nFillPos, painter->getZoomScale(), painter->m_iResX);
			break;
		default:  //TEXTFLOW_GARO
			break;
	}

	if (pChunkFill) {
		//[2014.4.20] ejjeong. TextFlow에 따른 rcFill Size 정리 및 예외 처리
		switch (nTextFlow) {
			case TEXTFLOW_SERO:
			case TEXTFLOW_SERO_90:
			case TEXTFLOW_SERO_270:
			{
				rcFill.Move(-rcFill.nLeft, -rcFill.nTop);
				rcFill.nRight = rcFill.nLeft + pChunkFill->cx();
				BrINT nFillPosYDev = twips2DeviceY(nFillPos, painter->getZoomScale(), BrFALSE, painter->m_iResY);
				rcFill.Move(0, nFillPosYDev);

				//Sero에서 BaseFill을 Crop할 Rect의 height가 Char의 height(글자가 누웠으므로 Font의 Width) 보다 작을 때
				BrINT32 nFillHeight = rcFill.nBottom - rcFill.nTop;
				if (nFillHeight < charInfo.nWidth + extraDist) {
					rcFill.nBottom = rcFill.nTop + charInfo.nWidth + extraDist;
					nFillHeight = rcFill.GetHeight();
				}

				//Sero에서 BaseFill을 Crop할 Rect의 nRight가 ChunkFill의 nRight보다 클 때, 없는 영역을 자르게 됨
				if (rcFill.nBottom > pChunkFill->cy()) {
					rcFill.nBottom = pChunkFill->cy();
					rcFill.nTop = rcFill.nBottom - nFillHeight;
					rcFill.nTop = rcFill.nTop < 0 ? 0 : rcFill.nTop;	//또한 음수의 nTop라면 없는 영역을 자르게 됨
				}
				break;
			}
			case TEXTFLOW_SERO_RTL:
			case TEXTFLOW_SERO_LTR:
			default:  //TEXTFLOW_GARO
			{
				// 여기서 밑줄이 있으면 밑줄 분량만큼 늘려야(-) 할거 같다 MS Test 해보니까 밑줄이 있든 없든 같은데? 항상 있을때의 크기로 되는거 같다
				// 아냐 여기서 사진 크기를 늘리는게 아니라 line_frame rect를 늘려야해. char outline 뽑은 쪽에서 polygon은 늘리지 않고 line_frame rect만 늘릴 수 있을까?
				rcFill.nBottom = rcFill.nTop + pChunkFill->cy();
				rcFill.Move(nFillPosDev, 0);

				//[JIRA] XRF-3278 Font의 크기가 커지면 A자 같이 화면을 전체 채우는 글자는 OutLine만큼이 잘린다.
				BrWORD ch = 0;
				const BChar* pCh = qStrBuffer.unicode();
				if (pCh)
					ch = pCh->unicode();
				BrINT nFontSize = IS_MODERN_KOREAN(ch) ? pTextAtt->getHanFSize() : pTextAtt->getEngFSize();
				nFontSize /= 20.;
				BPoint fontSize(nFontSize, 0);
				// rcCharDev 에 font size는 왜 더하지?; 안더하면 지금 발견한 __ 에서 이미지 채우기 오류 고쳐지는거 같은데?;
				//rcFill.nRight += twips2Device(painter, fontSize).x*2;

				//BaseFill을 Crop할 Rect의 Width가 Char의 nWidth보다 작을 때
				BrINT32 nFillWidth = rcFill.nRight - rcFill.nLeft;
				if (nFillWidth < charInfo.nWidth) {
					//[JIRA] XRF-3278 Font의 크기가 커지면 A자 같이 화면을 전체 채우는 글자는 OutLine만큼이 잘린다.
					rcFill.nRight = rcFill.nLeft + charInfo.nWidth + twips2Device(painter, fontSize).x * 2;
					nFillWidth = rcFill.GetWidth();
				}

				//BaseFill을 Crop할 Rect의 nRight가 ChunkFill의 nRight보다 클 때, 없는 영역을 자르게 됨
				if (rcFill.nRight > pChunkFill->cx()) {
					rcFill.nRight = pChunkFill->cx();
					rcFill.nLeft = rcFill.nRight - nFillWidth;
					rcFill.nLeft = rcFill.nLeft < 0 ? 0: rcFill.nLeft;		//또한 음수의 nLeft라면 없는 영역을 자르게 됨
				}
				break;
			}
		}
	}

	shape.setBaseFillFromGroup(rcFill, pChunkFill);
	return BrTRUE;
}


void CTextDraw::GetEmphasisOffset(BrDC* dc, BrINT nFontHgt, BrINT nFontWid, BrINT nEmphasisType,
                                  BrINT& nOffsetX, BrINT& nOffsetY, BrBOOL bIsHorizontalDraw)
{
	switch (nEmphasisType) {
		case BR_EMPHASIS_DOT:
		case BR_EMPHASIS_COMMA:
		case BR_EMPHASIS_KOREAHIGH:
		case BR_EMPHASIS_KOREALOWHIGH:
		case BR_EMPHASIS_VETNAMDAUNANG:
		case BR_EMPHASIS_DISK:
		{
			if (bIsHorizontalDraw) {
				if (nEmphasisType == BR_EMPHASIS_KOREAHIGH || nEmphasisType == BR_EMPHASIS_KOREALOWHIGH) {
					nOffsetX -= nFontHgt / 12;
					nOffsetY += nFontHgt / 2; // - 1; //5
				}
				else {
					nOffsetX += nFontWid / 2;
					if (nEmphasisType == BR_EMPHASIS_VETNAMDAUNANG)
						nOffsetY += nFontHgt + nFontHgt / 7; // - 1; //5
					else
						nOffsetY -= nFontHgt / 7; // - 1; //5
				}
			}
			else {
				if (nEmphasisType == BR_EMPHASIS_KOREAHIGH || nEmphasisType == BR_EMPHASIS_KOREALOWHIGH) {
					nOffsetX += nFontHgt + nFontHgt / 7; //-1;
					nOffsetY += nFontWid / 2;
				}
				else {
					PoDcTextAtt* curDcTextAtt = theBWordDoc->getTextAttHandler()->getCurDrawingDcTextAtt();
					if (curDcTextAtt->getRotateValue() == 270)	//[ZPD-22636][2015-12-10]
						nOffsetX -= g_pAppStatic->m_pFont->getCharDescent();
					else
						nOffsetX += nFontHgt + nFontHgt / 7; //-1;
					nOffsetY += nFontWid / 2;
				}
			}
		}
		break;
		case BR_EMPHASIS_THAIRISING:
		case BR_EMPHASIS_VETNAMDAUNGA:
		case BR_EMPHASIS_THAILOW:
		case BR_EMPHASIS_THAIHIGH:
		case BR_EMPHASIS_THAIFALLING:
		case BR_EMPHASIS_THAIMID:
		case BR_EMPHASIS_VETNAMDAUHOI:
		{
			BrWORD wCode = GetCombiningDiacriticalMarks(nEmphasisType);
			if (0 == wCode)
				return;

			BrINT nEmphasisWidth = dc->m_pFont->getCharWidth(wCode);
			if (bIsHorizontalDraw) {
				nOffsetY -= nFontHgt / 3; // - 1; //5
				if (nEmphasisWidth > 0) {
#ifndef WINDOWS_8
					nOffsetX += (nFontWid - nEmphasisWidth) / 2;
#else
					//[15.05.29][sglee1206] PC Version에서는 항상 폴라리스 바탕으로 처리하도록 함. SRG-1109
					//폴라리스 바탕 체 사용 시 간격 조정
					nOffsetX += nEmphasisWidth * 0.3f;
					switch (nEmphasisType) {
						case BR_EMPHASIS_THAIFALLING:
						case BR_EMPHASIS_THAIMID:
						case BR_EMPHASIS_THAIRISING:
							nOffsetX += nEmphasisWidth * 0.3f;
							break;
						case BR_EMPHASIS_VETNAMDAUNGA:
							nOffsetX -= nEmphasisWidth * 0.1f;
							break;
						default:
							break;
					}
#endif
				}
				else {
#ifndef WINDOWS_8
					if (nFontWid >= nFontHgt)
						nOffsetX += nFontWid * 0.8;
					else
						nOffsetX += nFontWid;
#else
					//[16.03.03] PC Version에서는 항상 폴라리스 바탕으로 처리하도록 함. ZPD-26436
					//폴라리스 바탕 체 사용 시 간격 조정
					switch (nEmphasisType) {
						case BR_EMPHASIS_THAILOW:
						case BR_EMPHASIS_THAIHIGH:
						case BR_EMPHASIS_VETNAMDAUHOI:
							nOffsetX += nFontWid * 0.3f;
							break;
						default:
							nOffsetX += nFontWid * 0.2f;
					}
#endif
				}
			}
			else {
				nOffsetX += nFontHgt + nFontHgt / 7; //-1;
				nOffsetY += nFontWid / 2;
			}
		}
		break;
		case BR_EMPHASIS_ACCENT:
		{
			BrINT nBaselineGap = 0;
			BrINT nGlyphHeight = 0;
			BrINT nEmphasisWidth = 0;

			nGlyphHeight = dc->m_pFont->GetGlyphHeight(0x02ce, &nBaselineGap);
			nEmphasisWidth = dc->m_pFont->getCharWidth(0x02ce);

			nOffsetX += (nEmphasisWidth + (BrABS(nFontWid - nEmphasisWidth) * 0.5));
			nOffsetY -= nGlyphHeight;
		}
		break;
		default:
			break;
	}
}


BrBOOL CTextDraw::SupportLocaleCompose(BFont* font, BString& display, CLine* line,
                                       BrINT col, BrBOOL is_export)
{
	if (BrNULL == line)
		return BrTRUE;

	BArray<SyllablesGlyph>& code_idx_arr = line->getCodeIndexArray();
	if (code_idx_arr.size() <= col || theBWordDoc->getInsertSymbol())
		return BrTRUE;

	SyllablesGlyph& syllables_glyph = code_idx_arr[col];
	if (0 < syllables_glyph.nGlyphCnt) {  // Glyph Max Count 0xFFFF
		BrINT local_index = syllables_glyph.GlyphArray[0];
		if (-1 == local_index)
			return BrFALSE;

		font->SetFontGlyphIndexValue(local_index);

		//[17.06.08][sglee1206] PDF Export 시 이미 조합이 완료된 글자가 전달되어 Rendering과 동일한 조건으로 처리[XPD-17277]
		if (is_export && 0 == local_index) {
			BChar compose_default[MAX_COMPOSE_LEN] = {};  // MAX_COMPOSE_LEN ???
			WORD uc = display[0].unicode();
			if (IS_USE_ICU(uc))
				display.setUnicode(compose_default, 1);
		}
	}

	return BrTRUE;
}


BrBOOL CTextDraw::CheckWordArtDrawText(const CLine* line, CFrame* frame, const PoTextAtt* text_att,
                                       BrINT descent, BrLONG zoom_scale, BrLONG res_x)
{
	if (BrNULL == line || BrNULL == frame || BrNULL == text_att || BrFALSE == text_att->isWordArtStyle())
		return BrFALSE;

	BrGrapAtt* grap_att = text_att->getGrapAtt();
	if (BMV_FILLTYPE_SOLID != grap_att->getBrush()->getStyle())
		return BrFALSE;

	BrINT grap_width = grap_att->getLineWidth();
	BrINT shape_width = (0 < grap_width)? twips2DeviceX(grap_width, zoom_scale, res_x): 0;
	BrINT line_width = BrShapeMagicNumber::getFontLineWidth(descent);
	if (2 < shape_width && 1 < line_width)
		return BrFALSE;

	BrCOLORREF highlight = text_att->getBackColor().getColor() & 0x00FFFFFF;
	BrCOLORREF color = theBWordDoc->getPaperColor() & 0x00FFFFFF;
	if (highlight == color) {
		BrShape* shape = frame->getBorder();
		if (shape && BrFALSE == shape->isNullBrush() && BrFALSE == grap_att->isNullBrush())
			color = shape->getBrushColor();
	}
	else {
		BrCOLORREF shading = text_att->getShadingFillColor().getColor() & 0x00FFFFFF;
		if (highlight != NONE_COLOR_BITS && highlight != TRANSPARENT_COLOR)
			color = highlight;
		else if (shading != NONE_COLOR_BITS || highlight != TRANSPARENT_COLOR)
			color = shading;
	}
	if (color != grap_att->getPen()->getColor())
		return BrFALSE;

	return BrFALSE == grap_att->hasGlow() &&
	       BrFALSE == grap_att->hasReflection() &&
	       BrFALSE == grap_att->hasOuterShdw() &&
	       BrFALSE == grap_att->hasInnerShdw() &&
	       BrFALSE == grap_att->hasSoftEdge() &&
	       BrFALSE == grap_att->isGradient();
}


BrBOOL CTextDraw::DrawCharBitmap(Painter* painter, BrDC* dc, CCharSet* pLink,
                                 const PoTextAtt* pTextAtt, CLine* pLine, BrINT nCol,
                                 BString& qStrBuffer, BrINT sx, BrINT sy,
                                 BrWordArtBitmapArray* pAlterBitmapArray/*=BrNULL*/,
                                 BrINT nAlterCol/*=0*/)
{
	if (!dc || !pLink || !pTextAtt || !pLine || !painter)
		return BrFALSE;

	CFrame* pFrame = pLine->getFrame();
	if (pFrame == BrNULL)
		return BrFALSE;

#ifdef USE_COLLABORATION
	//20hoon 공동편집에서는 성능 문제로 인하여 워드 아트 랜더링을 지원하지 않습니다.
	if (BrGetCollaborationMode() == BR_COLLABORATION_COLLABORATION_MODE) {
		CollaborationProvider* pProvider = g_pCollaborationProvider;
		if (pProvider) {
			BrBOOL bWordArtRendering = BrTRUE;
			bWordArtRendering = pProvider->checkSupportOperation(eBR_CLB_BWP_SUPPORT_ENABLE_TEXTEFFECT_RENDERING_N_ARRANGE) == true? BrTRUE: BrFALSE;
			if (bWordArtRendering == BrFALSE)
				return BrFALSE;
		}
	}
#endif  // USE_COLLABORATION
	BrBOOL bClearCache = !pTextAtt->isWordArtStyle();

#ifdef USE_ANIMATION_COMPONENT_COUTDEV
	// 텍스트 색상 애니메이션을 위한 비트맵을 뜰 때, 텍스트 윤곽선이 있더라도 이전에 TextAtt에 지정한 색상으로 비트맵을 떠야한다
	if (pFrame && pFrame->getColorBitmapAnimationWith() != BrNULL && !bClearCache && pTextAtt->getGrapAtt()->getLineType() > BMV_LINESTYLE_NOLINE)
		bClearCache = BrTRUE;
#endif  // USE_ANIMATION_COMPONENT_COUTDEV

	if (bClearCache) {
		pLine->clearDetachedCache(); 		//word art 속성이 사라진 경우 cache를 지운다.
		return BrFALSE;
	}

	BrBYTE doc_gray_mode = (BrBYTE)theBWordDoc->GetGrayMode();
	BrColorMode color_mode = GetColorMode(doc_gray_mode, pFrame);

	BrBOOL bNightView = BrFALSE;
#ifdef SUPPORT_NIGHT_VIEW_MODE
	bNightView = theBWordDoc->isNightViewMode();
#endif
	BrCOLORREF dwUserDefineForeColor = NONE_COLOR_BITS;
	BrCOLORREF dwUserDefineBackColor = NONE_COLOR_BITS;
#ifdef SUPPORT_LOW_VISION_SHAPE
#ifndef LOW_VISION_SHAPE_TEST
	if (theBWordDoc->m_pLowVisionColorModeEngine)
#endif  // LOW_VISION_SHAPE_TEST
	{
		color_mode = COLOR_FIXED;
#ifndef LOW_VISION_SHAPE_TEST
		dwUserDefineForeColor = theBWordDoc->m_pLowVisionColorModeEngine->GetTextColor();
		dwUserDefineBackColor = theBWordDoc->m_pLowVisionColorModeEngine->GetBackGroundColor();
#else  // LOW_VISION_SHAPE_TEST
		dwUserDefineForeColor = RED_COLOR;
		dwUserDefineBackColor = YELLOW_COLOR;
#endif  // LOW_VISION_SHAPE_TEST
	}
#endif  // SUPPORT_LOW_VISION_SHAPE

	BrBOOL bHas3DOnly = BrFALSE;
	BrGrapAtt* pGrapAtt = pTextAtt->getGrapAtt();
#ifndef USE_WORDART_3D
	BrBOOL bVisibleEffect = pGrapAtt->hasInnerShdw() || pGrapAtt->hasOuterShdw() || pGrapAtt->hasGlow();
	BrBOOL bHas3DBevel = BrFALSE;
	const CMsod_3DObject* p3DObject = pGrapAtt->get3DObjectProp();
	if (p3DObject) {
		if ((p3DObject->m_pPresetBevelTypeTop && p3DObject->m_lHeightBevelTop) ||
		    (p3DObject->m_pPresetBevelTypeBottom && p3DObject->m_lHeightBevelBottom))
			bHas3DBevel = BrTRUE;
	}

	bHas3DOnly = !bVisibleEffect && bHas3DBevel;

#ifndef WINDOWS_8
	if (bHas3DOnly)
		return BrFALSE;
#endif
#endif

	if (!pTextAtt->isWaPolygon() &&  //LINE이 없고,
	    (pGrapAtt->getBrushTransparency() == 0 || pGrapAtt->getBrush()->isNoFill())) //100% 투명인 경우, 채우기 없는 경우, 그리지 않음.
		return BrTRUE;

	BrWordArtBitmapArray* pWordArtBitmapArray = pLine->getWordArtBitmapArray();
	if (pAlterBitmapArray)
		CheckCacheData(painter, pAlterBitmapArray, pLink, nAlterCol);  //cache data check
	else
		CheckCacheData(painter, pWordArtBitmapArray, pLink, nCol, pLine);  //cache data check

	BrINT nDescent = dc->m_pFont->getCharDescent();
	BrINT nWidth = dc->m_pFont->getCharWidth(qStrBuffer.at(0).unicode());
	BrINT nHeight = dc->m_pFont->getCharHeight() + nDescent;
	BRect rect(sx, sy, sx + nWidth, sy + nHeight);

	BrBOOL bUnCompress = pGrapAtt->hasOuterShdw() || pGrapAtt->hasReflection() || pGrapAtt->hasGlow();
	BRect rcBound = rect;
	// twip 값을 넘겨야하는 함수인데 device 값을 넘기고 있다.
	if (bUnCompress) {
		rect.nLeft = Device2twips(rect.nLeft, getPainter()->getZoomScale(), getPainter()->m_iResX);
		rect.nTop = Device2twips(rect.nTop, getPainter()->getZoomScale(), getPainter()->m_iResY);
		rect.nRight = Device2twips(rect.nRight, getPainter()->getZoomScale(), getPainter()->m_iResX);
		rect.nBottom = Device2twips(rect.nBottom, getPainter()->getZoomScale(), getPainter()->m_iResY);

		rcBound = CTextProc::getBoundary(rect, pTextAtt, pLine, nCol);

		rect.nLeft = twips2DeviceX(rect.nLeft, getPainter()->getZoomScale(), getPainter()->m_iResX);
		rect.nTop = twips2DeviceY(rect.nTop, getPainter()->getZoomScale(), 0, getPainter()->m_iResY);
		rect.nRight = twips2DeviceX(rect.nRight, getPainter()->getZoomScale(), getPainter()->m_iResX);
		rect.nBottom = twips2DeviceY(rect.nBottom, getPainter()->getZoomScale(), 0, getPainter()->m_iResY);

		rcBound.nLeft = twips2DeviceX(rcBound.nLeft, getPainter()->getZoomScale(), getPainter()->m_iResX);
		rcBound.nTop = twips2DeviceY(rcBound.nTop, getPainter()->getZoomScale(), 0, getPainter()->m_iResY);
		rcBound.nRight = twips2DeviceX(rcBound.nRight, getPainter()->getZoomScale(), getPainter()->m_iResX);
		rcBound.nBottom = twips2DeviceY(rcBound.nBottom, getPainter()->getZoomScale(), 0, getPainter()->m_iResY);
	}
	//BRect rcBound = bUnCompress? CTextProc::getBoundary(rect, MARGIN_BORDER_FULL, pLink->getAttrID(), pLine, nCol): rect;

	BrBOOL isDrawable = pFrame->isBasic()? theBWordDoc->IsInInvalidateRect(rcBound, BrNULL, BrTRUE): BrTRUE;
	if (!isDrawable)
		return BrTRUE;

	if (!pWordArtBitmapArray) {
		pWordArtBitmapArray = BrNEW BrWordArtBitmapArray();
		pLine->setWordArtBitmapArray(pWordArtBitmapArray);
	}
	BrWordArtBitmap* pWABitmap = pAlterBitmapArray? pAlterBitmapArray->getBitmaps(nAlterCol): pWordArtBitmapArray->getBitmaps(nCol);

#if defined(EXT_PDF_WORDART_NO_TRANSFORM)
	// 임시처리
	// pdf랑 배율 같을 때 bitmap으로 그려줘서..
	if (isExportMode())
		pWABitmap = BrNULL;
#endif
	BrBOOL bHasBitmap = pWABitmap && pWABitmap->isHasBitmap();
	BrWORD ch = 0;
	const BChar* pCh = qStrBuffer.unicode();
	if (pCh) ch = pCh->unicode();
	BoraDoc* document = theBWordDoc;
#ifdef SUPPORT_ENCLOSED_CHARACTORS
	if (bHasBitmap) {
		PoTextAttHandler* pTextAttHandler = document->getTextAttHandler();
		if (pTextAttHandler) {
			BrINT nAttID = pLink->getAttrID();
			const PoTextAtt* pCurTextAtt = pTextAttHandler->getTextAtt(nAttID);
			BrCHARSET sBitmapCharSet = pWABitmap->getCharSet();
			// POD-3079 수정이 되긴하는데 애초에 27번 att로 draw 해야할 것을 왜 29번att를 추가해서 draw 하고 29번att는 지우고 29번att로 그린 bitmap은 27번att로 그려야할때 재활용하는건 뭐지
			// 동일 크기라서 재활용하는건가. 크기가 다를때는 hasbitmap이 아닌거보니 재활용을 안하는데. 29번att로 그린 bitmap을 27번att에서 재활용하는게 문제이려나
			// 29번으로 그린 것을 27번으로 재활용 할거면 27번으로 그렸다고 거짓말이라도 해둬야 맞지 않겠는가. 아니면 29번을 지울때 bitmap도 지우거나.
			// 엄밀히하면 다른 속성이니 29번 속성 지울때 bitmap도 지우는게 맞는거 같은데..그러면 다시 그리는 비용이 아깝겠지
			const PoTextAtt* pBitmapTextAtt = pTextAttHandler->getTextAttArraySize() > sBitmapCharSet.wAttrID?pTextAttHandler->getTextAtt(sBitmapCharSet.wAttrID):BrNULL;
			if (pCurTextAtt && pBitmapTextAtt) {
				//BrBOOL bSameBitmap = ch == sBitmapCharSet.wCode && ((pCurTextAtt == pBitmapTextAtt) || (pCurTextAtt->equalWordartStyle(pBitmapTextAtt) && pCurTextAtt->getFSize() == pBitmapTextAtt->getFSize() ));
				BrBOOL bSameBitmap = (ch == sBitmapCharSet.wCode)
					&& ((pCurTextAtt == pBitmapTextAtt)
							|| pCurTextAtt->equalWordArtStyle(pBitmapTextAtt)
							|| (pCurTextAtt->getHanFSize() == pBitmapTextAtt->getHanFSize() && pCurTextAtt->getEngFSize() == pBitmapTextAtt->getEngFSize())
							);
				if (!bSameBitmap) {
					// 필드 코드 토글 첫 문자가 원문자가 아닌 경우 두 번째 효과 글자부터는 효과 없이 그린다.
					// 첫 문자와 동일한 워드아트 스타일을 가진 경우에는 비트맵으로 그린다.
					if (pCurTextAtt)
						pLine->clearDetachedCache(); // word art 속성이 사라진 경우 cache를 지운다.

					return BrFALSE;
				}
			}
		}
	}
#endif  // SUPPORT_ENCLOSED_CHARACTORS

	CCmdEngine* pCmdEngine = document->getCmdEngine();

	//썸네일을 뜨거나 애니메이션 Bitmap을 뜰 때에는 FrameToDIBMode에서 뜬다. 이 때는 Virtual Mode로 취급하지 않는다.
	const BrBOOL bNeedEffect = pFrame->GetFrameToDIBMode() || pCmdEngine->isCurOperation(ACTMAKETHUMBNAIL);
	if (!bNeedEffect) {
		CCaret* pCaret = document->getCaret();

		BrBOOL bDraw = BrTRUE;
		if (document->isFromSlideType()
				&& pLink->isBulletLink()
				&& pLine->isEmptyLineBullet()
				&& pCaret->isCaretNormal() && pCaret->getLine() == pLine) {
			bDraw = BrFALSE;
		}

		// XPD-17858 Text편집시 basicmode rendering 안하도록 수정함
#ifdef USE_BASICMODE_TEXTEDITING
		if ((pFrame->getBorder() && pFrame->getBorder()->isBasicMode()
				 && !pCmdEngine->isLButtonDown() && pCaret->isCaretNormal()) && bDraw) {
			//Text 편집 시 BasicMode로 렌더링. 그러나 글자 색상과 배경 색상이 같으면 효과가 사라지면서 글자가 보이지 않기 때문에 편집 시에만 보색으로 보여지도록 지원
			BrCOLORREF color = BLACK_COLOR;
			BasicModeTextColor(pTextAtt, pLine, color);
			BFont font(*g_pAppStatic->m_pFont);
			font.setFontColor(GetBrRValue(color), GetBrGValue(color), GetBrBValue(color));
			dc->setFont(&font);
			dc->drawChars(&qStrBuffer, sx, sy);
			dc->setFont(g_pAppStatic->m_pFont);
			return BrTRUE;
		}
		else
#endif  // USE_BASICMODE_TEXTEDITING
			//[ZPD-26085] virtual mode의 경우, place holder가 아닌 경우
			if (pFrame->isVirtualMode(BrFALSE) != eFrame_Normal_Mode && !pFrame->isPlaceHolderText()) {
				if (DrawCharBitmap_V(painter, pTextAtt, dc, pLine, nCol, sx, sy))
					return BrTRUE;
			}
	}

#ifdef ESTIMATE_SHAPE_RENDERING_MEMORY
	if (!bHasBitmap) {
		BRect rcTwipRect;
		rcTwipRect.nLeft = Device2twips(rect.nLeft, painter->getZoomScale(), painter->m_iResX);
		rcTwipRect.nTop = Device2twips(rect.nTop, painter->getZoomScale(), painter->m_iResY);
		rcTwipRect.nRight = Device2twips(rect.nRight, painter->getZoomScale(), painter->m_iResX);
		rcTwipRect.nBottom = Device2twips(rect.nBottom, painter->getZoomScale(), painter->m_iResY);
		const BrINT nCharEffectMemSize = CalcEstimatedCharEffectMemSize(rcTwipRect, pGrapAtt, painter);
		pCmdEngine->checkCacheData(painter, nCharEffectMemSize);
	}
#endif  // ESTIMATE_SHAPE_RENDERING_MEMORY

	if (pWABitmap && bHasBitmap) {
		if ((doc_gray_mode == GRAY_MODE_COLOR && pWABitmap->getColorMode() != COLOR_OWN)
		    || (doc_gray_mode != GRAY_MODE_COLOR && pWABitmap->getColorMode() != color_mode)
		    || bNightView != pWABitmap->isNightView()
		    || dwUserDefineForeColor != pWABitmap->getBasicColor()) {
			if (pAlterBitmapArray) {
				pAlterBitmapArray->removeObjAt(nAlterCol);
			}
			else {
				pWordArtBitmapArray->removeObjAt(nCol);
				pLine->removeWaChunkFillByColorMode(pLink->getAttrID(), color_mode, bNightView);
			}
			pWABitmap = BrNULL; bHasBitmap = BrFALSE;
		}
	}

	BrShapeProxy shape(SHAPE_Rectangle);
	shape.setColorMode(color_mode, bNightView, dwUserDefineForeColor, dwUserDefineBackColor, BrFALSE, BrTRUE);
	pGrapAtt->setColorMode(color_mode, bNightView, dwUserDefineForeColor, dwUserDefineBackColor, BrFALSE, BrTRUE);

	BrBOOL bRet = BrFALSE;
	BPoint offset(sx, sy);
	if (getDocType() == BORA_DOCTYPE_HWP) {
		CFrame* pFrame = pLine->getFrame();
		if (pFrame && pFrame->getTextFlow() == TEXTFLOW_SERO)
			offset.x += dc->m_pFont->getCharDescent();
	}

	if (bHasBitmap) {
		BrShapeBitmap* pOuterShdw = bUnCompress? pWABitmap->getBitmaps()->getBitmap(esDIBSHADOW): BrNULL;
		if (pOuterShdw) //outer shadow의 크기가 100%가 아닌 경우, offse을 조정해줘야 한다.
			pOuterShdw->setEffectOffset(CTextProc::getOuterShadowOffset(pLine, pGrapAtt, nCol));

		//DumpImage(dc->getBitmapDib(), -1500, 0, BrFALSE);
		pWABitmap->getBitmaps()->draw(dc, offset, painter);
		//DumpImage(dc->getBitmapDib(), -1500, 0, BrFALSE);
		bRet = BrTRUE;
	}
	else {
		PoTextAtt tempTextAtt(*pTextAtt);
		BrGrapAtt* pTempGrapAtt = tempTextAtt.getGrapAtt();
		if (pTempGrapAtt && pLink && pLink->isFieldLink() && document->isFromSlideType() && IsHyperlinkColorNode(document, pLine, nCol)) {
			BrCOLORREF dwColor = document->m_pTheme->getHlinkColor();
			if (pLine && theBWordDoc->GetGrayMode() != GRAY_MODE_COLOR) {
				CFrame* pFrame = pLine->getFrame();
				if (pFrame)
					dwColor = BrColor::getBwColor(theBWordDoc->GetGrayMode(), pFrame->getFrameColorMode(), dwColor, GRAY_MODE_APPLY_TEXT);
			}
			pTempGrapAtt->resetBrush();
			tempTextAtt.setTextColor(dwColor);
			pTextAtt = &tempTextAtt;
			shape.copy(*pTempGrapAtt);
		}

		//prepareCache 역할 수행
		//ZoomScale할 때 기존 bitmap이 screen size보다 작으나, 현 scale 적용시 screen size를 넘도록 하지 않기 위해
		BrINT nOriginZoomScale = painter->getZoomScale();

		BrShapeBitmapDeco deco((BrGrapAtt*)&shape, (BriShapeDraw*)&shape);
		BrINT orgFontSize = dc->m_pFont->getFontAtts_FontHeight();
		BrFLOAT fRatio = 1.0f;
		if (!deco.getBitmaps() || deco.getBitmaps()->isEmpty()) {
			BrINT nMaxRatio = 1;
			//screen size를 넘어갈 때에 ZoomScale을 조정하고 그에 맞는 Char의 FontSize를 조정함
			//ZoomScale 조정하는 이유는 Screen Size를 넘어가는 Bitmap의 크기를 Screen Size로 조절하기 위함
			//Char FontSize 조정하는 이유는 Char 그릴 때 Font의 Size와 ZoomScale로 조정된 Bitmap의 Size를 맞추기 위함
			if (BrShapeUtil::getCacheLimitInfo(rect, fRatio, painter->getOrgScreenWidth() * nMaxRatio, painter->getOrgScreenHeight() * nMaxRatio)) {
				painter->setZoomScale(nOriginZoomScale / fRatio);
				BrINT nCurFontSize = twips2DeviceX(pTextAtt->getHanFSize(), painter->getZoomScale(), painter->m_iResX);
				dc->m_pFont->setFontSize(nCurFontSize);
			}
		}
		BRCHAREFFECTINFO charInfo = {BRect(0,0,0,0), 0,0,0,0,0,0,0,0, 0};
#ifndef USE_WORDART_3D
		//배경과 동일한 색상의 Color가 세팅된 Text의 경우 Bevel이 적용되어도 글자가 보이지 않는다.
		//3D Bevel이 미지원 상태라 대체 수단으로 그림자를 추가(그나마 유사함)하고, WordArt 3D Bevel 렌더링이 지원되면 사라져야 할 코드
		//		BrGrapAtt* pGrapAtt = text_att->getGrapAtt();
		BrThemeBrushObj* pBrush = pGrapAtt->getBrush();
		BrThemeBrushObj* pBackUpBrush = BrNULL;
		if (bHas3DOnly) {
			BrEffectOuterShdwType sShadow;
			sShadow.align = TopLeft; sShadow.blurRad = 80000;
			sShadow.dir = 2700000; sShadow.dist = 60000;
			sShadow.color.color.setRGBColor(0); sShadow.color.alpha = 102.;
			pGrapAtt->setOuterShdw(sShadow);
			if (pGrapAtt->getBrushColor() == NONE_COLOR_BITS) {
				pBackUpBrush = BrNEW BrThemeBrushObj(*pBrush);
				pGrapAtt->setBrushColor(pTextAtt->getTextColor());
			}
		}
#endif
		const PoTextAtt* pBackUp(pTextAtt);
		PoTextAtt text_att_dim;
		if (pFrame->isDimColorDraw()) {
			text_att_dim = *pTextAtt;
			pTextAtt = &text_att_dim;
#ifdef NEW_DIM_COLOR
			pTextAtt->setTextColor(pTextAtt->getDimTextColor());
			pTextAtt->setBackColor(pTextAtt->getDimBackColor());
#else
			text_att_dim.setTextColor(MakeTextDimColor(pTextAtt, pLine));
			text_att_dim.setBackColor(MakeBackDimColor(pTextAtt));
#endif
		}

		MakeWordArtDrawInfo(painter, dc, pLink, pTextAtt, pLine, nCol, qStrBuffer, sx, sy, shape, charInfo);
		auto pBitmaps = MakeTextEffect(painter, dc, pTextAtt, pLine, nCol,
		                               qStrBuffer, sx, sy, charInfo, &shape);
		//effect->dumpImage();
		pTextAtt = pBackUp;
#ifndef USE_WORDART_3D
		if (bHas3DOnly) {
			pGrapAtt->clearPictured(BrFALSE, BrFALSE, BrFALSE, BrTRUE, BrFALSE, BrFALSE);
			if (pBackUpBrush != BrNULL) {
				pGrapAtt->setBrush(pBackUpBrush);
				BR_SAFE_DELETE(pBackUpBrush);
			}
		}
#endif
		//Char를 draw한 후 fontSize와 ZoomScale 원래 크기로 복귀시킴
		painter->setZoomScale(nOriginZoomScale);
		dc->m_pFont->setFontSize(orgFontSize);
		if (pBitmaps) {
			pBitmaps->setOrgScale(*painter);
			BrBOOL compressComplete = BrFALSE;
			BrBOOL bVectorExportMode = BrFALSE;
#if defined(EXT_PDF_WORDART_NO_TRANSFORM)
			bVectorExportMode = isExportMode();
#endif
			if (!bVectorExportMode && !bUnCompress)
				compressComplete = pBitmaps->compressBitmap(); // 도형 + 효과 compress
			if (bUnCompress || compressComplete || bVectorExportMode) {
				if (pAlterBitmapArray) {
					pWABitmap = InsertWordArtBitmap(pAlterBitmapArray, pBitmaps.release(), (BrCHARSET*)pLink, nAlterCol, color_mode, bNightView, dwUserDefineForeColor, &ch);
					if (nAlterCol == 0 && !pWordArtBitmapArray->getBitmaps(nCol))	//dummy for field charset (enclosed char)
						InsertWordArtBitmap(pWordArtBitmapArray, BrNEW BrShapeEffectBitmaps(0, *painter), (BrCHARSET*)pLink, nCol, color_mode, bNightView, dwUserDefineForeColor, &ch);
				}
				else {
					pWABitmap = InsertWordArtBitmap(pWordArtBitmapArray, pBitmaps.release(), (BrCHARSET*)pLink, nCol, color_mode, bNightView, dwUserDefineForeColor, &ch);
				}

				if (pWABitmap && pWABitmap->isHasBitmap()) {
					BrShapeEffectBitmaps* pEffect = pWABitmap->getBitmaps();
					BrShapeBitmap* pOuterShdw = bUnCompress? pEffect->getBitmap(esDIBSHADOW): BrNULL;
					if (pOuterShdw) //outer shadow의 크기가 100%가 아닌 경우, offset을 조정해줘야 한다.
						pOuterShdw->setEffectOffset(CTextProc::getOuterShadowOffset(pLine, pTextAtt->getGrapAtt(), nCol));
					BrShapeBitmap* pOuterShdwRefl = bUnCompress? pEffect->getBitmap(esDIBSHADOW_Reflect): BrNULL;
					if (pOuterShdwRefl) //shadow reflect도 outer shadow처럼 offset 조정
						pOuterShdwRefl->setEffectOffset(CTextProc::getOuterShadowOffset(pLine, pTextAtt->getGrapAtt(), nCol));
#ifdef EXT_PDF_WORDART_NO_TRANSFORM
					if (bVectorExportMode) {
						ExportVectorWordArt(painter, dc, pTextAtt, pFrame, pWABitmap->getBitmaps(),
						                    pBitmaps, shape, rcBound, offset);
					}
					else
#endif  // EXT_PDF_WORDART_NO_TRANSFORM
					{
						pEffect->draw(dc, offset, painter);
						bRet = BrTRUE;
					}
				}
			}
		}
	}
	if (!pAlterBitmapArray)
		pLine->clearDetachedCache();
	return bRet;
}


BrColorMode CTextDraw::GetColorMode(BrINT doc_gray_mode, const CFrame* frame)
{
	if (GRAY_MODE_COLOR == doc_gray_mode)
		return COLOR_OWN;

	BrColorMode color_mode = frame->getFrameColorMode();
	switch (color_mode) {
		case COLOR_DEFAULT:      FALLTHROUGH;
		case COLOR_AUTO_G:       return (GRAY_MODE_GRAY == doc_gray_mode)? COLOR_AUTO_G_GRAY: COLOR_AUTO_G_BLACKWHITE;
		case COLOR_BLACK2GRAY:   FALLTHROUGH;
		case COLOR_BLACK2WHITE:  FALLTHROUGH;
		case COLOR_BLACK:        return COLOR_BLACK;
		case COLOR_GRAY2WHITE:   return COLOR_LIGHTGRAY;  // [TBD] line 처리를 위해 별도 텍스트
	}
	return color_mode;
}


void CTextDraw::CheckCacheData(Painter* painter, BrWordArtBitmapArray* pWordArtBitmapArray,
                               CCharSet* pLink, BrINT nCol, CLine* pLine)
{
	if (!pLink || !pWordArtBitmapArray || pWordArtBitmapArray->GetSize() <= 0)
		return;

	BrWordArtBitmap* pWABitmap = pWordArtBitmapArray->getBitmaps(nCol);
	BrBOOL bHasBitmap = pWABitmap && pWABitmap->isHasBitmap();
	//[MQP-10710] screen size를 넘어갈 때에 ZoomScale 조정하는 코드가 drawCharBitmap에 있어서 실제 비트맵 뜰 당시의 Zoom Scale과 비교하려면 getOrgZoomScale()로 비교해야 함
	BrINT nZoomScale = bHasBitmap? pWABitmap->getBitmaps()->getOrgZoomScale(): 0;
	BrBOOL isZoomEqual = BrABS(nZoomScale - painter->getZoomScale()) <= 1;
	BrINT nResX = bHasBitmap? pWABitmap->getBitmaps()->getResolutionX(): 0;
	BrBOOL isResEqual = BrABS(nResX - getResolution()) <= 1;
	BrBOOL bClearCache = bHasBitmap && !(isZoomEqual && isResEqual);

	CHeaderFooterEngine* pHFEngine = theBWordDoc->getHeaderFooterEngine();
	BrBOOL bChangeHFMode = BrFALSE;
	if (pHFEngine) {
		bChangeHFMode = pHFEngine->is_change_mode();
		if (!bClearCache)
			bClearCache = bHasBitmap && bChangeHFMode;
	}

	if (bClearCache)
		pWordArtBitmapArray->removeObjAt(nCol);

	BrWaChunkFillArray* pChunkArray = pLine? pLine->getWAGroupFillArray(): BrNULL;
	if (pChunkArray) {
		BrWaChunkFill* pChunk = pChunkArray->getFillInfo(pLink->getAttrID());
		if (pChunk && pChunk->scale.getZoomScale() != painter->getZoomScale())
			pChunkArray->removeOf(pLink->getAttrID());
	}
	// [TBD]line list내에 불필요한 cache 없애기
}


BrBOOL CTextDraw::BasicModeTextColor(const PoTextAtt* pTextAtt, CLine* pLine, BrCOLORREF& color)
{
	if (!pTextAtt || !pLine)
		return BrFALSE;
	CFrame* pFrame = pLine->getFrame();
	if (!pFrame)
		return BrFALSE;

	BrBOOL bRet = BrFALSE;
	color = BLACK_COLOR;

	BrBYTE doc_gray_mode = (BrBYTE)theBWordDoc->GetGrayMode();
	BrColorMode color_mode = GetColorMode(doc_gray_mode, pFrame);

	if (pTextAtt->getAutoColor()) {
#ifdef SUPPORT_GRAPHIC_STYLE
		if (pLine) {
			CFrame* pFrame = pLine->getFrame();
			BrThemeShapeStylePreset shapeStylePreset = BR_EDITOR_SHAPE_STYLE0_NONE;
			if (pFrame)
				shapeStylePreset = (BrThemeShapeStylePreset)pFrame->getShapeStyleID();
			if (shapeStylePreset) {//오토이고 퀵 스타일 인 경우 퀵 스타일의 텍스트를 세팅한다
				BrColor textColor;
				if (
					((shapeStylePreset >= BR_EDITOR_SHAPE_STYLE1_DK1) && (shapeStylePreset <= BR_EDITOR_SHAPE_STYLE7_ACCENT6)) ||
					((shapeStylePreset >= BR_EDITOR_SHAPE_STYLE22_DK1) && (shapeStylePreset <= BR_EDITOR_SHAPE_STYLE28_ACCENT6))
					) {
					textColor.setThemeID(theBWordDoc->getThemeID());
					textColor.setColorID(THEME_CID_DK1);
				}
				else if (
					((shapeStylePreset >= BR_EDITOR_SHAPE_STYLE8_DK1) && (shapeStylePreset <= BR_EDITOR_SHAPE_STYLE21_ACCENT6)) ||
					((shapeStylePreset >= BR_EDITOR_SHAPE_STYLE29_DK1) && (shapeStylePreset <= BR_EDITOR_SHAPE_STYLE42_ACCENT6))
					) {
					textColor.setThemeID(theBWordDoc->getThemeID());
					textColor.setColorID(THEME_CID_LT1);
				}
				color = textColor.getColor();
			}
			else {
				color = AutoTextColor(pLine, pTextAtt);
			}
		}
		else
#endif  // SUPPORT_GRAPHIC_STYLE
			color = AutoTextColor(pLine, pTextAtt);
	}
	else {
		BrGrapAtt* pGrapAtt = pTextAtt->getGrapAtt();
		if (pGrapAtt != BrNULL) {
			BrBrushObj* pBrushObj = pGrapAtt->getBrush();
			if (pBrushObj != BrNULL) {
				BrColor oColor = pBrushObj->getForeColorObj();
				color = oColor.getColor();
			}
		}
		else
			color = pTextAtt->getTextColor().getColor();
	}

	//docx에는 강조색이 TextBackGround인데 pptx에는 TextBackGroud 색상이 없음. 따라서 배경 색상이나 도형 색상으로 결정함.
	BoraDoc* document = theBWordDoc;
	if (!document)
		return BrFALSE;
	BrCOLORREF bgColor = BLACK_COLOR;
	if (pFrame != BrNULL) {
		BrBOOL bUsePageBackGroud = BrTRUE;
		BrGrapAtt* pGrapAtt = (BrGrapAtt*)pFrame->getBorder();
		if (pGrapAtt != BrNULL) {
			BrINT nStyle = pGrapAtt->getBrush()->getStyle();
			switch (nStyle) {
				case BMV_FILLTYPE_PATTERN:
				case BMV_FILLTYPE_TEXTURE:
				case BMV_FILLTYPE_IMAGE:
					return BrTRUE;
				case BMV_FILLTYPE_SOLID:
					bgColor = pGrapAtt->getBrushColor();
					bUsePageBackGroud = BrFALSE;
					break;
// 			case BMV_FILLTYPE_NOFILL:
// 			case BMV_FILLTYPE_NONE:
// 				bUsePageBackGroud = BrFALSE;
// 				break;
				default:
					break;
			}
		}
		if (document->getDocType() == BORA_DOCTYPE_PPTX && bUsePageBackGroud) {
			CPage* pPage = pFrame->getPage();
			if (!pPage)
				return BrFALSE;

			CPage* pLayoutPage = BRNULL;
#ifdef SEPERATE_MASTERID
			if (pPage->getPageType() == MASTER_PAGE)
				pLayoutPage = document->getMasterPage(pPage->getMasterID()); //XPD-1321 마스터 페이지일때 추가
			else
				pLayoutPage = document->getLayoutPage(pPage->getMasterID(), pPage->getLayoutID());
#else  // SEPERATE_MASTERID
			if (pPage->getPageType() == MASTER_PAGE)
				pLayoutPage = document->getMasterPage(pPage->getMasterID() & 0x0000ffff); //XPD-1321 마스터 페이지일때 추가
			else
				pLayoutPage = document->getLayoutPage(pPage->getMasterID() & 0x0000ffff, pPage->getMasterID() & 0xffff0000);
#endif  // SEPERATE_MASTERID


			CFrameList* pFrameList = BRNULL;
			if (pLayoutPage)
				pFrameList = pLayoutPage->getTFrameList();

			if (pFrameList == BrNULL)
				bgColor = BrColor::getBwColor(document->GetGrayMode(), color_mode, WHITE_COLOR, GRAY_MODE_APPLY_FILL);
			else {
				CFrame* pBgFrame = BrNULL;
				pBgFrame = pFrameList->getFirst();
				if (pBgFrame == BrNULL)
					bgColor = BrColor::getBwColor(document->GetGrayMode(), color_mode, WHITE_COLOR, GRAY_MODE_APPLY_FILL);
				else {
					if (pBgFrame->getBorder() && pBgFrame->getBorder()->getBrush()) {
						switch (pBgFrame->getBorder()->getBrush()->getStyle()) {
							case BMV_FILLTYPE_PATTERN:
							case BMV_FILLTYPE_TEXTURE:
							case BMV_FILLTYPE_IMAGE:
								return BrTRUE;
							default:
								bgColor = pBgFrame->getBorder()->getBrushColor();
								break;
						}
					}
					else {
						bgColor = BrColor::getBwColor(document->GetGrayMode(), color_mode, WHITE_COLOR, GRAY_MODE_APPLY_FILL);
					}
				}
			}
		}
		else if (document->getDocType() == BORA_DOCTYPE_DOCX)
			bgColor = pTextAtt->getBackColor().getColor();
	}
	else //(document->getDocType() == BORA_DOCTYPE_DOCX)
		bgColor = pTextAtt->getBackColor().getColor();

	//if(((bgColor & 0x00FFFFFF) == (color & 0x00FFFFFF)))
	if (BrColor::isSimilar(bgColor, color, BrTRUE)) {
		BrBYTE r = 0, g = 0, b = 0;
		r = GetBrRValue(bgColor); g = GetBrGValue(bgColor); b = GetBrBValue(bgColor);
		//보색 : r g b 값이 동일하면 보색이 없음(자기 자신) 그래서 127보다 낮은 것은 WHITE로 설정, 높은 것은 BLACK으로 보여줌
		if (r == g && r == b) {
			if (r < 127)
				color = WHITE_COLOR;
			else
				color = BLACK_COLOR;
		}
		else
			color = BrColor::getComplementaryColor(bgColor);
		bRet = BrTRUE;
	}

	return bRet;
}


BrBOOL CTextDraw::DrawCharBitmap_V(Painter* painter, const PoTextAtt* pTextAtt, BrDC* dc,
                                   CLine* pLine, BrINT nCol, BrINT sx, BrINT sy)
{
	if (!dc || !pLine)
		return BrFALSE;

	BrBOOL bRet = BrFALSE;

	BrBOOL bScreenUpdate = BrTRUE;
	BrWordArtBitmapArray* pWordArtBitmapArray = pLine->getWordArtBitmapArray();
	if (pWordArtBitmapArray && pWordArtBitmapArray->GetSize() > 0) {
		BrWordArtBitmap* pWABitmap = pWordArtBitmapArray->getBitmaps(nCol);
		BrBOOL bHasBitmap = pWABitmap && pWABitmap->isHasBitmap();
		if (bHasBitmap) {
			BrINT16 nZoomScale = pWABitmap->getBitmaps()->getZoomScale();
			//Zoom in out 시에도 가지고 있는 WA Bitmap 드로잉 하도록 아래 라인 주석
			//if (painter->getZoomScale() == nZoomScale) //panning, flicking 의 경우
			{
				BPoint offset(sx, sy);
				pWABitmap->getBitmaps()->draw(dc, offset, painter);
				bRet = BrTRUE;
				bScreenUpdate = BrFALSE;
			}
		}
	}

	if (bScreenUpdate) {
		CCmdEngine* pCmdEngine = theBWordDoc->getCmdEngine();
		pCmdEngine->setNeedValidateScreen(BrTRUE);
		pCmdEngine->setJustUpdateScreen(BrTRUE);
	}

	setGeneralStatus(BrTRUE, eNativeDrawPageGValueStatus);
	return bRet;
}


BrINT CTextDraw::CalcEstimatedCharEffectMemSize(const BRect& rcFrame, const BrGrapAttBase* pGrapAtt,
                                                Painter* painter)
{
	BrINT nCharEffectMemSize = 0;
	if (!pGrapAtt)
		return nCharEffectMemSize;

	//CTextProc::makeWordArtDrawInfo
	nCharEffectMemSize += MEM_SZ_1K;//shape.copy(*text_att->getGrapAtt());
	nCharEffectMemSize += MEM_SZ_4K;//BrBOOL bCreateAttr = shape.createFreeFormShapeAttrs();
	nCharEffectMemSize += MEM_SZ_1K;//BrBOOL bCreatePolygon = shape.createPolygon();
	nCharEffectMemSize += MEM_SZ_1K;//if(!font.getCharGlyphOutline(&sOutlineInfo, word, &rcFont))
	nCharEffectMemSize += MEM_SZ_1K;//LPBrPOINT lpp = (LPBrPOINT)BrMalloc(BrSizeOf(BrPOINT) * sOutlineInfo.nCnt);
	nCharEffectMemSize += MEM_SZ_1K;//drawOrgPL = (BrPOINT*)BrMalloc(BrSizeOf(BrPOINT) * sOutlineInfo.nCnt);


	//MakeTextEffect
	BrINT nDescent = rcFrame.getHeight() * 7 / 33.;//(((32 - ( rcFrame.getHeight()*BASE_DESCENT) / 200 ) ) >> 6);// * 20; //20: dev -> twip; painter가 없으므로.

	//2014. 5. 15. ejjeong. [Effect Refac]
	//desc를 예상하고 넣은 값인것 같은데 1.45를 곱하게 되면 Reflection과 Glow는 맞는다.
	//OuterShdw의 경우 맞지 않아서 CharEffect 들어갈 때에 1.45로 나눠서 맞춘다.
	BrINT bottomDesc = nDescent * 1000;
	BrFLOAT fontRatio = rcFrame.getHeight() / 1000. * 1.45;

	BrShapeCharBitmapDeco deco((BrGrapAtt*)pGrapAtt, BrNULL, BrNULL, fontRatio, bottomDesc);

	nCharEffectMemSize = deco.getEstimatedRenderMemSize(rcFrame, painter, BrTRUE);

	return nCharEffectMemSize;
}


BrWordArtBitmap* CTextDraw::InsertWordArtBitmap(
        BrWordArtBitmapArray* pArray, BrShapeEffectBitmaps* pBitmaps, BrCHARSET* pLink,
        BrINT nCol, BrColorMode eColorMode/*=COLOR_OWN*/, BrBOOL bNightView/*=BrFALSE*/,
        BrCOLORREF basicColor/*=NONE_COLOR_BITS*/, const BrWORD* pCh/*=BrNULL*/)
{
	if (!pArray || !pBitmaps)
		return BrNULL;

	BrWordArtBitmap* pWABitmap = pArray->getBitmaps(nCol);
	if (!pWABitmap) {
		pWABitmap = pArray->insertAt(nCol, pBitmaps, pLink, eColorMode, bNightView, basicColor, pCh);
		if (!pWABitmap) {
			BrDELETE pBitmaps;
			return BrNULL;
		}
	}
	else if (pWABitmap && !pWABitmap->isHasBitmap()) {  //dummy bitmap만 설정된 경우,
		pWABitmap->setBitmap(pBitmaps);
	}
	return pWABitmap;
}


#ifdef EXT_PDF_WORDART_NO_TRANSFORM
BrBOOL CTextDraw::ExportVectorWordArt(Painter* painter, BrDC* dc, PoTextAtt* pTextAtt, CFrame* pFrame,
                                      BrShapeEffectBitmaps* pTextBitmaps, BrShapeEffectBitmaps* pBitmaps,
                                      BrShapeProxy& shape, BRect rcBound, BPoint offset)
{
	BRTHREAD_ASSERT(isExportMode());

	if (pTextAtt->isWaPolygon()) {  // 외곽선이 있는 경우
		BrBOOL bFloatFrame = pFrame->isSpecial();
		//BRect rcChar(0,0, nWidth, nHeight), rcTwipBound;
		BRect rcChar = rcBound;
		rcChar.nLeft = Device2twips(rcChar.nLeft, painter->getZoomScale(), painter->m_iResX);
		rcChar.nTop = Device2twips(rcChar.nTop, painter->getZoomScale(), painter->m_iResY);
		rcChar.nRight = Device2twips(rcChar.nRight, painter->getZoomScale(), painter->m_iResX);
		rcChar.nBottom = Device2twips(rcChar.nBottom /*- nDescent*/ /*nCharLineW*/, painter->getZoomScale(), painter->m_iResY);

		BrEXPORT_INFO info;
		dc->getExport(&info);

		//글자 마다 영역을 제공하지 않으면 그라데이션 채우기할 때 offset 위치가 이상해진다.
		BRect rcFrame = (bFloatFrame && info.nRotateAngle != 0) ? pFrame->getFrameRect() : rcChar;
		//BRect rcFrame = bFloatFrame ? pFrame->getFrameRect() : rcChar;
		CDrawUnit dUnit;
		dUnit.setOrg(0, 0);
		dUnit.setPageStart(offset.getX(), offset.getY());
		dUnit.setFactor(painter->m_iResX, painter->m_iResY, painter->getZoomScale());

		pTextBitmaps->clearBitmaps(esDIBSHAPE); // 도형을 지운다.
		BrShapeBitmap* pInnerShdw = BrNULL;
		if (pTextBitmaps->isExist(esDIBINNERSHADOW)) {
			// InnerShadow를 지운다.
			// InnerShadow는 Text의 위에 그려지기 때문이다.
			pInnerShdw = BrNEW BrShapeBitmap(*pTextBitmaps->getBitmap(esDIBINNERSHADOW));
			pTextBitmaps->clearBitmaps(esDIBINNERSHADOW);
		}

		if (pTextBitmaps->isExist()) // 효과가 있는 경우
			pTextBitmaps->draw(dc, offset, painter); // 효과 그린다.

		// 도형을 그린다. shape.draw로 그려야 하고 벡터로 그려져야 함
		BrBYTE oldExtMode = painter->pDC->getExportMode();
		painter->pDC->setExportMode(eNoneDirectExtMode);

		// text와 외곽선을 벡터로 그리기 위해서는 BrShapeProxy의 draw를 타야한다.
		shape.enableBasicMode(BrTRUE);
		shape.setBoundary(rcChar);
		shape.draw(painter, dc, rcFrame, dUnit);
		shape.enableBasicMode(BrFALSE);
		painter->pDC->setExportMode(oldExtMode);

		if (pInnerShdw) {
			// text 위에 Inner Shadow를 그려준다.
			pBitmaps->clearBitmaps();
			pBitmaps->addBitmap(pInnerShdw);
			pBitmaps->draw(dc, offset, painter);
		}
		return BrTRUE;
	}
	else if (pTextBitmaps->isExist(esDIBINNERSHADOW)) {
		pTextBitmaps->clearBitmaps(esDIBINNERSHADOW);
		// Text와 효과 모두 이미지로 그린다.
		pTextBitmaps->draw(dc, offset, painter);
		return BrTRUE;
	}
	else {
		pTextBitmaps->clearBitmaps(esDIBSHAPE); // 도형을 지운다.

		// shape에서 draw를 해도 외곽선이 없는 경우에는 그려지지 않는다.
		// BrGrapAttBase::isDrawAnyThing() 값이 BrFALSE를 return하기 때문이다.
		// 외곽선이 없으면 text가 그려지지 않도록 설정이 되어있는 것으로 보인다.

		if (pTextBitmaps) // 효과가 있는 경우
			pTextBitmaps->draw(dc, offset, painter); // 효과 그린다.
		return BrFALSE; // 함수가 끝난 이후에 drawChars()를 호출하기 위함.
	}
}
#endif  // EXT_PDF_WORDART_NO_TRANSFORM


void CTextDraw::Draw4ByteUnicodeCharSet(CLine* line, BrDC* dc, BrINT x, BrINT y,
                                        BrINT col, BrULONG utf16_code)
{
#ifdef SUPPORT_EMOJI_SEQUENCES
	BrINT emoji_len = line? line->getEmojiSequencesLength(col): 0;
	if (0 == emoji_len) {
		dc->drawChars(&utf16_code, x, y, BrNULL, 1);
		return;
	}
#else  // SUPPORT_EMOJI_SEQUENCES
	dc->drawChars(&utf16_code, x, y, BrNULL, 1);
	return;
#endif  // SUPPORT_EMOJI_SEQUENCES

#ifdef SUPPORT_EMOJI_SEQUENCES
	BArray<SyllablesGlyph>& syllables_glyph_arr = line->getCodeIndexArray();
	SyllablesGlyph& syllables_glyph = syllables_glyph_arr[col];
	if (BrFALSE == syllables_glyph.bEmojiCompose)
		dc->drawChars(&utf16_code, x, y, BrNULL, 1);

	BrINT glyph_cnt = syllables_glyph.nGlyphCnt;
	if (glyph_cnt <= 0)
		return;

	BrINT width = 0;
	BrINT draw_width = 0;
	BrINT prev_width = 0;
	BFont* font = theBWordDoc->getCmdEngine()->getCurPainter()->pDC->m_pFont;
	BrINT* advance_arr = syllables_glyph.nAdvance;

	for (BrINT i = 0; i < glyph_cnt; ++i) {
		BrINT32 glyph_index = syllables_glyph.GlyphArray[i];
		font->SetFontGlyphIndexValue(glyph_index);

		if (glyph_cnt <= 2) {
			draw_width += dc->drawChars(&utf16_code, x + draw_width, y, BrNULL, 1);
			continue;
		}

		BrINT32 advance = advance_arr[i];
		BrINT32 offset = syllables_glyph.nXOffset[i];
		//Segoe UI Emoji.ttf
		if (3 == glyph_cnt && 0 == advance_arr[1] && 0 == advance_arr[2]) {
			if (0 == advance && offset < -1)
				draw_width -= prev_width;
			else if (0 == advance && 0 == offset)
				draw_width += draw_width * 2;
			else if (0 < advance)
				draw_width = font->getCharNoRotatedWidth(glyph_index) / 2;
		}
		else {
			//Segoe UI Emoji.ttf
			if (0 == advance && offset < -1)
				draw_width -= prev_width;
			else if (0 == advance && 0 == offset)
				draw_width += draw_width;
		}
		width = dc->drawChars(&utf16_code, x + draw_width, y, BrNULL, 1);
		prev_width = width;
		if (0 < advance)
			draw_width += width;
	}
#endif  // SUPPORT_EMOJI_SEQUENCES
}


void CTextDraw::DrawGaroOneLine(Painter* painter, BrDC* dc, CDrawUnit& du, CFrame* pFrame,
                                CLine* pLine, BrINT sx, BrINT sy, BrINT nWidth, BrINT nBandCount,
                                BrINT nMaxDescent, const PoParaAtt& mergedParaAtt,
                                BrINT nSCol, BrINT nECol, BrBOOL bEffect)
{
#ifdef _DEBUG
	CTextProc::DumpString(g_tdraw_buf, pLine->getCharSetArray());
#endif  // _DEBUG
	BoraDoc* document = theBWordDoc;
	if (document == BrNULL || pFrame == BrNULL || pLine == BrNULL)
		return;

	CCmdEngine* pCmdEngine = document->getCmdEngine();
	CLongArray& cPosArray = pLine->getPosArray();

	CCharSet* pLink = BrNULL;
	CFrame* pObject = BrNULL;
	BrINT    dx = 0, dy = 0;
	BrINT    nCol = 0;
	BrWORD   wCode;
	BrINT    nTabFill;
	BrINT    nEWCount;
	BrBOOL bArrange = BrFALSE;

	// qDebug("draw one line1");
	PoTextAttHandler* textAttHandler = document->getTextAttHandler();
	PoParaAttHandler* paraAttHandler = document->getParaAttHandler();
	if (textAttHandler == BrNULL)
		return;

	//////////////////////////////////////////////////////////////////////////
	//style 병합에 필요한 속성 get

	//cash로 사용될 temp textatt
	PoTextAtt mergedTextAtt;
	//////////////////////////////////////////////////////////////////////////

	BrINT nVerAlign = mergedParaAtt.getVerAlign();

	BrINT nAscent = pLine->getAscent();

	PoTextAtt defaultAtt = *(textAttHandler->getDefaultAttr());
	//[2013-11-24][20hoon]
	BrINT nMaxDecentUnderBasePos = pLine->getMaxHgtUnderBasePos();
	BrINT nLineHgt = du.doc2LogicalDY(nAscent + nMaxDecentUnderBasePos, BrFALSE);
	if (nLineHgt < 1) {
		if (!pLine->isAnchorSearch())
			return;
	}

	CCharSetArray* pLinkArray = pLine->getCharSetArray();
	if (pLinkArray == BrNULL)
		return;
	BrINT nCharNum = pLinkArray->size();
	if (nCharNum == 0 || (BrINT)cPosArray.size() < nCharNum + 1)
		return;

#ifdef _SPELLCHECKER
	if (document->isResetSpellCheck())
		pLine->setDoneChkSpell(BrFALSE);
	if (document->isSpellCheckMode() && !document->isSpellCheckSkipMode() && pLine->isStartLine() && !pLine->isDoneChkSpell()
			&& !document->getCmdEngine()->isCurOperation(ACTMAKETHUMBNAIL)) {
		CTextProc::checkWordSpellOfLine(document, pLine, pLine->getLastLineOfPara());
	}
#endif  // _SPELLCHECKER

	BrBOOL bBidiPara = mergedParaAtt.getBiDi();

	if (pLine->getStatus(LINE_FIELD) != 0)
		document->getCmdEngine()->m_bBwpDrawForeground |= TEXT_UNDERLINE_FOREGROUND;

	RevisionEngine* revision_engine = document->getRevisionEngine();

	if (document->getBWPEngineMode() == EDITOR_WORD && document->isShowMemo() && pLine->isMemoEnd()
			&& revision_engine->canDrawRevisionViewMode()) {
		document->getCmdEngine()->m_bBwpDrawForeground |= TEXT_MEMO_ICON_FOREGROUND;
	}

#ifdef BIDI_SUPPORT
	BrBOOL bDisplayCode = BrFALSE;
	if (pLine->isDisplayCodeFlag() && pLine->getDisplayCodeArray().size() == nCharNum)
		bDisplayCode = BrTRUE;
#endif  // BIDI_SUPPORT

	ResetDrawCharInfo(document);

	BrBOOL bCellTextViewOutLine = BrFALSE;
	if (!pFrame->isGaro() && pFrame->isCell() && document->isViewOutlineMode())
		bCellTextViewOutLine = BrTRUE;

	BrBOOL bIsWord = (document->getBWPEngineMode() == EDITOR_WORD)? BrTRUE: BrFALSE;

	BRDRAWCHARINFO stDrawCharInfo;
	memset(&stDrawCharInfo, 0, BrSizeOf(BRDRAWCHARINFO));
	stDrawCharInfo.pDC = dc;
	stDrawCharInfo.nLineHgt = nLineHgt;
	stDrawCharInfo.nDescent = nMaxDescent;
	stDrawCharInfo.nFlag = nVerAlign;
	stDrawCharInfo.bBidiPara = bBidiPara;

	BrBOOL bulletSpecialCharRTLFlag = BrTRUE;

	InsDelHwpTypeSetSymbol(document, pLine);

	if (nSCol >= 0 && nSCol <= pLine->getCharNum() && nECol >= 0 && nECol <= pLine->getCharNum()) {
		nCol = nSCol;
		nCharNum = nECol;
	}
	BrBOOL bRevisionLine = BrFALSE;

	for ( ; nCol < nCharNum; nCol++) {
		pLink = pLinkArray->getCharSet(nCol);
		if (!pLink)
			break;

		stDrawCharInfo.nCol = nCol;

		if (revision_engine->isShowRevision(pLink) && !pLink->isMemoLink() || (revision_engine->isPropertyChangeRun(pLink) && revision_engine->getFormatShowState()))
			bRevisionLine = BrTRUE;

		if (pLink->isPageNumLink()) {  //Ticket 27273
			CPage* pCurPage = pFrame->getPage();
			//[ZPD-25532] 바탕페이지일 경우 추가
			if (!bArrange && (pFrame->isHeader() || pFrame->isFooter() || pFrame->isFrameInHeaderFooterFrame() || (pCurPage && pCurPage->isBatangPage()))) {
				//ZPD-32308 아래 arrange 도중 invalidate flag가 변경되는 경우가 있음
				// BrBOOL bOldInvalidFlag = document->getInvalidateFlag();
				//CSP-2989 셀안의 line base pos 오류 수정
				if (/*pFrame->isCell() && */pFrame->getArrangePos() != TOP_ARRANGE && !pLine->getPrevInFrame()) // BBC-4638
					CTextProc::arrangeOneFrame(document, pFrame);
				else
					CTextProc::arrangeOneLine(document, pLine, BrFALSE, BrFALSE, BrTRUE, BrFALSE, BrNULL);

				nCharNum = pLine->getCharNum();
				if (nCol >= nCharNum)
					break;
				bArrange = BrTRUE;
			}
		}

#ifndef USE_TEXTANIMATION_COUTDEV
		if (nSCol >= 0 && nSCol <= pLine->getCharNum() && nECol >= 0 && nECol <= pLine->getCharNum()) {
			if (nCol == nSCol) {
				dx = 0;
			}
			else {
				dx = du.doc2LogicalDX(cPosArray[nCol] - cPosArray[nSCol]);
				BrTrace("nCol = %d, dx = %d", nCol, dx);
			}
		}
		else {
			dx = sx + du.doc2LogicalDX(cPosArray[nCol], BrFALSE);
		}
#else
		if (pFrame->getTextAnimationFlag()) {
			BrINT nBasePos = du.doc2LogicalDX((BrINT32)pFrame->getTextAnimationBasePos(), BrFALSE);
			dx = sx + du.doc2LogicalDX(cPosArray[nCol], BrFALSE) - nBasePos;
		}
		else {
			if (nSCol >= 0 && nSCol <= pLine->getCharNum() && nECol >= 0 && nECol <= pLine->getCharNum()) {
				if (nCol == nSCol) {
					dx = 0;
				}
				else {
					dx = du.doc2LogicalDX((BrINT32)(cPosArray[nCol] - cPosArray[nSCol]));
					BrTrace("nCol = %d, dx = %d", nCol, dx);
				}
			}
			else {
				dx = sx + du.doc2LogicalDX((BrINT32)(cPosArray[nCol]), BrFALSE);
			}
		}
#endif
		dy = sy;

		stDrawCharInfo.sx = dx;
		stDrawCharInfo.sy = dy;

		mergedTextAtt = *pLink->getTextAtt();

		if (document->isFromDoc() && pFrame->isWordMemoFrame()) {
			mergedTextAtt.setHanFSize(defaultAtt.getHanFSize());
			mergedTextAtt.setEngFSize(defaultAtt.getEngFSize());
		}

#ifdef USE_HWP_CONTROL
		if ((pLink->isClickhereBeginLink() || pLink->isClickhereEndLink())
            && !document->isThumbnailDraw() && !g_pAppStatic->isPrtPreview() && !document->getEditProtect() && !document->getViewTogetherMode()) {
            {
                clickhere::ClickHereHandler* pClkArray = theBWordDoc->getClickHereHandler();
                clickhere::ClickHere* pClickhere = pClkArray->find(pLink->getCode());

                //InCaret이 아니더라도 무조건 draw 한다.(개발 및 QA와 협의된 내용)
                if (pClickhere /*pClickhere->isInCaret() &&*/) {
                    CCharSet cClickhereLink;
                    PoTextAtt cClickhereTextAtt;

                    theBWordDoc->getTextAttHandler()->getTextAtt(cClickhereTextAtt, theBWordDoc->getClickHereHandler()->ClickHereAttrID());

                    BrINT nViewOption = theBWordDoc->getFieldViewOption();
                    switch (nViewOption) {
                        case 1:
                        {
                            cClickhereTextAtt.setTextColor(RGB_BLACK);
                        }
                        break;
                        case 2:
                        {
                            cClickhereTextAtt.setTextColor(RGB_RED);
                        }
                        break;
                        case 3:
                        {
                            cClickhereTextAtt.setTextColor(RGB_LTGRAY);
                        }
                        break;
                    }

                    if (pLink->isClickhereBeginLink()) {
                        cClickhereLink.setCode(clickhere::ClickHereHandler::OPEN_CODE);
                        BRect rcTextWidth;
                        rcTextWidth.setWidth(pClkArray->ClickHereTextWidth());
                        document->getCmdEngine()->page2Logical(pFrame->getPage(), rcTextWidth);
                        stDrawCharInfo.sx -= (BrINT)(rcTextWidth.GetWidth());
                    }
                    else
                        cClickhereLink.setCode(clickhere::ClickHereHandler::CLOSE_CODE);

                    DrawGaroCharSet(du, stDrawCharInfo, &cClickhereLink, &cClickhereTextAtt, BrNULL, BrFALSE, bEffect, painter, BrFALSE);
                }
            }
        }
#endif  // USE_HWP_CONTROL

		if (pLink->isFieldExDummyLink()) {
			CField* pField = pLink->getField(document);
			if (pField != BrNULL && pField->getFieldType() == BR_FIELD_TYPE_EQ) {
				CFieldEq* pFieldEq = static_cast<CFieldEq*>(pField);
				stDrawCharInfo.nCol = nCol;	//원문자에 텍스트 효과 적용되어 있을 때 필요
				pFieldEq->draw(dc, stDrawCharInfo, du, stDrawCharInfo.sx, stDrawCharInfo.sy, pLine, painter);
			}
		}

		// 수평선
		else if (pLink->isHLineLink()) {
			BrINT nActLineWidth;

			if ((nCol + 1) <= nCharNum)
				nActLineWidth = (sx + du.doc2LogicalDX((BrINT32)(cPosArray[nCol + 1]), BrFALSE)) - dx;
			else
				nActLineWidth = nWidth;
			DrawHorizontalLineCode(dc, dx, dy, nActLineWidth, nLineHgt, GARO);
		}
		else if (pLink->is4BYTE()) {
			wCode = pLink->getCode();
			if (wCode == 0)
				continue;
#ifdef SUPPORT_EMOJI_SEQUENCES
			stDrawCharInfo.nCol = nCol;
#endif
			DrawGaroCharSet(du, stDrawCharInfo, pLink, &mergedTextAtt, pLine, BrFALSE, bEffect, painter);
#ifdef SUPPORT_EMOJI_SEQUENCES

			if (pLine && pLine->getCodeIndexArray().size() > 0 && pLine->getCodeIndexArray().size() > nCol) {
				BrBOOL bCompose = pLine->getCodeIndexArray().at(nCol).bEmojiCompose;
				if (bCompose) {
					BrINT nEmojiLen = pLine->getEmojiSequencesLength(nCol);
					if (nEmojiLen >= 1)
						nCol += nEmojiLen - 1;
				}
			}

#endif  // SUPPORT_EMOJI_SEQUENCES

		}
		else if (pLink->isTextLink()) {
			wCode = pLink->getCode();
			if (wCode == 0)
				continue;

			if (!CTextProc::isCRCode(wCode)) {
				if (mergedTextAtt.isDrawUnderLine() || mergedTextAtt.getTextBorderLineInfo())
					document->getCmdEngine()->m_bBwpDrawForeground |= TEXT_UNDERLINE_FOREGROUND;
#ifdef _SPELLCHECKER
				if (document->isSpellCheckMode() && !g_pAppStatic->bBusyPrint && !painter->pDC->isExportMode() &&
						wCode != ASCII_CODE_SPACE && pLink->getWrongSpell() && !document->isResetSpellCheck())
					document->getCmdEngine()->m_bBwpDrawForeground |= TEXT_WRONG_SPELL;
#endif  // _SPELLCHECKER

#ifdef PPT_EDITOR
				if (wCode != ASCII_CODE_SPACE)
					pLine->setSpaceStatus(nCol);
#endif
			}

			if (wCode == ASCII_CODE_TAB && !pLink->isBulletLink() && mergedParaAtt.isSettedParaTabID()) {
				const PO_PARAATT_TAB::PoParaTab* paraTab = document->getParaAttHandler()->getParaTabArray()->getParaTab(mergedParaAtt.getParaTabID());
				if (paraTab)
					nTabFill = paraTab->getTabFill((BrINT32)(cPosArray[nCol]), mergedParaAtt.getLeftMargin());
			}
			else {
				nTabFill = 0;
			}

			BrBOOL check = bIsWord && !painter->pDC->isExportMode() && checkEditSymbol(pLink);
			if (check) {
#ifdef SUPPORT_SHOW_HWP_TYPESET
				// 고정폭 빈칸 조판부호
				if (wCode == NON_BREAKING_SPACE && document->isShowHWPTypeSetModeEx()) {
					DrawGaroCharSet(du, stDrawCharInfo, pLink, &mergedTextAtt, pLine, BrTRUE, bEffect, painter, BrTRUE);
				}
				else
#endif  // SUPPORT_SHOW_HWP_TYPESET
				{
					stDrawCharInfo.nCol = nCol;
					DrawEditSymbol(du, stDrawCharInfo, (BrINT32)(cPosArray[nCol]), (BrINT32)(cPosArray[nCol + 1]), pLink, pLine, &mergedTextAtt, sx, BrFALSE);

					if (nTabFill == 0)
						continue;
				}
			}
			else if (wCode == ASCII_CODE_TAB && pLink->isBulletLink())
				continue;

			if (nTabFill) {
				BrINT pos0 = static_cast<BrINT32>(cPosArray[nCol]);
				BrINT pos1 = static_cast<BrINT32>(cPosArray[nCol + 1]);
				if (document->isFromHwp() && 1 <= nTabFill && nTabFill <= 11) {
					DrawGaroHWPTabFill(dc, du, stDrawCharInfo, pos0, pos1, sx, nTabFill, &mergedTextAtt);
				}
				else {
					CCharSet cLink[2] = {};  // coverity 95027 Out-of-bounds access
					cLink[0] = *pLink;
					cLink[0].setCode((BrWORD)nTabFill);

					BrINT tab_fill_width = CTextProc::getTextLinkWidth(document, &mergedTextAtt, (BrWORD)nTabFill, BrNULL);
					if (tab_fill_width && pos0 < pos1) {
						while (pos0 + tab_fill_width <= pos1) {
							stDrawCharInfo.sx = dx;
							DrawGaroCharSet(du, stDrawCharInfo, cLink, &mergedTextAtt, BrNULL, BrFALSE, bEffect, painter);
							pos0 += tab_fill_width;
							dx = sx + du.doc2LogicalDX(pos0, BrFALSE);
						}
					}
				}
			}
			else if (pLink->isPageNumTimeDate()) {
				// [NDE-190] 쪽번호가 이전 문자로 대체되는 현상 발생. col값 갱신하면 안되는 케이스도 존재하는가.
				stDrawCharInfo.nCol = nCol;
				BrINT nDispWid = DrawGaroCharSetPgNumTimeDate(du, stDrawCharInfo, pLink,
				                                              &mergedTextAtt, pLine);

#ifdef SUPPORT_SHOW_HWP_TYPESET
				// 쪽 번호  조판부호
				if (document->isShowHWPTypeSetModeEx()) {
					BrINT w = HWPTypesetSymbolWidth(document, pLink, pLine, nCol);
					if (w) {
						stDrawCharInfo.sx = stDrawCharInfo.sx + nDispWid;
						DrawGaroCharSet(du, stDrawCharInfo, pLink, &mergedTextAtt, pLine, BrTRUE, bEffect, painter, BrTRUE);
					}
				}
#endif  // SUPPORT_SHOW_HWP_TYPESET

				if (g_pAppStatic->m_bDrawMasterPageInNormal && (nCol + 1 < nCharNum) && (nDispWid > 0) && pLink->isPageNumLink()) {
					BrINT lArgWid = du.doc2LogicalDX((BrINT32)(cPosArray[nCol + 1] - cPosArray[nCol]), BrFALSE);
					if (lArgWid < nDispWid) {
						sx += nDispWid - lArgWid;
					}
				}
			}
			// for concurrent
			else if (mergedTextAtt.isSrcConCur()) {
				BrBOOL drawSuccess = DrawConCurStringGaro(dc, document, pLine, nCol, nLineHgt, du, dx, dy, nVerAlign, nMaxDescent, document->isFromDoc() && pFrame->isWordMemoFrame());
				if (!drawSuccess) {
					stDrawCharInfo.sx = dx;
					stDrawCharInfo.sy = dy;
					DrawGaroCharSet(du, stDrawCharInfo, pLink, &mergedTextAtt, pLine, BrFALSE, bEffect, painter);
				}
			}
			else {
				nEWCount = 0;
				wCode = pLink->getCode();
				if (
// #ifndef DRAW_KOR_STRING
					(IS_ALPHABET(wCode) || IS_MODERN_KOREAN(wCode) || IsDigit(wCode)) && // 영어/한글 문자 적용 // 숫자도 추가
// #endif  // DRAW_KOR_STRING
					/*textAtt.getCharSp()==0 && */
					pFrame && (pFrame->getTextFlow() == TEXTFLOW_GARO || bCellTextViewOutLine)// 텍스트 방향이 가로일 경우만 적용
					&&	// 텍스트 방향이 가로일 경우만 적용
					(mergedTextAtt.getOutline() || mergedTextAtt.getShadow() || mergedTextAtt.getEmboss() || mergedTextAtt.getEngrave()) == 0
					) {
#ifdef BIDI_SUPPORT
					if (bDisplayCode)
						nEWCount = CountEngWordChar(pLinkArray, nCol, nCharNum, &pLine->getDisplayCodeArray());
					else
#endif  // BIDI_SUPPORT
						nEWCount = CountEngWordChar(pLinkArray, nCol, nCharNum);
				}
#ifdef BIDI_SUPPORT
				if (nEWCount > 1 && !(bBidiPara || pLine->hasBidi())) //Bidi인 경우에는 영문도 하나씩 그리도록 처리
#else
				if (nEWCount > 1)
#endif
				{
					DrawStringOfCharWord(dc, du, dx, dy, nLineHgt, nMaxDescent, &mergedTextAtt, nVerAlign,
					                     pLinkArray, nCol, nEWCount, cPosArray, pLine, bEffect, painter);

					nCol += (nEWCount - 1);
					//영어는 단어단위로 처리하기 때문에 임의로 하이퍼링크 필드 아이디 체크 함수 호출.
					// BoraDoc::m_bIsHypertext false 변경.
					if (document->isFromSlideType())
						IsHyperlinkColorNode(document, pLine, nCol);
				}
				else {
					if (pLink->isBulletLink() && pLink->getCode() != ASCII_CODE_TAB && pLink->getCode() != 0x20) {
						stDrawCharInfo.drawLeftInBullet = BrFALSE;
						if (document->isFromSlideType() && pLine->isEmptyLineBullet()) { //슬라이드 라인에 블릿만 존재하는 경우 블릿 출력 출력시키지 않는다
							CCaret* pCaret = pCmdEngine->getCaret();
							if (!pCaret)
								break;

							CLine* pSLine = pCaret->getSLine();
							CLine* pFirstLineOfPara = pCaret->getLine()->getFirstLineOfPara();

							//[221020][EMO-2135][Paul.S.Jeon] 불릿 출력 시키지 않는 부분 수정
							if (BrFALSE == pCaret->isCaretNormalOrMarking())
							{
								break;
							}
							else if (pSLine != pLine && pFirstLineOfPara != pLine)
							{
								break;
							}
						}
#ifdef BIDI_SUPPORT
						if (!bBidiPara) {
							if (IsRTLChar(pLink->getCode()))
								stDrawCharInfo.drawLeftInBullet = BrTRUE;
						} else if (NUMBER_MIN <= pLink->getCode() && pLink->getCode() <= NUMBER_MAX) {
							stDrawCharInfo.drawLeftInBullet = BrFALSE;
						} else if (IsRTLChar(pLink->getCode())) {
							stDrawCharInfo.drawLeftInBullet = BrTRUE;
						} else if (pLink->isSpecialCharacterInAscii()) {
							if (bulletSpecialCharRTLFlag) {
								stDrawCharInfo.drawLeftInBullet = BrTRUE;
							} else {
								for (BrINT nextCol = nCol + 1; nextCol < nCharNum; nextCol++) {
									CCharSet* nextChar = pLinkArray->getCharSet(nextCol);
									if (!nextChar) {
										stDrawCharInfo.drawLeftInBullet = BrTRUE;
									} else if(nextChar->isTextLink() && nextChar->getSubType() == BULLET_CHAR) {
										BrWORD code = nextChar->getCode();
										if (nextChar->isSpecialCharacterInAscii()) {
											continue;
										} else if (IsRTLChar(code)) {
											stDrawCharInfo.drawLeftInBullet = BrTRUE;
											bulletSpecialCharRTLFlag = BrTRUE;
										} else {
											stDrawCharInfo.drawLeftInBullet = BrFALSE;
										}
									} else {
										stDrawCharInfo.drawLeftInBullet = BrTRUE;
										bulletSpecialCharRTLFlag = BrTRUE;
									}
									break;
								}
							}

							if (stDrawCharInfo.drawLeftInBullet && pLink->isFlipDrawingCharacterInRtlBullet()) {
								stDrawCharInfo.flipInBullet = BrTRUE;
							}
						} else {
							stDrawCharInfo.drawLeftInBullet = BrFALSE;
							bulletSpecialCharRTLFlag = BrFALSE;
						}
							
						if (bDisplayCode && nCol < pLine->getDisplayCodeArray().size()) {
							BrWORD wNewCode = pLine->getDisplayCodeArray().at(nCol);
							if (0 == wNewCode)
								continue;

							if (wNewCode != pLink->getCode()) {
								pLink->setCode(wNewCode);
							}
						}
#endif
						CBullet* pBullet = CTextProc::getCurrentBulletOfCurLine(document, pLine);
						if (pBullet) {
							CBulletItem* pBulletItem = pBullet->getBulletItem(pLine->getBulletDepth());
							if (pBulletItem) {
								//[2013-12-1][T-19082][20hoon]
								stDrawCharInfo.nCol = nCol;
								BrWORD* pFaceName = document->getFontArray()->getFaceName(mergedTextAtt.getEngFontID());
#ifdef USE_EMBEDDED_SYMBOL_FONT
								// Wingdings
								// if ( pBullet->getHanFaceName().compare(BString("Wingdings"))==0 || pBullet->getEngFaceName().compare(BString("Wingdings"))==0 )
								if (CUtil::isWingdingFont(pFaceName)) {
									//[2013-12-6][T-19362][20hoon][Support Wordart to bullet]
									DrawGaroCharSet(du, stDrawCharInfo, pLink, &mergedTextAtt, pLine, BrFALSE, bEffect, painter);
									continue;
								}
								// Symbol
								// if ( pBullet->getHanFaceName().compare(BString("Symbol"))==0 || pBullet->getEngFaceName().compare(BString("Symbol"))==0 )
								if (CUtil::isSymbolFont(pFaceName)) {
									//[2013-12-6][T-19362][20hoon][Support Wordart to bullet]
									DrawGaroCharSet(du, stDrawCharInfo, pLink, &mergedTextAtt, pLine, BrFALSE, bEffect, painter);
									continue;
								}
#endif  // USE_EMBEDDED_SYMBOL_FONT
								// minus code는 직접 그리자. (2011.3.8)
								if (wCode == 0x2013) {
									pLink->setCode(0x2d);
									DrawGaroCharSet(du, stDrawCharInfo, pLink, &mergedTextAtt, BrNULL, BrFALSE, bEffect, painter);
									pLink->setCode(0x2013);
									continue;
								}
								if (pBullet->getBulletItem(pLine->getBulletDepth())->isBulletType() && pFrame->getPage() == BrNULL) {
									//클립보드에서 처리중은 getPage가 null이다.
									continue;
								}

								DrawGaroCharSet(du, stDrawCharInfo, pLink, &mergedTextAtt, pLine, BrFALSE, bEffect, painter); // eypark82
							}
						}
						else
							DrawGaroCharSet(du, stDrawCharInfo, pLink, &mergedTextAtt, pLine, BrFALSE, bEffect, painter); //[2013-12-6][T-19362][20hoon][Support Wordart to bullet]
					}
					else {
						CCharSet drawingLink = *pLink;
						if (bDisplayCode && nCol < pLine->getDisplayCodeArray().size()) {
							BrWORD wNewCode = pLine->getDisplayCodeArray().at(nCol);
							if (0 == wNewCode)
								continue;

							if (wNewCode != drawingLink.getCode()) {
								drawingLink.setCode(wNewCode);
							}
						}

						stDrawCharInfo.sx = dx;
						stDrawCharInfo.sy = dy;
						stDrawCharInfo.nCol = nCol;

						// 스크롤 시, Break 마크가 나타나지 않아 DrawGaroCharSet에서 그려주던 것을 여기서 그려줌.

#ifdef SUPPORT_HWP_PAGE_BREAK
						if (wCode == ASCII_CODE_CR && !painter->pDC->isExportMode() && (drawingLink.isPageBreak() || drawingLink.isColBreak() || drawingLink.isSectionBreak() || drawingLink.isPageBreakHWP()))
#else
						if (wCode == ASCII_CODE_CR && !painter->pDC->isExportMode() && (drawingLink.isPageBreak() || drawingLink.isColBreak() || drawingLink.isSectionBreak()))
#endif
						{
							BRect rcFrame = pLine->getFrame()->getFrameRect();
							du.doc2Logical(rcFrame);
							if (sy > rcFrame.nBottom) {
								if (!(drawingLink.isColBreak() && document->isFromDoc() && document->getCompatibilityModeVersion() == eCOMPATIBILITY_V12 && pLine->getCharNum() == 1)) // XPD-14272
									return;
							}

							if (stDrawCharInfo.sx < rcFrame.nRight) {
								// 한 라인에 Break Code 가 여러개 있는 경우를 위하여.
								BrINT nEx;
								if (nCol < (nCharNum - 1))
									nEx = sx + du.doc2LogicalDX((BrINT32)(cPosArray[nCol + 1]), BrFALSE);
								else
									nEx = rcFrame.nRight;
								DrawBreakCode(dc, du, &mergedTextAtt, drawingLink.getSubType(), stDrawCharInfo.sx, sy - nLineHgt / 2, nEx, sy - nLineHgt / 2, BrFALSE);
							}
						}
						else
							DrawGaroCharSet(du, stDrawCharInfo, &drawingLink, &mergedTextAtt, pLine, BrFALSE, bEffect, painter);
					}
				}
			}
		}
		else if (pLink->isImageBulletLink()) {
			// TODO : clipping
			DrawImageBullet(document, dc, du, pFrame, pLink, stDrawCharInfo);
		}
		else if (pLink->isAnchorLink()) {
			pObject = document->getAnchorFrame(pLink->getCode());
			if (!pObject)
				continue;

			// Header, Footer 등에서 가로, 세로 용지가 바뀌는 경우 동일한 anchored frame을 사용하기 때문에 이 곳에서 정렬을 한번 한다 WPD-1232, LQQ-7776
			if (!bArrange && (pFrame->isHeader() || pFrame->isFooter()) && pObject->getAnchorLine() && pObject->getAnchorLine() != pLine) {
				CTextProc::arrangeOneLine(document, pLine, BrFALSE, BrFALSE, BrTRUE, BrFALSE, BrNULL);
				nCharNum = pLine->getCharNum();
				if (nCol >= nCharNum)
					break;
				bArrange = BrTRUE;
			}

			if (document->isViewOutlineMode() && !pObject->isTable() && document->getDocType() != BORA_DOCTYPE_DOC)
				continue;

			// 글자처럼 취급된 경우
			if (pObject->isAnchored()) {
				if (painter->pDC->isExportMode()) {
					//[2013.07.03][inkkim][#31178] 도형 export시에는 normal mode로 해야함
					BrBYTE nOldMode = dc->setExportMode(eNormalExtMode);
					BrRect orgClipRect;
					dc->getClipRect(orgClipRect);
					dc->setClipRect(BrNULL);
					BrEXPORT_INFO sInfo;
					BrPOINT sOffset;
					painter->pDC->getExport(&sInfo);
					sOffset.x = sInfo.nPosX;
					sOffset.y = sInfo.nPosY;
					pObject->ExportPDF(painter, &sOffset);
					dc->setExportMode(nOldMode);
					dc->setClipRect(&orgClipRect);
				}
				else {
					BrINT nOldBandStart = GetAvailAreaMatrix()[0][0];
					BrINT nOldBandEnd = GetAvailAreaMatrix()[0][1];

					// HWP에서 우선 anchored frame을 clip 시키자.
					BrRect orgClipRect, clipRect;
					BrBOOL bClip = BrFALSE;
					if (document->isFromHwp() && (pFrame->isSpecial() || pFrame->isCell()) && (pObject->GetClass() == HWP_CHARTFRAME || pObject->GetClass() == HWP_EQUATIONFRAME || pObject->isWordArt())) {
						dc->getClipRect(orgClipRect);

						BRect rcFrameRect = pFrame->getFrameRect();
						du.doc2Logical(rcFrameRect);
						// if original clip is initial clip, skip intersection
						if (!(orgClipRect.left == 0 && orgClipRect.right == 0 && orgClipRect.top == 0 && orgClipRect.bottom == 0)) {
							rcFrameRect.Intersection(orgClipRect);
							// when there is a intersection clip, set clipping
							if (rcFrameRect.nRight >= rcFrameRect.nLeft && rcFrameRect.nBottom >= rcFrameRect.nTop) {
								clipRect = rcFrameRect.getBrRect();
								dc->setClipRect(&clipRect);
								bClip = BrTRUE;
							}
						}
					}
					else if (document->isFromOdt()) {
						if (pObject->isTable()) {
							BrBOOL bBasicOneColumn = BrFALSE;
							if (pObject->getAnchorLine() && !pObject->getAnchorLine()->isInMultiColumns())
								bBasicOneColumn = BrTRUE;

							if (bBasicOneColumn) {//XPD-7548
								dc->getClipRect(orgClipRect);

								// if original clip is initial clip, skip intersection
								if (!(orgClipRect.left == 0 && orgClipRect.right == 0 && orgClipRect.top == 0 && orgClipRect.bottom == 0)) {
									BRect rcFrameRect = pFrame->getFrameRect();
									du.doc2Logical(rcFrameRect);

									rcFrameRect.Intersection(orgClipRect);

									// when there is a intersection clip, set clipping
									if (rcFrameRect.nRight >= rcFrameRect.nLeft && rcFrameRect.nBottom >= rcFrameRect.nTop) {
										clipRect = rcFrameRect.getBrRect();
										clipRect.left -= DEF_MARGIN_PIX;
										clipRect.right += DEF_MARGIN_PIX;

										if (orgClipRect.left < clipRect.left)
											clipRect.left = orgClipRect.left;

										if (orgClipRect.top < clipRect.top)
											clipRect.top = orgClipRect.top;

										if (orgClipRect.right > clipRect.right)
											clipRect.right = orgClipRect.right;

										if (orgClipRect.bottom > clipRect.bottom)
											clipRect.bottom = orgClipRect.bottom;

										dc->setClipRect(&clipRect);
										bClip = BrTRUE;
									}
								}
							}
							else {//소속 컬럼 안에서만 그려준다
								dc->getClipRect(orgClipRect);
								BRect rcFrameRect = pFrame->getFrameRect();
								du.doc2Logical(rcFrameRect);
								// if original clip is initial clip, skip intersection
								if (!(orgClipRect.left == 0 && orgClipRect.right == 0 && orgClipRect.top == 0 && orgClipRect.bottom == 0))
									rcFrameRect.Intersection(orgClipRect);

								// when there is a intersection clip, set clipping
								if (rcFrameRect.nRight >= rcFrameRect.nLeft && rcFrameRect.nBottom >= rcFrameRect.nTop) {
									clipRect = rcFrameRect.getBrRect();
									clipRect.left -= DEF_MARGIN_PIX;
									clipRect.top -= DEF_MARGIN_PIX;
									clipRect.right += DEF_MARGIN_PIX;
									clipRect.bottom += DEF_MARGIN_PIX;
									dc->setClipRect(&clipRect);
									bClip = BrTRUE;
								}
							}
						}
						else if (pFrame->isCell()) { // ODT cell내 개체는 cell 영역에 영향받지 않음 SRG-91
							CPage* pPage = pFrame->getPage();
							BRect rect(0, 0, pPage->width(), pPage->height());

							dc->getClipRect(orgClipRect);
							pCmdEngine->page2Logical(pPage, rect);
							clipRect = rect.getBrRect();
							dc->setClipRect(&clipRect);
							bClip = BrTRUE;
						}
					}

					//ZPD-27134 Anchor 노드가 글자들 사이나 뒤에 있을때 m_bBwpDrawForeground 값을 draw함수에서 초기화하기 때문에 BackUp이 필요함.
					BYTE m_bBackUp = document->getCmdEngine()->m_bBwpDrawForeground;

					// "넘치면 텍스트 크기 조정" 에서 Image Bullet 처리 LQQ-5976, MQP-13116
					/*
					if ( document->isFromPpt() && pFrame->getAutoFitfontScale()>=1000 && pFrame->getAutoFitfontScale()<100000 && pLink->isBulletImageLink() )
					{
						BrINT nFrameWidth = pObject->width();
						BrINT nFrameHeight = pObject->height();
						BRect rcBack = pObject->getFrameRect();

						BrINT nXGap = nFrameWidth - (BrINT)(nFrameWidth * pFrame->getAutoFitfontScale()/100000.0);
						BrINT nYGap = nFrameHeight - (BrINT)(nFrameHeight * pFrame->getAutoFitfontScale()/100000.0);

						pObject->setRight(pObject->right()-nXGap);
						pObject->setTop(pObject->top()+nYGap*0.75);
						pObject->setBottom(pObject->bottom()-nYGap*0.25);

						pObject->draw(painter, dc, du);

						pObject->setFrameRect(rcBack);
					}
					else
					*/
					{
						document->setCallingDrawDuringOneLineDrawing(BrTRUE);
						pObject->draw(painter, dc, du);
						document->setCallingDrawDuringOneLineDrawing(BrFALSE);
						document->getRevisionEngine()->drawRevisionStrike(pObject, du, dc);
					}

					document->getCmdEngine()->m_bBwpDrawForeground = m_bBackUp;

					if (bClip)
						dc->setClipRect(&orgClipRect);

					// backup and restore the band area [RGD-725], ZPD-32489
					GetAvailAreaMatrix()[0][0] = nOldBandStart;
					GetAvailAreaMatrix()[0][1] = nOldBandEnd;

#ifdef SUPPORT_SHOW_HWP_TYPESET
					// 글자처럼 취급된 Object 조판부호
					if (document->isShowHWPTypeSetModeEx()) {
						BrINT w = HWPTypesetSymbolWidth(document, pLink, pLine, nCol);
						if (w) {
							stDrawCharInfo.sx = sx + du.doc2LogicalDX((BrINT32)(cPosArray[nCol + 1] - w), BrFALSE);
							DrawGaroCharSet(du, stDrawCharInfo, pLink, &mergedTextAtt, pLine, BrTRUE, bEffect, painter, BrTRUE);
						}
					}
#endif  // SUPPORT_SHOW_HWP_TYPESET
				}
			}
			else // display multi depth floating line_frame(추후 basic frame내 floating line_frame 고려 처리), XPD-15332
			{
				if (IsDrawFloatingFrame(pObject, pFrame, document->isFromHwp(), BrNULL))
					pObject->draw(painter, dc, du);
#ifdef SUPPORT_SHOW_HWP_TYPESET
				// floating line_frame 조판부호
				if (BrFALSE == pObject->isODTFrame() && document->isShowHWPTypeSetModeEx()) {
					stDrawCharInfo.nCol = nCol;
					DrawGaroCharSet(du, stDrawCharInfo, pLink, &mergedTextAtt, pLine, BrTRUE, bEffect, painter, BrTRUE);
				}
#endif  // SUPPORT_SHOW_HWP_TYPESET
			}

			ResetDrawCharInfo(document);
		}
		else if (pLink->isTypesetLink() != 0) {
			if (pLink->isFootnoteEndnoteLink())
				pLine->clearBitmapCache();
			if (mergedTextAtt.isDrawUnderLine())
				pCmdEngine->m_bBwpDrawForeground |= TEXT_UNDERLINE_FOREGROUND;

			stDrawCharInfo.nCol = nCol;	// ZPD-21178
			DrawGaroCharSet(du, stDrawCharInfo, pLink, &mergedTextAtt, pLine, BrTRUE, bEffect, painter);

#ifdef SUPPORT_SHOW_HWP_TYPESET
			// Typeset 조판부호
			if (document->isShowHWPTypeSetModeEx()) {
				BrINT w = HWPTypesetSymbolWidth(document, pLink, pLine, nCol);
				if (w) {
					stDrawCharInfo.sx = sx + du.doc2LogicalDX((BrINT32)(cPosArray[nCol + 1] - w), BrFALSE);
					DrawGaroCharSet(du, stDrawCharInfo, pLink, &mergedTextAtt, pLine, BrTRUE, bEffect, painter, BrTRUE);
				}
			}
#endif  // SUPPORT_SHOW_HWP_TYPESET
		}
#ifdef SUPPORT_SHOW_HWP_TYPESET
		else {
			// 그 외 조판부호
			if (document->isShowHWPTypeSetModeEx()) {
				if ((cPosArray[nCol + 1] - cPosArray[nCol]) > 0) {
					DrawGaroCharSet(du, stDrawCharInfo, pLink, &mergedTextAtt, pLine, BrTRUE, bEffect, painter, BrTRUE);
				}
			}
		}
#endif  // SUPPORT_SHOW_HWP_TYPESET
	}
	const PoParaAtt* para_att = document->getParaAttHandler()->getOrgParaAtt(pLine->getParaID());
	if (para_att->getRevisionID() != default_revision_val && pLine->isStartLine())
		bRevisionLine = BrTRUE;
	pLine->setRevisionLine(bRevisionLine);

	//  dc->SetBkMode(nOldBkMode);
#ifdef SUPPORT_TABLET_VIEW_MODE
	if (document->isTabletViewMode() && pLine->getPgNumForEBook())
		CCUtil::drawLine(dc, sx, sy - nLineHgt, sx + 30, sy - nLineHgt, 1, RGB_RED);
#endif
}


// draw horizontal line character
void CTextDraw::DrawHorizontalLineCode(BrDC* dc, BrINT x, BrINT y, BrINT w, BrINT h, BrINT direction)
{
	if (GARO == direction) {
		dc->drawLine(x, y - h/2, x, y - h/2 - 1);
		dc->drawLine(x, y - h/2 - 1, x + w, y - h/2 - 1);
		dc->setPenColor(192, 192, 192);  // RGB_LTGRAY
		BrBmvPen pen;
		pen.createPen(eSolidPen, 1, 192, 192, 192);
		BrBmvPen* prev_pen = dc->setPen(&pen);
		dc->drawLine(x, y - h/2 + 1, x + w, y - h/2 + 1);
		dc->drawLine(x + w, y - h/2 + 1, x + w, y - h/2 - 2);
		dc->setPen(prev_pen);
	}
	else {
		dc->drawLine(x + h/2, y, x + h/2 + 1, y);
		dc->drawLine(x + h/2 + 1, y, x + h/2 + 1, y + w);
		dc->setPenColor(192, 192, 192);  // RGB_LTGRAY
		dc->drawLine(x + h/2 - 1, y, x + h/2 - 1, y + w);
		dc->drawLine(x + h/2 - 1, y + w, x + h/2 + 2, y + w);
	}
}


BrBOOL CTextDraw::checkEditSymbol(CCharSet *link)
{
	if (!link || link->isBreakLink()) return BrFALSE;

	BrWORD code = link->getCode();
	return (code == ASCII_CODE_CR || code == ASCII_CODE_TAB || code == ASCII_CODE_SPACE ||
		code == SOFT_ENTER || code == NON_BREAKING_SPACE || code == IDEOGRAPHIC_SPACE);
}


BrBOOL CTextDraw::checkDrawEdit(CDrawUnit &du, CLine *pLine, CCharSet *pLink)
{
	if (!pLine || !pLink)
		return BrFALSE;

	CFrame *revision_frame = pLine->getFrame();
	if (revision_frame && revision_frame->isRevisionFrame())
		return BrFALSE;

	BoraDoc *document = theBWordDoc;
#ifdef SUPPORT_NIGHT_VIEW_MODE
	if (document->isNightViewMode())
		return BrFALSE;
#endif  // SUPPORT_NIGHT_VIEW_MODE

	if (document->getEditProtect()) //[LQQ-6338]보기모드에서 편집기호 표시됨.
		return BrFALSE;

	if (g_pAppStatic->isPrtPreview())
		return BrFALSE; //프린트시에는 표시 하지 않음

	if (g_BoraThreadAtom.m_nPrintStatus == PRINT_STATUS_START || g_BoraThreadAtom.m_nPrintStatus == PRINT_STATUS_PROGRESS)	//ZPD-4940
		return BrFALSE;

	CCmdEngine *pCmdEngine = document->getCmdEngine();
	BrEditSymbolShowStateSetting pShowState = pCmdEngine->getEditSymbolShowState();

	BrWORD wCode = pLink->getCode();
	if (BrFALSE == pCmdEngine->IsShowEditSymbol()) {
		if ((ASCII_CODE_CR == wCode || SOFT_ENTER == wCode) && BrFALSE == pShowState.bCR)
			return BrFALSE;
		if (ASCII_CODE_TAB == wCode && BrFALSE == pShowState.bTab)
			return BrFALSE;
		if ((ASCII_CODE_SPACE == wCode || NON_BREAKING_SPACE == wCode || IDEOGRAPHIC_SPACE == wCode) && BrFALSE == pShowState.bSpace)
			return BrFALSE;
	}

#ifndef HIDE_CR_CODE
	if (ASCII_CODE_CR == wCode || SOFT_ENTER == wCode) {
		//if (!IsClipRegion(sx, sy - 10, 9, 9))
		//	return BrFALSE;

		// Line의 logical height가 9 pixel 이하이면 그리지 않는다 XPD-14805
		if (pLine && du.doc2LogicalDX(pLine->getHeight() + pLine->getLineSp(), BrFALSE) < 9)
			return BrFALSE;
	}
	
#endif  // HIDE_CR_CODE

	CPage *page = pLine->getPage();
	if (page && page->isBatangPage())
		return BrFALSE;

	return BrTRUE;
}


BrWORD CTextDraw::codeForDrawing(BrWORD wCode, BrBOOL bSero)
{
	BoraDoc *document = theBWordDoc;

	if (ASCII_CODE_TAB == wCode) {
		if (bSero)
			return 0xAF;  // 0x2B63;  // 0x2193;
		else
			return 0xAE;  // 0x2B62;  // 0x2192;
	}
	if (ASCII_CODE_SPACE == wCode) {
		if (BrIsShowDiffEditingSymbol() && (document->isFromHwp() || document->isFromOdt()))
			return 0x02C7;
		else
			return 0x00B7;
	}
	if (NON_BREAKING_SPACE == wCode)
		return 0xB0;
	if (IDEOGRAPHIC_SPACE == wCode)
		return 0x2B1C; //0x25A1;
	if (SOFT_ENTER == wCode) {
		if (bSero)
			return 0xAC;  // 0x2B60;  // 0x2190;
		else
			return 0xAF;  // 0x2B63;  // 0x2193;
	}
	if (ASCII_CODE_CR == wCode)
		return 0x2936;

	return 0;
}


void CTextDraw::DrawEditSymbol(CDrawUnit& du, BRDRAWCHARINFO stDrawCharInfo, BrINT nCurPos,
                               BrINT nNextPos, CCharSet* pLink, CLine* pCurLine,
                               const PoTextAtt* pTextAtt, BrINT sx, BrBOOL bSero)
{
	if (!pLink || !pCurLine || !pTextAtt)
		return;

	CFrame *frame = pCurLine->getFrame();
	if (!frame)
		return;

	if (!checkDrawEdit(du, pCurLine, pLink))
		return;

	// limit. lower bound. XPD-10568.
	if (!bSero && pCurLine->getHeight() < 60)
		return;

	BoraDoc *document = theBWordDoc;
	BrBOOL isRTLLine = pCurLine->GetParaAtt()->getBiDi();
	BrWORD wCode = pLink->getCode();

	BrBOOL need_rotate = document->isFromDoc() || document->isFromHwp();  // document->isFromOdt();
	BrWORD wEditCode = codeForDrawing(wCode, bSero && !frame->isTextFlowBottomToTop() && need_rotate);
	if (wEditCode == 0)
		return;

	CCharSet cLink = *pLink;
	cLink.setCode(wEditCode);

	// 너비 계산 시, rotate 고려.
	wEditCode = codeForDrawing(wCode, bSero && !frame->isTextFlowBottomToTop());

	PoTextAtt editCodeTextAtt;

	BrINT nFontID;
	if (wCode == ASCII_CODE_TAB || wCode == SOFT_ENTER)
		nFontID = document->getFontArray()->getFontID((BrLPCTSTR)"Symbol");
	else
		nFontID = document->getFontArray()->getFontID((BrLPCTSTR)"Times New Roman");  // "Cambri"

	if (IDEOGRAPHIC_SPACE == wCode) {
		editCodeTextAtt = *pTextAtt;
	}
	else {
		editCodeTextAtt.setHanFontID(nFontID);
		editCodeTextAtt.setEngFontID(nFontID);
	}

	//[ZPD-408][2014-08-24][sangdon]:편집기호(탭,띄어쓰기) 표시가 글자 위치 조정을 하는것을 적용받도록 하기 위해서.
	if (pTextAtt)
		editCodeTextAtt.setTextVerticalPos(pTextAtt->getTextVerticalPos());

	if (pTextAtt && wCode == ASCII_CODE_SPACE) {
		if (BrIsShowDiffEditingSymbol() && (document->isFromHwp() || document->isFromOdt())) {
			if (pTextAtt->getEngFSize() < 240 || pTextAtt->getHanFSize() < 240) {
				editCodeTextAtt.setEngFSize(pTextAtt->getEngFSize());
				editCodeTextAtt.setHanFSize(pTextAtt->getHanFSize());
			}
			else {
				editCodeTextAtt.setEngFSize(240);
				editCodeTextAtt.setHanFSize(240);
			}
		}
		else {
			editCodeTextAtt.setEngFSize(pTextAtt->getEngFSize());
			editCodeTextAtt.setHanFSize(pTextAtt->getHanFSize());
		}
	}

	editCodeTextAtt.setBold(BrTRUE);

	if (BrIsShowDiffEditingSymbol() && (document->isFromHwp() || document->isFromOdt()))
		editCodeTextAtt.setTextColor(BrRGB(65, 155, 225));
	else
		editCodeTextAtt.setTextColor(RGB_DKGRAY);

	BrINT nOneWidth = CTextProc::getTextLinkWidth(document, &editCodeTextAtt, wEditCode, BrNULL);

	if (nOneWidth != 0 && ((!isRTLLine && nCurPos < nNextPos) || (isRTLLine && nNextPos < nCurPos))) {
		if (bSero) {
			int code_width = du.doc2LogicalDY(nOneWidth, BrFALSE);
			int width = du.doc2LogicalDY((nNextPos - nCurPos), BrFALSE);
			int f_size = du.doc2LogicalDX(editCodeTextAtt.getHanFSize(), BrFALSE);

			if (frame->isTextFlowBottomToTop()) {
				int dy = du.doc2LogicalDY(nCurPos, BrFALSE);
				stDrawCharInfo.sy = sx - dy;

				if (wCode == SOFT_ENTER)
					stDrawCharInfo.sy -= code_width;
				else if (wCode == ASCII_CODE_CR)
					stDrawCharInfo.sy -= width / 2;
				else
					stDrawCharInfo.sy -= width / 2 + code_width / 2;

				if (wCode == ASCII_CODE_CR)
					stDrawCharInfo.sx += f_size / 5;
			}
			else {
				if (wCode == SOFT_ENTER)
					stDrawCharInfo.sy += code_width / 2;
				else if (wCode != ASCII_CODE_CR)
					stDrawCharInfo.sy += width / 2 - code_width / 2;

				if (wCode == ASCII_CODE_CR)
					stDrawCharInfo.sx -= f_size / 2;
			}

			DrawSeroCharSet(du, stDrawCharInfo, pCurLine->getFrame(), &cLink, &editCodeTextAtt, pCurLine);
		}
		else {
			int code_width = du.doc2LogicalDX(nOneWidth, BrFALSE);
			int width = du.doc2LogicalDX((nNextPos - nCurPos), BrFALSE);
			int f_size = du.doc2LogicalDY(editCodeTextAtt.getHanFSize(), BrFALSE);

			if (isRTLLine) {
				if (wCode == SOFT_ENTER)
					stDrawCharInfo.sx -= code_width / 2;
				else if (wCode != ASCII_CODE_CR)
					stDrawCharInfo.sx += (width + code_width) / 2;

				if (wCode == ASCII_CODE_CR)
					stDrawCharInfo.sy += f_size / 5;
			} else {
				if (wCode == SOFT_ENTER)
					stDrawCharInfo.sx += code_width / 2;
				else if (wCode != ASCII_CODE_CR)
					stDrawCharInfo.sx += width / 2  - code_width / 2;

				if (wCode == ASCII_CODE_CR)
					stDrawCharInfo.sy += f_size / 5;
			}
			
			DrawGaroCharSet(du, stDrawCharInfo, &cLink, &editCodeTextAtt, pCurLine);
		}
	}
}


void CTextDraw::DrawGaroHWPTabFill(BrDC* dc, CDrawUnit& dUnit, BRDRAWCHARINFO stDrawCharInfo,
                                   BrINT nCurPos, BrINT nNextPos, BrINT sx, BrINT nFillCode,
                                   const PoTextAtt* pTextAtt)
{
	BrINT nSx = sx + dUnit.doc2LogicalDX(nCurPos, BrFALSE);
	BrINT nEx = sx + dUnit.doc2LogicalDX(nNextPos, BrFALSE);
	BrINT nWidth = dUnit.doc2LogicalDY(pTextAtt->getHanFSize(), BrFALSE);
	BrINT nSy = stDrawCharInfo.sy - nWidth / 2;
	DrawHWPTabFill(dc, nSx, nSy, nEx, nSy, nFillCode, pTextAtt->getTextColor().getColor(), nWidth);
}


// draw tab fill code for HWP
void CTextDraw::DrawHWPTabFill(BrDC* dc, BrINT nSx, BrINT nSy, BrINT nEx, BrINT nEy,
                               BrINT nFillCode, BrINT color, BrINT nWidth)
{
	BrINT pen_style = eSolidPen;
	BrINT8 line_style = eSimple;
	switch (nFillCode) {
		case 1:                                                  break;
		case 2:   pen_style = eDash;                             break;
		case 3:   pen_style = eRoundDot;                         break;
		case 4:   pen_style = eLongDashDot;                      break;
		case 5:   pen_style = eLongDashDotDot;                   break;
		case 6:   pen_style = eLongDash;                         break;
		case 7:   pen_style = eLargeGapDot;                      break;
		case 8:   if (6 < nWidth)  line_style = eDouble;         break;
		case 9:   if (6 < nWidth)  line_style = eThinThick;      break;
		case 10:  if (6 < nWidth)  line_style = eThickThin;      break;
		case 11:  if (6 < nWidth)  line_style = eTriple;         break;
		default:                                                 return;
	}

	BrBmvPen pen;
	pen.createPen(pen_style, 1, color);
	pen.setLineStyle(line_style);
	pen.setCellLine(BrTRUE);

	BrBmvPen* prev_pen = dc->setPen(&pen);
	dc->drawLine(nSx, nSy, nEx, nEy);
	dc->setPen(prev_pen);
}


BrINT CTextDraw::DrawGaroCharSetPgNumTimeDate(CDrawUnit& du, BRDRAWCHARINFO& rDrawCharInfo,
                                              CCharSet* pLink, const PoTextAtt* pTextAtt,
                                              CLine* pLine)
{
	rDrawCharInfo.bBidiPara = BrFALSE;
	DrawGaroCharSet(du, rDrawCharInfo, pLink, pTextAtt, pLine);
	PoDcTextAtt* pDcTextAtt = theBWordDoc->getTextAttHandler()->getCurDrawingDcTextAtt();
	unsigned short m_qBuffer[MAX_DRAWCHAR_BUF_LEN] = {0,};
	pDcTextAtt->getTextString()->getString(m_qBuffer, pDcTextAtt->getTextString()->length());
	return CTextProc::getStringWidthW(theBWordDoc,
	                                  (BrLPWORD)m_qBuffer,
	                                  pDcTextAtt->getHanFontID(),
	                                  pDcTextAtt->getHanFSize(),
	                                  BrFALSE, BrFALSE, BrFALSE,
	                                  pDcTextAtt->getHanExpCom());
}


#ifdef SUPPORT_SHOW_HWP_TYPESET
BrINT CTextDraw::HWPTypesetSymbolWidth(BoraDoc* document, CCharSet* pLink, CLine* pLine, BrINT nCol)
{
	if (!document || !pLink)
		return 0;

	BrHWPTypeSetSymbolIndex nIndex = CTextProc::getHWPTypesetSymbolIndex(document, pLink);
	// get String Width
	if (nIndex >= INDEX_HWP_TYPESET_HEADER_BOTH && nIndex < INDEX_HWP_TYPESET_MAX) {
		const PoTextAtt* pTextAtt = BrNULL;
		if (nIndex == INDEX_HWP_TYPESET_CONCURRENT)
			pTextAtt = pLine->getSrcConCurrentTextAtt(nCol);
		else
			pTextAtt = document->getTextAttHandler()->getTextAtt(pLink->getAttrID());
		if (!pTextAtt)
			return 0;
		return CTextProc::getStringWidthW(document, strHWPTypeSetSymbol[nIndex], 0, pTextAtt->getHanFSize(),
		                                  (pTextAtt->getSuperscript() || pTextAtt->getSubscript()),
		                                  pTextAtt->getBold(), pTextAtt->getItalic(),
		                                  pTextAtt->getHanExpCom());
	}

	return 0;
}
#endif  // SUPPORT_SHOW_HWP_TYPESET


// draw garo concurrent string with top/bottom position
BrBOOL CTextDraw::DrawConCurStringGaro(BrDC* dc, BoraDoc* document, CLine* pLine, BrINT & nCol, BrINT lineHeight, 
									 CDrawUnit& cCoord, PoPixel sx, PoPixel sy, BrINT nVerAlign, BrINT nMaxDescent, BrBOOL isWordMemoFrame)
{
	if (!document || !pLine) {
		BRTHREAD_ASSERT(BrFALSE);
		return BrFALSE;

	}

	BrINT  nCharNum = pLine->getCharNum();
	if (nCharNum == 0) {
		BRTHREAD_ASSERT(BrFALSE);
		return BrFALSE;
	}

	// 1. 윗주의 전체 크기 계산하여 필요값들 얻어오기

	PoConcurSizeInfo sizeInfo = CTextDraw::getConcurSizeInfo(document, pLine, nCol, GARO, isWordMemoFrame);

	if (sizeInfo.concurCount == 0)
		return BrFALSE;

	// 2. 원본 글자 그리기

	BRDRAWCHARINFO stDrawCharInfo = {};
	stDrawCharInfo.pDC = dc;
	stDrawCharInfo.nLineHgt = (nVerAlign == BR_TEXT_VALIGN_BOTTOM) ? lineHeight : lineHeight + cCoord.doc2LogicalDY(sizeInfo.destConcurHeight, BrFALSE);
	stDrawCharInfo.nDescent = nMaxDescent;
	stDrawCharInfo.nFlag = nVerAlign;
	stDrawCharInfo.bBidiPara = pLine->isParaRtL();

	PoTwip dx, dy, nCharWid;
	PoTwip nTotalCharSp = 0;

	PoTextAttHandler* pTextAttHandler = document->getTextAttHandler();
	const PoTextAtt* text_att = pTextAttHandler->getTextAtt(pLine->getCharSet(nCol)->getAttrID());
	const PoTextAtt* defaultAtt = pTextAttHandler->getDefaultAttr();
	BrWORD defaultHanFontSize = defaultAtt->getHanFSize();
	BrWORD defaultEngFontSize = defaultAtt->getEngFSize();
	if (BrNULL == text_att) {
		BRTHREAD_ASSERT(BrFALSE);
		return BrFALSE;
	}
	if (text_att->getCharSp())
		nTotalCharSp = (BrINT)((text_att->getCharSp() * (float)sizeInfo.sourceConcurWidth) / 100.0 + 0.5);
	if (text_att->getPositionForConCur() == BOTTOM_POS_CONCUR) {
		PoTwip lineSpace = pLine->getLineSp();
		PoTwip concurSpace = sizeInfo.sourceConcurHeight + sizeInfo.destConcurHeight + sizeInfo.concurSpace;
		if (lineSpace < concurSpace)
			lineSpace = concurSpace;
	}

	PoConcurAlign bAlign = (PoConcurAlign)text_att->getAlignForConCur();

	dx = (sizeInfo.totalConcurWidth - sizeInfo.sourceConcurWidth);

	if (dx > 0) { // source보다 dest가 크기가 클 때.
		switch (bAlign) {
			case LEFT_CONCUR:
				dx = 0;
				break;
			//case RIGHT_CONCUR: // ?? 왜 이건 주석인것인가
			//	break;
			case CENTER_CONCUR:
			case JUSTIFY_010_CONCUR:
			case JUSTIFY_121_CONCUR:
				dx = dx / 2;
				break;
		}
	}

	BrINT prevAttID = PO_TEXTATT_BASE::notSettedID;

	for (; nCol < nCharNum; nCol++) {
		CCharSet* pLink = pLine->getCharSet(nCol);
		BrWORD wCode = pLink->getCode();

		if (prevAttID != pLink->getAttrID()) {
			prevAttID = pLink->getAttrID();
			text_att = pTextAttHandler->getTextAtt(prevAttID);
			if (isWordMemoFrame) {
				PoTextAtt sizeChangedTextAtt = *text_att;
				sizeChangedTextAtt.setHanFSize(defaultHanFontSize);
				sizeChangedTextAtt.setEngFSize(defaultEngFontSize);
				text_att = pTextAttHandler->insertAndGetTextAtt(sizeChangedTextAtt);
			}

			if (text_att->isSrcConCur() == BrFALSE)
				break;
		}		

		stDrawCharInfo.sx = sx + cCoord.doc2LogicalDX(dx, BrFALSE);
		stDrawCharInfo.sy = sy;
		stDrawCharInfo.nCol = nCol;

		DrawGaroCharSet(cCoord, stDrawCharInfo, pLink, text_att, pLine, BrTRUE, text_att->isWordArtStyle(), getPainter());

		nCharWid = CTextProc::getTextLinkWidth(document, text_att, wCode, pLink);

		dx += nCharWid;
		if (text_att->getCharSp())
			dx += (BrINT)((text_att->getCharSp() * (float)nCharWid) / 100.0 + 0.5);
		sizeInfo.concurCount--;
	}

	// 3. 윗주 그리기
	// CalcConcurAlignDrawInfo에다 dx, dx 넣은거 실수 아님. 첨부터 값 잘못 넣은걸 가지고 그에 맞춰서 로직이 짜여있는 상태라서 저렇게 넣어줘야됨 ㅡㅡ 
	PoTwip alignGap = CalcConCurAlignDrawInfo(dx, dx, text_att, sizeInfo.concurCount, sizeInfo.totalConcurWidth, sizeInfo.destConcurWidth, nTotalCharSp);
	if (bAlign == JUSTIFY_010_CONCUR || bAlign == JUSTIFY_121_CONCUR) {
		if (nTotalCharSp && sizeInfo.concurCount)
			alignGap += nTotalCharSp / sizeInfo.concurCount;
	}

	if (text_att->getPositionForConCur() == TOP_POS_CONCUR)
		dy = -(sizeInfo.sourceConcurHeight + PTtoTWIP(text_att->getSpaceForConCur()));
	else
		dy = PTtoTWIP(text_att->getSpaceForConCur()) + sizeInfo.destConcurHeight;

	for (; nCol < nCharNum; nCol++) {
		CCharSet* pLink = pLine->getCharSet(nCol);
		BrWORD wCode = pLink->getCode();

		// get text attribute
		text_att = pTextAttHandler->getTextAtt(pLink->getAttrID());
		if (BrNULL == text_att) {
			BRTHREAD_ASSERT(BrFALSE);
			continue;
		}
		if (BrFALSE == text_att->isDestConCur())
			break;

		PoTwip characterWidth = CTextProc::getTextLinkWidth(document, text_att, wCode, pLink);
#ifdef APPLY_BACKGROUND_DEST_CONCUR
		DrawBackgroundGaroForConCur(dc, text_att,
		                            x + cCoord.doc2LogicalX(dx, BrFALSE),
		                            y + cCoord.doc2LogicalY(dy - sizeInfo.destConcurHeight, BrFALSE),
		                            x + cCoord.doc2LogicalY(dx + sizeInfo.characterWidth, BrFALSE),
		                            y + cCoord.doc2LogicalY(dy, BrFALSE));
#endif  // APPLY_BACKGROUND_DEST_CONCUR

		stDrawCharInfo.sx = sx + cCoord.doc2LogicalDX(dx, BrFALSE);
		stDrawCharInfo.sy = sy + cCoord.doc2LogicalDY(dy, BrFALSE);
		stDrawCharInfo.nCol = nCol;

		DrawGaroCharSet(cCoord, stDrawCharInfo, pLink, text_att, pLine, BrTRUE, text_att->isWordArtStyle(), getPainter());

		dx += characterWidth;
		if (bAlign == JUSTIFY_010_CONCUR || bAlign == JUSTIFY_121_CONCUR) {
			dx += alignGap;
		}
	}

#ifdef SUPPORT_SHOW_HWP_TYPESET
	// 4. hwp 조판부호 그리기
	if (document->isShowHWPTypeSetModeEx()) {
		const PoTextAtt* pSrcTextAtt = pLine->getSrcConCurrentTextAtt(--nCol);
		if (pSrcTextAtt) {
			stDrawCharInfo.sx = sx + cCoord.doc2LogicalDX(sizeInfo.totalConcurWidth, BrFALSE);
			stDrawCharInfo.sy = sy;
			DrawGaroCharSet(cCoord, stDrawCharInfo, pLine->getCharSet(nCol), pSrcTextAtt, pLine, BrTRUE, BrFALSE, getPainter(), BrTRUE);
		}
		nCol++;
	}
#endif  // SUPPORT_SHOW_HWP_TYPESET
	--nCol;

	return BrTRUE;
}

PoConcurSizeInfo CTextDraw::getConcurSizeInfo(BoraDoc* document, CLine* line, BrINT col, BrBYTE direction, BrBOOL isInsideMemo)
{
	if (!document || !line)
		return PoConcurSizeInfo();

	PoConcurSizeInfo info;
	PoTextAttHandler* textAttHandler = document->getTextAttHandler();

	BrWORD textID = textAttHandler->getNotSettedAttID();
	const PoTextAtt* textAtt;
	BrWORD hanFontSize;
	BrWORD engFontSize;

	const PoTextAtt* defaultAtt = textAttHandler->getDefaultAttr();
	BrWORD defaultHanFontSize = defaultAtt->getHanFSize();
	BrWORD defaultEngFontSize = defaultAtt->getEngFSize();

	BrBOOL isDest = BrFALSE;
	BrBOOL isFirstLoop = BrTRUE;
	BrINT  characterWidth; 
	BrINT  characterHeight;
	PoConcurPosition position = TOP_POS_CONCUR;

	BrINT  charNum = line->getCharNum();
	for( ; col < charNum; col++ ) {
		CCharSet* link = line->getCharSet(col);
		BrWORD wCode = link->getCode();

		if (textID != link->getAttrID()) {
			textID  = link->getAttrID();
			if (!isDest && isInsideMemo) {
				PoTextAtt sizeFixedAtt = *textAttHandler->getTextAtt(textID);
				sizeFixedAtt.setHanFSize(defaultHanFontSize);
				sizeFixedAtt.setEngFSize(defaultEngFontSize);
				textAtt = textAttHandler->insertAndGetTextAtt(sizeFixedAtt);
			} else {
				textAtt = textAttHandler->getTextAtt(textID);
			}

			hanFontSize = textAtt->getHanFSize();
			engFontSize = textAtt->getEngFSize();
		}

		if ( isFirstLoop ) { // 첫글자에서 Space, Position 등 가져옴
			info.concurSpace = BrMAX(PTtoTWIP(textAtt->getSpaceForConCur()), 0);
			position = (PoConcurPosition)textAtt->getPositionForConCur();
			isFirstLoop = BrFALSE;
		}

		if ( (isDest && !textAtt->isDestConCur()) ||
			(!isDest && !textAtt->isDestConCur() && !textAtt->isSrcConCur()) ||
			(info.concurCount > 0 && textAtt->isStartConCur()) ) {
			BR_ASSERT(FALSE); // 여기 들어왔다는건 라인의 윗주 글자들 속성 또는 순서가 깨졌다는 뜻
			break;
		}

		characterWidth = CTextProc::getTextLinkWidth(document, textAtt, wCode, link);
		characterHeight = (wCode>0xFF) ? hanFontSize : engFontSize;

		if ( direction == SERO )	// 세로 쓰기
			std::swap(characterWidth, characterHeight);

		// source concurrent
		if ( textAtt->isSrcConCur() ) {
			info.sourceConcurWidth += characterWidth;
			if ( characterHeight > info.sourceConcurHeight )
				info.sourceConcurHeight = characterHeight;
		} else {
			info.destConcurWidth += characterWidth;
			if ( characterHeight > info.destConcurHeight )
				info.destConcurHeight = characterHeight;
			isDest = BrTRUE;
		}
		info.concurCount++;

		if ( textAtt->isEndConCur() )
			break;
	}

	if ( info.concurCount > 1 ) { // 실패시 concurCount = 0 이 됨
		info.totalConcurWidth = ( info.sourceConcurWidth > info.destConcurWidth) ? info.sourceConcurWidth : info.destConcurWidth;

		if ( position == TOP_POS_CONCUR ) {
			info.totalConcurHeight = info.sourceConcurHeight + info.destConcurHeight + info.concurSpace;
		} else if (position == BOTTOM_POS_CONCUR) {
			info.totalConcurHeight = info.sourceConcurHeight;
		} else {
			// 오른쪽, 왼쪽에 붙는것(Odt스펙)은 미지원
		}
	}
	
	return info;
}


BrINT CTextDraw::CalcConCurAlignDrawInfo(BrINT& dx, BrINT& dy, const PoTextAtt* text_att,
                                         BrINT con_cur_cnt, BrINT con_cur_width,
                                         BrINT dest_width, BrINT total_char_sp)
{
	BrINT con_cur_align = text_att->getAlignForConCur();
	BrINT w = con_cur_width - dest_width;
	BrINT gap = 0;

	// 글자 정렬 기준
	// 정렬 수정 (ZPD-735)
	if (1 < con_cur_cnt &&
			ALIGN_BASE_CHAR == text_att->getAlignBaseConCur()
			/*&& text_att->getLangTypeConCur()==LT_KOREAN*/) {
		switch (con_cur_align) {
			case LEFT_CONCUR: {
				dx = 0;
				break;
			}
			case RIGHT_CONCUR: {
				gap = w;
				dx = gap + total_char_sp;
				break;
			}
			case CENTER_CONCUR: {
				gap = w;
				dx = (BrINT)(gap / 2) + (BrINT)(total_char_sp / 2);
				break;
			}
			case JUSTIFY_010_CONCUR: {
				gap = w / (con_cur_cnt - 1);
				dx = 0;
				break;
			}
			default: {
				gap = w / con_cur_cnt;
				dx = gap / 2;
				break;
			}
		}
		return gap;
	}

	// 단어 정렬 기준
	switch (con_cur_align) {
		case LEFT_CONCUR: {
			dy = 0;
			break;
		}
		case RIGHT_CONCUR: {
			dy = w + total_char_sp;
			break;
		}
		case CENTER_CONCUR: {
			dy = (BrINT)(w / 2) + (BrINT)(total_char_sp / 2);
			break;
		}
		case JUSTIFY_010_CONCUR: {
			if (1 < con_cur_cnt) {
				gap = w / (con_cur_cnt - 1);
				dy = 0;
			}
			else {
				gap = w;
				dy = gap / 2;
			}
			break;
		}
		case JUSTIFY_121_CONCUR: {
			gap = con_cur_cnt? (w / con_cur_cnt): w;
			dy = gap / 2;
			break;
		}
	}

	return gap;
}


#ifdef APPLY_BACKGROUND_DEST_CONCUR
// 병음에서의 밑줄체/중간줄체/바탕색 등을 처리...
void CTextDraw::DrawBackgroundGaroForConCur(BrDC* dc, const PoTextAtt* pTextAtt,
                                            BrINT sx, BrINT sy, BrINT ex, BrINT ey)
{
	if (!pTextAtt)
		return;

	// 역상
	if (pTextAtt->getReverse()) {
		BrBmvBrush brush, * pOldBrush;
#ifdef USE_THEME_COLOR
		brush.createSolidBrush(pTextAtt->getTextColor().getColor());
#else
		brush.createSolidBrush(pTextAtt->getTextColor());
#endif
		pOldBrush = dc->setBrush(&brush);
		dc->fillRect(sx, sy, ex + 1, ey + 1);
		dc->setBrush(pOldBrush);
		// FillRectangle(dc, sx, sy, ex+1, ey+1, SOLID, text_att->getTextColor());
	}
	// 바탕색
	else if (pTextAtt->getBackFlag()) {
		BrBmvBrush brush, * pOldBrush;
#ifdef USE_THEME_COLOR
		brush.createSolidBrush(pTextAtt->getBackColor().getColor());
#else
		brush.createSolidBrush(pTextAtt->getBackColor());
#endif

		pOldBrush = dc->setBrush(&brush);
		dc->fillRect(sx, sy, ex + 1, ey + 1);
		dc->setBrush(pOldBrush);
		// FillRectangle(dc, sx, sy, ex+1, ey+1, SOLID, text_att->getBackColor());
	}

#ifdef USE_THEME_COLOR
	if (pTextAtt->getUnderline()) {
		CCUtil::drawLine(dc, sx, ey, ex, ey, 1,
		                 pTextAtt->getReverse()? pTextAtt->getBackColor().getColor():
		                                         pTextAtt->getTextColor().getColor());
		// DrawLine(dc, sx, ey, ex, ey, 1, (text_att->getReverse())?text_att->getBackColor():text_att->getTextColor());
	}

	if (pTextAtt->getStrikeout()) {
		CCUtil::drawLine(dc, sx, sy + (ey - sy) / 2, ex, sy + (ey - sy) / 2, 1,
		                 pTextAtt->getReverse()? pTextAtt->getBackColor().getColor():
		                                         pTextAtt->getTextColor().getColor());
		// DrawLine(dc, sx, sy+(ey-sy)/2, ex, sy+(ey-sy)/2, 1, (text_att->getReverse())?text_att->getBackColor():text_att->getTextColor());
	}
#else  // USE_THEME_COLOR
	if (pTextAtt->getUnderline()) {
		CCUtil::drawLine(dc, sx, ey, ex, ey, 1,
		                 pTextAtt->getReverse()? pTextAtt->getBackColor(): pTextAtt->getTextColor());
		// DrawLine(dc, sx, ey, ex, ey, 1, (text_att->getReverse())?text_att->getBackColor():text_att->getTextColor());
	}

	if (pTextAtt->getStrikeout()) {
		CCUtil::drawLine(dc, sx, sy + (ey - sy) / 2, ex, sy + (ey - sy) / 2, 1,
		                 pTextAtt->getReverse()? pTextAtt->getBackColor(): pTextAtt->getTextColor());
		// DrawLine(dc, sx, sy+(ey-sy)/2, ex, sy+(ey-sy)/2, 1, (text_att->getReverse())?text_att->getBackColor():text_att->getTextColor());
	}
#endif  // USE_THEME_COLOR
}
#endif  // APPLY_BACKGROUND_DEST_CONCUR


BrINT CTextDraw::CountEngWordChar(CCharSetArray* pLinkArray, BrINT nSCol, BrINT nECol,
                                  CWordArray* pDispCodeArray)
{
	BrINT nCount = 0;

	if (!pLinkArray) {
		BRTHREAD_ASSERT(0); //그냥 넘기지 말고 linkArray 확인 후 수정바람.
		return 0;
	}

	CCharSet* pLink = pLinkArray->getCharSet(nSCol);
	if (pLink) {
		BrWORD nAttID = pLink->getAttrID();
		const PoTextAtt* pTextAtt = theBWordDoc->getTextAttHandler()->getTextAtt(nAttID);
		if (pTextAtt && (pTextAtt->getBiDi() || pTextAtt->getSmallCaps()))
			return 0;

		// BrBOOL bBold = pTextAtt->getBold();
		// BrBOOL bEngFlag = BrTRUE;

		// [ZPD-11856][2015-06-02][sangdon]:한글, 영문 폰트가 다르면 Ascii일때 아닐때를 구분해야함.
		//  Ascii는 영문 폰트 사용. 그 외는 한글 폰트 사용.
		BrWORD wCode = pLink->getCode();
		BrBOOL bAsciiCode = CCUtil::isAsciiChar(wCode);

		for (BrINT nCol = nSCol; nCol < nECol; nCol++) {
			pLink = pLinkArray->getCharSet(nCol);
			//AOM-14302 이슈 예외처리
			if (!pLink)
				return nCount;

			wCode = pLink->getCode();

#ifdef BIDI_SUPPORT
			if (pDispCodeArray) {
				BrWORD wTmp = pDispCodeArray->at(nCol);
				if (wTmp != wCode)
					wCode = wTmp;
			}
#endif  // BIDI_SUPPORT

			if ((nCount < (MAX_DRAWCHAR_BUF_LEN - 2)) &&
			    (pLink->isTextLink()) &&
			    (pLink->getAttrID() == nAttID)
// #ifndef DRAW_KOR_STRING
			    // && (wCode > 0x20 && wCode < 0x80)
			    && ((0x20 < wCode && wCode < 0x80) || IS_MODERN_KOREAN(wCode))
// #endif  // DRAW_KOR_STRING
			    && (bAsciiCode == CCUtil::isAsciiChar(wCode))
			) {
// #ifndef DRAW_KOR_STRING
				// if ( nCount==0 )  bEngFlag = ( wCode < 0xFF ) ? BrTRUE : BrFALSE;
				// else {
				//    if ( (wCode < 0xFF && !bEngFlag) || (wCode > 0xFF && bEngFlag) )
				//      break;
				// }
// #endif  // DRAW_KOR_STRING
				nCount++;
			}
			else {
				break;
			}
		}
	}

	return nCount;
}


void CTextDraw::DrawStringOfCharWord(
        BrDC* dc, CDrawUnit& du, BrINT sx, BrINT sy, BrINT nLineHgt, BrINT nDescent,
        const PoTextAtt* pTextAtt, BrINT nFlag, CCharSetArray* pLinkArray, BrINT nCol, BrINT nCount,
        CLongArray& cPosArray, CLine* pLine, BrBOOL bEffect/*=BrTRUE*/, Painter* painter/*=BrNULL*/)
{
	// qDebug("draw string");
	if (pTextAtt == BrNULL || pLinkArray == BrNULL || !nCount)
		return;

	CCharSet* pLink = pLinkArray->getCharSet(nCol);
	PoDcTextAtt* curDcTextAtt = theBWordDoc->getTextAttHandler()->getCurDrawingDcTextAtt();
	PoDcTextAtt* prevDcTextAtt = theBWordDoc->getTextAttHandler()->getPreDrawgDcTextAtt();
	// overframe되는 라인의 글자를 뿌리지 말자.
	CFrame* pFrame = pLine->getFrame();
	if (!theBWordDoc->isFromPpt() && pLine->getAnchorFlag() && (pLine->getBasePos() - pTextAtt->getHanFSize()) > pFrame->height())	// LQQ-5010
		return;

	if (DrawCharMakeParam(du, pLink, pTextAtt, pLine, nCol, painter) == BrFALSE)
		return;

	BrINT nFSize = curDcTextAtt->getHanFSize();

	// if ( !IsClipRegion(sx, sy-nFSize, nFSize, nFSize*nCount) )
	//[dwchun : 2012.09.07] : PDF Export일 때는 Clip 영역을 체크하지 않고 모든 글자를 출력해야 함
	if (!dc->isExportMode()) {

		if (pTextAtt->getEmphasis()) {
			if (!IsClipRegion(sx, sy - nLineHgt - nLineHgt / 2, nLineHgt + nLineHgt / 2, nFSize * nCount))
				return;
		}
		else if (pTextAtt->getTextVerticalPos() < 0) {
			if (!IsClipRegion(sx, sy - nLineHgt, nLineHgt * 2, nFSize * nCount))
				return;
		}
		else if (pTextAtt->isWordArtStyle()) {
			;
		}
		else {
			//[2016.01.21][zpd-24193][zpd-24485] 스크롤 시 글자가 잘려서 렌더링 되는 현상: g,j 같이 decsent가 있는 글자들의 경우에 대한 처리
			if (!IsClipRegion(sx, sy - nLineHgt, nLineHgt + nDescent, nFSize * nCount))
				return;
		}
	}

	BRCONTEXT;
	//if ( !theBWordDoc->isViewPrintMode() && !dc->isExportMode() && theBWordDoc->getDocType()==BORA_DOCTYPE_ASCI && Brcontext.m_GeneralValue.dwTextColorForTXT != BLACK_COLOR )	{
	if (Brcontext.m_GeneralValue.dwTextColorForTXT != BLACK_COLOR)
		curDcTextAtt->setTextColor(Brcontext.m_GeneralValue.dwTextColorForTXT);
	if (Brcontext.m_GeneralValue.dwBgColorForTXT != WHITE_COLOR)
		curDcTextAtt->setBackColor(Brcontext.m_GeneralValue.dwBgColorForTXT);
	//}

	BrBOOL bChanged = BrFALSE;
	BrINT i;
	BrINT nNoDrawCnt = 0;
	BrWORD bCode;
	BString qStrBuffer;
	for (i = 0; i < nCount; i++) {
		pLink = pLinkArray->getCharSet(nCol + i);
		// DRAW_KOR_STRING
		/*BrWORD*/ bCode = pLink->getCode();
		// #else  // DRAW_KOR_STRING
		// 		BYTE bCode = (BYTE)pLink->getCode();
		// #endif  // DRAW_KOR_STRING

				//hnsong:2012-10-04 5.0에서 대문자로'' 기능지원
		if (pTextAtt->getCaps() || pTextAtt->getSmallCaps()) {
			if (ALP_MIN2 <= bCode && bCode <= ALP_MAX2)
				bCode -= 0x20;
			else if (CUtil::isLatinSmallLetter(bCode))
				bCode--;
		}

		unsigned short m_qBuffer[MAX_DRAWCHAR_BUF_LEN] = {0,};
		curDcTextAtt->getTextString()->getString(m_qBuffer, curDcTextAtt->getTextString()->length());
		if (pLink->isRevisionLink()) {
			RevisionEngine* revision_engine = theBWordDoc->getRevisionEngine();

			switch (revision_engine->getReviewMode()) {
				case ReviewMode::SIMPLE_MARKUP:
				case ReviewMode::NO_MARKUP:
					if (revision_engine->isDeletedRun(pLink)) {
						nNoDrawCnt++;
					}
					else
						qStrBuffer.append(BChar(bCode));
					break;
				case ReviewMode::SOURCE:
					if (revision_engine->isInsertedRun(pLink))
						nNoDrawCnt++;
					else
						qStrBuffer.append(BChar(bCode));
					break;
				default:
					if (revision_engine->getInsDelsShowState() == BrFALSE
							&& revision_engine->isDeletedRun(pLink))
						nNoDrawCnt++;
					else
						qStrBuffer.append(BChar(bCode));
					break;
			}
		}
		else {
#ifdef SUPPORT_HIDDEN_TEXT
			if (PO_TEXTATT_ENGINE::PoTextAttEngine::canShowText(*pTextAtt))
				qStrBuffer.append(BChar(bCode));
			else
				nNoDrawCnt++;
#else
			qStrBuffer.append(BChar(bCode));
#endif  // SUPPORT_HIDDEN_TEXT
		}

		if (nCount - nNoDrawCnt == 0)
			return;
	}
	BFont* pAppStaticFont = g_pAppStatic->m_pFont;
	if (DrawCharChangedFont(*prevDcTextAtt, *curDcTextAtt)) {
		// 2007.12.21 hyohyun 영문 string일때 italic이 Setting이 안되는 경우 때문에 수정
		BrBOOL brItalic = curDcTextAtt->getItalic();
		BrBOOL brSuperSub = curDcTextAtt->getSuperscript() || curDcTextAtt->getSubscript();
		BrBOOL brBold = curDcTextAtt->getBold();
		BrCOLORREF textColor = curDcTextAtt->getTextColor().getColor();
		BrINT fontSizeForDraw = brSuperSub? (nFSize * PO_TEXTATT_BASE::superSubScriptSizeRatio): nFSize;

#ifndef BWP_EDITOR
		pAppStaticFont->setFontAttribute(fontSizeForDraw, brBold, brItalic, textColor);
#else
		pAppStaticFont->setFontAttribute(fontSizeForDraw, brBold, brItalic, textColor);
		pAppStaticFont->setFontSize(fontSizeForDraw, DEFAULT_TEXT_HORIZ_SCALE);
		pAppStaticFont->setFontName((BrUSHORT*)theBWordDoc->getFontArray()->GetAt(curDcTextAtt->getHanFontID())->lf.lfFaceName, MAX_FONT_LEN);
		pAppStaticFont->setFontWidthRatio(pTextAtt->getHanExpCom());
		pAppStaticFont->setFontEmboss(pTextAtt->getEmboss());
		pAppStaticFont->setFontEngrave(pTextAtt->getEngrave());
		pAppStaticFont->setFontOutline(pTextAtt->getOutline());
		pAppStaticFont->setCharEqualHeight(pTextAtt->isNormalizeH());
		pAppStaticFont->setFontRotate(0);
		//[2012.05.09] rabetgu font attr이 바뀌었을경우 shadow도 초기화 되도록 수정
		if (pTextAtt->getShadow() && !pTextAtt->isWaEffected())
			pAppStaticFont->setFontShadow(RGB_DKGRAY);
		else {
			pAppStaticFont->setFontShadow(-1);
			//[2013.06.03][강신유][TID:15441] TextBox의 Text의 shadow의 경우 100%, fill없음 인 경우만 생김.
			//해당 부분 Rendering 파트에서 6.0 개발 계획에 포함되어 주석처리
			/*if (pLine)
			{
				DrawTextShadowForBorder(pLine->getFrame());
			}*/
		}
#endif
		bChanged = BrTRUE;
	}

	if (pLine) {
		if (theBWordDoc->GetGrayMode() != GRAY_MODE_COLOR) {
			if (pFrame) {
				curDcTextAtt->setTextColor(BrColor::getBwColor(theBWordDoc->GetGrayMode(), pFrame->getFrameColorMode(), curDcTextAtt->getTextColor().getColor(), GRAY_MODE_APPLY_TEXT));
			}
		}
	}

	if (bChanged || DrawCharChangedColor(*prevDcTextAtt, *curDcTextAtt) || g_pAppStatic->m_pFont->getTextColor() != curDcTextAtt->getTextColor().getColor()) {
		BrCOLORREF textColor = AutoTextColor(pLine, curDcTextAtt);
#ifndef BWP_EDITOR
		g_pAppStatic->m_pFont->setFontAttribute((wStyle & SUPERSUB_MASK)?(nFSize * PO_TEXTATT_BASE::superSubScriptSizeRatio):nFSize, (wStyle & TEXTATT_MASK_BOLD), (wStyle & TEXTATT_MASK_ITALIC), g_BwpnewDrawCharInfo.m_TextColor);
#else
		g_pAppStatic->m_pFont->setFontColor(GetBrRValue(textColor), GetBrGValue(textColor), GetBrBValue(textColor));
#endif
		bChanged = BrTRUE;
	}
	if (bChanged)
		dc->setFont(pAppStaticFont);

#ifdef USE_PDFEXPORT_TEXTBOX
	if (dc->getDCType() == ePDFExtDCType && pFrame->isShape() && theBWordDoc->isExportPDFAnnot(pFrame->getID()))
	{
		return;
	}
#endif
	
	//[dwchun : 2012.04.05] : drawGaroCharSet()에서 계산한 sy와 방식이 달라 통일 시켜 줌. ( Baseline 문제 )
	//sy -= nFSize;		// 2006.2.20
	// sy -= g_pAppStatic->m_pFont->getCharHeight()-g_pAppStatic->m_pFont->getCharDescent();
	//BrINT nCharDes = (dc->isExportMode())? 0: g_pAppStatic->m_pFont->getCharDescent();
	BrINT nFontHgt = g_pAppStatic->m_pFont->getCharHeight();
	BrINT nCharDes = g_pAppStatic->m_pFont->getCharDescent();
	if (curDcTextAtt->getSuperscript()) {
		// 현 line에 모든 글자가 superscript인 경우 제외 NPC-7149
		if (!(pLine && (nFontHgt + 1) >= du.doc2LogicalDY(pLine->getAscent(), BrFALSE)))
			sy -= (BrINT)((nFontHgt - nCharDes) * 1.7);	// nFSize;
		else
			sy -= (BrINT)((nFontHgt - nCharDes) * 1.6);
	}
	else
		sy -= nFontHgt - nCharDes;

	// subscript인 경우는 Descent를 빼주지 않는다. (2012.05.31)
	if (!(curDcTextAtt->getSubscript()))
		sy -= nDescent;
	else
		sy -= nCharDes / 2;


	//[2013-11-08][T-18055][20hoon]
	if (pLine != BrNULL) {
		if (pTextAtt->getTextVerticalPos() > 0)
			sy -= /*rDrawCharInfo.nDescent+*/du.doc2LogicalY(pTextAtt->getTextVerticalPos(), BrFALSE);
		//else if (pTextAtt->getTextVerticalPos() == 0)
			//sy -= /*rDrawCharInfo.nDescent;*/du.doc2LogicalY(pLine->getDescent(), BrFALSE);
		else if (pTextAtt->getTextVerticalPos() < 0)
			sy = sy /*- rDrawCharInfo.nDescent*/ + du.doc2LogicalY(BrABS(pTextAtt->getTextVerticalPos()), BrFALSE);
	}

	// if(wStyle & SUB_BIT)    sy += (nFSize>>1)+1;
		// sy -= nDescent;
		// if(wStyle & SUPER_BIT)  sy -= (nFSize>>1);

	if (pTextAtt->getVOffset() != 0) {
		sy -= du.doc2LogicalDY(pTextAtt->getVOffset(), BrFALSE);
	}
	// HWP 글자위치
	else if (theBWordDoc->isFromHwp() && pTextAtt->getCharPosition() != 0) {
		sy += du.doc2LogicalDY(pTextAtt->getHanFSize() * pTextAtt->getCharPosition() / 100, BrFALSE);
	}

	//jyoh  	QFontMetrics   fm = dc->fontMetrics ();
	//jyoh  	sy -= fm.descent();


	BrWORD* pGapArray = (BrWORD*)BrMalloc(BrSizeOf(BrWORD) * nCount);
	if (!pGapArray)
		return;

	const BrBOOL bExportPDF = dc->getDCType() == ePDFExtDCType;
	LPBrCharGap pCharInterval = BrNULL;
	if (bExportPDF) {
		pCharInterval = (LPBrCharGap)BrMalloc(BrSizeOf(BrCharGap) * nCount);
		if (!pCharInterval) {
			BR_SAFE_FREE(pGapArray);
			return;
		}
	}

	CTextProc::getTextWidthOfCharWord(du, nCol, nCount, cPosArray, pGapArray);

	BString qTmpStrBuffer;

	CBCell* pCell = BrNULL;
	if (pFrame && pFrame->isCell())
		pCell = pFrame->getCell();


	BrINT nTotalWidth = 0;
	BrINT nTmpSx = sx;
	BrBOOL bDrawString = BrTRUE;
	BrBOOL bDrawCharBitmapFirst = BrTRUE;
	BrBOOL bDrawCharBitmapBuf[MAX_DRAWCHAR_BUF_LEN] = {BrFALSE,};

	BrFLOAT nFontSize = 0.0;

	BrINT nAngle, nHRatio;
	dc->m_pFont->getFontAtts(&nFontSize, &nHRatio, &nAngle);

	// HEJ-1426 pdf export 중 gaparray의 값이 BrINT로 소숫점 이하를 고려하지 못하여 수정
	// dc->m_pFont->getCharWidth 값이 여전히 BrINT로 소숫점 이하를 고려하지 못하므로 오차가 남아있음
	BrFLOAT nGap = 0;
	BrFLOAT nStartPos = (BrFLOAT)cPosArray[nCol] * (du.getZoomFactor() * du.getXResolution()) / (DOCRESOLUTION * ZOOM_10000);
	BrFLOAT nSumWidth = 0, nCurWidth = 0;

	BrBOOL bNoUseCharBitmap = CheckWordArtDrawText(pLine, pFrame, pTextAtt, dc->m_pFont->getCharDescent(),
	                                               painter->getZoomScale(), painter->m_iResX);

	// BTrace("%s(%d) %s qStrBuffer.utf8()[%s]", __FILE__, __LINE__, __FUNCTION__, qStrBuffer.utf8());	

	for (i = 0; i < nCount; i++) {
		nTotalWidth += pGapArray[i]; // String의 총 길이
		qTmpStrBuffer = qStrBuffer[i];

		if (bEffect && !bNoUseCharBitmap &&
				DrawCharBitmap(painter, dc, pLink, pTextAtt, pLine, nCol + i, qTmpStrBuffer, nTmpSx, sy)) {
			bDrawString = BrFALSE; //텍스트에 효과 있을 경우 원래 방식대로 drawing
			bDrawCharBitmapBuf[i] = BrTRUE;
		}
		else if (bExportPDF) {  //효과 없으면서 pdf 내보내기인 경우
			BChar* pTempChar = (BChar*)qTmpStrBuffer.unicode();
			//[18.11.02][sglee1206] 자간 조정을 위해 자료형 변경
			BrDOUBLE nTempCharWidth = dc->m_pFont->getCharWidthF(pTempChar->unicode());
			//nGap = (pGapArray[i] - nTempCharWidth);
			BrDOUBLE dTotalWidth = ((BrDOUBLE)cPosArray[i + nCol + 1]) * (du.getZoomFactor() * du.getXResolution()) / (DOCRESOLUTION * ZOOM_10000) - nStartPos;
			nTotalWidth = dTotalWidth;
			nCurWidth = dTotalWidth - nSumWidth;
			nSumWidth += nCurWidth;
			nGap = nCurWidth - nTempCharWidth;

			// ref 문서 5.3.3 Text Space Details 참고할 것
			pCharInterval[i] = (BrINT)BrFRound((nGap * 1000) / nFontSize);
		}

		nTmpSx += pGapArray[i];
	}

	bDrawString = bDrawString && bDrawCharBitmapFirst;

	if (bDrawString && (IsClipRegion(sx, sy, nFSize + nDescent, nTotalWidth, pCell) || dc->isExportMode() || pTextAtt->isWordArtStyle())) {
		if (!bExportPDF)
			dc->drawChars(&qStrBuffer, sx, sy, pGapArray);
		else
			dc->drawChars(&qStrBuffer, sx, sy, BrNULL, BrFALSE, pCharInterval);

		for (i = 0; i < nCount; i++) {
			if (pTextAtt->getEmphasis()) {
				if (!DrawEmphasisBitmap(painter, dc, pFrame, pLine, nCol + i, pTextAtt, sx, sy, pAppStaticFont->getCharHeight(), pAppStaticFont->getCharWidth(qStrBuffer.at(i).unicode()), pAppStaticFont->getTextColor()))
					DrawEmphasis(dc, pTextAtt, sx, sy, pAppStaticFont->getCharHeight(), pAppStaticFont->getCharWidth(qStrBuffer.at(i).unicode()), pAppStaticFont->getTextColor());
			}
			sx += pGapArray[i];
		}
	}
	else {
		for (i = 0; i < nCount; i++) {
			if (IsClipRegion(sx, sy, nFSize + nDescent, 0, pCell) || dc->isExportMode() || pTextAtt->isWordArtStyle())	//[SRG-824]텍스트 그림자 효과가 그림자와의 거리가 멀 경우 IsClipRegion에 포함이 안되서 isWordArtStyle 추가함.
			{
				qTmpStrBuffer = qStrBuffer[i];

				//20hoon
				pLink = pLinkArray->getCharSet(nCol + i);
				if (!bEffect || bDrawCharBitmapFirst? (bDrawCharBitmapBuf[i] == BrFALSE): (DrawCharBitmap(painter, dc, pLink, pTextAtt, pLine, nCol + i, qTmpStrBuffer, sx, sy) == BrFALSE)) {
					dc->drawChars(&qTmpStrBuffer, sx, sy);
				}
			}
			// display emphasis
			if (pTextAtt->getEmphasis()) {
				if (!DrawEmphasisBitmap(painter, dc, pFrame, pLine, nCol + i, pTextAtt, sx, sy, pAppStaticFont->getCharHeight(), pAppStaticFont->getCharWidth(qStrBuffer.at(i).unicode()), pAppStaticFont->getTextColor()))
					DrawEmphasis(dc, pTextAtt, sx, sy, pAppStaticFont->getCharHeight(), pAppStaticFont->getCharWidth(qStrBuffer.at(i).unicode()), pAppStaticFont->getTextColor());
			}

			sx += pGapArray[i];
		}
	}

	BR_SAFE_FREE(pGapArray);
	BR_SAFE_FREE(pCharInterval);

//	dc->ExtTextOut(sx, sy, 0, BrNULL, (BrLPCTSTR)lpBuffer, nCount, pGapArray);

	if (bChanged)
		*prevDcTextAtt = *curDcTextAtt;
}


BrBOOL CTextDraw::DrawCharChangedFont(const PoDcTextAtt& dcPOld, const PoDcTextAtt& dcPNew)
{
	return dcPOld != dcPNew;  // ;;
}


//hnsong:2013-03-18
//hnsong:2012-09-06 그림자색을 연한 색으로 바꿈. [T-9044]
void CTextDraw::DrawTextShadowForBorder(CFrame* a_pFrame)
{//도형의 그림자 속성이 있는 경우에 텍스트에도 그림자 속성 적용

	if (a_pFrame->isCell()) // cell일때는 border그림자가 있어도 display하지 않음!
		return;

	BrShape* pBorder = a_pFrame->getBorder();
	if (pBorder && pBorder->isShadow())
		g_pAppStatic->m_pFont->setFontShadow(pBorder->getShadow()->getForeColor());
}


//[2012.09.17][TID:7609][김회영]Section CR(Paragraph Mark/Page/Column/Section) Code 고도화 - Drawing
//CR Code Drawing을 기존의 Paragraph Mark뿐만 아니라 Page/Column/Section으로 확장한다.
//MS와 같은 방식으로 표시하도록 한다.
void CTextDraw::DrawBreakCode(BrDC* dc, CDrawUnit& du, const PoTextAtt* pTextAtt, BrINT nBreakCode,
                              BrINT sx, BrINT sy, BrINT ex, BrINT ey, BrBOOL bSero)
{
	if (theBWordDoc->getEditProtect())
		return;

	CCmdEngine* pCmdEngine = theBWordDoc->getCmdEngine();
	//[2014.01.02][M48343] 브레이크 코드 show/hide 기능 추가
	BrEditSymbolShowStateSetting pShowState = pCmdEngine->getEditSymbolShowState();

	if (BrFALSE == pCmdEngine->IsShowEditSymbol() && BrFALSE == pShowState.bSpace)
		return;
	if (g_BoraThreadAtom.m_nPrintStatus == PRINT_STATUS_START || g_BoraThreadAtom.m_nPrintStatus == PRINT_STATUS_PROGRESS)	//ZPD-4940
		return;

	BrUSHORT text[100] = {0};

	BString strBreak;
	BrCOLORREF rColorRef = BrRGB(0, 0, 0);
	switch (nBreakCode) {
		case PAGE_BREAK:
			BrGetResString(BR_RESSTR_PAGEBREAK, text, 100);
			strBreak = text;
			rColorRef = BrRGB(255, 0, 0);
			break;
		case COL_BREAK:
			BrGetResString(BR_RESSTR_COLUMNBREAK, text, 100);
			strBreak = text;
			rColorRef = BrRGB(0, 255, 0);
			break;
		case SECTION_BREAK_NEXT_PAGE:
			BrGetResString(BR_RESSTR_SECTIONBREAK_NEXTPAGE, text, 100);
			strBreak = text;
			rColorRef = BrRGB(0, 0, 255);
			break;
		case SECTION_BREAK_CONTINUOUS:
			BrGetResString(BR_RESSTR_SECTIONBREAK_CONTINUOUS, text, 100);
			strBreak = text;
			rColorRef = BrRGB(0, 0, 255);
			break;
		case SECTION_BREAK_EVEN_PAGE:
			BrGetResString(BR_RESSTR_SECTIONBREAK_EVENPAGE, text, 100);
			strBreak = text;
			rColorRef = BrRGB(0, 0, 255);
			break;
		case SECTION_BREAK_ODD_PAGE:
			BrGetResString(BR_RESSTR_SECTIONBREAK_ODDPAGE, text, 100);
			strBreak = text;
			rColorRef = BrRGB(0, 0, 255);
			break;
		case SECTION_BREAK_NEXT_COLUMN:
			BrGetResString(BR_RESSTR_END_OF_SECTION, text, 100);
			strBreak = text;//toUnicode(text, BrStrLen(text));
			rColorRef = BrRGB(0, 0, 255);
			break;
#ifdef SUPPORT_HWP_PAGE_BREAK
		case PAGE_BREAK_HWP:
			strBreak = "PAGE BREAK HWP";
			rColorRef = BrRGB(0, 0, 255);
			break;
#endif
		case PAGESTYLE_BREAK:
			BrGetResString(BR_RESSTR_PAGESTYLE_BREAK, text, 100);
			strBreak = text;//toUnicode(text, BrStrLen(text));
			rColorRef = BrRGB(0, 0, 255);
			break;

		default:
			break;
	}

	rColorRef = BrRGB(128, 128, 128);

	//1) Change DC Object.
	BrBmvPen pen(eDash, 1, rColorRef), * pOldPen = BrNULL;
	BrBmvBrush brush(BrRGB(255, 0, 0)), * pOldBrush = BrNULL;
	BFont font, * pOldFont = BrNULL;

	BrINT nFontSize = 10;
	font.setFontInfo(nFontSize, BrFALSE, BrFALSE, BrFALSE, BrFALSE);
	if (bSero)
		font.setFontInfo(nFontSize, BrFALSE, BrFALSE, BrFALSE, BrFALSE, -1, 90);
	font.setFontColor(rColorRef);
	//fontarray에서 0번째 가지고 있는 font name 셋팅
	BrLPWORD pFaceName = theBWordDoc->getFontArray()->GetAt(0)->getFaceName();
	font.setFontName(pFaceName, CUtil::WcsLen(pFaceName));

	pOldPen = dc->setPen(&pen);
	pOldBrush = dc->setBrush(&brush);
	pOldFont = dc->setFont(&font);

	//2) Draw breaking line & characters
	BrINT nWidthOfBreakChars = font.getBStringWidth(&strBreak);
	BrINT nHeightOfBreakChars = font.getCharHeight();

	BrINT nTmp = ex - sx;
	if (bSero)
		nTmp = ey - sy;

	if (nTmp < nWidthOfBreakChars) {
		dc->drawLine(sx, sy, ex, ey);
	}
	else if (bSero) {
		BrINT nPosSx = sx;// - nHeightOfBreakChars/2;
		BrINT nPosCenter = (sy + ey) / 2;

		dc->drawLine(nPosSx, sy, nPosSx, nPosCenter - nWidthOfBreakChars / 2);
		dc->drawLine(nPosSx, nPosCenter + nWidthOfBreakChars / 2, nPosSx, ey);
		dc->drawChars(&strBreak, sx - nFontSize / 2, nPosCenter - nWidthOfBreakChars / 2, BrNULL);
	}
	else {
		dc->drawLine(sx, sy + nHeightOfBreakChars / 2, (sx + ex) / 2 - nWidthOfBreakChars / 2, ey + nHeightOfBreakChars / 2);
		dc->drawLine((sx + ex) / 2 + nWidthOfBreakChars / 2, sy + nHeightOfBreakChars / 2, ex, ey + nHeightOfBreakChars / 2);
		dc->drawChars(&strBreak, (sx + ex) / 2 - nWidthOfBreakChars / 2, sy - nFontSize / 2, BrNULL);
	}

	//3) Restore DC Object.
	dc->setPen(pOldPen);
	dc->setBrush(pOldBrush);
	dc->setFont(pOldFont);
}


void CTextDraw::DrawImageBullet(BoraDoc* document, BrDC* dc, CDrawUnit& du, const CFrame* pLineFrame,
                                CCharSet* pLink, const BRDRAWCHARINFO& stDrawCharInfo)
{
	// shape 에서 raw id를 이용하여 bitmap을 가져온다.
	// raw id 가 없을 경우, bitmap을 생성하여 imageArray에 달아줌.
	// image load하여 draw하는 데까지 시간이 걸리는 것으로 보임(zoom in/out 시에 버벅임)
	// imagearray의 bitmap은 dib까지 만들어서 넣어두고 해당 bitmap을 가져와 바로 DC에서 draw 할수 있도록 함

	BrBOOL bDimColor = pLineFrame->isDimColorDraw();

	CFrame* frame = document->getBulletImageFrame(pLink->getCode());
	BrShape* shape = frame? frame->getBorder(): BrNULL;
	if (BrNULL == shape)
		return;

	CImageArray* image_arr = (CImageArray*)document->getImageArray();
	if (BrNULL == image_arr)
		return;

	shape->setImageInfo(image_arr, BrFALSE);
	BrINT raw_id = shape->getImageAttr()->GetRawID();

	//image가 없는 경우 한컴도 그리지 않음
	if (BrNULL == shape->getImage())
		return;

	unique_ptr<PrBitmap> bitmap_raii;
	PrBitmap* bitmap = BrNULL;
	if (0 < raw_id) {
		brCImageAttr* image_attr = image_arr->Get(raw_id);
		if (image_attr)
			bitmap = image_attr->GetDIB();
	}
	else {
		bitmap_raii.reset(BrNEW PrBitmap);
		bitmap = bitmap_raii.get();
	}
	if (BrNULL == bitmap)
		return;

	BrINT image_type = 0; // imageArray에 bitmap을 달아줄때, imageType 필요
	//imageArray에 bitmap이 있다고 해도 dib가 없는 경우가 있으므로, 확인하고 dib를 달아준다.

	if (BrFALSE == bitmap->isHasBitmap()) {
		PrBitmap* pImage = shape->getImage();
		BrINT len = 0;
		BrLPVOID data = pImage->getRawBitmapData(&len, pImage->getRawBitmapLoader() != BrNULL);
		if (BrNULL == data || len < 0)
			return;

		IMG_INFO img_info = { eImage_NONE, };
		PrBitmap::getImageInfoPtr(data, len, &img_info);
		image_type = img_info.type;

		BSize load_size = CTextProc::makeImageBulletSize(pLink, img_info.width, img_info.height, pLineFrame);
		load_size.setWidth(du.doc2LogicalDX(load_size.Width(), BrFALSE));
		load_size.setHeight(du.doc2LogicalDY(load_size.Height(), BrFALSE));

		bitmap->setRawBitmapData(data, len, NONE_COLOR_BITS, BrFALSE, BrTRUE);
		PrBitmapFlag flag;
		bitmap->loadImagePtr(data, len, load_size.Width(), load_size.Height(), 100, flag, BrNULL);
	}

	// 실제 bitmap size를 계산하기 위해(logical size)
	BSize draw_size = CTextProc::makeImageBulletSize(pLink, bitmap->cx(), bitmap->cy(), pLineFrame);
	draw_size.setWidth(du.doc2LogicalDX(draw_size.Width(), BrFALSE));
	draw_size.setHeight(du.doc2LogicalDY(draw_size.Height(), BrFALSE));

	if (BrFALSE == bitmap->isHasBitmap())
		return;

	// DimColor 셋팅(Header/Footer 쓰기모드 등일 때 투명도 적용)
	BrBYTE old_alpha_value = dc->setAlphaValue(bDimColor? 0x7F: 0xFF);
	BrBOOL bGaro = pLineFrame->isGaro() || (pLineFrame->isCell() && document->isViewOutlineMode());
	//bitmap 그리는 부분
	dc->stretchBlt(stDrawCharInfo.sx,
	               bGaro? (stDrawCharInfo.sy - draw_size.Height()):
	                      stDrawCharInfo.sy, draw_size.Width(), draw_size.Height(),
	               bitmap, 0, 0, bitmap->cx(), bitmap->cy(), SRCCOPY);
	dc->setAlphaValue(old_alpha_value);

	if (0 == raw_id) {
		bitmap_raii.release();  // it's equivalent to bitmap
		// raw id가 없는 경우, imagearray에 bitmap을 달아주고 shape에 id 셋팅
		BrBOOL bAddedImage = BrFALSE;
		raw_id = image_arr->AddImageObject(bitmap, image_type, bAddedImage, BrTRUE);
		if (!bAddedImage)
			BR_SAFE_DELETE(bitmap);
		shape->getImageAttr()->SetRawID(raw_id);
	}
}


void CTextDraw::DrawSeroOneLine(Painter* painter, BrDC* dc, CDrawUnit& du, CFrame* pFrame,
                                CLine* pLine, BrINT sx, BrINT sy, BrINT nWidth, BrINT nBandCount,
                                BrINT nSCol, BrINT nECol, BrBOOL bEffect)
{
	BoraDoc* document = theBWordDoc;
	if (document == BrNULL || pFrame == BrNULL || pLine == BrNULL)
		return;

	CLongArray& cPosArray = pLine->getPosArray();

	PoTextAtt textAtt;
	CCharSet* pLink;
	CFrame* pObject;
	BrINT    dx, dy;
	BrINT    nDescent = 0;
	BrINT    nGatherOrder = CHAR_GATHER_NONE;
	BrINT    nCol = 0;
	BrWORD    wCode;
	BrINT     nTabFill;
	BYTE    bSeroStyle;

	PoTextAttHandler* text_att_h = document->getTextAttHandler();
	if (text_att_h == BrNULL)
		return;

	const PoParaAtt* paraAtt = document->getParaAttHandler()->getMergedParaAtt(pLine->getParaID(), pLine);

	BrINT nVerAlign = paraAtt->getVerAlign();

	BrINT nAscent = pLine->getAscent();
	BrINT nLineWid = du.doc2LogicalDX(nAscent, BrFALSE);

	CCharSetArray* pLinkArray = pLine->getCharSetArray();
	if (pLinkArray == BrNULL || pLinkArray->size() == 0)
		return;

	BrINT nCharNum = pLinkArray->size();
	if ((BrINT)cPosArray.size() < nCharNum + 1)
		return;

	CFieldArray* pFieldArray = document->getFieldArray();
	if (pLine->getStatus(LINE_FIELD) != 0) {
#ifdef NOT_IMP
		CLocation pos;
		pos.setLocation(pLine, 0, -1);

		BrINT nFieldID;
		if ((nFieldID = pos.isFieldPos(LOC_LEFT)) != 0) {
			g_pdrawTextField = pFieldArray->getField(nFieldID);
		}
		else {
			g_pdrawTextField = BrNULL;
		}
#endif
		document->getCmdEngine()->m_bBwpDrawForeground |= TEXT_UNDERLINE_FOREGROUND;
	}

	if (document->getBWPEngineMode() == EDITOR_WORD && document->isShowMemo() && pLine->isMemoEnd()
			&& document->getRevisionEngine()->getReviewMode() == ReviewMode::ALL_MARKUP)
		document->getCmdEngine()->m_bBwpDrawForeground |= TEXT_MEMO_ICON_FOREGROUND;


	BrBOOL bBidiPara = paraAtt->getBiDi();
#ifdef BIDI_SUPPORT
	BrBOOL bBidiText = BrFALSE;
	BrBOOL bRTLChar = BrFALSE;
	BrBOOL bDisplayCode = BrFALSE;
	CCharSet* pPrevLink = BrNULL;
	CCharSet* pNextLink = BrNULL;
	const PoTextAtt* pPrevTextAtt = BrNULL;
	const PoTextAtt* pNextTextAtt = BrNULL;
	BrBOOL bPrevBidiText = BrFALSE;
	BrBOOL bNextBidiText = BrFALSE;
	if (pLine->isDisplayCodeFlag() && pLine->getDisplayCodeArray().size() == nCharNum)
		bDisplayCode = BrTRUE;

	CCharSet dispLink;
#endif  // BIDI_SUPPORT

	ResetDrawCharInfo(document);
	BRDRAWCHARINFO stDrawCharInfo;
	memset(&stDrawCharInfo, 0, BrSizeOf(BRDRAWCHARINFO));
	stDrawCharInfo.pDC = dc;
	stDrawCharInfo.nLineHgt = nLineWid;
	stDrawCharInfo.nDescent = nDescent;
	stDrawCharInfo.nFlag = nVerAlign;
	stDrawCharInfo.bBidiPara = bBidiPara;

	InsDelHwpTypeSetSymbol(document, pLine);

	if (nSCol >= 0 && nSCol <= pLine->getCharNum() && nECol >= 0 && nECol <= pLine->getCharNum()) {
		nCol = nSCol;
		nCharNum = nECol;
	}

	BrBOOL bRevisionLine = BrFALSE;

	for ( ; nCol < nCharNum; nCol++) {
		pLink = pLinkArray->getCharSet(nCol);
		if (!pLink)
			break;

		stDrawCharInfo.nCol = nCol;

		if (document->getRevisionEngine()->isShowRevision(pLink) && !pLink->isMemoLink())
			bRevisionLine = BrTRUE;

		text_att_h->getTextAtt(textAtt, pLink->getAttrID());

		dx = sx;

#ifdef BIDI_SUPPORT
		bBidiText = textAtt.getBiDi();
		bRTLChar = IsRTLChar(pLink->getCode());
		if (bDisplayCode) {
			BrWORD wNewCode = pLine->getDisplayCodeArray().at(nCol);
			if (0 == wNewCode)
				continue;

			if (wNewCode != pLink->getCode()) {
				dispLink = *pLink;
				dispLink.setCode(wNewCode);
				pLink = &dispLink;
			}
		}
#endif

		if (pFrame->isTextFlowBottomToTop()) {
#ifdef BIDI_SUPPORT
			if (bRTLChar || bBidiText) {
				pPrevLink = pLinkArray->getCharSet(nCol - 1);
				if (pPrevLink) {
					pPrevTextAtt = text_att_h->getTextAtt(pPrevLink->getAttrID());
					bPrevBidiText = pPrevTextAtt->getBiDi();
				}
				if (pPrevLink && (IsRTLChar(pPrevLink->getCode()) || bPrevBidiText)) //TopToBottom으로 글자가 적히는 경우
					dy = sy - du.doc2LogicalDY((BrINT32)(cPosArray[nCol - 1]), BrFALSE); //현재 글자의 Top = 이전 글자의 Bottom
				else //마지막 글자이거나 글자 방향이 바뀌는 경우
				{
					BrINT nCharWid = CTextProc::getTextLinkWidth(document, &textAtt, pLink->getCode(), pLink, BrNULL, 0, BrTRUE);
					dy = sy - du.doc2LogicalDY((BrINT32)(cPosArray[nCol] + nCharWid), BrFALSE); //width를 다시 계산하여 위치 설정
				}
			}
			else {
				pNextLink = pLinkArray->getCharSet(nCol + 1);
				if (pNextLink) {
					pNextTextAtt = text_att_h->getTextAtt(pNextLink->getAttrID());
					bNextBidiText = pNextTextAtt->getBiDi();
				}
				// WPD-1696
				//if(pNextLink && !(IsRTLChar(pNextLink->getCode()) || bNextBidiText)) //BottomToTop으로 글자가 적히는 경우
				//	dy = sy - du.doc2LogicalDY((BrINT32)(cPosArray[nCol+1]-25), BrFALSE); //현재 글자의 Top = 다음 글자의 Bottom
				//else //마지막 글자이거나 글자 방향이 바뀌는 경우
				{
					BrINT nCharWid = CTextProc::getTextLinkWidth(document, &textAtt, pLink->getCode(), pLink, BrNULL, 0, BrTRUE);
					dy = sy - du.doc2LogicalDY((BrINT32)(cPosArray[nCol] + nCharWid), BrFALSE); //width를 다시 계산하여 위치 설정
				}
			}
#else
			dy = sy - du.doc2LogicalDY((BrINT32)(cPosArray[nCol + 1]), BrFALSE);
#endif  // BIDI_SUPPORT
		}
		else {
#ifndef USE_TEXTANIMATION_COUTDEV
			if (nSCol >= 0 && nSCol <= pLine->getCharNum() && nECol >= 0 && nECol <= pLine->getCharNum()) {
				if (nCol == nSCol) {
					dy = 0;
				}
				else {
					dy = du.doc2LogicalDY((BrINT32)(cPosArray[nCol] - cPosArray[nSCol]));
				}
			}
			else
				dy = sy + du.doc2LogicalDY((BrINT32)(cPosArray[nCol]), BrFALSE);
#else
			//[2013.04.18][SlideEffect][Animation] Add Sero Position Fix
			if (pFrame->getTextAnimationFlag())
				dy = sy + du.doc2LogicalDX(cPosArray[nCol] - pFrame->getTextAnimationBasePos(), BrFALSE);
			else
				dy = sy + du.doc2LogicalDY((BrINT32)(cPosArray[nCol]), BrFALSE);
#endif
		}
		stDrawCharInfo.sx = dx;
		stDrawCharInfo.sy = dy;

		if (pLink->isFieldExDummyLink()) {
			CField* pField = pLink->getField(document);
			if (pField != BrNULL && pField->getFieldType() == BR_FIELD_TYPE_EQ) {
				CFieldEq* pFieldEq = static_cast<CFieldEq*>(pField);
				stDrawCharInfo.nCol = nCol;	//원문자에 텍스트 효과 적용되어 있을 때 필요
				pFieldEq->drawSero(dc, stDrawCharInfo, du, stDrawCharInfo.sx, stDrawCharInfo.sy, pFrame, pLine, painter);
			}
		}
		// 수평선
		else if (pLink->isHLineLink()) {
			BrINT nActLineWidth;

			if ((nCol + 1) <= nCharNum) {
				if (pFrame->isTextFlowBottomToTop())
					nActLineWidth = (sy - du.doc2LogicalDY((BrINT32)(cPosArray[nCol]), BrFALSE)) - dy;
				else
					nActLineWidth = (sy + du.doc2LogicalDY((BrINT32)(cPosArray[nCol + 1]), BrFALSE)) - dy;
			}
			else
				nActLineWidth = nWidth;

			if (pFrame->isTextFlowLeftToRight())
				DrawHorizontalLineCode(dc, dx - nLineWid, dy, nActLineWidth, nLineWid, SERO);
			else
				DrawHorizontalLineCode(dc, dx, dy, nActLineWidth, nLineWid, SERO);
		}
		else if (pLink->is4BYTE()) {
			wCode = pLink->getCode();

			if (textAtt.isDrawUnderLine())
				document->getCmdEngine()->m_bBwpDrawForeground |= TEXT_UNDERLINE_FOREGROUND;
#ifdef _SPELLCHECKER
			if (document->isSpellCheckMode() && !g_pAppStatic->bBusyPrint && !painter->pDC->isExportMode() &&
					wCode != ASCII_CODE_SPACE && pLink->getWrongSpell())
				document->getCmdEngine()->m_bBwpDrawForeground |= TEXT_WRONG_SPELL;
#endif  // _SPELLCHECKER

			bSeroStyle = textAtt.getSeroStyle();

			if ((bSeroStyle & SERO_LIE_BIT) != 0) {
				DrawSeroCharSet(du, stDrawCharInfo, pFrame, document->m_charSetForDrawOneLineSero, &textAtt, pLine, painter);
			}
			else {
				*document->m_charSetForDrawOneLineSero = *pLink;
				nGatherOrder = CHAR_GATHER_NONE;
				if (CTextProc::isGatheringChar(pFrame, wCode, bSeroStyle, &textAtt)) {
					if (nCol < nCharNum - 1 && cPosArray[nCol] == cPosArray[nCol + 1]) {
						nGatherOrder = CHAR_GATHER_FIRST;
					}
					else if (nCol > 0 && cPosArray[nCol - 1] == cPosArray[nCol]) {
						nGatherOrder = CHAR_GATHER_SECOND;
					}
				}

				stDrawCharInfo.nFlag = nVerAlign | nGatherOrder;
				DrawSeroCharSet(du, stDrawCharInfo, pFrame, document->m_charSetForDrawOneLineSero, &textAtt, pLine, painter);
				stDrawCharInfo.nFlag = nVerAlign;
			}
		}
		else if (pLink->isTextLink()) {
			wCode = pLink->getCode();
			if (!CTextProc::isCRCode(wCode)) {
				if (textAtt.isDrawUnderLine() || textAtt.getTextBorderLineInfo())
					document->getCmdEngine()->m_bBwpDrawForeground |= TEXT_UNDERLINE_FOREGROUND;
#ifdef _SPELLCHECKER
				if (document->isSpellCheckMode()
						&& !(g_pAppStatic->bBusyPrint || g_pAppStatic->isPrtPreview() || document->getCmdEngine()->isCurOperation(ACTMAKETHUMBNAIL))
						&& !painter->pDC->isExportMode()
						&& wCode != ASCII_CODE_SPACE && pLink->getWrongSpell())
					document->getCmdEngine()->m_bBwpDrawForeground |= TEXT_WRONG_SPELL;
#endif  // _SPELLCHECKER

#ifdef PPT_EDITOR
				if (wCode != ASCII_CODE_SPACE)
					pLine->setSpaceStatus(nCol);
#endif
			}

			if (wCode == ASCII_CODE_TAB && !pLink->isBulletLink() && paraAtt->isSettedParaTabID()) {
				const PO_PARAATT_TAB::PoParaTab* paraTab = document->getParaAttHandler()->getParaTabArray()->getParaTab(paraAtt->getParaTabID());
				if (paraTab)
					nTabFill = paraTab->getTabFill((BrINT32)(cPosArray[nCol]), paraAtt->getLeftMargin());
			}
			else
				nTabFill = 0;

			BrBOOL check = (document->getBWPEngineMode() == EDITOR_WORD) && !painter->pDC->isExportMode() && checkEditSymbol(pLink);
			if (check) {
#ifdef SUPPORT_SHOW_HWP_TYPESET
				// 고정폭 빈칸 조판부호
				if (wCode == NON_BREAKING_SPACE && document->isShowHWPTypeSetModeEx()) {
					DrawSeroCharSetForHWPTypesetSymbol(du, stDrawCharInfo, pFrame, pLink, &textAtt, pLine, painter);
				}
				else
#endif  // SUPPORT_SHOW_HWP_TYPESET
				{
					stDrawCharInfo.nCol = nCol;
					DrawEditSymbol(du, stDrawCharInfo, (BrINT32)(cPosArray[nCol]), (BrINT32)(cPosArray[nCol + 1]), pLink, pLine, &textAtt, sy, BrTRUE);
					if (nTabFill == 0)
						continue;
				}
			}

			bSeroStyle = textAtt.getSeroStyle();

			if (nTabFill != 0) {
				if (document->isFromHwp() && nTabFill >= 1 && nTabFill <= 11) {
					DrawSeroHWPTabFill(dc, du, stDrawCharInfo, cPosArray[nCol], cPosArray[nCol + 1],
					                   sy, nTabFill, &textAtt);
				}
				else {
					BrINT nCurPos, nNextPos, nOneWidth;

					*document->m_charSetForDrawOneLineSero = *pLink;
					document->m_charSetForDrawOneLineSero->setCode((BrWORD)nTabFill);

					nCurPos = cPosArray[nCol];
					nNextPos = cPosArray[nCol + 1];
					nOneWidth = CTextProc::getTextLinkWidth(document, &textAtt, (BrWORD)nTabFill, BrNULL);
					if (nOneWidth != 0 && nCurPos < nNextPos) {
						while (nCurPos + nOneWidth <= nNextPos) {
							stDrawCharInfo.sy = dy;
							DrawSeroCharSet(du, stDrawCharInfo, pFrame, document->m_charSetForDrawOneLineSero, &textAtt, pLine);
							nCurPos += nOneWidth;

							if (pFrame->isTextFlowBottomToTop())
								dy = sy - du.doc2LogicalDY(nCurPos, BrFALSE);
							else
								dy = sy + du.doc2LogicalDY(nCurPos, BrFALSE);
						}
					}
				}
			}
			else if (pLink->isPageNumTimeDate()) {
				/*
				BrINT    nDispWid;

				nDispWid = CTextProc::drawSeroCharSetPgNumTimeDate(dc, du, dx, dy, nLineHgt, nDescent, pLink, text_att, nVerAlign);
				if( g_pAppStatic->.g_bDrawMasterPageInNormal && (nCol+1 < nCharNum) && (nDispWid > 0) && pLink->isPageNumLink() )
				{
					BrINT lArgWid = du.doc2LogicalX(cPosArray[nCol+1] - cPosArray[nCol], BrFALSE);
					if( lArgWid < nDispWid )
					{
					sx += nDispWid - lArgWid;
					}
				}
				*/
			}
			else if (pLink->isImageBulletLink()) {
				DrawImageBullet(document, dc, du, pFrame, pLink, stDrawCharInfo);
			}
			// for concurrent
			else if ( /*!document->IsWongogiMode() &&*/ textAtt.isSrcConCurWithTopBtmPos()) {
				BrINT nLineAscent;
				PoConcurSizeInfo concurSizeInfo = CTextDraw::getConcurSizeInfo(document, pLine, nCol, SERO, BrFALSE);
				if (concurSizeInfo.concurCount > 1) {
					// if ( nVerAlign==TOP_ARRANGE || nVerAlign==MIDDLE_ARRANGE )
					if (BR_TEXT_VALIGN_BOTTOM != nVerAlign) // OFF-20088
						nLineAscent = nLineWid + du.doc2LogicalX(concurSizeInfo.destConcurHeight, BrFALSE);
					else
						nLineAscent = nLineWid;
					DrawConCurStringSero(dc, document, pFrame, pLinkArray, concurSizeInfo.concurCount,
					                     concurSizeInfo.sourceConcurWidth, concurSizeInfo.destConcurWidth, 
										 concurSizeInfo.sourceConcurHeight, concurSizeInfo.destConcurHeight, nCol, du, dx, dy,
					                     nLineAscent, nVerAlign, pLine, nLineWid);
					//--- loop끝 부분에서 pNode++를 하므로 Word 처리한 글자의
					// 마지막 위치로 wCol과 pNode값을 조정한다.
					if (concurSizeInfo.concurCount > 1)
						nCol += (concurSizeInfo.concurCount - 1);
					pLink = pLinkArray->getCharSet(nCol);
					//---
				}
				else {
					stDrawCharInfo.sx = dx;
					stDrawCharInfo.sy = dy;
					DrawSeroCharSet(du, stDrawCharInfo, pFrame, pLink, &textAtt, pLine, painter);
				}
			}
			else if ((bSeroStyle & SERO_LIE_BIT) != 0) {
				DrawSeroCharSet(du, stDrawCharInfo, pFrame, pLink, &textAtt, pLine, painter);
			}
			else {
				*document->m_charSetForDrawOneLineSero = *pLink;
				nGatherOrder = CHAR_GATHER_NONE;
				if (CTextProc::isGatheringChar(pFrame, wCode, bSeroStyle, &textAtt)) {
					if (nCol < nCharNum - 1 && cPosArray[nCol] == cPosArray[nCol + 1]) {
						nGatherOrder = CHAR_GATHER_FIRST;
					}
					else if (nCol > 0 && cPosArray[nCol - 1] == cPosArray[nCol]) {
						nGatherOrder = CHAR_GATHER_SECOND;
					}
				}

				if (!pLink->isBulletLink()) {
					if (wCode == _T('.') || wCode == _T(',')) {
						BrWORD    wCodePrev = 0;
						BrWORD    wCodeNext = 0;
						if (wCode == _T('.')) {
							wCodePrev = pLinkArray->getPrevCode(nCol);
							wCodeNext = pLinkArray->getNextCode(nCol);
						}
						document->m_charSetForDrawOneLineSero->setCode(CTextProc::isConvertingChar(wCode, wCodePrev, wCodeNext));
					}
				}
#ifdef BIDI_SUPPORT
				if (pLink->isCROrSoftEnterLink()) {
					BrINT i;
					BrLONG dwPos = cPosArray[0];
					BrBOOL bBidiLine = pLine->hasBidi();

					if (bBidiPara) {
						if (bBidiLine) {
							for (i = 0; i <= nCharNum; i++) {
								if (dwPos > cPosArray[i])
									dwPos = cPosArray[i];
							}
						}

						if (pFrame->isTextFlowBottomToTop())
							dy = sy - du.doc2LogicalDY(dwPos, BrFALSE); //최하단 글자의 시작 위치
						else
							dy = sy + du.doc2LogicalDX(dwPos, BrFALSE); //최상단 글자의 시작 위치
					}
					else {
						if (bBidiLine) {
							for (i = 0; i <= nCharNum; i++) {
								if (dwPos < cPosArray[i])
									dwPos = cPosArray[i];
							}

							if (pFrame->isTextFlowBottomToTop())
								dy = sy - du.doc2LogicalDY(dwPos, BrFALSE); //최상단 글자의 끝 위치
							else
								dy = sy + du.doc2LogicalDX(dwPos, BrFALSE); //최하단 글자의 끝 위치
						}
					}
				}
#endif  // BIDI_SUPPORT

				stDrawCharInfo.nFlag = nVerAlign | nGatherOrder;
				stDrawCharInfo.nCol = nCol;

#ifdef SUPPORT_HWP_PAGE_BREAK
				if (wCode == ASCII_CODE_CR && !painter->pDC->isExportMode() && (pLink->isPageBreak() || pLink->isColBreak() || pLink->isSectionBreak() || pLink->isPageBreakHWP()))
#else
				if (wCode == ASCII_CODE_CR && !painter->pDC->isExportMode() && (pLink->isPageBreak() || pLink->isColBreak() || pLink->isSectionBreak()))
#endif
				{
					BRect rcFrame = pLine->getFrame()->getFrameRect();
					du.doc2Logical(rcFrame);
					if (sx < rcFrame.nLeft)
						return;
					if (stDrawCharInfo.sy < rcFrame.nBottom) {
						// 한 라인에 Break Code 가 여러개 있는 경우를 위하여.
						BrINT nEx;
						if (nCol < (nCharNum - 1))
							nEx = sy + du.doc2LogicalDX((BrINT32)(cPosArray[nCol + 1]), BrFALSE);
						else
							nEx = rcFrame.nBottom;
						DrawBreakCode(dc, du, &textAtt, pLink->getSubType(), sx + nLineWid / 2, stDrawCharInfo.sy, sx + nLineWid / 2, nEx, BrTRUE);
					}
				}
				else
					DrawSeroCharSet(du, stDrawCharInfo, pFrame, document->m_charSetForDrawOneLineSero, &textAtt, pLine, painter);
				stDrawCharInfo.nFlag = nVerAlign;
			}
		}
		else if (pLink->isImageBulletLink()) {
			// TODO : clipping
			DrawImageBullet(document, dc, du, pFrame, pLink, stDrawCharInfo);
		}
		else if (pLink->isAnchorLink()) {
			pObject = document->getAnchorFrame(pLink->getCode());

			if (pObject != BrNULL) {
				// 글자처럼 취급된 경우
				if (pObject->isAnchored()) {
					/*
					BrINT    nObjSize = pObject->width(BrFALSE);
					BrINT    nOffset = nObjSize-nAscent;
					if( pObject->getAnchorRunAround()!=0 && nOffset > 0 )
					{
						nObjSize = du.doc2LogicalX(nObjSize, BrFALSE);
						nOffset  = du.doc2LogicalX(nOffset,  BrFALSE);
						dx -= nOffset;
					}
					else
					{
						nObjSize = du.doc2LogicalX(nObjSize, BrFALSE);
						{
							BrINT lLeftMargin = pObject->getRunLeftMargin();
							lLeftMargin = du.doc2LogicalX(lLeftMargin, BrFALSE);
							dx += lLeftMargin;
						}
					}
					DrawAnchorObject(dc, du, pObject, dx, dy, SERO);
					*/
					auto& AvailArea = GetAvailAreaMatrix();
					BrINT nOldBandStart = AvailArea[0][0];
					BrINT nOldBandEnd = AvailArea[0][1];
					pObject->draw(painter, dc, du);
					// backup and restore the band area [RGD-725]
					if (pObject->isText()) {
						AvailArea[0][0] = nOldBandStart;
						AvailArea[0][1] = nOldBandEnd;
					}
#ifdef SUPPORT_SHOW_HWP_TYPESET
					// 글자처럼 취급된 object 조판부호
					if (document->isShowHWPTypeSetModeEx()) {
						BrINT w = HWPTypesetSymbolWidth(document, pLink, pLine, nCol);
						if (w) {
							stDrawCharInfo.sy = sy + du.doc2LogicalDY((BrINT32)(cPosArray[nCol + 1] - w), BrFALSE);
							DrawSeroCharSetForHWPTypesetSymbol(du, stDrawCharInfo, pFrame, pLink, &textAtt, pLine, painter);
						}
					}
#endif  // SUPPORT_SHOW_HWP_TYPESET
				}
				// 쪽, 문단, 여백 기준으로 Anchor된 경우
				else {
					if (IsDrawFloatingFrame(pObject, pFrame, document->isFromHwp(), BrNULL))
						pObject->draw(painter, dc, du);
#ifdef SUPPORT_SHOW_HWP_TYPESET
					// floating line_frame 조판부호
					if (document->isShowHWPTypeSetModeEx()) {
						stDrawCharInfo.nCol = nCol;
						DrawSeroCharSetForHWPTypesetSymbol(du, stDrawCharInfo, pFrame, pLink, &textAtt, pLine, painter);
					}
#endif  // SUPPORT_SHOW_HWP_TYPESET
				}
				ResetDrawCharInfo(document);
			}
		}
		else if (pLink->isTypesetLink() != 0) {
			if (textAtt.isDrawUnderLine())
				document->getCmdEngine()->m_bBwpDrawForeground |= TEXT_UNDERLINE_FOREGROUND;

			DrawSeroCharSet(du, stDrawCharInfo, pFrame, pLink, &textAtt, pLine, painter);

#ifdef SUPPORT_SHOW_HWP_TYPESET
			// Typeset 조판부호
			if (document->isShowHWPTypeSetModeEx()) {
				BrINT w = HWPTypesetSymbolWidth(document, pLink, pLine, nCol);
				if (w) {
					stDrawCharInfo.sy = sy + du.doc2LogicalDY((BrINT32)(cPosArray[nCol + 1] - w), BrFALSE);
					DrawSeroCharSetForHWPTypesetSymbol(du, stDrawCharInfo, pFrame, pLink, &textAtt, pLine, painter);
				}
			}
#endif  // SUPPORT_SHOW_HWP_TYPESET
		}
#ifdef SUPPORT_SHOW_HWP_TYPESET
		else {
			// 그 외 조판부호
			if (document->isShowHWPTypeSetModeEx()) {
				if ((cPosArray[nCol + 1] - cPosArray[nCol]) > 0) {
					DrawSeroCharSetForHWPTypesetSymbol(du, stDrawCharInfo, pFrame, pLink, &textAtt, pLine, painter);
				}
			}
		}
#endif  // SUPPORT_SHOW_HWP_TYPESET
	}
	const PoParaAtt* para_att = document->getParaAttHandler()->getOrgParaAtt(pLine->getParaID());
	if (para_att->getRevisionID() != default_revision_val && pLine->isStartLine())
		bRevisionLine = BrTRUE;
	pLine->setRevisionLine(bRevisionLine);
}


#ifdef SUPPORT_SHOW_HWP_TYPESET
// sero 모드에서 HWP 조판부호 string 처리
void CTextDraw::DrawSeroCharSetForHWPTypesetSymbol(
        CDrawUnit& du, BRDRAWCHARINFO& rDrawCharInfo, CFrame* pFrame, CCharSet* pLink,
        const PoTextAtt* pTextAtt, CLine* pLine, Painter* painter)
{
	if (pTextAtt == BrNULL)
		return;

	BoraDoc* document = theBWordDoc;
	if (document == BrNULL)
		return;

	if (DrawCharMakeParamForHWPTypesetSymbol(du, pLink, pTextAtt, pLine, rDrawCharInfo.nCol, painter) == BrFALSE)
		return;

	PoDcTextAtt* curDcTextAtt = theBWordDoc->getTextAttHandler()->getCurDrawingDcTextAtt();
	PoDcTextAtt* prevDcTextAtt = theBWordDoc->getTextAttHandler()->getPreDrawgDcTextAtt();

	BrBOOL bChanged = BrFALSE;
	BrINT nFSize = curDcTextAtt->getHanFSize();
	BString* qStrBuffer = curDcTextAtt->getTextString();
	if (qStrBuffer->isNull()) return;

	BrDC* dc = rDrawCharInfo.pDC;
	BrINT sx = rDrawCharInfo.sx;
	BrINT sy = rDrawCharInfo.sy;
	BrINT nLineWid = rDrawCharInfo.nLineHgt;

	BrINT nCharWid = 0;
	if (IsRequireWidth(pFrame->getTextFlow(), curDcTextAtt->getSuperscript(), curDcTextAtt->getSubscript()) == BrTRUE) {
		if (CTextProc::isExchangeWidthAndHeight(pFrame->getTextFlow(), qStrBuffer->at(0).unicode(), pTextAtt) == BrTRUE) //세로 쓰기일 때 0도 회전인 글자
		{
			if (pLink->isTypesetLink() != 0)
				nCharWid = CTextProc::getCharSetWidth(document, BrNULL, pLink, GARO);
			else
				nCharWid = CTextProc::getTextLinkWidth(document, pTextAtt, qStrBuffer->at(0).unicode(), pLink, BrNULL, 0, BrTRUE, BrNULL, BrNULL, BrFALSE);	// no cache because of same text_att pointer
			nCharWid = du.doc2LogicalDX(nCharWid, BrFALSE);
		}
		else {
			nCharWid = nFSize;
		}
	}

	sx = CTextProc::getLeftPosOfText(pFrame->getTextFlow(), sx, nLineWid, nCharWid,
	                                 qStrBuffer->at(0).unicode(), pTextAtt, rDrawCharInfo.nFlag);
	if (pTextAtt->getVOffset() != 0) {
		if (pFrame->isTextFlowLeftToRight())
			sx -= du.doc2LogicalDX(pTextAtt->getVOffset(), BrFALSE);
		else
			sx += du.doc2LogicalDX(pTextAtt->getVOffset(), BrFALSE);
	}

	// 세로쓰기에서 90도 회전하는 글자는 descent만큼 올려주자.(2012.8.13)[T-16340] Issue
	if (curDcTextAtt->getRotateValue() == 90)
		sx += g_pAppStatic->m_pFont->getCharDescent();
	// 세로쓰기에서 270도 회전하는 글자는 descent만큼 올려주자.(2012.8.13)[T-16340] Issue
	else if (curDcTextAtt->getRotateValue() == 270) {
		//[16.04.04][sglee1206] PPT 계열에서는 해당 처리시 겹치는 현상이 존재함 [ZPD-24914][ZPD-26098][ZPD-26261]
		sx -= g_pAppStatic->m_pFont->getCharDescent();
	}


	curDcTextAtt->setRotateValue(CTextProc::getRotateAngle(pFrame->getTextFlow(), qStrBuffer->at(0).unicode(), pTextAtt));
	BrCOLORREF textColor = curDcTextAtt->getTextColor().getColor();
	BFont* pAppStaticFont = g_pAppStatic->m_pFont;
	if (DrawCharChangedFont(*prevDcTextAtt, *curDcTextAtt)) {
		BrBOOL isSuperSubScript = curDcTextAtt->getSuperscript() || curDcTextAtt->getSubscript();
		BrINT fontSizeForDraw = isSuperSubScript? (nFSize * PO_TEXTATT_BASE::superSubScriptSizeRatio): nFSize;
		pAppStaticFont->setFontAttribute(fontSizeForDraw, pTextAtt->getBold(), pTextAtt->getItalic(), textColor);
		pAppStaticFont->setFontSize(fontSizeForDraw, DEFAULT_TEXT_HORIZ_SCALE);
		pAppStaticFont->setFontName((BrUSHORT*)document->getFontArray()->GetAt(curDcTextAtt->getHanFontID())->lf.lfFaceName, MAX_FONT_LEN);
		pAppStaticFont->setFontWidthRatio(pTextAtt->getHanExpCom());
		pAppStaticFont->setFontEmboss(pTextAtt->getEmboss());
		pAppStaticFont->setFontEngrave(pTextAtt->getEngrave());
		pAppStaticFont->setFontOutline(pTextAtt->getOutline());
		pAppStaticFont->setCharEqualHeight(pTextAtt->isNormalizeH());
		// #8873 (2012.8.30)
		if (pTextAtt->getShadow() && !pTextAtt->isWaEffected())
			g_pAppStatic->m_pFont->setFontShadow(RGB_DKGRAY);
		else
			g_pAppStatic->m_pFont->setFontShadow(-1);
		g_pAppStatic->m_pFont->setFontRotate(curDcTextAtt->getRotateValue());
		bChanged = BrTRUE;
	}
	if (bChanged || DrawCharChangedColor(*prevDcTextAtt, *curDcTextAtt) || g_pAppStatic->m_pFont->getTextColor() != textColor) {
		BrCOLORREF textColor = AutoTextColor(pLine, curDcTextAtt);
		g_pAppStatic->m_pFont->setFontColor(GetBrRValue(textColor), GetBrGValue(textColor), GetBrBValue(textColor));
		bChanged = BrTRUE;
	}
	if (bChanged)
		dc->setFont(g_pAppStatic->m_pFont);

	BString  strTmpBuf;
	BrINT32 nLen = qStrBuffer->length();
	for (BrINT n = 0; n < nLen; n++) {
		if (n > 0) {
			curDcTextAtt->setRotateValue(CTextProc::getRotateAngle(pFrame->getTextFlow(), qStrBuffer->at(n).unicode(), pTextAtt));
			g_pAppStatic->m_pFont->setFontRotate(curDcTextAtt->getRotateValue());
		}

		strTmpBuf = qStrBuffer->mid(n, 1);
		sy += dc->drawChars(&strTmpBuf, sx, sy);
	}

	if (bChanged)
		*prevDcTextAtt = *curDcTextAtt;
}
#endif  // SUPPORT_SHOW_HWP_TYPESET


void CTextDraw::DrawSeroHWPTabFill(BrDC* dc, CDrawUnit& dUnit, BRDRAWCHARINFO stDrawCharInfo,
                                   BrINT nCurPos, BrINT nNextPos, BrINT sy, BrINT nFillCode,
                                   const PoTextAtt* pTextAtt)
{
	BrINT nSy = sy + dUnit.doc2LogicalDY(nCurPos, BrFALSE);
	BrINT nEy = sy + dUnit.doc2LogicalDY(nNextPos, BrFALSE);
	BrINT nWidth = dUnit.doc2LogicalDX(pTextAtt->getHanFSize(), BrFALSE);
	BrINT nSx = stDrawCharInfo.sx + nWidth / 2;
	DrawHWPTabFill(dc, nSx, nSy, nSx, nEy, nFillCode, pTextAtt->getTextColor().getColor(), nWidth);
}


// draw sero concurrent string with top/bottom position
void CTextDraw::DrawConCurStringSero(BrDC* dc, BoraDoc* document, CFrame* pFrame,
                                     CCharSetArray* pNodeArray, BrINT nConCurCnt,
                                     BrINT nSrcWid, BrINT nDestWid, BrINT nSrcHgt, BrINT nDestHgt,
                                     BrINT nCol, CDrawUnit& cCoord, BrINT sx, BrINT sy,
                                     BrINT nLineWid, BrINT nVerAlign, CLine* pLine, BrINT nOrgLineWid)
{
	if (!document || !pNodeArray)
		return;

	BrINT nConCurWid = (nSrcWid > nDestWid)? nSrcWid: nDestWid;

	CCharSet* pLink;
	BrWORD wCode;

	BrINT x, y;
	BrINT dx, dy, nCharWid;
	BrINT nSrcCnt = 0;		// source character count
	BrINT nTotalCharSp = 0, nCharSp = 0, nSrcLineHgt;

	PoTextAttHandler* pTextAttHandler = document->getTextAttHandler();
	BrINT nCharNum = pNodeArray->GetSize();

	const PoTextAtt* text_att = pTextAttHandler->getTextAtt(pNodeArray->getCharSet(nCol)->getAttrID());
	if (text_att && text_att->getCharSp())
		nTotalCharSp = (BrINT)((text_att->getCharSp() * (float)nSrcWid) / 100.0 + 0.5);

	BRDRAWCHARINFO stDrawCharInfo = {};
	stDrawCharInfo.pDC = dc;
	if (nLineWid > nOrgLineWid)
		stDrawCharInfo.nLineHgt = nOrgLineWid - (nLineWid - nOrgLineWid);		// width of source concur CSP-4882
	else
		stDrawCharInfo.nLineHgt = nLineWid;
	nSrcLineHgt = stDrawCharInfo.nLineHgt;
	stDrawCharInfo.nDescent = 0;	// nDescent;
	stDrawCharInfo.nFlag = nVerAlign;
	stDrawCharInfo.bBidiPara = 0;	// bBidiPara;

	// draw source string
	x = sx;
	dy = (nConCurWid - nSrcWid) / 2;
	y = sy;

	for (; nCol < nCharNum; nCol++) {
		pLink = pNodeArray->getCharSet(nCol);
		wCode = pLink->getCode();

		// get text attribute
		text_att = pTextAttHandler->getTextAtt(pLink->getAttrID());
		if (BrNULL == text_att) {
			BRTHREAD_ASSERT(BrFALSE);
			continue;
		}
		if (BrFALSE == text_att->isSrcConCur())
			break;

		stDrawCharInfo.sx = x;
		stDrawCharInfo.sy = y + cCoord.doc2LogicalY(dy, BrFALSE);
		DrawSeroCharSet(cCoord, stDrawCharInfo, pFrame, pLink, text_att, pLine);

		nCharWid = text_att->getHanFSize();

		dy += nCharWid;
		if (text_att->getCharSp())
			dy += (BrINT)((text_att->getCharSp() * (float)nCharWid) / 100.0 + 0.5);
		nConCurCnt--;
	}

	// 글자 간격...
	if (nTotalCharSp && nConCurCnt)
		nCharSp = nTotalCharSp / nConCurCnt;

	if (BrNULL == text_att) {
		BRTHREAD_ASSERT(BrFALSE);
		return;
	}

	BrBYTE bAlign = text_att->getAlignForConCur();
	x = sx;
	y = sy;
	dy = (nConCurWid - nDestWid) / 2;
	BrINT nGap = CalcConCurAlignDrawInfo(dx, dy, text_att, nConCurCnt, nConCurWid, nDestWid, nTotalCharSp);

	if (text_att->getPositionForConCur() == TOP_POS_CONCUR) {
		dx = nSrcHgt + PTtoTWIP(text_att->getSpaceForConCur());
		dx = cCoord.doc2LogicalX(dx, BrFALSE);
		// source line height와 비교해 주자 CAM-6613
		if (nSrcLineHgt > dx)
			dx = nSrcLineHgt;
	}
	else {
		dx = -(PTtoTWIP(text_att->getSpaceForConCur()) + nDestHgt);
		dx = cCoord.doc2LogicalX(dx, BrFALSE);
	}
	stDrawCharInfo.sx = x + dx;

	if (nLineWid > nOrgLineWid)
		stDrawCharInfo.nLineHgt = nLineWid - nOrgLineWid;	// width of destination concur

	for ( ; nCol < nCharNum; nCol++) {
		pLink = pNodeArray->getCharSet(nCol);
		wCode = pLink->getCode();

		// get text attribute
		text_att = pTextAttHandler->getTextAtt(pLink->getAttrID());
		if (BrNULL == text_att) {
			BRTHREAD_ASSERT(BrFALSE);
			continue;
		}
		if (BrFALSE == text_att->isDestConCur())
			break;

#ifdef APPLY_BACKGROUND_DEST_CONCUR
		DrawBackgroundSeroForConCur(dc, text_att,
		                            x + cCoord.doc2LogicalX(dx, BrFALSE),
		                            y + cCoord.doc2LogicalY(dy, BrFALSE),
		                            x + cCoord.doc2LogicalY(dx + nDestHgt, BrFALSE),
		                            y + cCoord.doc2LogicalY(dy + text_att->getHanFSize(), BrFALSE));
#endif  // APPLY_BACKGROUND_DEST_CONCUR

		stDrawCharInfo.sy = y + cCoord.doc2LogicalY(dy, BrFALSE);
		DrawSeroCharSet(cCoord, stDrawCharInfo, pFrame, pLink, text_att, pLine);
		// DrawSeroCharSet(dc, cCoord, x+cCoord.doc2LogicalX(dx, BrFALSE), y+cCoord.doc2LogicalY(dy, BrFALSE), cCoord.doc2LogicalX(nDestHgt, BrFALSE)/*nLineWid*/, 0, (*pLink), text_att, nVerAlign, BrTRUE);

		if (text_att->isEndConCur()) {
#ifdef SUPPORT_SHOW_HWP_TYPESET
			// 덧말 조판부호
			if (document->isShowHWPTypeSetModeEx()) {
				const PoTextAtt* pSrcTextAtt = pLine->getSrcConCurrentTextAtt(nCol);
				if (pSrcTextAtt) {
					stDrawCharInfo.sx = sx;
					stDrawCharInfo.sy = sy + cCoord.doc2LogicalDX(nConCurWid, BrFALSE);
					DrawSeroCharSetForHWPTypesetSymbol(cCoord, stDrawCharInfo, pFrame, pLink, pSrcTextAtt, pLine, getPainter());
				}
			}
#endif  // SUPPORT_SHOW_HWP_TYPESET
			break;
		}

		dy += text_att->getHanFSize();
		if (bAlign == JUSTIFY_010_CONCUR || bAlign == JUSTIFY_121_CONCUR) {
			dy += nGap;
			dy += nCharSp;
		}
	}
//}
}


#ifdef APPLY_BACKGROUND_DEST_CONCUR
void CTextDraw::DrawBackgroundSeroForConCur(BrDC* dc, const PoTextAtt* pTextAtt,
                                            BrINT sx, BrINT sy, BrINT ex, BrINT ey)
{
	if (!pTextAtt)
		return;

#ifdef USE_THEME_COLOR
	// 역상
	if (pTextAtt->getReverse()) {
		BrBmvBrush brush, * pOldBrush;
		brush.createSolidBrush(pTextAtt->getTextColor().getColor());
		pOldBrush = dc->setBrush(&brush);
		dc->fillRect(sx, sy, ex + 1, ey + 1);
		dc->setBrush(pOldBrush);
		// FillRectangle(dc, sx, sy, ex+1, ey+1, SOLID, text_att->getTextColor());
	}
	// 바탕색
	else if (pTextAtt->getBackFlag()) {
		BrBmvBrush brush, * pOldBrush;
		brush.createSolidBrush(pTextAtt->getBackColor().getColor());
		pOldBrush = dc->setBrush(&brush);
		dc->fillRect(sx, sy, ex + 1, ey + 1);
		dc->setBrush(pOldBrush);
		// FillRectangle(dc, sx, sy, ex+1, ey+1, SOLID, text_att->getBackColor());
	}

	if (pTextAtt->getUnderline()) {
		CCUtil::drawLine(dc, ex, sy, ex, ey, 1,
		                 pTextAtt->getReverse()? pTextAtt->getBackColor().getColor():
		                                         pTextAtt->getTextColor().getColor());
		// DrawLine(dc, ex, sy, ex, ey, 1, (text_att->getReverse())?text_att->getBackColor():text_att->getTextColor());
	}

	if (pTextAtt->getStrikeout()) {
		CCUtil::drawLine(dc, sx + (ex - sx) / 2, sy, sx + (ex - sx) / 2, ey, 1,
		                 pTextAtt->getReverse()? pTextAtt->getBackColor().getColor():
		                                         pTextAtt->getTextColor().getColor());
		// DrawLine(dc, sx+(ex-sx)/2, sy, sx+(ex-sx)/2, ey, 1, (text_att->getReverse())?text_att->getBackColor():text_att->getTextColor());
	}
#else  // USE_THEME_COLOR
	// 역상
	if (pTextAtt->getReverse()) {
		BrBmvBrush brush, * pOldBrush;
		brush.createSolidBrush(pTextAtt->getTextColor());
		pOldBrush = dc->setBrush(&brush);
		dc->fillRect(sx, sy, ex + 1, ey + 1);
		dc->setBrush(pOldBrush);
		// FillRectangle(dc, sx, sy, ex+1, ey+1, SOLID, text_att->getTextColor());
	}
	// 바탕색
	else if (pTextAtt->getBackFlag()) {
		BrBmvBrush brush, * pOldBrush;
		brush.createSolidBrush(pTextAtt->getBackColor());
		pOldBrush = dc->setBrush(&brush);
		dc->fillRect(sx, sy, ex + 1, ey + 1);
		dc->setBrush(pOldBrush);
		// FillRectangle(dc, sx, sy, ex+1, ey+1, SOLID, text_att->getBackColor());
	}

	if (pTextAtt->getUnderline()) {
		CCUtil::drawLine(dc, ex, sy, ex, ey, 1,
		                 pTextAtt->getReverse()? pTextAtt->getBackColor(): pTextAtt->getTextColor());
		// DrawLine(dc, ex, sy, ex, ey, 1, (text_att->getReverse())?text_att->getBackColor():text_att->getTextColor());
	}

	if (pTextAtt->getStrikeout()) {
		CCUtil::drawLine(dc, sx + (ex - sx) / 2, sy, sx + (ex - sx) / 2, ey, 1,
		                 pTextAtt->getReverse()? pTextAtt->getBackColor(): pTextAtt->getTextColor());
		// DrawLine(dc, sx+(ex-sx)/2, sy, sx+(ex-sx)/2, ey, 1, (text_att->getReverse())?text_att->getBackColor():text_att->getTextColor());
	}
#endif  // USE_THEME_COLOR
}
#endif  // APPLY_BACKGROUND_DEST_CONCUR


void CTextDraw::DrawAnchorObject(Painter* painter, BrDC* dc, CDrawUnit& du,
                                 CFrame* pFrame, BrINT sx, BrINT sy)
{
	if (BrNULL == pFrame)
		return;

	if (BrNULL == pFrame->getPage())
		CTextProc::restoreBackwardPointOfPage(theBWordDoc, pFrame);

	BPoint cSaveP;
	BPoint cFrameP;
	BPoint cOffsetP;
	BRect* lprcFrame = pFrame->getFrameRect();
	BRect* lprcMargin = pFrame->getRunMargin();

	du.getPageStart(cSaveP);

	cFrameP.x = lprcFrame->nLeft - lprcMargin->nLeft;
	cFrameP.y = lprcFrame->nTop;
	du.doc2Logical(cFrameP, BrTRUE);

	cOffsetP.x = sx - cFrameP.x + cSaveP.x;
	cOffsetP.y = sy - cFrameP.y + cSaveP.y;
	du.setPageStart(cOffsetP);

	pFrame->draw(painter, dc, du);

	du.setPageStart(cSaveP);
}


void CTextDraw::ResetDrawCharInfo(BoraDoc* document)
{
	document->getTextAttHandler()->getPreDrawgDcTextAtt()->reset();
}


void CTextDraw::InsDelHwpTypeSetSymbol(BoraDoc* document, CLine* line)
{
#ifdef SUPPORT_SHOW_HWP_TYPESET
	if (BrFALSE == document->isFromHwp())
		return;

	BrBOOL is_set_pos_hwp_typeset = line->getPosForHWPTypeSet();
	if (document->isShowHWPTypeSetModeEx()) {
		if (BrFALSE == is_set_pos_hwp_typeset)
			CTextProc::checkHWPTypeSetSymbol(document, line);  // 조판 부호 삽입
	}
	else {
		if (is_set_pos_hwp_typeset && line->getIsHWPTypeSet())
			CTextProc::removeHWPTypeSetSymbol(document, line);  // 조판 부호 삭제
	}
#endif  // SUPPORT_SHOW_HWP_TYPESET
}


BrBOOL CTextDraw::IsDrawFloatingFrame(CFrame* floating_frame, CFrame* frame, BrBOOL is_hwp, CPage* page)
{
	if (floating_frame->isODTFrame()) {
		return floating_frame->hasNextPosParentAnchorFrame();
	}

	CFrame* base_frame = frame;
	if (base_frame->isCell()) {
		base_frame = base_frame->getCell()->getTableFrame();
		if (is_hwp &&
		    floating_frame->getFrameList()->getNext(floating_frame) == base_frame &&
		    BrFALSE == floating_frame->isUnderBasic() &&
		    NO_RUN_AROUND != floating_frame->getRAType())  // WPD-1900
			return BrTRUE;
	}

	CFrame* anchor_frame = base_frame->getAnchorFrame();
	if (anchor_frame && BrFALSE == anchor_frame->isBasic()) {
		if (anchor_frame->isCell())
			anchor_frame = anchor_frame->getCell()->getTableFrame();
		if (BrFALSE == anchor_frame->isAnchored())
			return BrTRUE;
	}

	return (page && page->getFrameDraw());
}


#ifdef USE_ANIMATION_COMPONENT_COUTDEV
#ifdef SUPPORT_TEXT_PATHANIMATION
// [2013.06.28][TextAnimation][PathAnimation]
//  Line과 Frame에서 가장 최근에 진행된 Animation얻는 함수추가
ACTimeNode* CTextDraw::LineRecentPathAnimation(CPage* page, CLine* pLine, BrINT32 nAnimationIndex)
{
	ACTimeNode* pAni = BrNULL;
	BrINT32 animationIndex = nAnimationIndex;

	if (page->getEffectEnd())
		animationIndex++;

	BArray<ACTimeNode*> pLineAniArr = pLine->getAnimationNodeArray();

	if (pLineAniArr) {
		// line에 Animation이 적용된 경우 그에 해당한 Animation의 위치 참조
		BrINT32 maxIndex = -1;
		for (BrINT i = 0; i < pLineAniArr.GetSize(); i++) {
			if (pLineAniArr.GetAt(i)) {
				ACTimeNode* pLineAni = *pLineAniArr.GetAt(i);
				if (pLineAni && pLineAni->isPathAnimation()) {
					// path animation인 경우 frame위치보정
					BrINT32 index = page->getAnimationIndex(pLineAni);
					if (index < animationIndex && index > maxIndex) {
						maxIndex = index;
						pAni = pLineAni;
					}
				}
			}
		}
	}

	pLine->setResetPathAni(pAni);
	return pAni;
}


ACTimeNode* CTextDraw::FrameRecentPathAnimation(CPage* page, CFrame* pFrame, BrINT32 nAnimationIndex)
{
	ACTimeNode* pAni = BrNULL;
	BrINT32 animationIndex = nAnimationIndex;

	if (page->getEffectEnd())
		animationIndex++;

	BArray<ACTimeNode*> pFrmAniArr = pFrame->getAnimationNodeArray();

	if (pFrmAniArr) {
		BrINT32 maxIndex = -1;
		for (BrINT i = 0; i < pFrmAniArr.GetSize(); i++) {
			if (pFrmAniArr.GetAt(i)) {
				ACTimeNode* pFrameAni = *pFrmAniArr.GetAt(i);

				if (pFrameAni && pFrameAni->getTextElemnetType() != ACTextElementType_ParagraphTextRange && pFrameAni->PresetClass() == ACTimeNodePresetClass_path) {
					// path animation인 경우 frame위치보정
					BrINT32 index = page->getAnimationIndex(pFrameAni);
					if (index < animationIndex && index > maxIndex) {
						maxIndex = index;
						pAni = pFrameAni;
					}
				}
			}
		}
	}

	pFrame->setRecentPathAni(pAni);
	return pAni;
}


// [2013.06.28][TextAnimation][PathAnimation]
//  Path Animation진행후 Frame과 Line의 위치얻기
void CTextDraw::CalculatePosAfterPathAnimation(Painter* painter, CPage* page, ACTimeNode* pAni,
                                               BRect* rcFrame, BrBOOL isAnimation)
{
	if (pAni == BrNULL)
		return;

	CFrame* pPathAnimFrame = pAni->getAnimationPathFrame();

	if (pPathAnimFrame) {
		BPoint frmPos = pPathAnimFrame->getPos(BrFALSE);
		BArray<BrDPoint>* pVertexArray = pPathAnimFrame->getPathPointArray();
		if (!pVertexArray) {
			PrBitmap* bitmap = BrNEW PrBitmap;
			painter->pDC->setMakePathPoints(BrTRUE);
			pPathAnimFrame->generatePaths(painter, bitmap);
			painter->pDC->setMakePathPoints(BrFALSE);
			BR_SAFE_DELETE(bitmap);
			pVertexArray = pPathAnimFrame->getPathPointArray();
			if (!pVertexArray)
				return;
		}

		CCmdEngine* pCmdEngine = theBWordDoc->getCmdEngine();

		//[2013.07.10][SlideShow][TextPathAnimation] path frame의 pos가 frame의 중심으로부터의 상대값이므로 page내 위치를 계산할때에는 frame의 중심점을 리용한다.
		// Animation시에는 path frame의 위치를 리용한다.
		if (!isAnimation) {
			CFrame* org = pAni->getFrame();
			BRect rect = org->getFrameRect();
			BPoint frmCenter = rect.Center();

			frmCenter.x += pCmdEngine->getScrOffsetDx();
			frmCenter.y += pCmdEngine->getScrOffsetDy();
			pCmdEngine->page2Logical(org->getPage(), frmCenter);

			frmPos = frmCenter;
		}

		if (pVertexArray->GetSize() > 0) {
			BrDPoint* vertex = pVertexArray->GetAt(pVertexArray->GetSize() - 1);
			if (vertex) {
				BrLONG w = rcFrame->GetWidth(), h = rcFrame->GetHeight();

				rcFrame->nLeft = pCmdEngine->logical2DocX(vertex->x + frmPos.x) - w / 2 - pCmdEngine->getScrOffsetDx();
				rcFrame->nTop = pCmdEngine->logical2DocY(vertex->y + frmPos.y) - h / 2 - pCmdEngine->getScrOffsetDy();
				rcFrame->nRight = rcFrame->nLeft + w;
				rcFrame->nBottom = rcFrame->nTop + h;
			}
		}
	}
}
#endif  // SUPPORT_TEXT_PATHANIMATION


// [2013.08.13][SlideShow Animation][LetterWordEffect]
// Letter 나 Word의 Hightlight Animation을 위한 bitmap생성함수
#ifdef USE_TEXTANIMATION_LETTERWORD_COUTDEV
BrINT CTextDraw::MakeDIBForHighligthsAnimation(Painter* painter, TEXTBITMAPINFO& text_bmp_info,
                                               ACTimeNode* pAni)
{
	if (!pAni)
		return 0;

	CFrame* pFrame = pAni->getFrame();
	if (!pFrame)
		return 0;

	BrShape* pBorder = pFrame->getBorder();
	if (!pBorder)
		return 0;

	// frame에 hightlight 속성을 설정하여 animation필요한 Letter 나 Word bitmap을 얻는다.
	BrINT nTextAttArraySize = 0;
	PoTextAttHandler* text_att_h = BrNULL;
	PoTextAtt* pTextAtt = BrNULL;
	BArray<BrINT*>* pNewTextAttrArray = BrNULL;

	pFrame->getNewTextAttrArray(nTextAttArraySize, text_att_h, pNewTextAttrArray);

	BrEffectEndInfo* pEffectEndInfo = (BrEffectEndInfo*)BrMalloc(BrSizeOf(BrEffectEndInfo));
	pEffectEndInfo->nFontID = 0;  // changefonttype animation parsing 안된 림시
	pEffectEndInfo->fScaleX = 1.f;
	pEffectEndInfo->fScaleY = 1.f;  // GrowShrink Animation에 리용
	pEffectEndInfo->nAniBlastCount = 0;  // Blast Animation이 몇번 적용되였는지를 반영
	pEffectEndInfo->fTransparency = 0.f;  // Transparency Animation에 리용
	pEffectEndInfo->bLineStyle = BrFALSE;
	pEffectEndInfo->bBrushStyle = BrFALSE;  // brush, line style을 무조건 설정해야 하는지를 반영
	pEffectEndInfo->nLineColor[0] = GetRValue(pBorder->getLineColor());
	pEffectEndInfo->nLineColor[1] = GetGValue(pBorder->getLineColor());
	pEffectEndInfo->nLineColor[2] = GetBValue(pBorder->getLineColor());

	if (pBorder->getFillStyle() == BMV_FILLTYPE_GRADIENT) {
		pEffectEndInfo->nBrushColor[0] = GetRValue(pBorder->getBrush()->getBaseGradientColor());
		pEffectEndInfo->nBrushColor[1] = GetGValue(pBorder->getBrush()->getBaseGradientColor());
		pEffectEndInfo->nBrushColor[2] = GetBValue(pBorder->getBrush()->getBaseGradientColor());
	}
	else {
		pEffectEndInfo->nBrushColor[0] = GetRValue(pBorder->getBrushColor());
		pEffectEndInfo->nBrushColor[1] = GetGValue(pBorder->getBrushColor());
		pEffectEndInfo->nBrushColor[2] = GetBValue(pBorder->getBrushColor());
	}

//	BrBOOL bIsChangeFontSize = BrFALSE;
//	BrFLOAT fFontSizeRatio = 1.f;
	BrBOOL isHighlightAnimation = BrTRUE;
	BrBOOL bParaText = pAni->getTextElemnetType() == ACTextElementType_ParagraphTextRange; // line별로 Animation이 적용된 경우(즉 text animation인 경우)
	ACBuildParagraph* pBuild = pAni->getBldParGraph();

	switch (pAni->PresetIDEnum()) {
		case ACTimeNodePresetID_Darken:
		case ACTimeNodePresetID_Lighten:
		case ACTimeNodePresetID_Desaturate:
		case ACTimeNodePresetID_ComplementaryColor:
		case ACTimeNodePresetID_ComplementaryColor2:
		case ACTimeNodePresetID_ContrastingColor: {
			// 색조작이 필효한 Animation처리
			isHighlightAnimation = pFrame->drawHSLColor(pAni, pNewTextAttrArray, pEffectEndInfo);
			break;
		}
		case ACTimeNodePresetID_LineColor:
		case ACTimeNodePresetID_FillColor: {
			// 텍스트 애니메이션이므로 제외시킴
			isHighlightAnimation = BrFALSE;
			break;
		}
		case ACTimeNodePresetID_ChangeFontColor:
		case ACTimeNodePresetID_ObjectColor:
		case ACTimeNodePresetID_Blast:
		case ACTimeNodePresetID_GrowWithColor:
		case ACTimeNodePresetID_Underline:
		case ACTimeNodePresetID_BrushColor:
		case ACTimeNodePresetID_ColorWave:
		case ACTimeNodePresetID_Transparency:
		case ACTimeNodePresetID_BoldReveal:
		case ACTimeNodePresetID_ChangeFont:
		case ACTimeNodePresetID_ChangeFontStyle:
		case ACTimeNodePresetID_StyleEmphasis: {
			isHighlightAnimation = pFrame->drawEffectEnd(pAni, pNewTextAttrArray, pEffectEndInfo, painter, BrTRUE);
			//원래 없던 아이 //case ACTimeNodePresetID_Rotate
			//주석처리됨//case BrAnimationGrowShrink:
					// 		{
					// 			scaleX *= pAni->getScaleX() / 100000.f;
					// 			scaleY *= pAni->getScaleY() / 100000.f;
					//
					// 			break;
					// 		}
			break;
		}
		case ACTimeNodePresetID_BoldFlash:
		case ACTimeNodePresetID_Ent_ColorTypeWriter:
		case ACTimeNodePresetID_Ext_ColorTypeWriter:
		case ACTimeNodePresetID_VerticalHighLight:
		case ACTimeNodePresetID_ColorPulse: {
			isHighlightAnimation = pFrame->drawColorBitmap(pAni, pNewTextAttrArray, pEffectEndInfo, BrTRUE);
			break;
		}
		default: {
			isHighlightAnimation = BrFALSE;
		}
	}

	// highlit animation이 아닌 경우에는 아래의 조작을 진행할 필요가 없다.
	if (isHighlightAnimation == BrFALSE) {
		BrFree(pEffectEndInfo);
		return 0;
	}

	BrINT* line_rgb = pEffectEndInfo->nLineColor;
	line_rgb[0] = BrMAX(0, BrMIN(255, line_rgb[0]));
	line_rgb[1] = BrMAX(0, BrMIN(255, line_rgb[1]));
	line_rgb[2] = BrMAX(0, BrMIN(255, line_rgb[2]));

	BrINT* brush_rgb = pEffectEndInfo->nBrushColor;
	brush_rgb[0] = BrMAX(0, BrMIN(255, brush_rgb[0]));
	brush_rgb[1] = BrMAX(0, BrMIN(255, brush_rgb[1]));
	brush_rgb[2] = BrMAX(0, BrMIN(255, brush_rgb[2]));

	pFrame->setAnimateColoring(BrTRUE);

	BrINT oldLineStyle, oldDashStyle, oldBrushStyle;
	BrCOLORREF oldLineColor, oldBrushColor;

	BrCOLORREF line_color = BrRGB(line_rgb[0], line_rgb[1], line_rgb[2]);
	if (pEffectEndInfo->bLineStyle) {
		oldLineColor = pFrame->setAnimateLineColoring(line_color, oldLineStyle, oldDashStyle);
	}
	else {
		oldLineColor = pBorder->getLineColor();
		pBorder->setLineColor(line_color);
	}

	BrCOLORREF brush_color = BrRGB(brush_rgb[0], brush_rgb[1], brush_rgb[2]);
	if (pEffectEndInfo->bBrushStyle) {
		oldBrushColor = pFrame->setAnimateBrushColoring(brush_color, oldBrushStyle);
	}
	else {
		oldBrushColor = pFrame->setAnimateBrushColoring(brush_color, oldBrushStyle);
		//brush의 color를 설정할때 무조건 style이 solid로 변경(color가 있는한)되므로
		pBorder->setFillStyle(oldBrushStyle);
	}

	for (BrINT i = 0; pNewTextAttrArray && i < pNewTextAttrArray->size(); i++) {
		BrINT* pNewTextAttr = *pNewTextAttrArray->GetAt(i);

		pNewTextAttr[2] = BrMAX(0, BrMIN(255, pNewTextAttr[2]));
		pNewTextAttr[3] = BrMAX(0, BrMIN(255, pNewTextAttr[3]));
		pNewTextAttr[4] = BrMAX(0, BrMIN(255, pNewTextAttr[4]));

		pTextAtt = const_cast<PoTextAtt*>(text_att_h->getTextAtt(pNewTextAttr[0]));
		if (pTextAtt) {
			pTextAtt->setTextColor(BrRGB(pNewTextAttr[2], pNewTextAttr[3], pNewTextAttr[4]));
			pTextAtt->setBold(BrBOOL(pNewTextAttr[7]));
			pTextAtt->setItalic(BrBOOL(pNewTextAttr[8]));
			if (pNewTextAttr[9])
				pTextAtt->setUnderline(BrTRUE);
			pTextAtt->setHanFontID(pNewTextAttr[10]);
			pTextAtt->setEngFontID(pNewTextAttr[11]);
		}
	}
/*		if (bIsChangeFontSize)
		{
			text_att->setEngFSize(text_att->getEngFSize() * fFontSizeRatio);
			text_att->setHanFSize(text_att->getHanFSize() * fFontSizeRatio);
		}
	}
	if (bIsChangeFontSize)
	{
		if (pFrame->getAutoWidthFlag())
			pFrame->setBottom(pFrame->bottom() * 2 - pFrame->top());
		CTextProc::arrangeAndExpandFrame(theBWordDoc, pFrame->getFirstLine(), pFrame->getLastLine(), FORCE_DRAW, 0, BrTRUE);
	}
*/

	// highlight animation에 따르는 Bitmap얻기.
	TEXTBITMAPINFO text_bitmap_info = {};
	text_bitmap_info.nType = text_bmp_info.nType;
	text_bitmap_info.pBitMapArray = BrNULL;
	text_bitmap_info.pPointArray = BrNULL;
	text_bitmap_info.pFrame = pAni->getFrame();
	text_bitmap_info.pAni = pAni;
	if (!text_bitmap_info.pFrame) {
		BR_SAFE_FREE(pEffectEndInfo);
		return 0;
	}

	BrINT nRet = TextToDIB(gpPaint, text_bitmap_info);
	if (nRet != 1) {
		BR_SAFE_FREE(pEffectEndInfo);
		return nRet;
	}

	//[2013.11.12][SlideEffect]  convert line_frame pos to screen coordinate
	ConvertFrmPosToLogical(pFrame, text_bitmap_info);

	// frame에 각도가 있으면 Letter나 Word Bitmap을 회전시키고 위치를 보정한다.
	if (pFrame->GetRotation())
		RotateDIBWithAngle(getPainter(), pFrame, text_bitmap_info);

	// scale 처리
	if (pEffectEndInfo->nAniBlastCount > 0) {  //Blast Animation이 한번이라도 적용되였다면
		pEffectEndInfo->fScaleX *= 1.3f;
		pEffectEndInfo->fScaleY *= 1.6f;
	}

	// bitmap의 scale
	ScaleDIBWithScale(getPainter(), pFrame, text_bitmap_info,
	                  pEffectEndInfo->fScaleX, pEffectEndInfo->fScaleY);

	// bitmap의 transparency
	TranspDIBWithScale(getPainter(), pFrame, text_bitmap_info, pEffectEndInfo->fTransparency);

	//[2013.10.01][SlideEffect][Dandong][ColortypeWriter]
	// letter나 word의 ColorTypeWriter인 경우 second bitamp을 first bitamp뒤에 추가하여 리용한다.
	if (pAni->PresetIDEnum() == ACTimeNodePresetID_Ent_ColorTypeWriter ||
			pAni->PresetIDEnum() == ACTimeNodePresetID_Ext_ColorTypeWriter) {
		if (text_bmp_info.pHighlightBitmapArray) {
			if (text_bitmap_info.pBitMapArray) {
				text_bmp_info.pHighlightBitmapArray->Append(*text_bitmap_info.pBitMapArray);

				// remove and free highlight bitmap
				text_bitmap_info.pBitMapArray->RemoveAll();
				BR_SAFE_DELETE(text_bitmap_info.pBitMapArray);
			}
		}
		else {
			text_bmp_info.pHighlightBitmapArray = text_bitmap_info.pBitMapArray;
		}
	}
	else {
		text_bmp_info.pHighlightBitmapArray = text_bitmap_info.pBitMapArray;
	}

	if (text_bitmap_info.pPointArray)
		text_bitmap_info.pPointArray->RemoveAll();
	BR_SAFE_DELETE(text_bitmap_info.pPointArray);
	// frame에 hightlight 속성을 원본상태로 되돌려 놓는다.

	pBorder->setBrushColor(oldBrushColor);   //color설정시 style이 변경되므로 아래서 무조건 원래 style로 복귀해야 한다.
	pBorder->setFillStyle(oldBrushStyle);
	pBorder->setLineColor(oldLineColor);
	if (pEffectEndInfo->bLineStyle) {
		pBorder->setLineStyle(oldLineStyle);
		pBorder->setDashStyle(oldDashStyle);
	}

	pFrame->setAnimateColoring(BrFALSE);

	// free textattr
	pFrame->restoreTextAttrArray(nTextAttArraySize, text_att_h, pNewTextAttrArray);
//	if (bIsChangeFontSize)
//		CTextProc::arrangeAndExpandFrame(theBWordDoc, pFrame->getFirstLine(), pFrame->getLastLine(), FORCE_DRAW, 0, BrTRUE);

	return 1;
}
#endif  // USE_TEXTANIMATION_LETTERWORD_COUTDEV
#endif  // USE_ANIMATION_COMPONENT_COUTDEV


//[2013.11.12][SlideEffect] convert line_frame pos to logical.
BrBOOL CTextDraw::ConvertFrmPosToLogical(CFrame* pFrame, TEXTBITMAPINFO& rTextBitmapInfo)
{
	CCmdEngine* pCE = theBWordDoc->getCmdEngine();
	if (!pCE->isSlideShow()) {
		// 슬라이드쇼에 특화된 함수입니다. 이곳에 진입 하면 안됩니다.
		BRTHREAD_ASSERT(BrFALSE);
	}

	BPtrArray* pBitmapArray = rTextBitmapInfo.pBitMapArray;
	if (!pBitmapArray || pBitmapArray->count() <= 0)
		return BrFALSE;

	PrBitmap* bitmap = BrNULL;
	BPointArray* pPointArray = rTextBitmapInfo.pPointArray;
	if (pPointArray && pPointArray->count() > 0) {
		BrINT prevWidth = 0, yPos = 0;
		const BrINT kCount = BrMIN(pPointArray->count(), pBitmapArray->count());
		for (BrINT chIndex = 0; chIndex < kCount; chIndex++) {
			bitmap = (PrBitmap*)pBitmapArray->GetAt(chIndex);
			BPoint* pos = pPointArray->GetAt(chIndex);

			if (bitmap == BrNULL || pos == BrNULL) {
				continue;
			}

			BPoint tPOS(pos->x, pos->y);
			BPoint org(0, 0); // view original value 얻기

			pCE->frame2Logical(pFrame, tPOS);
			pCE->page2Logical(pFrame->getPage(), org);
			tPOS.x -= org.x;
			tPOS.y -= org.y;
			pos->x = tPOS.x;
			pos->y = tPOS.y;

			//[2015.4.20] Underline시 문자들사이 선들이 그려지지않는 오유수정(text bitmap pos 보정)
			if (chIndex == 0) {
				// 가로쓰기 일때 이전의 글자의 width 보관해 놓음
				yPos = tPOS.y;
				prevWidth = tPOS.x + bitmap->cx();
			}
			else {
				if ((tPOS.y == yPos) && (prevWidth != tPOS.x)) {
					if (rTextBitmapInfo.pFrame->getTextFlow() == TEXTFLOW_GARO) {
						pos->x = prevWidth;
						yPos = tPOS.y;
						prevWidth = prevWidth + bitmap->cx();
					}
				}
				else {
					yPos = tPOS.y;
					prevWidth = tPOS.x + bitmap->cx();
				}
			}
		}
	}

	return BrTRUE;
}


BrINT CTextDraw::TextToDIB(Painter* painter, TEXTBITMAPINFO& text_bmp_info)
{
	switch (text_bmp_info.nType) {
		case BITMAP_CHAR:  return MakeDIBFromChar(painter, text_bmp_info);
		case BITMAP_WORD:  return MakeDIBFromWord(painter, text_bmp_info);
	}
	return 0;
}


BrINT CTextDraw::MakeDIBFromChar(Painter* painter, TEXTBITMAPINFO& text_bmp_info)
{
	CFrame* pFrame = text_bmp_info.pFrame;
	CLine* pLine = pFrame? pFrame->getFirstLine(): BrNULL;
	if (BrNULL == pLine)
		return 0;

#ifdef USE_ANIMATION_COMPONENT
	if (BrFALSE == CreateDIB(text_bmp_info))
		return kPoWarnMemoryAllocFailForSlideShow;
#endif//#ifdef USE_ANIMATION_COMPONENT

	//[2013.06.04][Dandong2] Animation에 속한 Line들만 Letter 나 Word Bitmap을 따낸다.
#if defined(USE_TEXTANIMATION_LETTERWORD_COUTDEV) && defined(USE_ANIMATION_COMPONENT_COUTDEV)
	ACTimeNode* pAnimation = text_bmp_info.pAni;
#endif  // USE_TEXTANIMATION_LETTERWORD_COUTDEV && USE_ANIMATION_COMPONENT_COUTDEV

	for ( ; pLine; pLine = pLine->getNext()) {
#if defined(USE_TEXTANIMATION_LETTERWORD_COUTDEV) && defined(USE_ANIMATION_COMPONENT_COUTDEV)
		if (BrFALSE == CheckAnimation(pAnimation, pLine))
			continue;
#endif  // USE_TEXTANIMATION_LETTERWORD_COUTDEV && USE_ANIMATION_COMPONENT_COUTDEV

		BrINT nLen = pLine->getCharNum();
		for (BrINT i = 0; i < nLen; i++) {
			CCharSet* pCharSet = pLine->getCharSet(i);
			if (pCharSet && pCharSet->isTextLink()) {
				//2015.4.17 Underline효과시 공백이 그려지지않는 부분 수정
				if (i != nLen - 1) {
					BoraDoc* document = theBWordDoc;
					BrINT nLineSp = CTextProc::CalcLineSpace(document, pLine, BrTRUE);
					CalcCharPosInFrame(text_bmp_info, pLine, i, nLineSp);

					BrINT nRet = MakeDIBFromText(painter, text_bmp_info, pLine, i, i + 1);
					if (nRet != 1) {
#ifdef USE_ANIMATION_COMPONENT
						DeleteDIB(text_bmp_info);
#endif//#ifdef USE_ANIMATION_COMPONENT
						return nRet;
					}
				}
				//if(!pCharSet->isWhiteCharacterLinkForFinding(BrTRUE))
				else {
					if (!pCharSet->isWhiteCharacterLinkForFinding(BrTRUE)) {
						CalcCharPosInFrame(text_bmp_info, pLine, i);
						BrINT nRet = MakeDIBFromText(painter, text_bmp_info, pLine, i, i + 1);
						if (nRet != 1) {
#ifdef USE_ANIMATION_COMPONENT
							DeleteDIB(text_bmp_info);
#endif//#ifdef USE_ANIMATION_COMPONENT
							return nRet;
						}
					}
				}
			}
		}
	}

	return 1;
}


BrINT CTextDraw::MakeDIBFromWord(Painter* painter, TEXTBITMAPINFO& text_bmp_info)
{
	CFrame* pFrame = text_bmp_info.pFrame;
	CLine* pLine = pFrame? pFrame->getFirstLine(): BrNULL;
	if (BrNULL == pLine)
		return 0;

#ifdef USE_ANIMATION_COMPONENT
	if (BrFALSE == CreateDIB(text_bmp_info))
		return kPoWarnMemoryAllocFailForSlideShow;
#endif//#ifdef USE_ANIMATION_COMPONENT

	//[2013.06.04][Dandong2] Animation에 속한 Line들만 Letter 나 Word Bitmap을 따낸다.
#if defined(USE_TEXTANIMATION_LETTERWORD_COUTDEV) && defined(USE_ANIMATION_COMPONENT_COUTDEV)
	ACTimeNode* pAnimation = text_bmp_info.pAni;
#endif  // USE_TEXTANIMATION_LETTERWORD_COUTDEV && USE_ANIMATION_COMPONENT_COUTDEV

	BrINT nSCol = 0, nECol = 0;
	BrBOOL bWordStart = BrFALSE;

	for (; pLine; pLine = pLine->getNext()) {
#if defined(USE_TEXTANIMATION_LETTERWORD_COUTDEV) && defined(USE_ANIMATION_COMPONENT_COUTDEV)
		if (BrFALSE == CheckAnimation(pAnimation, pLine))
			continue;
#endif  // USE_TEXTANIMATION_LETTERWORD_COUTDEV && USE_ANIMATION_COMPONENT_COUTDEV

		BrINT nLen = pLine->getCharNum();
		for (BrINT i = 0; i < nLen; i++) {
			CCharSet* pCharSet = pLine->getCharSet(i);
			if (pCharSet && pCharSet->isTextLink()) {
				if (pCharSet->isWhiteCharacterLinkForFinding(BrTRUE)) {
					if (bWordStart) {
						nECol = i;
						CalcCharPosInFrame(text_bmp_info, pLine, nSCol);

						BrINT nRet = MakeDIBFromText(painter, text_bmp_info, pLine, nSCol, nECol);
						if (nRet != 1) {
#ifdef USE_ANIMATION_COMPONENT
							DeleteDIB(text_bmp_info);
#endif//#ifdef USE_ANIMATION_COMPONENT
							return nRet;
						}

						bWordStart = BrFALSE;
					}
				}
				else {
					if (!bWordStart) {
						nSCol = i;
						bWordStart = BrTRUE;
					}
				}
			}
		}
		if (bWordStart) {
			if (pLine->isEndLine())
				nECol = nLen - 1;
			else
				nECol = nLen;

			CalcCharPosInFrame(text_bmp_info, pLine, nSCol);

			BrINT nRet = MakeDIBFromText(painter, text_bmp_info, pLine, nSCol, nECol);
			if (nRet != 1) {
#ifdef USE_ANIMATION_COMPONENT
				DeleteDIB(text_bmp_info);
#endif//#ifdef USE_ANIMATION_COMPONENT
				return nRet;
			}
		}
		bWordStart = BrFALSE;
	}
	return 1;
}


#if defined(USE_TEXTANIMATION_LETTERWORD_COUTDEV) && defined(USE_ANIMATION_COMPONENT_COUTDEV)
//[2013.06.04][Dandong2] Animation에 속한 Line들만 Letter 나 Word Bitmap을 따낸다.
BrBOOL CTextDraw::CheckAnimation(ACTimeNode* animation, CLine* line)
{
	if (BrNULL == animation)
		return BrTRUE;

	BrINT start_para_num = animation->getStartParaNum();
	if (line->getParaRangeNum() == start_para_num)
		return BrTRUE;

	ACTextElementType txt_element_type = animation->getTextElemnetType();
	if (txt_element_type != ACTextElementType_ParagraphTextRange)
		return BrTRUE;

	// MS에서 XML 값이 이렇게 설정되며, 매우 드문 케이스라 세세한 값까지 조건문으로 추가함
	if (-1 != start_para_num)
		return BrFALSE;

	// 하나의 개체로 && 단어 단위 && NOT attach Shape 인 텍스트 애니메이션 진행 고려
	ACBuildParagraph* build_para = animation->getBldParGraph();
	if (BrNULL == build_para || build_para->AnimateBg())
		return BrFALSE;
	ACParaBuildType build_type = build_para->Build();
	return (ACParaBuildType_none == build_type || ACParaBuildType_whole == build_type);
}
#endif  // USE_TEXTANIMATION_LETTERWORD_COUTDEV && USE_ANIMATION_COMPONENT_COUTDEV


BrBOOL CTextDraw::CalcCharPosInFrame(TEXTBITMAPINFO& text_bmp_info, CLine* pLine,
                                     BrINT nCol, BrINT nLineSp)
{
	if (!pLine) {
		return BrFALSE;
	}

	if (pLine->isDirty()) {
		CTextProc::arrangeMarkingLines(theBWordDoc, pLine, BrNULL);
	}

	CFrame* pFrame = pLine->getFrame();
	if (!pFrame) {
		return BrFALSE;
	}
	BrLONG nCharPointX = 0;
	BrLONG nCharPointY = 0;

	CLongArray& cPosArray = pLine->getPosArray();
	BrINT nLen = pLine->getCharSetArray()->size();
	if (!nLen) {
		return BrFALSE;
	}

	BrBYTE nTextFlow = text_bmp_info.pFrame->getTextFlow();
	if (nTextFlow == TEXTFLOW_GARO) {
		nCharPointX = cPosArray[nCol];
		nCharPointY = pLine->getBasePos() - pLine->getHeight();
		/*if (nLineSp != 0) {
		nCharPointY += nLineSp / 2;
		}*/
	}
	else // 텍스트방향이 세로 계열 일때
	{
		BRect rect = pFrame->getFrameRect();
		if (nTextFlow == TEXTFLOW_SERO_270) {
			nCharPointX = pLine->getBasePos() - pLine->getHeight();
			BrINT nLen = pLine->getCharSetArray()->size();
			if (nLineSp != 0) {
				nCharPointX -= nLineSp / 2;
			}
			// TODO : [WPD-3247] TEXTATTRIBUTE 를 갖고와 현재 속성에 따른 BOUNDERY(장평, 여백, 이텔릭 기타 등등),
			// CPosArray 의 좌표는 렌더를 시작하는 좌표 이기 때문에 근본적으로 수정하기 위해서는 FONT 의 WIDTH, HEIGHT 정보를 이용하여 재 계산해야함
			nCharPointY = rect.GetHeight() - cPosArray[nCol + 1];// + ;
		}
		else {
			nCharPointX = rect.GetWidth() - pLine->getBasePos();
			if (nLineSp != 0) {
				nCharPointX -= nLineSp / 2;
			}
			nCharPointY = cPosArray[nCol];
		}
	}

	BPoint pCharpoint(nCharPointX, nCharPointY);
	text_bmp_info.pPointArray->Add(pCharpoint);
	return BrTRUE;
}


BrINT CTextDraw::MakeDIBFromText(Painter* painter, TEXTBITMAPINFO& text_bmp_info,
                                 CLine* line, BrINT nSCol, BrINT nECol)
{
	if (BrNULL == line)
		return 0;

	CLongArray& cPosArray = line->getPosArray();
	if (0 == cPosArray.GetSize())
		return 0;

	BoraDoc* document = theBWordDoc;
	PoParaAttHandler* para_att_h = document->getParaAttHandler();
	const PoParaAtt* mergedParaAtt = para_att_h->getMergedParaAtt(line->getParaID(), line);

	BrBOOL bOldUseAlphaTextDraw = BrFALSE;

	BRect rcBound(0, 0, 0, 0);
	CDrawUnit unit;
	unit.setOrg(0, 0);
	unit.setDefaultOutputOption();
	unit.setFactor(g_pAppStatic->m_nResX, g_pAppStatic->m_nResY, painter->getZoomScale());

	BrBOOL bOldOnDraw = document->isOnDraw();
	document->setOnDraw(BrFALSE);

	BRDRAWCHARINFO stDrawCharInfo;
	BrDC* dc = painter->pDC;
	PrBitmap* pOldBitmap = dc->getBitmap();
	BrRect rcOldClipRect;
	dc->getClipRect(rcOldClipRect);
	BRect rcOldInvalidRect = document->getInvalidateRect();

	BrINT32 nDescent = CTextProc::getMaxDescentOfCurLine(document, line);
	if (text_bmp_info.nType == BITMAP_CHAR) {
		rcBound.nRight = cPosArray[nECol] - cPosArray[nSCol];
	}
	else {
		rcBound.nLeft = cPosArray[nSCol];
		rcBound.nRight = cPosArray[nECol];
	}

	const PoTextAtt* pTextAtt = BrNULL;
	CCharSet* pLink = line->getCharSet(nSCol);
	PoTextAttHandler* text_att_h = document->getTextAttHandler();
	if (pLink && text_att_h)
		pTextAtt = text_att_h->getTextAtt(pLink->getAttrID());

	rcBound.nBottom = line->getHeight() + mergedParaAtt->getLineSpace(line);

	// [POD-4790][2019-05-23] 애니메이션 비트맵을 생성 할때는 이텔릭 글자인경우 0.25 * line->getHeight() 가감하여서 bitmap 비트맵을 크게 뜨는데. 커닝이 고려되지 않는다.
	//  0.25 * line->getHeight() 왜 곱하는지는 모르겠으나, 오프스크린으로 비트맵을 뜨고 나중에 하나하나 GL 텍스처를 만들고 에서 렌더링시 알파블랜딩이 먹히지 않는 문제가 있다.
	BrBOOL isSlideShow = document->getCmdEngine()->isSlideShow();
	if (BrFALSE == isSlideShow) {
		if (pTextAtt && pTextAtt->getItalic()) {
			if (text_bmp_info.nType == BITMAP_CHAR) {
				rcBound.nRight += 0.25 * line->getHeight();
			}
			else {
				pTextAtt = text_att_h->getTextAtt(line->getCharSet(nECol - 1)->getAttrID());
				if (pTextAtt && pTextAtt->getItalic())
					rcBound.nRight += 0.25 * line->getHeight();// (cPosArray[nECol] - cPosArray[nECol-1]);
			}
		}
	}

	// [XPD-18753][2019.04.18] 슬라이드쇼의 경우 슬라이드 쇼용 비트맵을 생성하고 쇼가 종료되면 모든 텍스쳐를 CLEAR 함
	if (pTextAtt && pTextAtt->isWordArtStyle()) {
		if (line->getWordArtBitmapArray() && line->getWordArtBitmapArray()->GetSize() > 0) {
			line->clearBitmapCache();
			line->getFrame()->clearBitmapCache();
		}
	}

	unit.doc2Logical(rcBound, false);

	BrBOOL bCreated = BrFALSE;
	PrBitmap* pDstBitmap = BrNEW PrBitmap();

	// getShapeBound에서 사용하는 DC bound의 특성상, Device 좌표로 변환된,
	// bound 영역에대한 정보는 [First, Last)로 getWidth(), getHeight()로 얻어야한다.
	if (text_bmp_info.pFrame->getTextFlow() == TEXTFLOW_GARO)
		bCreated = pDstBitmap->createBitmap(rcBound.getWidth(), rcBound.getHeight() + nDescent);
	else
		bCreated = pDstBitmap->createBitmap(rcBound.getHeight() + nDescent, rcBound.getWidth() + nDescent);

	if (!bCreated) {
		if (pDstBitmap && pDstBitmap->getImgState() == eMemoryErr) {
			BR_SAFE_DELETE(pDstBitmap);
			return kPoWarnMemoryAllocFailForSlideShow;
		}
		else {
			BR_SAFE_DELETE(pDstBitmap);
			return 0;
		}
	}

	//pDstBitmap->fill(tColor);
	dc->setBitmap(pDstBitmap);
	dc->setClipRect(BrNULL);
	document->InvalidateRect(BrNULL);
	dc->enableAlphaBitmapDC(BrTRUE);

	BrBYTE bTextFlow = text_bmp_info.pFrame->getTextFlow();
	if (text_bmp_info.nType == BITMAP_CHAR) {
		pLink = line->getCharSet(nSCol);
		if (pLink) {
			pTextAtt = document->getTextAttHandler()->getTextAtt(pLink->getAttrID());

			memset(&stDrawCharInfo, 0, BrSizeOf(BRDRAWCHARINFO));
			stDrawCharInfo.pDC = dc;
			stDrawCharInfo.nLineHgt = rcBound.nBottom;
			stDrawCharInfo.nDescent = CTextProc::getMaxDescentOfCurLine(document, line);

			if (bTextFlow != TEXTFLOW_GARO) {
				if (bTextFlow == TEXTFLOW_SERO_270) {
					// TODO :: rot 고려 해야함
					//stDrawCharInfo.sx = rcBound.Bottom() - stDrawCharInfo.nDescent;
					stDrawCharInfo.sy = unit.doc2LogicalDY(rcBound.nRight) + stDrawCharInfo.nDescent;
				}
				else
					stDrawCharInfo.sy = unit.doc2LogicalDY(rcBound.nRight);
			}
			else {
				stDrawCharInfo.sy = unit.doc2LogicalDY(line->getHeight()) + stDrawCharInfo.nDescent;
			}

			stDrawCharInfo.nFlag = 0;
			stDrawCharInfo.bBidiPara = BrFALSE;

			//[WPD-5152][minseob] Col 값을 전달해주지 않아 0으로 설정되어 조합된 문자의 경우 첫번째 문자로 보여짐
			stDrawCharInfo.nCol = nSCol;

			bOldUseAlphaTextDraw = dc->setUseAlphaValueforDrawText(BrTRUE);
			if (bTextFlow != TEXTFLOW_GARO) {
				DrawSeroCharSet(unit, stDrawCharInfo, text_bmp_info.pFrame, pLink, pTextAtt, line, painter);
			}
			else {
				DrawGaroCharSet(unit, stDrawCharInfo, pLink, pTextAtt, line, BrFALSE, BrTRUE, painter);	// PIE-1295
			}

#if defined(WIN32) && defined(DEBUG)
			DumpImage(pDstBitmap->getDib(), stDrawCharInfo.sx, stDrawCharInfo.sy, 0);
#endif
		}
	}
	else {
		BrINT32 nDescent = CTextProc::getMaxDescentOfCurLine(document, line);
		BrINT32 sx = 0;
		BrINT32 sy = 0;

		if (bTextFlow != TEXTFLOW_GARO) {
			if (bTextFlow == TEXTFLOW_SERO_270) {
				sx = rcBound.Bottom() - nDescent;
				sy = unit.doc2LogicalDY((BrINT32)(cPosArray[nECol])) + nDescent;
			}
			else {
				sx = nDescent;
				sy = unit.doc2LogicalDY((BrINT32)(cPosArray[nECol]));
			}
		}
		else {
			sx = unit.doc2LogicalDX(cPosArray[nSCol]);
			sy = unit.doc2LogicalDY(line->getHeight()) + nDescent;
		}

		bOldUseAlphaTextDraw = dc->setUseAlphaValueforDrawText(BrTRUE);
		if (bTextFlow != TEXTFLOW_GARO)
			DrawSeroOneLine(painter, dc, unit, text_bmp_info.pFrame, line, sx, sy, rcBound.nBottom, 1, nSCol, nECol);
		else {
			DrawGaroOneLine(painter, dc, unit, text_bmp_info.pFrame, line, 0, sy, rcBound.nRight, 1, nDescent, *mergedParaAtt, nSCol, nECol);
		}

		stDrawCharInfo.nFlag = 0;
		stDrawCharInfo.bBidiPara = BrFALSE;
	}

	BrINT nDiff = 0;
	for (BrINT i = nSCol; i < nECol; i++) {
		if (text_bmp_info.nType == BITMAP_WORD) {
			if (mergedParaAtt->getAlign() != RIGHT && mergedParaAtt->getAlign() != CENTER) {
				if (nSCol == 0) {
					rcBound.nLeft = cPosArray[i];
					rcBound.nRight = cPosArray[i + 1];
				}
				else {
					rcBound.nLeft = nDiff;
					rcBound.nRight = nDiff + cPosArray[i + 1] - cPosArray[i];
					nDiff = rcBound.nRight;
				}
			}
			else {
				if (nSCol == 0) {
					rcBound.nLeft = cPosArray[i] - cPosArray[0];
					rcBound.nRight = cPosArray[i + 1] - cPosArray[0];
				}
				else {
					rcBound.nLeft = nDiff;
					rcBound.nRight = nDiff + cPosArray[i + 1] - cPosArray[i];
				}
				nDiff = rcBound.nRight;
			}
		}

		pLink = line->getCharSet(i);
		if (pLink) {
			pTextAtt = text_att_h->getTextAtt(pLink->getAttrID());

			memset(&stDrawCharInfo, 0, BrSizeOf(BRDRAWCHARINFO));

			if (pTextAtt && pTextAtt->getItalic()) {
				if (text_bmp_info.nType == BITMAP_CHAR) {
					rcBound.nRight += 0.25 * line->getHeight();
				}
				else {
					pTextAtt = text_att_h->getTextAtt(line->getCharSet(nECol - 1)->getAttrID());
					if (pTextAtt->getItalic())
						rcBound.nRight += 0.25 * line->getHeight();//(unit.doc2LogicalDX(cPosArray[nECol] - cPosArray[nECol-1]) * 0.5);
				}
			}
		}

		stDrawCharInfo.nLineHgt = rcBound.nBottom;
		stDrawCharInfo.nDescent = CTextProc::getMaxDescentOfCurLine(document, line);

		if (bTextFlow != TEXTFLOW_GARO) {
			if (bTextFlow == TEXTFLOW_SERO_270) {
				stDrawCharInfo.sx = rcBound.Bottom() - stDrawCharInfo.nDescent;
				stDrawCharInfo.sy = unit.doc2LogicalDY(rcBound.nRight) + stDrawCharInfo.nDescent;
			}
			else
				stDrawCharInfo.sy = unit.doc2LogicalDY(rcBound.nRight);
		}
		else
			stDrawCharInfo.sy = unit.doc2LogicalDY(line->getHeight()) + stDrawCharInfo.nDescent;

		BrBOOL bUnderLine = pTextAtt && pTextAtt->getUnderline();
		BrBOOL bHyperlinkLine = pLink && !CTextProc::isCRCode(pLink->getCode()) && pLink->isTextLink()
			&& !line->isHyperLastSpaceInLine(nSCol) && document->isFromSlideType() && IsHyperlinkColorNode(document, line, nSCol);

		if (isSlideShow && pLink && pLink->isBulletLink())
			bUnderLine = BrFALSE;

		//underline
		if (bUnderLine || bHyperlinkLine) {
			BrINT lOneWidth = rcBound.GetWidth();
			BrINT lOneHeight = stDrawCharInfo.nLineHgt;
			BrINT dy = stDrawCharInfo.sy;
			BrINT dx = rcBound.nLeft;
			BrINT nUnderlineY = dy;
			BrINT nSx = 0, nDx = 0, nSy = 0, nDy = 0;

			if (bTextFlow == TEXTFLOW_GARO) { //글자의 아래에 Underline을 그려줌
				dy -= stDrawCharInfo.nDescent / 3;
			}
			else if (bTextFlow == TEXTFLOW_GARO_ROTATE) { //글자의 위에 Underline을 그려줌
				dy -= lOneHeight;
				nUnderlineY -= lOneHeight;
			}

			nSx = dx;
			nDx = dx + lOneWidth;

			nSy = nDy = nUnderlineY;

			if (bTextFlow == TEXTFLOW_SERO || bTextFlow == TEXTFLOW_SERO_270) {
				nSy = 0;
				nSx = nDx = nDy = lOneHeight;
			}
			else if (bTextFlow == TEXTFLOW_SERO_90) {
				nSy = nSx = 0;
				nDx = 1;
				nDy = lOneHeight;
			}

			BrINT32 dwUnderlineColor;
			if (bHyperlinkLine) {
				dwUnderlineColor = document->m_pTheme->getHlinkColor();
			}
			else {
				BrINT32 dwColor = pTextAtt->getReverse()? BrRGB2BGR(pTextAtt->getBackColor().getColor()):
				                                          BrRGB2BGR(pTextAtt->getTextColor().getColor());
				dwUnderlineColor = (pTextAtt->getUnderlineColor().getColor() != NONE_COLOR_BITS)?
				                                 pTextAtt->getUnderlineColor().getColor():
				                                 dwColor;
			}

			DrawNormalUnderline(dc, nSx, nSy, nDx, nDy, lOneHeight / 20, dwUnderlineColor,
			                    pTextAtt, line, stDrawCharInfo.nLineHgt);
		}
	}

	dc->setUseAlphaValueforDrawText(bOldUseAlphaTextDraw);
	text_bmp_info.pBitMapArray->Add(pDstBitmap);

#ifdef USE_TEXTANIMATION_LETTERWORD_COUTDEV
	//letter나 word의 CLine과 CharSet정보 얻기
	BrWORDINFO* info = (BrWORDINFO*)BrMalloc(BrSizeOf(BrWORDINFO));
	if (info) {
		info->m_pLine = line;
		info->m_nECol = nECol;
		info->m_nSCol = nSCol;
	}
	text_bmp_info.pCharSetInfoArray->Add(info);
#endif
#if defined(WIN32) && defined(DEBUG)
	DumpImage(pDstBitmap->getDib(), sx, sy, 0);
#endif

	g_pAppStatic->bProtectUndo = BrFALSE;
	dc->setBitmap(pOldBitmap);
	dc->setClipRect(&rcOldClipRect);
	document->setOnDraw(bOldOnDraw);
	document->setInvalidateRect(&rcOldInvalidRect);

	return 1;
}


//[2013.06.28][TextAnimation][LetterWordEffect] support to rotate text bitmap
BrBOOL CTextDraw::RotateDIBWithAngle(Painter* painter, CFrame* pFrame, TEXTBITMAPINFO& text_bmp_info,
                                     BrBOOL isLetterWordUnit, BrINT fAngle)
{
	BrBOOL bRet = BrFALSE;
	if (!pFrame)
		return bRet;

	BrINT nAngle = 0;
	if (pFrame)
		nAngle = pFrame->GetRotation();

	if (isLetterWordUnit)
		nAngle = fAngle;

	if (nAngle) {
		if (pFrame->getFlip())
			nAngle += 180;

		BPtrArray* pBitmapArray = BrNULL;
		BPointArray* pPointArray = BrNULL;
		PrBitmap* bitmap = BrNULL;

		pBitmapArray = text_bmp_info.pBitMapArray;
		pPointArray = text_bmp_info.pPointArray;

		if (pBitmapArray && pBitmapArray->count() > 0) {
			for (BrINT chIndex = 0; chIndex < pBitmapArray->count(); chIndex++) {
				bitmap = (PrBitmap*)pBitmapArray->GetAt(chIndex);

				if (bitmap == BrNULL)
					continue;

				if (pPointArray && pPointArray->count() > chIndex) {
					CDrawUnit unit;
					unit.setOrg(0, 0);
					unit.setDefaultOutputOption();
					unit.setFactor(g_pAppStatic->m_nResX, g_pAppStatic->m_nResY, painter->getZoomScale());

					BPoint* pos = pPointArray->GetAt(chIndex);
					BPoint tPos(pos->x, pos->y);

					BrINT bw = bitmap->cx(), bh = bitmap->cy();
					BRect rectFrame = pFrame->getFrameRect();
					BRect rectOrg = pFrame->getFrameRect();
					// convert line_frame to local
					unit.doc2Logical(rectFrame, BrFALSE);
					unit.doc2Logical(rectOrg, BrFALSE);

					BRect rect(tPos.x, tPos.y, tPos.x + bw, tPos.y + bh);

					if (isLetterWordUnit) {
						rectFrame = rect;
						rectOrg = rect;
					}

					BrINT nXTopLeft = 0, nYTopLeft = 0;
					BrINT nXTopRight = 0, nYTopRight = 0;
					BrINT nXBottomRight = 0, nYBottomRight = 0;
					BrINT nXBottomLeft = 0, nYBottomLeft = 0;

					CDrawUnit::rotateRectangle(nAngle, rectFrame.Center().getX(), rectFrame.Center().getY(),
					                           rect, nXTopLeft, nYTopLeft, nXTopRight, nYTopRight,
					                           nXBottomLeft, nYBottomLeft, nXBottomRight, nYBottomRight);
					BrINT XMin = nXTopLeft;
					BrINT YMin = nYTopLeft;

					// construct a new rect
					// min x
					XMin = XMin > nXTopRight ? nXTopRight : XMin;
					XMin = XMin > nXBottomLeft ? nXBottomLeft : XMin;
					XMin = XMin > nXBottomRight ? nXBottomRight : XMin;

					// min y
					YMin = YMin > nYTopRight ? nYTopRight : YMin;
					YMin = YMin > nYBottomLeft ? nYBottomLeft : YMin;
					YMin = YMin > nYBottomRight ? nYBottomRight : YMin;

					// rotate bitmap
					PrBitmap* pNew = PrBitmap::rotate(bitmap, nAngle);
					if (pNew) {
						bitmap->copyBitmap(pNew);
						BR_SAFE_DELETE(pNew);
					}

					//DumpImage(bitmap->getDib(), XMin, YMin, 0);
// 					pos->x = CDrawUnit::cvtLogical2DocX(XMin,g_pAppStatic->m_nResX,painter->getZoomScale()) - rectOrg.getX();
// 					pos->y = CDrawUnit::cvtLogical2DocY(YMin,g_pAppStatic->m_nResY,painter->getZoomScale()) - rectOrg.getY();
					pos->x = XMin;
					pos->y = YMin;
				}
			}
		}
	}
	return bRet;
}


//[2013.08.21][TextAnimation][LetterWordEffect] add a function for transparency.
BrBOOL CTextDraw::TranspDIBWithScale(Painter* painter, CFrame* pFrame, TEXTBITMAPINFO& text_bmp_info,
                                     BrFLOAT fTransparency)
{
	BPtrArray* pBitmapArray = text_bmp_info.pBitMapArray;
	if (pBitmapArray && pBitmapArray->count() > 0) {
		for (BrINT chIndex = 0; chIndex < pBitmapArray->count(); chIndex++) {
			PrBitmap* bitmap = (PrBitmap*)pBitmapArray->GetAt(chIndex);
			if (bitmap == BrNULL)
				continue;
			bitmap->setTransparency(fTransparency);
		}
	}
	return BrTRUE;
}


//[2013.08.16][TextAnimation] scale bitmap array and calculate pos.
BrBOOL CTextDraw::ScaleDIBWithScale(Painter* painter, CFrame* pFrame, TEXTBITMAPINFO& text_bmp_info,
                                    BrFLOAT fscaleX, BrFLOAT fscaleY)
{
	BrBOOL bRet = BrFALSE;
	if (fscaleX <= 0)
		fscaleX = 1.f;

	if (fscaleY <= 0)
		fscaleY = 1.f;

	if (fscaleX == 1.f && fscaleY == 1.f)
		return bRet;

	BPtrArray* pBitmapArray = text_bmp_info.pBitMapArray;
	BPointArray* pPointArray = text_bmp_info.pPointArray;
	if (pBitmapArray && pBitmapArray->count() > 0) {
		for (BrINT chIndex = 0; chIndex < pBitmapArray->count(); chIndex++) {
			BrFLOAT orgW = 0.f, orgH = 0.f;

			PrBitmap* bitmap = (PrBitmap*)pBitmapArray->GetAt(chIndex);
			if (bitmap == BrNULL)
				continue;

			orgW = bitmap->cx();
			orgH = bitmap->cy();
			bitmap->scale(orgW * fscaleX, orgH * fscaleY);

			if (pPointArray && pPointArray->count() > chIndex) {
				BrFLOAT dx = orgW * (fscaleX - 1), dy = orgH * (fscaleY - 1);
				BPoint* pos = pPointArray->GetAt(chIndex);

				pos->x -= dx / 2;
				pos->y -= dy / 2;
			}
		}
	}
	return bRet;
}


#endif  // BWP_EDITOR
