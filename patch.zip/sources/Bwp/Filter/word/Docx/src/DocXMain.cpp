// DocXMain.cpp: implementation of the CDocXMain class.
//
//////////////////////////////////////////////////////////////////////
#include <word_filter_PCH.hpp>

#ifdef IMPORT_DOCX

//#include "DocxUnzip.h"
#include "DocXMain.h"
#include "DocxConv.h"
#include "DocxWriter_TC.h"

#include "packageBase.h" 

// [2012.05.07][TID:6132][������] - Chart Export
#include "bwChart.h"
#include "shtChartFuncApi.h"
#include "shtFilterChartFuncApi.h"

#include "cmnFunc.h"

#ifdef XML_ENCRYPTOR
#include "OfficeCrypto/OfficeCryptoCommon/EncryptorContainer.h"
#include "OfficeCrypto/OfficeCryptoCommon/DecryptorContainer.h"
#endif

#include "DocxLoader.h"
#include "ThreadDefines_i.h"
#include "brutil.h"
#include "post_threadapp_property.h"
#include "WordCommon/DataType/SimpleValueGroup.h"
#include "WordCommon/DataType/SimpleType.h"
#include "PrimitiveType/PrimitiveTypeTemplete.h"

/////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CDocXMain::CDocXMain(BoraPackageBase* a_pPackage)
{
	m_pDocxLoader = NULL;
	m_pDocxConv = NULL;
	m_bFirstRead = BrTRUE;

	m_pPackage = a_pPackage;
	//[2011.09.26][�����][TID:239] callbackparam �ʱ�ȭ
	memset(&param, 0, BrSizeOf(CallbackParam));
}

CDocXMain::~CDocXMain()
{
	if( m_pDocxLoader )
		BrDELETE m_pDocxLoader;

	if( m_pDocxConv )
		BrDELETE m_pDocxConv;

	m_pPackage = BrNULL;
}

BrBOOL CDocXMain::doImportDocX(BString &InFile, BrINT16 & iRefNum, BrINT32 nPgNum)
{
	BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);		
	
	BrBOOL bRet = BrTRUE;

	if( m_bFirstRead )
	{
		BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);		
		//readNormalDotm();
		m_bFirstRead = BrFALSE;

		memset(&param, 0, BrSizeOf(CallbackParam));
		BrINT32 fileType = m_pPackage->getInternalFileType(&param);
BTrace("%s(%d) %s fileType[%d]", __FILE__, __LINE__, __FUNCTION__, fileType);		

		if( BORA_DOCTYPE_DOCX != fileType) {
		BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);		
			PoError nErrorCode = kPoErrCorruptFile;

			if (BORA_DOCTYPE_STRICT == fileType)
				nErrorCode = kPoErrStrictOpenXML;

			theBWordDoc->SetErrorCode(nErrorCode);
			ERR_TRACE(nErrorCode);
			return BrFALSE;
		}

		m_pDocxLoader = BrNEW CDocxLoader();
		m_pDocxConv = BrNEW CDocxConv();
		m_pDocxConv->setDocxLoader(m_pDocxLoader);
		m_pDocxConv->m_nReadPgNum = nPgNum;
		m_pDocxLoader->setDocxConv(m_pDocxConv, &param);
		param.pCurrentInstance = m_pDocxConv;
		m_pDocxLoader->m_pPackage = m_pPackage;
		m_pDocxConv->m_pPackage = m_pPackage;
BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);		
		bRet = m_pDocxLoader->OpenDocumentXML(&param);	
		if( bRet )		
		{BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);		
			bRet = m_pDocxConv->convertDocxToBwp(&param);
		}

#ifdef  SUPPORT_MULTICORE 
		BrSetEnableMCoreXSave(BrFALSE);
#endif
	}
	else
	{
		m_pDocxConv->m_nReadPgNum = nPgNum;
		bRet = m_pDocxConv->convertDocxToBwp(&param);
	}

	if( theBWordDoc->isFinishLoading() ) 
	{
#ifdef B_DEBUG
		ShowErrorTrace();
#endif // B_DEBUG
		BoraPackageBase::EndXmlParser(m_pDocxConv);
	}

	if(!g_pErrorHandler->CanContinue())
		bRet = BrFALSE;

	return bRet;
}
#endif //#ifdef DOCX_IMPORT
#include "OfficeCrypto/OfficeCryptoContainer.h"
#include "OfficeCrypto/DocumentProtector/OOXMLWriteProtector.h"
#ifdef FOR_DOCX_EXPORT
#include "msdrawsave.h"
BrBOOL CDocXMain::convertBwptoDocx(BString &docName, BrLPVOID pEvent)
{
	BRTHREAD_LEAK_CHECKER(1);
//BRTHREAD_DETECT_MEM_CORRUPTION;
	INCREASE_PROGRESS(1);
	CANCEL_LOAD_RETURN_INT_EX1;

	theBWordDoc->SetErrorCode(kPoProcessSucess);
	BrBOOL bRet = BrTRUE;
//	BString docBackName(docName);
//	docBackName.append(".qbk");
	BString docBackName = CUtil::getBackupFilePathInTempPath(docName);
	BrAutoChar temp = CUtil::convertBStringToChar(&docBackName, CP_UTF8);
	BrGetPublicZipHandle((BrCHAR*)temp.get(), BrNULL, BrNULL);
	PO_THREAD_TRY_BLOCK {
		BDataStream *pAr = BrNULL;
		// Terminate�ÿ� ����� callback �� ���
		BrBaseEventType BaseEvent = {0};
		CSaveTerminateCallBack* pCallBack = BrNEW CSaveTerminateCallBack(*((LPBrBaseEventType)pEvent), EDITOR_WORD);
		BrThreadAddTermCallBack( Brcontext, pCallBack );

		BrBOOL bChanged = BrFALSE;
		
#ifdef USE_COLLABORATION
		if(BrGetCollaborationMode() == BR_COLLABORATION_COLLABORATION_MODE)
			theBWordDoc->setModifiedFlag(BrTRUE);
#endif //USE_COLLABORATION
		if( theBWordDoc->IsModified() || g_bIsSetDstZipPassword ) {
			bChanged = BrTRUE;
		}
		else {//�������� ���� ���� - Save As
			if( 0 == docName.compare(theBWordDoc->GetPathName()) ) //��������
				goto DOCXSAVEEND;
			else if(theBWordDoc->getWriteProtect() && theBWordDoc->getDocumentWriteProtector()->isVerified() == BrFALSE) //���� ��ȣ �����ε�, �б� ���� �����Ͽ� password�� �𸣴°��
			{
				bChanged = BrTRUE;
			}
			else {
				if( BORA_DOCTYPE_DOCX == theBWordDoc->getDocType() && !theBWordDoc->isCreatedNewDoc() )
					bChanged = BrFALSE;
				else
					bChanged = BrTRUE;
			}
		}

		if( !bChanged && !theBWordDoc->isSavedDocument() )
		{
			//[2012.09.24][�����] ���� ���� ���� �� ZipHandler Release �� �����ؾ� Rename�� ���������� �ȴ�
			BrReleasePublicZipHandle();
			bRet = BrUtil::copyOrgFile(theBWordDoc->GetPathName(), docName, docBackName);
			if(!bRet)
				SetErrorFReturn(CFilterError(kPoErrCopyOrgFile));
		}
		else {
			theBWordDoc->setSavedDocument();
			CDocxWriter_TC *pDocxWriter = BrNEW CDocxWriter_TC();

			PO_THREAD_TRY_BLOCK {
				if( !pDocxWriter )
				{
					theBWordDoc->SetErrorCode(kPoErrMemory);
					ERR_TRACE(kPoErrMemory);	
					return BrFALSE;
				}
				pDocxWriter->m_strSaveDir = CUtil::UTF8ToBString((BrCHAR*)BrGetTempPath());
				//if( pDocxWriter->m_strSaveDir.findRev('/') != pDocxWriter->m_strSaveDir.length()-1)
				//	pDocxWriter->m_strSaveDir.append('/');

				bRet = pDocxWriter->convertBwpData(docName);

				if( bRet )
				{	
					//[2012.05.07][TID:6132][������]docx Chart Export
					bRet = createChart(pDocxWriter->m_pPackage, pEvent, &(pDocxWriter->m_CreatedChartFrameList));
					BrBOOL bCheckPassword = BrFALSE;
#ifdef XML_ENCRYPTOR
					if(theBWordDoc->getPasswordDoc()) {
						//Converting encrypted odt to docx is not supported.
						if ( getDocType() != BORA_DOCTYPE_ODT )
							bCheckPassword = BrTRUE;
					}
#endif
					if( bRet)
						bRet = pDocxWriter->serialize(docBackName, docName, pEvent, EDITOR_WORD, bCheckPassword);
				}

				if( !bRet ) {
#ifdef SUPPORT_MULTICORE
					// [2016.5.13][dhlee1223][XPD-1372] ���� ������ ����ó�� ��, BrReleasePublicZipHandle ȣ���ϱ� ���� �ݵ�� ��Ƽ�ھ� �����带 ���� ��������� ��
					BrWaitEndMultiCoreImp(BrTRUE);
					if(g_pMCoreImp)
					{
						g_pMCoreImp->removeMemZipList();
						g_pMCoreImp->setXSaveErrorCode(BrFALSE);
					}
#endif //#ifdef SUPPORT_MULTICORE
					BrReleasePublicZipHandle();
					//���� ���н� ������ ���� �������� ����
//					BFile::Remove(docBackName);
					if(theBWordDoc->GetErrorCode() == kPoProcessSucess)
						SET_ERROR((PoError)kPoErrFileWrite, "");
				}

				if(bRet == BrFALSE)
				{
					SET_ERROR((PoError)kPoErrFileWrite, "");
					BR_SAFE_DELETE(pDocxWriter);
					return BrFALSE;
				}

				BrDELETE pDocxWriter;
				pDocxWriter = BrNULL;
			} PO_THREAD_CATCH_BLOCK { 
				if( pDocxWriter ) {
					BrDELETE pDocxWriter;
					pDocxWriter = BrNULL;
				}
			} PO_THREAD_END
		}

	} PO_THREAD_CATCH_BLOCK { 
		BrReleasePublicZipHandle();
//		BFile::Remove(docBackName);
		br_destruct_obj(docBackName);
		if( kPoProcessSucess == theBWordDoc->GetErrorCode() )
		{
			theBWordDoc->SetErrorCode(kPoErrMemory);
			ERR_TRACE(kPoErrMemory);
		}
#if defined(BRTHREAD_MEMORY_DEBUG) && defined(RENDERING_WITH_BORATHREAD)
	//	br_destruct_obj(BrLeakchecker);
#endif
		g_BoraThreadAtom.m_nSaveStatus = SAVE_STATUS_END;
	} PO_THREAD_END

DOCXSAVEEND:
#ifdef B_DEBUG
	ShowErrorTrace();
#endif // B_DEBUG

//BRTHREAD_DETECT_MEM_CORRUPTION;
	if(bRet == BrFALSE)
		BrWaitEndMultiCoreImp(BrTRUE);
	BrReleasePublicZipHandle();
INCREASE_PROGRESS(1);
	return bRet;
}

BrBOOL	CDocXMain::createChart(CBrXmlPackage* a_pPackage, BrLPVOID a_pEvent, BArray<CFrame*>* a_pCreatedChartFrameList)
{
	if(!a_pPackage || !a_pCreatedChartFrameList || a_pCreatedChartFrameList->size() <= 0)
		return BrTRUE;

	const int nSheetFileNameLength = 60;
	const int nSheetSaveFileNameLength = 40;
	const int nXmlFileNameLength = 30;
	const int nXmlSaveFileNameLength = 20;

	BrCHAR pChartXmlFileName[nXmlFileNameLength] = {0,};
	BrCHAR pChartXmlSaveFileName[nXmlSaveFileNameLength] = {0,};
	BrCHAR pSheetFileName[nSheetFileNameLength] = {0,};	//[2013-03-01]
	BrCHAR pSheetSaveFileName[nSheetSaveFileNameLength] = {0,};
// 	BrCHAR pChartXmlRelFileName[40] = {0,};
// 	BrCHAR pChartXmlRelSaveFileName[20] = {0,};
	BString *strTempSheetFileName = BrNULL;

	// [COutDev][2015-11-18] - Doc/Slide���� Chart������ Image�� �ߺ���������
	BHANDLE_CXLSXRELATIONSHIPMANAGER_TC pChartImageRelManager = poChart_CXlsxRelationShipManager_TC_BrNew_init();
	
	for(BrUINT32 nChartIndex = 0; nChartIndex < a_pCreatedChartFrameList->size(); nChartIndex++)
	{
		CBWPChart *pChartFrame = (CBWPChart*)a_pCreatedChartFrameList->at(nChartIndex);

		memset(pChartXmlFileName, 0, BrSizeOf(pChartXmlFileName));
		memset(pChartXmlSaveFileName, 0, BrSizeOf(pChartXmlSaveFileName));
		memset(pSheetFileName, 0, BrSizeOf(pSheetFileName));
		memset(pSheetSaveFileName, 0, BrSizeOf(pSheetSaveFileName));
		// 		memset(pChartXmlRelFileName, 0, BrSizeOf(BrCHAR) * 40);
		// 		memset(pChartXmlRelSaveFileName, 0, BrSizeOf(BrCHAR) * 20);

		//chart.xml
		// OLE ���ϰ� �ߺ� ������ �ּҰ����� ó��
		int nRelNum = BrVTINT(pChartFrame);
		if (pChartFrame->isChartEx())
		{
			BString strPartName = pChartFrame->getOrgChartPartName();
			sprintf_s(pChartXmlFileName, BrSizeOf(pChartXmlFileName), "%s", strPartName.data());
			sprintf_s(pChartXmlSaveFileName, BrSizeOf(pChartXmlSaveFileName), "chartEx%d.xml", nChartIndex + 1);

			BString strOrgFileName = a_pPackage->getPackage()->GetEmbedOrgFileName(pChartXmlFileName, EMBED_PACKAGE_PART_TYPE);
			sprintf_s(pSheetFileName, BrSizeOf(pSheetFileName), "word/embeddings/%s", strOrgFileName.data());
			sprintf_s(pSheetSaveFileName, BrSizeOf(pSheetSaveFileName), "%s", strOrgFileName.data());
		}
		else
		{
			sprintf_s(pChartXmlFileName, BrSizeOf(pChartXmlFileName), "word/charts/chart%d.xml", nChartIndex + 1);
			sprintf_s(pChartXmlSaveFileName, BrSizeOf(pChartXmlSaveFileName), "chart%d.xml", nChartIndex + 1);

			sprintf_s(pSheetFileName, BrSizeOf(pSheetFileName), "word/embeddings/Polaris_Office_Excel_____%d.xlsx", nRelNum);
			sprintf_s(pSheetSaveFileName, BrSizeOf(pSheetSaveFileName), "Polaris_Office_Excel_____%d.xlsx", nRelNum);
		}
		bool bHasDataSheet = pChartFrame->HasEmbedSheet();
		if(!poSaveChartXml(a_pPackage, pChartFrame->getShapeChart(), a_pEvent, pChartXmlFileName, nChartIndex + 1, nRelNum, bHasDataSheet, pChartImageRelManager))
		{
			theBWordDoc->SetErrorCode(kPoErrFileWrite);
			ERR_TRACE(kPoErrFileWrite);
			return BrFALSE;
		}
		// DataSheet �� �������� ������ �������� ����
		if(bHasDataSheet == false)
			continue;

		strTempSheetFileName = BrNEW BString(CUtil::UTF8ToBString((BrCHAR*)BrGetTempPath()));
		strTempSheetFileName->append("exceltemp/");
		BrAutoChar temp = CUtil::convertBStringToChar(strTempSheetFileName, CP_UTF8);
		BrMakeDirectory((char*)temp.get());
		strTempSheetFileName->append(pSheetSaveFileName);

#ifndef NOT_USE_GLOBAL_VARIABLE
		extern BrBOOL g_bIsEmZip;
#endif //!NOT_USE_GLOBAL_VARIABLE
		g_bIsEmZip = BrTRUE;

		BrAutoChar temp2 = CUtil::convertBStringToChar(strTempSheetFileName, CP_UTF8);
		if(!pChartFrame->SaveEmbedSheet(a_pEvent, (BrCHAR*)temp2.get(), pSheetSaveFileName))
		{
			BR_SAFE_DELETE(strTempSheetFileName);
			theBWordDoc->SetErrorCode(kPoErrFileWrite);
			ERR_TRACE(kPoErrFileWrite);
			return BrFALSE;
		}
		g_bIsEmZip = BrFALSE;
		a_pPackage->addOneFilePackage(pSheetFileName, strTempSheetFileName);
		BrBOOL bRet = a_pPackage->closePackage(BrTRUE);
		if(!bRet)
			SetErrorFReturn(CFilterError(kPoErrFileWrite));
	}

	// [COutDev][2015-11-18] - Doc/Slide���� Chart������ Image�� �ߺ���������
	poChart_BR_SAFE_DELETE(pChartImageRelManager, eBHANDLE_CXLSXRELATIONSHIPMANAGER_TC);

	return BrTRUE;
}

BrBOOL CDocXMain::readNormalDotm()
{
	// AppData\Roaming\Microsoft\Templates ��θ� ui�κ��� �޾ƾ� ��
	BString dotmFilePath = g_pBInterfaceHandle->getMSTemplatePath();
	dotmFilePath += "//normal.dotm";
	if (BFile::Exist(dotmFilePath) == BrFALSE)
		return BrTRUE;

	BoraPackageBase packageBase;
	packageBase.InitPackage(dotmFilePath);
	CallbackParam	param;
	memset(&param, 0, BrSizeOf(CallbackParam));
	CDocxLoader normalLoader;
	CDocxConv normalConv;
	normalConv.setDocxLoader(&normalLoader);
	normalLoader.setDocxConv(&normalConv, &param);
	normalLoader.m_pPackage = &packageBase;
	normalConv.m_pPackage = &packageBase;
	CDocxStyleAtt docxStyle(&normalLoader);
	normalLoader.m_nCurDoingType = DOCX_STYLES;
	param.pCurrentInstance = &normalLoader;
	param.wParam = DOCX_STYLES;
	packageBase.ReadPart(&param, CORE_DOCUMENT_PART_TYPE, STYLES_PART_TYPE);
	theBWordDoc->makeNormalDotmStyleArray();
	normalLoader.createStyleAttArray(theBWordDoc->getNormalDotmStyleAttArray());

	return BrTRUE;
}


#endif//#ifdef FOR_DOCX_EXPORT
