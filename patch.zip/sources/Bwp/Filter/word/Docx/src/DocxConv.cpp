// DocxConv.cpp: implementation of the CDocxConv class.
//
//////////////////////////////////////////////////////////////////////
#include <word_filter_PCH.hpp>

#ifdef IMPORT_DOCX
#include "DocxConv.h"
#include "TextAtt/Handlers/PoTextAttHandler.h"
#include "Docx/FootnoteEndNote/DocxSection.h"
#include "Docx/Common/Util/DocxUtil.h"
#include "Docx/VML/DocxShape.h"
#include "DocxLockedCanvas.h"
#include "Docx/Paragraph/DocxPara.h"
#include "Docx/Paragraph/DocxParaAtt.h"
#include "Docx/Paragraph/DocxFramePr.h"
#include "Docx/Text/DocxText.h"
#include "DocxLevel.h"
#include "Docx/Text/DocxTextAtt.h"
#include "BrDrawArrow.h"
#include "BrPenObj.h"
#include "BrShape.h"
#include "BFreeDraw.h"
#include "bwFieldHyper.h"
#include "package_relationship.h"
#include "package_uri.h"
#include "Docx/Section/Manager/SectionManager.h"

#include "ODRAWDefine.h"
#include "Docx/Field/DocxField.h"
#include "Docx/Field/DocxRelationField.h"

#ifdef SUPPORT_INKML
#include "ContentPart/Handler/ContentPartHandler.h"
#endif	//SUPPORT_INKML

#include "Docx/CommentsExtended/CommentsEx.h"
#include "bwCharSet.h"
#include "bwLine.h"
#include "Docx/Common/Handler/ColorConvertHandler.h"
#include "bwPage.h"
#include "DocxLoader.h"
#include "bwPageNumItem.h"
#include "ftLibrary.h"
#include "Docx/Field/DocxFieldCaption.h"
#include "bwFieldCaption.h"

#ifdef DANDONG_SMARTART
#include "bwSmartArt.h"
#include "bwSmartArtEntry.h"
#endif // DANDONG_SMARTART
#ifdef	SUPPORT_DOCX_MATH // [2015.07.24]
#include "Docx/Math/MathInterface.h"
#endif

#include "Docx/Numbering/Handler/NumberingHandler.h"
#include "Docx/Styles/Style/DocxTableStyle.h"
#include "bwCellPen.h"

#include "drawing/officex_atomdef.h"

#include "bwBookMark.h"
#include "bwChart.h"
#include "bwpTypes.h"

#ifdef DOCX_DOCUMENT_PROTECTION
#include "OfficeCrypto/DocumentProtector/DocxDocumentProtector.h"
#endif

#ifdef DOCX_WRITE_PROTECTION
#include "OfficeCrypto/DocumentProtector/OOXMLWriteProtector.h"
#endif
#include "drawing/brdrawutil_bwp.h"
#include "Docx/Comment/DocxComments.h"
#include "brutil.h"
#include "ThreadDefines_i.h"
#include "bwCellList.h"
#include "drawing/officex_textparagraphBase.h"
#include "bwUtil.h"
#include "Docx/Field/DocxFieldManager.h"
#include "BaseDefines_i.h"
#include "../Error/ErrorHandle.h"
#include "bwTableStyleMgr.h"
#ifdef SUPPORT_CUSTOM_PROPERTIES
#include "Docx/Custom/DocxProperty.h"
#include "Docx/Custom/DocxCustom.h"
#endif //SUPPORT_CUSTOM_PROPERTIES

#include "Frame/CellFrame.h"
#include "Frame/text/FrameTextAutoResize.h"
#include "bwTableEngine.h"
#include "../TrackChange/DocxTrackChanges.h"
#include "drawing/officex_model3d.h"

#include "bfontex.h"
#include "ParaAtt/Handlers/PoParaAttHandler.h"
#include "Docx/FootnoteEndNote/DocxFootEndNote.h"

typedef PO_TEXTATT_LANGUAGE::PoLanguage PoLanguage;
typedef PO_TEXTATT_LANGUAGE::PoTextAttLanguage PoTextAttLanguage;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CDocxConv::CDocxConv()
{
	m_bFirstRead = BrTRUE;
	m_pCurPage = BrNULL;
	m_pCurFrame = BrNULL;
	m_pCurLineList = BrNULL; //table, drawobject���� Linelist�� ����Ű�� �ϱ� ���� ���
	m_nReadPgNum = 0;
	m_nNeedReadPageNum = 2;
	m_nCurParaHgt = 0;
	m_nFrameTextWidth = 0;
	m_nFrameTextHeight = 0;
	//jjoo:TableTextAtt
	m_bTextInTable = BrFALSE;
	m_bSuspendXmlParser = BrFALSE;
	m_bPageBreakInScope = BrFALSE;
	m_pFrameForOLE = BrNULL;	
	//jjoo:2008-07-08:FramePr
	m_pPrevFramePr = BrNULL;
	m_pFrameForTextFramePr = BrNULL;
	m_pPartName = BrNULL;
	//2008-06-26 hnsong
	m_nCurBigCharSize = 0;
	m_wAttrIDForCurBigChar = 0;
	m_bOnlyEngPara = BrTRUE;
	m_pPrevParaAtt = BrNULL;
	m_pDocxLoader = BrNULL;
	m_bHeaderFooter = BrFALSE;
	m_bComment = BrFALSE;
	m_bSectPrForSuspend = BrFALSE;
	m_bNewSection = BrTRUE;
	m_nOldCurParaHgt = 0;
	m_pOldCurLineList = BrNULL;
	m_pPackage = BrNULL;
	m_pTablePtrArray.resize(0);
	m_pDocxPara = BrNULL;
	m_nDoingType = 0;
	m_pPrevStyleID = BrNULL;
	m_arrEndNoteCustomCharSetArray.resize(0);
	m_bIsReadintEndnote = BrTRUE;
	m_nParaAttIDForPageBreak = -1;
	m_bExistTextAfterPageBreakInSamePara = BrFALSE;
	m_nCaptionIDForEndLink = -1;
	m_pDocxSectionManager = BrNEW CDocxSectionManager();
	m_bToc = BrFALSE;
	m_bSectionFirstLine = BrTRUE;
	m_nCurSectionIndex = 0;
	m_pNotCompleteTable = BrNULL;
	m_bSDTToc = BrFALSE;
	m_pShapeTypeAdjArray = BrNULL;
	m_pShapeAdjArray = BrNULL;
	m_pCurSectionInformation = BrNULL;
	m_fLockedCanvasRatio = 1;
	m_nCommnetCharCount = 0;
}

CDocxConv::~CDocxConv()
{
	if(m_pPartName)		BrFree(m_pPartName);
	if(m_pPrevFramePr)	BrDELETE m_pPrevFramePr;
	if(m_pPrevParaAtt )	BrDELETE m_pPrevParaAtt;

	m_pDocxPara = BrNULL;

	if(m_pPrevStyleID)
		BR_SAFE_FREE(m_pPrevStyleID);
	for(BrINT32 i = 0; i < m_arrEndNoteCustomCharSetArray.size(); i++)
		BR_SAFE_FREE(m_arrEndNoteCustomCharSetArray.at(i));

	BR_SAFE_DELETE(m_pDocxSectionManager);
	BR_SAFE_DELETE(m_pShapeTypeAdjArray);
	BR_SAFE_DELETE(m_pShapeAdjArray);
}

BrBOOL CDocxConv::convertDocxToBwp(CallbackParam *pParam)
{
	BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);

	BrBOOL bRet = BrTRUE;
	if(m_bFirstRead)
	{
		if(!FileValidate())
			return SET_ERROR(kPoErrCorruptFile, "");

		// [2013.01.21][������] Chart Color ���� ����.
		if(!theBWordDoc->getColorScheme() && getDocxLoader() && getDocxLoader()->m_pTheme && getDocxLoader()->m_pTheme->GetSchemeColor())
			theBWordDoc->setColorScheme(getDocxLoader()->m_pTheme->GetSchemeColor());
		if(!theBWordDoc->getContainerTheme() && getDocxLoader() && getDocxLoader()->m_pTheme)
			theBWordDoc->setContainerTheme(getDocxLoader()->m_pTheme);

		theBWordDoc->getPageArray()->Delete(1, 1, BrTRUE);

		// create first page
		//ù������ ���� convert
		//ù������ ���ΰ� ������ ���� Ȯ�� �ʿ�
		CPage *pPage = BrNEW CPage();
		if(!pPage)
			return SetErrorFReturn(CFilterErrorObj(kPoErrMemory, __FILE__, __LINE__));

		CPageArray *pPageArray= theBWordDoc->getPageArray();
		pPageArray->Add(pPage);
		pPage->setPageArray(pPageArray);
		m_pCurPage = pPage;
		CFrame* pFirstPageBasicFrame = BrNEW CFrame();
		pFirstPageBasicFrame->setClass( FIXFRAME );
		m_pCurFrame = pFirstPageBasicFrame;
		m_pCurFrame->updatePage(m_pCurPage);
		pPage->getBFrameList()->insertAtTail(pFirstPageBasicFrame);
		m_nNeedReadPageNum = m_nReadPgNum;

		convertSettings();

		CSectionInfomation	*pCurSectionInformation = BrNEW CSectionInfomation();
		if(!pCurSectionInformation)
			return SetErrorFReturn(CFilterErrorObj(kPoErrMemory, __FILE__, __LINE__));
		m_pCurSectionInformation = pCurSectionInformation;
		m_pDocxSectionManager->CreateSectionInformation(pCurSectionInformation, m_nCurSectionIndex++);

		SetFirstPageProperty(m_pCurPage);
BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);

		// real transfer doc content to bword
		if( !readDocument(pParam)) return BrFALSE;
	}
	else
	{
		//���� ���� �Ŀ� frame �� linelist�� ���� �� ��� ���� �ʿ�
		CLine* pLastLine = theBWordDoc->getLastLine();
		if(!pLastLine)
		{
			//���� ���� ����
			BRTHREAD_ASSERT(0);
			return SetErrorFReturn(CFilterErrorObj(kPoErrImportError, __FILE__, __LINE__));
		}
		m_pCurPage = pLastLine->getPage();//(CPage*)theBWordDoc->getPageArray()->GetAt(theBWordDoc->getPageArray()->GetSize()-1);	
		m_pCurFrame = pLastLine->getFrame();
		if(m_pCurFrame && m_pCurFrame->getSubFrame() )
		{
			m_pCurLineList = (CLineList*)m_pCurFrame->getSubFrame();
		}
		else 
			m_pCurLineList = BrNULL;
		if(m_pCurPage)
		{
			BrINT32 nCurPageNum = getPageNum();
			m_nNeedReadPageNum = m_nReadPgNum - nCurPageNum;
			if(m_nNeedReadPageNum < 2)
			{
				BRTHREAD_ASSERT(0);
				m_nNeedReadPageNum = 2;
			}
			//jjoo:2009-09-08:������ �����Ⱑ �����Ŀ� suspend�� �Ǿ��� ���� �������� ������ �־�� �Ѵ�.
			if(m_bSectPrForSuspend)
			{
				CFrame *pLastFrame = m_pCurPage->getLastBasic();
				if(pLastFrame && pLastFrame->getSubFrame() )
				{
					CLine* pLastLine = ((CLineList*)pLastFrame->getSubFrame())->getLast();
					if(pLastLine)
					{
						if(pLastLine->isPageBreak())
							createPage();
						else
						{
							CCharSet *pCharSet = pLastLine->getLastLink();
							if(pCharSet)
							{
								const PoTextAtt *pTextAtt = theBWordDoc->getTextAttHandler()->getTextAtt( pCharSet->getAttrID() );
								if(pTextAtt->getSubType() == PAGE_BREAK)
								{
									createPage();	//m_pCurPage ����Ʈ�� �ٲ�.
								}
							}
						}
					}
				}
			}
		}

		if(m_pCurFrame)
		{
			if( m_pCurFrame->getLastLine() )
				m_nCurParaHgt = m_pCurFrame->getLastLine()->getBasePos();
		}
		if(m_pNotCompleteTable)
			ConvertDocxTableToBWP(m_pNotCompleteTable, m_pCurLineList);

		if ( m_bSuspendXmlParser )	{		// SuspendXmlParser()�� ResumeXmlParser() �� �׻� ������� call�Ǿ�� �Ѵ�.
			m_bSuspendXmlParser = BrFALSE;
			m_bPageBreakInScope = BrFALSE;
			if (m_pPartName)
			{
				BrCallbackBase*	pObject = (BrCallbackBase*)this;
				BoraXmlParserContext* pContext = (BoraXmlParserContext*)pObject->GetXmlParserContext();
				
				pContext->pCurPackagePartName = m_pPartName;
			}
			BoraPackageBase::ResumeXmlParser(this);
		}

	}

	if(m_bFirstRead)
		m_bFirstRead = BrFALSE;

	return bRet;
}


BrBOOL CDocxConv::CallbackStartElement(LPVOID pParam)
{
	XMLDataDecodeParam* pInfo = (XMLDataDecodeParam*)pParam;

	switch( pInfo->callbackParam.wParam )
	{
	case DOCX_BODY:
	case DOCX_TXBXCONTENT:
		return RootChildReadStart(pInfo);
	}

	if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DOCUMENT) )
	{
		pInfo->nElementOption |= BR_XML_NEED_END_ELEMENT;
		return BrTRUE;
	}
	else if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_BODY) )
	{
		if (m_bHeaderFooter)
			return SetErrorFReturn(CFilterError(kPoErrCorruptFile));
		pInfo->callbackParam.wParam = DOCX_BODY;
		pInfo->callbackParam.pCurrentInstance = this;
		pInfo->nElementOption |= BR_XML_NEED_END_ELEMENT;
		m_bHeaderFooter = BrFALSE;
	}

	return BrTRUE;
}

BrBOOL CDocxConv::CallbackEndElement(LPVOID pParam)
{
	XMLDataDecodeParam* pInfo = (XMLDataDecodeParam*)pParam;

	switch( pInfo->callbackParam.wParam )
	{
	case DOCX_TABLE:
			m_pCurLineList = BrNULL;
		break;
	}

	RootChildReadEnd(pInfo);
	SendEngineArrange();
	pInfo->callbackParam.wParam = 0;
	return BrTRUE;
}


void CDocxConv::SendEngineArrange()
{
	if(m_bSectionFirstLine)
		return;
	CPage* pPage = theBWordDoc->getPageArray()->GetLast();
	if(pPage->getFirstBasic()->getSubFrame() == BrNULL)
		return;
	if(m_pCurLineList && !m_pCurLineList->getTotalLine())
		return;
	BrINT32 nReadPageNum = m_nReadPgNum;
	if(m_nReadPgNum != 0x7FFFFFFF && m_bPageBreakInScope )
		nReadPageNum += 2;

	CLine* pLastLine = theBWordDoc->getLastLine();
	if(!pLastLine->isCRAtLastPos())
		return;

	BrBOOL bReturnEngine = BrFALSE;
	if(m_nReadPgNum != 0x7FFFFFFF)	{
		if( nReadPageNum < theBWordDoc->getPageArray()->GetSize())
			bReturnEngine = BrTRUE;
	}

	BrINT32 nCheckSize = 0;		
	if(!m_pCurPage->getFirstBasic())
		nCheckSize = m_pCurPage->getPaperSize()->height();
	else
		nCheckSize = m_pCurPage->getFirstBasic()->height();
	
	nCheckSize *= m_nNeedReadPageNum;

	if (m_nCurParaHgt >= nCheckSize) 
		bReturnEngine = BrTRUE;

	if( !bReturnEngine)
		return;

	m_pCurFrame = BrNULL; //�ٽ� ������ �����ϱ� ���� getcurlinelist
	m_nCurParaHgt = 0;

	BrCallbackBase*	pObject = (BrCallbackBase*)this;
	BoraXmlParserContext* pContext = (BoraXmlParserContext*)pObject->GetXmlParserContext();

	if (!m_pPartName || strcmp(pContext->pCurPackagePartName, m_pPartName))	{
		int nLen = BrStrLen(pContext->pCurPackagePartName);
		if (m_pPartName)	BrFree(m_pPartName);
		m_pPartName = (BrCHAR*)BrCalloc(nLen + 1, sizeof(BrCHAR));
		strncpy_s(m_pPartName, nLen + 1, pContext->pCurPackagePartName, strlen(pContext->pCurPackagePartName));
		m_pPartName[nLen] = 0;
	}
	
	BoraPackageBase::SuspendXmlParser(this);
	m_bSuspendXmlParser = BrTRUE;
}

BrBOOL CDocxConv::RootChildReadStart(XMLDataDecodeParam* pInfo)
{
	const BrCHAR*	pElementName = pInfo->pElementData->pElementName;
	const BrCHAR*	pName = trimNamespace(pElementName);

	BrCHAR chElementOption = BR_XML_SKIP_ELEMENT;
	switch(pName[0])
	{
	case 'b':
		if( 0 == strcmp(pElementName, X_DOC_BOOKMARK_START))//w:bookmarkStart
		{
			BrINT32 id = -1;
			BrWORD	wBkName[42] = { 0, };
			BChar cBkName[42] = { 0, };
			BrINT32 nSizeBkName = 0;
			BrBOOL	bIgnoreBookmark = BrFALSE;
			if( pInfo->pElementData->pAttributePairs )
			{
				for( BrINT32 i = 0; pInfo->pElementData->pAttributePairs[i]; i += 2)
				{
					if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], X_ID) )
					{
						id = strtol(pInfo->pElementData->pAttributePairs[i+1], BrNULL, 10);
					}
					else if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], X_NAME) )
					{
						memset(wBkName, 0, 2 * 42);
						nSizeBkName = BoraMultiByteToWideChar_UTF8(pInfo->pElementData->pAttributePairs[i+1], BrStrLen(pInfo->pElementData->pAttributePairs[i+1]), wBkName, 40);
						wBkName[40] = 0;
						CCUtil::WORDtoBChar(wBkName, cBkName);
						//[2013-03-14][toypilot]_GoBack name�� MS���� ����
						//���� _�� ���۵Ǵ� ������ bookmark�� Name�� ���ؼ� �߰� ó�� �ʿ�
						if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i+1], "_GoBack"))
							bIgnoreBookmark = BrTRUE;
					}
				}
			}
			if(bIgnoreBookmark)
				break;

			CDocxLoader* pDocxLoader = getDocxLoader();
			if( NULL== pDocxLoader->m_pBkArray)
				pDocxLoader->m_pBkArray = BrNEW CDocxBookMarkArray();

			BrINT32 nBkSize = theBWordDoc->getTypesetInfo()->getBookMarkArray()->GetSize();				

			CDocxBookMark *pDocBkMk = BrNEW CDocxBookMark();
			pDocBkMk->m_nMsBkPos = id;
			pDocBkMk->m_nBwBkPos = nBkSize;
			pDocxLoader->m_pBkArray->Add(pDocBkMk);

			CBookMark *pBkMk = BrNEW CBookMark();
			if(!pBkMk)
				return SetErrorFReturn(CFilterErrorObj(kPoErrMemory, __FILE__, __LINE__));

			pBkMk->setID(nBkSize);
			pBkMk->setString(BString(cBkName, nSizeBkName));

			theBWordDoc->getTypesetInfo()->getBookMarkArray()->Add(pBkMk);

			CLineList *pLineList = getCurLineList();
			if(!pLineList)
			{
				m_pCurLineList = pLineList = ftLibrary::CreateLineList(m_pCurFrame);
				if(m_pDocxPara)
					m_pDocxPara->CreateLineWithPara(pLineList, m_pDocxPara->m_wParaAttID);
				else 
					ftLibrary::CreateLine(pLineList);
			}
			else if( BrNULL == pLineList->getLast() )
			{
				if(m_pDocxPara)
					m_pDocxPara->CreateLineWithPara(pLineList, (m_pDocxPara != BrNULL ? m_pDocxPara->m_wParaAttID : 0));
				else
					ftLibrary::CreateLine(pLineList);

			}

			CCharSetArray *pCharSetArray = pLineList->getLast()->getCharSetArray();
			CCharSet cCharSet;
			cCharSet.setCode(nBkSize);
			if( m_pDocxPara && m_pDocxPara->m_wTextAttID )
				cCharSet.setAttrID( m_pDocxPara->m_wTextAttID);
			else 
				cCharSet.setAttrID(0);

			cCharSet.setLinkSubType(LINKTYPE::BOOKMARK, START_LINK | SPLITABLE | EDITABLE );
			BrINT32 nBeforeCRIndex = pCharSetArray->size();
			if (pLineList->getLast()->isCRWholeLine()) {
				for (BrINT32 nIndex = pCharSetArray->size() - 1; nIndex >= 0; nIndex--) {
					if (pCharSetArray->at(nIndex).isCRLink())
						nBeforeCRIndex = nIndex;
				}
				pCharSetArray->InsertAt(nBeforeCRIndex, cCharSet);
			}
			else
				pCharSetArray->Add(cCharSet);
		}
		else if( 0 == strcmp(pElementName, X_DOC_BOOKMARK_END))//w:bookmarkEnd
		{
			BrINT32 id = -1;
			if( pInfo->pElementData->pAttributePairs )
			{
				for(BrINT32 i = 0; pInfo->pElementData->pAttributePairs[i]; i += 2)
				{
					if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], X_ID) )
						id = strtol(pInfo->pElementData->pAttributePairs[i+1], BrNULL, 10);
				}
			}

			CDocxLoader* pDocxLoader = getDocxLoader();
			if(!pDocxLoader->m_pBkArray)
				return BrFALSE;

			CDocxBookMark *pDocBkMk = NULL;
			BrINT32 nBkArSize = pDocxLoader->m_pBkArray->GetSize();
			for(BrINT32 j = 0; j < nBkArSize; j++) {
				CDocxBookMark* pTmpDocBkMk = pDocxLoader->m_pBkArray->GetAt(j);
				if(pTmpDocBkMk && (pTmpDocBkMk->m_nMsBkPos == id)) {
					pDocBkMk = pTmpDocBkMk;
					break;
				}
			}

			if(!pDocBkMk)
				break;
			
			CLineList *pLineList = getCurLineList();
			CLine* pLine = BrNULL;
			if(!pLineList) {
				m_pCurLineList = pLineList = ftLibrary::CreateLineList(m_pCurFrame);
				BrINT32 nParaAttID = m_pDocxPara != BrNULL ? m_pDocxPara->m_wParaAttID : 0;
				pLine = m_pDocxPara->CreateLineWithPara(pLineList,nParaAttID);
			}
			else if( BrNULL == pLineList->getLast() ) {
				pLine = theBWordDoc->getLastLine();
				if(!pLine) {
					BrINT32 nParaAttID = m_pDocxPara != BrNULL ? m_pDocxPara->m_wParaAttID : 0;
					if(m_pDocxPara)
						pLine = m_pDocxPara->CreateLineWithPara(pLineList,nParaAttID);
					else
						pLine = ftLibrary::CreateLine(pLineList);
				}
			}
			else
				pLine = pLineList->getLast();

			if(!pLine->getCharSetArray())
				ftLibrary::CreateCharSetArray(pLine);
			CCharSetArray *pCharSetArray = pLine->getCharSetArray();

			CCharSet cCharSet;
			cCharSet.setCode(pDocBkMk->m_nBwBkPos);
			if( m_pDocxPara && m_pDocxPara->m_wTextAttID )
				cCharSet.setAttrID( m_pDocxPara->m_wTextAttID);
			else 
				cCharSet.setAttrID(0);
			cCharSet.setLinkSubType(LINKTYPE::BOOKMARK, END_LINK | SPLITABLE | EDITABLE );
			BrINT32 nBeforeCRIndex = pCharSetArray->size();
			if (pLine->isCRWholeLine()) {
				for (BrINT32 nIndex = pCharSetArray->size() - 1; nIndex >= 0; nIndex--) {
					if (pCharSetArray->at(nIndex).isCRLink())
						nBeforeCRIndex = nIndex;
				}
				pCharSetArray->InsertAt(nBeforeCRIndex, cCharSet);
			}
			else
				pCharSetArray->Add(cCharSet);
		}
		break;
	case 'c':
		{
		/* [SBKang][15/12/08] : ���� ��ƾ�� �� �κ� ��Ÿ�� �� ������, �м� �ʿ� */
		/* [15/12/22] : w:body �Ʒ� �ٷ� commentRange�� ������ �ش�κп� �ɸ� */
			if( 0 == strcmp(pElementName, X_DOC_COMMENT_START))		//w:commentRangeStart
			{
				BrINT32 nCommentID = -1;

				/* 1. Comment ID ���� ���� */
				for( BrINT32 i = 0; pInfo->pElementData->pAttributePairs; i += 2)
				{
					if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], X_ID) )
					{
						nCommentID = BrAtoi( (const BrCHAR*) pInfo->pElementData->pAttributePairs[i+1] );
						break;
					}
				}
				this->convertCommentRangeStart(nCommentID);
			}
			else if( 0 == strcmp(pElementName, X_DOC_COMMENT_END))//w:commentRangeEnd
			{
				BrINT32 nCommentID = -1;

				/* 1. Comment ID ���� ���� */
				for( BrINT32 i = 0; pInfo->pElementData->pAttributePairs; i += 2)
				{
					if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], X_ID) )
					{
						nCommentID = BrAtoi( (const BrCHAR*) pInfo->pElementData->pAttributePairs[i+1] );
						break;
					}
				}
				this->convertCommentRangeEnd(nCommentID);
			}					
			else if( 0 == strcmp(pElementName, X_DOC_COMMENT_REF))//w:commentrangeReference
			{
				BrINT32 nCommentID = -1;

				/* 1. Comment ID ���� ���� */
				for( BrINT32 i = 0; pInfo->pElementData->pAttributePairs; i += 2)
				{
					if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], X_ID) )
					{
						nCommentID = BrAtoi( (const BrCHAR*) pInfo->pElementData->pAttributePairs[i+1] );
						break;
					}
				}
				this->convertCommentReference(nCommentID);
			}
			else if( 0 == strcmp(pElementName, "w:customXml"))//w:commentrangeReference
			{
				return SetErrorFReturn(CFilterError(kPoErrUnsupportedVersion));
			}
		}
		break;
	case 'p':
		if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_PARA) )
		{
			//w:p���۽� �ʱ�ȭ �ʿ�
			m_nParaAttIDForPageBreak = -1;
			CDocxPara *pDocxPara = BrNEW CDocxPara(this);
			if(!pDocxPara)
			{
				pInfo->nElementOption |= BR_XML_SKIP_ELEMENT;
				return SetErrorFReturn(CFilterErrorObj(kPoErrMemory, __FILE__, __LINE__));
			}
			BR_SAFE_DELETE(m_pDocxPara);
			m_pDocxPara = pDocxPara;

			pInfo->callbackParam.wParam = DOCX_PARA;
			pInfo->callbackParam.pCurrentInstance = pDocxPara;
			chElementOption = BR_XML_NEED_END_ELEMENT;
		}
		break;
	case 's':
		if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_SECTIONPR))	//jjoo:2008-07-25:������ section�����̹Ƿ� section���� ������ �����ϸ� �ɵ�.
		{
			CLine *pLine = getCurLineList()->getLast();
			if ( pLine )
				m_pDocxSectionManager->checkRegionInfomation(pLine);

			chElementOption = BR_XML_SKIP_ELEMENT;
		}
		else if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_SDT) )
		{
			CDocxSdt *pDocxSdt = BrNEW CDocxSdt(m_pDocxLoader, this);
			if(!pDocxSdt)
			{
				pInfo->nElementOption |= BR_XML_SKIP_ELEMENT;
				return SET_ERROR(kPoErrImportError, "");
			}
			pInfo->callbackParam.wParam = DOCX_SDT;
			pInfo->callbackParam.pCurrentInstance = pDocxSdt;
			chElementOption = BR_XML_NEED_END_ELEMENT;
		}
		else if( 0 == strcmp(pInfo->pElementData->pElementName, "wx:sect"))
		{
			pInfo->callbackParam.wParam = DOCX_BODY;
			pInfo->callbackParam.pCurrentInstance = this;
			chElementOption = BR_XML_NEED_END_ELEMENT;
		}
		break;
	case 't':
		if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_TABLE) )	//w:tbl
		{
			BR_SAFE_DELETE(m_pPrevFramePr);

			CDocxTable *pDocxTable = BrNEW CDocxTable(this);
			if(!pDocxTable)	{
				pInfo->nElementOption |= BR_XML_SKIP_ELEMENT;
				return SET_ERROR(kPoErrImportError, "");
			}

			BRect cRect(0,0,0,0);
			pDocxTable->m_pTableFrame = createFrame(TABLEFRAME, &cRect, BrFALSE, getPageNum(), BrFALSE);
			if( !pDocxTable->m_pTableFrame ) {
				BR_SAFE_DELETE(pDocxTable);
				return SetErrorFReturn(CFilterErrorObj(kPoErrImportError, __FILE__, __LINE__));
			}
			CBTable *pTable = BrNEW CBTable();
			CFrame* pTableFrame = pDocxTable->m_pTableFrame;
			pTableFrame->setSubFrame(pTable);
			pTableFrame->setAnchorFlag(BrTRUE);
			pTableFrame->setPageNum(m_pCurFrame->getPageNum());
			pTable->setFrame(pTableFrame); //direct�� read�� �����ؾ���.... 

			//////////////////////////////////////////////////////////////////////////
			//����â �۾� �Ϸ� �� ����. ǥ ����â ����
			BString sTableName;
			pDocxTable->m_pTableFrame->setNameForSelectionPane(sTableName);
			//////////////////////////////////////////////////////////////////////////
			//[2013.07.19][������][M34816] Float Table�϶� Zindex ���� ����.
			if(pDocxTable->m_pTableFrame->isAnchored())
			{
				if(m_bHeaderFooter)
					theBWordDoc->getAFrameList4HeaderFooter()->insertAtTail(pDocxTable->m_pTableFrame, BrTRUE);
				else
					theBWordDoc->getAFrameList()->insertAtTail(pDocxTable->m_pTableFrame, BrTRUE);
			}
			else
			{
				if(m_bHeaderFooter)
					theBWordDoc->getAFrameList4HeaderFooter()->insertAtHead(pDocxTable->m_pTableFrame, BrTRUE);
				else
					theBWordDoc->getAFrameList()->insertAtHead(pDocxTable->m_pTableFrame, BrTRUE);
			}


			m_pTablePtrArray.Add(pDocxTable);
			m_nDoingType |= DOC_TABLE;
			pInfo->callbackParam.wParam = DOCX_TABLE;
			pInfo->callbackParam.pCurrentInstance = pDocxTable;
			chElementOption = BR_XML_NEED_END_ELEMENT;
		}
		break;
	}

	pInfo->nElementOption |= chElementOption;
	return BrTRUE;
}

BrBOOL CDocxConv::RootChildReadEnd(XMLDataDecodeParam* pInfo)
{
	if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_PARA) )
	{
		CDocxPara *pDocxPara = (CDocxPara *)pInfo->callbackParam.pCurrentInstance;
		if(pDocxPara)
		{
			if(pDocxPara->m_wTextAttID == 0xffff)
			{
				if(pDocxPara->m_pDocxTextAtt)
					pDocxPara->m_wTextAttID = pDocxPara->m_pDocxTextAtt->makeTextAttID();
				else
				{
					PoTextAtt emptyAtt;
					pDocxPara->m_wTextAttID = theBWordDoc->getTextAttHandler()->insertTextAtt(emptyAtt);
				}
			}

			if(pDocxPara->m_wParaAttID == 0xFFFF) //w:p���� element�� ���� ���
			{
				if(pDocxPara->m_pDocxParaAtt)
					pDocxPara->m_wParaAttID = pDocxPara->m_pDocxParaAtt->makeParaAttID();
				else
				{
					PoParaAtt emptyAtt;
					pDocxPara->m_wParaAttID = theBWordDoc->getParaAttHandler()->insertParaAtt(emptyAtt);
				}
				pDocxPara->CheckPrevTableLine();
			}

			//[SRG-819][2015.03.31][�̼���] begin, separate, end�� ���� �ٸ� ���ܿ� �ִ� ��� ������ �ܶ��� ������.
			DocxField* pDocxField = BrNULL;
			DocxFieldManager * pDocxFieldManager = getDocxLoader()->getDocxFieldManager();
			pDocxField = pDocxFieldManager->peek();

			if(pDocxField && !pDocxField->IsDrawingHyper() && !pDocxField->IsTextHyper() )
				pDocxField->ConvertParaEndFldSeparate(getCurLineList());

			if(pDocxPara->m_pDocxParaAtt)
				m_bSectPrForSuspend = pDocxPara->m_pDocxParaAtt->m_bSectPr;

			CLine* pLine = getCurLineList()->getLast();
			if(pDocxPara->getParaStatus() != ParaStatus_Normal)
			{
				CLineList *pLineList = getCurLineList();
				if(!pLineList)
					m_pCurLineList = pLineList = ftLibrary::CreateLineList(m_pCurFrame);

				if(!pDocxPara->CreateParaLine())
					return SetErrorFReturn(CFilterErrorObj(kPoErrImportError, __FILE__, __LINE__));

				if( pDocxPara->m_pDocxParaAtt && pDocxPara->m_pDocxParaAtt->m_pFramePr)
				{
					pDocxPara->m_pDocxParaAtt->m_pFramePr->ConvertFramePr(this, pDocxPara->m_pDocxParaAtt);
					if(m_pCurLineList)
						pLineList = m_pCurLineList;
				}

				pLine = pLineList->getLast();								
			}
			else if(!pLine)
			{
				if(pDocxPara)
				{
					// [SRG-2291] pagebreak �� ���� �������� CLine �������� �ʵ��� ����
					pLine = pDocxPara->CreateLine(getCurLineList());
					if(!pLine)
						return SetErrorFReturn(CFilterErrorObj(kPoErrImportError, __FILE__, __LINE__));

					pLine->setParaID(pDocxPara->m_wParaAttID);

					if(pDocxPara->GetAfterBreak())
					{
						m_pDocxPara->SetBigCharSize(m_nCurBigCharSize);
						m_nCurParaHgt += m_pDocxPara->GetParaHeight();

						InitVarForPara(pDocxPara);
						CLine* pBreakLine = theBWordDoc->getLastLine();
						if(!pBreakLine->isPageBreak())
							pBreakLine = pBreakLine->getPrev();
						if(pDocxPara->m_pDocxParaAtt && pDocxPara->m_pDocxParaAtt->m_bSectPr)
						{							
							pDocxPara->MakeSection(pBreakLine);
							m_bSectionFirstLine = BrFALSE;
							m_bNewSection = BrTRUE;
							m_pDocxPara->m_pNeedCRBreakLine = BrNULL; 
						}
						else if(pBreakLine)
						{
							CLine* needCRLine = m_pDocxPara->m_pDocxParaAtt == BrNULL ? theBWordDoc->getLastLine() : pBreakLine;
							ftLibrary::AddCharSet(needCRLine, ASCII_CODE_CR, pDocxPara->m_wTextAttID);
						}

						// [SRG-1903] ���ܿ� bullet �Ӽ��� �ִ� ��� bullet ����.
						if(m_pDocxPara->m_pDocxParaAtt && m_pDocxPara->m_pDocxParaAtt->m_pNumPr && m_pDocxPara->m_pDocxParaAtt->m_pNumPr->numID)
						{
							if(!m_pDocxPara->MakeBulletData(pBreakLine))
								SetErrorFReturn(CFilterErrorObj(kPoErrImportError, __FILE__, __LINE__));
						}
						return BrTRUE;
					}					
				}
			}

			CDocxParaAtt* pDocxParaAtt = pDocxPara->m_pDocxParaAtt;

			if( pDocxParaAtt && pDocxParaAtt->m_bExistFramePrTag )
			{
				//setResizeWidthForTextFramePr(pDocxParaAtt);
				if(pDocxParaAtt->m_pFramePr && m_pFrameForTextFramePr)
					pDocxParaAtt->m_pFramePr->ConvertFloatFramePrInfo(m_pFrameForTextFramePr, m_pCurPage, m_bHeaderFooter);
			}
			
			if(!m_bHeaderFooter && m_bSectionFirstLine && !m_bTextInTable && !m_bComment && !m_pDocxLoader->m_bFootEndNote) //���� ���� ����
			{
				CLine* pLine = theBWordDoc->getFirstLine();
				pLine->setSectionInformation(m_pCurSectionInformation);
				m_bSectionFirstLine = BrFALSE;
				m_bNewSection = BrFALSE;	
			}

			if(pDocxParaAtt && pDocxParaAtt->m_bSectPr && !m_bTextInTable && !m_bSectionFirstLine && !m_pDocxLoader->m_bFootEndNote)
			{
				pDocxPara->MakeSection(pLine);
				m_bNewSection = BrTRUE;	
				m_pDocxPara->m_pNeedCRBreakLine = BrNULL; //page break �ڿ� section break�� �޸����  CR���ʿ�
			}
			else 
			{
				ftLibrary::AddCharSet(pLine, ASCII_CODE_CR, pDocxPara->m_wTextAttID);
				if( pDocxParaAtt && pDocxParaAtt->m_bExistFramePrTag)
				{
					if(pLine->getFrame()->getSubClass() == FRAMEPR && pLine->getFrame()->getAnchorLine())
						m_pCurLineList = pLine->getFrame()->getAnchorLine()->getLineList();
				}
			}

			m_pDocxPara->SetBigCharSize(m_nCurBigCharSize);
			m_nCurParaHgt += m_pDocxPara->GetParaHeight();

			if(pLine && pDocxParaAtt && pDocxParaAtt->m_pNumPr && pDocxParaAtt->m_pNumPr->numID)
			{
				const PoParaAtt* curParaAtt = theBWordDoc->getParaAttHandler()->getParaAtt(pDocxPara->m_wParaAttID);
				if(curParaAtt->getBulletID() > 0)
				{
					BrINT32 outLineOrderNum = 0;
					if((m_nDoingType & DOC_HEADER) || (m_nDoingType & DOC_FOOTER))
						outLineOrderNum = pDocxParaAtt->countOutLineOrder(outLineOrdersHeaderFooter, curParaAtt->getBulletID(), curParaAtt->getBulletDepth());
					else
						outLineOrderNum = pDocxParaAtt->countOutLineOrder(outLineOrders, curParaAtt->getBulletID(), curParaAtt->getBulletDepth());

					pLine->setOutlineOrder(outLineOrderNum);
				}
			}

			if(pLine && pLine->getCharNum() == 0 && !pLine->getSectionInformation())
			{
				CLineList* pLineList = pLine->getLineList();
				pLineList->unLink(pLine);
			}

			InitVarForPara(pDocxPara);

			//2011-04-05 hnsong �̾ ������ �ʴ� framepr�� ������!!
			if (pDocxPara->m_pDocxParaAtt && !pDocxPara->m_pDocxParaAtt->m_pFramePr && m_pPrevFramePr)
				BR_SAFE_DELETE(m_pPrevFramePr);
			
			BR_SAFE_DELETE(pDocxPara);
			m_pDocxPara = BrNULL;
		}
	}
	else if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_TABLE))
	{
		CDocxTable *pDocxTable = (CDocxTable *)pInfo->callbackParam.pCurrentInstance;
		CLineList* pLineList = getCurLineList();
		
		if(pDocxTable->m_pDocxRowArray)
			ConvertDocxTableToBWP(pDocxTable, pLineList);
		else
		{
			for(BrINT32 nIndex = 0; nIndex < m_pTablePtrArray.size(); nIndex++)
			{
				if(pDocxTable == m_pTablePtrArray.at(nIndex))
					m_pTablePtrArray.RemoveAt(nIndex);
			}
			m_pNotCompleteTable = BrNULL;
			BR_SAFE_DELETE(pDocxTable);		
		}

		m_nDoingType &= ~DOC_TABLE;
		if(m_pCurFrame->GetClass() != CELLFRAME)
			m_bTextInTable = BrFALSE;

		if(!m_bComment && !m_bHeaderFooter && (m_bSectionFirstLine || m_bNewSection) && !m_bTextInTable && m_pCurFrame->isBasic()) //���� ���� ����
		{
			CLine* pLine = BrNULL;
			if(m_bSectionFirstLine)
				pLine = theBWordDoc->getFirstLine();
			else
				pLine = theBWordDoc->getLastLine();
			if(!pLine)
			{
				CLineList* pLineList = static_cast <CLineList*> (m_pCurFrame->getSubFrame());
				if(!pLineList)
					pLineList = ftLibrary::CreateLineList(m_pCurFrame);
				pLine = ftLibrary::CreateLine(pLineList);
			}
			pLine->setSectionInformation(m_pCurSectionInformation);
			m_bSectionFirstLine = BrFALSE;
			m_bNewSection = BrFALSE;
		}
		m_pDocxPara = BrNULL;
	}
	else if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_BODY))		//jjoo:2008-11-28:�������� �ѹ� �� ���ֱ� ����.
	{
		BrINT32 nPagenum = getPageNum();
		if(nPagenum > 1)
		{
			CPage* pPage = theBWordDoc->getPageArray()->getPage(nPagenum);
			CPage* pPrevPage = theBWordDoc->getPageArray()->getPage(nPagenum - 1);
			CLine* pLine = pPage->getLastLine();
			if(pLine && !pLine->isCRWholeLine())
			{
				BrBOOL bNeedCR = BrFALSE;
				CLine* pPrevPageLastLine = pPrevPage->getLastLine();
				if(pPrevPageLastLine != BrNULL)
				{
					BrINT32 nPrevLineCharSetSize = pPrevPageLastLine->getCharSetArray()->size();
					for(BrINT32 i = 0; i < nPrevLineCharSetSize; i++)
					{
						CCharSet cNode = pPrevPageLastLine->getCharSetArray()->at(i);
						if(cNode.isPageBreak())
						{
							bNeedCR = BrTRUE;
							break;
						}
					}
					if(bNeedCR)
					{
						//[2013-05-29][toypilot]
						//�ش� ��ƾ���� ������ ��쿡��
						//������ ������ w:p�� pagebreak �� ������ text�� ���� ���
						//���� �������� CR�� �����Ǿ�� �ϸ�,
						//���� �������� ���������ο� �޸� CR�� ���� �Ǿ�� �Ѵ�.
						CLineList* pLineList = pPage->getFirstLineList();
						pLine = ftLibrary::CreateLine(pLineList);
						pLine->setParaID(m_nParaAttIDForPageBreak);
						ftLibrary::AddCharSet(pLine, ASCII_CODE_CR);

						//���� ������ ������ ���� CR����
						if(pPrevPageLastLine && nPrevLineCharSetSize > 0)
						{
							CCharSet cNode = pPrevPageLastLine->getCharSetArray()->at(nPrevLineCharSetSize-1);
							if(!cNode.isPageBreak() && cNode.isCRLink())
								pPrevPageLastLine->getCharSetArray()->RemoveAt(nPrevLineCharSetSize-1);
						}
					}
				}		

			}
			else if(!pLine)
			{
				CLine* pLine = ftLibrary::CreateLine(pPage->getFirstLineList());
				ftLibrary::AddCharSet(pLine, ASCII_CODE_CR);
			}
			else if(pLine && pLine->getCharNum() == 2 && pLine->getTableFlag())	//MS word�� ���̺��� �������� �ִ� ��� ������ ���ο� ���� ������ �ִ� �������� �ڵ�
			{
				CLine* pLastLine = ftLibrary::CreateLine(pLine->getLineList());
				ftLibrary::AddCharSet(pLastLine, ASCII_CODE_CR);
			}
		}
		else
		{
			//ZPD-7452 ���� ��ü�� w:p�� �ϳ��� ���� ���
			CLine* pFirstLine = theBWordDoc->getFirstLine();
			if(!pFirstLine || pFirstLine->getCharNum() == 0)
			{
				if(!pFirstLine)
				{
					CFrame* pFrame = theBWordDoc->getFirstFrame();
					CLineList* pLineList = static_cast <CLineList*> (pFrame->getSubFrame());
					if(!pLineList)
						pLineList = ftLibrary::CreateLineList(pFrame);
					pFirstLine = ftLibrary::CreateLine(pLineList);
				}
				ftLibrary::AddCharSet(pFirstLine, ASCII_CODE_CR);
				pFirstLine->setSectionInformation(m_pCurSectionInformation);
			}

			//���� ������ ���ο� framePr �ϳ� �ִ� ���
			CLine* pLastLine = theBWordDoc->getLastLine();
			if(pLastLine && pLastLine->getLastLink() && !pLastLine->getLastLink()->isCRLink())
				ftLibrary::AddCharSet(pLastLine, ASCII_CODE_CR);
		}
			   	
		theBWordDoc->setFinishLoading(BrTRUE);
	}
#ifdef SUPPORT_CUSTOM_PROPERTIES
	else if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_CUSTOM_PROPERTY))
	{
		CDocxProperty *pDocxProperty = (CDocxProperty *)pInfo->callbackParam.pCurrentInstance;
		if(pDocxProperty)
		{
			CDocxCustomValue *pDocxCustomValue = pDocxProperty->GetCustomValue();
			LPDOCPROPERTIESINFO pBwpProperty = (LPDOCPROPERTIESINFO) BrMalloc(BrSizeOf(DOCPROPERTIESINFO));
			memset(pBwpProperty, 0, BrSizeOf(DOCPROPERTIESINFO));
		
			if(!pBwpProperty->fmtid && pDocxProperty->GetFmtID())
			{
				BrAutoChar temp = CUtil::convertBStringToChar(pDocxProperty->GetFmtID(), CP_UTF8);
				pBwpProperty->fmtid = temp.release();
			}	

			// �̸� : utf-8
			if(!pBwpProperty->name && pDocxProperty->GetName())
			{
				BrAutoChar temp = CUtil::convertBStringToChar(pDocxProperty->GetName(), CP_UTF8);
				pBwpProperty->name = temp.release();
			}
			pBwpProperty->pid = pDocxProperty->GetPID();		

			if(pDocxCustomValue)
			{
				// �� : utf-8
				if(!pBwpProperty->text && pDocxCustomValue->GetContent())
				{
					BrAutoChar temp = CUtil::convertBStringToChar(pDocxCustomValue->GetContent(), CP_UTF8);
					pBwpProperty->text = temp.release();
				}
				pBwpProperty->vt = pDocxCustomValue->GetValueType();
			}		

			theBWordDoc->setDocPropertiesInfo(pBwpProperty);

			BR_SAFE_DELETE(pDocxCustomValue);
		}
	}
#endif
	else if (0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DOCUMENT))
	{
		CLine* line = theBWordDoc->getLastLine();
		if (line && line->getLineList()) {
			CNote* pEndNote = theBWordDoc->getTypesetInfo()->getEndnoteOption();
			BrINT32 endNoteCount = pEndNote->getTotalNum();
			CLineList* lastPageLIneLIst = line->getLineList();
			CLineList* noteLineLIst = BrNULL;
			for (BrINT32 i = 1; i <= endNoteCount; i++) {
				noteLineLIst = m_pDocxLoader->getFootEndNote()->getEndnoteLineList(i);
				if (!noteLineLIst)
					continue;
				lastPageLIneLIst->insertAtTail(noteLineLIst);
			}
		}
	}
	return BrTRUE;
}

BrINT32 CDocxConv::setDrawObjInfo(CFrame *pFrame, BrWORD nTextAttID)
{
	AddShapeFrame(pFrame, nTextAttID);

	DocxField* pDocxField  = BrNULL;

	DocxFieldManager * pDocxFieldManager = getDocxLoader()->getDocxFieldManager();
	pDocxField = pDocxFieldManager->peek();

	if(pDocxField)
	{
		if(pDocxField->InstanceOf(eDocx_RelationField) && pDocxField->IsDrawingHyper())
		{
			DocxRelationField* pDocxRealationField = (DocxRelationField*)pDocxField;
			pDocxRealationField->SetCurFldCharType(eWSTFLDCHARTYPE_end);
			pDocxRealationField->ConvertEndRelationField(getCurLineList(), 0 );//, pFrame->getID());
			pDocxFieldManager->removePeek();
			pFrame->setFieldID(pDocxField->GetFieldID());

		}
		else
			BRTHREAD_ASSERT(0);
	}

	return pFrame->getID();
}

CFrame *CDocxConv::createPenFreeDrawFrame(BrINT32 a_nPenID, BRect& a_rRect)
{
	BrPenFreeDrawArray *pPenDrawArray = m_pDocxLoader->getPenDrawArray();
	if( !pPenDrawArray)
	{
		SetErrorFReturn(CFilterErrorObj(kPoErrImportError, __FILE__, __LINE__));
		return BrNULL;
	}
	BrPenFreeDraw *pPenDraw = pPenDrawArray->getPenDraw(a_nPenID);
	if( !pPenDraw)
	{
		SetErrorFReturn(CFilterErrorObj(kPoErrImportError, __FILE__, __LINE__));
		return BrNULL;
	}
	CFrame *pFrame = createFrame(PENDRAWFRAME, &a_rRect, BrFALSE,  getPageNum(), BrTRUE);
	if(!pFrame)
		pFrame = MakeInvalidShape(a_rRect, BrFALSE);
	if(!pFrame)
	{
		SetErrorFReturn(CFilterErrorObj(kPoErrImportError, __FILE__, __LINE__));
		return BrNULL;
	}
	BFreeDraw *pFreeDraw = (BFreeDraw*)pFrame->getSubFrame();
	BInkml* pInkML = pFreeDraw->getInkml();
	BArray<BInkmlContext>*	pInkMLContextArr = pInkML->getInkmlContextArr();
	BArray<BInkmlBrush>*	pInkMLBrushArr = pInkML->getInkmlBrushArr();
	BArray<LPBInkmlTrace>*	pInkMLTraceArr = pInkML->getInkmlTracePointerArr();

	//context
	BInkmlContext inkmlContext(0,0);
	inkmlContext.setExistForce((BrPenMode)pPenDraw->m_nPenType);
	inkmlContext.setDefaultContextNoUseProperty((BrPenMode)pPenDraw->m_nPenType);
	pInkMLContextArr->Add(inkmlContext);

	//brush
	BrINT32 nBrushID = 0;
	BrFLOAT fBrushWidth = pPenDraw->m_nPenWidth;
	BrFLOAT fBrushHeight = pPenDraw->m_nPenWidth;
	BrCOLORREF nColor = BrRGB(pPenDraw->m_bRed, pPenDraw->m_bGreen, pPenDraw->m_bBlue);
	BInkmlBrush	inkmlBrush(nBrushID, fBrushWidth, fBrushHeight, nColor);
	inkmlBrush.setRasterOpAndTipValue((BrPenMode)pPenDraw->m_nPenType);
	pInkMLBrushArr->Add(inkmlBrush);

	//Point
	BArray<BrPoint> mCmPointArr;
	mCmPointArr.resize(pPenDraw->m_nPoint);
	BrINT32 x = 0, y = 0;
	for(BrINT32 i=0;i<pPenDraw->m_nPoint;i++)
	{
		x = BrTWIPtoCM(pPenDraw->m_pPoints[i].x) * 1000;
		y = BrTWIPtoCM(pPenDraw->m_pPoints[i].y) * 1000;

	 	mCmPointArr[i].x = x;
		mCmPointArr[i].y = y;
	}

	BArray<BrUINT> forceArr;
	if(inkmlContext.getExistForce())
	{
		for(BrINT32 i=0;i<pPenDraw->m_sFixPressure.size();i++)
			forceArr.Add(pPenDraw->m_sFixPressure.at(i));
	}

	pInkMLTraceArr->Add(BrNEW BInkmlTrace(0,nBrushID,mCmPointArr,forceArr));
	pFreeDraw->setInkmlRect(a_rRect);
	return pFrame;
}

BrINT32 CDocxConv::setDrawingInfo(CDocxDrawingML *pDocxDrawing, BrWORD nTextId, CFrame*& a_pInkMLFrame, const BrCHAR* a_pCurPartName, CFrame*& a_pChartExFrame, CFrame*& a_p3DShapeFrame)
{
	if(!pDocxDrawing)
		return 0;

	CFrame *pFrame = NULL;

	if( pDocxDrawing->m_pPenShapeName)
	{
		BCOfficeXShape *pShape = (BCOfficeXShape *)pDocxDrawing->m_pShape;
		if(!pShape)
			return -1;

		BCOfficeXShapeProperty *pProperty = pShape->GetShapeProperty();
		if(!pProperty)
			return -1;

		//SetTransform2D()�Լ��� officex_�迭���� �� ��ǥ �� ��ȯ, docxshape���� read�� �����ʹ� �̹� twip���� ��ȯ �� ��ǥ ��
		pShape->SetTransform2D(NULL);
		//[TID:423][��ȸ��]Rotated Frame Editing �� CLintList ����
		BRect oRect(pProperty->m_offset.x, pProperty->m_offset.y, pProperty->m_extent.cx, pProperty->m_extent.cy);

		pFrame = createPenFreeDrawFrame(pDocxDrawing->m_nPenID, oRect);
	}
#ifdef SUPPORT_INKML
	else if(pDocxDrawing->m_pShape && pDocxDrawing->m_pShape->m_nShape == SHAPE_CONTENTPART)
	{
		BCOfficeXContentPart* pContentPart = (BCOfficeXContentPart*)pDocxDrawing->m_pShape;
		pFrame = pContentPart->ConvertDocxContentPart(this, !pDocxDrawing->m_bFloating, a_pCurPartName);
		a_pInkMLFrame = pFrame;	
	}
#endif	//SUPPORT_INKML
	else if( pDocxDrawing->m_pShape ) 
	{
		//jjoo:2008-06-10:BCOfficeXShapePic �������
		BCOfficeXShape *pShape = pDocxDrawing->m_pShape;
		//SetTransform2D()�Լ��� officex_�迭���� �� ��ǥ �� ��ȯ, docxshape���� read�� �����ʹ� �̹� twip���� ��ȯ �� ��ǥ ��
		pShape->SetTransform2D(NULL);

		//[TID:423][��ȸ��]Rotated Frame Editing �� CLintList ����
		BrBOOL	bAnchor = (!pDocxDrawing->m_bFloating) ? BrTRUE : BrFALSE;

		//[2013.05.21][������][TID:15445] ���� ��� ũ�� ����
		BRect Rect(0,0,0,0);

		if(!pShape->GetShapeProperty())
			return SetErrorFReturn(CFilterErrorObj(kPoErrImportError, __FILE__, __LINE__));

		if((pDocxDrawing->m_nPctHeight != 0) || (pDocxDrawing->m_nPctWidth != 0))
		{
			BrSize RectSize = pDocxDrawing->ConvertRelativeToAbsoluteSize(m_pCurPage);
			if((pDocxDrawing->m_nPctHeight != 0) && (pDocxDrawing->m_nPctWidth != 0))
				Rect.setRect(
					pShape->GetShapeProperty()->m_offset.x, 
					pShape->GetShapeProperty()->m_offset.y,
					pShape->GetShapeProperty()->m_offset.x + RectSize.cx, 
					pShape->GetShapeProperty()->m_offset.y + RectSize.cy
				);
			else if((pDocxDrawing->m_nPctHeight != 0) && (pDocxDrawing->m_nPctWidth == 0))
				Rect.setRect(
					pShape->GetShapeProperty()->m_offset.x, 
					pShape->GetShapeProperty()->m_offset.y,
					pShape->GetShapeProperty()->m_extent.cx, 
					pShape->GetShapeProperty()->m_offset.y + RectSize.cy
				);
			else
				Rect.setRect(
					pShape->GetShapeProperty()->m_offset.x, 
					pShape->GetShapeProperty()->m_offset.y,
					pShape->GetShapeProperty()->m_offset.x + RectSize.cx, 
					pShape->GetShapeProperty()->m_extent.cy
				);
		}
		else
		{
			Rect.setRect(
				pShape->GetShapeProperty()->m_offset.x, 
				pShape->GetShapeProperty()->m_offset.y,
				pShape->GetShapeProperty()->m_offset.x + pShape->GetShapeProperty()->m_extent.cx, 
				pShape->GetShapeProperty()->m_offset.y + pShape->GetShapeProperty()->m_extent.cy
			);
		}
		BRect GRect(0,0,0,0);
		BRect ExtRect(0, 0, pShape->GetShapeProperty()->m_extent.cx, pShape->GetShapeProperty()->m_extent.cy);
		pFrame = ConvertShapeFromLockedCanvas(pShape, Rect, ExtRect, GRect, bAnchor);
		if(!pFrame)
			pFrame = MakeInvalidShape(Rect, bAnchor);
		if(!pFrame)
			return 0;

		if(pDocxDrawing->m_nPctHeight != 0 || pDocxDrawing->m_nPctWidth !=0)
		{
			pFrame->setHeightRelative((BrFLOAT)pDocxDrawing->m_nPctHeight / 1000);
			pFrame->setHeightRelativeType(pDocxDrawing->m_nSizeVRel);
			pFrame->setWidthRelative((BrFLOAT)pDocxDrawing->m_nPctWidth / 1000);
			pFrame->setWidthRelativeType(pDocxDrawing->m_nSizeHRel);			
			pFrame->setFrameRect(pFrame->getFrameRect());
		}
	}
	else if( pDocxDrawing->m_pShapePic ) 
	{
		BCOfficeXShape *pShape = (BCOfficeXShape *)pDocxDrawing->m_pShapePic;
		//SetTransform2D()�Լ��� officex_�迭���� �� ��ǥ �� ��ȯ, docxshape���� read�� �����ʹ� �̹� twip���� ��ȯ �� ��ǥ ��
		pShape->SetTransform2D(NULL);

		//[TID:423][��ȸ��]Rotated Frame Editing �� CLintList ����
		BrBOOL	bAnchor = !pDocxDrawing->m_bFloating;
		BRect Rect(pDocxDrawing->m_simplePos.cx, pDocxDrawing->m_simplePos.cy,
			pDocxDrawing->m_extent.cx, pDocxDrawing->m_extent.cy);
		
		if(a_pChartExFrame || a_p3DShapeFrame) //chartEx
		{
			pFrame = a_pChartExFrame == BrNULL ? a_p3DShapeFrame : a_pChartExFrame;
			BCOfficeXShapePic* pPicture = ((BCOfficeXShapePic*)pShape);
			BCOfficeXBlipFillStyle* pBlipFill = pPicture->m_pBlipFill;
			ShapeType dType = SHAPE_None;
			if(pPicture->m_pShapeProperty->m_pPresetShape)
				dType = (ShapeType)pPicture->m_pShapeProperty->m_pPresetShape->m_nShapeType;
			else
				dType = SHAPE_Rectangle;

			if(pPicture->m_pNVPicProperty && pPicture->m_pNVPicProperty->m_cNvPicPr && pPicture->m_pNVPicProperty->m_cNvPicPr->m_bPreferRelativeResize == BrFALSE)
				pFrame->setRelativeToOrgPictureSize(BrFALSE);

			pFrame->setFrameRect(Rect);
			if(a_p3DShapeFrame && a_p3DShapeFrame->getBorder())
			{

			}
			else
			{
				BrShape *pBwpShape = NULL;
				pBwpShape = BrShape::createShape(dType, *pFrame->getFrameRect());
				pFrame->setBorder( pBwpShape );
			}
			pShape->ConvertDocxOfficexShape(pFrame);
		}
		else
			pFrame = ConvertImageFromLockedCanvas(pShape, Rect, bAnchor);

		if(!pFrame)
			pFrame = MakeInvalidShape(Rect, bAnchor);
		if(!pFrame)
			return SetErrorFReturn(CFilterErrorObj(kPoErrImportError, __FILE__, __LINE__));
	}
	else if( pDocxDrawing->m_pShapeGroup )
	{
		//jjoo:2009-01-19:LockedCanvas ������ ������ �׷����� ó����.
		BCOfficeXShapeGroup *pShapeGroup = pDocxDrawing->m_pShapeGroup;

		//[2013.04.18][������][TID:14747] DML �׸��� ĵ���� -> Group Shape���� �����Ͽ� ����
		//GroupShapePr�� ���� Drawing �� ũ��� ������ ������.
		if(pShapeGroup->m_bDMLCanvas)
		{
			pDocxDrawing->m_pShapeGroup->m_pGroupShapeProperty = BrNEW BCOfficeXShapeProperty(m_pPackage);
			pDocxDrawing->m_pShapeGroup->m_pGroupShapeProperty->m_childOffset.x = 0;
			pDocxDrawing->m_pShapeGroup->m_pGroupShapeProperty->m_childOffset.y = 0;
			pDocxDrawing->m_pShapeGroup->m_pGroupShapeProperty->m_childExtent.cx = pDocxDrawing->m_extent.cx;
			pDocxDrawing->m_pShapeGroup->m_pGroupShapeProperty->m_childExtent.cy = pDocxDrawing->m_extent.cy;
		}

		if(pShapeGroup->m_bLockedCanvas)
		{
			if(pDocxDrawing->m_extent.cx > 0)
				m_fLockedCanvasRatio = pDocxDrawing->m_pShapeGroup->m_pGroupShapeProperty->m_extent.cx / (BrFLOAT)pDocxDrawing->m_extent.cx;
		}

		if (pShapeGroup->GetShapeProperty())
		{
			pShapeGroup->GetShapeProperty()->m_extent.cx = TWIPtoEMU(pDocxDrawing->m_extent.cx);
			pShapeGroup->GetShapeProperty()->m_extent.cy = TWIPtoEMU(pDocxDrawing->m_extent.cy);
		}

		//[2013.05.30][������][TID:15441] GroupFrame ��� ũ�� ����.(Sample �Ӹ��۹ٴڱ�2~4)
		BRect GrpRect(0,0,0,0);
		if((pDocxDrawing->m_nPctHeight != 0) || (pDocxDrawing->m_nPctWidth != 0))
		{
			BrSize RectSize = pDocxDrawing->ConvertRelativeToAbsoluteSize(m_pCurPage);

			if((pDocxDrawing->m_nPctHeight != 0) && (pDocxDrawing->m_nPctWidth != 0))
			{
				pShapeGroup->m_pGroupShapeProperty->m_extent.cx = TWIPtoEMU(RectSize.cx);
				pShapeGroup->m_pGroupShapeProperty->m_extent.cy = TWIPtoEMU(RectSize.cy);
			}
			else if((pDocxDrawing->m_nPctHeight != 0) && (pDocxDrawing->m_nPctWidth == 0))
				pShapeGroup->m_pGroupShapeProperty->m_extent.cy = TWIPtoEMU(RectSize.cy);
			else
				pShapeGroup->m_pGroupShapeProperty->m_extent.cx = TWIPtoEMU(RectSize.cx);
		}
		
#ifdef DANDONG_SMARTART
		// [DanDong2] [2015.04.17] PO���� ����/������ SmartArt����(docxȭ��)�� PO���� �ٽ� ��������
		// ������������ ǥ�õǴ� ������ ����(CNZ-6534)
		// PO���� SmartArt�� ������ �����ϸ� �׷쵵������ �����ȴ�. �̶� �׷쵵���� �Ӽ��� <wp:inline>���� �Ǹ�
		// �׷쵵���� ũ������(<a:xfrm>)�� <a:chOff>, <a:chExt>�� ���Ե��� �ʴ´�.
		// inline�Ӽ��� ���Ͽ� <a:chOff>, <a:chExt>�� �����Ҽ��� �ְ� �������� �������� �ִ�.
		// �׷��� �Ʒ��� �ڵ�, ShapeGroup->SetTransform2D(NULL);�� ������ �� <a:chOff>, <a:chExt>�� �ش��� ������
		// �ݵ�� �����ϴ°����� �˰� ��ǥ����� �ϱ⶧���� �ش� ������ �߻��Ѵ�.
		// �ش� ���� ���� ��쿡�� <a:off>, <a:ext>�� ����� ��ġ��Ű���� �Ѵ�.(�ߺ�ȭ���� �м��غ��� �׷��� �ǿ�����)

		BCOfficeXShapeProperty* pGroupProperty = pShapeGroup->GetShapeProperty();
		if (!pGroupProperty)
			return SetErrorFReturn(CFilterError(kPoErrCorruptFile));
		if (pGroupProperty->m_childOffset.x == -1 && pGroupProperty->m_childOffset.y == -1)
		{
			pGroupProperty->m_childOffset.x = pGroupProperty->m_offset.x;
			pGroupProperty->m_childOffset.y = pGroupProperty->m_offset.y;
		}

		if (pGroupProperty->m_childExtent.cx == -1 && pGroupProperty->m_childExtent.cy == -1)
		{
			pGroupProperty->m_childExtent.cx = pGroupProperty->m_extent.cx;
			pGroupProperty->m_childExtent.cy = pGroupProperty->m_extent.cy;
		}

#endif // DANDONG_SMARTART

		//SetTransform2D()�Լ��� officex_�迭���� �� ��ǥ �� ��ȯ, docxshape���� read�� �����ʹ� �̹� twip���� ��ȯ �� ��ǥ ��
		pShapeGroup->SetTransform2D(NULL);
		GrpRect.setRect(0, 0, pShapeGroup->m_pGroupShapeProperty->m_extent.cx, pShapeGroup->m_pGroupShapeProperty->m_extent.cy);
		
		BRect ExtRect(0, 0, pDocxDrawing->m_extent.cx, pDocxDrawing->m_extent.cy);
		//BRect GrpRect(0, 0, pShapeGroup->m_pGroupShapeProperty->m_extent.cx, pShapeGroup->m_pGroupShapeProperty->m_extent.cy);
		BrBOOL bAnchorType = !pDocxDrawing->m_bFloating;
		BRect Rect(GrpRect);
		pFrame = createFrame(GROUPFRAME, &Rect, bAnchorType, getPageNum(), BrTRUE);
		if(!pFrame)
			pFrame = MakeInvalidShape(Rect, bAnchorType);
		if(!pFrame)
			return SetErrorFReturn(CFilterErrorObj(kPoErrImportError, __FILE__, __LINE__));

		if(pDocxDrawing->m_nPctHeight != 0 || pDocxDrawing->m_nPctWidth !=0)
		{
			pFrame->setHeightRelative((BrFLOAT)pDocxDrawing->m_nPctHeight / 1000);
			pFrame->setHeightRelativeType(pDocxDrawing->m_nSizeVRel);

			pFrame->setWidthRelative((BrFLOAT)pDocxDrawing->m_nPctWidth / 1000);
			pFrame->setWidthRelativeType(pDocxDrawing->m_nSizeHRel);
		}
		//[2013.07.24][������][M34552]Canvas Frame Check
		if(pShapeGroup->m_bDMLCanvas)
			pFrame->setDrawingCanvas(BrTRUE);

		if(bAnchorType)
		{
			m_nCurParaHgt += pFrame->height();
		}
		else	//Floating�϶� ó��
		{
			setDrawingFrameOnlyFloating(pFrame, pDocxDrawing);
		}

		ConvertLockedData(pShapeGroup, pDocxDrawing, pFrame, a_pCurPartName);
	}
	else if(pDocxDrawing->m_pGraphicData)
	{
		BCOfficeXGraphicChart *pGraphicData = (BCOfficeXGraphicChart *)pDocxDrawing->m_pGraphicData;

		BrBOOL	bAnchor = !pDocxDrawing->m_bFloating;
		BRect Rect(0, 0, pDocxDrawing->m_extent.cx, pDocxDrawing->m_extent.cy);
		BrINT32 nGraphicType =  ((*(BCOfficeXGraphicData*)(&*pGraphicData))).m_nGraphicType;

		pFrame = ConvertImageFromChart(pGraphicData, Rect, bAnchor);

		if(nGraphicType == BoraOfficeXGraphicTypeChartEx)
		{
			a_pChartExFrame = pFrame;
			pFrame->setLockRectValue(BrTRUE);
			pFrame->setLockEditing(BrTRUE);
		}

		if(!pFrame)
			pFrame = MakeInvalidShape(Rect, bAnchor);
		if(!pFrame)
			return SetErrorFReturn(CFilterErrorObj(kPoErrImportError, __FILE__, __LINE__));
	}
	else if(pDocxDrawing->m_pGraphicDataDgm)
	{
		BrBOOL	bAnchorType = !pDocxDrawing->m_bFloating;
#ifdef DANDONG_SMARTART
		// [2015.09.18] SmartArtǥ��ũ�⸦ rect�� �ѱ涧���� (0, 0)�� �������� �ϹǷ� right, top���� 
		// �ʺ�, ���̰����� 1�� ����� �Ѵ�.
		// �̷��� ���� ������ CDocxConv::convertRatioFontSizeLockedCanvas()���� ExtRect�� GRect�� 
		// ���̷� ���Ͽ� ������üũ�⿡ ������ �ְ� �ȴ�.
		BRect	ExtRect(0, 0, pDocxDrawing->m_extent.cx - 1, pDocxDrawing->m_extent.cy - 1);
#else
		BRect	ExtRect(0, 0, pDocxDrawing->m_extent.cx, pDocxDrawing->m_extent.cy);
#endif // DANDONG_SMARTART
		
		BCOfficeXGraphicData * pGraphicData = (BCOfficeXGraphicData *)pDocxDrawing->m_pGraphicDataDgm;		

		if(pGraphicData)
		{
 			BRect GRect;

			if(pGraphicData->m_nGraphicType == BoraOfficeXGraphicTypeDiagrame)	//SHAPE_GRAPHICFRAME
			{
				CFrame *pFrame = NULL;
				BCOfficeXGraphicDiagram * pGraphicDataDgm = (BCOfficeXGraphicDiagram *)pGraphicData;

				BrUINT32 nSize = pGraphicDataDgm->m_ShapeArray.size();

				if(nSize)
				{
					BCOfficeXShape* pDgmShape;		
					
					BrPoint offset;
					BRect Rect;							
					CFrame* pGFrame=BrNULL;
					BrBOOL bShapeGroup = BrFALSE;

					for(BrUINT32 i = 0; i < nSize; i++)
					{
						pDgmShape = pGraphicDataDgm->m_ShapeArray.at(i);
						
						offset.x = ((BCOfficeXShapeNormal*)pDgmShape)->m_pShapeProperty->m_offset.x;
						offset.y = ((BCOfficeXShapeNormal*)pDgmShape)->m_pShapeProperty->m_offset.y;						
						Rect.setRect(offset.x, offset.y, ((BCOfficeXShapeNormal*)pDgmShape)->m_pShapeProperty->m_extent.cx + offset.x, ((BCOfficeXShapeNormal*)pDgmShape)->m_pShapeProperty->m_extent.cy + offset.y);
						
						if(i == 0)	//GroupFrame = GraphicFrame
						{
							GRect.setRect(Rect.nLeft,Rect.nTop,Rect.nRight,Rect.nBottom);
#ifndef DANDONG_SMARTART//[2011.12.12][������][TID:1275] �ܵ� SmartArt Export Merge
							pGFrame = createFrame(GROUPFRAME, &Rect, bAnchorType, getPageNum(), BrTRUE);
#else
							// [2011.12.7][dandong2] GROUPFRAME�� �ƴ� DIAGRAMXFRAME���� ó��
							pGFrame = createFrame(DIAGRAMXFRAME, &Rect, bAnchorType, getPageNum(), BrTRUE);
#endif							

#ifdef DANDONG_SMARTART_INSERT
							((CSmartArt*)pGFrame)->setSmartArtDiagramInfo(theBWordDoc->getSmartArtDiagramInfo());
#endif //DANDONG_SMARTART_INSERT

							//Misty - 2009.08.12 : GraphicFrame �Ӽ� ó��
							pFrame = ConvertShapeFromLockedCanvas(pDgmShape,Rect,ExtRect,GRect,bAnchorType , BrTRUE);
#ifdef DANDONG_SMARTART
							// ��̵����� ����� ��Ÿ���� FLOATFRAME�� ��̵����� �ּҸ� �����ϱ�
							// �׷��� �������� �Ӽ������ �ݿ��� ����� �ȴ�.
							pFrame->setGroupParent(pGFrame);
#endif // DANDONG_SMARTART
						}
						else		//Group���� frame
						{
#ifndef DANDONG_SMARTART
							if(pDgmShape->m_nShape == 1)			//SHAPE_NORMAL
								pFrame = ConvertShapeFromLockedCanvas(pDgmShape,Rect,ExtRect,GRect,bAnchorType, BrTRUE);
							else if(pDgmShape->m_nShape == 2)		//SHAPE_PICTURE
								pFrame = ConvertImageFromLockedCanvas(pDgmShape,Rect,bAnchorType);
							else
								pFrame = MakeInvalidShape(Rect, bAnchorType);							
#else
							if(pDgmShape->m_nShape == 1)			//SHAPE_NORMAL
								pFrame = ConvertSmartArtFromLockedCanvas(pDgmShape,Rect,ExtRect,GRect,BrFALSE, BrTRUE);

							if(pFrame)
							{
								((CSmartArtEntry*)pFrame)->m_nFrameIndex = ((BCOfficeXShapeNormal*)pDgmShape)->m_pShapeProperty->m_nShapeIndex;
								((CSmartArtEntry*)pFrame)->m_bConn = ((BCOfficeXShapeNormal*)pDgmShape)->m_pShapeProperty->m_bConn;
								((CSmartArtEntry*)pFrame)->m_nZOrder = ((BCOfficeXShapeNormal*)pDgmShape)->m_pShapeProperty->m_nZOrder;

								pFrame->setGroupParent(pGFrame);
							}
#endif // DANDONG_SMARTART
							if ( pFrame )	{
								//pFrame->setAutoWidthFlag(BrTRUE);								
							}
							bShapeGroup = BrTRUE;
						}	//Group���� frame
						
						if(!pFrame)
							pFrame = MakeInvalidShape(Rect, bAnchorType);

						if(!pFrame)
							return -1;

						if(pFrame)
						{
							if(bShapeGroup)
							{
								bShapeGroup = BrFALSE;
								CFrameList *pFrameList = (CFrameList*)pGFrame->getSubFrame();
								if(pFrameList)
									pFrameList->insertAtTail(pFrame,pFrame->getZindex());
							}
							else
							{
#ifdef DANDONG_SMARTART
								if(pDocxDrawing->m_bFloating)
									setDrawingFrameOnlyFloating(pGFrame, pDocxDrawing);
								else
									m_nCurParaHgt += pFrame->height();

								// [2014.01.06][Dandong3] SmartArt GroupFrame�� Zindexó��(���� 46814 �����Ϸ�)
								//[2013.06.25][������]noChangeAspect ���μ��� ���� ����
								//���� Lock�߿� �ϳ��� �б� ������ �Ʒ��Ͱ����� ������ Convert�� �Լ��� �� �ʿ�.
								if(pDocxDrawing->m_pGraphicFrameLocks)
									pGFrame->setNoChangeAspect(pDocxDrawing->m_pGraphicFrameLocks->m_bNoChangeAspect);


								//[2013.01.02][������] Hidden Data Setting
								pGFrame->setHiddenFlag(pDocxDrawing->m_bHidden);

								//effectextext setting
								pGFrame->setExternalMargin(pDocxDrawing->m_rEffectExtent);

								pGFrame->setZindex(pDocxDrawing->m_nRelativeHeight);
								pGFrame->setPlaceInCell(pDocxDrawing->m_bLayoutInCell);

								// [2016.01.16] SmartArt������ �����ɿ� ������ Shading�� �����Ҷ� MS����ó�� SmartArt������ü�� ��� Shading�� 
								// ������� �ʰ� �����ɿ��� Shading�� ����Ǵ� ������ ����(ZPD-23959)
								// Shading�� ����� SmartArt������ �ִ� word������ PO���� �����Ҷ� Shadingȿ���� ��Ȯ�� ǥ�õǵ��� nTextId��
								// �Ķ���ͷ� �Բ� �Ѱ��ش�.
								AddShapeFrame(pGFrame, nTextId);
#else // DANDONG_SMARTART
								AddShapeFrame(pGFrame);//AddShapeFrame(pFrame);
#endif // DANDONG_SMARTART

								//Misty - 2009.08.12 : GraphicFrame �Ӽ� ó��
								CFrameList *pFrameList = (CFrameList*)pGFrame->getSubFrame();	
								if(pFrameList)
									pFrameList->insertAtTail(pFrame,pFrame->getZindex());
							}
						}
					}

#ifdef DANDONG_SMARTART
					// [2015.05.27] SmartArt�� �ڽĵ����鿡 spid�� �Ҵ��ϱ�(ZPD-12107��������)
					// save�� �� <p:cNvPr>�±��� id�Ӽ��� �Ҵ�Ǵ� ������ �ȴ�. save�� ��ü�� �ĺ��ϱ� ���� �߿��� ����
					if (pGFrame && pGFrame->getSubFrame()) {
						CFrameList *pFrameList = (CFrameList*)pGFrame->getSubFrame();
						pFrameList->setPage(m_pCurPage, BrNULL, NESTALL);
						pFrameList->setParentFrame(pGFrame);
					}
	#ifdef DOCX_SPID
					pGFrame->setDocxSpid(pDocxDrawing->m_nObjectID);
	#endif //DOCX_SPID
#endif // DANDONG_SMARTART
				}
			}
	
			return BrTRUE;
		}
		else	//!BoraOfficeXGraphicTypeDiagrame
		{
			BrBOOL	bAnchor = !pDocxDrawing->m_bFloating;
			BRect Rect(0, 0, pDocxDrawing->m_extent.cx, pDocxDrawing->m_extent.cy);

			pFrame = MakeInvalidShape(Rect, bAnchor);
			if(!pFrame)
				return -1;
		}
	}
	else if(pDocxDrawing->m_p3DShape)
	{
		BCOfficeXGraphicModel3D* p3DShape = pDocxDrawing->m_p3DShape;
		BrBOOL	bAnchor = !pDocxDrawing->m_bFloating;
		BRect Rect(0, 0, pDocxDrawing->m_extent.cx, pDocxDrawing->m_extent.cy);
		pFrame = createFrame(PICTUREFRAME, &Rect, bAnchor, getPageNum(), BrTRUE);

		BrShape *pShape = NULL;
		pShape = BrShape::createShape(SHAPE_Rectangle, *pFrame->getFrameRect());
		pFrame->setBorder( pShape );

		pFrame->setLockRectValue(BrTRUE);
		pFrame->setLockEditing(BrTRUE);

		a_p3DShapeFrame = pFrame;		

#ifdef SUPPORT_3DOBJECT
		p3DShape->convertGraphicModel3DToBrShape(pFrame->getBorder());
#else
		BrModel3DAttr* pModel3DAttr = pFrame->getBorder()->getModel3DAttr();
		// image
		pModel3DAttr->setModelID(p3DShape->m_str3DGLBRelID);
		pModel3DAttr->setModelName(p3DShape->m_strSrcPartName);
		pModel3DAttr->setModel3DDomDocument((domDocument*)(p3DShape->m_pModel3DDom->GetDOMDocument()));
		BString attrSrcUrl = m_pPackage->GetHyperlinkName(DOCX_PARTNAME_DOCUMENT, const_cast <BrCHAR*> (p3DShape->m_strAttrSrcUrl.latin1()));
		pModel3DAttr->setStrAttrSrcUrl(attrSrcUrl);		
#endif // SUPPORT_3DOBJECT

		if(p3DShape->spPr)
			DMLConverter::ConvertShapeProperty(p3DShape->spPr, pFrame);

	}
	else	//jjoo:2009-01-08:SmartArt�� �簢������ ǥ�ø�.
	{
		BrBOOL	bAnchor = !pDocxDrawing->m_bFloating;
		BRect Rect(0, 0, pDocxDrawing->m_extent.cx, pDocxDrawing->m_extent.cy);

		pFrame = MakeInvalidShape(Rect, bAnchor);
		if(!pFrame)
			return -1;
	}

	if( !pFrame)
		return -1;

	if(pDocxDrawing->m_bFloating)
		setDrawingFrameOnlyFloating(pFrame, pDocxDrawing);
	else
		m_nCurParaHgt += pFrame->height();
	
	// NOTE! https://confluence.infraware.net:8443/pages/viewpage.action?pageId=29132196
	// auto resize scalar
	pFrame->AutoResize()->reset_initial_size(pDocxDrawing->m_extent.cx, pDocxDrawing->m_extent.cy);

	//[2013.06.25][������]noChangeAspect ���μ��� ���� ����
	//���� Lock�߿� �ϳ��� �б� ������ �Ʒ��Ͱ����� ������ Convert�� �Լ��� �� �ʿ�.
	if(pDocxDrawing->m_pGraphicFrameLocks)
		pFrame->setNoChangeAspect(pDocxDrawing->m_pGraphicFrameLocks->m_bNoChangeAspect);


	//[2013.01.02][������] Hidden Data Setting
	pFrame->setHiddenFlag(pDocxDrawing->m_bHidden);

	//effectextext setting
	pFrame->setExternalMargin(pDocxDrawing->m_rEffectExtent);

	pFrame->setZindex(pDocxDrawing->m_nRelativeHeight);
	pFrame->setPlaceInCell(pDocxDrawing->m_bLayoutInCell);

	if((a_p3DShapeFrame || a_pChartExFrame) && pDocxDrawing->m_bAlternateContent != BrFALSE)
	{
		//fallback chartEx�� �̹� �߰� �� frame
	}
	else
		AddShapeFrame(pFrame, nTextId);

	//[2013.09.11][������] ���� name, id setting
	pFrame->setIDForSeclectionPane(pDocxDrawing->m_nObjectID);
#ifdef DOCX_SPID
	pFrame->setDocxSpid(pDocxDrawing->m_nObjectID);
#endif //DOCX_SPID
	if(pDocxDrawing->m_pObjectName)
	{
		BString strObjName;
		BrINT32 nStrLen = BrStrLen(pDocxDrawing->m_pObjectName);

		BrUSHORT *pOutput = (BrUSHORT*)BrMalloc((nStrLen + 1)*2);
		memset(pOutput, 0, (nStrLen + 1)*2);
		BrINT32 nLen = BrMultiByteToWideChar( CP_UTF8, (BrLPCSTR)pDocxDrawing->m_pObjectName, nStrLen, (BrLPWSTR)pOutput, nStrLen);
		for (BrINT32 i = 0; (i <= nLen) && pOutput[i]; i++)
			strObjName.append(BChar(pOutput[i]));

		pFrame->setNameForSelectionPane(strObjName);

		BR_SAFE_FREE(pOutput);
	}
	if(pDocxDrawing->m_pDescr) {
		BString descriptionString;
		descriptionString.setMultiByte(CP_UTF8, pDocxDrawing->m_pDescr);
		pFrame->setAltTextDescription(descriptionString);
	}
	if(pDocxDrawing->m_pTitle) {
		BString titleString;
		titleString.setMultiByte(CP_UTF8, pDocxDrawing->m_pTitle);
		pFrame->setAltTextTitle(titleString);
	}

	DocxField* pDocxField  = BrNULL;
	DocxFieldManager * pDocxFieldManager = getDocxLoader()->getDocxFieldManager();
	pDocxField = pDocxFieldManager->peek();

	if(pDocxField)
	{
		if(pDocxField->InstanceOf(eDocx_RelationField) && pDocxField->IsDrawingHyper())
		{
			DocxRelationField* pDocxRealationField = (DocxRelationField*)pDocxField;
			pDocxRealationField->SetCurFldCharType(eWSTFLDCHARTYPE_end);
			pDocxRealationField->ConvertEndRelationField(getCurLineList(), 0 );//, pFrame->getID());
			pFrame->setFieldID( pDocxField->GetFieldID() );
			pDocxFieldManager->removePeek();
		}
		else
			BRTHREAD_ASSERT(0);
	}

	//hnsong:2012-01-19 [M-4879] memo import
	return pFrame->getID();
}

void CDocxConv::setRealText(CDocxText *pDocxText)
{
	CLineList *pLineList = getCurLineList();

	if(m_nParaAttIDForPageBreak != -1)
		m_bExistTextAfterPageBreakInSamePara = BrTRUE;

	if( pDocxText->m_pStrCode )
		createText(pLineList, pDocxText);
}

void CDocxConv::setDrawingFrameOnlyFloating(CFrame *pFrame, CDocxDrawingML *pDocxDrawing)
{
	if(!pFrame || !pDocxDrawing)
		return;

	pDocxDrawing->ConvertFramePosition(pFrame);
	pFrame->setAllowOverlap(pDocxDrawing->m_bAllowOverlap);	//jjoo:2008-12-18:Add
	//ǥ ���� ��ġ
	pFrame->setPlaceInCell(pDocxDrawing->m_bLayoutInCell);

	switch (pDocxDrawing->m_nWrappingMode) 
	{
	case 1: //��/�Ʒ� 
		pFrame->setRunArroundType(FULL_RUN_AROUND);
		pDocxDrawing->m_rWrapRect.nTop = pDocxDrawing->m_nDistT;
		pDocxDrawing->m_rWrapRect.nBottom = pDocxDrawing->m_nDistB;
		break;
	case 2: //���簢��
		pFrame->setRunArroundType(PART_RUN_AROUND);
		pDocxDrawing->m_rWrapRect.nTop = pDocxDrawing->m_nDistT;
		pDocxDrawing->m_rWrapRect.nBottom = pDocxDrawing->m_nDistB;
		pDocxDrawing->m_rWrapRect.nLeft = pDocxDrawing->m_nDistL;
		pDocxDrawing->m_rWrapRect.nRight = pDocxDrawing->m_nDistR;
		break;

	case 3: //��, ��, �پ�
		pFrame->setRunArroundType(NO_RUN_AROUND);
		//pFrame->setAnchorFlag((BYTE)pFSPA->fAnchorLock); //�پ��� ��� set
		break;
	case 4://�����ϰ�
	case 5://����
		pFrame->setRunArroundType((pDocxDrawing->m_nWrappingMode==4)?TIGHT_RUN_AROUND:THROUGH_RUN_AROUND);
		pDocxDrawing->m_rWrapRect.nTop = pDocxDrawing->m_nDistT;
		pDocxDrawing->m_rWrapRect.nBottom = pDocxDrawing->m_nDistB;
		pDocxDrawing->m_rWrapRect.nLeft = pDocxDrawing->m_nDistL;
		pDocxDrawing->m_rWrapRect.nRight = pDocxDrawing->m_nDistR;
		break;
	}

	if(pDocxDrawing->m_bAnchorLocked)
		pFrame->setLockAnchor(BrTRUE);

	pFrame->setUnderBasic(pDocxDrawing->m_nAnchorBehindDoc> 0 ? BrTRUE : BrFALSE); //������, �Ʒ�

	//���簢��, �����ϰ�, �����Ͽ� �ϴ� wrapText setting
	if(pDocxDrawing->m_nWrappingMode == 2 || pDocxDrawing->m_nWrappingMode == 4 || pDocxDrawing->m_nWrappingMode == 5)
	{
		if( 0 == strcmp(pDocxDrawing->m_pWrapText, "largest"))
			pFrame->setWrapTextType(BR_WRAP_TEXT_LARGEST_ONLY);
		else if( 0 == strcmp(pDocxDrawing->m_pWrapText, "right"))
			pFrame->setWrapTextType(BR_WRAP_TEXT_RIGHT_ONLY);
		else if( 0 == strcmp(pDocxDrawing->m_pWrapText, "left"))
			pFrame->setWrapTextType(BR_WRAP_TEXT_LEFT_ONLY);
		else if( 0 == strcmp(pDocxDrawing->m_pWrapText, "bothSides"))
			pFrame->setWrapTextType(BR_WRAP_TEXT_BOTH_SIDES);
	}

	if(pFrame->getBorder() && pDocxDrawing->m_PolygonData.GetSize() > 0)
		pFrame->getBorder()->setTextWrapPolygon(pDocxDrawing->m_PolygonData);

	BRect pRect;
	pRect.nTop = pDocxDrawing->m_rWrapRect.nTop;
	pRect.nBottom = pDocxDrawing->m_rWrapRect.nBottom;
	pRect.nLeft = pDocxDrawing->m_rWrapRect.nLeft;
	pRect.nRight = pDocxDrawing->m_rWrapRect.nRight;
	
	pFrame->setRunMargin(&pRect);
}

void CDocxConv::AddShapeFrame(CFrame* pFrame, BrWORD nTextID)
{
	if(!pFrame)
	{
		SetErrorFReturn(CFilterError(kPoErrArgumentNull));
		return;
	}
	CLineList* pLineList = getCurLineList();
	CLine* pLine = pLineList->getLast();
	if(!pLine)
		pLine = m_pDocxPara->CreateLine(pLineList);
	
	CCharSetArray *pCharSetArray = pLine->getCharSetArray();
	CCharSet cCharSet;
	if( PO_TEXTATT_BASE::notSettedID != nTextID )	//[2012.06.22][������][TID:7270] ���� TextAttr ���� ����
	{
		const PoTextAtt* pTextAtt = theBWordDoc->getTextAttHandler()->getTextAtt(nTextID);
		cCharSet.setAttrID(nTextID);
		//[2013-03-06][toypilot]rPr�� biti setting
		if(BrTRUE == pTextAtt->getBiDi())
			pLine->setBidiFlag(BrTRUE);
	}
	else if(pFrame->getSubClass() != DROPCAPFRAME && m_pDocxPara && m_pDocxPara->m_pDocxTextAtt) {
		BrWORD textAttID = m_pDocxPara->m_wTextAttID;
		cCharSet.setAttrID(textAttID);
	}
	else
		cCharSet.setAttrID(0);

	if( m_pDocxPara )
		m_pDocxPara->m_bText = BrTRUE;

	cCharSet.setCode( (BrWORD)pFrame->getID() );
	cCharSet.setLinkSubType(LINKTYPE::ANCHOR, LINKTYPE::STANDARD);
	pCharSetArray->Add(cCharSet);
	pLine->setDirtyFlag(BrTRUE);

	//[2013.10.01][������] ������ �޸����
	BrINT32 nSize = pCharSetArray->GetSize();
	if(nSize >= 2 && pCharSetArray->getCharSet(nSize - 2)->getLinkType() == LINKTYPE::MEMO)
		pFrame->setMemoFlag(BrTRUE);

	CLineList* pFrameListList = (CLineList*) pFrame->getSubFrame();
	if(pFrame->GetClass() == FLOATFRAME && pFrameListList && pFrameListList->getTotalLine() > 0)
	{
		CLine* pLastLIne = pFrameListList->getLast();
		if(!pLastLIne->isCRAtLastPos())
			ftLibrary::AddCharSet(pLastLIne, ASCII_CODE_CR);
	}

	pFrame->setAnchorLine(pLine);
	if(m_bHeaderFooter)
		theBWordDoc->getAFrameList4HeaderFooter()->insertAtTail(pFrame,pFrame->getZindex());
	else
		theBWordDoc->getAFrameList()->insertAtTail(pFrame,pFrame->getZindex());

	if (pFrame->isAnchored() && m_pDocxPara)
		m_pDocxPara->m_nParaWidth += pFrame->width();
}

BrBOOL CDocxConv::readDocument(CallbackParam *pParam)
{
	BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);

	pParam->pCurrentInstance = this;
	return m_pPackage->ReadMain(pParam, CORE_DOCUMENT_PART_TYPE, BrTRUE);
}

BrBOOL CDocxConv::createPage()
{	
	if(m_pCurSectionInformation == BrNULL)
		return SetErrorFReturn(CFilterErrorObj(kPoErrImportError, __FILE__, __LINE__));
	
	CPage *pPage = BrNEW CPage();
	if(!pPage)
		return SetErrorFReturn(CFilterErrorObj(kPoErrMemory, __FILE__, __LINE__));

	CPageArray *pPageArray= theBWordDoc->getPageArray();
	pPageArray->Add(pPage);
	pPage->setPageArray(pPageArray);
	m_pCurPage = pPage;

	SetPageProperty(pPage);

	return BrTRUE;
}

BrBOOL CDocxConv::SetPageProperty(CPage *a_pPage)
{
	if(a_pPage == BrNULL)
		return SetErrorFReturn(CFilterErrorObj(kPoErrImportError, __FILE__, __LINE__));
	// PaperSize
	(a_pPage->getPaperSize())->setWidth( m_pCurSectionInformation->getPageWidth() );
	(a_pPage->getPaperSize())->setHeight(m_pCurSectionInformation->getPageHeight());

	(a_pPage->getPaperSize())->setSizeID(m_pCurSectionInformation->getPageSizeID());
	(a_pPage->getPaperSize())->setDirection(((a_pPage->width() > a_pPage->height()) ? LANDSCAPE : PORTRAIT )); //����/����

	a_pPage->setPageNum( theBWordDoc->getPageArray()->GetSize() );

	BrINT32 nColWidthForEqualCols = 0;

	if(m_pDocxLoader->m_pDocxBackground )
		m_pDocxLoader->m_pDocxBackground->CreatePageBackGround(m_pCurPage->width(), m_pCurPage->height());

	// Column
	createColumn( a_pPage->getColumn(), nColWidthForEqualCols );

	createBasicFrame( m_pCurPage->getBFrameList(), nColWidthForEqualCols );

	return BrTRUE;
}

#ifdef NEW_COLUMN
void CDocxConv::createColumn(CColumn *pCol, BrINT32& nColWidthForEqualCols) 
{
	pCol->setTopMar( BrABS(m_pCurSectionInformation->getPageMargin().top) );
	pCol->setBtmMar( BrABS(m_pCurSectionInformation->getPageMargin().bottom) );
	pCol->setLeftMar( BrABS(m_pCurSectionInformation->getPageMargin().left + m_pCurSectionInformation->getGutterMargin() ) );
	pCol->setRightMar( BrABS(m_pCurSectionInformation->getPageMargin().right ) );
	//pCol->setColumnCount(0, (BYTE)(m_pCurSectionInformation->getColumnNum()) );
	pCol->setDirection( 0 );    // GARO
	pCol->getSubRegionArray()->setRegionHeight(0, m_pCurSectionInformation->getPageHeight() - (pCol->topMar() + pCol->btmMar() ));
	pCol->getSubRegionArray()->setRegionSpace(0, 0);


	if ( (pCol->getColumnCount(0)) < 2) // single column
	{  
		pCol->getSubRegionArray()->setColumnWidthAndSpace(0, 0, m_pCurSectionInformation->getPageWidth() - (pCol->leftMar() + pCol->rightMar()), m_pCurSectionInformation->getColumnColSpaceVal(0));
	}
	else
	{   
		if(m_pCurSectionInformation->getColumnEqualWidth())
		{
			nColWidthForEqualCols =  ((m_pCurSectionInformation->getPageWidth() - (pCol->leftMar() + pCol->rightMar())) / m_pCurSectionInformation->getColumnNum());
			for (BrINT32 i = 0; i < (pCol->getColumnCount(0)); i++) 
			{
				pCol->getSubRegionArray()->setColumnWidthAndSpace(0, i, nColWidthForEqualCols, nColWidthForEqualCols );
			}
		}
		else
		{
			for (BrINT32 i = 0; i < m_pCurSectionInformation->getColumnNum(); i++) 
			{
				pCol->getSubRegionArray()->setColumnWidthAndSpace(0, i, m_pCurSectionInformation->getColumnColWidthVal(i), m_pCurSectionInformation->getColumnColSpaceVal(i));
			}
		}
	}
}
#else
void CDocxConv::createColumn(CColumn *pCol, BrINT32& nColWidthForEqualCols) 
{
	pCol->setTopMar( BrABS(m_pCurSectionInformation->getPageMargin().top) );
	pCol->setBtmMar( BrABS(m_pCurSectionInformation->getPageMargin().bottom) );
	pCol->setLeftMar( BrABS(m_pCurSectionInformation->getPageMargin().left + m_pCurSectionInformation->getGutterMargin() ) );
	pCol->setRightMar( BrABS(m_pCurSectionInformation->getPageMargin().right ) );
	pCol->setColumnCount(0, (BYTE)(m_pCurSectionInformation->getColumnNum()) );
	pCol->setDirection( 0 );    // GARO
	pCol->setRegionHeight( 0, (m_pCurSectionInformation->getPageHeight() - (pCol->topMar() + pCol->btmMar() )) ); //page height
	pCol->setRegionSpace(0, 0);
	if ( (pCol->getColumnCount(0)) < 2) 
	{  // single column
		pCol->setColumnWidth(0, 0, m_pCurSectionInformation->getPageWidth() - (pCol->leftMar() + pCol->rightMar() ) );
		pCol->setColumnSpace(0, 0, m_pCurSectionInformation->getColumnColSpaceVal(0) );
		pCol->setOrder( 0, 0, 1 );
	}
	else
	{   
		if(m_pCurSectionInformation->getColumnEqualWidth())
		{
			nColWidthForEqualCols =  ((m_pCurSectionInformation->getPageWidth() - (pCol->leftMar() + pCol->rightMar())) / m_pCurSectionInformation->getColumnNum());
			for (BrINT32 i = 0; i < (pCol->getColumnCount(0)); i++) 
			{
				pCol->setColumnWidth(0, i, nColWidthForEqualCols );
				pCol->setColumnSpace(0, i, nColWidthForEqualCols );
				pCol->setOrder(0, i, (BYTE)(i + 1) );
			}
		}
		else
		{
			for (BrINT32 i = 0; i < m_pCurSectionInformation->getColumnNum(); i++) 
			{
				pCol->setColumnWidth(0, i, m_pCurSectionInformation->getColumnColWidthVal(i) );
				pCol->setColumnSpace(0, i, m_pCurSectionInformation->getColumnColSpaceVal(i) );
				pCol->setOrder(0, i, (BYTE)(i + 1) );
			}
		}
	}
}
#endif

void CDocxConv::createBasicFrame(CFrameList *pFrameList, BrINT32 nColWidthForEqualCols)
{
	if (!pFrameList)
		return;

	BrINT32 i = 0, nSize = m_pCurSectionInformation->getColumnNum();
	CFrame *pFrame = NULL;
	BrINT32 nSX = 0;
	m_nFrameTextWidth = m_nFrameTextHeight = 0;
	m_nCurParaHgt = 0; 

	for (i = 0; i < nSize; i++) 
	{
		pFrame = BrNEW CFrame();
		if(pFrame)
		{
			pFrame->setPageNum( theBWordDoc->getPageArray()->GetSize() );
			pFrame->updatePage(m_pCurPage);
			pFrame->UpdateID(); 
			pFrame->setPairID( 0 );
			pFrame->setClass( FIXFRAME );
			pFrame->setDirection( 0 );  // GARO

			pFrame->setXOrgType( ORG_PAGE );
			pFrame->setYOrgType( ORG_PAGE );
			pFrame->setOrgDx( 0 );
			pFrame->setOrgDy( 0 );

			pFrame->setTop( BrABS(m_pCurSectionInformation->getPageMargin().top) );   
			pFrame->setBottom( m_pCurSectionInformation->getPageHeight() - BrABS(m_pCurSectionInformation->getPageMargin().bottom ) );


			if(0 == i)
			{
				pFrame->setLeft( BrABS(m_pCurSectionInformation->getPageMargin().left + m_pCurSectionInformation->getGutterMargin() ) );

				if (nSize < 2)    // single column
					pFrame->setRight( m_pCurSectionInformation->getPageWidth() - BrABS(m_pCurSectionInformation->getPageMargin().right) );
				else    // multi column
				{
					if(m_pCurSectionInformation->getColumnEqualWidth())
						pFrame->setRight( pFrame->left() + nColWidthForEqualCols );
					else
					{
						pFrame->setRight( pFrame->left() + m_pCurSectionInformation->getColumnColWidthVal(i) );
					}
				}
			}
			else
			{
				pFrame->setLeft( nSX + m_pCurSectionInformation->getColumnColSpaceVal(0));
				if(m_pCurSectionInformation->getColumnEqualWidth())
					pFrame->setRight( pFrame->left() + nColWidthForEqualCols);
				else
				{
					pFrame->setRight( pFrame->left() + m_pCurSectionInformation->getColumnColWidthVal(i) );
				}
			}

			nSX = pFrame->right();
			m_nFrameTextWidth = pFrame->width();
			m_nFrameTextHeight += pFrame->height();
			pFrameList->insertAtTail(pFrame);
			pFrame = NULL;
		}
	}
	m_pCurFrame = (CFrame*)pFrameList->getFirst(); 

}

CFrame* CDocxConv::createFrame(BYTE bClass, BRect *pFrameRect, BrBOOL bAnchorType, BrINT32 nPageNum, BrBOOL bCreateEds, BYTE bImage, BrBOOL	bImageBullet) 
{
	CFrame *pFrame = BrNULL;
	if (bClass == CHARTFRAME)
		pFrame = BrNEW CBWPChart();
 #ifdef DANDONG_SMARTART
 	else if (bClass == DIAGRAMXFRAME)
 		pFrame = BrNEW CSmartArt();
 	else if (bClass == DIAGRAMXENTRY)
 		pFrame = BrNEW CSmartArtEntry();
 #endif // DANDONG_SMARTART
	else if(bClass == CELLFRAME)
		pFrame = BrNEW CellFrame();
	else
		pFrame = BrNEW CFrame();

	if(!pFrame)
	{
		SetErrorFReturn(CFilterErrorObj(kPoErrMemory, __FILE__, __LINE__));
		return BrNULL;
	}
	BrGrapAtt *pGrapAtt = BrNULL;
	if(!pFrame->isDrawing())
	{
		pGrapAtt = (BrGrapAtt*)pFrame->getBorder();	
		if( (bClass == GROUPFRAME/* || bClass == CHARTFRAME */)&& !pGrapAtt) //[�̻�ȣ] ��Ʈ�� brshape�� ���� xlsobject���� ����
		{
			BrShape *pBwpShape = BrShape::createShape(msosptMin, *pFrame->getFrameRect());
			pFrame->setBorder(pBwpShape);
			pGrapAtt = (BrGrapAtt*)pBwpShape;
			//[2013.04.29][������][M28033] Chart, Group Frame�� ��쿡�� DML, VML Check ���־���Ѵ�.
			if(bClass == CHARTFRAME || (bClass == GROUPFRAME && theBWordDoc->getCompatibilityModeVersion() >= eCOMPATIBILITY_V14))
				pGrapAtt->setOffice2007Shape(BrTRUE);				
		}
	}

	//default value setting
	pFrame->setPageNum(nPageNum);
	if(!bImageBullet)
		pFrame->UpdateID();
	pFrame->setPairID(0);
	pFrame->setClass(bClass); 
	pFrame->setDirection(0); //Garo
	pFrame->setXOrgType(ORG_PAGE);
	pFrame->setYOrgType(ORG_PAGE);
	pFrame->setOrgDx(0);
	pFrame->setOrgDy(0);
	pFrame->setFrameRect(pFrameRect);
	if(!(m_nDoingType & DOC_CELL))
		pFrame->updatePage(m_pCurPage);
	pFrame->setAnchorFlag(bAnchorType);

	if (bCreateEds)
		pFrame->setSubFrame( pFrame->newElementByType(bClass) );

	return pFrame;
}

BrBOOL CDocxConv::SetFirstPageProperty(CPage* a_pPage)
{
	if(a_pPage == BrNULL)
		return SetErrorFReturn(CFilterErrorObj(kPoErrImportError, __FILE__, __LINE__));
	// PaperSize
	(a_pPage->getPaperSize())->setWidth( m_pCurSectionInformation->getPageWidth() );
	(a_pPage->getPaperSize())->setHeight(m_pCurSectionInformation->getPageHeight());

	(a_pPage->getPaperSize())->setSizeID(m_pCurSectionInformation->getPageSizeID());
	(a_pPage->getPaperSize())->setDirection(((a_pPage->width() > a_pPage->height()) ? LANDSCAPE : PORTRAIT )); //����/����

	a_pPage->setPageNum( theBWordDoc->getPageArray()->GetSize() );

	BrINT32 nColWidthForEqualCols = 0;


	if(m_pDocxLoader->m_pDocxBackground )
		m_pDocxLoader->m_pDocxBackground->CreatePageBackGround(m_pCurPage->width(), m_pCurPage->height());

	CFrame *pFrame = a_pPage->getBFrameList()->getFirst();
	BrINT32 nSX = 0;
	m_nFrameTextWidth = m_nFrameTextHeight = 0;
	m_nCurParaHgt = 0;

	// Column
	createColumn( a_pPage->getColumn(), nColWidthForEqualCols );

	BrINT32 i = 0, nSize = m_pCurSectionInformation->getColumnNum();

	for (i = 0; i < nSize; i++) 
	{
		if(pFrame == BrNULL)
		{
			pFrame = BrNEW CFrame();
			if(pFrame)
				a_pPage->getBFrameList()->insertAtTail(pFrame);
		}
		if(pFrame)
		{
			pFrame->setRegionPos(0);
			pFrame->setColumnPos(i);
			pFrame->setPageNum( theBWordDoc->getPageArray()->GetSize() );
			pFrame->updatePage(m_pCurPage);
			pFrame->UpdateID(); 
			pFrame->setPairID( 0 );
			pFrame->setClass( FIXFRAME );
			pFrame->setDirection( 0 );  // GARO

			pFrame->setXOrgType( ORG_PAGE );
			pFrame->setYOrgType( ORG_PAGE );
			pFrame->setOrgDx( 0 );
			pFrame->setOrgDy( 0 );

			pFrame->setTop( BrABS(m_pCurSectionInformation->getPageMargin().top) );   
			pFrame->setBottom( m_pCurSectionInformation->getPageHeight() - BrABS(m_pCurSectionInformation->getPageMargin().bottom ) );


			if(0 == i)
			{
				pFrame->setLeft( BrABS(m_pCurSectionInformation->getPageMargin().left + m_pCurSectionInformation->getGutterMargin() ) );

				if (nSize < 2)    // single column
					pFrame->setRight( m_pCurSectionInformation->getPageWidth() - BrABS(m_pCurSectionInformation->getPageMargin().right) );
				else    // multi column
				{
					if(m_pCurSectionInformation->getColumnEqualWidth())
						pFrame->setRight( pFrame->left() + nColWidthForEqualCols );
					else
					{
						pFrame->setRight( pFrame->left() + m_pCurSectionInformation->getColumnColWidthVal(i) );
					}
				}
			}
			else
			{
				pFrame->setLeft( nSX + m_pCurSectionInformation->getColumnColSpaceVal(0));
				if(m_pCurSectionInformation->getColumnEqualWidth())
					pFrame->setRight( pFrame->left() + nColWidthForEqualCols);
				else
				{
					pFrame->setRight( pFrame->left() + m_pCurSectionInformation->getColumnColWidthVal(i) );
				}
			}

			if(i+1 == nSize)
				pFrame->setRight(a_pPage->width() - a_pPage->rightMargin());	// ������ ����� ��ġ��Ű���� �Ѵ�.

			nSX = pFrame->right();

			m_nFrameTextWidth = pFrame->width();
			m_nFrameTextHeight += pFrame->height();

			pFrame = BrNULL;
		}
	}
	m_pCurFrame = (CFrame*)a_pPage->getBFrameList()->getFirst(); 

	return BrTRUE;
}

void	CDocxConv::SearchBulletForLockedCanvas(CLine *pLine, BCOfficeXTextParagraph* pPara,BCOfficeXTextRunProp* pTRProp, BCOfficeXShapeStyleRef* pRef)
{
	BCOfficeXParagraphStyle*	pParaTextStyle = BrNULL;	
	pParaTextStyle = pPara->m_pTextParagraphStyle;		
	BrBOOL bBulletInfo = BrFALSE;

	if( !pLine || !pParaTextStyle)
		return;

	// [2016.03.30] buNone tag�� ������ bullet�� ǥ������ �ʵ��� �ؾ� �Ѵ�.
	if(pParaTextStyle->m_pBulletInfo && pParaTextStyle->m_pBulletInfo->m_bNone == BrFALSE)
		bBulletInfo = BrTRUE;

	CBulletItem *pBulletItem = NULL;
	if(bBulletInfo)
	{
		PoParaAtt cParaData ;
		convertParaAttForLockedCanvas(&cParaData,pPara);
		
		BrINT32 nParaAttID = theBWordDoc->getParaAttHandler()->insertParaAtt(cParaData);
		if(pLine)
			pLine->setParaID(nParaAttID);

		BrINT nTextID;
		nTextID = SearchTextAttAndAddForLockedCanvas(pTRProp, pRef);
		
		//[2014.04.24]coverity - 22857
		BrWORD wBulletCode = 0;
		BrBOOL bOutline = BrFALSE;
		NumFormatType eNumType = eSTNum_bullet;		

		CCharSetArray *pCharSetArray = pLine->getCharSetArray();

		BrWORD wNodeCode[256] = {0};
		BrINT nStrSize = 0;
		BrINT i;

		switch(pParaTextStyle->m_pBulletInfo->GetBulletType())
		{
			case OfficeXBTAutoNum:
				eNumType = eSTNum_bullet;
				break;
			case OfficeXBTBlip:
				eNumType = eSTNum_image;
				break;
			case OfficeXBTChar:
				eNumType = eSTNum_none;
				break;		

		}

		if(eNumType == eSTNum_none)	//�� �� �� �� ��..
		{
			bOutline = BrFALSE;
			wBulletCode = pParaTextStyle->m_pBulletInfo->m_BulletChar;
			wNodeCode[nStrSize++] =  wBulletCode;
		}
		else	//��ȣ �ű��
		{
			bOutline = BrTRUE;
		} 

		if ((pLine->getLineList()->getFrame()->GetClass() != DIAGRAMXENTRY) || (cParaData.getIndent() != -1))
		{
			if(cParaData.getIndent() != 0)
				wNodeCode[nStrSize++] = ASCII_CODE_TAB;
		}

		wNodeCode[nStrSize] = NULL;

		for( i = 0; i < nStrSize; i++)
		{
			CCharSet cCharSet;
			cCharSet.setCode(wNodeCode[i]);
			cCharSet.setAttrID(nTextID);
			cCharSet.setLinkSubType(LINKTYPE::STANDARD, BULLET_CHAR);
			pCharSetArray->InsertAt(i, cCharSet);
		}

	//////////////////////////////////////////////////////////////////////////
	// set bullet
	//////////////////////////////////////////////////////////////////////////
		BrINT32 nCount = 1;
		if (bOutline)//��ȣ�ű��
		{	
			nCount = 9;
			if (eSTNum_bullet != eNumType)
				wBulletCode = 0;
		}
		else	//�۸Ӹ� ��ȣ	//�� �� �� �� ��.. 
		{	
			nCount = 1;
			eNumType = eSTNum_bullet;
		}

		CBullet *pBullet = BrNEW CBullet();
		if(pBullet)
		{
			pBullet->setCount( (BYTE)nCount );
			CDocxLevel *pTmpLevel = NULL;
			for (i = 0; i < pBullet->getCount(); i++) 
			{
				if( i == MAX_BULLET_DEPTH ) //bora������ 9���̻��� �ʿ����..2002-03-07
					break;

				pBulletItem = BrNEW CBulletItem();
				if(pBulletItem)
				{					
					//ù �� �����
					BrINT32	nHanging = 0;
					if(pParaTextStyle->m_nIndent < 0) // ������ line�� -indent�� ����
						nHanging = pParaTextStyle->m_nIndent;

					//ù �� �鿩����
					BrINT32	nfirstLine = 0;
					if(pParaTextStyle->m_nIndent >= 0)// ù��°line�� indent�� ����
						nfirstLine = pParaTextStyle->m_nIndent;

					BrINT32	nLeft = 0;
					if(pParaTextStyle->m_nLeftMargin)									
						nLeft = pParaTextStyle->m_nLeftMargin;

					BrINT32	nRight = 0;
					if(pParaTextStyle->m_nRightMargin)
						nRight = pParaTextStyle->m_nRightMargin;

					if(nHanging > 0)	//ù �� ����Ⱑ �������� leftChars���� ����ȴ�. left���� ���� ��.
					{
						pBulletItem->setIndent(-nHanging);
						BrINT32 nTmp = 0;
						if(pParaTextStyle->m_nIndent > 0)//else if(pPap->m_nhanging > 0)
							nTmp = nLeft - nHanging;

						/*0.1cm ���ϴ� ������ ����. �׷��� �������� direct�� �����ϸ� 1pt�� �ν��� */
						/* ���̾ƿ��� ������ ������ �ȴ�. �̸� �����ϱ� ����.. 						 */
						if( nTmp > 0 && nTmp < 57 ) 
							pBulletItem->setLeftMargin(0);
						else
							pBulletItem->setLeftMargin(nTmp);
					}					
					else
					{
						pBulletItem->setIndent(nfirstLine);
						pBulletItem->setLeftMargin(nLeft);
					}
					
					pBulletItem->setCode( wBulletCode );            //Bullet���ڷ� �� ����� ���� Code (0:None)
					pBulletItem->setNumType( eNumType );            // ��ȣ �ű���� ���� (�ѱ�, ����, ����, �θ���, ������, ��ȣ����, ...)
					pBulletItem->setTabCode(ASCII_CODE_TAB);
					pBullet->addBulletItem(i, pBulletItem);
					pBulletItem->setTextAttID(nTextID);
					//pBulletItem->setParaAttID(nParaAttID);
				}
			}

			if( i > 9 )
				i = 9;

			pBullet->setCount( i ); 
			nCount = i ;
			PoParaAtt* pParaData = const_cast<PoParaAtt*>(theBWordDoc->getParaAttHandler()->getParaAtt(nParaAttID));
			{
				CBullet *pBWordDocBullet = BrNULL;
				BrBOOL bFind = BrFALSE;
				BrINT32 sz = theBWordDoc->getBulletArray()->size();
				for(BrINT32 i=0; i<sz; i++)
				{
					pBWordDocBullet = theBWordDoc->getBulletArray()->getBullet(i);
					if(pBullet->equals(*pBWordDocBullet)) {
						pParaData->setBulletID(i);
						bFind = BrTRUE;
					}
				}

				if (!bFind) {
					//theBWordDoc->getBulletArray()->Add(pBullet);
#ifdef DANDONG_SMARTART
					// [2015.11.18] docx������ ������ MS���� �����Ͽ��� �� bullet�� ǥ�õ��� �ʴ� ������ ����(SRG-1806 2������)
					// Numbering.xml���� <w:lvl> / <w:pPr>�� <w:numPr>������ �������� �ʵ��� PoParaAtt::setBulletID()��
					// �ι�° �Ķ���͸� BrFALSE�� �����Ѵ�.
					pParaData->setBulletID(theBWordDoc->getNumArray()->addBullet(*pBullet));
					// ���� <w:numbering>�� <w:num>�±��ڷḦ �߰��ϱ� ���� �Ʒ��� �ڵ带 �߰��Ѵ�.
#else // DANDONG_SMARTART
					pParaData->setBulletID(theBWordDoc->getBulletArray()->size());
#endif // DANDONG_SMARTART
				}
			}
		}
	}
}//MistY - 2009.07.01

BrINT32 CDocxConv::createBullet(CLine *pLine, CDocxParaAtt *pDocxParaAtt, BrINT32 nTextID, CDocxTextAtt* a_pTextAtt)
{
	if(!pLine || !pDocxParaAtt)
		return 0;
	NumberingHandler* pNumberingHandler =  m_pDocxLoader->GetNumberingHandler();
	if(!pNumberingHandler)
		return 0;
	return pNumberingHandler->ConvertNumberingXMLToBWPForLine(pLine,pDocxParaAtt,nTextID, m_pDocxLoader);	
}

BrBOOL CDocxConv::createText(CLineList *pLineList, CDocxText *pDocxText)
{
	if(!pLineList || !pDocxText )
		return SetErrorFReturn(CFilterErrorObj(kPoErrImportError, __FILE__, __LINE__));

	if(!pDocxText->m_pStrCode)
		return SetErrorFReturn(CFilterErrorObj(kPoErrImportError, __FILE__, __LINE__, "pDocxText->m_pStrCode is null"));

	BrINT32 nStrLen = BrStrLen(pDocxText->m_pStrCode);

	CLine *pLine = pLineList->getLast();
	//[2013-05-31][toypilot] ���� �ؽ�Ʈ�� �־ ���� ����̱� ������ linelist�� line���� ���(pagebreak ���� ù���� ���� ���) ������ ��������
	if(pLine == BrNULL)
		pLine = m_pDocxPara->CreateLine(pLineList);

	BrWORD nTextID = pDocxText->m_nTextAttID == 0xffff ? 0 : pDocxText->m_nTextAttID;

	PoTextAtt textAtt(*theBWordDoc->GetTextAttr( nTextID ));
	if( textAtt.getHighSurrogate() > 0 )
	{
		textAtt.setHighSurrogate(0);
		nTextID = theBWordDoc->getTextAttHandler()->insertTextAtt( textAtt );
	}

	CCharSetArray *pCharSetArray = pLine->getCharSetArray();

	if(m_bSDTToc)
		pLine->setTOCLine(BrTRUE);

	BrINT32 j = 0;
	BrWORD wCode = 0;
	CCharSet cCharSet;
	CCharSet *pLink = BrNULL;
	const PoTextAtt *pTextAtt = BrNULL;;

	pTextAtt = theBWordDoc->getTextAttHandler()->getTextAtt(nTextID);

	if(m_bToc) {
		PoTextAtt cTextAtt(*pTextAtt);
		if(cTextAtt.getStyleID() > 0)
		{
			CStyleAttBase* pStyle = theBWordDoc->getStyleAttArray()->at(cTextAtt.getStyleID());
			if(pStyle && pStyle->getStyleName() == "Hyperlink")
			{
				if(cTextAtt.getTextColor().getColorID() == 11 || cTextAtt.getTextColor().getColor() == 0x00ff0000)//HyperLinkColor
				{
					BrColor AutoTextColor;
					cTextAtt.setAutoColor(BrTRUE);
				}
				if(cTextAtt.getUnderline())
					cTextAtt.setUnderline(BrFALSE);
				
				if( cTextAtt != *pTextAtt ) {
					nTextID = theBWordDoc->getTextAttHandler()->insertTextAtt(cTextAtt);
					pTextAtt = theBWordDoc->getTextAttHandler()->getTextAtt(nTextID);
				}
			}
		}
	}

	//[TID-710] issue 82.docx symbol code support
	if( pDocxText->m_bSymbol ) {
		wCode = BrAtoX(pDocxText->m_pStrCode);
		wCode = BrUtil::convertSymbolCode(wCode);

		cCharSet.setCode(wCode);
		cCharSet.setAttrID(nTextID);

		//2011-07-15 hnsong
		if( m_bOnlyEngPara && IsFullWidthChar(wCode) )
			m_bOnlyEngPara = BrFALSE;
		if(pCharSetArray)
			pCharSetArray->Add(cCharSet);

		return BrTRUE;

	}
	//~ [TID-710] issue 82.docx symbol code support
	BrUSHORT *pOutput = (BrUSHORT*)BrMalloc((nStrLen + 1)*2); 
	memset(pOutput, 0, (nStrLen + 1)*2);
	BrINT32 nLen = BrMultiByteToWideChar( CP_UTF8, (BrLPCSTR)pDocxText->m_pStrCode, nStrLen, (BrLPWSTR)pOutput, nStrLen);

	BrBOOL	bCommentCounted = BrFALSE;
	if(m_bComment && (m_nCommnetCharCount + nLen) < 10000)	//comment char count limit
		m_nCommnetCharCount += nLen;		

	for( j = 0; (j < nLen) && pOutput[j]; j++)
	{
		// �� ���ο� �ʹ� ���� CharSet Node�� �޸��� ���� �����ϱ� ���Ͽ� �ϴ� 128�� ��������...
		if(pCharSetArray && (pCharSetArray->GetSize() > 0 && pCharSetArray->getCharSet(pCharSetArray->GetSize()-1)->isCRLink() || pCharSetArray->GetSize()>128) )
		{
			CLine *pNewLine = BrNULL;

			if(m_pDocxPara)
				pNewLine = m_pDocxPara->CreateLine(pLineList);
			else
			{
				BRTHREAD_ASSERT(0);
				pNewLine = ftLibrary::CreateLine(pLineList);
			}

			pCharSetArray = pNewLine->getCharSetArray();
			pLine = pNewLine;

			// [SRG-2294] ���� w:r, ���ο� line ���� �� toc line setting �ȵǴ� ��� setting.
			if(pLine && m_bSDTToc)
				pLine->setTOCLine(BrTRUE);
		}

		wCode = pOutput[j];
		
		if( m_bOnlyEngPara && IsFullWidthChar(wCode) )
			m_bOnlyEngPara = BrFALSE;


		if( UTF_IS_SURROGATE_LEAD(wCode) && UTF_IS_SURROGATE_TRAIL(pOutput[j+1]))
		{
			cCharSet.setAttrID( theBWordDoc->GetTextAttrID( textAtt, wCode ) );
			cCharSet.setCode(pOutput[j+1]);

			j++;
		}
		else 
		{
			//[2012-02-22][toypilot]wingdings ��Ʈ �տ� �ٴ� f0 ����
			if (0xf0 == BrHIBYTE(wCode))
				wCode = BrUtil::convertExceptionCode(wCode, nTextID);
			cCharSet.setCode(wCode);
			cCharSet.setAttrID(nTextID);
		}
		DocxField* pDocxField = BrNULL;
		DocxFieldManager * pDocxFieldManager = getDocxLoader()->getDocxFieldManager();
		pDocxField = pDocxFieldManager->peek();

		if(pDocxField )
		{
			pDocxField->ConvertFldCharSeparate(pLine, cCharSet);
			continue;
		}

		if(pCharSetArray)
			pCharSetArray->Add(cCharSet);

		//[2013-11-22][toypilot] �ڵ� ������ ��� ��� �ϳ��� line�� �޾���
		if(pTextAtt->getFitFlag() == BrFALSE)
			m_pDocxPara->m_nParaWidth += IsFullWidthChar(wCode) == BrTRUE ? pTextAtt->getHanFSize() : pTextAtt->getHanFSize()/2;
		if(!IS_UCS2_Khmer(wCode) && !m_pDocxLoader->m_bFootEndNote && m_pDocxPara && m_pDocxPara->m_nParaWidth >= m_nFrameTextWidth || 0xd == wCode || (pCharSetArray && pCharSetArray->size() > 128))
		{
			BrINT32 nParaAttID = m_pDocxPara != BrNULL ? m_pDocxPara->m_wParaAttID : 0;
			CLine *pNewLine = m_pDocxPara->CreateLineWithPara(pLineList, nParaAttID);
			if(!pNewLine)
				return SetErrorFReturn(CFilterErrorObj(kPoErrImportError, __FILE__, __LINE__));

			pLine = pNewLine;
			pCharSetArray = pLine->getCharSetArray();
		}	

		if(m_bComment)
		{
			if(!bCommentCounted)
				m_nCommnetCharCount++;
			if(m_nCommnetCharCount > 10000)
				break;
		}
	}	/* end of for( j = 0; (j < nLen) && pOutput[j]; j++) */
	BR_SAFE_FREE(pOutput);
	
	if(m_nCaptionIDForEndLink != -1)
	{
		if(!ftLibrary::AddCharSet(pLine, m_nCaptionIDForEndLink, nTextID, LINKTYPE::FIELD , END_LINK | SPLITABLE | EDITABLE))
			return SetErrorFReturn(CFilterErrorObj(kPoErrImportError, __FILE__, __LINE__));
		m_nCaptionIDForEndLink = -1;
	}

	return BrTRUE;
}

// get paragraph height
BrINT32 CDocxConv::getParaHeight(BrSHORT wID, BrINT32 hps) 
{
	const PoParaAtt* pParaAtt = theBWordDoc->getParaAttHandler()->getParaAtt(wID);
	BrINT32 nLineSp = 0;
	if (LINESP_UNIT_PERCENTAGE == pParaAtt->getLineSpaceUnit() )
		nLineSp = (BrINT32)BrMulDivDouble(BrMulDiv(hps, 20, 2)/*hps*/ , pParaAtt->getLineSpace(), 100);
	else if(LINESP_UNIT_MULTIPLE == pParaAtt->getLineSpaceUnit())
	{
		BrINT32 nTextAttID = 0;
		if(m_wAttrIDForCurBigChar != 0xFFFF)
			nTextAttID = m_wAttrIDForCurBigChar;
		const PoTextAtt* pTextAtt = theBWordDoc->getTextAttHandler()->getTextAtt(nTextAttID);
		BrWORD wTextSize = pTextAtt->getHanFSize();
		nLineSp =(BrINT32)(pParaAtt->getLineSpace() * 110 * wTextSize) / 100;
	}
	else
		nLineSp = (BrINT32)pParaAtt->getLineSpace();

	nLineSp += pParaAtt->getFrontParaSpace() + pParaAtt->getBackParaSpace();

	return nLineSp;
}

// get line space
BrINT32 CDocxConv::getLineSpace(BrSHORT wID, BrINT32 nBigCharSize) 
{
	BrINT32 nLineSp = 0;
	BrINT32 hps = BrMulDiv(nBigCharSize, 20, 2);
	const PoParaAtt* pParaAtt = theBWordDoc->getParaAttHandler()->getParaAtt(wID);
	if ( pParaAtt->getLineSpaceUnit() ==LINESP_UNIT_PERCENTAGE ) {
		nLineSp = (BrINT32)(( hps * pParaAtt->getLineSpace()/ 100.0 + 0.5) - hps);
	}
	else if (LINESP_UNIT_FIX == pParaAtt->getLineSpaceUnit() )			// ���밪
	{
		nLineSp = (BrINT32)(pParaAtt->getLineSpace() - hps);
	}
	else if (LINESP_UNIT_TWIP == pParaAtt->getLineSpaceUnit() )		// �ּ�, For DOC
	{
		BrINT32		nMinLineHgt = hps;		//(BrINT32)(nLineHgt * 1.3);		// 30% line space �⺻
		BrINT32		nMinLineSp = nMinLineHgt-hps;
		if ( pParaAtt->getLineSpace() > nMinLineHgt )	nLineSp = (BrINT32)(pParaAtt->getLineSpace() - hps);
		else		nLineSp = nMinLineSp;
	}

	return nLineSp;
}

CLineList* CDocxConv::getCurLineList() 
{
	if(m_pCurLineList)
		return m_pCurLineList;


	if( !m_pCurFrame )
	{
		m_pCurPage = (CPage*)theBWordDoc->getPageArray()->GetAt(theBWordDoc->getPageArray()->GetSize()-1);		
		if( getPageNum() <= 0 )
			return BrNULL;

		m_pCurFrame = m_pCurPage->getLastBasic();
	}
	CLineList *pLineList = BrNULL;
	if( m_pCurFrame ) {//[2013.02.14][������][TID:12537] Page�� LineList return (�Լ� �ۿ��� LineList�� ����ٰ� �ϰ� ���� ��찡 ����.)
		if( m_pCurPage != m_pCurFrame->getPage() && !(m_pCurFrame->isHeader() || m_pCurFrame->isFooter() || m_pCurFrame->isNote()))
			return m_pCurFrame->getPage()->getFirstLineList();

		pLineList = (CLineList*)m_pCurFrame->getSubFrame();
	}

	if (!pLineList) 
	{
		m_pCurLineList = pLineList = ftLibrary::CreateLineList(m_pCurFrame);
		if(!pLineList)
			return BrNULL;
	}

	return pLineList;
}
BrBOOL CDocxConv::ConvertDocxTableToBWP(CDocxTable* a_pDocxTable, CLineList* a_pLineList, BrBOOL a_bInCell)
{
	if(!a_pDocxTable || !a_pDocxTable->m_pDocxRowArray )
		return SetErrorFReturn(CFilterErrorObj(kPoErrImportError, __FILE__, __LINE__));
	BrBOOL  bNeedAddLine = BrTRUE;
	if(m_pNotCompleteTable && !a_bInCell)
		bNeedAddLine = BrFALSE;
	CFrame* pTableFrame = PrepareConvertTable(a_pDocxTable, a_pLineList, a_bInCell);
	if(!pTableFrame)
		return SetErrorFReturn(CFilterErrorObj(kPoErrImportError, __FILE__, __LINE__));
	
	if(!ConvertTableToCBTable(a_pDocxTable, pTableFrame, a_bInCell))
		return SetErrorFReturn(CFilterErrorObj(kPoErrImportError, __FILE__, __LINE__));

	//Add Table
	if(!a_pDocxTable->m_bDelTable)
	{
		if(bNeedAddLine)
			AddTableAtLine(a_pDocxTable, pTableFrame, a_pLineList);
	}
	else if(m_bNewSection)
	{
		CLine* pLine = ftLibrary::CreateLine(a_pLineList);	
		pLine->setParaID(0);
		pLine->setSectionInformation(m_pCurSectionInformation);
		ftLibrary::AddCharSet(pLine, ASCII_CODE_CR);
	}
	
	if(m_pNotCompleteTable == BrNULL)
	{
		if(pTableFrame)
		{
			CBTable* pTable = reinterpret_cast <CBTable*> (pTableFrame->getSubFrame());
			pTable->setImportCompleted(BrTRUE);
		}

		for(BrINT32 nIndex = 0; nIndex < m_pTablePtrArray.size(); nIndex++)
		{
			if(a_pDocxTable == m_pTablePtrArray.at(nIndex))
				m_pTablePtrArray.RemoveAt(nIndex);
		}
		BR_SAFE_DELETE(a_pDocxTable);
		m_pNotCompleteTable = BrNULL;
		m_bSuspendXmlParser = BrTRUE;
	}

	return BrTRUE;
}

BrBOOL	CDocxConv::ConvertTableToCBTable(CDocxTable* a_pDocxTable, CFrame* a_pTableFrame, BrBOOL a_bInCell)
{
	if(!a_pDocxTable || !a_pTableFrame)
		return SetErrorFReturn(CFilterErrorObj(kPoErrImportError, __FILE__, __LINE__));
	CBTable* pTable = (CBTable*)a_pTableFrame->getSubFrame();
	CFrame *pNewCellFrame = NULL;
	CBCell  *pNewCell = NULL;
	BrINT32 nTopPos = 0;
	CDocxRow *pDocxRow = BrNULL;
	CDocxCell *pDocxCell = BrNULL;
	CDocxTblPr*	pDocxTblPr = a_pDocxTable->m_pDocxTblPr;

	CTableStyleMgr *pTableStyleMgr = theBWordDoc->getTableEngine()->getStyleMgr();
	pTableStyleMgr->mergeStyle(pTable);

	if(pDocxTblPr)
	{
		if(pDocxTblPr->m_pDescription) {
			BString descriptionString;
			descriptionString.setMultiByte(CP_UTF8, pDocxTblPr->m_pDescription);
			a_pTableFrame->setAltTextDescription(descriptionString);
		}
		if(pDocxTblPr->m_pTitle) {
			BString titleString;
			titleString.setMultiByte(CP_UTF8, pDocxTblPr->m_pTitle);
			a_pTableFrame->setAltTextTitle(titleString);
		}

		pTable->setBidiDirection(pDocxTblPr->m_bBidi);

		if(pDocxTblPr->m_nWidth != 0)
		{
			pTable->setAutoResizeByContentType(BrFALSE);
			pTable->setWidthUnitType(BrTRUE);
		}
		else
			pTable->setAutoResizeByContentType(BrTRUE);

#ifdef USE_DOCX_UNIQUEID
		pTable->setUniqueID(a_pDocxTable->m_nTableIDForCollaboration);
#endif // USE_DOCX_UNIQUEID

		CTableBorders* pTableBorders = BrNEW CTableBorders();
		if(!pDocxTblPr->ConvertTblPrBorders(pTableBorders))
			return SetErrorFReturn(CFilterErrorObj(kPoErrImportError, __FILE__, __LINE__));
		pTable->setBorders(pTableBorders);
		BRect rcBorderMargin(0,0,0,0);

		if(pTableStyleMgr->getTableBorderMargin())
			rcBorderMargin = *pTableStyleMgr->getTableBorderMargin();
		
		//left margine
		if(pDocxTblPr->m_cLeftMar.m_nWidth > 0 && pDocxTblPr->m_cLeftMar.m_cType[0] != 0)
			rcBorderMargin.nLeft = pDocxTblPr->m_cLeftMar.m_nWidth;

		if(pDocxTblPr->m_cTopMar.m_nWidth > 0 && pDocxTblPr->m_cTopMar.m_cType[0] != 0)
			rcBorderMargin.nTop = pDocxTblPr->m_cTopMar.m_nWidth;

		if(pDocxTblPr->m_cRightMar.m_nWidth > 0 && pDocxTblPr->m_cRightMar.m_cType[0] != 0)
			rcBorderMargin.nRight = pDocxTblPr->m_cRightMar.m_nWidth;

		if(pDocxTblPr->m_cBottomMar.m_nWidth > 0 && pDocxTblPr->m_cBottomMar.m_cType[0] != 0)
			rcBorderMargin.nBottom = pDocxTblPr->m_cBottomMar.m_nWidth;

		pTable->setCellMargin(&rcBorderMargin);

		CDocxTableStyle::ConvertTableCellSpacing(pTable, pDocxTblPr->m_nCellSpaceWidth, pDocxTblPr->m_cCellSpaceWidthType);
		pTable->setWordTableLook(pDocxTblPr->m_nTableLook);
	}

	BrINT32 nRowNum = a_pDocxTable->m_pDocxRowArray->GetSize();
	BRect*  pFrameRect = a_pTableFrame->getFrameRect();
	BrINT32 nCurTableBottom = pFrameRect->nBottom;
	BrINT32 nCurTableRight = pFrameRect->nRight;
	VMergeColumnList MergeColums;
	BrINT32 nRow = 0;
	BrINT32 nCellSpacing = 0;
	if(m_pNotCompleteTable && !a_bInCell)
	{
		nRow = m_pNotCompleteTable->m_nArrangeRow;
		m_pNotCompleteTable = BrNULL;
	}

	BArray<BrINT32> colPos;
	colPos.resize(0);
	BrINT32 nGridColWidth = 0;//table width

	nCellSpacing = pTable->getCellSpace() / 2; //XML �� ���� �����ϰ� �ϱ� ���� / 2 ó�� �߰�. (Cell Spacin �� setting �� 1/10 point��� �Ͽ� *2 ó�� ��)
	BrINT32 nGridColValue = 0;

	for(BrINT32 i = 0; a_pDocxTable->m_pGridColArray && i < a_pDocxTable->m_pGridColArray->size(); i++)
	{
		nGridColValue = a_pDocxTable->m_pGridColArray->at(i);
		if (nCellSpacing > 0)
		{
			if (i == 0) //���� ���� ���Ե� Cell Spacing ����
				nGridColValue -= nCellSpacing;
			
			if(i == a_pDocxTable->m_pGridColArray->size() - 1) //������ ���� ���� Cell Spacing ����
				nGridColValue -= nCellSpacing;

			nGridColValue -= (nCellSpacing * 2); //�⺻������ �� �ִ� Cell Spacing ����
		}

		if(nGridColValue <= 0) //Cell Space���� ���� Grid Col Value�� Cell Space ó�� ���� ����. (MS XML Ȯ�� �ÿ� ó������ �ʴ� ������ Ȯ��)
			nGridColValue = a_pDocxTable->m_pGridColArray->at(i);

		nGridColWidth += nGridColValue;
		colPos.Add(nGridColWidth);
	}

	if(nCurTableRight > nGridColWidth)
		nGridColWidth = nCurTableRight;
	else
		nCurTableRight = nGridColWidth;


	BArray<CBCell*> lastCellArray;

	BrINT32 nCurConvertCellCount = 0;//�ϳ��� table�� 2000�� �̻� convert�� �ÿ� ������ ���� ����

	for(; nRow < nRowNum; nRow++) 
	{
		pDocxRow = (CDocxRow*)a_pDocxTable->m_pDocxRowArray->GetAt(nRow);
		if(!pDocxRow->m_pDocxCellArray || pDocxRow->m_pDocxCellArray->size() ==0)
		{

			theBWordDoc->getAFrameList()->remove(a_pTableFrame);
			return SetErrorFReturn(CFilterErrorObj(kPoErrCorruptFile, __FILE__, __LINE__, "Tr��child element�� Tc�� ���� ���"));
		}

		CCellList *pNewCellList = pDocxRow->m_pCurCellList;
		pNewCellList->setTable(pTable);
		
		//TrPR
		ConvertTrPr(pDocxRow->m_pDocxTrPr, pTable, pNewCellList, nRow );
		nCellSpacing = pTable->getCellSpace(); //Row ���� Cell Space�� ���� �� ������. �������� ������ �Ǿ�����, �Ʒ����� �ش� ���� ��� �ϱ� ������, Table Cell Space �����θ� �����ϵ��� ��

		BrINT32 nGridBefore = 0;
		BrINT32 nGridAfter = 0;
		if(pDocxRow->m_pDocxTrPr)
		{
			nGridBefore = pDocxRow->m_pDocxTrPr->m_nGridBefore;
			nGridAfter = pDocxRow->m_pDocxTrPr->m_nGridAfter;
		}

		BrINT32 nNumGridSpan = 0;
		BrINT32 nRowHeight = CalculateRowHeight(a_pDocxTable, pDocxRow, nRow, nRowNum);
		BrINT32 nRowWidth = 0;
		BRect cellRect;	
		cellRect.nLeft = cellRect.nRight = pFrameRect->nLeft;
		cellRect.nBottom = 0;
		BrINT32 nRowCnt = nRow + 1;
		cellRect.nTop = nCurTableBottom /*+ nCellSpacing*/;
		BrINT32 nColNum = pDocxRow->m_pDocxCellArray->GetSize();
		BrINT32 nCurRowRight = 0;
		for(BrINT32 nCol = 0; nCol < nColNum; nCol++) 
		{
			// create cell
			
			pDocxCell = (CDocxCell*)pDocxRow->m_pDocxCellArray->GetAt(nCol);

			pNewCellFrame = pDocxCell->cellFrame;
			pNewCell = pNewCellFrame->getCell();

			if(pDocxRow->m_pDocxTrPr && pDocxRow->m_pDocxTrPr->m_ntrHeight)
				pNewCell->setAssignHgt(pDocxRow->m_pDocxTrPr->m_ntrHeight);						
			//ConvertTcPr
			CDocxTcPr *pDocxTcPr = pDocxCell->m_pDocxTcPr;
			CaluateCellFrameRect(cellRect, a_pDocxTable, pDocxCell, nColNum, nRowHeight, nNumGridSpan + nGridBefore, nCellSpacing);

			if(cellRect.getWidth() == 0)
			{
				if(nRow != 0)
				{
					CDocxRow* pPreDocxRow = (CDocxRow*)a_pDocxTable->m_pDocxRowArray->GetAt(nRow-1);
					if(pPreDocxRow)
					{
						if(pPreDocxRow->m_pDocxCellArray->size() > nCol)
						{
							CDocxCell* pPreDocxCell = (CDocxCell*)pPreDocxRow->m_pDocxCellArray->GetAt(nCol);
							if(pPreDocxCell)
								cellRect.setWidth(pPreDocxCell->cellFrame->getFrameRect()->getWidth());
						}
						else if((nCol + 1) == nColNum)
						{
							cellRect.nRight = nCurTableRight;
						}
						else
						{
							BRTHREAD_ASSERT(0);
						}
					}
				}
				else
				{
					BrINT32 cellWidth = 0;
					BrINT32 frameWidth = m_pCurPage->getFirstBasic()->width();
					cellWidth = m_pCurFrame->width() / nColNum;
				}
			}			
		
			pNewCellFrame->setFrameRect(cellRect);
			pNewCellFrame->setPageNum(m_pCurFrame->getPageNum());
			pNewCellFrame->updatePage(m_pCurPage);
			nCurConvertCellCount++;
			pNewCellFrame->setCell(pNewCell);
			pNewCell->setFrame( pNewCellFrame );	
			if(pNewCellFrame->width() <= 0)
				pNewCellFrame->getFrameRect()->nRight = pNewCellFrame->getFrameRect()->nLeft+1;
			if(pDocxTcPr)
			{
				if(!pDocxCell->m_bVirtualCell)
				{
					ConvertTcPr(pDocxTcPr, pNewCell, pTableStyleMgr);
					ConvertCellBorderMargin(pDocxTblPr, pDocxRow, pDocxTcPr, pNewCell, *pTable->getCellMargin(), pTableStyleMgr);
					a_pDocxTable->ConvertCellBorder(pNewCell, nCol, nRow);
				}
				else
				{
					pDocxCell->SetVirtualCellBorder(pNewCell);
					pNewCell->setVirtualCell(BrTRUE);
				}
			}			
			ConvertCellLineList(pNewCellFrame, pDocxCell);

			if(pDocxRow->m_pDocxTrPr && pDocxRow->m_pDocxTrPr->m_hRule == 2)	//���� ������ ���.
			{
				pNewCell->setLock(1);
				pNewCellFrame->setNoOverFrame(BrTRUE);
			}

			if(pDocxTcPr)
				nNumGridSpan += pDocxTcPr->m_nGridSpan;
			else
				nNumGridSpan++;

			BrBOOL bAdd = BrTRUE;
			//MergeCell
			if(pDocxTcPr && pDocxTcPr->m_bVMerge)
			{
				if(!ConvertMergeCell(pNewCell, pDocxCell, a_pDocxTable, nNumGridSpan, nRow, &MergeColums, bAdd, pNewCellList, nCurTableBottom))
					return SetErrorFReturn(CFilterErrorObj(kPoErrCorruptFile, __FILE__, __LINE__));
				cellRect = pNewCell->getCellRect();
			}
			if(nCol == 0 && pDocxTcPr && pDocxTcPr->m_bVMerge && pDocxTcPr->m_bRestart == BrFALSE )	
			{
				BrINT32 nHeadCount = pTable->getHeading();
				if(nHeadCount > 1)
					pTable->setHeading(nHeadCount - 1);
			}


			if(nGridBefore && nCol == 0)
			{
				CBCell* pVirtualCell = BrNEW CBCell(pNewCellList);
				BRect cellRect(pTable->getFrame()->left(), pNewCell->top(), pNewCell->left(), pNewCell->bottom());
				if(pNewCell->getAssignHgt())
					pVirtualCell->setAssignHgt(pNewCell->getAssignHgt());

				CFrame* pVirtualCellFrame = createFrame(CELLFRAME, &cellRect, BrFALSE, m_pCurFrame->getPageNum(), BrFALSE);
				CLineList* pLineList = ftLibrary::CreateLineList(pVirtualCellFrame);
				CLine* pLine = ftLibrary::CreateLine(pLineList);
				PoTextAtt virtualCRAtt;
				theBWordDoc->getTextAttHandler()->getTextAtt(virtualCRAtt, 0);
				virtualCRAtt.setHanFSize(1);
				virtualCRAtt.setEngFSize(1);
				BrWORD attID = theBWordDoc->getTextAttHandler()->insertTextAtt(virtualCRAtt);
				ftLibrary::AddCharSet(pLine, ASCII_CODE_CR, attID);
				pVirtualCell->setVirtualCell(BrTRUE);
				pVirtualCell->setFrame(pVirtualCellFrame);
				pVirtualCellFrame->setCell(pVirtualCell);
				pNewCellList->insertAtTail(pVirtualCell);
				//����� ��û virtual cell�� ���� �Ӽ��� �ٷ� �� cell�� ù ��° ���� �Ӽ����� ����
				if(pVirtualCell->getNext())
				{
					CLine* pNextCellLine = pVirtualCell->getNext()->getFirstLine();
					CLine* pCurCellLine = pVirtualCell->getFirstLine();
					pCurCellLine->setParaID(pNextCellLine->getParaID());
				}

			}

	
			if(bAdd)
			{
				if(pNewCellList->getTotalCellNum() == 0)
					pNewCellList->setCell(pNewCell);
				else 
					pNewCellList->insertAtTail(pNewCell);
			}	


			if(a_pDocxTable->m_pDocxTblPr && (!a_pDocxTable->m_pGridColArray || a_pDocxTable->m_pGridColArray->GetSize() <= 0))
			{
				if(nColNum == (nCol + 1) && a_pDocxTable->m_pDocxTblPr->m_nWidth > cellRect.Right())
					cellRect.nRight = a_pDocxTable->m_pDocxTblPr->m_nWidth;
			}


			nCurTableRight = (nCurTableRight < cellRect.Right()) ? cellRect.Right() : nCurTableRight;
			nCurRowRight = cellRect.Right();
		}

		CBCell* pLastCell = pNewCell;

		if(nGridAfter || (a_pDocxTable->m_pGridColArray && a_pDocxTable->m_pGridColArray->size() > nNumGridSpan && pNewCell->right() < nGridColWidth))
		{			
			CBCell* pVirtualCell = BrNEW CBCell(pNewCellList);
			BRect cellRect(pNewCell->right(), pNewCell->top(), nGridColWidth , pNewCell->bottom());
			if(pNewCell->getAssignHgt())
				pVirtualCell->setAssignHgt(pNewCell->getAssignHgt());

			nCurTableRight = (nCurTableRight < cellRect.Right()) ? cellRect.Right() : nCurTableRight;
			nCurRowRight = cellRect.Right();

			CFrame* pVirtualCellFrame = createFrame(CELLFRAME, &cellRect, BrFALSE, m_pCurFrame->getPageNum(), BrFALSE);
			CLineList* pLineList = ftLibrary::CreateLineList(pVirtualCellFrame);
			CLine* pLine = ftLibrary::CreateLine(pLineList);
			ftLibrary::AddCharSet(pLine, ASCII_CODE_CR);
						pVirtualCell->setVirtualCell(BrTRUE);
			pVirtualCell->setFrame(pVirtualCellFrame);
			pVirtualCellFrame->setCell(pVirtualCell);
			pNewCellList->insertAtTail(pVirtualCell);
			//����� ��û virtual cell�� ���� �Ӽ��� �ٷ� �� cell�� ù ��° ���� �Ӽ����� ����
			if(pVirtualCell->getPrev())
			{
				CLine* pPrevCellLine = pVirtualCell->getPrev()->getFirstLine();
				CLine* pCurCellLine = pVirtualCell->getFirstLine();
				pCurCellLine->setParaID(pPrevCellLine->getParaID());
			}

			pLastCell = pVirtualCell;
		}

		if(pLastCell->right() != nCurTableRight)
		{
			if(lastCellArray.size() > 0)
			{
				CBCell* preRowLastCell = lastCellArray.at(lastCellArray.size() - 1);
				if( pLastCell->bottom() > preRowLastCell->bottom())
				{
					if(pLastCell->right() < nCurTableRight)
						pLastCell->setRight(nCurTableRight);
				}
			}						
		}

		lastCellArray.Add(pLastCell);


		if(pNewCellList->getTotalCellNum() != 0)
		{
			if(0 == nRow)
				pTable->setCellList(pNewCellList);
			else
				pTable->getLastCellList()->insertAfter(pNewCellList);

			nCurTableBottom = pNewCellFrame->getFrameRect()->Bottom();
		}		

// 		if((!pTable->getCellSpace() && !m_bHeaderFooter && !a_bInCell && !pDocxTblPr->m_bBidi && (CheckSendArrangeTable(nCurTableBottom, MergeColums))))
// 		{
// 			SendArrangeTable(a_pDocxTable, nRow+1);
// 			a_pTableFrame->setDoneResizeTable(BrFALSE);
// 			m_bSuspendXmlParser = BrFALSE;
// 			break;
// 		}
	}

	pFrameRect->nRight = nCurTableRight /*+ nCellSpacing*/;
	pFrameRect->nBottom = nCurTableBottom /*+ nCellSpacing*/;

	return BrTRUE;
}

CFrame*	CDocxConv::PrepareConvertTable(CDocxTable* a_pDocxTable, CLineList* a_pLineList, BrBOOL	a_bInCell)
{
	if(!a_pDocxTable || !a_pDocxTable->m_pTableFrame)
	{
		SetErrorFReturn(CFilterErrorObj(kPoErrImportError, __FILE__, __LINE__));
		return BrNULL;
	}
	if(m_pNotCompleteTable && !a_bInCell)
	{
		CFrame* pTableFrame = SearchNotCompleteTable(a_pLineList);

		if(!pTableFrame)
		{
			SetErrorFReturn(CFilterErrorObj(kPoErrImportError, __FILE__, __LINE__));
			return BrNULL;
		}

		CBTable *pTable = static_cast <CBTable*> (pTableFrame->getSubFrame());
		while (pTable)
		{
			if(pTable->getNext())
				pTable = pTable->getNext();
			else
			{
				a_pDocxTable->m_pTableFrame = pTable->getFrame();
				break;
			}
		}
		a_pDocxTable->m_pTableFrame->setDoneResizeTable(BrFALSE);
		return a_pDocxTable->m_pTableFrame;	
	}
	
	CBTable *pTable = static_cast <CBTable*> (a_pDocxTable->m_pTableFrame->getSubFrame());
	if(!pTable)
	{
		SetErrorFReturn(CFilterErrorObj(kPoErrImportError, __FILE__, __LINE__));
		return BrNULL;
	}
	
	BRect rcTableFrame;
	rcTableFrame.nLeft = rcTableFrame.nBottom = rcTableFrame.nTop = rcTableFrame.nRight = 0;

	// Table Editor Convert Procedure
	pTable->setID( theBWordDoc->getTableEngine()->getNextTableID() );    // 0 ���� ��ȿ

	//Table Style Setting
	if(a_pDocxTable->m_pTblStyle != BrNULL)
	{
		BrINT32 nTableStyleIndex = theBWordDoc->getStyleAttArray()->GetSTyleIndexByMSStyleID(a_pDocxTable->m_pTblStyle);
		if(nTableStyleIndex >= 0)
			pTable->setStyleArrayIndex(nTableStyleIndex);
	}
	else
		pTable->setStyleID(BR_TABLE_STYLE_NONE);

	return a_pDocxTable->m_pTableFrame;
}

CFrame*	CDocxConv::SearchNotCompleteTable(CLineList* pLineList)
{
	if(!pLineList)
		return BrNULL;

	CLine* pLine = pLineList->getLast();
	if(!pLine)
		return BrNULL;

	CFrame* pTableFrame = BrNULL;

	CCharSetArray* pCharsetArray =  pLine->getCharSetArray();
	for(BrINT32 i = 0; i<pCharsetArray->size();i++)
	{
		CCharSet Charset = pCharsetArray->at(i);
		if(Charset.getLinkType() == LINKTYPE::ANCHOR)
		{
			CFrame* pFrame = theBWordDoc->getAFrameList()->getFrame(Charset.getCode());
			if(pFrame && pFrame->GetClass() == TABLEFRAME)
			{
				pTableFrame = pFrame;				
				break;
			}
		}
	}

	return pTableFrame;

}

BrBOOL CDocxConv::SendArrangeTable(CDocxTable* a_pDocxTable, BrINT32 a_nRow)
{
	m_pNotCompleteTable = a_pDocxTable;
	m_pNotCompleteTable->m_nArrangeRow = a_nRow;

	return BrTRUE;
}

BrBOOL	CDocxConv::CheckSendArrangeTable(BrINT32 a_nCurTableHeight, VMergeColumnList a_MergeColums)
{
	if ( m_pCurPage == BrNULL ){
		return BrFALSE;					/* ���� Page�� �����Ƿ� ������ �� ���� */
	}

	BrINT32 nLimitSize = m_nNeedReadPageNum * (m_pCurPage->getLastBasic()->height());

	if(nLimitSize > a_nCurTableHeight)
		return BrFALSE;
	
	if(a_MergeColums.count() > 0)
		return BrFALSE;

	if(m_nDoingType & DOC_TXBXCONTENT)
		return BrFALSE;

	return BrTRUE;
}

BrBOOL	CDocxConv::ConvertMergeCell(CBCell* a_pCurCell, CDocxCell* a_pDocxCell, CDocxTable* a_pDocxTable, BrINT32 a_nCurGridNum, BrINT32 a_nCurRowNum, VMergeColumnList* a_pMergeColums, BrBOOL& a_bADD, CCellList* curCellList, BrINT32& curTableBottom)
{
	if(!a_pCurCell || !a_pDocxCell || !a_pMergeColums)
		return SetErrorFReturn(CFilterErrorObj(kPoErrImportError, __FILE__, __LINE__));
	CDocxTcPr* pCurDocxTcPr = a_pDocxCell->m_pDocxTcPr;
	
	if(!pCurDocxTcPr || !pCurDocxTcPr->m_bVMerge)
		return SetErrorFReturn(CFilterErrorObj(kPoErrImportError, __FILE__, __LINE__));

	a_bADD = BrTRUE;

	if (pCurDocxTcPr->m_bRestart ) 
	{
		VMergeCellList* pVMergeCellList = BrNEW VMergeCellList();
		pVMergeCellList->SetStartMergeCell(a_pCurCell);
		pVMergeCellList->SetGridSpan(a_nCurGridNum);
		pVMergeCellList->SetWidth(pCurDocxTcPr->m_nWidth);
		BrINT32 nRowSize = a_pDocxTable->m_pDocxRowArray->GetSize();

		for (BrINT32 i = a_nCurRowNum + 1; i < nRowSize; i++) 
		{
			CDocxCell* pMergeCell = BrNULL;
			CDocxRow* pDocxRow = (CDocxRow*)a_pDocxTable->m_pDocxRowArray->GetAt(i);
			if(!pDocxRow->m_pDocxCellArray)
			{
				theBWordDoc->getAFrameList()->remove(a_pDocxTable->m_pTableFrame);
				BR_SAFE_DELETE(pVMergeCellList);
				return SetErrorFReturn(CFilterErrorObj(kPoErrCorruptFile, __FILE__, __LINE__));
			}
			BrINT32 nColSize = pDocxRow->m_pDocxCellArray->GetSize();
			BrINT32 nNumGridSpan = 0;
			for(BrINT32 j=0; j<nColSize; j++)
			{
				CDocxCell* pCurCell = pDocxRow->m_pDocxCellArray->at(j);
				if(pCurCell->m_pDocxTcPr)
					nNumGridSpan += pCurCell->m_pDocxTcPr->m_nGridSpan;
				else
					nNumGridSpan++;

				if(a_nCurGridNum == nNumGridSpan)
				{
					if(pCurCell->m_pDocxTcPr)
					{
						CDocxTcPr* pMerTcPr = pCurCell->m_pDocxTcPr;
						if(/*pMerTcPr->m_nWidth == pCurDocxTcPr->m_nWidth
							&&*/ pMerTcPr->m_bVMerge && pMerTcPr->m_bRestart == BrFALSE)
							pMergeCell = pCurCell;
					}
					break;
				}
			}
			if(pMergeCell)
				pVMergeCellList->append(pMergeCell);
			else
				break;
		}

		if(pVMergeCellList->count() > 0)
			a_pMergeColums->append(pVMergeCellList);
		else 
			BR_SAFE_DELETE(pVMergeCellList);
	}
	else
	{
		BrINT32 nIndex = -1;
		VMergeCellList* pMergeCellList = a_pMergeColums->SearchMergeCellList(a_pDocxCell,a_nCurGridNum, nIndex);
		if(!pMergeCellList)
		{
			//���� �� celllist�� ã�� ���ϴ� ��� curcell�� �ܺο��� ������. �ش� �ڵ忡�� ���� ���� ��
			//curCellList->insertAtTail(a_pCurCell);
			return BrTRUE;
		}
		if(nIndex < 0)
			return BrFALSE;
		CBCell* pStartMergeCell = pMergeCellList->GetStartMergeCell();

		//Bottom Size ����
		BrINT32 nNewBottom = a_pCurCell->getFrame()->bottom();
		if(nNewBottom > curTableBottom)
			curTableBottom = nNewBottom;
		pStartMergeCell->getFrame()->setBottom(nNewBottom);
		a_pCurCell->getFrame()->setRight(pStartMergeCell->getFrame()->right());

		//Bottom Border ����.
		CCellPen* pCellPen = pStartMergeCell->getLinesPen();
		CCellPen* pCurCellPen = a_pCurCell->getLinesPen();
		if(pCellPen && pCurCellPen && pCurCellPen->getBottom())
		{
			CCellLine* pNewbottom = BrNEW CCellLine();
			pNewbottom->setData(*pCurCellPen->getBottom());
			pCellPen->setBottom(pNewbottom);
		}	
		a_bADD = BrFALSE;
		pMergeCellList->removeAt(nIndex);
		if(pMergeCellList->count() == 0)
			a_pMergeColums->remove(pMergeCellList);

	}

	return BrTRUE;
}

BrBOOL	CDocxConv::ConvertCellBorderMargin(CDocxTblPr* a_pDocxTblPr, CDocxRow* a_pDocxRow, CDocxTcPr* a_pDocxTcPr,CBCell* a_pCurCell, BRect a_tableRect, CTableStyleMgr *a_pTableStyleMgr)
{
	if(!a_pCurCell)
		return SetErrorFReturn(CFilterErrorObj(kPoErrImportError, __FILE__, __LINE__));
	BRect rcBorderMargin(a_tableRect);
	rcBorderMargin.nLeft = rcBorderMargin.nRight = 108; //default
	rcBorderMargin.nBottom = rcBorderMargin.nTop = 0;
 	
	if(a_pTableStyleMgr)
	{
		BRect* pStyleCellborderMargin = a_pTableStyleMgr->getCellBorderMargin(a_pCurCell);
		if(pStyleCellborderMargin)
			rcBorderMargin = *pStyleCellborderMargin;
	}

	if(a_pDocxTblPr)
	{
		if(a_pDocxTblPr->m_cLeftMar.m_cType[0] != 0)
			rcBorderMargin.nLeft = a_pDocxTblPr->m_cLeftMar.m_nWidth;
		if(a_pDocxTblPr->m_cRightMar.m_cType[0] != 0)
			rcBorderMargin.nRight = a_pDocxTblPr->m_cRightMar.m_nWidth;
		if(a_pDocxTblPr->m_cBottomMar.m_cType[0] != 0)
			rcBorderMargin.nBottom = a_pDocxTblPr->m_cBottomMar.m_nWidth;
		if(a_pDocxTblPr->m_cTopMar.m_cType[0] != 0)
			rcBorderMargin.nTop = a_pDocxTblPr->m_cTopMar.m_nWidth;
	}

	if(a_pDocxTcPr)
	{
		if(a_pDocxTcPr->m_cLeftMar.m_cType[0] != 0)
		{
			rcBorderMargin.nLeft = a_pDocxTcPr->m_cLeftMar.m_nWidth;
			a_pCurCell->setBorderMarginLeft(&rcBorderMargin, BrTRUE);
		}
		if(a_pDocxTcPr->m_cRightMar.m_cType[0] != 0)
		{
			rcBorderMargin.nRight = a_pDocxTcPr->m_cRightMar.m_nWidth;
			a_pCurCell->setBorderMarginRight(&rcBorderMargin, BrTRUE);
		}
		if(a_pDocxTcPr->m_cTopMar.m_cType[0] != 0)
		{
			rcBorderMargin.nTop = a_pDocxTcPr->m_cTopMar.m_nWidth;
			a_pCurCell->setBorderMarginTop(&rcBorderMargin, BrTRUE);
		}
		if(a_pDocxTcPr->m_cBottomMar.m_cType[0] != 0)
		{
			rcBorderMargin.nBottom = a_pDocxTcPr->m_cBottomMar.m_nWidth;
			a_pCurCell->setBorderMarginBottom(&rcBorderMargin, BrTRUE);
		}
	}

	if(a_pDocxRow->m_nMaxTopCellMar > 0)
		rcBorderMargin.nTop = a_pDocxRow->m_nMaxTopCellMar;

	if(a_pDocxRow->m_nMaxBottomCellMar > 0)
		rcBorderMargin.nBottom = a_pDocxRow->m_nMaxBottomCellMar;

	a_pCurCell->setBorderMargin(&rcBorderMargin);
	return BrTRUE;
}	

BrBOOL	CDocxConv::ConvertCellLineList(CFrame* a_pCellFrame, CDocxCell* a_pDocxCell)
{
	if(!a_pCellFrame || !a_pDocxCell)
		return SetErrorFReturn(CFilterErrorObj(kPoErrImportError, __FILE__, __LINE__));
	
	CLineList *pLineList = (CLineList*)a_pCellFrame->getSubFrame();
// 	if( pLineList ) 
// 		BrDELETE pLineList;

	if(!a_pDocxCell->m_pLineList->getFirst() || a_pDocxCell->m_pLineList->getFirst()->getCharNum() == 0)
	{
		CLine* pLine = a_pDocxCell->m_pLineList->getFirst();

		if(!pLine)
			pLine = ftLibrary::CreateLine(a_pDocxCell->m_pLineList);
		else if(pLine->getCharSetArray() == BrNULL)
			ftLibrary::CreateCharSetArray(pLine);

		ftLibrary::AddCharSet(pLine, ASCII_CODE_CR);
	}

	a_pCellFrame->setSubFrame(  a_pDocxCell->m_pLineList );
	((CLineList*)a_pCellFrame->getSubFrame())->setFrame(a_pCellFrame); //direct read�� �ݵ�� �����ؾ���..
	a_pDocxCell->m_pLineList = NULL;

	return BrTRUE;
}

BrBOOL	CDocxConv::ConvertTcPr(CDocxTcPr* a_pDocxTcPr, CBCell* a_pCurCell, CTableStyleMgr* a_pTableStyleMgr)
{
	if(!a_pDocxTcPr)
		return SetErrorFReturn(CFilterErrorObj(kPoErrImportError, __FILE__, __LINE__));
	
	//cnf style setting for style export
	BrINT32 nTrCnfStyle = 0;
	CDocxTableStyle::ConvertCnfStyle(a_pDocxTcPr->m_cCnfStyle, nTrCnfStyle);
	a_pCurCell->setCnfMask(nTrCnfStyle);
	
	//arrange (��������)	
	if (a_pTableStyleMgr) //�⺻ ���̺� ��Ÿ�Ͽ��� ���� ���� ���� ������, ����� ��Ÿ�Ͽ��� ���� �Ҽ� �ֱ� ������, Table Style�� ������ setting ��.
		a_pCurCell->setArrangePos(a_pTableStyleMgr->getCellArrangePos(a_pCurCell));

	if(a_pDocxTcPr->m_nVAlign != 0xff)
		a_pCurCell->setArrangePos(a_pDocxTcPr->m_nVAlign);

	// text direction and flow
	a_pCurCell->setDirection(a_pDocxTcPr->m_bDirection);

	a_pCurCell->setTextFlow(a_pDocxTcPr->m_bTextFlow);


	// set border info.
	if( a_pDocxTcPr->m_pShd )
		a_pDocxTcPr->m_pShd->SetShading(a_pCurCell);
		
	return BrTRUE;
}

BrBOOL	CDocxConv::ConvertTrPr(CDocxTrPr* a_pDocxTrPr, CBTable* a_pTable, CCellList* a_pCurCellList, BrINT32 a_nCurRow )
{
	if(!a_pDocxTrPr)
		return BrTRUE;
	// MS���� ���̺� �� ���� '�ּ�' ���� �� w:hRule attribute �������� ����.	
	// w:hRule = "atLeast"�� �����ϴ� ��� �ּҸ� �ڵ����� �����ϸ� �ȵ�.(�ּ� : 0, �ڵ� : 1, ���� : 2)
	if(a_pDocxTrPr->m_ntrHeight && a_pDocxTrPr->m_bHeight && a_pDocxTrPr->m_hRule == 0xff)
		a_pDocxTrPr->m_hRule = 0;
	
	//cnf style setting for style export
	BrINT32 nTrCnfStyle = 0;
	CDocxTableStyle::ConvertCnfStyle(a_pDocxTrPr->m_cCnfStyle, nTrCnfStyle);
	a_pCurCellList->setCnfMask(nTrCnfStyle);
	a_pCurCellList->setCantSplit(a_pDocxTrPr->m_bCantSplit);
	CDocxTableStyle::ConvertRowCellSpacing(a_pCurCellList, a_pTable->getFrame()->width(), a_pDocxTrPr->m_nCellSpaceWidth, a_pDocxTrPr->m_cCellSpaceWidthType);

	if(a_pDocxTrPr->m_bHeading)
		a_pTable->setHeading(a_pTable->getHeading() + 1);

	if(a_pDocxTrPr->m_hRule != 0xff)
	{
		a_pCurCellList->setTableRowHeightType(static_cast <TsTRHType> (a_pDocxTrPr->m_hRule));
		a_pCurCellList->setTableRowHeight(a_pDocxTrPr->m_ntrHeight);
	}
	if(a_pDocxTrPr->m_bHidden)	//���� hidden setting���� �Ǵ� �ʿ�
		a_pCurCellList->setHidden(BrTRUE);

	return BrTRUE;
}

BrBOOL	CDocxConv::CaluateCellFrameRect(BRect& a_CellRect, CDocxTable* a_pDocxTable, CDocxCell* a_pDocxCell, BrINT32 a_nColSize, BrINT32 a_nRowHeight, BrINT32 a_nCurGridSpan, BrINT32 a_nCellSpacing)
{
	//CalculateCellWidth()�Լ��� gridcol ����� return	
	BrINT32 nCurSpanSize = 1;
	if(a_pDocxCell->m_pDocxTcPr && a_pDocxCell->m_pDocxTcPr->m_nGridSpan != 0)
		nCurSpanSize = a_pDocxCell->m_pDocxTcPr->m_nGridSpan;
	BrINT32 nTableWidht = 0;
	if(a_pDocxTable->m_pDocxTblPr)
		nTableWidht = a_pDocxTable->m_pDocxTblPr->m_nWidth;

	BrINT32 nWidth = GetCellWidth(a_pDocxCell->m_pDocxTcPr, a_nCurGridSpan, a_nCurGridSpan + nCurSpanSize, a_pDocxTable->m_pGridColArray, nTableWidht, a_nColSize, a_nCellSpacing);
	BrINT32 nHeight = a_nRowHeight;

	BrINT32 nLeftGrid = 0;
	if(!a_pDocxTable->m_pGridColArray || a_pDocxTable->m_pGridColArray->GetSize() <= 0)
	{
		nLeftGrid = a_CellRect.Right();
		if(a_pDocxCell->m_pDocxTcPr && a_pDocxCell->m_pDocxTcPr->m_nWidth)
			nWidth = a_pDocxCell->m_pDocxTcPr->m_nWidth;
	}
	else
		nLeftGrid = GetCurCellStart(a_pDocxTable->m_pGridColArray, a_nCurGridSpan, a_nCellSpacing);

	if(!a_pDocxTable->m_pTableFrame)
		return BrFALSE;
	a_CellRect.nLeft = nLeftGrid + a_pDocxTable->m_pTableFrame->left();
	a_CellRect.nRight = a_CellRect.nLeft + nWidth;
	a_CellRect.nBottom = a_CellRect.nTop + nHeight;

	return BrTRUE;
}

BrINT32	CDocxConv::GetCurCellStart(CDWordArray* gridColArray, BrINT32 startGrid, BrINT32 a_nCellSpacing)
{
	if(gridColArray == BrNULL || gridColArray->size() <= 0 || startGrid > gridColArray->size())
		return 0;

	BrINT32 startValue = 0;
	BrBOOL bCellSpace = BrFALSE;
	BrINT nHalfCellSpacing = a_nCellSpacing / 2;
	BrINT nGridColValue = 0;

	for(BrINT32 i = 0; i < startGrid; i++)
	{
		startValue += gridColArray->at(i);
		if (a_nCellSpacing > 0)
		{
			bCellSpace = BrTRUE;
			nGridColValue = gridColArray->at(i);
			if(i == 0)
				nGridColValue -= nHalfCellSpacing;

			if (gridColArray->size() == 1)
				nGridColValue -= nHalfCellSpacing;

			nGridColValue -= (nHalfCellSpacing * 2); //�⺻������ �� �ִ� Cell Spacing ����

			if (nGridColValue <= 0)
				bCellSpace = BrFALSE;

			if (bCellSpace)
			{
				if (i == 0)
					startValue -= (a_nCellSpacing * 1.5f);
				else
					startValue -= a_nCellSpacing;
			}
		}
	}
	return startValue;
}

void CDocxConv::ApplyCellSpacingToCellFrmae(BRect& a_CellRect, BrINT32 a_nColSize, BrINT32 a_nCurGridSpan, BrINT32 a_nCellSpacing)
{
	//first column, last column
	if(a_nCurGridSpan == 0 || a_nCurGridSpan == (a_nColSize - 1))
	{
		a_CellRect.nLeft += a_nCellSpacing;
		a_CellRect.nRight -= (a_nCellSpacing/2);
	}
	else
	{
		a_CellRect.nLeft += a_nCellSpacing;
	}
}

BrINT32 CDocxConv::GetCellWidth(CDocxTcPr* curTcPr, BrINT32 a_nStartGridSpan, BrINT32 a_nGridEndSpan, CDWordArray* gridColArray, BrINT32 a_nTableWidth, BrINT32 nTotalCellNum, BrINT32 a_nCellSpacing)
{
	BrINT32 cellWidth = 0;
	if(gridColArray && gridColArray->size() >= 1)
	{
		for(BrINT32 nStart = a_nStartGridSpan; nStart < a_nGridEndSpan && gridColArray->size() > nStart; nStart++)
		{
			cellWidth += gridColArray->at(nStart);
		}

		if (a_nCellSpacing > 0) //GridCol Width���� Cell Spacing ���� �߰��Ǿ� �־�, ���� Cell Width ����� ���� ���� ��
		{ // ���޵Ǵ� a_nCellSpacing �� ���� ����ÿ� 1/10 point��� �Ǿ� �־�, ���� * 2 �Ǿ� �־� �ش� �κ� �����ϵ��� ��
			//First, last col ���� ��ġ�� �� xml cell Space ���� * 4, �Ѱ��� ��ġ�� * 3, �� �� * 2

			BrINT nHalfCellSpacing = a_nCellSpacing / 2;
			BrINT nGridColValue = 0;

			if (a_nStartGridSpan == 0)
			{
				nGridColValue = gridColArray->at(a_nStartGridSpan);
				nGridColValue -= nHalfCellSpacing;

				if (gridColArray->size() == 1)
					nGridColValue -= nHalfCellSpacing;

				nGridColValue -= (nHalfCellSpacing * 2); //�⺻������ �� �ִ� Cell Spacing ����

				if(nGridColValue > 0)
					cellWidth -= nHalfCellSpacing; //First Col �� ���Ե� ��� ����
			}

			if (a_nGridEndSpan == gridColArray->size())
			{
				nGridColValue = gridColArray->at(a_nGridEndSpan - 1);
				if (gridColArray->size() == 1) //���� ���� ���Ե� Cell Spacing ����
					nGridColValue -= nHalfCellSpacing;

				nGridColValue -= nHalfCellSpacing;
				nGridColValue -= (nHalfCellSpacing * 2); //�⺻������ �� �ִ� Cell Spacing ����

				if(nGridColValue > 0)
					cellWidth -= nHalfCellSpacing; //������ Col�� ���Ե� ��� ����
			}
			
			cellWidth -= a_nCellSpacing; //�⺻������ ���� �Ǵ� ��

			//�Ʒ��� �۾��� ���� ���� Merge �Ǿ� ������, �ش� �������� cell space ������ ���� �ʱ� ������, ������ Cell Space width ���� ��������� ��
			//���� Table ���� ������ Cell Spacing ������ �Ǹ鼭, Cell Width�� �þ
			if ((a_nGridEndSpan - a_nStartGridSpan) > 1)
			{
				BrINT nGridColCount = a_nGridEndSpan - a_nStartGridSpan - 1;
				
				for (BrINT nIndex = a_nStartGridSpan; nIndex < a_nGridEndSpan; nIndex++)
				{
					nGridColValue = gridColArray->at(nIndex);
					if (nIndex == 0) //���� ���� ���Ե� Cell Spacing ����
						nGridColValue -= nHalfCellSpacing;

					if (nIndex == gridColArray->size() - 1) //������ ���� ���� Cell Spacing ����
						nGridColValue -= nHalfCellSpacing;

					nGridColValue -= (nHalfCellSpacing * 2); //�⺻������ �� �ִ� Cell Spacing ����

					if (nGridColValue <= 0) //Cell Space���� ���� Grid Col Value�� Cell Space ó�� ���� ����. (XML �� Cell�� ������ tcW �� ���� �´� ���� Ȯ��)
						nGridColCount--;
				}

				cellWidth -= (a_nCellSpacing * nGridColCount);
			}
		}		
	}
	else    //table gridcoll element�� ���� ���
	{
		if(a_nTableWidth && nTotalCellNum)
			cellWidth = a_nTableWidth / nTotalCellNum;
		else if(curTcPr)
		{
			if( 0 == strcmp(curTcPr->m_cType, "pct"))
			{
				BrINT32 frameWidth = m_pCurPage->getFirstBasic()->width();
				cellWidth = (frameWidth * curTcPr->m_nWidth) / 5000;
			}
			else
				cellWidth = curTcPr->m_nWidth;

			if(!curTcPr->m_nWidth && nTotalCellNum && !cellWidth)
				cellWidth = m_pCurFrame->width() / nTotalCellNum;
		}

	}
	//BRTHREAD_ASSERT(cellWidth);
	return cellWidth;
}

BrINT32 CDocxConv::CalculateRowHeight(CDocxTable* a_pDocxTable, CDocxRow* a_pCurRow, BrINT32 a_nCurRow, BrINT32 a_nRowSize)
{
	CDocxTrPr* pCurTrPr = a_pCurRow->m_pDocxTrPr;
	BrINT32 nMarginSize = 0;
	BrINT32 nRowHeight = 0;
	if(a_pCurRow->m_nMaxTopCellMar > 0)
		nMarginSize += a_pCurRow->m_nMaxTopCellMar;
	if(a_pCurRow->m_nMaxBottomCellMar > 0)
		nMarginSize += a_pCurRow->m_nMaxBottomCellMar;
	if(pCurTrPr && (pCurTrPr->m_hRule == TS_TRH_ATLEAST || pCurTrPr->m_hRule == TS_TRH_EXACT))	//����
	{
		nRowHeight = (pCurTrPr->m_ntrHeight + nMarginSize); ////table engine���� ���̰� 0�̸� ������ �Ұ����Ͽ� �ּ� 1�� ��
		return nRowHeight <= 0 ? 1 : nRowHeight;
	}	
	
	BrINT32 nColSize = a_pCurRow->m_pDocxCellArray->GetSize();
	for(BrINT32 nCol = 0; nCol < nColSize; nCol++) 
	{
		CDocxCell* pDocxCell = (CDocxCell*)a_pCurRow->m_pDocxCellArray->GetAt(nCol);
		BrINT32 nCellHeight = GetCellAutoHeightToAbsolute(a_pDocxTable->m_pDocxTblPr, pDocxCell, a_nCurRow, a_nRowSize);
		if(nRowHeight < nCellHeight)
			nRowHeight = nCellHeight;
	}
	nRowHeight += nMarginSize;
	return nRowHeight <= 0 ? 1 : nRowHeight; //table engine���� ���̰� 0�̸� ������ �Ұ����Ͽ� �ּ� 1�� ��
}

BrINT32 CDocxConv::GetCellAutoHeightToAbsolute(CDocxTblPr* a_pDocxTblPr, CDocxCell *pDocxCell, BrINT32 a_nCurRow, BrINT32 a_nRowSize)
{
	CDocxTcPr *pDocxTcPr = pDocxCell->m_pDocxTcPr;
	BrINT32 nCellHeight = 0;
	//Top�� Bottom�� Margin�� ���Ѵ�.
	BrINT32 nTopMar = 0;
	BrINT32 nBottomMar = 0;

	if(a_pDocxTblPr)
	{
		nTopMar = a_pDocxTblPr->m_cTopMar.m_nWidth;
		nBottomMar = a_pDocxTblPr->m_cBottomMar.m_nWidth;
	}
	if(pDocxTcPr)
	{
		if(pDocxTcPr->m_cTopMar.m_nWidth > 0)
			nTopMar = pDocxTcPr->m_cTopMar.m_nWidth;
		if(pDocxTcPr->m_cBottomMar.m_nWidth > 0)
			nBottomMar = pDocxTcPr->m_cBottomMar.m_nWidth;
	}
	nCellHeight = nTopMar + nBottomMar;

	//���� �� ������ �ƴ� ���
	BrINT32 nTopBorderSz = 0;
	BrINT32 nBottomBorderSz = 0;
	if(a_pDocxTblPr)
	{
		if(a_nCurRow == 0)	//First's row
		{
			if(a_pDocxTblPr->m_pTopBorder && !(0 == strcmp(a_pDocxTblPr->m_pTopBorder->m_cType, "nil") || 0 == strcmp(a_pDocxTblPr->m_pTopBorder->m_cType, "none")))
				nTopBorderSz = BrMulDiv(a_pDocxTblPr->m_pTopBorder->m_nSize, 20, 8);
			if(a_nRowSize == 1)
			{
				if(a_pDocxTblPr->m_pBottomBorder && !(0 == strcmp(a_pDocxTblPr->m_pBottomBorder->m_cType, "nil") || 0 == strcmp(a_pDocxTblPr->m_pBottomBorder->m_cType, "none")))
					nBottomBorderSz = BrMulDiv(a_pDocxTblPr->m_pBottomBorder->m_nSize, 20, 8);
			}
		}
		else if(a_nCurRow != a_nRowSize - 1)	//Middle's row
		{
			if(a_pDocxTblPr->m_pInsideH && !(0 == strcmp(a_pDocxTblPr->m_pInsideH->m_cType, "nil") || 0 == strcmp(a_pDocxTblPr->m_pInsideH->m_cType, "none")))
				nTopBorderSz = BrMulDiv(a_pDocxTblPr->m_pInsideH->m_nSize, 20, 8);
		}
		else	//Last's row
		{
			if(a_pDocxTblPr->m_pBottomBorder && !(0 == strcmp(a_pDocxTblPr->m_pBottomBorder->m_cType, "nil") || 0 == strcmp(a_pDocxTblPr->m_pBottomBorder->m_cType, "none")))
				nBottomBorderSz = BrMulDiv(a_pDocxTblPr->m_pBottomBorder->m_nSize, 20, 8);
		}
	}
	if(pDocxTcPr && !pDocxTcPr->m_bVMerge)
	{
		if(pDocxTcPr->m_pTopBorder && !(0 == strcmp(pDocxTcPr->m_pTopBorder->m_cType, "nil") || 0 == strcmp(pDocxTcPr->m_pTopBorder->m_cType, "none")))
			nTopBorderSz = BrMulDiv(pDocxTcPr->m_pTopBorder->m_nSize, 20, 8);
		if(pDocxTcPr->m_pBottomBorder && !(0 == strcmp(pDocxTcPr->m_pBottomBorder->m_cType, "nil") || 0 == strcmp(pDocxTcPr->m_pBottomBorder->m_cType, "none")))
			nBottomBorderSz = BrMulDiv(pDocxTcPr->m_pBottomBorder->m_nSize, 20, 8);
	}

	//TopBorder�� BottomBorder �� �� �ϳ��� �������� ��Ƽ� ���ؾ� �Ѵ�.
	//TopBorder�� �������� ��Ƽ� TopBorder Size�� ���ϰ�, ������ ���� BottomBorder Size���� �����ش�.
	if(a_nCurRow == 0 || a_nCurRow != a_nRowSize - 1)
	{
		nCellHeight += nTopBorderSz;
		if(a_nRowSize == 1)
			nCellHeight += nBottomBorderSz;
	}
	else
		nCellHeight += nTopBorderSz + nBottomBorderSz;

	CLine *pLine = pDocxCell->m_pLineList->getFirst();
	CCharSetArray* pCharSetArray = BrNULL;
	CCharSet *pLink = NULL;
	const PoTextAtt *pTextAtt = BrNULL, textAtt;
	int i = 0, nCharNum = 0, nParaID = 0;
	BrWORD nNewID = 0;
	double nLineSp = 0;
	CCharSet cBigCharOfPara; //2008-09-26
	int nBigCharOfPara = 0;
	int nTextID = -1;
	PoTextAttHandler* textAttHandler = theBWordDoc->getTextAttHandler();

	// lines height of cell
	while (BrNULL != pLine)
	{
		pCharSetArray = pLine->getCharSetArray();

		if (BrNULL == pCharSetArray)
			break;

		nCharNum = pCharSetArray->size();
		if( 0 == nCharNum)
			break;

		nCharNum = pCharSetArray->size();
		nParaID = pLine->getParaID();

		for (i = 0; i < nCharNum; i++)
		{
			pLink = (CCharSet *)pCharSetArray->GetAt(i);

			if( 0 == i ) {
				nBigCharOfPara = 0;
				nTextID = -1;
			}

			if( nTextID != pLink->m_wAttrID ) {
				pTextAtt = textAttHandler->getTextAtt(pLink->m_wAttrID);
				nNewID = pLink->m_wAttrID;
			}

			if( (pLink->isNormalTextLink() || pLink->isCRLink())
				&& nBigCharOfPara <= pTextAtt->getHanFSize())
			{
				nBigCharOfPara = pTextAtt->getHanFSize();
				cBigCharOfPara.setAttrID(pLink->m_wAttrID);
				cBigCharOfPara.setCode(pLink->m_wCode);
			}
		}

		nCellHeight += BrUtil::getParaHeight(pLine, pLine->getParaID(), cBigCharOfPara, nLineSp);
		if(pLink && pLink->isCRLink() || pLink->isSoftEnterLink() )
		{
			nBigCharOfPara = 0;
		}
		pLine = pLine->getNextLink();
	}

	return nCellHeight;
}

BrBOOL	CDocxConv::AddTableAtLine(CDocxTable* a_pDocxTable, CFrame* a_pTableFrame, CLineList* a_pLineList)
{
	if(!a_pDocxTable || !a_pTableFrame || !a_pLineList)
		return SetErrorFReturn(CFilterError(kPoErrArgumentNull));

	CLine *pLine = a_pLineList->getLast();
	if(!a_pLineList->getFrame()) //Frame setting
		a_pLineList->setFrame(m_pCurFrame);

	CBTable* pTable = (CBTable*)a_pTableFrame->getSubFrame();

	//cnf mask ����cnf�� ���� �������� ����
	theBWordDoc->getTableEngine()->getStyleMgr(pTable);
	theBWordDoc->getTableEngine()->updateCnfAndTableStyleID(pTable, BrTRUE, BrTRUE, BrFALSE, BrFALSE, BrTRUE);

	//���̺� ������ġ�� ���� ���ϱ� ����
	CDocxTblPr* pDocxTblPr = a_pDocxTable->m_pDocxTblPr;
	if(pDocxTblPr)
		pDocxTblPr->ConvertFramePositon(a_pTableFrame);
	
	CCharSetArray *pNodeArray = BrNULL;
	BrBOOL	bNeedCR = BrFALSE;
	BrBOOL	bCreateLine = BrFALSE;
	if(a_pDocxTable->m_bAnchor) //Anchor Table
	{
		if(pLine && (!pLine->getCharSetArray() || pLine->getCharNum() == 0 || !pLine->isCRWholeLine()))
		{
			if(pLine->getCharSetArray() == BrNULL )
				ftLibrary::CreateCharSetArray(pLine);

			pNodeArray = pLine->getCharSetArray();
		}
		else
		{
			if(m_pDocxPara)
				pLine = m_pDocxPara->CreateLine(a_pLineList);
			else
				pLine = ftLibrary::CreateLine(a_pLineList);

			pNodeArray = pLine->getCharSetArray();
			bCreateLine = BrTRUE;
		}
		bNeedCR = BrTRUE;
		if (a_pTableFrame && a_pTableFrame->isAnchored() && m_pDocxPara)
			m_pDocxPara->m_nParaWidth += a_pTableFrame->width();

		a_pTableFrame->setAnchorFlag(BrTRUE);
	}
	else // Float Table
	{
		a_pTableFrame->setAnchorFlag(BrFALSE);
		if(pLine)
		{
			if(pLine->getCharSetArray() == BrNULL )
				ftLibrary::CreateCharSetArray(pLine);
			else if(pLine->getCharSetArray()->size() > 0)
			{
				CCharSet LastNode = pLine->getCharSetArray()->at(pLine->getCharSetArray()->size()-1);
				if(LastNode.isCRLink())
					ftLibrary::CreateLine(a_pLineList);

				pLine = a_pLineList->getLast();

				if(pLine->getCharSetArray() == BrNULL )
					ftLibrary::CreateCharSetArray(pLine);
			}

			pNodeArray = pLine->getCharSetArray();
		}
		else
		{
			pLine = ftLibrary::CreateLine(a_pLineList);
			if(pLine == BrNULL)
				return BrFALSE;
			pNodeArray = pLine->getCharSetArray();
			if(pNodeArray == BrNULL)
				return BrFALSE;
		}
	}

	if(!theBWordDoc->getTableEngine()->checkTableValidate(pTable))
	{
		theBWordDoc->setEditProtect(BrTRUE);
		SetErrorTReturn(CFilterError(kPoWarnOpenBrokenFileAsReadOnly));
		GiveWarning(kPoWarnOpenBrokenFileAsReadOnly);
	}

	CCharSet cCharSet; 
	cCharSet.setLinkSubType(LINKTYPE::ANCHOR, 0);
	cCharSet.setCode(a_pTableFrame->getID());
	if(a_pDocxTable->m_bAnchor)	//[2013.06.01][������][M32362] Table Anchor ��ġ ���� ����.
		pNodeArray->InsertAt(pNodeArray->size(), cCharSet);
	else
	{
		//���� ���ο� ���� ���̺��� ���� �Ǵ� ��� ������ ���߾� insert�ϱ� ���� �˻�
		BrINT32 nInsertIndex = 0;
		for(BrINT32 nNodeIndex = 0; nNodeIndex < pNodeArray->size(); nNodeIndex++)
		{
			if(!pNodeArray->at(nNodeIndex).isAnchorLink())
				break;
			nInsertIndex++;
		}
		pNodeArray->InsertAt(nInsertIndex, cCharSet);
	}
	pLine->setTableFlag(BrTRUE);

	if (a_pDocxTable->m_bAnchor )	//Anchor Table Add	
	{
		a_pTableFrame->setAnchorLine(pLine);

		// add cr node
		if(m_pDocxPara && m_pDocxPara->m_pDocxTextAtt ) 
			cCharSet.setAttrID(m_pDocxPara->m_wTextAttID);
		else 
			cCharSet.setAttrID(0);

		cCharSet.setCode(ASCII_CODE_CR);
		pNodeArray->Add(cCharSet);

		BrWORD nParaID = 0;
		if( pLine->getPrev() ) 
			nParaID = pLine->getPrev()->getParaID();
		PoParaAtt paraAtt;
		//theBWordDoc->getParaAttArray()->getAttr(PoParaAtt, nParaID);

		paraAtt.setLineSpaceUnit(LINESP_UNIT_MULTIPLE);
		paraAtt.setLineSpace(1); //100%�� �ٲ۴�. 2008-07-08

		//jjoo:2008-07-16:tblpr�� ���� ���ΰ� indent�� �������� �ʴ´�.
		paraAtt.setIndent(0);
		paraAtt.setLeftMargin(0);
		paraAtt.setRightMargin(0);	
		if(pDocxTblPr)
		{
			paraAtt.setAlign(pDocxTblPr->m_nTableAlign);
			pTable->setAlign(pDocxTblPr->m_nTableAlign);
			paraAtt.setLeftMargin(pDocxTblPr->m_nTblIndent);
		}

		//[2013.01.21][������][M21696] Table�ڿ� �ٴ� CR�� Line Space �� ���̾ƿ� Ʋ������ ���� ����.
		paraAtt.setFrontParaSpace(0);
		paraAtt.setBackParaSpace(0);

		pLine->setParaID(theBWordDoc->getParaAttHandler()->insertParaAtt(paraAtt));
	}
	else //FloatTable Add
	{	

		a_pTableFrame->setAnchorFlag(0);
		pTable->setRunArroundType(PART_RUN_AROUND);

		if(pDocxTblPr)
		{
			pTable->setRunMargin(pDocxTblPr->m_nLeftFromText, pDocxTblPr->m_nTopFromText, 
				pDocxTblPr->m_nRightFromText, pDocxTblPr->m_nBottomFromText);

			pTable->setAllowOverlap(pDocxTblPr->m_bOverLap);
		}
	}

	// root table
	pLine->setBasePos(m_nCurParaHgt + a_pTableFrame->height());

	if(a_pDocxTable->m_nAllRowParaHgt >= a_pTableFrame->height())
		m_nCurParaHgt += a_pDocxTable->m_nAllRowParaHgt;
	else
		m_nCurParaHgt += a_pTableFrame->height();

	a_pTableFrame->setAnchorLine(pLine);
	if(!a_pDocxTable->m_bAnchor && bNeedCR)
		ftLibrary::AddCharSet(pLine, ASCII_CODE_CR);

	return BrTRUE;
}

BrBOOL CDocxConv::setFloatingFrameInfo(CFrame *pFrame, CDocxDrawStyle *pDocxDrawStyle, BrINT32 nWrappingMode /*=0*/) //, BrBOOL bLine	/*= BrFALSE*/, BrINT32 nLeftForLine /*=0*/, BrINT32 nTopForLine /*=0*/)
{
	if(pDocxDrawStyle)
		pDocxDrawStyle->ConvertFramePosition(pFrame);

	if(nWrappingMode > -1)
		pFrame->setRunArroundType(static_cast<RunAroundTypes>(nWrappingMode));

	//�ߺ��ڵ� ���� (DocxShape.cpp)
	if(pDocxDrawStyle && pDocxDrawStyle->m_pTextBox )
	{

	}
	else
	{
		pFrame->setArrangePos(TOP_ARRANGE);
		BRect rcMagin;
		rcMagin.nLeft = rcMagin.nRight = (BrLONG)INCHtoTWIP(0.1);
		rcMagin.nTop = rcMagin.nBottom = (BrLONG)INCHtoTWIP(0.05);
		pFrame->setBorderMargin(&rcMagin);

	}
	
	if(pDocxDrawStyle)
		pFrame->setRunMargin(&pDocxDrawStyle->m_nWrapMargin);

	return BrTRUE;
}

CFrame* CDocxConv::createImage(BRect &pRect, const BrCHAR* pPartName, const BrCHAR *pID, BrBOOL bAnchorType, BrBOOL bGroup, BYTE bClass/*=FIMAGE*/,ShapeType nShapeType, CDocxImageData *pImageData)
{
	//[2013.02.12][������][M-22146] FillImage�� ��� Line�޾��־����.
	BrBOOL nCreateEds = BrTRUE;
	if(bClass == PICTUREFRAME)
		nCreateEds = BrFALSE;

	BrINT32 nCurPage = 0;
	BrBOOL	bImageBullet = BrFALSE;

	nCurPage = getPageNum();

	if(0 == strcmp(pPartName, "word/numbering.xml") )
		bImageBullet = BrTRUE;

	CFrame *pImageFrame = createFrame(bClass, &pRect, bAnchorType, nCurPage, nCreateEds, BrTRUE, bImageBullet);

	if(!pImageFrame)
		return BrNULL;


	BrShape* pBwpShape = BrShape::createShape(nShapeType, *pImageFrame->getFrameRect());
	pImageFrame->setBorder( pBwpShape );
	BrImageAttr* pImgAttr = pBwpShape->getImageAttr();

	BString strPartName(pPartName);
	BString strRelID(pID);

	if(pImageData)
		CDocxUtil::convertImageAttribute(pImageData, pImgAttr);

	
	BLIPCROPINFO* pClipInfo = pImgAttr->GetClipInfo();


	if(bClass == PICTUREFRAME || bClass == OLEFRAME)
		pImgAttr = pBwpShape->getImageAttr();
	else
	{
		BrGrapAtt *pGrapAtt = pImageFrame->getBorder();
		pImgAttr = pGrapAtt->getBrush()->getImageAttr();
	}

	pImgAttr->setImageLoader(m_pPackage->GetImageLoader(strPartName, strRelID, pClipInfo->CropLeft, pClipInfo->CropTop, pClipInfo->CropRight, pClipInfo->CropBottom));

	return pImageFrame;
}

CFrame* CDocxConv::createImage(BRect &pRect, BrBOOL bAnchorType, BYTE bClass, ShapeType nShapeType)
{
	//[2013.02.12][������][M-22146] FillImage�� ��� Line�޾��־����.
	BrBOOL nCreateEds = BrTRUE;
	if(bClass == PICTUREFRAME)
		nCreateEds = BrFALSE;

	BrINT32 nCurPage = getPageNum();

	CFrame *pImageFrame = createFrame(bClass, &pRect, bAnchorType, nCurPage, nCreateEds, BrTRUE);

	if(!pImageFrame)
		return BrNULL;


	BrShape* pBwpShape = BrShape::createShape(nShapeType, *pImageFrame->getFrameRect());
	pImageFrame->setBorder( pBwpShape );

	return pImageFrame;
}

//ó�� ���ϴ� ������Ʈ�� �簢������
CFrame*	CDocxConv::MakeInvalidShape(BRect Rect, BrBOOL bAnchor)
{
	CFrame* pFrame = createFrame(FLOATFRAME, &Rect, bAnchor, getPageNum(), BrFALSE);
	if(!pFrame)
		return NULL;

	BrShape *pShape = NULL;
	pShape = BrShape::createShape(SHAPE_Rectangle, *pFrame->getFrameRect());
	pFrame->setBorder( pShape );

	BrGrapAtt* pGrapAtt = (BrGrapAtt*)pFrame->getBorder();
	if(pGrapAtt)
	{
		pGrapAtt->getBrush()->setForeColor(FILLTYPE_EMPTYBOX_COLOR);
		pGrapAtt->getPen()->setLineStyle(BMV_DASHSTYLE_NONE);
	}

	return pFrame;
}

CFrame* CDocxConv::createFootNoteFrame(BrINT32 textAttId, BrBOOL bFootnote, BrINT32 noteID, BrINT32 noteLineNum)
{
	BrBOOL bRtn = BrFALSE;
	CFrame* pFrame = BrNULL;
	CFrame* lastBasicFrame = BrNULL;
	lastBasicFrame = m_pCurPage->getLastBasic();

	if (eCOMPATIBILITY_V15 > theBWordDoc->getCompatibilityModeVersion())
		pFrame = m_pCurPage->getFrame(lastBasicFrame->getPairID());
	else 
		pFrame = m_pCurPage->getFirstNoteFrame();

	CLineList* noteLineList = BrNULL;
	if (!pFrame) {
		BRect frameRect;

		// get frame info
		frameRect.nLeft = lastBasicFrame->left();
		frameRect.nRight = lastBasicFrame->right();
		frameRect.nBottom = lastBasicFrame->bottom();
		frameRect.nTop = frameRect.nBottom - lastBasicFrame->top() / 2;

		// create footnote frame
		pFrame = createFrame(NOTEFRAME, &frameRect, BrFALSE, lastBasicFrame->getPageNum(), BrFALSE);

		pFrame->setPairID(lastBasicFrame->getID());
		lastBasicFrame->setPairID(pFrame->getID());
		m_pCurPage->getTFrameList()->insertAtTail(pFrame);
		pFrame->setPage(m_pCurPage);
	}

	if (!pFrame->getSubFrame()) {
		noteLineList = ftLibrary::CreateLineList(pFrame);
	}
	else
		noteLineList = (CLineList*)pFrame->getSubFrame();
		
	docxNote* noteItem = getDocxLoader()->getFootEndNote()->getFootNote(noteID);
		
	CLineList* docxNoteLineList = noteItem->getLineList();

	if (docxNoteLineList && docxNoteLineList->getFirst()) {
		CLine* pNewLine, * pInsert;
		pNewLine = docxNoteLineList->getFirst();
		CCharSet* itemChar = pNewLine->getCharSet(0);
		if (itemChar && itemChar->getSubType() & FOOTNOTE_ITEM)
			itemChar->setCode(noteLineNum);

		if (pNewLine != BrNULL) {
			while (pNewLine != BrNULL) {
				pInsert = docxNoteLineList->getNextInFrame(pNewLine);
				pNewLine->setNoteLineNum(noteLineNum);
				docxNoteLineList->unLink(pNewLine);
				noteLineList->insertAtTail(pNewLine);
				pNewLine = pInsert;
			}
		}
	}


	return pFrame;
}

//footnote, endnote
BrINT32 CDocxConv::createNotenode(BrINT32 textAttId, BrBOOL bInMainText, BrINT32 noteID, BrBOOL isFootNote)
{
	BrINT32 nNoteNum = 0;
	if(m_pCurSectionInformation == BrNULL)
		return SetErrorFReturn(CFilterErrorObj(kPoErrImportError, __FILE__, __LINE__));
	if(bInMainText)
	{
		BrINT32 nTotalNum = 0;
		//BYTE nNumKind;
		if(isFootNote)
		{
			CNote* pFootNote = theBWordDoc->getTypesetInfo()->getFootnoteOption();
			nTotalNum = pFootNote->getTotalNum();
			pFootNote->setTotalNum(nTotalNum + 1);
			pFootNote->setLineTopMargin(FOOTNOTE_TOP_MARGIN);
			pFootNote->setLineBottomMargin(FOOTNOTE_BOTTOM_MARGIN);

			CFrame* footNoteFrame = createFootNoteFrame(textAttId, BrTRUE, noteID, nTotalNum + 1);
		}
		else
		{
			CNote* pEndNote = theBWordDoc->getTypesetInfo()->getEndnoteOption();
			nTotalNum = pEndNote->getTotalNum();
			pEndNote->setTotalNum(nTotalNum + 1);
		}

		nNoteNum = nTotalNum + 1;
	}
	else
	{
		nNoteNum = m_pDocxLoader->getNoteLineNum();
	}
	
	return nNoteNum;
}

//jjoo:2009-01-19:LockedCanvas ������ ������ �׷����� ó����.
BrBOOL CDocxConv::ConvertLockedData(BCOfficeXShapeGroup* pShapeGroup, CDocxDrawingML *pDocxDrawing, CFrame* pGroupFrame /*= NULL*/, const BrCHAR* a_pCurPartName)
{
	if(!pShapeGroup || !pDocxDrawing)
		return SetErrorFReturn(CFilterErrorObj(kPoErrImportError, __FILE__, __LINE__));

	BRect ExtRect(0, 0, pDocxDrawing->m_extent.cx, pDocxDrawing->m_extent.cy);
	BRect GrpRect(0, 0, pShapeGroup->m_pGroupShapeProperty->m_extent.cx, pShapeGroup->m_pGroupShapeProperty->m_extent.cy);

	//Group ���� ��ü�� �Ӽ� ó��.
#ifdef SUPPORT_GRAPHIC_STYLE
	pShapeGroup->ConvertDocxOfficexShape(pGroupFrame);
#else	//SUPPORT_GRAPHIC_STYLE
	convertShapeAttFromLockedCanvas((BCOfficeXShape*)pShapeGroup, pGroupFrame);
#endif	//SUPPORT_GRAPHIC_STYLE

	BrINT32 i, sz = pShapeGroup->m_ShapeArray.size();
	BCOfficeXShape*	pShape;

	CFrame*	pFrame = NULL;
	BRect Rect;
	BrPoint offset;
	for(i=0; i<sz; i++)
	{
		pShape = pShapeGroup->m_ShapeArray[i];
		switch(pShape->m_nShape)
		{
		case SHAPE_NORMAL:	//���� ó�� �κ�
			{
				offset.x = ((BCOfficeXShapeNormal*)pShape)->m_pShapeProperty->m_offset.x;
				offset.y = ((BCOfficeXShapeNormal*)pShape)->m_pShapeProperty->m_offset.y;
				Rect.setRect(offset.x, offset.y, ((BCOfficeXShapeNormal*)pShape)->m_pShapeProperty->m_extent.cx + offset.x, ((BCOfficeXShapeNormal*)pShape)->m_pShapeProperty->m_extent.cy + offset.y);
				BrBOOL bAnchorType = BrFALSE; //Child ���� float����..
				pFrame = ConvertShapeFromLockedCanvas(pShape, Rect, ExtRect, GrpRect,bAnchorType);
				if(!pFrame)
					continue;
				if(((BCOfficeXShapeNormal*)pShape)->m_pCNVProperty)
				{
					if( !((BCOfficeXShapeNormal*)pShape)->m_pCNVProperty->m_strName.isEmpty())
					{
						pFrame->setIDForSeclectionPane(((BCOfficeXShapeNormal*)pShape)->m_pCNVProperty->m_id);
						pFrame->setNameForSelectionPane(((BCOfficeXShapeNormal*)pShape)->m_pCNVProperty->m_strName);
					}

					if (((BCOfficeXShapeNormal*)pShape)->m_pCNVProperty->m_phlinkClick)
					{
						DocxRelationField pDocxRelationField(m_pPackage, ((BCOfficeXShapeNormal*)pShape)->m_pCNVProperty->m_phlinkClick->m_pCurPartName, eFieldCode_DRAWINGHYPERLINK, getDocxLoader());

						pDocxRelationField.SetRelID(((BCOfficeXShapeNormal*)pShape)->m_pCNVProperty->m_phlinkClick->m_pRID);
						pDocxRelationField.CreateStartLink(getCurLineList(), 0, m_nCaptionIDForEndLink);
						pDocxRelationField.ConvertEndRelationField(getCurLineList(), 0 );
						pFrame->setFieldID( pDocxRelationField.GetFieldID() );
					}
				}

			}
			break;
		case SHAPE_PICTURE:	//�׸� ó�� �κ�
			{
				offset.x = ((BCOfficeXShapePic*)pShape)->m_pShapeProperty->m_offset.x;
				offset.y = ((BCOfficeXShapePic*)pShape)->m_pShapeProperty->m_offset.y;
				Rect.setRect(offset.x, offset.y, ((BCOfficeXShapePic*)pShape)->m_pShapeProperty->m_extent.cx + offset.x, ((BCOfficeXShapePic*)pShape)->m_pShapeProperty->m_extent.cy + offset.y);
				pFrame = ConvertImageFromLockedCanvas(pShape, Rect);
			}
			break;
		case SHAPE_GRAPHICFRAME:
			{
				// [2011-06-27][Begin]-LockedCanvas���� Diagram�� ���Ե� ����� ó���߰�
				BrBOOL bAnchorType = !pDocxDrawing->m_bFloating;
				BCOfficeXGraphicData * pGraphicData = ((BCOfficeXShapeGraphicFrame*)pShape)->m_pGraphicData;		

				if(pGraphicData)
				{
					BRect GRect;

					if(pGraphicData->m_nGraphicType == BoraOfficeXGraphicTypeDiagrame)	//SHAPE_GRAPHICFRAME
					{
						BCOfficeXGraphicDiagram * pGraphicDataDgm = (BCOfficeXGraphicDiagram *)pGraphicData;

						BrUINT32 nSize = pGraphicDataDgm->m_ShapeArray.size();

						if(nSize)
						{
							BCOfficeXShape* pDgmShape;		

							BrPoint offset;
							BRect Rect;							
							CFrame* pGFrame=BrNULL;
							BrBOOL bShapeGroup = BrFALSE;

							for(BrUINT32 i = 1; i < nSize; i++)
							{
								pDgmShape = pGraphicDataDgm->m_ShapeArray.at(i);

								offset.x = ((BCOfficeXShapeNormal*)pDgmShape)->m_pShapeProperty->m_offset.x;
								offset.y = ((BCOfficeXShapeNormal*)pDgmShape)->m_pShapeProperty->m_offset.y;						
								Rect.setRect(offset.x, offset.y, ((BCOfficeXShapeNormal*)pDgmShape)->m_pShapeProperty->m_extent.cx + offset.x, ((BCOfficeXShapeNormal*)pDgmShape)->m_pShapeProperty->m_extent.cy + offset.y);

								if(pDgmShape->m_nShape == 1)			//SHAPE_NORMAL
									pFrame = ConvertShapeFromLockedCanvas(pDgmShape,Rect,ExtRect,GrpRect,bAnchorType , BrTRUE);
								else if(pDgmShape->m_nShape == 2)		//SHAPE_PICTURE
									pFrame = ConvertImageFromLockedCanvas(pDgmShape,Rect);
								else
									pFrame = MakeInvalidShape(Rect, bAnchorType);

								if(!pFrame)
									pFrame = MakeInvalidShape(Rect, bAnchorType);

								if(pFrame)
								{
									if(pGroupFrame)
									{
										CFrameList *pFrameList = (CFrameList*)pGroupFrame->getSubFrame();
										if(pFrameList)
											pFrameList->insertAtTail(pFrame);
									}
									else
										AddShapeFrame(pFrame);
								}
							}
						}
					}
					else if(pGraphicData->m_nGraphicType == BoraOfficeXGraphicTypeChart)//[2012.11.16][������] Group Chart Import ����.
					{
						BCOfficeXGraphicChart *pGraphicChartData = (BCOfficeXGraphicChart *)pGraphicData;
						BCOfficeXShapeGraphicFrame* pGraphicFrame = ((BCOfficeXShapeGraphicFrame*)pShape);

						BRect Rect(pGraphicFrame->m_offset.x, pGraphicFrame->m_offset.y, pGraphicFrame->m_extent.cx + pGraphicFrame->m_offset.x, pGraphicFrame->m_extent.cy + pGraphicFrame->m_offset.y);
						
						pFrame = ConvertImageFromChart(pGraphicChartData, Rect, bAnchorType);

						if(!pFrame)
							return BrFALSE;

						if(pGroupFrame)
						{
							CFrameList *pFrameList = (CFrameList*)pGroupFrame->getSubFrame();
							if(pFrameList)
								pFrameList->insertAtTail(pFrame);
						}
						else
							AddShapeFrame(pFrame);
						

					}
				}
			}
			break;
		case SHAPE_CONNECTION:	//���ἱ ó�� �κ�	//MistY Test - 2008.05.28
			{
				offset.x = ((BCOfficeXShapeConnection*)pShape)->m_pShapeProperty->m_offset.x;
				offset.y = ((BCOfficeXShapeConnection*)pShape)->m_pShapeProperty->m_offset.y;
				Rect.setRect(offset.x, offset.y, ((BCOfficeXShapeConnection*)pShape)->m_pShapeProperty->m_extent.cx + offset.x, ((BCOfficeXShapeConnection*)pShape)->m_pShapeProperty->m_extent.cy + offset.y);
				pFrame = ConvertShapeConnectionFromLockedCanvas(pShape, Rect);
			}
			break;
			
		case SHAPE_GROUP:	//�׷� Ŭ���� ����
			{
				BrBOOL bAnchorType = BrFALSE;

				offset.x = ((BCOfficeXShapeGroup*)pShape)->m_pGroupShapeProperty->m_offset.x;
				offset.y = ((BCOfficeXShapeGroup*)pShape)->m_pGroupShapeProperty->m_offset.y;
				Rect.setRect(offset.x, offset.y, ((BCOfficeXShapeGroup*)pShape)->m_pGroupShapeProperty->m_extent.cx + offset.x, ((BCOfficeXShapeGroup*)pShape)->m_pGroupShapeProperty->m_extent.cy + offset.y);
				pFrame = createFrame(GROUPFRAME, &Rect, bAnchorType, getPageNum(), BrTRUE);

				ConvertLockedData((BCOfficeXShapeGroup*)pShape, pDocxDrawing, pFrame, a_pCurPartName);

				if(pFrame)
				{
					if(bAnchorType)
					{
						//CDocxLockedCanvas�� �׷��� ������ ����Ƿ�, �׷���� �׷��� ���� ����� �����ʴ´�.
					}
					else	//Floating�϶� ó��
					{
						setDrawingFrameOnlyFloating(pFrame, pDocxDrawing);
					}
				}
			}
			break;
#ifdef SUPPORT_INKML
		case SHAPE_CONTENTPART:
			{
				BCOfficeXContentPart* pContentPart = (BCOfficeXContentPart*)pShape;
				pFrame = pContentPart->ConvertDocxContentPart(this, BrFALSE, a_pCurPartName);
			}
			break;
#endif	//SUPPORT_INKML

		default:
			break;
		}
		// [2011-06-27]-LockedCanvas���� Diagram�� ���Ե� ����� ó���߰�
		if(pShape->m_nShape != SHAPE_GRAPHICFRAME && pFrame)
		{
			if(pGroupFrame)
			{
				CFrameList *pFrameList = (CFrameList*)pGroupFrame->getSubFrame();
				if(pFrameList)
				{
					pFrameList->insertAtTail(pFrame);
					pFrameList->setParentFrame(pGroupFrame);
					pFrame->setGroupParent(pGroupFrame); //�θ��� instance ���� �ڽ������ӿ� ����
				}
			}
			else
				AddShapeFrame(pFrame);
		}

	}

	//[2014.01.28][MID-51299][������] group frame�� flip �� mirror ����
	if(pGroupFrame && pGroupFrame->isGroup())
		theBWordDoc->getCmdEngine()->convertGroupSubFramesMSToBWP(pGroupFrame);

	return BrTRUE;
}


CFrame* CDocxConv::ConvertImageFromLockedCanvas(BCOfficeXShape* pShape, BRect Rect, BrBOOL bAnchor)
{
	CFrame *pImageFrame = BrNULL;

	if(!pShape)
		return BrNULL;

	BCOfficeXShapePic* pPicture = ((BCOfficeXShapePic*)pShape);

	BCOfficeXBlipFillStyle* pBlipFill = pPicture->m_pBlipFill;
	if(!pBlipFill)
		return BrNULL;

	if(pBlipFill->m_strRelID.isEmpty() && pBlipFill->m_strLinkRelID.isEmpty())
		return BrNULL;

	pImageFrame = (CFrame*)createFrame(PICTUREFRAME, &Rect, bAnchor, getPageNum(), BrFALSE, 1);

	if(!pImageFrame)
		return BrNULL;

	//ä��� �׸�
	ShapeType dType = SHAPE_None;
	if(pPicture->m_pShapeProperty->m_pPresetShape)
		dType = (ShapeType)pPicture->m_pShapeProperty->m_pPresetShape->m_nShapeType;
	else
		dType = SHAPE_Rectangle;

	if(pPicture->m_pNVPicProperty && pPicture->m_pNVPicProperty->m_cNvPicPr && pPicture->m_pNVPicProperty->m_cNvPicPr->m_bPreferRelativeResize == BrFALSE)
		pImageFrame->setRelativeToOrgPictureSize(BrFALSE);

	BrShape *pBwpShape = NULL;
	pBwpShape = BrShape::createShape(dType, *pImageFrame->getFrameRect());
	pImageFrame->setBorder( pBwpShape );
	
	//���� Image�� �Ӽ� ó��
#ifdef SUPPORT_GRAPHIC_STYLE
	pShape->ConvertDocxOfficexShape(pImageFrame);
#else	//SUPPORT_GRAPHIC_STYLE
	convertShapeAttFromLockedCanvas(pShape, pImageFrame);
#endif	//SUPPORT_GRAPHIC_STYLE

	//[TID:987][��ȸ��]Luminance �Ӽ� ���޵��� �ʴ� ����
	//BrDrawUtil_BWP::setImageProperty(pBlipFill, pBwpShape->getImageAttr(), 1);

	return (CFrame*)pImageFrame;
}

CFrame* CDocxConv::ConvertShapeFromLockedCanvas(BCOfficeXShape* pShape, BRect Rect, BRect ExtRect, BRect GRect, BrBOOL bAnchor, BrBOOL bFixTextAngle)
{
	BCOfficeXShapeNormal* pShapeNor = (BCOfficeXShapeNormal*)pShape;

	BrBOOL bAnchorType = bAnchor;
	BrBOOL bCreatEds = BrFALSE;

	BrShape *pBwpShape = NULL;
	CFrame *pFrame = NULL;
	BrGrapAtt *pGrapAtt = BrNULL;
	ShapeType nShapeType = SHAPE_None;

	if( pShapeNor->m_pShapeProperty->m_pPresetShape )
	{
		nShapeType = (ShapeType)pShapeNor->m_pShapeProperty->m_pPresetShape->m_nShapeType;
		BCOfficeXBlipFillStyle*	pImageFillStyle = BrNULL;
		if(pShapeNor->m_pShapeProperty->m_pFillStyles && (pShapeNor->m_pShapeProperty->m_pFillStyles->GetFillType() == OfficeXFillTypeBlip))
		{
			pImageFillStyle = (BCOfficeXBlipFillStyle*)pShapeNor->m_pShapeProperty->m_pFillStyles;
			pFrame = createImage(Rect, bAnchorType, FLOATFRAME, nShapeType);
			if(!pFrame)
				return BrNULL;
		}
		else
		{
			pFrame = createFrame(FLOATFRAME, &Rect, bAnchorType, getPageNum(), BrTRUE);
			if(!pFrame)
				return BrNULL;
		}

		if( pShapeNor->m_pWPSDrawStyle)
			pShapeNor->m_pWPSDrawStyle->convertStyleAttr(pFrame, this);
		else if( pFrame->isText())//[2013.02.13][������][TID:12537] ������ CR�ȴ޷� �ؽ�Ʈ �Է� �ȵǴ� ���� ����.
		{
			CLineList *pLineList = (CLineList*)pFrame->getSubFrame();
			if( pLineList )
			{
				CLine* pLine = ftLibrary::CreateLine(pLineList);
				ftLibrary::AddCharSet(pLine, ASCII_CODE_CR);
			}
		}

		if( pShapeNor->m_pCNVShapeProperty && pShapeNor->m_pCNVShapeProperty->m_txBox)
			pFrame->setSubClass(TEXTBOXFRAME);		

		BrShape *pBwpShape = BrNULL;
		if(!pFrame->getBorder())
		{
			if(nShapeType == SHAPE_TextBox || nShapeType >= SHAPE_Max)
				nShapeType = SHAPE_Rectangle;
			pBwpShape = BrShape::createShape(nShapeType, *pFrame->getFrameRect());
			pFrame->setBorder( pBwpShape );
		}
		else
			pBwpShape = (BrShape *)pFrame->getBorder();
		
#ifdef SUPPORT_GRAPHIC_STYLE
		pShape->ConvertDocxOfficexShape(pFrame);
#else	//SUPPORT_GRAPHIC_STYLE
	convertShapeAttFromLockedCanvas(pShape, pFrame);
#endif	//SUPPORT_GRAPHIC_STYLE		

		BrGrapAtt *pGrapAtt = (BrGrapAtt*)pFrame->getBorder();
		// [2011-7-15]-ȸ������ �ִ� ��� Setó���� ���� �ڵ� �߰�
		if(pGrapAtt)
			pGrapAtt->setBaseAngle(pShapeNor->m_pShapeProperty->m_nBaseAngle);
		//[2011.11.14]][������][TID:1267] �ܵ� smart Art Merge
		if(pShapeNor->m_pShapeText) {
			if( OfficeXTextVerticalTypeEa == pShapeNor->m_pShapeText->m_pTextBodyProperty->m_nTextVertType )
				pFrame->setDirection(SERO);


			SetTextBoxFromLockedCanvas(pShapeNor, pFrame, ExtRect, GRect);	
		}
#ifndef SUPPORT_GRAPHIC_STYLE
		////[2013.02.18][������][TID:12537] BodyPr Import ����.
		if (pShapeNor->m_pWPSBodyProperty)
			ConvertShapeBodyPr(pFrame, pShapeNor->m_pWPSBodyProperty);
#endif// SUPPORT_GRAPHIC_STYLE
		return pFrame;
	}
	else if( pShapeNor->m_pShapeProperty->m_pCustGeomImport )
	{
		BCOfficeXBlipFillStyle*	pImageFillStyle = BrNULL;
		nShapeType = SHAPE_scribble;
		pFrame = createFrame(FLOATFRAME, &Rect, bAnchorType, getPageNum(), BrTRUE);
		if(!pFrame)
			return BrNULL;
		
		if( pShapeNor->m_pWPSDrawStyle)
			pShapeNor->m_pWPSDrawStyle->convertStyleAttr(pFrame, this);
		else if( pFrame->isText())//[2013.02.13][������][TID:12537] ������ CR�ȴ޷� �ؽ�Ʈ �Է� �ȵǴ� ���� ����.
		{
			CLineList *pLineList = (CLineList*)pFrame->getSubFrame();
			if( pLineList )
			{
				CLine* pLine = m_pDocxPara->CreateLine(pLineList);
				ftLibrary::AddCharSet(pLine, ASCII_CODE_CR);
			}
		}

		if(!pFrame->getBorder())
		{
			pBwpShape = BrShape::createShape(nShapeType, *pFrame->getFrameRect());
			pFrame->setBorder( pBwpShape );
		}
		else	
			pBwpShape = (BrShape *)pFrame->getBorder();
#ifdef SUPPORT_GRAPHIC_STYLE
		pShape->ConvertDocxOfficexShape(pFrame);
#else	//SUPPORT_GRAPHIC_STYLE
		convertShapeAttFromLockedCanvas(pShape, pFrame);
#endif	//SUPPORT_GRAPHIC_STYLE
		
		BrGrapAtt *pGrapAtt = (BrGrapAtt*)pFrame->getBorder();
		
		//�ؽ�Ʈ ����
		if(pGrapAtt)
		{
			SetTextBoxFromLockedCanvas(pShapeNor, pFrame, ExtRect, GRect);
			pGrapAtt->setBaseAngle(pShapeNor->m_pShapeProperty->m_nBaseAngle);
		}

		return pFrame;
	}

	return BrNULL;
}

#ifdef	DANDONG_SMARTART

CFrame* CDocxConv::ConvertSmartArtFromLockedCanvas(BCOfficeXShape* pShape, BRect Rect, BRect ExtRect, BRect GRect, BrBOOL bAnchor, BrBOOL bFixTextAngle)
{
	BCOfficeXShapeNormal* pShapeNor = (BCOfficeXShapeNormal*)pShape;

	BrBOOL bAnchorType = bAnchor;
	BrBOOL bCreatEds = BrFALSE;

	BrShape *pBwpShape = NULL;
	CFrame *pFrame = NULL;
	BrGrapAtt *pGrapAtt = BrNULL;
	ShapeType nShapeType = SHAPE_None;

	if( pShapeNor->m_pShapeProperty->m_pPresetShape )
	{
		nShapeType = (ShapeType)pShapeNor->m_pShapeProperty->m_pPresetShape->m_nShapeType;
		BCOfficeXBlipFillStyle*	pImageFillStyle = BrNULL;
		if(pShapeNor->m_pShapeProperty->m_pFillStyles && (pShapeNor->m_pShapeProperty->m_pFillStyles->GetFillType() == OfficeXFillTypeBlip))
		{
			pImageFillStyle = (BCOfficeXBlipFillStyle*)pShapeNor->m_pShapeProperty->m_pFillStyles;
			pFrame = createImage(Rect, bAnchorType, DIAGRAMXENTRY, nShapeType);
			if(!pFrame)
				return BrNULL;
		}
		else
		{ // Sample-1.docx����
			pFrame = createFrame(DIAGRAMXENTRY, &Rect, bAnchorType, getPageNum(), BrTRUE);
			if(!pFrame)
				return BrNULL;

			if(pShapeNor->m_bDrawing == BrTRUE)
				((CSmartArtEntry*)pFrame)->m_bDrawing = BrTRUE;
		}

		if( pShapeNor->m_pWPSDrawStyle) {
			pShapeNor->m_pWPSDrawStyle->convertStyleAttr(pFrame, this);
		}
		else if( pFrame->isText())//[2013.02.13][������][TID:12537] ������ CR�ȴ޷� �ؽ�Ʈ �Է� �ȵǴ� ���� ����.
		{ // Sample-1.docx����
			CLineList *pLineList = (CLineList*)pFrame->getSubFrame();
			if( pLineList )
			{ // Sample-1.docx����
				CLine* pLine = m_pDocxPara->CreateLine(pLineList);
				ftLibrary::AddCharSet(pLine, ASCII_CODE_CR);
			}
		}

		BrShape *pBwpShape = BrNULL;
		if(!pFrame->getBorder())
		{
			if(nShapeType == SHAPE_TextBox || nShapeType >= SHAPE_Max)
				nShapeType = SHAPE_Rectangle;
			pBwpShape = BrShape::createShape(nShapeType, *pFrame->getFrameRect());
			pFrame->setBorder( pBwpShape );
		}
		else
			pBwpShape = (BrShape *)pFrame->getBorder();

#ifdef SUPPORT_GRAPHIC_STYLE
		if(pShapeNor->m_bTextFrame == BrFALSE)
		{
			pShape->ConvertDocxOfficexShape(pFrame);
		}
		else
		{
			pShape->GetShapeProperty()->m_nRotate %= 360;

			if (pShape->GetShapeProperty()->m_nRotate < 0)
				pShape->GetShapeProperty()->m_nRotate += 360;

			pFrame->getBorder()->setRotation( pShape->GetShapeProperty()->m_nRotate);
		}
#else //SUPPORT_GRAPHIC_STYLE
		convertShapeAttFromLockedCanvas(pShape, pFrame);
#endif //SUPPORT_GRAPHIC_STYLE

		//[2012-07-09][toypilot] ���� fill�̹��� ȿ�� ����
		if(BrTRUE == pFrame->isFillImage())
		{
			BrGrapAtt *pGrapAtt = (BrGrapAtt*)pFrame->getBorder();
			if(pGrapAtt)
				pGrapAtt->getBrush()->setStyle(BMV_FILLTYPE_IMAGE);

			BrDrawUtil_BWP::setImageProperty(pImageFillStyle, pBwpShape->getBrush()->getImageAttr(), m_pDocxLoader->m_pTheme);
		}

		BrGrapAtt *pGrapAtt = (BrGrapAtt*)pFrame->getBorder();
		// [2013.12.15] [DanDong5] SmartArt�� Node�� ȸ���� �� ������ ȸ������ �ʴ� ������ ����.
		// BCOfficeXShapePropertyŬ���� m_nRotate�� m_nBaseAngle�� �������� �� �ʿ䰡 ����.
		// ����� ������ ȸ�������� m_nRotate Ȥ�� m_nBaseAngle�� ���� �����ǹǷ� �̿� ���Ͽ� ���� ó���� �����ϰ�����.
		// ppt������ �̿� ���Ͽ� �ٸ� ������� ó���ϰ�����(cmSlide::setDrawAttribute()�� �����Ұ�.)
		if(pGrapAtt != BrNULL && pFrame->GetClass() == DIAGRAMXENTRY && pShapeNor->m_pShapeProperty->m_nBaseAngle > 0)
			pGrapAtt->setRotation(pShapeNor->m_pShapeProperty->m_nBaseAngle);

		// ���������� �����Ѱ��� ��Ÿ���� ��ߺ����� Placeholder Text�� ǥ���ؾ� �ϴ°��� ��Ÿ���� ��ߺ����� ����
		if (pFrame && pFrame->GetClass() == DIAGRAMXENTRY) {
			// ���������� �����Ѱ��� ��Ÿ���� ��ߺ����� ����
			((CSmartArtEntry*)pFrame)->SetAlgType(pShapeNor->m_nAlgType);

			// Placeholder Text�� ǥ���ؾ� �ϴ°��� ��Ÿ���� ��ߺ����� ����
			((CSmartArtEntry*)pFrame)->SetPlaceHolderTextFlag(((BCOfficeXShapeNormal*)pShape)->m_bPhldr);
		}

		// [2013.12.15] [DanDong5] ����ȸ�������� ����
		// SmartArt�� Tx�˰������� autoTxRot�Ӽ��� �Ѱ��־� ����ȸ�������� �����Ѵ�.
		if (pFrame->GetClass() == DIAGRAMXENTRY) {
			CSmartArtEntry* pEntry = (CSmartArtEntry*)pFrame;
			if (pShapeNor->m_pShapeText != BrNULL)
				pEntry->AdjustTextRotation(pShapeNor->m_pShapeText->m_pTextBodyProperty->m_nAutoTxRotationType);
			else
				pEntry->AdjustTextRotation();

			// ������ �ʱ�ȸ�������� �����ϱ�
			BrINT32 nAngle = 0;
			if(pGrapAtt)
				nAngle = pGrapAtt->getRotation();
			pEntry->SetInitialRotateAngle(nAngle);
		}

		if(pShapeNor->m_pShapeText) {
			if( OfficeXTextVerticalTypeEa == pShapeNor->m_pShapeText->m_pTextBodyProperty->m_nTextVertType )
				pFrame->setDirection(SERO);

			// [DanDong2] [2014.01.21] �ʱ� ������ ȸ���� ��� ȸ���� ũ�⿡ �����Ͽ� ���ڷ��� �׸��� ���ϴ� ������ ����
			// ������ �����ϴ� SmartArt������ ���� CFrame��ü(��Ȯ���� CSmartArtEntry)�� NoOverFrame�������� True��
			// �����ǿ����� �����Ƿ� CFrame::getBoundary(BRect& rc, BrINT nMgnOpt, BrBOOL bIncludeTextArea)�Լ����� 
			// ȸ���� ũ�⿡ ������ ��Ȯ�� ���4����ũ�⸦ ���� ���Ѵ�.
			if (pFrame->GetClass() == DIAGRAMXENTRY) {
				pFrame->setNoOverFrame(BrTRUE);
			}

			SetTextBoxFromLockedCanvas(pShapeNor, pFrame, ExtRect, GRect);
			// [2015.08.14] ��üũ�⸦ �����ϱ�
			// [2015.08.27] ��������üũ����ġ������ �Ѿ���� ���ϴ� ���ǿ��� �Ʒ��� �ڵ嶧���� �ʱ�ǥ�ÿ��� 
			// ��üũ�Ⱑ Ŀ���� ������ ��Ÿ����. ���� �ش� �κ��� �ּ�ó���ϵ��� �Ѵ�.
			if (pFrame->GetClass() == DIAGRAMXENTRY && ((CSmartArtEntry*)pFrame)->IsEnableText()) {
				if (((CSmartArtEntry*)pFrame)->IsEmptyText()) // ���ڷ��̶��
					((CSmartArtEntry*)pFrame)->ReCalcEmptyTextFontSize();
				//else // ���ڷ��� �ƴ϶��
				//	((CSmartArtEntry*)pFrame)->CheckFontSize();
			}
		}

#ifndef SUPPORT_GRAPHIC_STYLE
		////[2013.02.18][������][TID:12537] BodyPr Import ����.
		if (pShapeNor->m_pWPSBodyProperty)
			ConvertShapeBodyPr(pFrame, pShapeNor->m_pWPSBodyProperty);
#endif //SUPPORT_GRAPHIC_STYLE

		return pFrame; // Sample-1.docx������ Frame�� ��ȯ.
	}

	return BrNULL;
}

#endif // DANDONG_SMARTART

CFrame*	CDocxConv::ConvertImageFromChart(BCOfficeXGraphicData *pGraphicData, BRect Rect, BrBOOL bAnchor/* = BrFALSE*/)
{
	if(!pGraphicData )
		return BrNULL;

	BrBOOL bIsChartEx = BrFALSE;
	if(pGraphicData->m_nGraphicType == BoraOfficeXGraphicTypeChart)
		bIsChartEx = BrFALSE;
	else if(pGraphicData->m_nGraphicType == BoraOfficeXGraphicTypeChartEx)
		bIsChartEx = BrTRUE;
	else
		return BrNULL;


	CFrame *pFrame = createFrame(CHARTFRAME, &Rect, bAnchor, getPageNum(), BrFALSE, 1);
	CBWPChart* pChart = ((CBWPChart*)pFrame);

	if(!pFrame)
		return BrNULL;


	if(bIsChartEx)
	{
		pChart->setChartEx(BrTRUE);
		pChart->setEmbedChartPackage( (BoraPackageBase*)pGraphicData->m_pPackage );
		pChart->setEmbedChartPartName( ((BCOfficeXGraphicChartEx*) pGraphicData)->m_strSrcPartName );
		pChart->setEmbedChartPartID( ((BCOfficeXGraphicChartEx*) pGraphicData)->m_strChartID );
	}
	else
	{
		pChart->setChartEx(BrFALSE);
		pChart->setEmbedChartPackage( (BoraPackageBase*)pGraphicData->m_pPackage );
		pChart->setEmbedChartPartName( ((BCOfficeXGraphicChart*) pGraphicData)->m_strSrcPartName );
		pChart->setEmbedChartPartID( ((BCOfficeXGraphicChart*) pGraphicData)->m_strChartID );
	}

	//pChart->ReadEmbedChart();
	
	return pFrame;
}
CFrame*	CDocxConv::ConvertShapeConnectionFromLockedCanvas(BCOfficeXShape* pShape, BRect Rect)
{//MistY Test - 2008.05.28
	BCOfficeXShapeConnection* pShapeConnection = (BCOfficeXShapeConnection*)pShape;

	BrBOOL bAnchorType = BrFALSE;
	BrBOOL bCreatEds = BrFALSE;

	BrShape *pBwpShape = NULL;
	CFrame *pFrame = NULL;
	ShapeType nShapeType = SHAPE_None;

	if( pShapeConnection->m_pShapeProperty->m_pPresetShape )
	{		
		if(SHAPE_Line == pShapeConnection->m_pShapeProperty->m_pPresetShape->m_nShapeType ||
			(pShapeConnection->m_pShapeProperty->m_pPresetShape->m_nShapeType >= SHAPE_StraightConnector1 && pShapeConnection->m_pShapeProperty->m_pPresetShape->m_nShapeType <= SHAPE_CurvedConnector5) )
		{
			pFrame = createFrame(FLOATFRAME, &Rect, bAnchorType, getPageNum(), BrTRUE);
			if(!pFrame)
				return BrNULL;

			nShapeType = (ShapeType)pShapeConnection->m_pShapeProperty->m_pPresetShape->m_nShapeType;
			if(nShapeType == SHAPE_TextBox || nShapeType >= SHAPE_Max)
				nShapeType = SHAPE_Rectangle;
			BrShape *pBwpShape = BrShape::createShape(nShapeType, *pFrame->getFrameRect());
			pFrame->setBorder( pBwpShape );
#ifdef SUPPORT_GRAPHIC_STYLE
			pShape->ConvertDocxOfficexShape(pFrame);
#else //SUPPORT_GRAPHIC_STYLE
			convertShapeAttFromLockedCanvas(pShape, pFrame);
#endif //SUPPORT_GRAPHIC_STYLE
		}

		return pFrame;
	}

	return BrNULL;
}

#ifndef SUPPORT_GRAPHIC_STYLE

BrBOOL CDocxConv::CheckConnectionLine(BCOfficeXShapeProperty* pShapeProperty)
{
	if(pShapeProperty->m_pPresetShape && 
		((pShapeProperty->m_pPresetShape->m_nShapeType >= SHAPE_StraightConnector1 && pShapeProperty->m_pPresetShape->m_nShapeType <= SHAPE_CurvedConnector5) || 
		(pShapeProperty->m_pPresetShape->m_nShapeType == SHAPE_FlowChartAlternateProcess )||(pShapeProperty->m_pPresetShape->m_nShapeType ==  SHAPE_Arc)) )
		return BrTRUE;
	else
		return BrFALSE;
}

BCOfficeXLineStyle* CDocxConv::ConvertLineRefToLineStyle(BCOfficeXShapeStyleRef* a_pLineRef, BCOfficeXThemeX* pUsedTheme)
{
	if(!a_pLineRef || !pUsedTheme)
		return BrNULL;

	//0, 1000 �� no background ��.
	if( a_pLineRef->m_nIndex==0 || a_pLineRef->m_nIndex==1000 )
		return BrNULL;

	BCOfficeXLineStyle* pLineStyle;

	if( a_pLineRef->m_nIndex < 1000 )
		pLineStyle = pUsedTheme->GetLineStyle(a_pLineRef->m_nIndex-1);
	else
		pLineStyle = pUsedTheme->GetLineStyle(a_pLineRef->m_nIndex%1000-1);

	return pLineStyle;
}

BCOfficeXFillStyle* CDocxConv::ConvertFillRefToFillStyle(BCOfficeXShapeStyleRef* a_pFillRef, BCOfficeXThemeX* pUsedTheme)
{
	if(!a_pFillRef || !pUsedTheme)
		return BrNULL;

	//0, 1000 �� no background ��.
	if( a_pFillRef->m_nIndex==0 || a_pFillRef->m_nIndex==1000 )
		return BrNULL;

	BCOfficeXFillStyle* pFillStyle;

	if( a_pFillRef->m_nIndex < 1000 )
		pFillStyle = pUsedTheme->GetFillStyle(a_pFillRef->m_nIndex-1);
	else
		//[2013.05.02][������] Index 1~999�� ��� FillStyleLst, 1001 �̻��� ��� BgFillStyleLst�� ���(0�� 1000�� ��� reference ���� ����)
		pFillStyle = pUsedTheme->GetBgFillStyle(a_pFillRef->m_nIndex%1000-1);

	return pFillStyle;
}

BCOfficeXEffectStyle* CDocxConv::ConvertEffectRefToEffectStyle(BCOfficeXShapeStyleRef* a_pEffectRef, BCOfficeXThemeX* pUsedTheme)
{
	if(!a_pEffectRef || !pUsedTheme)
		return BrNULL;

	//0, 1000 �� no background ��.
	if( a_pEffectRef->m_nIndex==0 || a_pEffectRef->m_nIndex==1000 )
		return BrNULL;

	BCOfficeXEffectStyle* pEffectStyle;

	if( a_pEffectRef->m_nIndex < 1000 )
		pEffectStyle = pUsedTheme->GetEffectStyle(a_pEffectRef->m_nIndex-1);
	else
		pEffectStyle = pUsedTheme->GetEffectStyle(a_pEffectRef->m_nIndex%1000-1);

	return pEffectStyle;
}

BrBOOL CDocxConv::convertShapeAttFromLockedCanvas(BCOfficeXShape* pShape, CFrame* pFrame)
{
	if(!pFrame)	return BrFALSE;

	BrGrapAtt *pGrapAtt = (BrGrapAtt*)pFrame->getBorder();
	if( !pGrapAtt ) 
		pGrapAtt = (BrGrapAtt*)pFrame->getSubFrame();

	BrShape* pSh = pFrame->getBorder();
	if(!pSh)
		return BrFALSE;


	BCOfficeXShapeProperty* pShapeProperty = pShape->GetShapeProperty();
	BCOfficeXShapeStyle*	pShapeStyle = pShape->GetShapeStyle();
#ifdef SUPPORT_GRAPHIC_STYLE
	if(pShapeStyle)
	{
		BrINT32 nStyleID = pShapeStyle->ConvertDocxShapeStyle();
		if(nStyleID > 0)
			pFrame->setShapeStyleID(nStyleID);
	}
#endif	//SUPPORT_GRAPHIC_STYLE

	if(!pShapeProperty || !pGrapAtt)
		return BrFALSE;

	pGrapAtt->setOffice2007Shape(1);

	BCOfficeXFillStyle*			pFillStyle = BrNULL;
	BCOfficeXLineStyle*			pLineStyle = BrNULL;
	BCOfficeXShapeStyleRef*		pRefFillStyle = BrNULL;
	BCOfficeXShapeStyleRef*		pRefLineStyle = BrNULL;
	//[2013.02.12][������][M-22146] ������ fontStyle �� ����.
	BCOfficeXShapeStyleRef*		pRefFontStyle = BrNULL;
	//[2013.04.01][������] ������ Shadow Effect �� ����.
	BCOfficeXShapeStyleRef*		pRefEffectStyle = BrNULL;
	BCOfficeXEffectStyle*		pEffectStyle = 	BrNULL;	

	//wps:style(Theme Reference)
	if( pShapeStyle )
	{
		BrINT32 i;
		BCOfficeXShapeStyleRef* pRef;
		for(i=0; i<(BrINT32)pShapeStyle->m_StyleRefs.size(); i++)
		{
			pRef = pShapeStyle->m_StyleRefs[i];
			switch(pRef->m_nRefType)
			{
			case OfficeXSpStyleRefFill:
				pRefFillStyle = pRef;
				break;
			case OfficeXSpStyleRefLine:
				pRefLineStyle = pRef;
				break;
			case OfficeXSpStyleRefFont:
				pRefFontStyle = pRef;
				break;
				//���� �ʿ��� �� ó��...
			case OfficeXSpStyleRefEffect:
				pRefEffectStyle = pRef;
				break;
			default:
				break;
			}
		}
	}

	//wps:spPr 
	if( pShapeProperty )
	{
		SetShapeGeom(pShapeProperty, pSh);

		pFillStyle = pShapeProperty->m_pFillStyles;
		pLineStyle = pShapeProperty->m_pLineStyle;
		pEffectStyle = pShapeProperty->m_pEffectStyle;
	}

	BoraOfficexColorMap		m_aUsedMap[COLOR_SCHEME_DEPTH];

	if(m_pDocxLoader->m_pSettings)
		memcpy(&m_aUsedMap, &m_pDocxLoader->m_pSettings->m_aMap, BrSizeOf(BoraOfficexColorMap)*COLOR_SCHEME_DEPTH);

	//LineStyle
	if ( pLineStyle || pRefLineStyle ) 
	{
		//Ref Setting
		if(pRefLineStyle)
		{
#ifndef SUPPORT_GRAPHIC_STYLE
			BCOfficeXLineStyle*	 tmpRefLineStyle = ConvertLineRefToLineStyle(pRefLineStyle, m_pDocxLoader->m_pTheme);
			if(tmpRefLineStyle)
				tmpRefLineStyle->ConvertDocxLineStyle(pRefLineStyle, pGrapAtt->getPen(), m_pDocxLoader->m_pTheme, m_aUsedMap, CheckConnectionLine(pShapeProperty));
#endif	//SUPPORT_GRAPHIC_STYLE
		}
		//shapePro Setting
		if(pLineStyle)
			pLineStyle->ConvertDocxLineStyle(BrNULL, pGrapAtt->getPen(), m_pDocxLoader->m_pTheme, m_aUsedMap, CheckConnectionLine(pShapeProperty));
	}
	else 
		pGrapAtt->getPen()->setLineStyle(BMV_DASHSTYLE_NONE);

	//FillStyle
	if ( (pFillStyle || pRefFillStyle) && !pShapeProperty->m_bNoFill)
	{
		if(pRefFillStyle)
		{
#ifndef SUPPORT_GRAPHIC_STYLE
			BCOfficeXFillStyle*	 tmpRefFillStyle = ConvertFillRefToFillStyle(pRefFillStyle, m_pDocxLoader->m_pTheme);
			if(tmpRefFillStyle)
				tmpRefFillStyle->ConvertDocxFillStyle(pRefFillStyle, pGrapAtt->getBrush(), m_pDocxLoader->m_pTheme, m_aUsedMap);
#endif	//SUPPORT_GRAPHIC_STYLE
		}
		if(pFillStyle)
			pFillStyle->ConvertDocxFillStyle(BrNULL, pGrapAtt->getBrush(), m_pDocxLoader->m_pTheme, m_aUsedMap);
	}
	else
		pGrapAtt->getBrush()->setStyle(BMV_FILLTYPE_NONE);

	//EffectStyle
	if( pEffectStyle || pRefEffectStyle || pFrame->GetClass() == PICTUREFRAME) //[2013.05.20][������]image pic:spPr ����
	{
		if(pRefEffectStyle)
		{
#ifndef SUPPORT_GRAPHIC_STYLE
			BCOfficeXEffectStyle* tmpRefEffectStyle = ConvertEffectRefToEffectStyle(pRefEffectStyle, m_pDocxLoader->m_pTheme);
			if(tmpRefEffectStyle)
			{
				tmpRefEffectStyle->ConvertDocxEffectStyle(pGrapAtt, m_pDocxLoader->m_pTheme, m_aUsedMap);
				//[2013.05.02][������]Theme�� effectStyle�� 3D Property �ִ� ��� ó��.
				SetShape3DProperty(tmpRefEffectStyle->m_pShape3DProperty, tmpRefEffectStyle->m_pScene3DProperty, pSh, pFrame, m_pDocxLoader->m_pTheme, m_aUsedMap);
			}
#endif	//SUPPORT_GRAPHIC_STYLE
		}
		if(pEffectStyle)
			pEffectStyle->ConvertDocxEffectStyle(pGrapAtt, m_pDocxLoader->m_pTheme, m_aUsedMap);

		SetShape3DProperty(pShapeProperty->m_pShape3DProperty, pShapeProperty->m_pScene3DProperty, pSh, pFrame, m_pDocxLoader->m_pTheme, m_aUsedMap);
	}
	else if(pShapeProperty->m_pShape3DProperty || pShapeProperty->m_pScene3DProperty)
	{
		//[2013.05.22][������][M-31129] �ܼ� 3Dȸ���� ������ ��� ó��
		SetShape3DProperty(pShapeProperty->m_pShape3DProperty, pShapeProperty->m_pScene3DProperty, pSh, pFrame, m_pDocxLoader->m_pTheme, m_aUsedMap);
	}

	//FontStyle
#ifndef SUPPORT_GRAPHIC_STYLE
	if( pFrame->GetClass() == FLOATFRAME && pFrame->getSubFrame() && pRefFontStyle)
		SetShapetTextFontStyle( pRefFontStyle, (CLineList*)pFrame->getSubFrame(), m_pDocxLoader->m_pTheme);
#endif	//SUPPORT_GRAPHIC_STYLE


	SetFlipAndRotation(pShapeProperty, pGrapAtt);

	return BrTRUE;
}

void CDocxConv::SetShape3DProperty(BCOfficeXShape3DProperty* a_pShape3DProperty, BCOfficeXScene3DProperty* a_pScene3DProperty, BrShape* a_pSh, CFrame* pFrame, BCOfficeXThemeX* a_pUsedTheme, BoraOfficexColorMap aUsedMap[])
{
	if(a_pShape3DProperty || a_pScene3DProperty ) 
	{
		CShape3DInfo CShape3DInfo;
		CShape3DInfo.convert3DShape(a_pShape3DProperty, a_pScene3DProperty, a_pUsedTheme ? a_pUsedTheme->GetSchemeColor() : BrNULL, aUsedMap);
		BrShape *pBwpShape = (BrShape*)pFrame->getBorder();
		if( CShape3DInfo.m_pMsod3DObject ) {
			CShape3DInfo.m_pMsod3DObject->m_fc3DLightFace |= 0x80008;
			a_pSh->set3DObjectProp(CShape3DInfo.m_pMsod3DObject);
			CShape3DInfo.m_pMsod3DObject = BrNULL;
		}
		else
		{
			CShape3DInfo.m_pMsod3DObject = BrNEW CMsod_3DObject();
			CShape3DInfo.m_pMsod3DObject->m_fc3DLightFace |= 0x80008;
			CShape3DInfo.m_pMsod3DObject->m_c3DExtrudeBackward = 0;
			a_pSh->set3DObjectProp(CShape3DInfo.m_pMsod3DObject);
			CShape3DInfo.m_pMsod3DObject = BrNULL;
		}
		if(  CShape3DInfo.m_pMsod3DStyle ) {
			a_pSh->set3DStyleProp(CShape3DInfo.m_pMsod3DStyle);
			CShape3DInfo.m_pMsod3DStyle = BrNULL;
		}
		pBwpShape->reCreateShape(*pFrame->getFrameRect());
	}
}

void CDocxConv::SetShapetTextFontStyle(BCOfficeXShapeStyleRef* pRefFontStyle, CLineList* pLineList, BCOfficeXThemeX* pUsedTheme)
{	
	if (!pUsedTheme) return;

	BrDWORD nColor = 0;
	BrBYTE	r=0x00, g=0x00, b=0x00;
	BCOfficeXColorSchemeAtom* pSchemeColor = pUsedTheme->GetSchemeColor();
	if(!pSchemeColor || !pRefFontStyle->m_pStyleColor || !pRefFontStyle->m_pStyleColor->m_pColorType)
		return;

	BCOfficeXColor* pScheme = pRefFontStyle->m_pStyleColor->m_pColorType;
	pScheme->GetColor(r, g, b, pSchemeColor,BrNULL);

	nColor = (((BrUINT32)((UINT8)(r))))|(((BrUINT32)((UINT8)(g)))<<8)|(((BrUINT32)((UINT8)(b)))<<16);

	for(BrINT32 i = 0; i<pLineList->getTotalLine(); i++)
	{
		CLine* pLine = pLineList->getNthLine(i);
		for(BrINT32 j = 0; j<pLine->getCharSetArray()->size(); j++)
		{
			CCharSet* pCharSet = pLine->getCharSetArray()->GetAt(j);
			PoTextAtt pTextAtt;
			theBWordDoc->getTextAttHandler()->getAttr(pTextAtt , pCharSet->getAttrID());
			if(pTextAtt.ExtAttFlag.flag.m_bAutoColor)
			{
				pTextAtt.setAutoColor(BrFALSE);
				pTextAtt.setTextColor(nColor);
				BrINT32 nTextId = theBWordDoc->getTextAttHandler()->getAttrID(pTextAtt);
				pCharSet->setAttrID(nTextId);
			}
		}
	}
}

void CDocxConv::SetShapeGeom(BCOfficeXShapeProperty* a_pShapeProperty, BrShape* a_pSh)
{
#ifdef NEW_SHAPE_MODULE

	if(a_pShapeProperty->m_pAdjust)
	{
		BrUINT32 i;
		for(i = 0; i < a_pShapeProperty->m_pAdjust->size(); i++)
			CDocxUtil::setShapeGeometry(a_pShapeProperty->m_pAdjust->at(i), i, a_pSh);
	}

	if(a_pShapeProperty->m_pCustGeomImport)
	{
		SetCustGeom(a_pShapeProperty->m_pCustGeomImport, a_pSh);
	}

#else //NEW_SHAPE_MODULE
	if( a_pShapeProperty->m_pPresetShape)//MistY - 2008.06.10
	{			
		for(int i=0; i<(int)a_pShapeProperty->m_pPresetShape->m_AdjustValueArray.size();i++)
		{
			BoraFormulaGuide* pf = a_pShapeProperty->m_pPresetShape->m_AdjustValueArray[i];
			if( pf->m_nFormulaIndex==BSG_FORMULA_VAL )
			{
				CDocxUtil::setShapeGeometry( BrAtol(pf->m_strVal1) ,i, a_pSh);
			}
		}
	}
#endif //NEW_SHAPE_MODULE
}

void CDocxConv::SetCustGeom(BCCustomGeometry* a_pCustGeom, BrShape* a_pSh)
{
	BrShapeProperty sPro;

	if(a_pCustGeom->m_pViewBox)
	{
		sPro.nType = eShapeViewBox;
		sPro.pPro = a_pCustGeom->m_pViewBox;

		a_pSh->getGeometryAttrs().Add(sPro);
		a_pCustGeom->m_pViewBox = BrNULL;
	}

	if(a_pCustGeom->m_pEquations && a_pCustGeom->m_bNeedEqution)
	{
		sPro.nType = eShapeEquations;
		sPro.pPro = a_pCustGeom->m_pEquations;

		a_pSh->getGeometryAttrs().Add(sPro);
		a_pCustGeom->m_pEquations = BrNULL;
	}

	if(a_pCustGeom->m_pSegments)
	{
		sPro.nType = eShapeSegment;
		sPro.pPro = a_pCustGeom->m_pSegments;

		a_pSh->getGeometryAttrs().Add(sPro);
		a_pCustGeom->m_pSegments = BrNULL;
	}

	if(a_pCustGeom->m_pCoordinates)
	{
		sPro.nType = eShapeCoordinates;
		sPro.pPro = a_pCustGeom->m_pCoordinates;

		a_pSh->getGeometryAttrs().Add(sPro);
		a_pCustGeom->m_pCoordinates = BrNULL;
	}

	if(a_pCustGeom->m_pAddColors)
	{
		sPro.nType = eShapeAdditionalColors;
		sPro.pPro = a_pCustGeom->m_pAddColors;

		a_pSh->getGeometryAttrs().Add(sPro);
		a_pCustGeom->m_pAddColors = BrNULL;
	}	
}

void CDocxConv::SetFlipAndRotation(BCOfficeXShapeProperty* a_pShapeProperty, BrGrapAtt* a_pGrapAtt)
{
	a_pShapeProperty->m_bFlipH = (a_pShapeProperty->m_bFlipH != -1) ? a_pShapeProperty->m_bFlipH : 0;
	a_pShapeProperty->m_bFlipV = (a_pShapeProperty->m_bFlipV != -1) ? a_pShapeProperty->m_bFlipV : 0;

	a_pShapeProperty->m_nRotate %= 360;

	if (a_pShapeProperty->m_nRotate < 0)
		a_pShapeProperty->m_nRotate += 360;

	a_pGrapAtt->setRotation( a_pShapeProperty->m_nRotate);

	//[2012.01.12][TID : 3302][���ؼ�] �̹��� ����/�¿� ���� ����
	if(a_pShapeProperty->m_bFlipV)
		a_pGrapAtt->setFlipY(BrTRUE);

	if(a_pShapeProperty->m_bFlipH)
		a_pGrapAtt->setFlipX(BrTRUE);
}

#endif	//SUPPORT_GRAPHIC_STYLE

void CDocxConv::SetTextBoxFromLockedCanvas(BCOfficeXShapeNormal* pShapeNor, CFrame* pFrame, BRect ExtRect, BRect GRect)
{
	if(ExtRect.IsEmpty() || GRect.IsEmpty())
		return;

	if ( pShapeNor->m_pShapeText && pShapeNor->m_pShapeText->m_TextParagraphArray.size())
	{
		if( BrNULL == pFrame->getSubFrame() )
		{
			pFrame->setClass(FLOATFRAME);
			pFrame->setSubFrame( pFrame->newElementByType(FLOATFRAME) );
		}

		CLineList *pLineList = (CLineList*)pFrame->getSubFrame();

		BCOfficeXShapeText* pShapeText = pShapeNor->GetShapeText();
		if (pShapeText && pLineList)
		{					
			BCOfficeXShapeStyleRef* pRefShapeStyle = BrNULL;	
			BCOfficeXShapeStyle*	pShapeStyle = pShapeNor->GetShapeStyle();
			if( pShapeStyle )
			{		
				for(BrINT32 i=0; i<(BrINT32)pShapeStyle->m_StyleRefs.size(); i++)
				{		
					if (pShapeStyle->m_StyleRefs[i]->m_nRefType == OfficeXSpStyleRefFont)
					{
						pRefShapeStyle = pShapeStyle->m_StyleRefs[i];
						break;
					}
				}
			}

			BCOfficeXTextParagraph* pPara;
			ParagraphTextRun* pTR;
			BCOfficeXTextRunProp* pTRProp;					

			BrINT32 nParaArrayCount = pShapeText->m_TextParagraphArray.size();
			for (BrINT32 jj=0 ; jj<nParaArrayCount ; jj++)
			{
				pPara = pShapeText->m_TextParagraphArray.at(jj);

				if (pPara)
				{
					BrWORD nTextID = 0;
					if(jj == 0)
					{
						pLineList->removeAll();
					}

					CLine* pLine = m_pDocxPara->CreateLine(pLineList);
					BrWORD nWParaAttID = SearchParaAttAndAddForLockedCanvas(pPara);	
					if(pLine)
						pLine->setParaID(nWParaAttID);

					BrINT32 nRunCount = pPara->m_TextRunArray.size();
					for (BrINT32 kk=0 ; kk<nRunCount ; kk++)
					{
						pTR = (ParagraphTextRun*)pPara->m_TextRunArray.at(kk);
						if (pTR && pLine)
						{
							PoParaAtt paraAtt;
							pTRProp = pTR->m_pTextRunProp;
							// [2015.07.24] ������ ���Ե� ��� �ش� ������ Frame����(equation) �߰��Ѵ�.
							if ((pTR->m_strText.compare(BString("m")) == 0) && pTR->m_pMathImporter != BrNULL)
								// if (pTRProp == BrNULL)
							{
#ifdef DANDONG_SMARTART  // [2015.07.24]
								theBWordDoc->getParaAttHandler()->getParaAtt(paraAtt, nWParaAttID);

								BMathManagerArray* pMathMgrArray = pTR->m_pMathImporter->GetMathManagerArray();
								for (int i = 0; i < pMathMgrArray->GetSize(); i++)
								{
									CMathManager* pMathManager = (CMathManager*)pMathMgrArray->at(i);
									CFrame *pEquationFrame = BrNULL;
									BRect rcFrame(0, 0, 0, 0);

									if(pMathManager)
									{
										// para�� alignment ����
										// para�� ���ĸ� ������� 
										if(((CMathImporter*)pTR->m_pMathImporter)->m_bUseMathPara)
										{
											paraAtt.setAlign(CENTER);

											BrINT32 nAlign = pMathManager->GetEquationAlignment();
											if(nAlign == eJC_CENTER)
												paraAtt.setAlign(CENTER);
											else if(nAlign == eJC_LEFT)
												paraAtt.setAlign(LEFT);
											else if(nAlign == eJC_RIGHT)
												paraAtt.setAlign(RIGHT);
											else if(nAlign == eJC_CENTER_GROUP)
												paraAtt.setAlign(CENTER);
											// m_wParaAttID = wParaAttID;
										}

										//��ü rect�� ���´�.
										pMathManager->GetEquationRect(BrNULL, &rcFrame);

										pEquationFrame = (CFrame*)createFrame(EQUATIONFRAME, &rcFrame, BrTRUE, getPageNum(), BrFALSE);
										if(pEquationFrame == BrNULL)
											continue;

										pEquationFrame->setSubFrame(pMathManager);
										// pEquationFrame->setFixSizeFlag(BrTRUE);
										pEquationFrame->setAutoResizeFlag(BrFALSE);
										pMathManager->setBoraDoc(pEquationFrame->getDocument());

										if(pEquationFrame && theBWordDoc && theBWordDoc->getAFrameList(m_pCurPage))
										{
											theBWordDoc->getAFrameList(m_pCurPage)->insertAtTail(pEquationFrame);

											CCharSet cCharSet;
											CCharSetArray *pCharSetArray = pLine->getCharSetArray();

											cCharSet.setCode(pEquationFrame->getID());
											cCharSet.setLinkSubType(LINKTYPE::ANCHOR, LINKTYPE::STANDARD);

											if(pCharSetArray)
												pCharSetArray->Add(cCharSet);
										}
									}
								}
#endif // DANDONG_SMARTART
								continue;
							}
							//������ �°� ��Ʈ ũ�� ����
							convertRatioFontSizeLockedCanvas(ExtRect, GRect, pTRProp);
							if (pTR->m_strText.length() > 0)
							{
								CCharSetArray *pCharSetArray = pLine->getCharSetArray();
								// �� ���ο� �ʹ� ���� CharSet Node�� �޸��� ���� �����ϱ� ���Ͽ� �ϴ� 128�� ��������...
								if(pCharSetArray && pCharSetArray->GetSize() > 0)
								{
									if( (0xd == pCharSetArray->getCharSet(pCharSetArray->GetSize()-1)->getCode()) 
										|| pCharSetArray->GetSize() > 128 )
									{
										CLineList *pLineList = pLine->getLineList();
										CLine* pNewLine = BrNEW CLine();
										if(pNewLine)
										{
											pLineList->insertAtTail(pNewLine);						
											CCharSetArray *pNewCharSetArray = BrNEW CCharSetArray;
											if(pNewCharSetArray)
												pNewLine->setCharSetArray(pNewCharSetArray);

											pLine = pNewLine;
										}
										BrWORD nWParaAttID = SearchParaAttAndAddForLockedCanvas(pPara);
										if(pLine)	
											pLine->setParaID(nWParaAttID);		
									}
								}

#ifdef DANDONG_SMARTART
								// [DanDong2] [2015.02.06] SmartArt�������� ��üũ���������
								// ��üũ�Ⱑ �����Ȱ��ΰ��� �Ǵ��ϱ�
								if (pFrame->GetClass() == DIAGRAMXENTRY && pTRProp != BrNULL && pTRProp->m_bFixedFontSize == BrTRUE) {
									pLine->setFixedFontSizeFlag(BrTRUE);
								}
#endif // DANDONG_SMARTART

								if(pPara->m_pTextParagraphStyle && pPara->m_pTextParagraphStyle->m_pBulletInfo && pFrame->GetClass() == DIAGRAMXENTRY)
									SearchBulletForLockedCanvas(pLine, pPara, pTRProp, pRefShapeStyle);	

								//������ �ؽ�Ʈ �Ӽ��� ã�� ������ �߰� 
								if(pRefShapeStyle )
									nTextID = SearchTextAttAndAddForLockedCanvas(pTRProp, pRefShapeStyle);
								else {
									BCOfficeXParagraphStyle *pParaStyle = pShapeText->m_pTextParaStyles->m_pDefaultStyle;
									//pParaStyle null ó��
									if( pParaStyle && pTRProp->m_nFontSize <= 0) {
										if( pParaStyle->m_pTextRunProp->m_nFontSize > 0 )
											pTRProp->m_nFontSize = pParaStyle->m_pTextRunProp->m_nFontSize;
										else if( pParaStyle->m_pTextRunProp->m_nKerning > 0 )
											pTRProp->m_nFontSize = pParaStyle->m_pTextRunProp->m_nKerning/100; 
									}

									nTextID = SearchTextAttAndAddForLockedCanvas(pTRProp, pRefShapeStyle);
								}
								const PoTextAtt *pTextAtt = theBWordDoc->getTextAttHandler()->getTextAtt(nTextID);
#ifdef DANDONG_SMARTART
								// 2013.10.01 [DanDong8]
								// DOCX���Ϸκ��� SmartArt������ ���� ������ paragraph���ú����� RTL������ �����ȴ�.
								// CFrame������ theBWordDoc�� �����ǿ��ִ� �ش� PoTextAtt��ü�κ��� RTL������ �����ϰ� �ǿ��ִ�.
								// �׷��� ���������� ���� ������ ���� �� ��ü�� RTL������ �ݿ������� SmartArt������ �ݿ����� �����Ƿ�
								// �Ʒ��� ���� paragraph�� �ִ� RTL������ �ش� PoTextAtt��ü�� �ݿ��Ͽ��� �Ѵ�.
// 								if (pTextAtt != BrNULL && pPara->m_pTextParagraphStyle && pTextAtt->getBiDi() != (pPara->m_pTextParagraphStyle->m_nRtl? true : false)) 
// 									pTextAtt->setBiDi((pPara->m_pTextParagraphStyle->m_nRtl == 1) ? BrTRUE : BrFALSE);

								// [2015.09.02] SmartArt�� �������� paragraph������ ��Ȯ�� �������� �ʴ� ����
								// SmartArt����ǥ�ÿ��� ����Ǵ� ���� Paragraph������ �Ϲݺ���ǥ�ÿ� ����Ǵ� paragraph������ �ٸ���.
								// data.xml���� ǥ�ؼ����� ��� ���� paragraph������ ���������� �ʴ�.
								// SmartArt������ ǥ�� paragraph������ ��üũ�⿡ �����ϸ� ������ ����.
								// Line Spacing = Multiple, At = 0.9, Before = 0pt, After = ��üũ��*0.42 pt
								if (pFrame->GetClass() == DIAGRAMXENTRY && pTextAtt != BrNULL) {
									paraAtt.setLineSpace(LINESP_SMARTART_DEFAULT_VALUE);
									paraAtt.setFrontParaSpace(0);
									paraAtt.setBackParaSpace(((BrFLOAT)pTextAtt->getHanFSize() * 0.42f));
								}
#endif // DANDONG_SMARTART
								BrWORD wCode;
								CCharSet cCharSet;
								BString strText(pTR->m_strText);
								BrINT32 nLen = strText.length();
								BrINT32 j;
								for( j = 0; j < nLen; j++)
								{
									wCode = strText.at(j).unicode();
									if (pTRProp && ((pTRProp->m_nCapital == OfficeXCapitalAll) || (pTRProp->m_nCapital == OfficeXCapitalSmall)))
									{//�ҹ��ڸ��빮�ڷ�, ��δ빮�ڷ�
										if( wCode >= 0x61 && wCode <=0x71 )
											wCode = wCode - 0x20;
									}
									if( m_bOnlyEngPara && wCode > 0x00FF && wCode < 0xF000 )
									{
										m_bOnlyEngPara = BrFALSE;
									}

									cCharSet.setCode(wCode);
									cCharSet.setAttrID(nTextID);
									pCharSetArray->Add(cCharSet);
								} 
							}

							nWParaAttID = theBWordDoc->getParaAttHandler()->insertParaAtt(paraAtt);
							if(pLine)
								pLine->setParaID(nWParaAttID);
						}
					}

					//�� ���� ���� CR �߰�
					CLine* pTmpLine = pLineList->getLast();
					CCharSet cCharSet;
					
					cCharSet.setCode(ASCII_CODE_CR);
					cCharSet.setLinkSubType(LINKTYPE::STANDARD, 0);
					BrINT32		nCharNum = pTmpLine->getCharNum();
					// CR�� �ϳ� �ִ� ��� CR�� size�� ��Ȯ�� setting����...
					if ( nCharNum==0 )	{
						if(pPara->m_pEndParaRunProp)
						{
							nTextID = SearchTextAttAndAddForLockedCanvas(pPara->m_pEndParaRunProp,pRefShapeStyle);
							cCharSet.setAttrID(nTextID);
						}
						else
							cCharSet.setAttrID(0);	//default Size

#ifdef DANDONG_SMARTART
						// Word�������� SmartArt������ Placeholder Text�� ǥ���ϱ�
						// bullet�� �����ǿ��ְ� ���ڷ��� ��� bullet�� ǥ���ϸ鼭 Placeholder Text�� ǥ���ؾ� �Ѵ�.
						if(pPara->m_pTextParagraphStyle && pPara->m_pTextParagraphStyle->m_pBulletInfo && pFrame->GetClass() == DIAGRAMXENTRY) {
							if (pPara->m_pEndParaRunProp) {
								SearchBulletForLockedCanvas(pTmpLine, pPara, pPara->m_pEndParaRunProp, pRefShapeStyle);

								//������ �ؽ�Ʈ �Ӽ��� ã�� ������ �߰� 
								if(pRefShapeStyle )
									nTextID = SearchTextAttAndAddForLockedCanvas(pPara->m_pEndParaRunProp, pRefShapeStyle);
								else {
									BCOfficeXParagraphStyle *pParaStyle = pShapeText->m_pTextParaStyles->m_LevelStyles.at(jj);
									//pParaStyle null ó��
									if( pParaStyle && pTRProp->m_nFontSize <= 0) {
										if( pParaStyle->m_pTextRunProp->m_nFontSize > 0 )
											pTRProp->m_nFontSize = pParaStyle->m_pTextRunProp->m_nFontSize;
										else if( pParaStyle->m_pTextRunProp->m_nKerning > 0 )
											pTRProp->m_nFontSize = pParaStyle->m_pTextRunProp->m_nKerning/100; 
									}

									nTextID = SearchTextAttAndAddForLockedCanvas(pPara->m_pEndParaRunProp, pRefShapeStyle);
								}

								// bullet���� �Ѱ��� �߰��ǿ��ٸ� TAB���ڸ� �Ѱ� �� �߰��ϱ�
								if (pTmpLine->getCharSetArray() != BrNULL && pTmpLine->getCharSetArray()->GetSize() == 1) {
									CCharSet cTab;

									cTab.setCode(ASCII_CODE_TAB);
									cTab.setAttrID(nTextID);
									cTab.setLinkSubType(LINKTYPE::STANDARD, BULLET_CHAR);
									pTmpLine->getCharSetArray()->InsertAt(1, cTab);
								}

								cCharSet.setAttrID(nTextID);
							}

							// [2016.01.25] Word���� SmartArt�ڽĵ������� bullet�� placeholder text���� ������ Ŀ�� ������ ����(ZPD-23994)
							// bullet�� ���� SmartArt����ǥ�ÿ��� ����Ǵ� ���� Paragraph�������� bullet��ȣ�� ���� ù���ڻ��� ���ݰ�꿡 �ʿ���
							// ������ ���������� �ʴ�.
							// ��ü������ ǥ�ؼ����� �ƴ� ��� data.xml�� <a:pPr indent="-283464"/>�� ���� indent������ ������������
							// ǥ�ؼ����� ��� ���� paragraph������ ���������� �ʴ�.
							// �м���� SmartArt������ ǥ�� paragraph indent������ ��üũ�⿡ �����Ѵ�.
							if (pFrame->GetClass() == DIAGRAMXENTRY) {
								PoParaAtt* pParaAtt = const_cast<PoParaAtt*>(theBWordDoc->getParaAttHandler()->getParaAtt(pTmpLine->getParaID()));
								const PoTextAtt *pTextAtt = theBWordDoc->getTextAttHandler()->getTextAtt(nTextID);
								if (pParaAtt != BrNULL) {
									if (pParaAtt->getIndent() == -1) {
										BrFLOAT fFontSize = (BrFLOAT)pTextAtt->getHanFSize();
										if (fFontSize <= 220) 
											pParaAtt->setIndent(-1440 * 0.06);
										else if (fFontSize < 320)
											pParaAtt->setIndent(-1440 * 0.13);
										else if (fFontSize < 400)
											pParaAtt->setIndent(-1440 * 0.19);
										else if (fFontSize < 560)
											pParaAtt->setIndent(-1440 * 0.25);
										else
											pParaAtt->setIndent(-1440 * 0.31);
									}
								}
							}
						}
#endif // DANDONG_SMARTART
					}
					else	{
						cCharSet.setAttrID(nTextID);
					}

					CCharSetArray* pCharSetArray = pTmpLine->getCharSetArray();
					if(pCharSetArray)
						pCharSetArray->Add(cCharSet);
				}
			}
		}

		if(pShapeText && pShapeText->m_pTextBodyProperty)	
		{
			if((pShapeText->m_pTextBodyProperty->m_bAnchorCenter == -1) && (pFrame->GetClass() != DIAGRAMXENTRY)) {
				pFrame->setArrangePos(MIDDLE_ARRANGE);
			}
			else {	
				switch(pShapeText->m_pTextBodyProperty->m_nAnchor)
				{
				case OfficeXTextAnchorCenter:
					pFrame->setArrangePos(MIDDLE_ARRANGE);
					break;

				case OfficeXTextAnchorBottom:
					pFrame->setArrangePos(BOTTOM_ARRANGE);
					break;

				case OfficeXTextAnchorTop:
				case OfficeXTextAnchorNotSet:
				case OfficeXTextAnchorNone:
				case OfficeXTextAnchorDist:
				case OfficeXTextAnchorJust:
				default:
					pFrame->setArrangePos(TOP_ARRANGE);
					break;
				}
#ifdef DANDONG_SMARTART
				// [2014.04.26][Dandong3] txBody->bodyPr�� anchorCtr="1"�϶� Text centering ó���κ�
				if(pShapeText->m_pTextBodyProperty->m_bAnchorCenter == 1)
				{
					pFrame->setArrangeVericalCenterPos(BrTRUE);
				}
#endif // DANDONG_SMARTART
			}

			BRect RcInMargin;
			RcInMargin.nLeft = pShapeText->m_pTextBodyProperty->m_nLeftInset;				
			RcInMargin.nTop = pShapeText->m_pTextBodyProperty->m_nTopInset;
			RcInMargin.nRight = pShapeText->m_pTextBodyProperty->m_nRightInset;
			RcInMargin.nBottom = pShapeText->m_pTextBodyProperty->m_nBottomInset;

			convertRatioInMarginLockedCanvas(ExtRect, GRect, RcInMargin);
			pFrame->setBorderMargin(&RcInMargin);							
		}
		else
		{//default
			pFrame->setArrangePos(TOP_ARRANGE);

			BRect rcMagin;
			rcMagin.nLeft = rcMagin.nRight = (BrLONG)MMtoTWIP_DOUBLE(2.5);
			rcMagin.nTop = rcMagin.nBottom = (BrLONG)(0.025 * 1440); 
			convertRatioInMarginLockedCanvas(ExtRect, GRect, rcMagin);
			pFrame->setBorderMargin(&rcMagin);
		}
	}
}


BrSHORT CDocxConv::SearchParaAttAndAddForLockedCanvas(BCOfficeXTextParagraph* pPara)
{	
	PoParaAtt pParaData;
	convertParaAttForLockedCanvas(&pParaData,pPara);

	return theBWordDoc->getParaAttHandler()->insertParaAtt(pParaData);
}

void CDocxConv::convertParaAttForLockedCanvas(PoParaAtt *pParaData, BCOfficeXTextParagraph *pPara)//MistY - 2009.06.27- para ����
{
	if(!pPara || !pPara->m_pTextParagraphStyle)	return;

//set alignment
	BYTE nTmp = 0;
	pParaData->setFrontParaSpace(0);
	pParaData->setBackParaSpace(0);
	if(pPara->m_pTextParagraphStyle->m_nTextAlign == OfficeXTACenter)		//��� ����
		nTmp = CENTER;
	else if(pPara->m_pTextParagraphStyle->m_nTextAlign == OfficeXTARight)	//������ ����
		nTmp = RIGHT;
	else if(pPara->m_pTextParagraphStyle->m_nTextAlign == OfficeXTADist)	//�յ����
		nTmp = DISTRIBUTE;
	else if(pPara->m_pTextParagraphStyle->m_nTextAlign == OfficeXTALeft)	//���� ����
		nTmp = LEFT;
	else if(pPara->m_pTextParagraphStyle->m_nTextAlign == OfficeXTAJust)	//���� ����
		nTmp = JUSTIFY;
	else if(pPara->m_pTextParagraphStyle->m_nTextAlign == OfficeXTANotSet)	//default
		nTmp = LEFT;
	else
		nTmp = CENTER;

	// ms word�� ������ ���� �ܾ� ��ȣ�����
	pParaData->setProtectEngWord(BrTRUE);

	// AlignOption : HIGH 4 BITs (0xF0)
	// �ܾ� �߸� ���� : PROTECT_HANWORD(0x80), PROTECT_ENGWORD(0x40)
#ifdef DANDONG_SMARTART_EDIT
	// [2016.03.02] SmartArt�������� LatinLnBreak�Ӽ��� ������ ��üũ��������� ����(ZPD-26298)
	// LatinLnBreak�� �������� ���� ��� slide������ ���� �ܾ��߸��� ������� �ʵ��� �Ѵ�.
	if (1 != ( pPara->m_pTextParagraphStyle->m_byEastAsianLineBreak == 1 || !(pPara->m_pTextParagraphStyle->m_byLatinLineBreak == 0)))//if (1 == pPap->m_nWordWrap ) // �ѱ� �ܾ� �߸� ��� ����
#else // DANDONG_SMARTART_EDIT
	if (1 == ( pPara->m_pTextParagraphStyle->m_byEastAsianLineBreak == 1|| !(pPara->m_pTextParagraphStyle->m_byLatinLineBreak == 0)))//if (1 == pPap->m_nWordWrap ) // �ѱ� �ܾ� �߸� ��� ����
#endif // DANDONG_SMARTART_EDIT
		pParaData->setProtectHanWord(BrTRUE);

	// set alignment
	pParaData->setAlign(nTmp);	

	switch(pPara->m_pTextParagraphStyle->m_nFontAlign)
	{
	case OfficeXFABottom:	//VA_BOTTOM
		pParaData->setVerAlign(BR_TEXT_VALIGN_BOTTOM);
		break;

	case OfficeXFAAuto:
	case OfficeXFABase:		//VA_BASELINE
	case OfficeXFANotSet:
		pParaData->setVerAlign(BR_TEXT_VALIGN_BASELINE);
		break;

	case OfficeXFACenter:	//VA_CENTER
		pParaData->setVerAlign(BR_TEXT_VALIGN_MIDDLE);
		break;

	case OfficeXFATop:		//VA_TOP
		pParaData->setVerAlign(BR_TEXT_VALIGN_TOP);
		break;	
	}

	BrINT32 nLeftMargin, nRightMargin, nFirstLine;
	nFirstLine = pPara->m_pTextParagraphStyle->m_nIndent;
	nLeftMargin = pPara->m_pTextParagraphStyle->m_nLeftMargin;
	nRightMargin = pPara->m_pTextParagraphStyle->m_nRightMargin;
	
	pParaData->setIndent(nFirstLine);
	if( pPara->m_pTextParagraphStyle->m_nRtl == 1) {
		pParaData->setRightMargin(nLeftMargin);
		pParaData->setLeftMargin(nRightMargin);
	}
	else {
#ifndef DANDONG_SMARTART
 		pParaData->setRightMargin(nRightMargin);
 		pParaData->setLeftMargin(nLeftMargin);
#else // DANDONG_SMARTART
		// [2014.04.18][Dandong3] SmartArt���� bullet���� text���� before, hanging�� ó��
		if(nFirstLine < 0)
			nLeftMargin += nFirstLine;

		if(nLeftMargin < 0)
			nLeftMargin = 0;

		pParaData->setLeftMargin(nLeftMargin);
		pParaData->setIndent(nFirstLine);
#endif // DANDONG_SMARTART
	}
}

BrSHORT CDocxConv::SearchTextAttAndAddForLockedCanvas(BCOfficeXTextRunProp* pTRProp,BCOfficeXShapeStyleRef* pRef)
{
	PoTextAtt *pTextData = BrNEW PoTextAtt();
	if(!pTextData)
		return 0;

	convertTextAttForLockedCanvas(pTextData, pTRProp, pRef);

	BrSHORT wID =theBWordDoc->getTextAttHandler()->insertTextAtt(*pTextData);

	BR_SAFE_DELETE(pTextData);
	return 	wID;	
}

void CDocxConv::convertTextAttForLockedCanvas(PoTextAtt *pTextData, BCOfficeXTextRunProp *pTRProp, BCOfficeXShapeStyleRef* pRef) 
{
	if( !pTRProp || !pTextData) return;

	if(pTRProp->m_nFontSize == -1 || 0 == pTRProp->m_nFontSize)	//pptx�� default font size is 18
	{
		pTextData->setHanFSize( 16 / m_fLockedCanvasRatio * 20);
		pTextData->setEngFSize( 16 / m_fLockedCanvasRatio * 20);		
	}
	else
	{
		pTextData->setHanFSize( pTRProp->m_nFontSize / m_fLockedCanvasRatio * 20);
		pTextData->setEngFSize( pTRProp->m_nFontSize / m_fLockedCanvasRatio * 20);		
	}
#ifdef DANDONG_SMARTART
	//[2014.05.09][Dandong3] SmartArt�� Text�� Font����
	if(pTRProp->m_pFontInfo)
	{
		// �켱 ������ü�̸��� �ִٸ� �츮�ۼ�ü������ ������ü������ �Ȱ��� �����Ѵ�.
		if( !pTRProp->m_pFontInfo->GetFontName().isEmpty() ) {
			BrWORD face[BR_LF_FACESIZE] = {1,};
			CUtil::BStringToWord_S(pTRProp->m_pFontInfo->GetFontName(), face, BR_LF_FACESIZE);

			pTextData->setEngFontID( (BrWORD)theBWordDoc->getFontArray()->getFontID(face));
		}

		// [DanDong2] [2014.09.26] ���� �����ۼ�ü�̸��� �ִٸ� �쿡�� ������ �츮�ۼ�ü�������� �����Ѵ�.
		if( !pTRProp->m_pFontInfo->GetEAFontName().isEmpty() ) {
			BrWORD face[BR_LF_FACESIZE];
			CUtil::BStringToWord_S(pTRProp->m_pFontInfo->GetEAFontName(), face, BR_LF_FACESIZE);

			pTextData->setHanFontID( (BrWORD)theBWordDoc->getFontArray()->getFontID(face));
		}
	}
	else
	{
		pTextData->setEngFontID( (BrWORD)theBWordDoc->getFontArray()->getFontID("Times New Roman"));
	}
#endif

	BrWORD wAttr = 0; 
	// font attribute, main => bitfield union !
	if (-1 != pTRProp->m_bBold )		pTextData->setBold(pTRProp->m_bBold);
	if (-1 != pTRProp->m_bItalic)		pTextData->setItalic(pTRProp->m_bItalic);
	if (OfficeXStrikeNotSet != pTRProp->m_nStrike )		pTextData->setStrikeout(BrTRUE);
	if (OfficeXUnderlineNotSet != pTRProp->m_nUnderline)		pTextData->setUnderline(BrTRUE);
	if (-1 != pTRProp->m_nBaseline)
	{
		if (pTRProp->m_nBaseline > 0 )		pTextData->setSuperscript(BrTRUE);
		else if (pTRProp->m_nBaseline < 0 )		pTextData->setSubscript(BrTRUE);
	}

	//[2013.07.19][�����][TID:16275] pptx���� ���� �������� parsing �� ���� ��ȯ �ڵ� ����
	if(pTRProp->m_nCharSpace != -1)
		pTextData->setCharSp((CDocxUtil::PTtoTWIPDocx((BrWORD)(pTRProp->m_nCharSpace / 100)))/2);	//jjoo:2008-06-12:�Ŀ�����Ʈ�� ���� ������ ���庸�� ���Ƽ� /2 �� ����.

	pTextData->setVOffset( 0 );                    // BrCHARacter's vertical offset : from base line (optional)
	pTextData->setBackColor( RGB_WHITE );
	pTextData->setBackFlag( BrFALSE );      // flag for background color (ON/OFF)
	

	// text color 
	BoraOfficexColorMap		aUsedMap[COLOR_SCHEME_DEPTH];
	memcpy(&aUsedMap, &m_pDocxLoader->m_pSettings->m_aMap, BrSizeOf(BoraOfficexColorMap)*COLOR_SCHEME_DEPTH);
	BrDWORD nColor = 0;
	
	BrBYTE	red=0, green=0, blue=0;	
	//[M40262] theme ���°�� �߻�
	BCOfficeXColorSchemeAtom* pSchemeColor = BrNULL;
	if(m_pDocxLoader->m_pTheme)
		pSchemeColor = m_pDocxLoader->m_pTheme->GetSchemeColor();
	if(pTRProp->m_pFillStyles)
		pTRProp->m_pFillStyles->GetColor(red, green, blue, pSchemeColor, aUsedMap);	
	else if(pRef && pRef->m_pStyleColor)	//MistY - 2009.08.10
		pRef->m_pStyleColor->GetColor(red, green, blue, pSchemeColor, aUsedMap);	
	
	nColor = (((BrUINT32)((UINT8)(red))))|(((BrUINT32)((UINT8)(green)))<<8)|(((BrUINT32)((UINT8)(blue)))<<16);
	pTextData->setTextColor(nColor);
	pTextData->setAutoColor(BrFALSE);
}

void CDocxConv::convertRatioFontSizeLockedCanvas(BRect ExtRect, BRect GRect, BCOfficeXTextRunProp* pTRProp)
{
	if(ExtRect.IsEmpty() || GRect.IsEmpty() || pTRProp == BrNULL)	
		return;

	//�������ϱ� 
	BrDOUBLE nWidth = GRect.GetWidth();
	BrDOUBLE nWidthA = ExtRect.GetWidth();
	BrDOUBLE nRatioWidth = nWidth / nWidthA;

	BrDOUBLE nHeight = GRect.GetHeight();
	BrDOUBLE nHeightA = ExtRect.GetHeight();
	BrDOUBLE nRatioHeight = nHeight / nHeightA;

	//������ �°� ��Ʈ ũ�� ����
	if( nRatioWidth != 1) //1:1�� ���� 
	{
		//[2013.07.19][�����][TID:16275] pptx���� ���� �������� parsing �� ���� ��ȯ �ڵ� ����
		if(pTRProp->m_nCharSpace == 0)
			pTRProp->m_nCharSpace = 1;

		//��Ʈ ���� ����
		if(nWidth < nWidthA)
			pTRProp->m_nCharSpace = (BrUINT32)((pTRProp->m_nCharSpace / 100) * nRatioWidth);
		else if(nWidth > nWidthA)
			pTRProp->m_nCharSpace = (BrUINT32)((pTRProp->m_nCharSpace / 100) / nRatioWidth);
	}

	BrINT32 nFontSize = 0;
	if( nRatioHeight != 1 ) //1:1�� ���� 
	{
		if(pTRProp->m_nFontSize == -1)
			nFontSize = 18;

		//��Ʈ ������ ����
		if(nHeight < nHeightA)
			nFontSize = (BrINT32)(pTRProp->m_nFontSize * nRatioHeight);
		else if(nHeight > nHeightA)
			nFontSize = (BrINT32)(pTRProp->m_nFontSize / nRatioHeight);
	}
	if( nFontSize )
		pTRProp->m_nFontSize = nFontSize;
}

void CDocxConv::convertRatioInMarginLockedCanvas(BRect ExtRect, BRect GRect, BRect& InMargin)
{
	if(ExtRect.IsEmpty() || GRect.IsEmpty())	
		return;

	//�������ϱ� 
	BrDOUBLE nWidth = GRect.GetWidth();
	BrDOUBLE nWidthA = ExtRect.GetWidth();
	BrDOUBLE nRatioWidth = nWidth / nWidthA;

	BrDOUBLE nHeight = GRect.GetHeight();
	BrDOUBLE nHeightA = ExtRect.GetHeight();
	BrDOUBLE nRatioHeight = nHeight / nHeightA;

	//������ �°� ���� ���� ũ�� ����
	if( nRatioWidth != 1) //1:1�� ���� 
	{
		//Left, Right ����
		if(nWidth < nWidthA)
		{
			InMargin.nLeft = (BrUINT32)(InMargin.nLeft * nRatioWidth);
			InMargin.nRight = (BrUINT32)(InMargin.nRight * nRatioWidth);
		}
		else if(nWidth > nWidthA)
		{
			InMargin.nLeft = (BrUINT32)(InMargin.nLeft / nRatioWidth);
			InMargin.nRight = (BrUINT32)(InMargin.nRight / nRatioWidth);
		}
	}
	if( nRatioHeight != 1 ) //1:1�� ���� 
	{
		//Top, Bottom ����
		if(nHeight < nHeightA)
		{
			InMargin.nTop = (BrINT32)(InMargin.nTop * nRatioHeight);
			InMargin.nBottom = (BrINT32)(InMargin.nBottom * nRatioHeight);
		}
		else if(nHeight > nHeightA)
		{
			InMargin.nTop = (BrINT32)(InMargin.nTop / nRatioHeight);
			InMargin.nBottom = (BrINT32)(InMargin.nBottom / nRatioHeight);
		}
	}
}

void CDocxConv::setResizeWidthForTextFramePr(CDocxParaAtt* pDocxParaAtt)
{
	if( m_pFrameForTextFramePr)	//jjoo:2009-07-30:frame's rect���� ���� �ؽ�Ʈ�� Ŭ���� �����Ƿ� �׻� ������.
	{
		BrINT32 nWidth = 0, nHeight = 0;
		CLineList* pLineList = (CLineList*)m_pFrameForTextFramePr->getSubFrame();
		CCharSetArray* pCharSetArray = NULL;
		CCharSet* pCharSet	= NULL;
		PoTextAtt cTmpTextAtt;
		if(pLineList)
		{
			CLine* pLine = (CLine*)pLineList->getLast();
			if(pLine)
			{
				pCharSetArray = (CCharSetArray*)pLine->getCharSetArray();
				if( pCharSetArray )
				{
					BrINT32 nSize = pCharSetArray->GetSize();
					BrINT32 nMaxHeight = 0;
					for(BrINT32 i = 0; i < nSize; i++)
					{
						pCharSet = (CCharSet*)pCharSetArray->getCharSet(i);
						if(pCharSet)
						{
							theBWordDoc->getTextAttHandler()->getTextAtt(cTmpTextAtt, pCharSet->getAttrID());						
							if(pCharSet->getCode() > 0x00FF && pCharSet->getCode() < 0xF000)	//������ ���� 2byte�ڵ�(�ѱ�).
							{
								nWidth += cTmpTextAtt.getHanFSize();
								if(nMaxHeight < cTmpTextAtt.getHanFSize())
									nMaxHeight = cTmpTextAtt.getHanFSize();
							}
							else if(pCharSet->getLinkType() == LINKTYPE::ANCHOR)
							{
								CFrame* pFrame = BrNULL;
								if(m_bHeaderFooter)
									pFrame = theBWordDoc->getAFrameList4HeaderFooter()->getFrame(pCharSet->getCode());
								else
									pFrame = (CFrame*)theBWordDoc->getAFrameList()->getFrame(pCharSet->getCode());
	
								if(pFrame && pFrame->isAnchored())
								{
									nWidth += pFrame->width();
									if(nMaxHeight < pFrame->height())
										nMaxHeight = pFrame->height();
								}
							}
							else{
								nWidth += cTmpTextAtt.getHanFSize()/2;
								if(nMaxHeight < cTmpTextAtt.getHanFSize())
									nMaxHeight = cTmpTextAtt.getHanFSize();
							}
						}
					}
					if(nHeight < nMaxHeight)	
						nHeight = nMaxHeight;
				}
			}
		}

		BRect rect = m_pFrameForTextFramePr->getFrameRect();
		BrINT32 nPageWidth = m_pCurPage->width();
		BrINT32 x = m_pFrameForTextFramePr->getOrgDx();

		if(pDocxParaAtt && pDocxParaAtt->m_pFramePr)
		{
			if((pDocxParaAtt->m_pFramePr->m_nWidth == 0) && (rect.nRight < nWidth) )
			{
				if(nWidth > nPageWidth)
					nWidth = nPageWidth - x;

				rect.nRight = nWidth;
			}


			if((pDocxParaAtt->m_pFramePr->m_nHeight == 0) && (rect.nBottom < nHeight) )
				rect.nBottom = nHeight;
		}

		m_pFrameForTextFramePr->setFrameRect(rect);
	}
}

void CDocxConv::InitVarForPara(CDocxPara* pDocxPara)
{
	if(!pDocxPara)	
		return;

	m_bOnlyEngPara = BrTRUE;
	m_nCurBigCharSize = 0;
	m_wAttrIDForCurBigChar = 0xFFFF;

	if( pDocxPara->m_pDocxParaAtt && pDocxPara->m_pDocxParaAtt->m_bChangeLineList)
	{
		m_pCurLineList = m_pOldCurLineList;
		m_nCurParaHgt = m_nOldCurParaHgt;
	}
}

#ifndef SUPPORT_GRAPHIC_STYLE
//// DMLBodyPrConverter���� �̵�.
BrBOOL CDocxConv::ConvertShapeBodyPr(CFrame* a_pFrame, BCOfficeXTextBodyProp* a_pBodyPr)
{
	if(!ConvertShapeTextAlign(a_pFrame, a_pBodyPr->m_nAnchor, a_pBodyPr->m_bAnchorCenter))
		return BrFALSE;

	if(!ConvertShapeTextMargin(a_pFrame, a_pBodyPr))
		return BrFALSE;

	if(!ConvertShapeTextVertType(a_pFrame, a_pBodyPr->m_nTextVertType))
		return BrFALSE;

	if(!ConvertShapeTextResize(a_pFrame, a_pBodyPr))
		return BrFALSE;

	if(a_pBodyPr->m_nPresetShapeWarp >= OfficeXTextShapeTypePlain && a_pBodyPr->m_nPresetShapeWarp <= OfficeXTextShapeTypeCanDown)
	{
		if(!ConvertDMLTextWarpType(a_pBodyPr, a_pFrame))
			return BrFALSE;
	}

	if(a_pBodyPr->m_bUpRight)
		a_pFrame->setDoNotRotateText(BrTRUE);

	if(a_pBodyPr->m_pAdjust)
	{
		for(BrUINT32 i = 0; i < a_pBodyPr->m_pAdjust->size(); i++)
			CDocxUtil::setShapeGeometry(a_pBodyPr->m_pAdjust->at(i), i, a_pFrame->getBorder());
	}

	return BrTRUE;
}

BrBOOL CDocxConv::ConvertDMLTextWarpType(BCOfficeXTextBodyProp* a_pBodyPr, CFrame* a_pFrame)
{	
	if(!a_pBodyPr)
		return BrFALSE;

	CShapeWordartInfo* pWordArtInfo = a_pFrame->getBorder()->getWordartInfo();
	if(!pWordArtInfo)
		pWordArtInfo = BrNEW CShapeWordartInfo();

	CLineList* pLineList = ((CLineList*)a_pFrame->getSubFrame());
	if(!pLineList)
		return BrFALSE;

	CLine* pLine = pLineList->getLast();
	if(!pLine)
		return BrFALSE;

	BrINT32 nTextAttID = pLine->getCharSetArray()->at(0).getAttrID();

	PoTextAtt* pTextAtt = theBWordDoc->getTextAttHandler()->getAttr(nTextAttID);

	pWordArtInfo->m_nShape = a_pBodyPr->m_nPresetShapeWarp;
	pWordArtInfo->m_strFaceName = ftLibrary::GetFontName(pTextAtt->getEngFontID());
	pWordArtInfo->m_strKorFaceName = ftLibrary::GetFontName(pTextAtt->getHanFontID());
	pWordArtInfo->m_nHeight = pTextAtt->getFSize();
	pWordArtInfo->m_bUnderline = pTextAtt->getUnderline();
	pWordArtInfo->m_bBold = pTextAtt->getBold();
	pWordArtInfo->m_bItalic = pTextAtt->getItalic();
	pWordArtInfo->m_bStrikeout = pTextAtt->getStrikeout();

 	BrINT32 nStrLen  = pLine->getCharSetArray()->size();

	for(BrINT32 i = 0 ; i < nStrLen ; i++)
	{
		BChar tmp(pLine->getCharSetArray()->at(i).getCode());
		pWordArtInfo->m_strText.append(tmp);
	}

	a_pFrame->getBorder()->setWordartInfo(pWordArtInfo);

	return BrTRUE;
}

//[2013.05.21][������][TID:15441] TextBoxResize ���� (������ �ش� Ƽ�� ���� Ȯ�� ��Ź�帳�ϴ�)
BrBOOL	CDocxConv::ConvertShapeTextResize(CFrame* a_pFrame, BCOfficeXTextBodyProp* a_pBodyPr)
{
	if(!a_pBodyPr)
		return BrFALSE;

	BrBOOL	bWrapTextInShape = BrFALSE;	//������ �ؽ�Ʈ ��ġ
	if(a_pBodyPr->m_eWrap == eASTTextWrappingType_square || a_pBodyPr->m_eWrap == eASTTextWrappingType_NoSet)
		bWrapTextInShape = BrTRUE;
	
	BrBOOL	bReSizeShapeFitToText = BrFALSE;	//������ �ؽ�Ʈ ũ�⿡ ����
	if(a_pBodyPr->m_nAutoFit == 2)
		bReSizeShapeFitToText = BrTRUE;

	if(!bWrapTextInShape)
		a_pFrame->setAutoWidthFlag(BrTRUE);
	if(bReSizeShapeFitToText)
	{
		a_pFrame->setOnceStretchFlag(BrTRUE);
		a_pFrame->setAutoResizeFlag(BrTRUE);
	}
	return BrTRUE;
}

//AnchorCentert�� PPTX�� �����Ͽ� ó������.(���� ���� �߻��� ó�� ���ؼ� �Ű������� �޸� ����)
BrBOOL	CDocxConv::ConvertShapeTextAlign(CFrame* a_pFrame, BoraOfficeXTextAnchorType a_nAnchor, BrINT8 m_bAnchorCenter)
{
	switch(a_nAnchor)
	{
	case OfficeXTextAnchorCenter:
		a_pFrame->setArrangePos(MIDDLE_ARRANGE);
		break;
	case OfficeXTextAnchorBottom:
		a_pFrame->setArrangePos(BOTTOM_ARRANGE);
		break;
	case OfficeXTextAnchorTop:
		a_pFrame->setArrangePos(TOP_ARRANGE);
		break;
	default://���� default Center(5.1.5.1.1 bodyPr (Body Properties))
		a_pFrame->setArrangePos(MIDDLE_ARRANGE);
		break;
	}

	return BrTRUE;
}

//���� �ڵ� �Լ��θ� ����.
BrBOOL	CDocxConv::ConvertShapeTextMargin(CFrame* a_pFrame, BCOfficeXTextBodyProp* a_pBodyPr)
{
	//border margin setting
	BRect*	rcBorderMargin = a_pFrame->getBorderMargin();
	BrINT32 nLeftRightMargin = 0, nTopBottomMargin = 0;
	nLeftRightMargin = (BrINT32)EMUtoTWIP_DOUBLE(91440);//���� default (5.1.5.1.1 bodyPr (Body Properties))
	nTopBottomMargin = (BrINT32)EMUtoTWIP_DOUBLE(45720);

	//left margin
	if(a_pBodyPr->m_nLeftInset)
		rcBorderMargin->nLeft = a_pBodyPr->m_nLeftInset;
	else
		rcBorderMargin->nLeft = nLeftRightMargin;

	//top
	if(a_pBodyPr->m_nTopInset)
		rcBorderMargin->nTop = a_pBodyPr->m_nTopInset;
	else
		rcBorderMargin->nTop = nTopBottomMargin;

	//right
	if(a_pBodyPr->m_nRightInset)
		rcBorderMargin->nRight = a_pBodyPr->m_nRightInset;
	else
		rcBorderMargin->nRight = nLeftRightMargin;

	//bottom
	if(a_pBodyPr->m_nBottomInset)
		rcBorderMargin->nBottom = a_pBodyPr->m_nBottomInset;
	else
		rcBorderMargin->nBottom = nTopBottomMargin;

	return BrTRUE;
}
//���� �ڵ� �Լ��θ� ����.
BrBOOL	CDocxConv::ConvertShapeTextVertType(CFrame* a_pFrame, BoraOfficeXTextVerticalType a_nTextVertType)
{
	if( a_nTextVertType != OfficeXTextVerticalTypeNotSet && a_nTextVertType != OfficeXTextVerticalTypeNone)
		a_nTextVertType == OfficeXTextVerticalTypeHorz ?  a_pFrame->setDirection(GARO) : a_pFrame->setDirection(SERO);

	switch(a_nTextVertType)
	{
	case textVerticalTypeVert:		a_pFrame->setTextFlow(TEXTFLOW_SERO_90);	break;
	case textVerticalTypeVert270:	a_pFrame->setTextFlow(TEXTFLOW_SERO_270);	break;
	case textVerticalTypeEa:		a_pFrame->setTextFlow(TEXTFLOW_SERO);		break;
	case textVerticalTypeMongolian:	a_pFrame->setTextFlow(TEXTFLOW_SERO);		break;
	case textVerticalTypeWordArt:	a_pFrame->setTextFlow(TEXTFLOW_SERO_LTR);	break;
	case textVerticalTypeWordArtRtl:a_pFrame->setTextFlow(TEXTFLOW_SERO_RTL);	break;
	case textVerticalTypeHorz:		a_pFrame->setTextFlow(TEXTFLOW_GARO);		break;
	case textVerticalTypeNotSet:
	case textVerticalTypeNone:
	default:
		{
			BYTE bTextVertical = (a_pFrame->getDirection() == GARO) ? TEXTFLOW_GARO : TEXTFLOW_SERO;
			a_pFrame->setTextFlow(bTextVertical);
		}
		break;
	}	

	return BrTRUE;
}

#endif //SUPPORT_GRAPHIC_STYLE

BrINT32 CDocxConv::getPageNum()
{ 
	if( m_pCurPage ) 
		return m_pCurPage->getPageNum(); 
	else 
		return 1;
}

BrBOOL CDocxConv::CheckThemeSchemeColor(BCOfficeXColorSchemeAtom* a_pSource)
{
	if(!a_pSource)
		return BrFALSE;

	BrBOOL bResult = BrTRUE;

	for(BrINT32 nIndex = 0; nIndex < a_pSource->m_SchemeColors.size(); nIndex++)
	{
		if(a_pSource->m_SchemeColors[nIndex] == BrNULL)
		{
			bResult = BrFALSE;
			break;
		}
	}

	return bResult;
}

BrBOOL CDocxConv::FileValidate()
{
	BrBOOL bResult = BrTRUE;
	//theme color check
	if(getDocxLoader()->m_pTheme && getDocxLoader()->m_pTheme->GetSchemeColor())
	{
		bResult = CheckThemeSchemeColor(getDocxLoader()->m_pTheme->GetSchemeColor());
	}
	return bResult;	
}

BrBOOL CDocxConv::convertCommentRangeStart(BrINT32 a_nCommentID, CLineList * a_pLineList /*=BrNULL*/)
{
	if((m_nDoingType & DOC_ENDNOTE) || (m_nDoingType & DOC_FOOTNOTE))
		return BrTRUE;
	/* 1. comments.xml ���� �ش� ID�� ���� �ش� �޸� ������ */
	CDocxComment * pDocxComment = BrNULL;
	CDocxComments * pDocxComments = m_pDocxLoader->getDocxComments();
	if ( pDocxComments == BrNULL ){
		BRTHREAD_ASSERT(0);
		return BrFALSE;
	}
	pDocxComment = pDocxComments->getComment(a_nCommentID);
	if ( pDocxComment == BrNULL ){
		BRTHREAD_ASSERT(0);
		return BrFALSE;
	}
	/* 2. ���� �Ÿ��� StartLink�� ������ �޷Ⱦ��ٸ�, ���� ���� */
	if ( pDocxComment->isMemoLinkStartAdded() == BrTRUE )
		return BrFALSE;


	/* 3. ���� LineList�� ������ ���� ��ų� ���� */
	CLineList * pLineList = BrNULL;
	if ( a_pLineList ){
		pLineList = a_pLineList;
	}
	else{
		/* 3.1 ���̺��� ��쿡�� CurLineList�� �̿� */
		if ( m_bTextInTable ){
			if ( m_pCurLineList )
				pLineList = m_pCurLineList;
			else
				pLineList = (CLineList *) m_pCurFrame->getSubFrame();
		}
		/* 3.2 ���̺��� �ƴ� ���� �����ӿ��� LineList�� ������ �� */
		else{
			pLineList = (CLineList *) m_pCurFrame->getSubFrame();
		}
	}
	/* 3.3 LineList�� �������� �õ��� �Ͽ�����, �������Ƿ� ���� ���� */
	if ( pLineList == BrNULL )
		pLineList = ftLibrary::CreateLineList(m_pCurFrame);

	if ( pLineList != BrNULL )
	{
		CLine * pLastLine = pLineList->getLast();

		if ( pLastLine == BrNULL )
			pLastLine = ftLibrary::CreateLine(pLineList);

		/* 4. �ش� Comment�� Memo�� ��� ������ �߰��� */
		CMemo * pMemo = pDocxComment->getMemoByMemoID();
		theBWordDoc->getMemoArray()->addMemo(pMemo, BrFALSE );

		CFrame * pMemoFrame = pDocxComment->getMemoFrame();
		/* 5. ȸ�� �޸� ó�� */
		if ( m_pDocxLoader->GetCommentsEx() )
		{
			CommentsEx * pCommentsEx =  m_pDocxLoader->GetCommentsEx();
			BrINT32 nCommentParaIdParent = 0;
			nCommentParaIdParent = pCommentsEx->GetParaIdParent(pDocxComment->getCommentLastParaID() );

			/* ���� ParaIdParent�� �����Ѵٸ�, �ش� �޸�� Parent�� ���� ȸ�� �޸���. */
			if(nCommentParaIdParent != 0){
				CDocxComment * pParentComment = pDocxComments->getCommentByCommentParaId(nCommentParaIdParent);
				if(pParentComment)
				{
					CMemo * pParentMemo = pParentComment->getMemoByMemoID();
					pMemo->setMemoParentID( pParentMemo->getMemoID() );
					pMemoFrame->setParentMemoID( pMemo->getMemoParentID() );
				}
			}
		}

		/* 6. Memo CharSet ���� �ʱ�ȭ */
		CCharSet memoCharSet;
		memoCharSet.setAttrID(0);
		memoCharSet.setCode( pMemo->getMemoID() );
		BrINT32 nSubType = MEMO_TYPE_START | SPLITABLE | EDITABLE;
		memoCharSet.setLinkSubType( LINKTYPE::MEMO, nSubType );

		/* 7. Memo CharSet�� ���ο� �߰� */
		CCharSetArray *pCharSetArray = pLastLine->getCharSetArray();
		/* 7.1 ������ �ɸ��ͼ��� CR�� ��� �� �տ�, �ƴ� ��� �� �ڿ� �޾��� */
		/* 7.2 CharSetArray�� ũ�⸦ ���� */
		BrINT32 nCharSetSize = pCharSetArray->size();

		/* 7.3 ���� CharSetArray�� ���� ������ ���� */
		if ( nCharSetSize > 0){
			// ������ CharSet�� CR���� �˻� �ʿ�
			CCharSet pLastCharSet = pCharSetArray->at(nCharSetSize-1);
			/* 7.3.1 ������ CharSet�� CR�̾ CR ������ �޸�ũ �ޱ� */
			if ( pLastCharSet.getCode() == 0xa && pLastCharSet.getLinkType() == LINKTYPE::STANDARD )
				pCharSetArray->InsertAt(nCharSetSize-1, memoCharSet);
			else /* 7.3.2. ������ CharSet�� CR�� �ƴ�. �׳� �߰� */
				pCharSetArray->Add(memoCharSet);
		}
		else{
			/* CharSetArray�� �ƹ��� �����Ͱ� �����Ƿ� �޸�ũ�� �ܼ� �߰� */
			pCharSetArray->Add(memoCharSet);
		}

		BrINT32 nSize = pCharSetArray->size();

		/* 8. MemoFrame �� Anchor Line ���� */
		pMemoFrame->setAnchorLine(pLastLine);
		pMemoFrame->setAnchorCol(nSize - 1);
		pMemoFrame->updatePage( m_pCurPage);
		pMemoFrame->setMemoID( pMemo->getMemoID() );

		CFrameList * memoFrameList = pMemo->GetFrameListBelowOfGroupFrame(theBWordDoc, m_pCurPage );
		pMemoFrame->setGroupParent(memoFrameList->getParentFrame());
		memoFrameList->insertAtTail(pDocxComment->getMemoFrame() );
		pMemoFrame->setMemoeFrameXPosition(theBWordDoc);

		/* 9. ���� �޸��� StratLink�� ������ ���������� ���� */
		pDocxComment->setMemoLinkStartAdded();
	}
	else
	{
		BRTHREAD_ASSERT(0); // LineList�� �������� ����
	}

	return BrTRUE;
}

BrBOOL CDocxConv::convertCommentRangeEnd(BrINT32 a_nCommentID, CLineList * a_pLineList/*=BrNULL*/)
{
	if((m_nDoingType & DOC_ENDNOTE) || (m_nDoingType & DOC_FOOTNOTE))
		return BrTRUE;
	/* 1. comments.xml ���� �ش� ID�� ���� �ش� �޸� ������ */
	CDocxComment * pDocxComment = BrNULL;
	CDocxComments * pDocxComments = m_pDocxLoader->getDocxComments();
	if ( pDocxComments == BrNULL ){
		BRTHREAD_ASSERT(0);
		return BrFALSE;
	}
	pDocxComment = pDocxComments->getComment(a_nCommentID);
	if ( pDocxComment == BrNULL ){
		BRTHREAD_ASSERT(0);
		return BrFALSE;
	}

	/* 2. MemoStartLink�� �����ߴ� Comments ���� �˻� */
	if ( pDocxComment->isMemoLinkStartAdded() != BrTRUE )	//start link ���� end�� �ִ� ���
	{
		convertCommentRangeStart(a_nCommentID);
	}

	/* 3. ���� LineList�� ������ ���� ��ų� ���� */
	CLineList * pLineList = BrNULL;
	if ( a_pLineList ){
		pLineList = a_pLineList;
	}
	else{
		/* 3.1 ���̺��� ��쿡�� CurLineList�� �̿� */
		if ( m_bTextInTable ){
			if ( m_pCurLineList )
				pLineList = m_pCurLineList;
			else
				pLineList = (CLineList *) m_pCurFrame->getSubFrame();
		}
		/* 3.2 ���̺��� �ƴ� ���� �����ӿ��� LineList�� ������ �� */
		else{
			pLineList = (CLineList *) m_pCurFrame->getSubFrame();
		}
	}

	/* 3.3 LineList�� �������� �õ��� �Ͽ�����, �������Ƿ� ���� ���� */
	if ( pLineList == BrNULL )
		pLineList = ftLibrary::CreateLineList(m_pCurFrame);

	if ( pLineList != BrNULL )
	{
		CLine * pLastLine = pLineList->getLast();
		if ( pLastLine == BrNULL )
			pLastLine = ftLibrary::CreateLine(pLineList);


		/* 4. Memo CharSet ���� �ʱ�ȭ */
		CCharSet memoCharSet;
		memoCharSet.setAttrID(0);
		memoCharSet.setCode( pDocxComment->getMemoByMemoID()->getMemoID() );
		BrINT32 nSubType = MEMO_TYPE_END | SPLITABLE | EDITABLE;
		memoCharSet.setLinkSubType( LINKTYPE::MEMO, nSubType );

		/* 5. Memo CharSet�� CharSetArray�� �޾��� */
		CCharSetArray *pCharSetArray = pLastLine->getCharSetArray();

		/* 6. ������ �ɸ��ͼ��� CR�� ��� �� �տ�, �ƴ� ��� �� �ڿ� �޾��� */
		/* 6.1 CharSetArray�� ũ�⸦ ���� */
		BrINT32 nCharSetSize = pCharSetArray->size();

		/* 6.2 ���� CharSetArray�� ���� ������ ���� */
		if ( nCharSetSize > 0){
			// ������ CharSet�� CR���� �˻� �ʿ�
			CCharSet pLastCharSet = pCharSetArray->at(nCharSetSize-1);
			/* 6.2.1 ������ CharSet�� CR�̾ CR ������ �޸�ũ �ޱ� */
			if ( pLastCharSet.getCode() == 0xa && pLastCharSet.getLinkType() == LINKTYPE::STANDARD )
				pCharSetArray->InsertAt(nCharSetSize-1, memoCharSet);
			else /* 6.2.2. ������ CharSet�� CR�� �ƴ�. �׳� �߰� */
				pCharSetArray->Add(memoCharSet);
		}
		else{
			/* CharSetArray�� �ƹ��� �����Ͱ� �����Ƿ� �޸�ũ�� �ܼ� �߰� */
			pCharSetArray->Add(memoCharSet);
		}

		/* 7. ���� �޸��� EndLink�� ������ ���������� ���� */
		pDocxComment->setMemoLinkEndAdded();
	}	// if ( pLineList != BrNULL)
	else
	{
		BRTHREAD_ASSERT(0); // LineList�� �������� ����
	}


	return BrTRUE;
}

BrBOOL CDocxConv::convertCommentReference(BrINT32 a_nCommentID)
{
	/* Not Implemented */
	CDocxComments * pDocxComments = m_pDocxLoader->getDocxComments();
	if ( pDocxComments != BrNULL)
	{
		BrBOOL bNeedMemoStartLink = pDocxComments->getNeedMemoLinkStart(a_nCommentID);
		/* �޸� StartLink�� �޾Ҿ��ų�, comments.xml�� �ش� id�� comment�� ���ٸ� �ƹ��۾� ����*/
		if ( bNeedMemoStartLink == BrTRUE ){
			convertCommentRangeStart(a_nCommentID);
			convertCommentRangeEnd(a_nCommentID);
		}
	}

	return BrTRUE;
}

BrBOOL CDocxConv::convertSettings()
{
	if (m_pDocxLoader->m_pSettings)
	{
		CDocxSettings* pDocxSetting = m_pDocxLoader->m_pSettings;

		PoParaAtt defaultParaAtt = *(theBWordDoc->getDefaultParaAtt());
		defaultParaAtt.setDefaultParaTab(pDocxSetting->m_nDefaultTapStop);
		theBWordDoc->setDefaultParaAtt(defaultParaAtt);

		theBWordDoc->setfDntBlnSbDbWid(pDocxSetting->m_bBalanceSingleByteDoubleByteWidth ? BrTRUE : BrFALSE);

		if (pDocxSetting->m_bMirrorMargins)
			theBWordDoc->setMultiplePages(BR_PAPER_LAYOUT_VIEW_MIRROR);
		//compatibilitymode setting
		if (pDocxSetting->m_nCompatibilityModeVersion)
		{
			COMPATIBILITYMODE nCompatibilityModeVersion;
			switch (pDocxSetting->m_nCompatibilityModeVersion)
			{
			case eCOMPATIBILITY_V12:
				nCompatibilityModeVersion = eCOMPATIBILITY_V12;
				break;
			case eCOMPATIBILITY_V14:
				nCompatibilityModeVersion = eCOMPATIBILITY_V14;
				break;
			case eCOMPATIBILITY_V15:	//MS2013������ Compatibility�� 15
				nCompatibilityModeVersion = eCOMPATIBILITY_V15;
				break;
			default:
				nCompatibilityModeVersion = eCOMPATIBILITY_None;
				break;
			}
			theBWordDoc->setCompatibilityModeVersion(nCompatibilityModeVersion);
		}
		//[2013.05.20][TID:15372][������] ������ ���� ���� �۾�(��������)
		theBWordDoc->setGutterAtTop(pDocxSetting->m_bgutterAtTop);

		theBWordDoc->setKinsokuJC(pDocxSetting->m_nKinsoku);
		if (pDocxSetting->m_nKinsoku == 1) {
			theBWordDoc->setNoLineBreaksDefaultChars();
		}
		else if (pDocxSetting->m_nKinsoku == 2) {
			theBWordDoc->setKinsokuLocale(pDocxSetting->m_strKinsokuLocale);
			theBWordDoc->setNoLineBreaksAfter(pDocxSetting->m_strNoLineBreaksAfter);
			theBWordDoc->setNoLineBreaksBefore(pDocxSetting->m_strNoLineBreaksBefore);
		}

		if (pDocxSetting->m_nDefaultTapStop != 360)
			theBWordDoc->SetDefaultTabStop(pDocxSetting->m_nDefaultTapStop);

		theBWordDoc->setAdjustLineHeightInTable(pDocxSetting->m_bAdjustLineHeightInTable);
		theBWordDoc->setCharacterSpacingControl(pDocxSetting->m_nCharacterSpacingControl);
		theBWordDoc->setUseWord97LineBreakRules(pDocxSetting->m_bUseWord97LineBreakRules);

		PoTextAttLanguage poLang;
		if (!pDocxSetting->m_strFontLangAscii.isEmpty())
		{
			const BrCHAR* pLang = pDocxSetting->m_strFontLangAscii.latin1();
			PoLanguage asciiLang;
			asciiLang.setLanguage(pLang);
			poLang.setLatinLang(&asciiLang);
		}

		if (!pDocxSetting->m_strFontLangEastAsia.isEmpty())
		{
			const BrCHAR* pLang = pDocxSetting->m_strFontLangEastAsia.latin1();
			PoLanguage eastAsiaLang;
			eastAsiaLang.setLanguage(pLang);
			poLang.setEastAsiaLang(&eastAsiaLang);
		}

		if (!pDocxSetting->m_strFontLangBidi.isEmpty())
		{
			const BrCHAR* pLang = pDocxSetting->m_strFontLangBidi.latin1();
			PoLanguage bidiLang;
			bidiLang.setLanguage(pLang);
			poLang.setBidiLang(&bidiLang);
		}
		theBWordDoc->setWordLang(poLang);
	}

	return BrTRUE;
}


#endif//IMPORT_DOCX
