#include <word_filter_PCH.hpp>
 
#ifdef IMPORT_DOCX
#include "TextAtt/Handlers/PoTextAttHandler.h"
#include "ParaAtt/Handlers/PoParaAttHandler.h"
#include "bwFrameSet.h"
#include "bwTableEngine.h"
#include "Docx/VML/DocxShape.h"
#include "Docx/Common/Util/DocxUtil.h"
#include "DocxSchema.h"
#include "DocxConv.h"
#include "DocxLockedCanvas.h"
#include "Docx/Text/DocxTextRun.h"
#include "packageBase.h"
#include "package_uri_helper.h"
#include "package_relationship.h"
#include "package_relationship_collection.h"
#include "package_part.h"
#include "package_uri.h"
#include "Docx/Common/Handler/FrameConvertHandler.h"
#include "Docx/Field/DocxField.h"
#include "Docx/Field/DocxRelationField.h"
#include "OOXMLSTHandler.h"

#ifdef SUPPORT_INKML
#include "ContentPart/Handler/ContentPartHandler.h"
#endif	//SUPPORT_INKML

#include "Docx/Common/Util/DocxUtil.h"

#include "bwLine.h"
#include "ftLibrary.h"
#include "DocxLoader.h"
#include "../Paragraph/DocxPara.h"
#include "drawing/brdrawutil_cmn.h"
#include "ftUtil.h"
#include "bwpTypes.h"
#include "Docx/Field/DocxFieldManager.h"
#include "../Error/ErrorHandle.h"
#include "bwTextProc.h"
#include "drawing/officex_model3d.h"
#include "DOM/Dom/domDocument.h"
#include "DOM/Dom/domAttr.h"

#include "bfontex.h"
#include "bwPage.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDocxImageData::CDocxImageData()
{
	m_pID = BrNULL;
	m_pTitle = BrNULL;
	m_pCropTop = BrNULL;
	m_pCropBottom = BrNULL;
	m_pCropLeft = BrNULL;
	m_pCropRight = BrNULL;
	m_pBlackLevel = BrNULL;
	m_pGain	= BrNULL;
	m_pGrayscale = BrNULL;
	m_pBilevel = BrNULL;
}

CDocxImageData::~CDocxImageData()
{
	if( m_pID ) BrFree(m_pID);
	if( m_pTitle ) BrFree(m_pTitle);
	if(m_pCropTop)	BrFree(m_pCropTop); 
	if(m_pCropBottom)	BrFree(m_pCropBottom);
	if(m_pCropLeft)		BrFree(m_pCropLeft);
	if(m_pCropRight)	BrFree(m_pCropRight);
	if(m_pBlackLevel)	BrFree(m_pBlackLevel);
	if(m_pGain)	BrFree(m_pGain);
}

BrBOOL CDocxImageData::readImageDataInfo(XMLDataDecodeParam *pChildNode)
{
	if( pChildNode->pElementData->pAttributePairs )
	{
		for( BrINT32 i = 0; pChildNode->pElementData->pAttributePairs[i]; i+= 2)
		{
			if( 0 == strcmp(pChildNode->pElementData->pAttributePairs[i], X_RID) )
			{
				BrINT32 nLen = BrStrLen(pChildNode->pElementData->pAttributePairs[i+1]);
				m_pID = (BrCHAR*)BrMalloc(nLen+1);
				memcpy(m_pID, pChildNode->pElementData->pAttributePairs[i+1], nLen);
				m_pID[nLen] = 0;
			}
			else if( 0 == strcmp(pChildNode->pElementData->pAttributePairs[i], X_DOC_DRAW_FILL_TITLE) )
			{
				BrINT32 nLen = BrStrLen(pChildNode->pElementData->pAttributePairs[i+1]);
				m_pTitle = (BrCHAR*)BrMalloc(nLen+1);
				memcpy(m_pTitle, pChildNode->pElementData->pAttributePairs[i+1], nLen);
				m_pTitle[nLen] = 0;
			}
			else if( 0 == strcmp(pChildNode->pElementData->pAttributePairs[i], X_DOC_DRAW_CROPTOP) )
			{
				BrINT32 nLen = BrStrLen(pChildNode->pElementData->pAttributePairs[i+1]);
				m_pCropTop = (BrCHAR*)BrMalloc(nLen+1);
				memcpy(m_pCropTop, pChildNode->pElementData->pAttributePairs[i+1], nLen);
				m_pCropTop[nLen] = 0;
			}
			else if( 0 == strcmp(pChildNode->pElementData->pAttributePairs[i], X_DOC_DRAW_CROPBOTOM) )
			{
				BrINT32 nLen = BrStrLen(pChildNode->pElementData->pAttributePairs[i+1]);
				m_pCropBottom = (BrCHAR*)BrMalloc(nLen+1);
				memcpy(m_pCropBottom, pChildNode->pElementData->pAttributePairs[i+1], nLen);
				m_pCropBottom[nLen] = 0;
			}
			else if( 0 == strcmp(pChildNode->pElementData->pAttributePairs[i], X_DOC_DRAW_CROPLEFT) )
			{
				BrINT32 nLen = BrStrLen(pChildNode->pElementData->pAttributePairs[i+1]);
				m_pCropLeft = (BrCHAR*)BrMalloc(nLen+1);
				memcpy(m_pCropLeft, pChildNode->pElementData->pAttributePairs[i+1], nLen);
				m_pCropLeft[nLen] = 0;
			}
			else if( 0 == strcmp(pChildNode->pElementData->pAttributePairs[i], X_DOC_DRAW_CROPRIGHT) )
			{
				BrINT32 nLen = BrStrLen(pChildNode->pElementData->pAttributePairs[i+1]);
				m_pCropRight = (BrCHAR*)BrMalloc(nLen+1);
				memcpy(m_pCropRight, pChildNode->pElementData->pAttributePairs[i+1], nLen);
				m_pCropRight[nLen] = 0;
			}
			else if( 0 == strcmp(pChildNode->pElementData->pAttributePairs[i], X_DOC_DRAW_BLACKLEVEL) )
			{
				BrINT32 nLen = BrStrLen(pChildNode->pElementData->pAttributePairs[i+1]);
				m_pBlackLevel = (BrCHAR*)BrMalloc(nLen+1);
				memcpy(m_pBlackLevel, pChildNode->pElementData->pAttributePairs[i+1], nLen);
				m_pBlackLevel[nLen] = 0;
			}
			else if( 0 == strcmp(pChildNode->pElementData->pAttributePairs[i], X_DOC_DRAW_GAIN) )
			{
				BrINT32 nLen = BrStrLen(pChildNode->pElementData->pAttributePairs[i+1]);
				m_pGain = (BrCHAR*)BrMalloc(nLen+1);
				memcpy(m_pGain, pChildNode->pElementData->pAttributePairs[i+1], nLen);
				m_pGain[nLen] = 0;
			}
			else if( 0 == strcmp(pChildNode->pElementData->pAttributePairs[i], X_DOC_DRAW_GRAYSCALE) )
			{
				BrINT32 nLen = BrStrLen(pChildNode->pElementData->pAttributePairs[i+1]);
				m_pGrayscale = (BrCHAR*)BrMalloc(nLen+1);
				memcpy(m_pGrayscale, pChildNode->pElementData->pAttributePairs[i+1], nLen);
				m_pGrayscale[nLen] = 0;
			}
			else if( 0 == strcmp(pChildNode->pElementData->pAttributePairs[i], X_DOC_DRAW_BILEVEL) )
			{
				BrINT32 nLen = BrStrLen(pChildNode->pElementData->pAttributePairs[i+1]);
				m_pBilevel = (BrCHAR*)BrMalloc(nLen+1);
				memcpy(m_pBilevel, pChildNode->pElementData->pAttributePairs[i+1], nLen);
				m_pBilevel[nLen] = 0;
			}
			
		}
	}

	return BrTRUE;
}

///////////////////////////////////////////////////////////////////////////////////
CDocxDrawTextBox::CDocxDrawTextBox()
{
	m_nVTextAnchor = 0;//TOP_ARRANGE;
	//[2012.11.05][������][M16594] Shape���� Margin 2������ Setting �Ѱ� ����ϱ� ������ �⺻�� 0���� �־���Ѵ�.
	m_nInMargin.nLeft = m_nInMargin.nRight = (BrLONG)INCHtoTWIP(0.1);;//(BrLONG)MMtoTWIP_DOUBLE(2.5);
	m_nInMargin.nTop = m_nInMargin.nBottom = (BrLONG)INCHtoTWIP(0.05);//(BrLONG)(0.025 * 1440); //MMtoTWIP(1.3) jjoo:2009-07-24:�ʱⰪ ����
	m_bFlow = GARO;
	m_bMsoFitShapeToText = BrFALSE;

	m_bTxBxID = BrFALSE;
	m_nTxBxID = 0;
	m_nNextTxBxID = 0;
	m_nSeqence = 0;
}

CDocxDrawTextBox::~CDocxDrawTextBox()
{
}

void CDocxDrawTextBox::setTextBoxInfo(CFrame* a_pFrame, BrBOOL a_bHeaderFooter)
{
	//[2012.02.17][TID : 4211][���ؼ�] �ۻ��� ���� ���� �Ӽ� ����
	a_pFrame->setDirection(m_bFlow > 1 ? BrTRUE : BrFALSE);
	a_pFrame->setTextFlow(m_bFlow);
	a_pFrame->setAutoResizeFlag(m_bMsoFitShapeToText);
	a_pFrame->setArrangePos(m_nVTextAnchor);//[2012.10.20][������] ������ �ؽ�Ʈ  V - arrage ����.
	a_pFrame->setBorderMargin(&m_nInMargin);

	CFrameList* pTargetFrameList = BrNULL;
	if(a_bHeaderFooter)
		pTargetFrameList = theBWordDoc->getAFrameList4HeaderFooter();
	else
		pTargetFrameList = theBWordDoc->getAFrameList();

	BrBOOL bDML = BrTRUE;
	if(a_pFrame->getBorder())
		bDML = (((BrShape*)a_pFrame->getBorder())->isOffice2007Shape() == BrTRUE) ? BrTRUE : BrFALSE;
	if(bDML)
	{
		a_pFrame->setLinkedID(m_nNextTxBxID);
		a_pFrame->setSequence(m_nSeqence);

		if( m_nTxBxID) 
		{
			a_pFrame->setLinkedID(m_nTxBxID);
			SetConnectTextBoxInfo(pTargetFrameList, a_pFrame, m_nTxBxID);
		}
		if( m_nNextTxBxID) 
		{
			SetConnectTextBoxInfo(pTargetFrameList, a_pFrame, m_nNextTxBxID);
		}
	}
	else
	{
		a_pFrame->setLinkedID(m_nTxBxID);
		if(m_nNextTxBxID)
			a_pFrame->setSequence(m_nNextTxBxID);
		SearchLinkedVMLTextBox(pTargetFrameList, a_pFrame, m_nNextTxBxID);
	}
	
}

void CDocxDrawTextBox::SearchLinkedVMLTextBox(CFrameList* a_pTargetFrameList, CFrame* a_pFrame, BrINT32 a_nTextBoxID)
{
	if(!a_pTargetFrameList || !a_pFrame)
		return;

	BrINT32 nSize = a_pTargetFrameList->getTotalFrame();
	CFrame* pTargetFrame = a_pTargetFrameList->getFirst();
	if(!pTargetFrame)
		return;
	for( BrINT32 i = 0; i < nSize; i++)
	{
		 if(pTargetFrame->getSubClass() == FRAMEPR || pTargetFrame->getSubClass() == DROPCAPFRAME)
		 {
			 pTargetFrame = pTargetFrame->getNext();
			 continue;
		 }

		if(a_nTextBoxID != 0 && pTargetFrame->getLinkedID() == a_nTextBoxID)
		{
			pTargetFrame->setAutoResizeFlag(BrFALSE);
			a_pFrame->setAutoResizeFlag(BrFALSE);
			pTargetFrame->setPairID(a_pFrame->getID());
			a_pFrame->setConnectID(pTargetFrame->getID());
			break;
		}
		if(pTargetFrame->getSequence() == a_pFrame->getLinkedID())
		{
			pTargetFrame->setAutoResizeFlag(BrFALSE);
			a_pFrame->setAutoResizeFlag(BrFALSE);
			a_pFrame->setPairID(pTargetFrame->getID());
			pTargetFrame->setConnectID(a_pFrame->getID());
			pTargetFrame->setSequence(0);
			//a_pFrame->m_nSequence = 0;
			break;
		}
		pTargetFrame = pTargetFrame->getNext();
	}
}

void CDocxDrawTextBox::SetConnectTextBoxInfo(CFrameList* a_pAFrameList, CFrame* a_pFrame, BrINT32 a_nNextID)
{
	BArray<CFrame*> ConnectFrames;
	SearchTextBox(a_pAFrameList, ConnectFrames, a_pFrame, a_nNextID);
	if( !ConnectFrames.size())
		return;

	if(ConnectFrames.size() <= a_pFrame->getSequence())
		ConnectFrames.resize(a_pFrame->getSequence()+1);
	ConnectFrames.SetAt(a_pFrame->getSequence(), a_pFrame);

	for(BrINT32 i =0;i<ConnectFrames.size(); i++)
	{
		if(ConnectFrames.at(i))
			ConnectTextBox(ConnectFrames.at(i), ConnectFrames);
	}
}

void CDocxDrawTextBox::ConnectTextBox(CFrame* a_pFrame, BArray<CFrame*> ConnectFrames)
{
	CFrame* pPrevFrame = BrNULL;
	CFrame* pNextFrame = BrNULL;

	if(a_pFrame->getSequence() != 0 )
	{
		if(ConnectFrames.size() > a_pFrame->getSequence() - 1)
			pPrevFrame = ConnectFrames.at(a_pFrame->getSequence() - 1);
	}

	if(ConnectFrames.size() > a_pFrame->getSequence() + 1)
		pNextFrame = ConnectFrames.at(a_pFrame->getSequence() + 1);

	if(pPrevFrame) {
		pPrevFrame->setAutoResizeFlag(BrFALSE);
		a_pFrame->setPairID(pPrevFrame->getID());
		pPrevFrame->setConnectID(a_pFrame->getID());
	}

	if(pNextFrame) {
		pNextFrame->setAutoResizeFlag(BrFALSE);
		pNextFrame->setPairID(a_pFrame->getID());
		a_pFrame->setConnectID(pNextFrame->getID());
	}
}

void CDocxDrawTextBox::SearchTextBox(CFrameList* a_pAFrameList, BArray<CFrame*>& a_LinkedTextBoxes, CFrame* a_pFrame, BrINT32 a_nNextID)
{
	BrINT32 nSize = a_pAFrameList->getTotalFrame();
	CFrame* pFrame = a_pAFrameList->getFirst();
	for( BrINT32 i = 0; i < nSize; i++)
	{
		if( pFrame->isGroup())
			SearchTextBox((CFrameList*)pFrame->getSubFrame(), a_LinkedTextBoxes, a_pFrame, a_nNextID);

		if( pFrame->getLinkedID() == a_nNextID)	{
			if(a_LinkedTextBoxes.size() <= pFrame->getSequence() )
				a_LinkedTextBoxes.resize(pFrame->getSequence() + 1);
			a_LinkedTextBoxes.SetAt(pFrame->getSequence(), pFrame);
		}
		
		pFrame = pFrame->getNext();
	}
}

//////////////////////////////////////////////////////
CDocxDrawStyle::CDocxDrawStyle(CDocxConv *pDocxConv /*=BrNULL*/)
{
	m_nType = 0;
	m_nPosition = 0; //position:static = 0, absolute = 1, relative = 2

	m_bMarginLeft = BrFALSE;
	m_nMarginLeft = 0;
	m_bMarginTop = BrFALSE;
	m_nMarginTop = 0;
	m_nLeft = 0;
	m_nTop = 0;
	m_nWidth = 0;
	m_nHeight = 0;
	m_nZIndex = 0;
	m_nRotation = 0;
	m_nPosHor = -1;
	m_nPosVer = -1;

	m_nPosHorRel = RT_COLUMN;
	m_nPosVerRel = RT_PARAGRAPH;
	m_bFlipX = BrFALSE;
	m_bFlipY = BrFALSE;

	m_pLineList = BrNULL;
	m_pTextBox = BrNULL;
	
	//[2013.02.28][������][M24248] Spec 6.1.2 Elements (VML) �ش� �� 0�� default��.
	m_nWrapMargin.nLeft = m_nWrapMargin.nRight = 0;
	m_nWrapMargin.nTop = m_nWrapMargin.nBottom = 0;

	m_bVisibility = BrTRUE;
	m_pDocxConv = pDocxConv;

	m_nOldBeginLine = 0;
	m_nOldCurBigCharSize = 0;
	m_nOldCurParaHgt = 0;
	m_pOldLineBeforePageBreak = BrNULL;
	m_pOldLineList = BrNULL;
	m_pOldDocxPara = BrNULL;
	m_nWidthPercent = 0;
	m_nHeightPercent = 0;
	m_nWidthRelative = RT_PAGE;
	m_nHeightRelative = RT_PAGE;
	m_dMarginLeftPercent = 0;
	m_dMarginTopPercent = 0;

	m_bWrapTextInShape = BrTRUE;
}

CDocxDrawStyle::~CDocxDrawStyle()
{
	if( m_pTextBox ) BR_SAFE_DELETE(m_pTextBox);
}

BrBOOL CDocxDrawStyle::readStyleInfo(const BrCHAR *strStyle)
{//ex)position:absolute;margin-left:315pt;margin-top:621pt;width:81pt;height:81pt;z-index:251680768

	BrINT32 nTotal = BrStrLen(strStyle);
	BrCHAR* pTmp = (BrCHAR*)strStyle;
	BrCHAR* pMatch = NULL;
	BrINT32 nPos = 0;
	//jjoo:2008-10-06:���� ��Ȯ�� �˼� ����. ex)mso-position-horizontal-relative:right-margin-area
	while(pTmp < strStyle + nTotal)
	{
		pMatch = strchr(pTmp, _T(';'));
		if( pMatch )
			nPos = (BrINT32)(pMatch - pTmp);
		else
			nPos = BrStrLen(pTmp);

		BrCHAR* pCh = (BrCHAR*)BrMalloc(nPos+1);
		memcpy(pCh, pTmp, nPos);
		pCh[nPos] = 0;

		convertStyleInfo(pCh);

		BrFree(pCh);

		pTmp += (nPos+1);
	}

	return BrTRUE;
}

BrINT32 CDocxDrawStyle::getValueDisjoin(BrCHAR *sepsSubCh, BrCHAR** pContext)
{
	BrINT32 nValue = 0;
	BrCHAR* pSubCh = strtok_s(NULL, sepsSubCh, pContext);
	BrCHAR* pPtPos = NULL;
	BrCHAR* pInPos = NULL;
	BrINT32 nPtPos = 0;
	BrINT32 nInPos = 0;
	pPtPos = strstr(pSubCh, "pt");
	pInPos = strstr(pSubCh, "in");
	if(pPtPos)
	{
		nPtPos = (BrINT32)(pPtPos - pSubCh);
		pSubCh[nPtPos] = 0;
		nValue = CDocxUtil::PTtoTWIPDocx(BrAtof(pSubCh));
	}
	else if(pInPos)
	{
		nInPos = (BrINT32)(pInPos - pSubCh);
		pSubCh[nInPos] = 0;
		nValue = INCHtoTWIP(BrAtoi(pSubCh));
	}
	else if(!pPtPos && !pInPos)
		nValue = BrAtoi(pSubCh);

	return nValue;
}

BrINT32 CDocxDrawStyle::getPositionDisjoin(BrCHAR *sepsSubCh, BrCHAR** pContext, BrBYTE bHorizontal)
{
	BrINT32 nValue = 0;
	BrCHAR *pSubCh = strtok_s(NULL, sepsSubCh, pContext);
	if(!pSubCh)
		return RT_COLUMN;
	switch(pSubCh[0])
	{
	case 'a':
		if( 0 == strcmp(pSubCh, "absolute") )
			nValue = -1; //�ʱⰪ �״�� -1 return 
		break;
	case 'b':
		if( 0 == strcmp(pSubCh, "bottom") )
			nValue = ALG_BOTTOM;
		if( 0 == strcmp(pSubCh, "bottom-margin-area") )
			nValue = RT_BOTTOM_MARGIN;	//[2012.08.09][������][TID:8469] Footer �� TextBox ��ġ�� ���� ���� ����.
		break;

	case 'c':
		if( 0 == strcmp(pSubCh, "center") )
			nValue = ALG_CENTER;
		else if( 0 == strcmp(pSubCh, "char") )
			nValue = RT_CHARACTER;
		break;
	case 'i':
		if( 0 == strcmp(pSubCh, "inside") )
			nValue = ALG_INSIDE;
		else if(0 == strcmp(pSubCh, "inner-margin-area"))
			nValue = RT_PADDING;

		break;
	case 'l':
		if( 0 == strcmp(pSubCh, "left") )
			nValue = ALG_LEFT;
		else if( 0 == strcmp(pSubCh, "left-margin-area"))
			nValue = RT_LEFT_MARGIN;
		else if( 0 == strcmp(pSubCh, "line") )
			nValue = RT_LINE;
		break;

	case 'm':
		if( 0 == strcmp(pSubCh, "margin") )
			nValue = RT_MARGIN;
		break;

	case 'o':
		if( 0 == strcmp(pSubCh, "outside") )
			nValue = ALG_OUTSIDE;
		else if( 0 == strcmp(pSubCh, "outer-margin-area"))
			nValue = RT_OUTSIDE_MARGIN;
		break;

	case 'p':
		if( 0 == strcmp(pSubCh, "page") )
			nValue = RT_PAGE;
		if( 0 == strcmp(pSubCh,"paragraph"))
		{
			if( !bHorizontal)
				nValue = RT_LINE;//[2012.08.13][������][TID:8272]���� ��ġ ���� ����.
		}

		break;
	case 'r':
		if( 0 == strcmp(pSubCh, "right") )
		{
			nValue = ALG_RIGHT;
			//[2011.12.21][TID : 2590][���ؼ�] �׷쵵�� Ư�� ��ġ���� ���̾ƿ� �� ��ġ ���� ����
			m_nMarginLeft = (BrINT32)(m_nMarginLeft / 20);
		}
		else if( 0 == strcmp(pSubCh, "right-margin-area"))
			nValue = RT_RIGHT_MARGIN;

		break;
	case 't':
		if( 0 == strcmp(pSubCh, "text") )
		{
			if(bHorizontal)
				nValue = RT_COLUMN;
			else
				nValue = RT_PARAGRAPH;
		}
		else if( 0 == strcmp(pSubCh, "top") )
			nValue = ALG_TOP;
		else if( 0 == strcmp(pSubCh, "top-margin-area"))
			nValue = RT_TOP_MARGIN;

		break;
	}

	return nValue;
}

void CDocxDrawStyle::getDrawRect(BRect &rRect, BrBOOL bInGroup)
{
	if(bInGroup)
		rRect.setRect(m_nLeft, m_nTop, m_nLeft+m_nWidth, m_nTop+m_nHeight);
	else
		rRect.setRect(0, 0, m_nWidth, m_nHeight);
}


BrBOOL	CDocxDrawStyle::ConvertRelativeToAbsolutePosition(CFrame* a_pFrame, CPage* a_pCurPage, BrINT32 a_nFromX, BrINT32 a_nFromY)
{
	FrameConvertHandler FrameConverter;

	if(a_nFromX != 0 || a_nFromY != 0)
		return FrameConverter.ConvertRelativeToAbsolutePosition(a_pFrame, m_nPosHorRel, m_nPosHor, m_nPosVerRel, m_nPosVer, a_nFromX, a_nFromY, m_pDocxConv->m_pCurSectionInformation);
	else 
		return FrameConverter.ConvertRelativeToAbsolutePosition(a_pFrame, m_nPosHorRel, m_nPosHor, m_nPosVerRel, m_nPosVer, m_nMarginLeft, m_nMarginTop, m_pDocxConv->m_pCurSectionInformation);

}

BrBOOL	CDocxDrawStyle::ConvertFramePosition(CFrame* a_pFrame, BrINT32 a_nFromX, BrINT32 a_nFromY)
{
	FrameConvertHandler FrameConverter;
	BrINT32 nLocationTypeH, nLocationTypeV = 0;
	BrFLOAT nValueH, nValueV = 0;

	if(!m_bMarginLeft && m_dMarginLeftPercent != 0)
	{
		nLocationTypeH = LT_RELATIVE;
		nValueH = m_dMarginLeftPercent;
	}
	else if(m_nPosHor == -1)
	{
		nLocationTypeH = LT_ABSOLUTE;
		nValueH = TWIPtoMM_DOUBLE(m_nMarginLeft);
	}
	else
	{
		nLocationTypeH = LT_ALIGNMENT;
		nValueH = m_nPosHor;
	}

	if(!m_bMarginTop && m_dMarginTopPercent != 0)
	{
		nLocationTypeV = LT_RELATIVE;
		nValueV = m_dMarginTopPercent;
	}
	else if(m_nPosVer == -1)
	{
		nLocationTypeV = LT_ABSOLUTE;
		nValueV = TWIPtoMM_DOUBLE(m_nMarginTop);
	}
	else
	{
		nLocationTypeV = LT_ALIGNMENT;
		nValueV = m_nPosVer;
	}

	if(a_nFromX != 0 || a_nFromY != 0)
	{
		nLocationTypeH = nLocationTypeV = LT_ABSOLUTE;
		//m_nPosVerRel = m_nPosVerRel = RT_PAGE;

		return FrameConverter.ConvertFramePosition(a_pFrame, nLocationTypeH, nLocationTypeV, m_nPosHorRel, m_nPosVerRel, TWIPtoMM_DOUBLE(a_nFromX), TWIPtoMM_DOUBLE(a_nFromY));
	}
	else 
	{
		if(m_nPosVerRel == RT_PARAGRAPH && m_nPosVer == ALG_OUTSIDE)
		{
			nLocationTypeV = LT_ABSOLUTE;
			nValueV = 0.0;
		}
		return FrameConverter.ConvertFramePosition(a_pFrame, nLocationTypeH, nLocationTypeV, m_nPosHorRel, m_nPosVerRel, nValueH, nValueV);
	}

}

BrBOOL CDocxDrawStyle::convertStyleInfo(const BrCHAR *strStyle)
{
	if(0 >= BrStrLen(strStyle))
		return BrFALSE;

	BrCHAR sepsSubCh[] = ":";
	char* pContext = BrNULL;
	BrCHAR *pSubCh = strtok_s((BrCHAR*)strStyle, sepsSubCh, &pContext);

	if(!pSubCh)
		return SetErrorFReturn(CFilterErrorObj(kPoErrNullStringAttributeValue, __FILE__, __LINE__));

	BrCHAR chSwitchWord = pSubCh[0];

	if(pSubCh[0] == ASCII_CODE_SPACE)
		strncpy_s(pSubCh, strlen(pSubCh), pSubCh + 1, strlen(pSubCh) - 1);

	switch(pSubCh[0])
	{
	case 'f':
		if( 0 == strcmp(pSubCh, "flip") )
		{
			pSubCh = strtok_s(NULL, sepsSubCh, &pContext);
			BrINT32 nSize = BrStrLen(pSubCh);
			for(BrINT32 idx=0; idx<nSize; idx++)
			{
				BrCHAR pCh[2] = "";
				strncpy_s(pCh, sizeof(pCh), pSubCh+idx, 1);
				if( 0 == strcmp(pCh, "y") )
					m_bFlipY = BrTRUE;
				else if( 0 == strcmp(pCh, "x") )
					m_bFlipX = BrTRUE;
			}
		}
		break;
	case 'm':
		if( 0 == memcmp(pSubCh, "margin", 5)) {
			if( 0 == strcmp(pSubCh, "margin-left") )
			{
				m_nMarginLeft = getValueDisjoin(sepsSubCh, &pContext);
				m_bMarginLeft = BrTRUE;
			}
			else if( 0 == strcmp(pSubCh, "margin-top") )
			{
				m_nMarginTop = getValueDisjoin(sepsSubCh, &pContext);
				m_bMarginTop = BrTRUE;
			}
		}
		else if( 0 == memcmp(pSubCh, "mso", 3))
		{
			switch(pSubCh[4])
			{
			case 'f':
				if( 0 == strcmp(pSubCh, "mso-fit-shape-to-text") )
				{
					if( !m_pTextBox )
						break;

					pSubCh = strtok_s(NULL, sepsSubCh, &pContext);
					if(!pSubCh)
						break;

					if( 0 == strcmp(pSubCh, "t") )
						m_pTextBox->m_bMsoFitShapeToText = BrTRUE;
				}
				break;
			case 'h':
				{
					BrCHAR *pSubCh2 = strtok_s(NULL, sepsSubCh, &pContext);
					if(!pSubCh2)
						break;
					if( 0 == strcmp(pSubCh, "mso-height-percent") )
						m_nHeightPercent = strtol(pSubCh2, BrNULL, 10) /10;
					else if( 0 == strcmp(pSubCh, "mso-height-relative") )
					{
						if( 0 == strcmp(pSubCh2, "page") )
							m_nHeightRelative = RT_PAGE;
						else if( 0 == strcmp(pSubCh2, "margin") )
							m_nHeightRelative = RT_MARGIN;
						else if( 0 == strcmp(pSubCh2, "top-margin-area") )
							m_nHeightRelative = RT_TOP_MARGIN;
						else if( 0 == strcmp(pSubCh2, "bottom-margin-area") )
							m_nHeightRelative = RT_BOTTOM_MARGIN;
						else if( 0 == strcmp(pSubCh2, "inner-margin-area") )
							m_nHeightRelative = RT_PADDING;
						else if( 0 == strcmp(pSubCh2, "outer-margin-area") )
							m_nHeightRelative = RT_OUTSIDE_MARGIN;
					}
				}
				break;
			case 'l':
				{
					if( 0 == strcmp(pSubCh, "mso-layout-flow-alt") )
					{
						if( !m_pTextBox )
							break;

						pSubCh = strtok_s(NULL, sepsSubCh, &pContext);
						if(!pSubCh)
							break;

						if( 0 == strcmp(pSubCh, "bottom-to-top") )
							m_pTextBox->m_bFlow = TEXTFLOW_SERO_270;
					}
					else if(0 == strcmp(pSubCh, "mso-left-percent") )
					{
						pSubCh = strtok_s(NULL, sepsSubCh, &pContext);
						if(!pSubCh)
							break;

						m_dMarginLeftPercent = strtod(pSubCh, BrNULL)/10;
					}
				}

				break;
			case 'n':
				if(0 == strcmp(pSubCh, "mso-next-textbox") )
				{
					if( !m_pTextBox )
						break;

					pSubCh = strtok_s(NULL, sepsSubCh, &pContext);
					if(!pSubCh)
						break;

					m_pTextBox->m_nNextTxBxID = BrAtoi(&pSubCh[8]);
				}
				break;
			case 'p':
				{
					if( 0 == strcmp(pSubCh, "mso-position-horizontal") )
						m_nPosHor = getPositionDisjoin(sepsSubCh, &pContext);
					else if( 0 == strcmp(pSubCh, "mso-position-horizontal-relative") )
						m_nPosHorRel = getPositionDisjoin(sepsSubCh, &pContext);
					else if( 0 == strcmp(pSubCh, "mso-position-vertical") )
						m_nPosVer = getPositionDisjoin(sepsSubCh, &pContext);
					else if( 0 == strcmp(pSubCh, "mso-position-vertical-relative") )
						m_nPosVerRel = getPositionDisjoin(sepsSubCh, &pContext, BrFALSE);
					break;
				}
			case 't':
				{
					if(0 == strcmp(pSubCh, "mso-top-percent") )
					{
						pSubCh = strtok_s(NULL, sepsSubCh, &pContext);
						if(!pSubCh)
							break;

						m_dMarginTopPercent = strtod(pSubCh, BrNULL)/10;
					}
				}
			case 'w':
				{
					BrCHAR *pSubCh2 = strtok_s(NULL, sepsSubCh, &pContext);
					if(!pSubCh2)
						break;

					if( 0 == strcmp(pSubCh, "mso-wrap-distance-left") )
						m_nWrapMargin.nLeft = CDocxUtil::PTtoTWIPDocx(BrAtof(pSubCh2));
					else if( 0 == strcmp(pSubCh, "mso-wrap-distance-top") )
						m_nWrapMargin.nTop = CDocxUtil::PTtoTWIPDocx(BrAtof(pSubCh2));
					else if( 0 == strcmp(pSubCh, "mso-wrap-distance-right") )
						m_nWrapMargin.nRight = CDocxUtil::PTtoTWIPDocx(BrAtof(pSubCh2));
					else if( 0 == strcmp(pSubCh, "mso-wrap-distance-bottom") )
						m_nWrapMargin.nBottom = CDocxUtil::PTtoTWIPDocx(BrAtof(pSubCh2));
					//[2012.06.08][TID:6875]width percent ����
					else if( 0 == strcmp(pSubCh, "mso-width-percent") )
						m_nWidthPercent = strtol(pSubCh2, BrNULL, 10)/10;
					else if( 0 == strcmp(pSubCh, "mso-width-relative") )
					{
						if( 0 == strcmp(pSubCh2, "page") )
							m_nWidthRelative = RT_PAGE;
						else if( 0 == strcmp(pSubCh2, "margin") )
							m_nWidthRelative = RT_MARGIN;
						else if( 0 == strcmp(pSubCh2, "left-margin-area") )
							m_nWidthRelative = RT_LEFT_MARGIN;
						else if( 0 == strcmp(pSubCh2, "right-margin-area") )
							m_nWidthRelative = RT_RIGHT_MARGIN;
						else if( 0 == strcmp(pSubCh2, "inner-margin-area") )
							m_nWidthRelative = RT_PADDING;
						else if( 0 == strcmp(pSubCh2, "outer-margin-area") )
							m_nWidthRelative = RT_OUTSIDE_MARGIN;
					}
					else if( 0 == strcmp(pSubCh, "mso-wrap-style") )
					{
						if( 0 == strcmp(pSubCh2, "none") )
							m_bWrapTextInShape = BrFALSE;
						else if( 0 == strcmp(pSubCh2, "square") )
							m_bWrapTextInShape = BrTRUE;
					}
				}
				break;
			}
		}
		break;
	case 'l':
		if( 0 == strcmp(pSubCh, "left") )
			m_nLeft = getValueDisjoin(sepsSubCh, &pContext);
		else if( 0 == strcmp(pSubCh, "layout-flow") )
		{
			if( !m_pTextBox )
				break;

			pSubCh = strtok_s(NULL, sepsSubCh, &pContext);
			if( !pSubCh)
				break;

			if( 0 == strcmp(pSubCh, "vertical") )
				m_pTextBox->m_bFlow = TEXTFLOW_SERO_90;
			else if( 0 == strcmp(pSubCh, "vertical-ideographic") )
				m_pTextBox->m_bFlow = TEXTFLOW_SERO;
			else if( 0 == strcmp(pSubCh, "horizontal-ideographic") )
				m_pTextBox->m_bFlow = TEXTFLOW_GARO_ROTATE;	
		}
		break;
	case 'h':
		if( 0 == strcmp(pSubCh, "height") )
			m_nHeight = getValueDisjoin(sepsSubCh, &pContext);
		break;
	case 'p':
		if( 0 == strcmp(pSubCh, "position") )
		{
			pSubCh = strtok_s(NULL, sepsSubCh, &pContext);
			if( !pSubCh)
				break;

			if( 0 == strcmp(pSubCh, "absolute") )
				m_nPosition = 1;
			else if( 0 == strcmp(pSubCh, "relative") )
				m_nPosition = 2;
			else if( 0 == strcmp(pSubCh, "static"))
				m_nPosition = 0;
		}		
		break;
	case 'r':
		if( 0 == strcmp(pSubCh, "rotation"))
		{
			pSubCh = strtok_s(NULL, sepsSubCh, &pContext);
			if(!pSubCh)
				break;

			if(strstr( pSubCh, "fd" ))
				m_nRotation = (BrINT32)BrMulDiv( BrAtoi(pSubCh) , 1, 65536);
			else
				m_nRotation = BrAtoi(pSubCh);

			m_nRotation %= 360;
			if (m_nRotation < 0)
				m_nRotation += 360;
		}
		break;
	case 't':
		if( 0 == strcmp(pSubCh, "top") )
			m_nTop = getValueDisjoin(sepsSubCh, &pContext);
		break;
	case 'v':
		if( 0 == strcmp(pSubCh, "v-text-anchor") )
		{//�ؽ�Ʈ �ڽ��� Vertical Arrange
			if( !m_pTextBox ) 
				m_pTextBox = BrNEW CDocxDrawTextBox();

			pSubCh = strtok_s(NULL, sepsSubCh, &pContext);
			if(!pSubCh)
				break;

			if( 0 == strcmp(pSubCh, "top") )
				m_pTextBox->m_nVTextAnchor = TOP_ARRANGE;
			else if( 0 == strcmp(pSubCh, "middle") )
				m_pTextBox->m_nVTextAnchor = MIDDLE_ARRANGE;
			else if( 0 == strcmp(pSubCh, "bottom") )
				m_pTextBox->m_nVTextAnchor = BOTTOM_ARRANGE;		
		}
		else if( 0 == strcmp(pSubCh, "visibility") )
		{
			pSubCh = strtok_s(NULL, sepsSubCh, &pContext);
			if(!pSubCh)
				break;
			if( 0 == strcmp(pSubCh, "hidden") )
				m_bVisibility = BrFALSE;
		}
		break;
	case 'w':
		if( 0 == strcmp(pSubCh, "width") )
			m_nWidth = getValueDisjoin(sepsSubCh, &pContext);
		break;
	case 'z':
		if( 0 == strcmp(pSubCh, "z-index") )
		{
			pSubCh = strtok_s(NULL, sepsSubCh, &pContext);
			if(!pSubCh)
				break;

			m_nZIndex = BrAtoi(pSubCh);
		}
		break;
	}

	return BrTRUE;
}

BrBOOL CDocxDrawStyle::CallbackStartElement(LPVOID pParam)
{
	XMLDataDecodeParam* pInfo = (XMLDataDecodeParam*)pParam;
	
	switch( pInfo->callbackParam.wParam )
	{
	case DOCX_TEXTBOX:
		break;

	case DOCX_TXBXCONTENT:
		{
			if(m_pDocxConv)
			{
				if(!m_pLineList)
					m_pLineList = BrNEW CLineList();

				m_pDocxConv->m_pCurLineList = m_pLineList;
				m_pLineList->setFrame(m_pDocxConv->m_pCurFrame);

				m_pDocxConv->RootChildReadStart(pInfo);
			}
		}
		break;
	}

	if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_TXBXCONTENT))
	{
		if(m_pDocxConv)
		{
			m_pOldLineList = m_pDocxConv->m_pCurLineList;
			m_pDocxConv->m_pCurLineList = NULL;
			m_nOldCurParaHgt = m_pDocxConv->m_nCurParaHgt;
			m_pDocxConv->m_nCurParaHgt = 0;
			m_nOldCurBigCharSize = m_pDocxConv->m_nCurBigCharSize;
			m_pDocxConv->m_nCurBigCharSize = 0;
			m_pOldDocxPara = m_pDocxConv->m_pDocxPara;
			m_pDocxConv->m_pDocxPara = BrNULL;
			m_pDocxConv->m_nDoingType |= DOC_TXBXCONTENT;
		}

		pInfo->callbackParam.wParam = DOCX_TXBXCONTENT;
		pInfo->nElementOption |= BR_XML_NEED_END_ELEMENT;
	}

	return BrTRUE;
}

BrBOOL CDocxDrawStyle::CallbackEndElement(LPVOID pParam)
{
	XMLDataDecodeParam* pInfo = (XMLDataDecodeParam*)pParam;
	
	if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_TXBXCONTENT))
	{
		if(m_pDocxConv)
		{
			// ������ ����� ��������...
			m_pDocxConv->m_pCurLineList = m_pOldLineList;
			m_pDocxConv->m_nCurParaHgt = m_nOldCurParaHgt;
			m_pDocxConv->m_nCurBigCharSize = m_nOldCurBigCharSize;
			m_pDocxConv->m_pDocxPara = m_pOldDocxPara;
			m_pDocxConv->m_nDoingType &= ~DOC_TXBXCONTENT;
		}
	}
	else
	{
		if(m_pDocxConv)
			m_pDocxConv->RootChildReadEnd(pInfo);
	}

	return BrTRUE;
}

BrBOOL  CDocxDrawStyle::readLinkedTextBoxInfo(XMLDataDecodeParam*  pInfo)
{
	if( !pInfo->pElementData->pAttributePairs)
		return BrTRUE;

	if( !m_pTextBox ) 
		m_pTextBox = BrNEW CDocxDrawTextBox();

	for(BrINT32 i = 0; pInfo->pElementData->pAttributePairs[i]; i += 2)
	{
		const BrCHAR *pStr = pInfo->pElementData->pAttributePairs[i];
		switch(pStr[0])
		{
		case 'i':
			if(0 == strcmp(pStr, X_DOC_DRAW_ID) )
			{
				m_pTextBox->m_nNextTxBxID = BrAtoi(pInfo->pElementData->pAttributePairs[i+1]);
				m_pTextBox->m_bTxBxID = BrTRUE;
			}
			break;
		case 's':
			if(0 == strcmp(pStr, "seq") )
			{
				m_pTextBox->m_nSeqence = BrAtoi(pInfo->pElementData->pAttributePairs[i+1]);
			}
			break;
		}
	}
	return BrTRUE;
}

BrBOOL  CDocxDrawStyle::readTextBoxInfo(XMLDataDecodeParam*  pInfo)
{
	if( !pInfo->pElementData->pAttributePairs)
		return BrTRUE;

	if( !m_pTextBox ) 
		m_pTextBox = BrNEW CDocxDrawTextBox();

	for(BrINT32 i = 0; pInfo->pElementData->pAttributePairs[i]; i += 2)
	{
		const BrCHAR *pStr = pInfo->pElementData->pAttributePairs[i];
		switch(pStr[0])
		{
		case 'i':
			if(0 == strcmp(pStr, X_DOC_DRAW_ID) )
			{
				m_pTextBox->m_nTxBxID = BrAtoi(pInfo->pElementData->pAttributePairs[i+1]);
				m_pTextBox->m_bTxBxID = BrTRUE;
			}
			else if( 0 == strcmp(pStr, X_DOC_DRAW_TXBXINMARGIN) )
			{				//[TID 2186][toypilot] ���� �� ���� ���� import ����
				BrINT32 nTotal = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
				BrCHAR *pMargin = (BrCHAR *)BrMalloc(nTotal+1);//BrNEW BrCHAR[nTotal+1];
				memcpy(pMargin, pInfo->pElementData->pAttributePairs[i+1], nTotal);
				pMargin[nTotal] = 0;

				if( nTotal >= 1024) {//2012-10-04 �Ｚ���ȹ��� ���� ����
					SET_ERROR((PoError)kPoErrCorruptFile, "TextMargin Value incorrect");
					BoraPackageBase::CurruptedXmlParser(m_pDocxConv);
					BR_SAFE_FREE(pMargin)
					return BrFALSE;
				}

				BrCHAR *pTmp = pMargin;
				BrCHAR cCh[64]={0,};
				BrCHAR* pMatch = NULL;
				BrINT32 nPos = 0;
				BrINT32 nCount = 0;
				while(pTmp < pMargin + nTotal)
				{
					BrCHAR* pPtPos = NULL;
					BrCHAR* pInPos = NULL;
					BrINT32 nPtPos, nValue;

					pMatch = strchr(pTmp, _T(','));
					if( pMatch )
						nPos = (BrINT32)(pMatch - pTmp);
					else
						nPos = BrStrLen( pTmp );
					strncpy_s(cCh, sizeof(cCh), pTmp, nPos);
					cCh[nPos] = 0;

					pPtPos = strstr(cCh, "pt");
					pInPos = strstr(cCh, "in");

					if(pPtPos)
					{
						nPtPos = (BrINT32)(pPtPos - cCh);
						cCh[nPtPos] = 0;
						nValue = (BrLONG)PTtoTWIP(BrAtof(cCh));
					}
					else if(pInPos)
					{
						nPtPos = (BrINT32)(pInPos - cCh);//hnsong:2011-12-15 [T-2364] [LG325] ���� ���� �ε带 �����ϰ� �̻� �����.(÷�� ���� ����)
						cCh[nPtPos] = 0;
						nValue = (BrLONG)INCHtoTWIP(BrAtof(cCh));
					}
					else
						nValue = (BrLONG)MMtoTWIP_DOUBLE(BrAtof(cCh));

					switch(nCount)
					{
					case 0:	m_pTextBox->m_nInMargin.nLeft = nValue;		break;
					case 1:	m_pTextBox->m_nInMargin.nTop = nValue;		break;
					case 2:	m_pTextBox->m_nInMargin.nRight = nValue;	break;
					case 3:	m_pTextBox->m_nInMargin.nBottom = nValue;	break;
					}

					nCount++;
					pTmp += (nPos+1);
				}
				BrFree(pMargin);
			}
			break;
		case 's':
			if( 0 == strcmp(pStr, X_DOC_DRAW_STYLE) )
			{
				readStyleInfo(pInfo->pElementData->pAttributePairs[i+1]);
			}
			break;
		}
	}

	return BrTRUE;		
}

void CDocxDrawStyle::convertStyleAttr(CFrame *pFrame, CDocxConv *pDocxConv)
{
	if( m_nZIndex)//MistY - 2008.07.21
	{
		//text �� ��ġ �� Frame�� underbasicFlag Set	//MistY - 2008.08.20
		if( (m_nZIndex<0) && (m_nZIndex != DEF_Z_INDEX))	
			pFrame->setUnderBasic(TRUE);
		pFrame->setZindex(m_nZIndex);
	}

	if( m_pTextBox )
	{
		if(!m_bWrapTextInShape)
		{
			pFrame->setAutoWidthFlag(BrTRUE);
			pFrame->setWrapNone(BrTRUE);
		}
		m_pTextBox->setTextBoxInfo(pFrame, pDocxConv->m_bHeaderFooter);
		pFrame->setSubClass(TEXTBOXFRAME);
		//Textbox Caret on/off
		pFrame->setUseTextBox(BrTRUE);
	}
	else
	{//default
		pFrame->setArrangePos(TOP_ARRANGE);

		BRect rcMagin;
		rcMagin.nLeft = rcMagin.nRight = (BrLONG)MMtoTWIP_DOUBLE(2.5);
		rcMagin.nTop = rcMagin.nBottom = (BrLONG)(0.025 * 1440); //MMtoTWIP(1.3) jjoo:2009-07-24:�ʱⰪ ����
		pFrame->setBorderMargin(&rcMagin);
	}
	pFrame->setRunMargin(&m_nWrapMargin);

	if( m_pLineList )
	{
		CLineList *pLineList = (CLineList*)pFrame->getSubFrame();
		if( pLineList )
		{
			BrDELETE pLineList;
			pFrame->setSubFrame(m_pLineList);
			((CLineList*)pFrame->getSubFrame())->setFrame(pFrame);
			m_pLineList = NULL;
		}
	}

}

//////////////////////////////////////////////////////
CDocxDrawFillExt::CDocxDrawFillExt(CDocxConv *pDocxConv)
{
	m_pDocxConv = pDocxConv;
	m_pExt = BrNULL;
	m_pType = BrNULL;
}

CDocxDrawFillExt::~CDocxDrawFillExt()
{
	if(m_pExt)		BR_SAFE_FREE(m_pExt);
	if(m_pType)		BR_SAFE_FREE(m_pType);
}

BrBOOL CDocxDrawFillExt::readFillExtInfo(XMLDataDecodeParam*  pInfo)
{
	if( pInfo->pElementData->pAttributePairs )
	{
		for( BrINT32 i = 0; pInfo->pElementData->pAttributePairs[i]; i+=2)
		{
			const BrCHAR *pStr = pInfo->pElementData->pAttributePairs[i];
			if( 0 == strcmp(pStr, X_DOC_DRAW_EXT) )
			{
				BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
				//possible value = "backwardCompatible", "edit", "view"
				EDTD_RESULT nRet = BrXMLDTDUtil::VMLDocTypeDefintion(eATTValueTypeString, eATTValueSubTypeString_FillExt, pInfo->pElementData->pAttributePairs[i], pInfo->pElementData->pAttributePairs[i+1], m_pDocxConv);
				switch(nRet)
				{
				case DTD_SUCCESS:
					{
						m_pExt = (BrCHAR*)BrMalloc(nLen+1);
						memset(m_pExt,0,nLen+1);
						memcpy(m_pExt, pInfo->pElementData->pAttributePairs[i+1], nLen);
					}
					break;
				case DTD_NEED_DEFAULT_VALUE:
					break;
				case DTD_FAIL:
				case DTD_IGNOREELEMENT:
					return BrFALSE;
				}
			}
			else if( 0 == strcmp(pStr, X_DOC_DRAW_TYPE) )
			{
				BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
				//possible value = "background", "frame", "gradient", "gradientCenter", "gradientRadial", "gradientUnscaled", "pattern", "solid", "tile"
				EDTD_RESULT nRet = BrXMLDTDUtil::VMLDocTypeDefintion(eATTValueTypeString, eATTValueSubTypeString_FillType, pInfo->pElementData->pAttributePairs[i], pInfo->pElementData->pAttributePairs[i+1], m_pDocxConv);
				switch(nRet)
				{
				case DTD_SUCCESS:
					{
						m_pType = (BrCHAR*)BrMalloc(nLen+1);
						memset(m_pType,0,nLen+1);
						memcpy(m_pType, pInfo->pElementData->pAttributePairs[i+1], nLen);
					}
					break;
				case DTD_NEED_DEFAULT_VALUE:
					break;
				case DTD_FAIL:
				case DTD_IGNOREELEMENT:
					return BrFALSE;
				}
			}

		}
	}

	return BrTRUE;
}

//////////////////////////////////////////////////////
CDocxDrawGradient::CDocxDrawGradient(CDocxConv *pDocxConv)
{
	m_nAngle = 0;
	m_nFocusSize = 0;
	m_nFocus = 0;
	m_pDocxConv = pDocxConv;

	m_pMethod = BrNULL;

	m_nFocusPositionX = 0;
	m_nFocusPositionY = 0;
};

CDocxDrawGradient::~CDocxDrawGradient()
{
	if(m_pMethod)		BR_SAFE_FREE(m_pMethod);

}


//////////////////////////////////////////////////////
CDocxDrawFill::CDocxDrawFill(CDocxConv *pDocxConv)
{
	m_pID = BrNULL;
	m_pTitle = BrNULL;
	m_pColor2 = BrNULL;
	m_pColors = BrNULL;
	m_pType = BrNULL;

	m_pDocxConv = pDocxConv;

	m_bFillRotate = BrFALSE;
	m_bRecolor = BrFALSE;

	m_pFillExt = BrNULL;
	m_pOpacity = BrNULL;
	m_pGradient = BrNULL;
	m_pOpacity2 = BrNULL;
}

CDocxDrawFill::~CDocxDrawFill()
{
	if(m_pFillExt)	BR_SAFE_DELETE(m_pFillExt);
	if( m_pGradient ) BR_SAFE_DELETE(m_pGradient);
	if( m_pOpacity ) BR_SAFE_FREE(m_pOpacity);

	if(m_pID)		BR_SAFE_FREE(m_pID);
	if(m_pTitle)	BR_SAFE_FREE(m_pTitle);
	if(m_pColor2)	BR_SAFE_FREE(m_pColor2);
	if(m_pColors)	BR_SAFE_FREE(m_pColors);
	if(m_pType)		BR_SAFE_FREE(m_pType);
	if( m_pOpacity2 ) BR_SAFE_FREE(m_pOpacity2);
}

BrBOOL CDocxDrawFill::readFillInfo(XMLDataDecodeParam*  pInfo)
{
	if( pInfo->pElementData->pAttributePairs )
	{
		for( BrINT32 i = 0; pInfo->pElementData->pAttributePairs[i]; i+=2)
		{
			const BrCHAR *pStr = pInfo->pElementData->pAttributePairs[i];
			if( 0 == strcmp(pStr, X_RID) )
			{
				BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
				EDTD_RESULT nRet = BrXMLDTDUtil::VMLDocTypeDefintion(eATTValueTypeString, eATTValueSubTypeString_ShapeFillId, pInfo->pElementData->pAttributePairs[i], pInfo->pElementData->pAttributePairs[i+1], m_pDocxConv);
				switch(nRet)
				{
				case DTD_SUCCESS:
					m_pID = (BrCHAR*)BrMalloc(nLen+1);
					memset(m_pID,0,nLen+1);
					memcpy(m_pID, pInfo->pElementData->pAttributePairs[i+1], nLen);
					break;
				case DTD_NEED_DEFAULT_VALUE:
					break;
				case DTD_FAIL:
				case DTD_IGNOREELEMENT:
					return BrFALSE;
				}
			}
			else if( 0 == strcmp(pStr, X_DOC_DRAW_FILL_TITLE) )
			{
				BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);

				EDTD_RESULT nRet = BrXMLDTDUtil::VMLDocTypeDefintion(eATTValueTypeString, eATTValueSubTypeString_ShapeFillTitle, pInfo->pElementData->pAttributePairs[i], pInfo->pElementData->pAttributePairs[i+1], m_pDocxConv);
				switch(nRet)
				{
				case DTD_SUCCESS:
					m_pTitle = (BrCHAR*)BrMalloc(nLen+1);
					memset(m_pTitle,0,nLen+1);
					memcpy(m_pTitle, pInfo->pElementData->pAttributePairs[i+1], nLen);
					break;
				case DTD_NEED_DEFAULT_VALUE:
					break;
				case DTD_FAIL:
				case DTD_IGNOREELEMENT:
					return BrFALSE;
				}
			}
			else if( 0 == strcmp(pStr, "recolor") )
			{
				BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
				BrCHAR buf[10];
				memcpy(buf, pInfo->pElementData->pAttributePairs[i+1], nLen);
				buf[nLen] = 0;

				BrXMLDTDUtil::setVMLBoolData((BrCHAR *)buf,nLen,m_bRecolor);
			}
			else if( 0 == strcmp(pStr, X_DOC_DRAW_FILL_ROTATE) )
			{
				//�ش� val��(true, t, f, false)�� �ü� ����
				BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
				if(nLen > 5 ) {//2012-10-04 �Ｚ���ȹ��� ���� ����
					SET_ERROR((PoError)kPoErrCorruptFile, "Rotate Value incorrect");
					BoraPackageBase::CurruptedXmlParser(m_pDocxConv);
					return BrFALSE;
				}

				BrCHAR buf[10] = { 0, };
				memcpy(buf, pInfo->pElementData->pAttributePairs[i+1], nLen);
				buf[nLen] = 0;

				BrXMLDTDUtil::setVMLBoolData((BrCHAR *)buf,nLen,m_bFillRotate);
			}
			else if( 0 == strcmp(pStr, X_DOC_DRAW_TYPE) )
			{
				BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
				EDTD_RESULT nRet = BrXMLDTDUtil::VMLDocTypeDefintion(eATTValueTypeString, eATTValueSubTypeString_ShapeFillType, pInfo->pElementData->pAttributePairs[i], pInfo->pElementData->pAttributePairs[i+1], m_pDocxConv);
				switch(nRet)
				{
				case DTD_SUCCESS:
					m_pType = (BrCHAR*)BrMalloc(nLen+1);
					memset(m_pType,0,nLen+1);
					memcpy(m_pType, pInfo->pElementData->pAttributePairs[i+1], nLen);
					break;
				case DTD_NEED_DEFAULT_VALUE:
					break;
				case DTD_FAIL:
				case DTD_IGNOREELEMENT:
					return BrFALSE;
				}
			}
			else if( 0 == strcmp(pStr, X_DOC_DRAW_FILL_COLOR2) )
			{
				BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
				EDTD_RESULT nRet = BrXMLDTDUtil::VMLDocTypeDefintion(eATTValueTypeString, eATTValueSubTypeString_ShapeFillColor2, pInfo->pElementData->pAttributePairs[i], pInfo->pElementData->pAttributePairs[i+1], m_pDocxConv);
				switch(nRet)
				{
				case DTD_SUCCESS:
					m_pColor2 = (BrCHAR*)BrMalloc(nLen+1);
					memset(m_pColor2,0,nLen+1);
					memcpy(m_pColor2, pInfo->pElementData->pAttributePairs[i+1], nLen);
					break;
				case DTD_NEED_DEFAULT_VALUE:
					break;
				case DTD_FAIL:
				case DTD_IGNOREELEMENT:
					return BrFALSE;
				}
			}
			else if( 0 == strcmp(pStr, X_DOC_DRAW_FILL_COLORS) )
			{
				//[������][2013.4.19] �׶��̼� �⺻ ������ �����ϱ� ���� Colors Attribute�� Read�Ѵ�.
				BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
				m_pColors = (BrCHAR*)BrMalloc(nLen+1);
				memset(m_pColors,0,nLen+1);
				memcpy(m_pColors, pInfo->pElementData->pAttributePairs[i+1], nLen);
			}
			else if( 0 == strcmp(pStr, X_DOC_DRAW_FILL_METHOD) )
			{
				if( NULL == m_pGradient ) 
					m_pGradient = BrNEW CDocxDrawGradient(m_pDocxConv);

				BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
				EDTD_RESULT nRet = BrXMLDTDUtil::VMLDocTypeDefintion(eATTValueTypeString,eATTValueSubTypeString_FillMethod, pInfo->pElementData->pAttributePairs[i], pInfo->pElementData->pAttributePairs[i+1], m_pDocxConv);
				switch(nRet)
				{
				case DTD_SUCCESS:
					{
						m_pGradient->m_pMethod = (BrCHAR*)BrMalloc(nLen+1);
						memcpy(m_pGradient->m_pMethod, pInfo->pElementData->pAttributePairs[i+1], nLen );
						m_pGradient->m_pMethod[nLen] = 0;
					}
					break;
				case DTD_NEED_DEFAULT_VALUE:
					break;
				case DTD_FAIL:
				case DTD_IGNOREELEMENT:
					return BrFALSE;
				}
			}
			else if( 0 == strcmp(pStr, X_DOC_DRAW_FILL_FOCUS) )
			{
				if( NULL == m_pGradient ) 
					m_pGradient = BrNEW CDocxDrawGradient();

				m_pGradient->m_nFocus = BrAtoi(pInfo->pElementData->pAttributePairs[i+1] );
			}
			else if( 0 == strcmp(pStr, X_DOC_DRAW_FILL_FOCUSPOSITION) )
			{
				if( NULL == m_pGradient ) 
					m_pGradient = BrNEW CDocxDrawGradient();

				BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
				BrCHAR* pBuf = (BrCHAR*)BrMalloc(nLen+1);
				memcpy(pBuf, pInfo->pElementData->pAttributePairs[i+1], nLen);
				pBuf[nLen] = 0;
				char* pContext = BrNULL;
				BrCHAR *ch = strtok_s(pBuf, ",", &pContext);
				if( ch )
				{
					if(pBuf[0] == ',')
					{
						m_pGradient->m_nFocusPositionX = 0;
						m_pGradient->m_nFocusPositionY = BrAtoi(ch);
					}
					else
					{
						m_pGradient->m_nFocusPositionX = BrAtoi(ch);
						ch = strtok_s(NULL, ",", &pContext);
						if( ch )
						{
							m_pGradient->m_nFocusPositionY = BrAtoi(ch);
						}
					}
				}

				BrFree(pBuf);
			}
			else if( 0 == strcmp(pStr, X_DOC_DRAW_FILL_FOCUSSIZE) )
			{
				if( NULL == m_pGradient ) 
					m_pGradient = BrNEW CDocxDrawGradient();

				m_pGradient->m_nFocusSize = BrAtoi(pInfo->pElementData->pAttributePairs[i+1] );
			}
			else if( 0 == strcmp(pStr, X_DOC_DRAW_FILL_ANGLE) )
			{
				if( NULL == m_pGradient ) 
					m_pGradient = BrNEW CDocxDrawGradient();

				m_pGradient->m_nAngle = BrAtoi(pInfo->pElementData->pAttributePairs[i+1] );
			}
			else if( 0 == strcmp(pStr, X_DOC_DRAW_FILL_OPACITY) )
			{
				BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
				m_pOpacity = (BrCHAR*)BrMalloc(nLen+1);
				memcpy(m_pOpacity, pInfo->pElementData->pAttributePairs[i+1], nLen);
				m_pOpacity[nLen] = 0;				
			}
			else if(0 == strcmp(pStr, "o:opacity2"))
			{
				BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
				m_pOpacity2 = (BrCHAR*)BrMalloc(nLen+1);
				memcpy(m_pOpacity2, pInfo->pElementData->pAttributePairs[i+1], nLen);
				m_pOpacity2[nLen] = 0;		
			}
		}
	}
	
	return BrTRUE;
}

CFrame* CDocxDrawFill::convertFillAttribute(const BrCHAR* pCurPackagePartName, BRect *pRect, ShapeType dType)
{
	if(!m_pDocxConv)
		return BrNULL;
	CFrame *pFrame = BrNULL;
	if( m_pType && m_pID && //hnsong:2013-02-03 �״� ���� ����
		( 0 == strcmp(m_pType, "frame")|| 0 == strcmp(m_pType, "tile")) )		
	{//frame, tile
		pFrame = m_pDocxConv->createImage(*pRect, pCurPackagePartName, m_pID, BrFALSE, BrFALSE, FLOATFRAME, dType);
		if(!pFrame)
			return BrNULL;
	}
	else
	{
		pFrame = m_pDocxConv->createFrame(FLOATFRAME, pRect, BrFALSE, m_pDocxConv->m_pCurPage->getPageNum(), BrTRUE);
		if(!pFrame)
			return NULL;
	}

	if( BrNULL == pFrame->getBorder() )
		pFrame->setBorder( BrShape::createShape((int)dType, *pFrame->getFrameRect() ));

	return pFrame;
}

BrBOOL CDocxDrawFill::convertFillInfo(CFrame *pFrame, BrGrapAtt *pGrapAtt, BoraPackageBase* a_pPackage)
{
	if( m_pType ) 
	{
		BrBrushObj* pBrushObj = pGrapAtt->getBrush();
		switch(m_pType[0])
		{
			if(!pBrushObj)
				return BrFALSE;
				//frame, tile�� �׻� �̹����� �����Ѵ�.
		case 'f':
			if( 0 == strcmp(m_pType, "frame"))
			{
				//[2013.04.22][������] Fill Image ó�� �ϴ� Crop, strPartName ���Ƿ� ó��.
				if(m_pID)
				{
#ifdef SUPPORT_IMAGE_BRUSH
					if(pGrapAtt->hasBrush(eBrBrushId_Main))
					{
						BrBrushObj* pImageBrush = BrNULL;
						BrImageAttr* pImgAttr = BrNULL;
						pImageBrush = BrNEW BrBrushObj();
						pImgAttr = pImageBrush->getImageAttr();
						pImgAttr->setImageLoader(a_pPackage->GetImageLoader("word/document.xml", m_pID, pImgAttr->GetClipInfo()->CropLeft, pImgAttr->GetClipInfo()->CropTop, pImgAttr->GetClipInfo()->CropRight, pImgAttr->GetClipInfo()->CropBottom));
						pImageBrush->setStyle(BMV_FILLTYPE_IMAGE);
						
						pGrapAtt->addBrush(*pImageBrush, eBrBrushId_Image);
						BR_SAFE_DELETE(pImageBrush);
					}
					else
					{
						BrImageAttr* pImgAttr = pBrushObj->getImageAttr();
						pImgAttr->setImageLoader(a_pPackage->GetImageLoader("word/document.xml", m_pID, pImgAttr->GetClipInfo()->CropLeft, pImgAttr->GetClipInfo()->CropTop, pImgAttr->GetClipInfo()->CropRight, pImgAttr->GetClipInfo()->CropBottom));
						pBrushObj->setStyle(BMV_FILLTYPE_IMAGE);
					}
#else //SUPPORT_IMAGE_BRUSH
					BrImageAttr* pImgAttr = pBrushObj->getImageAttr();
					pImgAttr->setImageLoader(a_pPackage->GetImageLoader("word/document.xml", m_pID, pImgAttr->GetClipInfo()->CropLeft, pImgAttr->GetClipInfo()->CropTop, pImgAttr->GetClipInfo()->CropRight, pImgAttr->GetClipInfo()->CropBottom));
					pBrushObj->setStyle(BMV_FILLTYPE_IMAGE);
#endif //SUPPORT_IMAGE_BRUSH
				}
			}
			break;
		case 't':
			if( 0 == strcmp(m_pType, "tile"))
			{
				pBrushObj->setStyle(BMV_FILLTYPE_TEXTURE);
				if( 0 == strcmp(m_pType, "tile") )
					pBrushObj->setTile(BrTRUE);
				//	pBrushObj->getImageAttr()->setTile(BrTRUE);			
			}
			break;
		case 'p':
			if(m_pID && 0 == strcmp(m_pType, "pattern"))
			{
				const BrCHAR *pImageName = a_pPackage->GetPathWithMainRelType(CORE_DOCUMENT_PART_TYPE, IMAGE_PART_TYPE, m_pID);
				if( !pImageName )
					return BrFALSE;
				pBrushObj->setStyle(BMV_FILLTYPE_PATTERN);
				if( m_pColor2 )
					pBrushObj->setBackColor(CDocxUtil::getColor2(m_pColor2, pGrapAtt->getBrush()->getForeColor()));

				IMG_INFO cImageInfo = { eImage_NONE, };
#ifdef XML_DOC_TYPE_DEF
				BrLPBYTE pImage = a_pPackage->ReadBlip_DOCX(m_pID, &cImageInfo);	
#else
				BrLPBYTE pImage = a_pPackage->ReadBlip_DOCX(m_cID, &cImageInfo);	
#endif

				PrBitmap bitmap ;
				if(bitmap.getImageInfoToPattern(pImage, cImageInfo.nRawSize, cImageInfo.width, cImageInfo.height))
				{
					BrINT32 pID = ftUtil::ComparePattern_DOCX(&bitmap);
					pBrushObj->setPattern(pID+1);// index�� 1���� ���۵�.
				}	
			}
			break;

		case 'g':
			if(0 == strcmp(m_pType, "gradient"))
			{
				pBrushObj->setStyle(BMV_FILLTYPE_GRADIENT);
#ifdef XML_DOC_TYPE_DEF
				if(m_pColor2)
					pBrushObj->setBackColor(CDocxUtil::getColor2(m_pColor2, pGrapAtt->getBrush()->getForeColor()));
#else
				pGrapAtt->getBrush()->setBackColor(CDocxUtil::getColor2(m_cColor2, pGrapAtt->getBrush()->getForeColor()));
#endif
				//[������][2013.04.19] �׶��̼� �⺻������ ����
				if(m_pColors)
				{
					BArray<BrCHAR*> arrPosition;
					BArray<BrCHAR*> arrColor;
					BrINT32 nCurOpacity = 0 , nPrevPosition = 0, nPrevOpacity = 0;
					BrINT32 nForeOpacity = convertOpacity(m_pOpacity);
					BrINT32 nBackOpacity = convertOpacity(m_pOpacity2);
					//Colors�� ���� Position���� Color������ �и��Ѵ�.
					convertGradientColors(m_pColors, arrPosition, arrColor);

					for(BrINT32 i = 0; i < arrPosition.size(); i++)
					{
						BrFLOAT nPosition = 0;
						BrCHAR* pPositionData = arrPosition.at(i);
						
						//Position�� ���� �����ʹ� 0~1������ ���� ���´�. 1�� ��� setting �� �� 100���� �ٲ� �ش�.
						if(strtol(pPositionData, BrNULL, 10) == 1)
							arrPosition.at(i) = "65536";

						if(pPositionData[0] == '.')
							nPosition = strtod(pPositionData, BrNULL) * 100;
						else
							nPosition = strtol(arrPosition.at(i), BrNULL, 10)/65536.0*100;

						if(nForeOpacity != 0 || nBackOpacity != 0)
						{
							nCurOpacity = nBackOpacity;

							if(i != 0)
							{
								nCurOpacity = nPrevOpacity + (nForeOpacity - nBackOpacity) * ((nPosition - nPrevPosition) / 100);
									//((nPrevPosition - nPosition) / 2) + nPrevOpacity;
								if(i == arrPosition.size() - 1)
									nCurOpacity = nForeOpacity;
							}						

							pBrushObj->addGColor(nPosition, CUtil::getColor(arrColor.at(i)), nCurOpacity);
						}
						else
							pBrushObj->addGColor(nPosition, CUtil::getColor(arrColor.at(i)), nCurOpacity);

						nPrevOpacity = nCurOpacity;	
						nPrevPosition = nPosition;
					}					
				}
				else if(pBrushObj->getGColorsA()->GetSize() <= 0) //�ΰ��� ���� ��쿡�� AddGColor�� ����
				{
					if(pBrushObj->getForeColor( ) != NONE_COLOR_BITS)
						pBrushObj->addGColor(0, pBrushObj->getForeColor(), convertOpacity(m_pOpacity));
					else
						pBrushObj->addGColor(0, RGB_WHITE, convertOpacity(m_pOpacity));

					if(pBrushObj->getBackColor() != NONE_COLOR_BITS)
						pBrushObj->addGColor(100, pBrushObj->getBackColor(), convertOpacity(m_pOpacity2));
					else
						pBrushObj->addGColor(100, RGB_WHITE, convertOpacity(m_pOpacity2));
				}

				pBrushObj->setGradient(GRADIENT_BOTTOMTOP); //default�� - ms�� �̰��� �⺻��.
				if( m_pGradient )
				{
					pBrushObj->setGAngle(m_pGradient->m_nAngle);
					switch( m_pGradient->m_nFocus )
					{
					case 100: 
						switch(m_pGradient->m_nAngle)
						{
						case 0:  // ����
							pBrushObj->setGradient(GRADIENT_TOPBOTTOM); //����1
							break;
						case -90: // ����
							pBrushObj->setGradient(GRADIENT_LEFTRIGHT); //����1
							break;
						case -135: // ����
							pBrushObj->setGradient(GRADIENT_LT2RB); //����1
							break;
						case -45: // ����
							pBrushObj->setGradient(GRADIENT_RT2LB); //����2
							break;
						default:
							pBrushObj->setGradient(GRADIENT_LINEAR_ANGLE);
							break;
						}
						break;
					case 50 :
						switch(m_pGradient->m_nAngle)
						{
						case 0: 
							pBrushObj->setGradient(GRADIENT_VERTIOUT); //����3
							break;
						case -90:
							pBrushObj->setGradient(GRADIENT_HORIZIN); //����4
							break;
						case -135:
							pBrushObj->setGradient(GRADIENT_SLASHIN); //����4
							break;
						case -45:
							pBrushObj->setGradient(GRADIENT_BSLASHIN); //����4
							break;
						default:
							pBrushObj->setGradient(GRADIENT_LINEAR_ANGLE);
							break;
						}
						break;
					case 0 :
						switch(m_pGradient->m_nAngle)
						{
						case 0: 
							pBrushObj->setGradient(GRADIENT_BOTTOMTOP); //����2
							break;
						case -90:
							pBrushObj->setGradient(GRADIENT_RIGHTLEFT); //����2
							break;
						case -135:
							pBrushObj->setGradient(GRADIENT_RB2LT);	//����2
							break;
						case -45:
							pBrushObj->setGradient(GRADIENT_LB2RT); //����1
							break;
						default:
							pBrushObj->setGradient(GRADIENT_LINEAR_ANGLE);
							break;
						}					
						break;
					default :
						switch(m_pGradient->m_nAngle)
						{
						case 0: 
							pBrushObj->setGradient(GRADIENT_VERTIIN); //����4
							break;
						case -90:
							pBrushObj->setGradient(GRADIENT_HORIZOUT); //����3
							break;
						case -135:
							pBrushObj->setGradient(GRADIENT_SLASHOUT); //����3
							break;
						case -45:
							pBrushObj->setGradient(GRADIENT_BSLASHOUT); //����3
							break;
						default:
							pBrushObj->setGradient(GRADIENT_LINEAR_ANGLE);
							break;
						}					
						break;
					}
				}

				if(pBrushObj->getGradient() == GRADIENT_LINEAR_ANGLE)
				{
					BrINT32 nInt = m_pGradient->m_nAngle;
					if(nInt >= 0)
						nInt = -nInt + 90;
					else
						nInt = (-nInt + 90) - 180;

					if(nInt < 0)
						nInt = 360 + nInt;
					pBrushObj->setGAngle(nInt);
				}
				
				//���� ���� �׶��̼� �Բ� ȸ�� ���� ����
				pBrushObj->setRotationwithShape(m_bFillRotate);
			}
			else if(0 == strcmp(m_pType, "gradientRadial") )
			{
				pBrushObj->setStyle(BMV_FILLTYPE_GRADIENT);
				if(m_pColors)
				{
					BArray<BrCHAR*> arrPosition;
					BArray<BrCHAR*> arrColor;

					//Colors�� ���� Position���� Color������ �и��Ѵ�.
					convertGradientColors(m_pColors, arrPosition, arrColor);

					for(BrINT32 i = 0; i < arrPosition.size(); i++)
					{
						//Position�� ���� �����ʹ� 0~1������ ���� ���´�. 1�� ��� setting �� �� 100���� �ٲ� �ش�.
						if(strtol(arrPosition.at(i), BrNULL, 10) == 1)
							arrPosition.at(i) = "65536";

						pBrushObj->addGColor(strtol(arrPosition.at(i), BrNULL, 10)/65536.0*100, CUtil::getColor(arrColor.at(i)));
					}

				}
				pBrushObj->setBackColor(CDocxUtil::getColor2(m_pColor2, pGrapAtt->getBrush()->getForeColor()));
				
				if(pBrushObj->getGColorsA()->GetSize() <= 0) //�ΰ��� ���� ��쿡�� AddGColor�� ����
				{
					if(pBrushObj->getForeColor( ) != NONE_COLOR_BITS)
						pBrushObj->addGColor(0, pBrushObj->getForeColor(), convertOpacity(m_pOpacity));
					else
						pBrushObj->addGColor(0, RGB_WHITE, convertOpacity(m_pOpacity));

					if(pBrushObj->getBackColor() != NONE_COLOR_BITS)
						pBrushObj->addGColor(100, pBrushObj->getBackColor(), convertOpacity(m_pOpacity2));
					else
						pBrushObj->addGColor(100, RGB_WHITE, convertOpacity(m_pOpacity2));
				}

				if(m_pFillExt && m_pFillExt->m_pType && (strcmp(m_pFillExt->m_pType, "gradientCenter") == 0))	//�𼭸�
				{
					BrINT32 x = m_pGradient->m_nFocusPositionX;
					BrINT32 y = m_pGradient->m_nFocusPositionY;

					if(x == 0 && y == 0)
						pBrushObj->setGradient(GRADIENT_CORNER_TOPLEFT);
					else if(x == 1 && y == 0)
						pBrushObj->setGradient(GRADIENT_CORNER_TOPRIGHT);
					else if(x == 0 && y == 1)
						pBrushObj->setGradient(GRADIENT_CORNER_BOTTOMLEFT);
					else if(x == 1 && y == 1)
						pBrushObj->setGradient(GRADIENT_CORNER_BOTTOMRIGHT);
					else
					{
						if( m_pGradient->m_nFocus == 100)
							pBrushObj->setGradient(GRADIENT_CENTER_OUT);
						else
							pBrushObj->setGradient(GRADIENT_CENTER_IN);
					}
				}
				else	//���
				{
					if( m_pGradient->m_nFocus == 100)
						pBrushObj->setGradient(GRADIENT_CENTER_OUT);
					else
						pBrushObj->setGradient(GRADIENT_CENTER_IN);
				}
				//���� ���� �׶��̼� �Բ� ȸ�� ���� ����
				pBrushObj->setRotationwithShape(m_bFillRotate);
			}
			break;
		}
	}
	else if( m_pColor2 && pFrame->isWordArt() )
	{//2011.01.20 hnsong for export
		pGrapAtt->getBrush()->setBackColor(CDocxUtil::getColor2(m_pColor2, pGrapAtt->getBrush()->getForeColor()));
	}

	//[TID:5032] FreeDraw���� �׷��� Ellipse/Polygon�� ������ ���� �� ������ �̻� ����
	if(m_pOpacity && pGrapAtt->getBrush() && BMV_FILLTYPE_GRADIENT != pGrapAtt->getBrush()->getStyle() )
	{//[2012.09.12][������][TID:9276] Gradient �ϋ� ������ 0�̸� �ȵ�.	
		BrINT32 nSize = BrStrLen(m_pOpacity);
		BrINT32 nVal = 0;
		if(m_pOpacity[0] == '.')
		{
			nVal = (BrINT32)(BrFRound((BrFLOAT)(BrAtof(m_pOpacity) * 255.0)));
		}
		else if(m_pOpacity[nSize-1] == 'f')
		{
			nVal = (BrINT32)(BrFRound((BrFLOAT)(BrAtoi(m_pOpacity) / 65536.0 * 255.0)));
		}
		else if(m_pOpacity[0] == '1')	//[2012.11.03][������][M14786]1 or 1.0 �϶� ���������� Setting �Ǿ� ��.
			nVal = 255;

		pGrapAtt->getBrush()->setTransparent(nVal); //0(����) ~ 255(������)
	}
	else
		pGrapAtt->getBrush()->setTransparent(0xff);

	if(m_pFillExt)
	{
		if(m_pFillExt->m_pExt)
		{
			if(strcmp(m_pFillExt->m_pExt, "backwardCompatible") == 0)
			{
				pGrapAtt->setBrushExtHandlingBehavior(eBrBrushExtHB_BackwardCompatible);
			}
			else if(strcmp(m_pFillExt->m_pExt, "edit") == 0)
			{
				pGrapAtt->setBrushExtHandlingBehavior(eBrBrushExtHB_Edit);
			}
			else if(strcmp(m_pFillExt->m_pExt, "view") == 0)
			{
				pGrapAtt->setBrushExtHandlingBehavior(eBrBrushExtHB_View);
			}
		}
	}

	return BrTRUE;
}

BrINT32 CDocxDrawFill::convertOpacity(BrCHAR* a_pOpacity) //0~100%�� ȯ��
{
	//������ �����ϴ� Transparent �� �޸� GColor��  0%(������)~100%(����)
	if(!a_pOpacity)
		return 0;

	BrINT32 nSize = BrStrLen(a_pOpacity);
	BrINT32 nVal = 0;
	if(a_pOpacity[0] == '.')
	{
		nVal = 100 - (BrINT32)(BrFRound((BrFLOAT)(BrAtof(a_pOpacity) * 100.0)));
	}
	else if(a_pOpacity[nSize-1] == 'f')
	{
		nVal = 100 - (BrINT32)(BrFRound((BrFLOAT)(BrAtoi(a_pOpacity) / 65536.0 * 100.0)));
	}
	else if(a_pOpacity[0] == '1')	//[2012.11.03][������][M14786]1 or 1.0 �϶� ���������� Setting �Ǿ� ��.
	{
		nVal = 0;
	}
	else if(a_pOpacity[0] == '0')
	{
		nVal = 100;
	}

	return nVal;
}

void CDocxDrawFill::convertGradientColors(BrCHAR  *a_pColors, 	BArray<BrCHAR*> a_arrPosition,  BArray<BrCHAR*> a_arrColor)
{
	BrCHAR* pBuf = BrNULL;
	BrINT32 nTotalLen = BrStrLen(a_pColors);
	pBuf = (BrCHAR*)BrMalloc(nTotalLen+1);

	memcpy(pBuf, a_pColors, nTotalLen);
	pBuf[nTotalLen] = 0;

	BArray<BrCHAR*> arrColorsData;

	BrCHAR seps1[] = ";";

	//";"���� ��ū �и�
	char* pContext = BrNULL;
	strtok_s(pBuf, seps1, &pContext);
	while(pBuf)
	{
		arrColorsData.Add(pBuf);
		pBuf = strtok_s(BrNULL, seps1, &pContext);
	}
	
	BrCHAR seps2[] = " ";
	//" "���� ��ū �и� �� �Ҽ��� ��Ÿ���� "f" ����
	for(BrINT32 i = 0; i < arrColorsData.size(); i++)
	{
		a_arrPosition.Add(strtok_s(arrColorsData.at(i), seps2, &pContext));
		a_arrColor.Add(strtok_s(BrNULL, seps2, &pContext));
		a_arrPosition.at(i) = strtok_s(a_arrPosition.at(i), "f", &pContext);
	}

	BR_SAFE_FREE(pBuf);
}

//////////////////////////////////////////////////////
CDocxDrawArrow::CDocxDrawArrow()
{
#ifdef XML_DOC_TYPE_DEF
	m_pStartArrow = BrNULL;
	m_pStartArrowWidth = BrNULL;
	m_pStartArrowLength = BrNULL;
	m_pEndArrow = BrNULL;
	m_pEndArrowWidth = BrNULL;
	m_pEndArrowLength = BrNULL;
#else
	memset(m_cStartArrow, 0, 10);
	memset(m_cStartArrowWidth, 0, 10);
	memset(m_cStartArrowLength, 0, 10);
	memset(m_cEndArrow, 0, 10);
	memset(m_cEndArrowWidth, 0, 10);
	memset(m_cEndArrowLength, 0, 10);
#endif
}
CDocxDrawArrow::~CDocxDrawArrow()
{
#ifdef XML_DOC_TYPE_DEF
	if(m_pStartArrow)		BR_SAFE_FREE(m_pStartArrow);
	if(m_pStartArrowWidth)	BR_SAFE_FREE(m_pStartArrowWidth);
	if(m_pStartArrowLength)	BR_SAFE_FREE(m_pStartArrowLength);
	if(m_pEndArrow)			BR_SAFE_FREE(m_pEndArrow);
	if(m_pEndArrowWidth)	BR_SAFE_FREE(m_pEndArrowWidth);
	if(m_pEndArrowLength)	BR_SAFE_FREE(m_pEndArrowLength);
#endif
}

void CDocxDrawArrow::convertArrow(BrGrapAtt *pGrapAtt, BrBOOL bFlipX /*= BrFALSE*/)
{
	if(!pGrapAtt )
		return;

	if(bFlipX)
	{
		if( m_pStartArrow ) {
			BrINT	nArrowStyle = getArrowStyle(m_pStartArrow);
			if( nArrowStyle > 0)
			{
				pGrapAtt->getPen()->setEndArrowType(nArrowStyle);
				pGrapAtt->getPen()->setEndArrowSizeIndex(getArrowSize(m_pStartArrowWidth, m_pStartArrowLength));
			}
		}

		if( m_pEndArrow)
		{
			BrINT	nArrowStyle = getArrowStyle(m_pEndArrow);
			if( nArrowStyle > 0)
			{
				pGrapAtt->getPen()->setStartArrowType(nArrowStyle);
				pGrapAtt->getPen()->setStartArrowSizeIndex(getArrowSize(m_pEndArrowWidth, m_pEndArrowLength));
			}
		}
	}
	else
	{
		if( m_pStartArrow ) {
			BrINT	nArrowStyle = getArrowStyle(m_pStartArrow);
			if( nArrowStyle > 0)
			{
				pGrapAtt->getPen()->setStartArrowType(nArrowStyle);
				pGrapAtt->getPen()->setStartArrowSizeIndex(getArrowSize(m_pStartArrowWidth, m_pStartArrowLength));
			}
		}

		if( m_pEndArrow)
		{
			BrINT	nArrowStyle = getArrowStyle(m_pEndArrow);
			if( nArrowStyle > 0)
			{
				pGrapAtt->getPen()->setEndArrowType(nArrowStyle);
				pGrapAtt->getPen()->setEndArrowSizeIndex(getArrowSize(m_pEndArrowWidth, m_pEndArrowLength));
			}
		}
	}
}

BrINT32 CDocxDrawArrow::getArrowSize(BrCHAR *pArrowWidth, BrCHAR *pArrowLength)
{
	BrINT32 nArrowSize = 5;
	if( !pArrowWidth)
		return nArrowSize;

	if( 0 == strcmp(pArrowWidth, "narrow" ) )
	{
		if( pArrowLength) {
			if( 0 == strcmp(pArrowLength, "short" ) )
				nArrowSize = 1;
			else if( 0 == strcmp(pArrowLength, "long" ) )
				nArrowSize = 3;
		}
		else
			nArrowSize = 2;

	}
	else if( 0 == strcmp(pArrowWidth, "wide" ) )
	{
		if( pArrowLength ) {
			if( 0 == strcmp(pArrowLength, "short" ) )
				nArrowSize = 7;
			else if( 0 == strcmp(pArrowLength, "long" ) )
				nArrowSize = 9;
		}
		else
			nArrowSize = 8;
	}
	else
	{
		if( pArrowLength) {
			if( 0 == strcmp(pArrowLength, "short" ) )
				nArrowSize = 4;
			else if( 0 == strcmp(pArrowLength, "long" ) )
				nArrowSize = 6;		
		}
		else
			nArrowSize = 5;
	}

	return nArrowSize;
}


BrINT32 CDocxDrawArrow::getArrowStyle(BrCHAR *pArrow)
{
	BrINT32 nArrowStyle = BMV_ARROWSTYLE_NOARROW;
	if( !pArrow)
		return nArrowStyle;

	if( 0 == strcmp(pArrow, "block" ) )
		nArrowStyle = BMV_ARROWSTYLE_COMMON;
	else if( 0 == strcmp(pArrow, "open" ) )
		nArrowStyle = BMV_ARROWSTYLE_OPEN;
	else if( 0 == strcmp(pArrow, "classic" ) )
		nArrowStyle = BMV_ARROWSTYLE_STEALTH;
	else if( 0 == strcmp(pArrow, "diamond" ) )
		nArrowStyle = BMV_ARROWSTYLE_DIAMOND;
	else if( 0 == strcmp(pArrow, "oval" ) )
		nArrowStyle = BMV_ARROWSTYLE_OVAL;

	return nArrowStyle;
}

//////////////////////////////////////////////////////
CDocxDrawStroke::CDocxDrawStroke(CDocxConv *pDocxConv)
{
	m_pDocxConv = pDocxConv;
#ifdef XML_DOC_TYPE_DEF
	m_pDashStyle = BrNULL;
	m_pLineStyle = BrNULL;
	m_pEndCap = BrNULL;
	m_pJoinStyle = BrNULL;
#else
	memset(m_cDashStyle, 0, 20);
	memset(m_cLineStyle, 0, 20);
	memset(m_cEndCap, 0, 20);
	memset(m_cJoinStyle, 0, 20);

	memcpy(m_cDashStyle, "solid", 5);	//default
	memcpy(m_cLineStyle, "single", 6);	//default
	memcpy(m_cEndCap, "flat", 4);	//default
	memcpy(m_cJoinStyle, "round", 5);	//default

#endif

	m_nStrokeWeight = 5;

	m_pArrow		= BrNULL;
	m_pStrokeColor	= BrNULL;
	m_pOpacity		= BrNULL;
}
CDocxDrawStroke::~CDocxDrawStroke()
{
	if(m_pStrokeColor)	BrFree(m_pStrokeColor);
	if(m_pOpacity)		BrFree(m_pOpacity);
	if( m_pArrow )		BrDELETE m_pArrow;
#ifdef XML_DOC_TYPE_DEF
	if(m_pDashStyle)	BR_SAFE_FREE(m_pDashStyle);
	if(m_pLineStyle)	BR_SAFE_FREE(m_pLineStyle);
	if(m_pEndCap)		BR_SAFE_FREE(m_pEndCap);
	if(m_pJoinStyle)	BR_SAFE_FREE(m_pJoinStyle);
#endif
}

BrBOOL CDocxDrawStroke::readStrokeInfo(XMLDataDecodeParam*  pChildNode)
{
	if( pChildNode->pElementData->pAttributePairs )
	{
		for( BrINT32 i = 0; pChildNode->pElementData->pAttributePairs[i]; i+= 2)
		{
			if( 0 == strcmp(pChildNode->pElementData->pAttributePairs[i], X_DOC_DRAW_STROKE_DASHSTYLE) )
			{
				BrINT32 nLen = BrStrLen(pChildNode->pElementData->pAttributePairs[i+1]);
#ifdef XML_DOC_TYPE_DEF
				EDTD_RESULT nRet = BrXMLDTDUtil::VMLDocTypeDefintion(eATTValueTypeString,eATTValueSubTypeString_StrokeDashStyle, pChildNode->pElementData->pAttributePairs[i], pChildNode->pElementData->pAttributePairs[i+1], m_pDocxConv);

				switch(nRet)
				{
				case DTD_SUCCESS:
					m_pDashStyle = (BrCHAR*)BrMalloc(nLen+1);
					memcpy(m_pDashStyle, pChildNode->pElementData->pAttributePairs[i+1], nLen );
					m_pDashStyle[nLen] = 0;	
					break;
				case DTD_NEED_DEFAULT_VALUE:
					nLen = 5;
					m_pDashStyle = (BrCHAR*)BrMalloc(nLen+1);
					memcpy(m_pDashStyle, "solid", nLen );
					m_pDashStyle[nLen] = 0;
					break;

				case DTD_FAIL:
				case DTD_IGNOREELEMENT:
					return BrFALSE;
				}


#else
				memcpy(m_cDashStyle, pChildNode->pElementData->pAttributePairs[i+1], nLen);
				m_cDashStyle[nLen] = 0;
#endif
			}
			else if( 0 == strcmp(pChildNode->pElementData->pAttributePairs[i], X_DOC_DRAW_STROKE_COLOR) )
			{
				BrINT32 nLen = BrStrLen(pChildNode->pElementData->pAttributePairs[i+1]);
#ifdef XML_DOC_TYPE_DEF
				EDTD_RESULT nRet = BrXMLDTDUtil::VMLDocTypeDefintion(eATTValueTypeString,eATTValueSubTypeString_ShapeFillColor2, pChildNode->pElementData->pAttributePairs[i], pChildNode->pElementData->pAttributePairs[i+1], m_pDocxConv);
				switch(nRet)
				{
				case DTD_SUCCESS:
					m_pStrokeColor = (BrCHAR*)BrMalloc(nLen+1);
					memcpy(m_pStrokeColor, pChildNode->pElementData->pAttributePairs[i+1], nLen );
					m_pStrokeColor[nLen] = 0;
					break;
				case DTD_NEED_DEFAULT_VALUE:
				case DTD_FAIL:
				case DTD_IGNOREELEMENT:
					return BrFALSE;
				}	
#else
				memcpy(m_cLineStyle, pChildNode->pElementData->pAttributePairs[i+1], nLen);
				m_cLineStyle[nLen] = 0;
#endif
			}
			else if( 0 == strcmp(pChildNode->pElementData->pAttributePairs[i], X_DOC_DRAW_STROKE_WEIGHT) )
			{
				if(pChildNode->pElementData->pAttributePairs[i+1])
				{
					const BrCHAR* pValue = pChildNode->pElementData->pAttributePairs[i+1];
					BrINT32 strLen = strlen(pValue);
					if(strstr(pValue, "pt"))
					{
						m_nStrokeWeight = CDocxUtil::PTtoTWIPDocx(BrAtof(pChildNode->pElementData->pAttributePairs[i+1]) );
					}
					else if(strstr(pValue, "mm"))
					{
						m_nStrokeWeight = MMtoTWIP(BrAtof(pChildNode->pElementData->pAttributePairs[i+1]) );
					}
					else
						m_nStrokeWeight = CDocxUtil::MSEMUtoTWIP(BrAtof(pChildNode->pElementData->pAttributePairs[i+1]) );
					
				}
				
			}
			else if( 0 == strcmp(pChildNode->pElementData->pAttributePairs[i], X_DOC_DRAW_STROKE_LINESTYLE) )
			{
				BrINT32 nLen = BrStrLen(pChildNode->pElementData->pAttributePairs[i+1]);
#ifdef XML_DOC_TYPE_DEF
				EDTD_RESULT nRet = BrXMLDTDUtil::VMLDocTypeDefintion(eATTValueTypeString,eATTValueSubTypeString_StrokeLineStyle, pChildNode->pElementData->pAttributePairs[i], pChildNode->pElementData->pAttributePairs[i+1], m_pDocxConv);
				switch(nRet)
				{
				case DTD_SUCCESS:
					m_pLineStyle = (BrCHAR*)BrMalloc(nLen+1);
					memcpy(m_pLineStyle, pChildNode->pElementData->pAttributePairs[i+1], nLen );
					m_pLineStyle[nLen] = 0;
					break;
				case DTD_NEED_DEFAULT_VALUE:
					nLen = 6;
					m_pLineStyle = (BrCHAR*)BrMalloc(nLen+1);
					memcpy(m_pLineStyle, "single", nLen );
					m_pLineStyle[nLen] = 0;
					break;

				case DTD_FAIL:
				case DTD_IGNOREELEMENT:
					return BrFALSE;
				}				
#else
				memcpy(m_cLineStyle, pChildNode->pElementData->pAttributePairs[i+1], nLen);
				m_cLineStyle[nLen] = 0;
#endif
			}
			else if( 0 == strcmp(pChildNode->pElementData->pAttributePairs[i], X_DOC_DRAW_STROKE_ENDCAP) )
			{
				BrINT32 nLen = BrStrLen(pChildNode->pElementData->pAttributePairs[i+1]);
#ifdef XML_DOC_TYPE_DEF
				EDTD_RESULT nRet = BrXMLDTDUtil::VMLDocTypeDefintion(eATTValueTypeString,eATTValueSubTypeString_StrokeEndCap, pChildNode->pElementData->pAttributePairs[i], pChildNode->pElementData->pAttributePairs[i+1], m_pDocxConv);
				switch(nRet)
				{
				case DTD_SUCCESS:
					m_pEndCap = (BrCHAR*)BrMalloc(nLen+1);
					memcpy(m_pEndCap, pChildNode->pElementData->pAttributePairs[i+1], nLen );
					m_pEndCap[nLen] = 0;
					break;
				case DTD_NEED_DEFAULT_VALUE:
					nLen = 4;
					m_pEndCap = (BrCHAR*)BrMalloc(nLen+1);
					memcpy(m_pEndCap, "flat", nLen );
					m_pEndCap[nLen] = 0;
					break;

				case DTD_FAIL:
				case DTD_IGNOREELEMENT:
					return BrFALSE;
				}				
#else
				memcpy(m_cEndCap, pChildNode->pElementData->pAttributePairs[i+1], nLen);
				m_cEndCap[nLen] = 0;
#endif
			}
			else if( 0 == strcmp(pChildNode->pElementData->pAttributePairs[i], X_DOC_DRAW_STROKE_JOINSTYLE) )
			{
				BrINT32 nLen = BrStrLen(pChildNode->pElementData->pAttributePairs[i+1]);
#ifdef XML_DOC_TYPE_DEF
				EDTD_RESULT nRet = BrXMLDTDUtil::VMLDocTypeDefintion(eATTValueTypeString,eATTValueSubTypeString_StrokeJoinStyle, pChildNode->pElementData->pAttributePairs[i], pChildNode->pElementData->pAttributePairs[i+1], m_pDocxConv);
				switch(nRet)
				{
				case DTD_SUCCESS:
					m_pJoinStyle = (BrCHAR*)BrMalloc(nLen+1);
					memcpy(m_pJoinStyle, pChildNode->pElementData->pAttributePairs[i+1], nLen );
					m_pJoinStyle[nLen] = 0;
					break;
				case DTD_NEED_DEFAULT_VALUE:
					nLen = 5;
					m_pJoinStyle = (BrCHAR*)BrMalloc(nLen+1);
					memcpy(m_pJoinStyle, "round", nLen );
					m_pJoinStyle[nLen] = 0;
					break;

				case DTD_FAIL:
				case DTD_IGNOREELEMENT:
					return BrFALSE;
				}				
#else

				memcpy(m_cJoinStyle, pChildNode->pElementData->pAttributePairs[i+1], nLen);
				m_cJoinStyle[nLen] = 0;
#endif
			}
			else if( 0 == strcmp(pChildNode->pElementData->pAttributePairs[i], X_DOC_DRAW_STROKE_STARTARROW) )
			{
				if( NULL == m_pArrow )
					m_pArrow = BrNEW CDocxDrawArrow();

				BrINT32 nLen = BrStrLen(pChildNode->pElementData->pAttributePairs[i+1]);
#ifdef XML_DOC_TYPE_DEF
				EDTD_RESULT nRet = BrXMLDTDUtil::VMLDocTypeDefintion(eATTValueTypeString,eATTValueSubTypeString_StrokeArrow, pChildNode->pElementData->pAttributePairs[i], pChildNode->pElementData->pAttributePairs[i+1], m_pDocxConv);

				switch(nRet)
				{
				case DTD_SUCCESS:
					m_pArrow->m_pStartArrow = (BrCHAR*)BrMalloc(nLen+1);
					memcpy(m_pArrow->m_pStartArrow, pChildNode->pElementData->pAttributePairs[i+1], nLen);
					m_pArrow->m_pStartArrow[nLen] = 0;
					break;
				case DTD_NEED_DEFAULT_VALUE:
					break;
				case DTD_FAIL:
				case DTD_IGNOREELEMENT:
					return BrFALSE;
				}
#else
				memcpy(m_pArrow->m_cStartArrow, pChildNode->pElementData->pAttributePairs[i+1], nLen);
				m_pArrow->m_cStartArrow[nLen] = 0;
#endif
			}
			else if( 0 == strcmp(pChildNode->pElementData->pAttributePairs[i], X_DOC_DRAW_STROKE_STARTARROWWIDTH) )
			{
				if( NULL == m_pArrow )
					m_pArrow = BrNEW CDocxDrawArrow();

				BrINT32 nLen = BrStrLen(pChildNode->pElementData->pAttributePairs[i+1]);
#ifdef XML_DOC_TYPE_DEF
				EDTD_RESULT nRet = BrXMLDTDUtil::VMLDocTypeDefintion(eATTValueTypeString,eATTValueSubTypeString_StrokeArrowWidth, pChildNode->pElementData->pAttributePairs[i], pChildNode->pElementData->pAttributePairs[i+1], m_pDocxConv);

				switch(nRet)
				{
				case DTD_SUCCESS:
					m_pArrow->m_pStartArrowWidth = (BrCHAR*)BrMalloc(nLen+1);
					memcpy(m_pArrow->m_pStartArrowWidth, pChildNode->pElementData->pAttributePairs[i+1], nLen);
					m_pArrow->m_pStartArrowWidth[nLen] = 0;
					break;
				case DTD_NEED_DEFAULT_VALUE:
					break;
				case DTD_FAIL:
				case DTD_IGNOREELEMENT:
					return BrFALSE;
				}
#else
				memcpy(m_pArrow->m_cStartArrowWidth, pChildNode->pElementData->pAttributePairs[i+1], nLen);
				m_pArrow->m_cStartArrowWidth[nLen] = 0;
#endif
			}
			else if( 0 == strcmp(pChildNode->pElementData->pAttributePairs[i], X_DOC_DRAW_STROKE_STARTARROWLENGTH) )
			{
				if( NULL == m_pArrow )
					m_pArrow = BrNEW CDocxDrawArrow();

				BrINT32 nLen = BrStrLen(pChildNode->pElementData->pAttributePairs[i+1]);
#ifdef XML_DOC_TYPE_DEF
				EDTD_RESULT nRet = BrXMLDTDUtil::VMLDocTypeDefintion(eATTValueTypeString,eATTValueSubTypeString_StrokeArrowLength, pChildNode->pElementData->pAttributePairs[i], pChildNode->pElementData->pAttributePairs[i+1], m_pDocxConv);

				switch(nRet)
				{
				case DTD_SUCCESS:
					m_pArrow->m_pStartArrowLength = (BrCHAR*)BrMalloc(nLen+1);
					memcpy(m_pArrow->m_pStartArrowLength, pChildNode->pElementData->pAttributePairs[i+1], nLen);
					m_pArrow->m_pStartArrowLength[nLen] = 0;
					break;
				case DTD_NEED_DEFAULT_VALUE:
					break;
				case DTD_FAIL:
				case DTD_IGNOREELEMENT:
					return BrFALSE;
				}
#else
				memcpy(m_pArrow->m_cStartArrowLength, pChildNode->pElementData->pAttributePairs[i+1], nLen);
				m_pArrow->m_cStartArrowLength[nLen] = 0;
#endif
			}
			else if( 0 == strcmp(pChildNode->pElementData->pAttributePairs[i], X_DOC_DRAW_STROKE_ENDARROW) )
			{
				if( NULL == m_pArrow )
					m_pArrow = BrNEW CDocxDrawArrow();

				BrINT32 nLen = BrStrLen(pChildNode->pElementData->pAttributePairs[i+1]);
#ifdef XML_DOC_TYPE_DEF
				EDTD_RESULT nRet = BrXMLDTDUtil::VMLDocTypeDefintion(eATTValueTypeString,eATTValueSubTypeString_StrokeArrow, pChildNode->pElementData->pAttributePairs[i], pChildNode->pElementData->pAttributePairs[i+1], m_pDocxConv);

				switch(nRet)
				{
				case DTD_SUCCESS:
					m_pArrow->m_pEndArrow = (BrCHAR*)BrMalloc(nLen+1);
					memcpy(m_pArrow->m_pEndArrow, pChildNode->pElementData->pAttributePairs[i+1], nLen);
					m_pArrow->m_pEndArrow[nLen] = 0;
					break;
				case DTD_NEED_DEFAULT_VALUE:
					break;
				case DTD_FAIL:
				case DTD_IGNOREELEMENT:
					return BrFALSE;
				}
#else
				memcpy(m_pArrow->m_cEndArrow, pChildNode->pElementData->pAttributePairs[i+1], nLen);
				m_pArrow->m_cEndArrow[nLen] = 0;
#endif				
			}
			else if( 0 == strcmp(pChildNode->pElementData->pAttributePairs[i], X_DOC_DRAW_STROKE_ENDARROWWIDTH) )
			{
				if( NULL == m_pArrow )
					m_pArrow = BrNEW CDocxDrawArrow();

				BrINT32 nLen = BrStrLen(pChildNode->pElementData->pAttributePairs[i+1]);
#ifdef XML_DOC_TYPE_DEF
				EDTD_RESULT nRet = BrXMLDTDUtil::VMLDocTypeDefintion(eATTValueTypeString,eATTValueSubTypeString_StrokeArrowWidth, pChildNode->pElementData->pAttributePairs[i], pChildNode->pElementData->pAttributePairs[i+1], m_pDocxConv);

				switch(nRet)
				{
				case DTD_SUCCESS:
					m_pArrow->m_pEndArrowWidth = (BrCHAR*)BrMalloc(nLen+1);
					memcpy(m_pArrow->m_pEndArrowWidth, pChildNode->pElementData->pAttributePairs[i+1], nLen);
					m_pArrow->m_pEndArrowWidth[nLen] = 0;
					break;
				case DTD_NEED_DEFAULT_VALUE:
					break;
				case DTD_FAIL:
				case DTD_IGNOREELEMENT:
					return BrFALSE;
				}
#else
				memcpy(m_pArrow->m_cEndArrowWidth, pChildNode->pElementData->pAttributePairs[i+1], nLen);
				m_pArrow->m_cEndArrowWidth[nLen] = 0;
#endif
			}
			else if( 0 == strcmp(pChildNode->pElementData->pAttributePairs[i], X_DOC_DRAW_STROKE_ENDARROWLENGTH) )
			{
				if( NULL == m_pArrow )
					m_pArrow = BrNEW CDocxDrawArrow();

				BrINT32 nLen = BrStrLen(pChildNode->pElementData->pAttributePairs[i+1]);
#ifdef XML_DOC_TYPE_DEF
				EDTD_RESULT nRet = BrXMLDTDUtil::VMLDocTypeDefintion(eATTValueTypeString,eATTValueSubTypeString_StrokeArrowLength, pChildNode->pElementData->pAttributePairs[i], pChildNode->pElementData->pAttributePairs[i+1], m_pDocxConv);

				switch(nRet)
				{
				case DTD_SUCCESS:
					m_pArrow->m_pEndArrowLength = (BrCHAR*)BrMalloc(nLen+1);
					memcpy(m_pArrow->m_pEndArrowLength, pChildNode->pElementData->pAttributePairs[i+1], nLen);
					m_pArrow->m_pEndArrowLength[nLen] = 0;
					break;
				case DTD_NEED_DEFAULT_VALUE:
					break;
				case DTD_FAIL:
				case DTD_IGNOREELEMENT:
					return BrFALSE;
				}
#else
				memcpy(m_pArrow->m_cEndArrowLength, pChildNode->pElementData->pAttributePairs[i+1], nLen);
				m_pArrow->m_cEndArrowLength[nLen] = 0;
#endif
			}
			//[TID:5032] FreeDraw���� �׷��� Ellipse/Polygon�� ������ ���� �� ������ �̻� ����
			else if( 0 == strcmp(pChildNode->pElementData->pAttributePairs[i], X_DOC_DRAW_STROKE_OPACITY) )
			{
				BrINT32 nLen = BrStrLen(pChildNode->pElementData->pAttributePairs[i+1]);
				m_pOpacity = (BrCHAR*)BrMalloc(nLen+1);
				memcpy(m_pOpacity, pChildNode->pElementData->pAttributePairs[i+1], nLen);
				m_pOpacity[nLen] = 0;
			}
		}
	}

	return BrTRUE;
}

//////////////////////////////////////////////////////WordArt
CDocxDrawShadow::CDocxDrawShadow(CDocxConv *pDocxConv)
{
	m_pDocxConv = pDocxConv;
#ifdef XML_DOC_TYPE_DEF
	m_pType = BrNULL;
	m_pColor = BrNULL;
#else
	memset(m_pType, 0, 20);
	memset(m_cColor, 0, 50);
#endif
	m_pOffset = BrNULL;	
	m_pOffset2 = BrNULL;	
	m_pMatrix = BrNULL;
	m_pOrigin = BrNULL;
	m_pOpacity = BrNULL;	
	m_bShadow = BrFALSE;	
}

CDocxDrawShadow::~CDocxDrawShadow()
{
	if( m_pOffset )		BR_SAFE_FREE(m_pOffset);
	if( m_pOffset2 )	BR_SAFE_FREE(m_pOffset2);
	if( m_pMatrix )		BR_SAFE_FREE(m_pMatrix);
	if( m_pOrigin )		BR_SAFE_FREE(m_pOrigin);
	if( m_pOpacity )	BR_SAFE_FREE(m_pOpacity);
#ifdef XML_DOC_TYPE_DEF
	if(m_pType)			BR_SAFE_FREE(m_pType);
	if(m_pColor)		BR_SAFE_FREE(m_pColor);
#endif
}

BrBOOL CDocxDrawShadow::readShadowInfo(XMLDataDecodeParam*  pInfo)
{
	if( pInfo->pElementData->pAttributePairs )
	{
		for( BrINT32 i = 0; pInfo->pElementData->pAttributePairs[i]; i+=2)
		{
			const BrCHAR *pStr = pInfo->pElementData->pAttributePairs[i];
			if( 0 == strcmp(pStr, X_DOC_DRAW_SHADOW_TYPE) )
			{
				BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
#ifdef XML_DOC_TYPE_DEF
				EDTD_RESULT nRet = BrXMLDTDUtil::VMLDocTypeDefintion(eATTValueTypeString,eATTValueSubTypeString_ShadowType, pStr, pInfo->pElementData->pAttributePairs[i+1],m_pDocxConv);
				switch(nRet)
				{
				case DTD_SUCCESS:
					m_pType = (BrCHAR*)BrMalloc(nLen+1);
					memcpy(m_pType, pInfo->pElementData->pAttributePairs[i+1], nLen );
					m_pType[nLen] = 0;
					break;
				case DTD_NEED_DEFAULT_VALUE:
					break;
				case DTD_FAIL:
				case DTD_IGNOREELEMENT:
					return BrFALSE;
				}
#else
				memcpy(m_pType, pInfo->pElementData->pAttributePairs[i+1], nLen );
				m_pType[nLen] = 0;								
#endif
			}
			else if( 0 == strcmp(pStr, X_DOC_DRAW_SHADOW_COLOR) )
			{
				BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
#ifdef XML_DOC_TYPE_DEF
				EDTD_RESULT nRet = BrXMLDTDUtil::VMLDocTypeDefintion(eATTValueTypeString,eATTValueSubTypeString_ShadowColor, pStr, pInfo->pElementData->pAttributePairs[i+1],m_pDocxConv);
				switch(nRet)
				{
				case DTD_SUCCESS:
					m_pColor = (BrCHAR*)BrMalloc(nLen+1);
					memcpy(m_pColor, pInfo->pElementData->pAttributePairs[i+1], nLen );
					m_pColor[nLen] = 0;
					break;
				case DTD_NEED_DEFAULT_VALUE:
					break;
				case DTD_FAIL:
				case DTD_IGNOREELEMENT:
					return BrFALSE;
				}				
#else
				memcpy(m_cColor, pInfo->pElementData->pAttributePairs[i+1], nLen );
				m_cColor[nLen] = 0;
#endif
			}
			else if( 0 == strcmp(pStr, X_DOC_DRAW_SHADOW_OPACITY) )
			{
				BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
				m_pOpacity = (BrCHAR*)BrMalloc(nLen+1);
				memcpy(m_pOpacity, pInfo->pElementData->pAttributePairs[i+1], nLen);
				m_pOpacity[nLen] = 0;

			}
			else if( 0 == strcmp(pStr, X_DOC_DRAW_SHADOW_ORIGIN) )
			{
				BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
				m_pOrigin = (BrCHAR*)BrMalloc(nLen+1);
				memcpy(m_pOrigin, pInfo->pElementData->pAttributePairs[i+1], nLen);
				m_pOrigin[nLen] = 0;
			}
			else if( 0 == strcmp(pStr, X_DOC_DRAW_SHADOW_OFFSET) )
			{
				BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
				m_pOffset = (BrCHAR*)BrMalloc(nLen+1);
				memcpy(m_pOffset, pInfo->pElementData->pAttributePairs[i+1], nLen);
				m_pOffset[nLen] = 0;
			}
			else if( 0 == strcmp(pStr, X_DOC_DRAW_SHADOW_OFFSET2) )
			{
				BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
				m_pOffset2 = (BrCHAR*)BrMalloc(nLen+1);
				memcpy(m_pOffset2, pInfo->pElementData->pAttributePairs[i+1], nLen);
				m_pOffset2[nLen] = 0;
			}
			else if( 0 == strcmp(pStr, X_DOC_DRAW_SHADOW_MATRIX) )
			{
				BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
				m_pMatrix = (BrCHAR*)BrMalloc(nLen+1);
				memcpy(m_pMatrix, pInfo->pElementData->pAttributePairs[i+1], nLen);
				m_pMatrix[nLen] = 0;
			}	
			else if( 0 == strcmp(pStr, X_DOC_DRAW_ON) )	//MistY - 2008.12.11
			{
				if(0 == strcmp(pInfo->pElementData->pAttributePairs[i+1],"t"))
					m_bShadow = BrTRUE;				
			}
		}
	}

	return BrTRUE;
}

void CDocxDrawShadow::convertShadowInfo(CDocxDrawStyle* pDocxStyle, BrGrapAtt* pGrapAtt, BrBOOL bWordArt )
{//MistY - 2008.12.11
	//hnsong 2011.01.20
	//hnsong 2011.09.16
	if(!pGrapAtt)
		return;

	BString pStr ="";
	BrINT32 nSepsPos = -1 ;
	BrCHAR seps[]   = ",";
	BrCHAR *pBuf = "";

	BrShadowObj *pShadow = pGrapAtt->getShadow();
	pShadow->setBackColor(0xbebebe);
	if(m_pType)	
	{
		if( 0 == strcmp(m_pType, _T("single")) )
			pShadow->setShadowType(msoshadowOffset);
		else if( 0 == strcmp(m_pType, _T("double")) )
			pShadow->setShadowType(msoshadowDouble);
		else if( 0 == strcmp(m_pType, _T("perspective")) )
			pShadow->setShadowType(msoshadowRich);
		else if( 0 == strcmp(m_pType, _T("shaperelative")) )
			pShadow->setShadowType(msoshadowShape);
		else if( 0 == strcmp(m_pType, _T("drawingrelative")) )
			pShadow->setShadowType(msoshadowDrawing);
		else if( 0 == strcmp(m_pType, _T("emboss")) )
			pShadow->setShadowType(msoshadowEmbossOrEngrave);
		else
			pShadow->setShadowType(msoshadowOffset);
	}
	else
		pShadow->setShadowType(msoshadowOffset);

	if(m_pColor)	
		pShadow->setForeColor((BrCOLORREF) CUtil::getColor(m_pColor) ); 
	else
		pShadow->setForeColor(BrRGB(128,128,128));

	//[2012.02.20][TID : 4293][���ؼ�] �׸��� ������ ���� ���� ����
	if(m_pOpacity)
	{
		BrINT nOpacity = 0;
		if( BrNULL != strstr(m_pOpacity, "f") )
		{
			nOpacity = BrAtoi(m_pOpacity);	
			nOpacity = (BrINT)(BrFRound((BrFLOAT)(nOpacity / 65536.0 * 255)));
		}
		else
		{
			nOpacity = (BrINT)(BrFRound((BrFLOAT)(BrAtof(m_pOpacity) * 255)));
		}

		pShadow->setTransparent(nOpacity);
	}
	else
		pShadow->setTransparent(0xff);

	if( bWordArt ) {
		pShadow->setOffsetX1(0);
		pShadow->setOffsetY1(0);
	}

	if(m_pOffset)	
	{		
		nSepsPos = BrStrCpn(m_pOffset,seps);
		char* pContext = BrNULL;
		if(nSepsPos== 0 && nSepsPos < (BrINT32) BrStrLen(m_pOffset))
		{
			pShadow->setOffsetX1(0);			
			pBuf = strtok_s(m_pOffset,seps, &pContext);										
			if(pBuf)															
				pShadow->setOffsetY1(convertUnitValue(pBuf , pDocxStyle->m_nHeight));					
		}
		else if(nSepsPos > 0 && nSepsPos <  (BrINT32)BrStrLen(m_pOffset))		
		{
			pBuf = strtok_s(m_pOffset,seps, &pContext);										
			if(pBuf)															
				pShadow->setOffsetX1(convertUnitValue(pBuf, pDocxStyle->m_nWidth));											
			pBuf = strtok_s(NULL,seps, &pContext);											
			if(pBuf)
				pShadow->setOffsetY1(convertUnitValue(pBuf, pDocxStyle->m_nHeight));				
		}
		else
			pShadow->setOffsetX(convertUnitValue(m_pOffset, pDocxStyle->m_nWidth));								
	}
	else
	{
		pShadow->setOffsetX1(40); //default 2pt
		pShadow->setOffsetY1(40);
	}


	if(m_pOffset2)	
	{
		nSepsPos = BrStrCpn(m_pOffset2,seps);
	 	char* pContext = BrNULL;
		if(nSepsPos== 0 && nSepsPos < (int) BrStrLen(m_pOffset2))
		{
			pShadow->setOffsetX2(0);
			pBuf = strtok_s(m_pOffset2,seps, &pContext);										
			if(pBuf)															
				pShadow->setOffsetY2(convertUnitValue(pBuf));	
		}
		else if(nSepsPos> 0 && nSepsPos < (int) BrStrLen(m_pOffset2))		
		{
			pBuf = strtok_s(m_pOffset2,seps, &pContext);										
			if(pBuf)															
				pShadow->setOffsetX2(convertUnitValue(pBuf));				
			pBuf = strtok_s(NULL,seps, &pContext);
			if(pBuf)
				pShadow->setOffsetY2(convertUnitValue(pBuf));
		}
		else
			pShadow->setOffsetX2(convertUnitValue(m_pOffset2));					
	}
	else
	{
		pShadow->setOffsetX2(-40); //default -2pt
		pShadow->setOffsetY2(-40);
	}

	if(m_pMatrix)
		convertShadowMatrixInfo(pGrapAtt, bWordArt);			

	if(m_pOrigin)
	{
		nSepsPos = BrStrCpn(m_pOrigin,seps);
		char* pContext = BrNULL;
		if(nSepsPos== 0 && nSepsPos < (int) BrStrLen(m_pOrigin))
		{
			pShadow->setOriginX(0);
			pBuf = strtok_s(m_pOrigin,seps, &pContext);
			if(pBuf)															
				pShadow->setOriginY(convertUnitValue(pBuf, pDocxStyle->m_nHeight));						
		}
		else if(nSepsPos> 0 && nSepsPos < (int) BrStrLen(m_pOrigin))		
		{
			pBuf = strtok_s(m_pOrigin,seps, &pContext);
			if(pBuf)															
				pShadow->setOriginX(convertUnitValue(pBuf, pDocxStyle->m_nWidth));				
			pBuf = strtok_s(NULL,seps, &pContext);
			if(pBuf)
				pShadow->setOriginY(convertUnitValue(pBuf, pDocxStyle->m_nHeight));
		}
		else
			pShadow->setOriginX( convertUnitValue(m_pOrigin , pDocxStyle->m_nWidth));							
	}
}

void CDocxDrawShadow::convertShadowMatrixInfo(BrGrapAtt *pGrapAtt, BrBOOL bWordArt)
{
	BrShadowObj *pShadow = pGrapAtt->getShadow();	

	//vml �׸��� ��Ÿ��17�� import�ÿ� �ٸ� �׸��ڵ�� matrix����� �޸�, �ٸ� ������ Ȯ�εɶ����� ������ �� ����
	//[2012-05-02][toypilot]
	if(0 == strcmp(",,,-1",m_pMatrix))
	{
		pShadow->setScaleX2X(0);
		pShadow->setScaleY2X(0);
		pShadow->setScaleX2Y(0);
		pShadow->setScaleY2Y(-164125);
		return;
	}

	BrBOOL bInch = BrFALSE;
	const BrCHAR *strShadowMatrix = m_pMatrix;

	BrINT32 nTotal = BrStrLen(strShadowMatrix);
	BrCHAR *pCh = (BrCHAR*)BrMalloc(nTotal + 1); 
	BrINT32 nLen = 0;
	BrINT32 nPosCount = 0;
	BrDOUBLE nValue = 0;

	BrINT32 nPos = BrStrCpn(strShadowMatrix, ",");	
	memcpy(pCh, strShadowMatrix, nPos);
	pCh[nPos] = 0;

	while(nLen < nTotal)
	{
		switch(nPosCount )
		{
		case	0:
			pShadow->setScaleX2X(convertUnitValue(pCh));
			break;

		case	1:
			pShadow->setScaleY2X(convertUnitValue(pCh));
			break;

		case	2:
			pShadow->setScaleX2Y(convertUnitValue(pCh));
			break;

		case	3:
			pShadow->setScaleY2Y(convertUnitValue(pCh));
			break;

		case	4:
			pShadow->setPerspectiveX(convertUnitValue(pCh, 0, BrTRUE));
			break;

		case	5:
			pShadow->setPerspectiveY(convertUnitValue (pCh, 0, BrTRUE));
			break;							
		}

		strShadowMatrix += (nPos+1);	nLen += (nPos+1);

		if( nLen > nTotal )
			break;

		nPos = BrStrCpn(strShadowMatrix, ",");

		if( nPos > nTotal )
			nPos = nTotal;

		memcpy(pCh, strShadowMatrix, nPos);
		pCh[nPos] = 0;
		nPosCount++;
	}

	BrFree(pCh); 
}

BrLONG CDocxDrawShadow::convertUnitValue(BrCHAR *strValue ,BrINT32 nValue, BrBOOL bPerspective)
{
	BrDOUBLE dChgValue = 0;
	BrLONG   lRetValue = 0;

	if(!strValue)				
		return lRetValue;

	BrINT32 nLen = BrStrLen(strValue);
	BrCHAR *nptr = (BrCHAR*)BrMalloc(nLen+BrSizeOf(BrCHAR));
	BrCHAR *endptr;

	BrINT32 nPtPos = BrStrCpn(strValue,"pt");
	BrINT32 nFloatPos = BrStrCpn(strValue,"f");
	BrINT32 nPerPos = BrStrCpn(strValue,"%");
	BrINT32 nDatPos =	BrStrCpn(strValue,"\\.");
	BrINT32 nDoublePos =	BrStrCpn(strValue,"e");

	if(nPtPos > 0 && nPtPos < nLen) {
		dChgValue = BrAtof(strValue) * 20;
	}
	else if(nPerPos > 0 && nPerPos < nLen) {
		dChgValue = BrAtof(strValue)/100 * nValue;
	}
	else if(*strValue) {
		memcpy(nptr,strValue,nLen);
		nptr[nLen] = 0;

		dChgValue = strtod(nptr,&endptr);
	}
	else {
		dChgValue = BrAtof(strValue);		
	}


	if(nDatPos >= 0 && nDatPos < nLen)
		lRetValue = (BrLONG)BrMulDivDouble( 65536 * dChgValue , 1440, 575) ;
	else if(nPtPos >= nLen) {
		if( bPerspective ) {
			lRetValue = (BrLONG)BrMulDivDouble( 65536 * dChgValue, 914400, 1440) ;
		}
		else
			lRetValue = (BrLONG)BrMulDivDouble( dChgValue, 1440, 575) ;
	}
	else 
		lRetValue = (BrLONG)dChgValue;

	BrFree(nptr);
	return lRetValue;
}



//////////////////////////////////////////////////////////////////////////////////////////////////////////
CDocxDrawTextPath::CDocxDrawTextPath()
{	
	m_pStyle  = BrNULL;
	m_pString = BrNULL;	
}

CDocxDrawTextPath::~CDocxDrawTextPath()
{
	if( m_pString ) BR_SAFE_FREE(m_pString);
}

BrBOOL CDocxDrawTextPath::readTextPathInfo(XMLDataDecodeParam*  pInfo)
{
	if( pInfo->pElementData->pAttributePairs )
	{
		for( BrINT32 i = 0; pInfo->pElementData->pAttributePairs[i]; i+=2)
		{
			const BrCHAR *pStr = pInfo->pElementData->pAttributePairs[i];

			//[2013.07.11][������] WaterMark���� TexPath Style
			if( 0 == strcmp(pStr, X_DOC_DRAW_STYLE) )
			{
				BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
				m_pStyle = (BrCHAR*)BrMalloc(nLen+1);
				memcpy(m_pStyle, pInfo->pElementData->pAttributePairs[i+1], nLen);
				m_pStyle[nLen] = 0;
			}
			else if( 0 == strcmp(pStr, X_DOC_DRAW_TEXTPATH_STRING) )
			{
				BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
				if(nLen > PO_WORDARTSTR_MAXSIZE)
				{
					m_pString = (BrCHAR*)BrMalloc(PO_WORDARTSTR_MAXSIZE + 1);
					memset(m_pString, 0 , PO_WORDARTSTR_MAXSIZE + 1);
					memcpy(m_pString, pInfo->pElementData->pAttributePairs[i+1], PO_WORDARTSTR_MAXSIZE);
				}
				else
				{
					m_pString = (BrCHAR*)BrMalloc(nLen+1);
					memset(m_pString, 0 , nLen + 1);
					memcpy(m_pString, pInfo->pElementData->pAttributePairs[i+1], nLen);
				}
			}
		}
	}

	return BrTRUE;
}
///////////////////////////////////////////////////////////////////
//#define EQUATION_TRACE
CDocxFormulaArray::CDocxFormulaArray()
{

}
CDocxFormulaArray::~CDocxFormulaArray()
{

}
void	CDocxFormulaArray::setShapeGeoEquation(BrShape* pSh)
{
	if(!pSh )
		return;

	BrShapeProperty sPro;	

	BrUINT32 nEqSize = 0;
	BrBOOL bFirst = BrTRUE;
	BArray<BrShapeEquation>* pEquations = BrNULL;

	for(BrUINT32 i = 0;i<(BrUINT32)size();i++)
	{
		if(bFirst)
		{
			pEquations = BrNEW BArray<BrShapeEquation>;
			bFirst = BrFALSE;
		}
		else
			nEqSize = pEquations->size();
		pEquations->resize(nEqSize+1);

		BrShapeEquation* pEqu = pEquations->GetAt(nEqSize);
		FormulasValue* pFmla = GetAt(i);

		//equation flag
		pEqu->nFlags = GetEquationFlag(pFmla->Flag);

		//equation para 
		if(GetEquationPara(pEqu->nVal1, pFmla->Val1) == eShapeEquationVertex)
			pEqu->nFlags |= 0x2000; 
		if(GetEquationPara(pEqu->nVal2, pFmla->Val2) == eShapeEquationVertex)
			pEqu->nFlags |= 0x4000;
		if(GetEquationPara(pEqu->nVal3, pFmla->Val3) == eShapeEquationVertex)
			pEqu->nFlags |= 0x8000;

#ifdef EQUATION_TRACE
		{
			BrTrace("Equation Code [%d]: %d %d %d %d", i,pEqu->nFlags, pEqu->nVal1,pEqu->nVal2,pEqu->nVal3);			
		}
#endif //EQUATION_TRACE	
	}

	sPro.nType = eShapeEquations;
	sPro.pPro = pEquations;

	pSh->getGeometryAttrs().Add(sPro);
}

BrUINT16 CDocxFormulaArray::GetEquationFlag(BrCHAR * pFlagEquToken)
{
	BrUINT16 nFlag = 0;

	switch(*pFlagEquToken)
	{
	case 'a' :
		{
			*pFlagEquToken++;
			if( *pFlagEquToken == 'b' )				//abs
				nFlag = 3;
			else if( *pFlagEquToken == 't' )		//'atan2'
				nFlag = 18;	
		}
		break;

	case 'c' :
		{
			*pFlagEquToken++;
			if( *pFlagEquToken == 'o' )	
			{
				*pFlagEquToken++;
				if(*(++pFlagEquToken))				//'costan2' 
					nFlag = 11;
				else
					nFlag = 21;						//cos//21,10
			}						
		}
		break;

	case 'i' :										//? :
		{
			*pFlagEquToken++;
			if( *pFlagEquToken == 'f' )				//if
				nFlag = 6;	
		}
		break;		

	case 'm' :
		{
			*pFlagEquToken++;
			if( *pFlagEquToken == 'a' )				//max
				nFlag = 5;
			else if( *pFlagEquToken == 'i' )
			{
				*pFlagEquToken++;
				if( *pFlagEquToken == 'd' )			//mid	//+	/
					nFlag = 17;
				else if( *pFlagEquToken == 'n' )	//min
					nFlag = 4;
			}
			else if( *pFlagEquToken == 'o' )		//mod
				nFlag = 7;
		}
		break;

	case 'p' :	nFlag = 1;	break;					//prod, product

	case 's' :
		{
			*pFlagEquToken++;
			if( *pFlagEquToken == 'i' )				
			{
				*pFlagEquToken++;
				if(*(++pFlagEquToken))				//'sinatan2' 
					nFlag = 12;				
				else
					nFlag = 19;						//sin//19//9
				break;	
			}
			else if( *pFlagEquToken == 'u' )		
			{
				*pFlagEquToken++;					
				if(*(++pFlagEquToken))
					nFlag = 23;						//sumangle
				else
					nFlag = 0;						//sum	//+ -
			}					
			else if( *pFlagEquToken == 'q' )		//sqrt
				nFlag = 13;
		}
		break;						

	case 't' :	nFlag = 16;	break;					//tan

		//case 'val' :				break;

		//case 'ellipse' :			break;

	default :
		break;
	}
	return nFlag;
}

BrINT32 CDocxFormulaArray::GetEquationPara(BrINT32 & nPara, BrCHAR* pFlagEquToken)
{
	BrINT16 nCoordType = CDocxUtil::GetVtxTokenType(pFlagEquToken);

	switch(nCoordType)
	{
	case 1 :	//#	adjust
		{
			*pFlagEquToken++;
			nPara = BrAtoi(pFlagEquToken);	
			switch(nPara)
			{
			case 0 :	nPara = BMV_MSP_ADJUSTTYPE_VALUE;	break;						
			case 1 :	nPara = BMV_MSP_ADJUSTTYPE_VALUE2;	break;
			case 2 :	nPara = BMV_MSP_ADJUSTTYPE_VALUE3;	break;
			case 3 :	nPara = BMV_MSP_ADJUSTTYPE_VALUE4;	break;
			case 4 :	nPara = BMV_MSP_ADJUSTTYPE_VALUE5;	break;
			case 5 :	nPara = BMV_MSP_ADJUSTTYPE_VALUE6;	break;
			case 6 :	nPara = BMV_MSP_ADJUSTTYPE_VALUE7;	break;
			case 7 :	nPara = BMV_MSP_ADJUSTTYPE_VALUE8;	break;
			case 8 :	nPara = BMV_MSP_ADJUSTTYPE_VALUE9;	break;					
			case 9 :	nPara = BMV_MSP_ADJUSTTYPE_VALUE10;	break;
			}
			nCoordType = eShapeEquationVertex;			
		}
		break;

	case 2 :	//@	equation
		{	
			nPara = BrAtoi(pFlagEquToken);				
			nPara |= 0x400;
			nCoordType = eShapeEquationVertex;	
		}
		break;

	case 3 :	break;	//,

	case 4 :	//number
		{
			nPara = BrAtoi(pFlagEquToken);				
			nCoordType = eShapeNormalVertex;
		}
		break;

	case 5:
		{
			switch(*pFlagEquToken)
			{
			case 'w' :	nPara = BMV_MSP_GEORIGHT;	break;
			case 'h' :	nPara = BMV_MSP_GEOBOTTM;	break;
			case 'p' :  nPara = BMV_BSP_PI;			break;
			default:	nPara = 0;					break;
			}
			nCoordType = eShapeEquationVertex;
		}			
		break;	//alphabet			
	default :
		{
			nPara = 0;
			nCoordType = eShapeEquationVertex;
		}
		break;
	}
	return nCoordType;
}

//////////////////////////////////////////////////////
CDocxShape::CDocxShape(CDocxConv *pDocxConv, BrBOOL bInGroup/*=BrFALSE*/)
{
	m_pDocxConv = pDocxConv;
	m_bInGroup = bInGroup;


#ifdef XML_DOC_TYPE_DEF//[2012.10.09][TID:9464][������] DTD�Լ� �߰�.
	m_pType = BrNULL;
#else
	memset(m_pType, 0, 20);
	memset(m_cConnectorType, 0, 20);
#endif

	m_nCoordOriginX = 0;
	m_nCoordOriginY = 0;
	m_nCoordSizeX = 1000;
	m_nCoordSizeY = 1000;

	//image border
	m_pBorderColor = BrNULL;
	m_pBorderType = BrNULL;
	m_pBorderWidth = BrNULL;

	m_pPath = NULL;

	m_bOLEShape = BrFALSE;

	//jjoo:ImageData
	m_pImageData = BrNULL;
	m_bWordArt = BrFALSE;
	m_pTextPath = BrNULL;
	m_pFormulas = BrNULL;
	m_bBullet = BrFALSE;
}

CDocxShape::~CDocxShape()
{
	if(m_pTextPath)		BR_SAFE_DELETE(m_pTextPath);

	if(m_pImageData)	BR_SAFE_DELETE(m_pImageData);

	if(m_pFormulas)		BR_SAFE_DELETE(m_pFormulas);

	//image border
	if(m_pBorderColor)			BR_SAFE_FREE(m_pBorderColor);
	if(m_pBorderType)			BR_SAFE_FREE(m_pBorderType);
	if(m_pBorderWidth)			BR_SAFE_FREE(m_pBorderWidth);

#ifdef XML_DOC_TYPE_DEF
	if(m_pType)					BR_SAFE_FREE(m_pType);
#endif
}

BrBOOL CDocxShape::CallbackStartElement(LPVOID pParam)
{
	BrBOOL bRet = BrTRUE;
	XMLDataDecodeParam* pInfo = (XMLDataDecodeParam*)pParam;
	switch( pInfo->callbackParam.wParam )
	{
	case DOCX_DRAWINFO:
		return readShapeAttribute(pInfo);
	}
	return BrTRUE;
}

BrBOOL CDocxShape::CallbackEndElement(LPVOID pParam)
{
	XMLDataDecodeParam* pInfo = (XMLDataDecodeParam*)pParam;

	//[M-21709] hnsong:2013-01-21 ���� miss �߰�ó����
	if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_TEXTBOX)) //textbox
		m_pDocxConv->m_nDoingType &= ~DOC_CON_TEXTBOX;

	return BrTRUE;
}

BrBOOL CDocxShape::readDrawShapeInfo(XMLDataDecodeParam*  pInfo)
{
	if( !pInfo->pElementData->pAttributePairs)
		return BrFALSE;

	BrCHAR *pBuf;
	for( BrINT32 i = 0; pInfo->pElementData->pAttributePairs[i]; i+= 2)
	{
		DRAW_RESULT nResult = readObjectInfo(pInfo->pElementData->pAttributePairs[i], pInfo->pElementData->pAttributePairs[i+1], BrFALSE);
		if( DRAW_ETC == nResult )
		{
			const BrCHAR *pStr = pInfo->pElementData->pAttributePairs[i];
			switch(pStr[0])
			{
			case 't':
				if( 0 == strcmp(pStr, X_DOC_DRAW_TYPE) )
				{
					BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
					EDTD_RESULT nRet = BrXMLDTDUtil::VMLDocTypeDefintion(eATTValueTypeString,eATTValueSubTypeString_ShapeType, pStr, pInfo->pElementData->pAttributePairs[i+1],m_pDocxConv);
					switch(nRet)
					{
					case DTD_SUCCESS:
						m_pType = (BrCHAR*)BrMalloc(nLen+1);
						memcpy(m_pType, pInfo->pElementData->pAttributePairs[i+1], nLen );
						m_pType[nLen] = 0;
						break;
					case DTD_NEED_DEFAULT_VALUE:
						break;
					case DTD_FAIL:
					case DTD_IGNOREELEMENT:
						return BrFALSE;
					}
				}
				break;
			case 'c':
				if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], X_DOC_DRAW_SHAPE_COORDORIGIN) )
				{
					BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
					pBuf = (BrCHAR*)BrMalloc(nLen+1);
					memcpy(pBuf, pInfo->pElementData->pAttributePairs[i+1], nLen);
					pBuf[nLen] = 0;
					BrCHAR *pTmp = pBuf;
					BrCHAR seps[]   = ",";
					char* pContext = BrNULL;
					BrCHAR *ch = strtok_s(pTmp, seps, &pContext);
					if( ch )
					{
						if(pBuf[0] == ',')
						{
							m_nCoordOriginX = 0;
							m_nCoordOriginY = BrAtoi(ch);
						}
						else
						{
							m_nCoordOriginX = BrAtoi(ch);

							ch = strtok_s(NULL, seps, &pContext);
							if(ch)
								m_nCoordOriginY = BrAtoi(ch);
						}
					}
					BrFree(pBuf);
				}
				else if( 0 == strcmp(pStr, X_DOC_DRAW_SHAPE_COORDSIZE) )
				{
					BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
					pBuf = (BrCHAR*)BrMalloc(nLen+1);
					memcpy(pBuf, pInfo->pElementData->pAttributePairs[i+1], nLen);
					pBuf[nLen] = 0;
					BrCHAR *pTmp = pBuf;

					BrCHAR seps[]   = ",";
					char* pContext = BrNULL;
					BrCHAR *ch = strtok_s(pTmp, seps, &pContext);
					if( ch )
					{
						if(pBuf[0] == ',')
						{
							m_nCoordSizeX = 1000;
							m_nCoordSizeY = BrAtoi(ch);
						}
						else
						{
							m_nCoordSizeX = BrAtoi(ch);
							ch = strtok_s(NULL, seps, &pContext);
							if(ch)
								m_nCoordSizeY = BrAtoi(ch);
						}
					}
					BrFree(pBuf);
				}
				break;
			case 'p':
				if( 0 == strcmp(pStr, X_DOC_DRAW_SHAPE_PATH) )
				{// m795, l,2010 r2670,225 l1740,450, 795,xe
					// m570, l2520,705, 2325,2055, 495,1785, ,315, 570,xe
					BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
					if(nLen > 0)	//jjoo:2009-01-23:���ǽ� �߰� => ���� �Ӽ� �߿��� path�� < path=""> ������ ��찡 �߻��ؼ� ������ ��.
					{
						m_pPath = (BrCHAR*)BrMalloc(nLen+1);
						memcpy(m_pPath, pInfo->pElementData->pAttributePairs[i+1], nLen);
						m_pPath[nLen] = 0;
					}
				}
				break;
			case 'o':
				if( 0 == strcmp(pStr, X_DOC_DRAW_OLE))	
				{
					if(BrStrLen(pInfo->pElementData->pAttributePairs[i+1]) > 0)
						OOXMLSTHandler::SetSTOnOff(pInfo->pElementData->pAttributePairs[i+1], m_bOLEShape);
				}
				else if( 0 == strcmp(pStr, X_DOC_DRAW_BORDER_TOP_COLOR))	
				{
					BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
					m_pBorderColor = (BrCHAR*)BrMalloc(nLen+1);
					memcpy(m_pBorderColor, pInfo->pElementData->pAttributePairs[i+1], nLen);
					m_pBorderColor[nLen] = 0;
				}
				else if( 0 == strcmp(pStr, "o:bullet"))
					m_bBullet = BrTRUE;
				break;
			}		
		}
		else if (nResult == DRAW_FAIL)
			return BrFALSE;
	}

	return BrTRUE;
}

BrBOOL CDocxShape::readShapeAttribute(XMLDataDecodeParam*  pInfo)
{
	BrBOOL bRet = BrTRUE;
	const BrCHAR *pName = trimNamespace(pInfo->pElementData->pElementName);
	switch(pName[0])
	{
	case 'b':
		if( 0 == strcmp(pInfo->pElementData->pElementName, "w10:bordertop"))	//w10:bordertop
		{//[T-4784]
			if( pInfo->pElementData->pAttributePairs )
			{
				for( BrINT32 i = 0; pInfo->pElementData->pAttributePairs[i]; i+= 2)
				{
					if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], X_DOC_DRAW_TYPE) )
					{
						BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
						m_pBorderType = (BrCHAR*)BrMalloc(nLen+1);
						memcpy(m_pBorderType, pInfo->pElementData->pAttributePairs[i+1], nLen);
						m_pBorderType[nLen] = 0;
					}
					else if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], "width") )
					{
						BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
						m_pBorderWidth = (BrCHAR*)BrMalloc(nLen+1);
						memcpy(m_pBorderWidth, pInfo->pElementData->pAttributePairs[i+1], nLen);
						m_pBorderWidth[nLen] = 0;
					}
				}
			}
		}
		break;
	case 'f':
		if( 0 == strcmp(pInfo->pElementData->pElementName,X_DOC_DRAW_FORMULAS_F))	
		{
			readDrawFormulasInfo(pInfo);
		}
		else
			bRet = readDrawAttribute(pInfo);
		break;

	case 'i':
		if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_IMAGEDATA) || 0 == strcmp(pInfo->pElementData->pElementName, "v:imageData"))	//v:imagedata
		{
			if(!m_pImageData )
				m_pImageData = BrNEW CDocxImageData();

			m_pImageData->readImageDataInfo(pInfo);
		}
		break;
	case 't':
		if( 0 == strcmp(pInfo->pElementData->pElementName,X_DOC_DRAW_TEXTPATH))
		{
			if(!m_pTextPath)
				m_pTextPath = BrNEW CDocxDrawTextPath();

			m_pTextPath->readTextPathInfo(pInfo);
		}
		else
			bRet = readDrawAttribute(pInfo);
		break;
	default:
		bRet = readDrawAttribute(pInfo);
		break;
	}

	return bRet;
}

void CDocxShape ::readDrawFormulasInfo(XMLDataDecodeParam*  pInfo)
{		
	if( pInfo->pElementData->pAttributePairs )
	{
		for( BrINT32 i = 0; pInfo->pElementData->pAttributePairs[i]; i+=2)
		{
			const BrCHAR *pStr = pInfo->pElementData->pAttributePairs[i];

			if( 0 == strcmp(pStr, X_DOC_DRAW_FORMULAS_F_EQN))
			{
				BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
				BrCHAR* pBuf = (BrCHAR*)BrMalloc(nLen+1);
				memcpy(pBuf, pInfo->pElementData->pAttributePairs[i+1], nLen );
				pBuf[nLen] = 0;

				BrUINT32 nEqSize = 0;
				BrINT32	nTokenIndex=0;

				BrCHAR pToken[32];
				memset(pToken, 0, 32);

				FormulasValue* pEqu = (FormulasValue*)BrMalloc(BrSizeOf(FormulasValue));
				memset(pEqu,0,BrSizeOf(FormulasValue));		

				if(!m_pFormulas)
					m_pFormulas = BrNEW CDocxFormulaArray;
				else
					nEqSize = m_pFormulas->size();

				if(m_pFormulas)
				{
					m_pFormulas->resize(nEqSize+1);
					BrINT32 nReadLen = 0;
					do
					{
						pBuf = GetFormulaToken(pBuf,pToken,&nReadLen);
						if(!pBuf && nReadLen >= 32) {//2012-10-04 �Ｚ���ȹ��� ���� ����
#ifdef XML_DOC_TYPE_DEF
							BrXMLDTDUtil::SetXmlDtdError(pStr,m_pDocxConv);
#else
							SET_ERROR((PoError)kPoErrCorruptFile, "Adjust Value incorrect");
							BoraPackageBase::CurruptedXmlParser(m_pDocxConv);
#endif
							BR_SAFE_FREE(pEqu);
							return;
						}

						nLen = BrStrLen(pToken);
						switch(nTokenIndex)
						{
						case 0:	memcpy(pEqu->Flag, pToken, nLen); break;
						case 1:	memcpy(pEqu->Val1, pToken, nLen); break;
						case 2:	memcpy(pEqu->Val2, pToken, nLen); break;
						case 3:	memcpy(pEqu->Val3, pToken, nLen); break;
						}
						nTokenIndex++;
						memset(pToken, 0, 32);
					}while(pBuf);	
					m_pFormulas->SetAt(nEqSize,*pEqu);
				}	
				BR_SAFE_FREE(pEqu);
				BrFree(pBuf);
			}
		}	
	}	
}

BrCHAR* CDocxShape::GetFormulaToken(BrCHAR* pBuf, BrCHAR* pToken, BrINT32* pLen)
{
	BrCHAR * pTokenBuf = BrNULL;
	BrINT32 nLen = 0;
	
	while(*pBuf==' ')
	{
		pBuf++;
	}

	while(BrTRUE)
	{
		*pToken++ = *pBuf++;
		nLen++;
		if( *pBuf==' ' )
		{
			pTokenBuf = pBuf;
			break;
		}
		else if( *pBuf=='\0')
			break;
		if( nLen >= 32)//2012-10-04 �Ｚ���ȹ��� ���� ����
			return BrNULL;
	}
	
	if(pLen)
		*pLen = nLen;
	
	return pTokenBuf;
}

BrINT32 CDocxShape::getTemplateType(BrCHAR *pType)
{
	BrINT32 nType = SHAPE_None;
	if( pType )
		nType = BrAtoi(&pType[9]);

	if(nType == 1150 || nType == 1130 || nType == 1168) //WordArt ��� ������ �������� ���̽� CNZ-2421. Sample : Aturan Sinus2.docx
		nType = 144;

	if((nType > SHAPE_Max || nType < SHAPE_Min) && m_nSPT > 0)
		nType = m_nSPT;

	return nType;
}

CFrame* CDocxShape::convertShape(const BrCHAR* pCurPackagePartName, BrBOOL bInGroup/*=BrFALSE*/)
{
	if(!m_pStyle)
		return BrNULL;
	if(m_bBullet == BrTRUE && m_pImageData== BrNULL)
		return BrNULL;

	CDocxDrawStyle* pStyle = m_pStyle;
	BrBOOL bAnchorType = BrFALSE;
	BrBOOL bCreatEds = BrFALSE;
	BRect Rect;
	memset(&Rect,0,BrSizeOf(BRect));


	CFrame *pFrame = BrNULL;
	BrShape *pBwpShape = BrNULL;
	BrGrapAtt *pGrapAtt = BrNULL;
	ShapeType nShapeType = SHAPE_None;

	nShapeType = (ShapeType)getTemplateType(m_pType);
	if(nShapeType == SHAPE_TextBox || nShapeType >= SHAPE_Max)
		nShapeType = SHAPE_Rectangle;
	else if( SHAPE_None == nShapeType && m_pPath )
		nShapeType = SHAPE_Min;

	m_pStyle->getDrawRect(Rect, bInGroup);
	if(m_pImageData && m_pImageData->m_pID)	//jjoo:2003���� docx�� ������ �׸��� ���	//jjoo:2008-09-18:imagedata�� rId�� ���� ���
	{
		BrBYTE bClass = PICTUREFRAME;
		if(m_bOLEShape)
			bClass = OLEFRAME;

		pFrame = m_pDocxConv->createImage(Rect, pCurPackagePartName, m_pImageData->m_pID, (m_pStyle->m_nPosition == 0) ? BrTRUE : BrFALSE, BrFALSE, bClass, SHAPE_Rectangle, m_pImageData);
		m_pDocxConv->m_pFrameForOLE = pFrame;
		
	}
	else {
		
// 		if((!m_pFill || !m_pFill->m_pType) && SHAPE_PictureFrame == nShapeType)
// 			nShapeType = SHAPE_None;
		if(m_pFill)
			pFrame = m_pFill->convertFillAttribute(pCurPackagePartName, &Rect, nShapeType);
		else
		{
			if(m_pDocxConv->m_bComment)
				pFrame = m_pDocxConv->createFrame(FLOATFRAME, &Rect, BrFALSE, 0, BrTRUE);
			else
				pFrame = m_pDocxConv->createFrame(FLOATFRAME, &Rect, BrFALSE, m_pDocxConv->m_pCurPage ? m_pDocxConv->m_pCurPage->getPageNum() : 1, BrTRUE);

			if(pFrame && BrNULL == pFrame->getBorder())
				pFrame->setBorder( BrShape::createShape(nShapeType, *pFrame->getFrameRect() ));

			if(pFrame && m_pStyle->m_pTextBox)
				pFrame->setSubClass(TEXTBOXFRAME);
		}
	}

	if( !pFrame )
		return BrNULL;

	pBwpShape = pFrame->getBorder();

	if( m_pDocxConv->m_pCurFrame && (m_pDocxConv->m_pCurFrame->GetClass() == HEADFRAME || m_pDocxConv->m_pCurFrame->GetClass() == FOOTFRAME)
		&& (m_pID && (strstr(m_pID, "Watermark") != BrNULL || strstr(m_pID, "WaterMark") != BrNULL )))
		pFrame->setWatermark(BrTRUE);

	if(nShapeType >= SHAPE_TextPlainText && nShapeType<=SHAPE_TextCanDown) {
		m_bWordArt = BrTRUE;
	}

	((CDocxDrawAttr*)this)->convertAttribute(pFrame, m_pDocxConv);

	if(pBwpShape) {
		if(m_pDocxConv->m_pShapeTypeAdjArray)
		{
			AdjustValue adjValue;
			memset(&adjValue, 0, sizeof(AdjustValue));
			for(BrINT32 i=0; i< m_pDocxConv->m_pShapeTypeAdjArray->GetSize(); i++)
			{
				switch (i)
				{
				case 0:				
					adjValue.b01 = BrTRUE;
					adjValue.l01 = m_pDocxConv->m_pShapeTypeAdjArray->at(i);
					break;
				case 1:
					adjValue.b02 = BrTRUE;
					adjValue.l02 = m_pDocxConv->m_pShapeTypeAdjArray->at(i);
					break;
				case 2:
					adjValue.b03 = BrTRUE;
					adjValue.l03 = m_pDocxConv->m_pShapeTypeAdjArray->at(i);
					break;
				case 3:
					adjValue.b04 = BrTRUE;
					adjValue.l04 = m_pDocxConv->m_pShapeTypeAdjArray->at(i);
					break;
				case 4:
					adjValue.b05 = BrTRUE;
					adjValue.l05 = m_pDocxConv->m_pShapeTypeAdjArray->at(i);
					break;
				case 5:
					adjValue.b06 = BrTRUE;
					adjValue.l06 = m_pDocxConv->m_pShapeTypeAdjArray->at(i);
					break;
				case 6:
					adjValue.b07 = BrTRUE;
					adjValue.l07 = m_pDocxConv->m_pShapeTypeAdjArray->at(i);
					break;
				case 7:
					adjValue.b08 = BrTRUE;
					adjValue.l08 = m_pDocxConv->m_pShapeTypeAdjArray->at(i);
					break;
				case 8:
					adjValue.b09 = BrTRUE;
					adjValue.l09 = m_pDocxConv->m_pShapeTypeAdjArray->at(i);
					break;
				case 9:
					adjValue.b10 = BrTRUE;
					adjValue.l10 = m_pDocxConv->m_pShapeTypeAdjArray->at(i);
					break;
				}				
			}
			pBwpShape->setHandleValue(adjValue, m_pDocxConv->m_pShapeTypeAdjArray->size());		
		}
		if ( m_pDocxConv->m_pShapeAdjArray ){
			for(BrINT32 i=0; i< m_pDocxConv->m_pShapeAdjArray->GetSize(); i++)
			{
				BrINT32 tempAdj = m_pDocxConv->m_pShapeAdjArray->at(i);
				if ( tempAdj != 0 )
					pBwpShape->setRuleInfo(i, tempAdj );
			}
		}

		//o:border~color setting //������ �̹��� �׵θ��� �ϳ��� ��������
		if(m_pBorderColor || m_pBorderType)
		{
			BrPenObj* pPenObj = pBwpShape->getPen();
			if(m_pBorderColor)
				pPenObj->setColor(CUtil::getColor(m_pBorderColor));

			if(m_pBorderType)
			{
				pPenObj->setLineStyle(CDocxUtil::getLineStyle(m_pBorderType));
				pPenObj->setDashStyle(CDocxUtil::getLineStyle(m_pBorderType));
			}
		}

		if(m_bWordArt)
		{
			setShapeGeoText(pBwpShape);
			setWordArtLineInfo(pBwpShape->getWordartInfo(), pFrame);
		}
		if(m_pPath || m_pFormulas)
			setShapeGeometryAttributes(pBwpShape);
	}

	if( pStyle->m_nZIndex)//MistY - 2008.07.21
	{
		//text �� ��ġ �� Frame�� underbasicFlag Set	//MistY - 2008.08.20
		if( (pStyle->m_nZIndex< 0) && (pStyle->m_nZIndex != DEF_Z_INDEX) )	
			pFrame->setUnderBasic(TRUE);
		pFrame->setZindex(pStyle->m_nZIndex);
	}

#ifdef BWP_EDITOR
	if (pFrame->getBorder() && pBwpShape) 
		pBwpShape->reCreateShape(*pFrame->getFrameRect());
#endif
 	if(m_pDocxConv->m_pShapeTypeAdjArray)
 		BR_SAFE_DELETE(m_pDocxConv->m_pShapeTypeAdjArray);	
	
	if(m_pDocxConv->m_pShapeAdjArray)
		BR_SAFE_DELETE(m_pDocxConv->m_pShapeAdjArray);

	return pFrame;
}

//MistY - 2008.05.20
void CDocxShape::setShapeGeoText(BrShape *sh)
{
	if(!sh || !m_pTextPath)
		return;

	BString pStr ="";
	BrINT32 nSepsPos = -1 ;
	BrCHAR seps[]   = ",";	
	BrCHAR *pBuf = "";

	//WordArtInfo
	if(!sh->getWordartInfo())
	{
		//Shape ID setting 
		//[2013-11-09][toypilot] word art id���� �ʿ�
		CShapeWordartInfo* pWordArtInfo = BrNEW CShapeWordartInfo();
		pWordArtInfo->m_nShape = (ShapeType)getTemplateType(m_pType);
		sh->setWordartInfo(pWordArtInfo);
	}

	if(m_pTextPath->m_pString)
	{
		BrINT32 nStrLen = BrStrLen(m_pTextPath->m_pString);

		BrUSHORT *pOutput = (BrUSHORT*)BrMalloc(BrSizeOf(BrUSHORT) * MS_WORDARTSTR_MAXSIZE);
		memset(pOutput, 0, BrSizeOf(BrUSHORT) * MS_WORDARTSTR_MAXSIZE);
		BrINT32 nLen = BrMultiByteToWideChar( CP_UTF8, (BrLPCSTR)m_pTextPath->m_pString, nStrLen, (BrLPWSTR)pOutput, MS_WORDARTSTR_MAXSIZE);
		
		for (BrINT32 i = 0; (i < nLen) && pOutput[i]; i++)

			sh->getWordartInfo()->m_strText.append(BChar(pOutput[i]));

		BrFree(pOutput);
	}
	if(m_pTextPath->m_pStyle)
	{
		BrCHAR* pBuf = BrNULL;
		BrINT32 nTotalLen = BrStrLen(m_pTextPath->m_pStyle);
		pBuf = (BrCHAR*)BrMalloc(nTotalLen+1);

		memcpy(pBuf, m_pTextPath->m_pStyle, nTotalLen);
		pBuf[nTotalLen] = 0;

		BArray<BrCHAR*> StyleDataArray;
		BrCHAR seps1[] = ";";

		char* pContext = BrNULL;
		strtok_s(pBuf, seps1, &pContext);
	
		while(pBuf)
		{
			StyleDataArray.Add(pBuf);
			pBuf = strtok_s(BrNULL, seps1, &pContext);		
		}

		for(BrINT32 i = 0; i < StyleDataArray.size() ; i++)
			SetTextPathStyle(StyleDataArray.at(i), sh->getWordartInfo());

		BR_SAFE_FREE(pBuf);
	}
}

void CDocxShape::SetTextPathStyle(BrCHAR* a_pStyle, CShapeWordartInfo* a_pWordArtInfo)
{	//[2013.07.11][������] WaterMark ���� Font, Size setting 
	BrCHAR seps[] = ":";
	char* pContext = BrNULL;
	strtok_s(a_pStyle, seps, &pContext);

	if(	0 == strcmp(a_pStyle, "font-family") )
	{
		BrCHAR* pValue = strtok_s(BrNULL, seps, &pContext);

		if(pValue == BrNULL)
			return;

		BrINT32 nStrLen = BrStrLen(pValue);

		BrUSHORT *pOutput = (BrUSHORT*)BrMalloc((nStrLen + 1)*2);
		memset(pOutput, 0, (nStrLen + 1)*2);
		BrINT32 nLen = BrMultiByteToWideChar( CP_UTF8, (BrLPCSTR)pValue, nStrLen, (BrLPWSTR)pOutput, nStrLen);

		for (BrINT32 i = 0; (i <= nLen) && pOutput[i]; i++)
		{
			if(pOutput[i] != '"')
				a_pWordArtInfo->m_strFaceName.append(BChar(pOutput[i]));
		}

		BR_SAFE_FREE(pOutput);
	}
	if(	0 == strcmp(a_pStyle, "font-size") ) //font-size:1pt �̸� �ڵ�
	{
		BrCHAR* pValue = strtok_s(BrNULL, seps, &pContext);

		if(!pValue)
			return;

		BrINT32 nFontSize = 0;
		if( strstr(pValue, "pt") )
			nFontSize = BrAtoi(pValue);
		else if( strstr(pValue, "in") )
			nFontSize = (BrAtoi(pValue)) * 72;

		if(nFontSize != 1)		//�ڵ��� �� default �� ���� �ֵ��� ���� ������.	
			a_pWordArtInfo->m_nHeight = nFontSize;
	}
	if( 0 == strcmp(a_pStyle, "font-style") )
	{
		BrCHAR* pValue = strtok_s(BrNULL, seps, &pContext);
		if(pValue && 0 == strcmp(pValue, "italic") )
			a_pWordArtInfo->m_bItalic = BrTRUE;
	}
	if(0 == strcmp(a_pStyle, "font-weight"))
	{
		BrCHAR* pValue = strtok_s(BrNULL, seps, &pContext);
		if(pValue && 0 == strcmp(pValue, "bold") )
			a_pWordArtInfo->m_bBold = BrTRUE;
	}
	if(0 == strcmp(a_pStyle, "v-rotate-letters"))
	{
		BrCHAR* pValue = strtok_s(BrNULL, seps, &pContext);
		BrBOOL rotateLetter = BrFALSE;
		OOXMLSTHandler::SetSTOnOff(pValue, rotateLetter);
		a_pWordArtInfo->m_bVertical = rotateLetter;
	}
}

BrBOOL CDocxShape::setWordArtLineInfo(CShapeWordartInfo* a_pWordArtInfo, CFrame* a_pFrame)
{
	if(!a_pWordArtInfo)
		return BrFALSE;

	CLineList* pLineList = BrNEW CLineList();
	CLine *pLine = BrNEW CLine();
	CCharSetArray *pNodeArray = BrNEW CCharSetArray();
	CCharSet cCharSet;
	BrSHORT nFontID = 0;
	BrSHORT nTextAttID = 0;
	BrBOOL bRTL = BrFALSE;

	BString strText = a_pWordArtInfo->m_strText;
	BrINT32 nSize = strText.length();

	//TextAtt
	PoTextAtt pTextAtt;
	pTextAtt.setBold(a_pWordArtInfo->m_bBold);
	pTextAtt.setItalic(a_pWordArtInfo->m_bItalic);
	pTextAtt.setStrikeout(a_pWordArtInfo->m_bStrikeout);
	pTextAtt.setUnderline(a_pWordArtInfo->m_bUnderline);
	pTextAtt.setHanFSize(PTtoTWIP(a_pWordArtInfo->m_nHeight));
	pTextAtt.setEngFSize(PTtoTWIP(a_pWordArtInfo->m_nHeight));
	pTextAtt.setTextColor(RGB_BLACK);

	if(a_pWordArtInfo->m_strFaceName.length() > 0)
	{
		BrWORD face[BR_LF_FACESIZE];
		memset(face, 0, BR_LF_FACESIZE);
		CUtil::BStringToWord_S(a_pWordArtInfo->m_strFaceName, face, BR_LF_FACESIZE);

		nFontID = theBWordDoc->getFontArray()->getFontID(face);
		pTextAtt.setHanFontID(nFontID);
		pTextAtt.setEngFontID(nFontID);
	}

	for(BrINT32 i = 0 ; i < nSize ; i++)
	{
		CCharSet oCharSet;
		USHORT nCode = strText[i].unicode();
		oCharSet.setCode(nCode);

		if(IsRTLChar(nCode))
		{
			pTextAtt.setBiDi(BrTRUE);
			bRTL = BrTRUE;
		}
		else
			pTextAtt.setBiDi(BrFALSE);

		nTextAttID = theBWordDoc->getTextAttHandler()->insertTextAtt(pTextAtt);
		oCharSet.setAttrID(nTextAttID);

		pNodeArray->Add(oCharSet);
	}

	pNodeArray->addCR(nTextAttID);

	//ParaAtt
	PoParaAtt pParaAtt;
	if(bRTL)
		pParaAtt.setBiDi(BrTRUE);

	pLine->setParaID(theBWordDoc->getParaAttHandler()->insertParaAtt(pParaAtt));

	pLine->setCharSetArray( pNodeArray );
	pLineList->insertAtTail(pLine);

	pLineList->setFrame(a_pFrame);
	a_pFrame->setSubFrame(pLineList);

	return BrTRUE;
}

void CDocxShape::setShapeGeometryAttributes(BrShape* pSh)		//MistY - 2008.11.17
{
	if(!pSh)
		return;

	if(pSh->getBorderStyle() == SHAPE_Min)
		pSh->setBorderStyle(SHAPE_scribble);

	if(m_pPath)
		ShapePathAnalyze(pSh);							//set segment,vertex

	if(m_pFormulas)	
		m_pFormulas->setShapeGeoEquation(pSh);							//set equation	

	//[2013.04.04][������][T-14712] �ʱⰪ 1000�϶� Setting ���� �ʰ� 
	if(m_nCoordSizeX != 1000|| m_nCoordSizeY != 1000)
		setShapeGeoViewBox(pSh);						//set viewbox
}

void	CDocxShape::setShapeGeoViewBox(BrShape* pSh)
{
	if(!pSh)
		return;

	BrShapeProperty sPro;	
	BrRect *pRect = (BrRect*) BrMalloc(BrSizeOf(BrRect));
	memset(pRect,0,BrSizeOf(BrRect));

	if(m_nCoordSizeX)
		pRect->right = m_nCoordSizeX;

	if(m_nCoordSizeY)
		pRect->bottom = m_nCoordSizeY;

	sPro.nType = eShapeViewBox;
	sPro.pPro = pRect;

	pSh->getGeometryAttrs().Add(sPro);
}


void CDocxShape::ShapePathAnalyze(BrShape* pSh)
{
	BrCHAR *pStrPathData = m_pPath;
	
	BrBOOL	bReverse = BrFALSE , bKeep = BrFALSE;
	BrINT32  nPtCnt = 0, nVtxIndex = 0, nSegIndex = 0;

	BrCHAR SegInfo[3];	
	BrCHAR *pSegVtxToken = BrNULL;
	BrCHAR SegVtxToken[1024];	
	BrCHAR VtxToken1[15], VtxToken2[15];		
	BrCHAR VtxTmpTok1[15], VtxTmpTok2[15];	

	memset(SegInfo,0,3);
	memset(VtxToken1,0,15);
	memset(VtxToken2,0,15);
	memset(VtxTmpTok1,0,15);
	memset(VtxTmpTok2,0,15);
	memset(SegVtxToken, 0, 1024);		

	BrShapeProperty sPro;
	BArray<BrShapeVertices>* pCoordinates = BrNULL;
	BArray<BrShapeSegment>*	pSegments = BrNULL;

	do
	{
		pStrPathData = GetShapePathToken(pStrPathData, SegVtxToken, &bReverse);	//StrPathData => pVertexToken make
		pSegVtxToken = SegVtxToken;
		
		while(*pSegVtxToken)
		{
			pSegVtxToken = GetShapeSegVtxAnalyze(pSegVtxToken,SegInfo,VtxToken1,sizeof(VtxToken1),VtxToken2,sizeof(VtxToken2),&nPtCnt);
			
			if(nPtCnt<2)
				nVtxIndex += nPtCnt;
			else
				nVtxIndex += nPtCnt/2;

			if(nVtxIndex)		//vtx�� �ִ� ���
			{	
				if(bReverse || SegInfo[0] == 'r' || SegInfo[0] == 't'|| SegInfo[0] == 'v')	//NextToken is reverse
				{
					if(*pSegVtxToken && (SegInfo[0] == 'r' || SegInfo[0] == 't'|| SegInfo[0] == 'v'))
						bKeep = BrTRUE;

					CDocxUtil::ChgVtxTokenValue(VtxTmpTok1,VtxTmpTok2,VtxToken1,VtxToken2,SegInfo,bKeep);					
				}
				
				if(nSegIndex == 0 && nVtxIndex == 1)
					pCoordinates = BrNEW BArray<BrShapeVertices>;

				AddVertices(pSh,pCoordinates,nSegIndex,nVtxIndex,VtxToken1,VtxToken2, SegInfo);				
			
				if(!(*pSegVtxToken))//nVtxCnt�� �ְ�.. pSegVtxToken�� ����.. pSeginfo�� �������??	ex>token�� �� ���� �� ������ x,e�� �� ���
				{
					if(nSegIndex == 0)
						pSegments = BrNEW BArray<BrShapeSegment>;

					AddSegment(pSh,pSegments,nSegIndex,nVtxIndex,SegInfo);					
				}
			}
			else	//vtx�� ���� ��� ex>x,e
			{
				if(nSegIndex == 0)
					pSegments = BrNEW BArray<BrShapeSegment>;

				AddSegment(pSh,pSegments,nSegIndex,nVtxIndex,SegInfo);				
			}
			memset(VtxToken1,0,15);
			memset(VtxToken2,0,15);

			if(pSegVtxToken == BrNULL)
				break;
		}//while	

		nSegIndex++;
		nVtxIndex= 0;
		memset(SegInfo,0,3);
		memset(SegVtxToken, 0, 1024);				
		
		if(pStrPathData == BrNULL)
			break;
	} while(pStrPathData);

	//vertex
	sPro.nType = eShapeCoordinates;
	sPro.pPro = pCoordinates;

	pSh->getGeometryAttrs().Add(sPro);
	//segment
	sPro.nType = eShapeSegment;
	sPro.pPro = pSegments;

	pSh->getGeometryAttrs().Add(sPro);
}

void CDocxShape::AddVertices(BrShape* pSh,BArray<BrShapeVertices>* pCoordinates, BrINT32 nSegIndex, BrINT32 nVtxIndex,  BrCHAR* pStrVertex1,BrCHAR* pStrVertex2, BrCHAR* pSegInfo)
{
	if( !pCoordinates )
		return;

	//vtx
	BrUINT32 nCoordLen = 0;
	BrCHAR pBufX[10] = {0,};
	BrCHAR pBufY[10] = {0,};

	if(!(nSegIndex == 0 && nVtxIndex == 1))
		nCoordLen = pCoordinates->size();

// 	if((strcmp(pSegInfo, "v") == 0 || strcmp(pSegInfo, "t") == 0 || strcmp(pSegInfo, "r") == 0) && nCoordLen > 0)
// 	{
// 		BrShapeVertices* pCoord = pCoordinates->GetAt(nCoordLen - nVtxIndex);
// 		pStrVertex1 = BrItoa(BrAtoi(pStrVertex1) + pCoord->vertex1.nValue, pBufX, 10);
// 		pStrVertex2 = BrItoa(BrAtoi(pStrVertex2) + pCoord->vertex2.nValue, pBufY, 10);
// 	}

	pCoordinates->resize(nCoordLen+1);
	BrShapeVertices* pCoord = pCoordinates->GetAt(nCoordLen);
	
	setShapeGeoVertex(&pCoord->vertex1, pStrVertex1);
	setShapeGeoVertex(&pCoord->vertex2, pStrVertex2);

	if(strcmp(pSegInfo, "al") == 0 || strcmp(pSegInfo, "ae") == 0)
	{
		switch (nVtxIndex)
		{
		case 2:
			if(pCoord->vertex1.nType == eShapeNormalVertex)
				pCoord->vertex1.nType = eShapeLogNormalVertex;
			else if(pCoord->vertex1.nType == eShapeEquationVertex)
				pCoord->vertex1.nType = eShapeLogEquationVertex;

			if(pCoord->vertex2.nType == eShapeNormalVertex)
				pCoord->vertex2.nType = eShapeLogNormalVertex;
			else if(pCoord->vertex2.nType == eShapeEquationVertex)
				pCoord->vertex2.nType = eShapeLogEquationVertex;
			break;
		case 3:
			if(pCoord->vertex1.nType == eShapeNormalVertex)
				pCoord->vertex1.nType = eShapeNativeNormalVertex;
			else if(pCoord->vertex1.nType == eShapeEquationVertex)
				pCoord->vertex1.nType = eShapeNativeEquationVertex;

			if(pCoord->vertex2.nType == eShapeNormalVertex)
				pCoord->vertex2.nType = eShapeNativeNormalVertex;
			else if(pCoord->vertex2.nType == eShapeEquationVertex)
				pCoord->vertex2.nType = eShapeNativeEquationVertex;

			pCoord->vertex1.nValue /= 65536;
			pCoord->vertex2.nValue /= 65536;
			break;
		default:
			break;
		}
	}

	//[M-19260] hnsong:2013-01-02 CoordOrigin�� �ִ� ��� ����
	if(m_nCoordOriginX)
		pCoord->vertex1.nValue -= m_nCoordOriginX;
	if(m_nCoordOriginY)
		pCoord->vertex2.nValue -= m_nCoordOriginY;

}

void CDocxShape::setShapeGeoVertex(BrShapeVertex*  pVertex, BrCHAR* pStrVertex)
{
	BrINT32 nVertLen = 0;
	BrINT32 nVertex = 0;

	nVertLen = BrStrLen(pStrVertex);
	
	switch(*pStrVertex)
	{		
		case '@' : //equation
			{
				*pStrVertex++;
				nVertex = BrAtoi(pStrVertex);
				pVertex->nType = eShapeEquationVertex;
				//nVertex |= 0x400;
				pVertex->nValue = nVertex;
			}
			break;

		case '#' :	//adjust
			{
				*pStrVertex++;
				nVertex = BrAtoi(pStrVertex);
				pVertex->nType = BMV_MSP_ADJUSTTYPE_VALUE;
				pVertex->nValue = nVertex ;
			}
			break;

		case ',' :
			{
				*pStrVertex++;				
				pVertex->nType = eShapeNormalVertex;
				pVertex->nValue = 0 ;
			}
			break;

		default : //number
			{
				if(BrStrLen(pStrVertex) == 0)
					nVertex = 0;
				else
					nVertex = BrAtoi(pStrVertex);
				pVertex->nType = eShapeNormalVertex;
				pVertex->nValue = nVertex;
			}
			break;
	}

	//if(pVertex->nType == eShapeEquationVertex)
	//	m_bNeedEqution = BrTRUE;
}

void CDocxShape::AddSegment( BrShape* pSh,BArray<BrShapeSegment>* pSegments, BrINT32 nSegIndex, BrINT32 nVtxIndex,  BrCHAR* pSegInfo)
{
	if(*pSegInfo)	//[2011.12.05][������][TID:1969] segment �������� ���̵� ǥ�� �ǵ��� ���� segment �������� ���̵� ǥ�� �ǵ��� ����
	{
		BrUINT32 nSegLen = pSegments->size();
		BrShapeSegment* pSeg = BrNULL;
		
		pSegments->resize(nSegLen+1);
		pSeg = pSegments->GetAt(nSegLen);
		
		setSegment(pSeg,pSegInfo,nVtxIndex,nSegIndex);						
//#define PATH_TRACE	
#ifdef PATH_TRACE
		{
			BrTrace("nSegIndex :%d %d %d ",nSegIndex,pSeg->nCmd,pSeg->nCnt);								
		}
#endif//#ifdef PATH_TRACE
	}
}

BrINT16 CDocxShape::GetSegmentType(BrCHAR *pSegInfo)
{
	BrINT16 nSegType = 0;
	switch(*pSegInfo)
	{
		case 'm' :	
		case 't' :	
			nSegType = eGlyphPathMoveTo;	
			break;

		case 'l' :	
		case 'r' :
			nSegType = eGlyphPathLineTo;	
			break;	

		case 'v' :
		case 'c' :	
			nSegType = eGlyphPathCurveTo;	
			break;	

		case 'x' :	nSegType = eGlyphPathClose;		break;	
		case 'e' :	nSegType = eGlyphPathEnd;		break;	
			break;
				
		case 'n' :
			{
				*pSegInfo++;
				switch(*pSegInfo)
				{
					case 'f' :	nSegType = eGlyphPathNoFill;		break;		
					case 's' :	nSegType = eGlyphPathNoStroke;		break;		
				}
			}
			break;

		case 'a' :
			{
				*pSegInfo++;
				switch(*pSegInfo)
				{
					case 'e' :	nSegType = eGlyphPathAngleEllipseTo;	break;
					case 'l' :	nSegType = eGlyphPathAngleEllipse;		break;
					case 't' :	nSegType = eGlyphPathArcTo;				break;
					case 'r' :	nSegType = eGlyphPathArc;				break;
				}					
			}
			break;

		case 'w' :
		{
			*pSegInfo++;
			switch(*pSegInfo)
			{
				case 'a' :	nSegType = eGlyphPathCWArcTo;	break;	
				case 'r' :	nSegType = eGlyphPathCWArc;		break;	
			}
		}
		break;

		case 'q' :
			{
				*pSegInfo++;
				switch(*pSegInfo)
				{
					case 'x' :	nSegType = eGlyphPathEllipticalQuadrantX;	break;	
					case 'y' :	nSegType = eGlyphPathEllipticalQuadrantY;	break;	
				}
			}
			break;
	}
	return nSegType;
}

void CDocxShape::setShapeGeoSegment(BrShapeSegment* pSegment,BrINT16 nCmd, BrINT16 nVtxCnt,BrINT32 nSegCnt)
{	
	//[2011.12.05][������][TID:1969] segment �������� ���̵� ǥ�� �ǵ��� ����
	pSegment->nCmd = nCmd;
	pSegment->nCnt = nVtxCnt;			
}

void CDocxShape::setSegment(BrShapeSegment* pSegment,BrCHAR *pSegInfo,BrINT32 nVtxCnt,BrINT32 nSegCnt)
{
	switch(*pSegInfo)//[2011.12.05][������][TID:1969] segment �������� ���̵� ǥ�� �ǵ��� ����
	{
		case 'c' :	
		case 'v' :	
			{
				//[2012.03.14][TID : 4883][���ؼ�] ��� ��� ���׸�Ʈ ī��Ʈ ��ġ ����
				setShapeGeoSegment(pSegment,eGlyphPathCurveTo, nVtxCnt / 3, nSegCnt);
			}
			break;

		case 'l' :				
		case 'r' :	
			{
				setShapeGeoSegment(pSegment,eGlyphPathLineTo, nVtxCnt, nSegCnt);	
			}
			break;

		case 'm' :	
		case 't' :	
			{
				setShapeGeoSegment(pSegment,eGlyphPathMoveTo, nVtxCnt, nSegCnt);
			}
			break;		
				
		case 'x' :	setShapeGeoSegment(pSegment,eGlyphPathClose, nVtxCnt, nSegCnt);		break;					
		case 'e' :	setShapeGeoSegment(pSegment,eGlyphPathEnd, nVtxCnt, nSegCnt);		break;
				
		case 'n' :
			{
				*pSegInfo++;
				switch(*pSegInfo)
				{
					case 'f' :	setShapeGeoSegment(pSegment,eGlyphPathNoFill, nVtxCnt, nSegCnt);		break;
					case 's' :	setShapeGeoSegment(pSegment,eGlyphPathNoStroke, nVtxCnt, nSegCnt);	break;
				}
			}
			break;

		case 'a' :
			{
				*pSegInfo++;
				switch(*pSegInfo)
				{
					case 'e' :	
						{
							nVtxCnt = nVtxCnt/3;
							setShapeGeoSegment(pSegment,eGlyphPathAngleEllipseTo, nVtxCnt, nSegCnt);	
						}
						break;
					case 'l' :	
						{
							nVtxCnt = nVtxCnt/3;
							setShapeGeoSegment(pSegment,eGlyphPathAngleEllipse, nVtxCnt, nSegCnt);
						}
						break;
					case 't' :
						{
							nVtxCnt = nVtxCnt/4;
							setShapeGeoSegment(pSegment,eGlyphPathArcTo, nVtxCnt, nSegCnt);							
						}
						break;
					case 'r' :	
						{
							nVtxCnt = nVtxCnt/4;
							setShapeGeoSegment(pSegment,eGlyphPathArc, nVtxCnt, nSegCnt);			
						}
						break;
				}					
			}
			break;

		case 'w' :
		{
			*pSegInfo++;
			switch(*pSegInfo)
			{
				case 'a' :	
					{
						nVtxCnt = nVtxCnt/4;
						setShapeGeoSegment(pSegment,eGlyphPathCWArcTo, nVtxCnt, nSegCnt);
					}
					break;
				case 'r' :	
					{
						nVtxCnt = nVtxCnt/4;
						setShapeGeoSegment(pSegment,eGlyphPathCWArc, nVtxCnt, nSegCnt);		
					}
					break;
			}
		}
		break;

		case 'q' :
			{
				*pSegInfo++;
				switch(*pSegInfo)
				{
					case 'x' :	setShapeGeoSegment(pSegment,eGlyphPathEllipticalQuadrantX, nVtxCnt, nSegCnt);	break;
					case 'y' :	setShapeGeoSegment(pSegment,eGlyphPathEllipticalQuadrantY, nVtxCnt, nSegCnt);	break;
				}
			}
			break;
	}
}

BrCHAR * CDocxShape::GetShapeSegVtxAnalyze(BrCHAR *pSegVtxToken, BrCHAR *pSegInfo, BrCHAR *pVtxToken1, int pVtxToken1Size, BrCHAR *pVtxToken2, int pVtxToken2Size, BrINT32* pVtxCnt)
{
	BrINT32	nVtxCnt = 0;				//VtxToken�� ������� ����,pVtxCnt�� set
	BrBOOL	bVtxTok = BrFALSE;			//Vtx token ���� �Ϸ�
	BrCHAR *pRetToken = BrNULL;
	BrBOOL	bFstTok = BrTRUE;
	
	BrCHAR *pTmpToken = BrNULL;
	BrCHAR TmpToken[15];
	memset(TmpToken,0,15);
	pTmpToken = TmpToken;
	
	do{			
		switch(*pSegVtxToken)
		{
			case 'm' :
			case 'l' :	
			case 'c' :	
			case 'x' :
			case 'e' :				
			case 't' :				
			case 'r' :				
			case 'v' :				
				{
					*pSegInfo = *pSegVtxToken++;
				}
					break;

			case 'n' :
				{
					*pSegInfo = *pSegVtxToken++;
					switch(*pSegVtxToken)
					{
					case 'f' :
					case 's' :
						{
							*(pSegInfo+1) = *pSegVtxToken++;					
						}
						break;
					}
				}
				break;

			case 'a' :
				{
					*pSegInfo = *pSegVtxToken++;
					switch(*pSegVtxToken)
					{
						case 'e' :				
						case 'l' :				
						case 't' :				
						case 'r' :
							{
								*(pSegInfo+1) = *pSegVtxToken++;								
							}
							break;
					}					
				}
				break;

			case 'w' :
			{
				*pSegInfo = *pSegVtxToken++;
				switch(*pSegVtxToken)
				{
					case 'a' :			
					case 'r' :			
						{
							*(pSegInfo+1) = *pSegVtxToken++;								
						}
						break;
				}
			}
			break;

			case 'q' :
				{
					*pSegInfo = *pSegVtxToken++;
					switch(*pSegVtxToken)
					{
						case 'x' :
						case 'y' :	
							{
								*(pSegInfo+1) = *pSegVtxToken++;
							}
							break;
					}
				}
				break;

			case '@' :	//equation
			case '#' :	//adjust
			case ',' :
				{
					*(pTmpToken) = *pSegVtxToken++;										

					BrBOOL bQuit = BrFALSE;
					BrINT32 nBufLen = BrStrLen(pSegVtxToken);			

					for(int i = 0 ; i<nBufLen ; i++)
					{
						BrINT32 nTokenLen;
						nTokenLen = BrStrLen(pTmpToken);
						
						if(!bQuit)
						{
							BrINT16 Type = CDocxUtil::GetVtxTokenType(pSegVtxToken);
							switch(Type)
								{
									case 1 :	break;	//#
									case 2 :	break;	//@
										
									case 3 :	//,
										{
											bQuit = BrTRUE;						
											if(IsDigit(*(pTmpToken+nTokenLen)))
												nVtxCnt--;																					
										}
										break;

									case 4 :	//number
										{													
											if((*pTmpToken ==44))	//,�� ����
												bQuit = BrTRUE;
											else
											{
												if(IsDigit(*pSegVtxToken))//����
												{											
													*(pTmpToken+i+1) = *pSegVtxToken++;			
												}
												else	//alpahbet
													bQuit = BrTRUE;
																
												Type = CDocxUtil::GetVtxTokenType(pSegVtxToken);												
												if(Type == 3)	//,
												{
													pSegVtxToken++;
													bQuit = BrTRUE;
												}
												else if(Type != 4 && Type!= 3)	//, number
													bQuit = BrTRUE;												
											}											
										}
										break;

									case 5 :	//alpahbet
										{
											if(IsDigit(*pSegVtxToken))//����
											{
												*(pTmpToken+i+1) = *pSegVtxToken++;			
											}
											else	//alpahbet
												bQuit = BrTRUE;										
										}
										break;

									default :	break;	//����, alpahbet										
								}
						}
						else
							break;
					}

					if(bFstTok)
						strncpy_s(pVtxToken1, pVtxToken1Size,pTmpToken, strlen(pTmpToken));
					else
						strncpy_s(pVtxToken2, pVtxToken2Size,pTmpToken, strlen(pTmpToken));

					memset(pTmpToken,0,15);

					nVtxCnt++;				
					pRetToken = pSegVtxToken;	//MistY - 2008.11.19
				}
					break;		

			case '\0' :		bVtxTok = BrTRUE;		break;

			default:	//number
				{		
					*(pTmpToken) = *pSegVtxToken++;										
					BrINT32 nBufLen = BrStrLen(pSegVtxToken);					

					for(int i = 0 ; (0 != nBufLen) ; i++)
					{						
						if(pSegVtxToken[0]>=48 && pSegVtxToken[0]<= 57)
						{
							*(pTmpToken+i+1) = *pSegVtxToken++;			
						}
						else if(pSegVtxToken[0] == 44)	//���ڵ�,?
						{
							*pSegVtxToken++;
							if(!*pSegVtxToken)
								nVtxCnt++;
							break;						//MistY - 2008.11.21
						}
						else		
							break;								
					}
					nVtxCnt++;
					pRetToken = pSegVtxToken;	//MistY - 2008.11.19
					if(bFstTok)
						strncpy_s(pVtxToken1, pVtxToken1Size,pTmpToken, strlen(pTmpToken));
					else
						strncpy_s(pVtxToken2, pVtxToken2Size,pTmpToken, strlen(pTmpToken));

					memset(pTmpToken,0,15);

				}
				break;
		}			

		if(nVtxCnt)
		{
			if(nVtxCnt%2)	//����������
			{							
				bFstTok = BrFALSE;			//1stTok�����ϹǷ� FALSE�� chg
				if(*pSegVtxToken)		//pSegVtxToken�� ������..
					bVtxTok = BrFALSE;
				else					//pSegVtxToken�� ������..
					bVtxTok = BrTRUE;
			}
			else		//������ ���� x
			{
				bVtxTok = BrTRUE;
			}			
		}
	}while(!bVtxTok);

	if(pVtxCnt)
		*pVtxCnt = nVtxCnt++;

	return pRetToken;
}

BrCHAR* CDocxShape ::GetShapePathToken(BrCHAR* pStrPathData, BrCHAR* pSegVtxToken,BrBOOL* pReverse )
{
	BrCHAR bBeforeSegment = 0;
	BrCHAR beforeChar ;
	BrBOOL bToken = BrFALSE;
	BrBOOL bReverse = BrFALSE;
	BrCHAR *pToken = BrNULL;
	BrINT32 nSegVtxToken = 1;
	do{
		
		if(1 == nSegVtxToken)
		{
			bBeforeSegment = *pStrPathData;
		}

		*pSegVtxToken++ = *pStrPathData++;
		nSegVtxToken++;
		
		switch(*pStrPathData)
		{
			case 'm' :
			case 'l' : 		
			case 'c' : 
			case 'x' :
			case 'e' :
			case 't' :
			case 'r' :
			case 'v' :
			{
				if(*pStrPathData == 'r' || *pStrPathData == 'v' || *pStrPathData == 't')
					bReverse = BrTRUE;
				beforeChar = *(pStrPathData - 1);
				if( (beforeChar == 'q') && (*pStrPathData == 'x') )
					break;
				else if((beforeChar == 'a') && ((*pStrPathData == 'e') || (*pStrPathData == 'l') || (*pStrPathData == 't') || (*pStrPathData == 'r')))
					break;
				else if((beforeChar == 'w') && (*pStrPathData == 'r') )
					break;
				else
				{
					pToken = pStrPathData;	
					bToken = BrTRUE;
				}
			}	
				break;		
			
			case 'n' :
				{					
					*pSegVtxToken++ = *pStrPathData++;
					nSegVtxToken++;
					switch(*pStrPathData)
					{
						case 'f' :
						case 's' :
							{
								*(pSegVtxToken-1)=0;
								*pStrPathData--;
								pToken = pStrPathData;	
								bToken = BrTRUE;
							}
							break;

						default:
							{
								*(pSegVtxToken-1)= 0;
								*pStrPathData--;
							}
							break;
					}
				}
				break;

			case 'a' :
				{
					beforeChar = *(pStrPathData-1);
					if( (beforeChar == 'w'))
						break;
					*pSegVtxToken++ = *pStrPathData++;
					nSegVtxToken++;
					switch(*pStrPathData)
					{
						case 'e' :
						case 'l' :
						case 't' :
						case 'r' :
							{
								*(pSegVtxToken-1)=0;
								*pStrPathData--;
								pToken = pStrPathData;	
								bToken = BrTRUE;				
							}
							break;

						default:
							{
								*(pSegVtxToken-1)=0;
								*pStrPathData--;
							}
							break;
					}
				}
				break;

			case 'w' :
				{
					*pSegVtxToken++ = *pStrPathData++;
					nSegVtxToken++;
					switch(*pStrPathData)
					{
						case 'a' :
						case 'r' :
							{
								*(pSegVtxToken-1)=0;
								*pStrPathData--;
								pToken = pStrPathData;	
								bToken = BrTRUE;
							}
							break;

						default:
							{
								*(pSegVtxToken-1)=0;
								*pStrPathData--;
							}
							break;
					}
				}
				break;

			case 'q' :
				{
					*pSegVtxToken++ = *pStrPathData++;
					nSegVtxToken++;
					switch(*pStrPathData)
					{
						case 'x' :
						case 'y' :
							{
								*(pSegVtxToken-1)=0;
								*pStrPathData--;
								pToken = pStrPathData;	
								bToken = BrTRUE;
							}
							break;

						default:
							{
								*(pSegVtxToken-1)=0;
								*pStrPathData--;
							}
							break;
					}
				}
				break;

			case '\0' :		bToken = BrTRUE;		break;

			case 'h' :	//MistY - 2009.01.28
				{
					*pStrPathData++;
					*pStrPathData++;
					pToken = pStrPathData;	
					bToken = BrTRUE;
				}
				break;

			default	  :					break;
		}	
		if( nSegVtxToken >= 1024 ) //[2011.11.04][������][TID:1241]
		{
			BrINT16 nCommaCount = 0;	//vertex ���� �����ֱ� ���ؼ� ¦���� ¥��.
			BrINT16 nDelCount = 0;	
			BrINT16 k = 0;

			while(nSegVtxToken > k)
			{
				if(',' == *(pSegVtxToken-k))
				{
					nCommaCount++;
				}
				k++;
			}

			nDelCount = nCommaCount%6 + 1;

			while(nDelCount > 0)
			{
				if( *(pSegVtxToken - 1) != ',') 
				{
					do 
					{
						*pSegVtxToken--;
						*pStrPathData--;
					}while(*(pSegVtxToken) != ',');
				}
				else
				{
					*pSegVtxToken--;
					*pStrPathData--;
				}
				nDelCount--;
			}			

			*pSegVtxToken = 0;
			
			if(bBeforeSegment != 0)	//���� Segment insert
				*pStrPathData = bBeforeSegment;
			else
				pStrPathData++;
			

			pToken = pStrPathData;	
			bToken = BrTRUE;

			break;
		}
	}while(!bToken);

	if(pReverse)
		*pReverse = bReverse;
	
	return pToken;
}

BrBOOL	CDocxShape::convWordArtShadowMatrix(const BrCHAR *strShadowMatrix,BrShape *sh)
{
#if 0
	BrBOOL bInch = BrFALSE;

	BrINT32 nTotal = BrStrLen(strShadowMatrix);
	BrCHAR *pCh = (BrCHAR*)BrMalloc(nTotal); 
	BrINT32 nLen = 0;
	BrINT32 nPosCount = 0;
	BrDOUBLE nValue = 0;

	BrINT32 nPos = BrStrCpn(strShadowMatrix, ",");	
	memcpy(pCh, strShadowMatrix, nPos);
	pCh[nPos] = 0;

	while(nLen < nTotal)
	{
		switch(nPosCount )
		{
		case	0:
			sh->m_pShadowInfo->m_lScaleX2X	= convertUnitValue(pCh);
			break;

		case	1:
			sh->m_pShadowInfo->m_lScaleY2X	=  convertUnitValue(pCh);
			break;

		case	2:
			sh->m_pShadowInfo->m_lScaleX2Y	= convertUnitValue(pCh);
			break;

		case	3:
			sh->m_pShadowInfo->m_lScaleY2Y	=  convertUnitValue(pCh);
			break;

		case	4:
			sh->m_pShadowInfo->m_lPerspectiveX = convertUnitValue(pCh);
			break;

		case	5:
			sh->m_pShadowInfo->m_lPerspectiveY = convertUnitValue (pCh);
			break;							
		}

		strShadowMatrix += (nPos+1);	nLen += (nPos+1);

		if( nLen > nTotal )
			break;

		nPos = BrStrCpn(strShadowMatrix, ",");

		if( nPos > nTotal )
			nPos = nTotal;

		memcpy(pCh, strShadowMatrix, nPos);
		pCh[nPos] = 0;
		nPosCount++;
	}

	BrFree(pCh);
#endif
	return BrTRUE;
}


///////////////////////////////////////////////////////
CDocxVML::CDocxVML(CDocxConv *pDocxConv, BrBOOL bInGroup)
{
	m_pDocxConv = pDocxConv;
	m_bInGroup = bInGroup;

	m_nShapeType = SHAPE_Rectangle;
	m_nArcSize = 0;

	m_bRoundRect = BrFALSE;

}

CDocxVML::~CDocxVML()
{
}

BrBOOL CDocxVML::CallbackStartElement(LPVOID pParam)
{
	XMLDataDecodeParam* pInfo = (XMLDataDecodeParam*)pParam;

	pInfo->callbackParam.pCurrentInstance = this;

	switch( pInfo->callbackParam.wParam )
	{
	case DOCX_DRAWINFO:
		return readDrawAttribute(pInfo);
	}

	return BrTRUE;
}

BrBOOL CDocxVML::CallbackEndElement(LPVOID pParam)
{ 
	XMLDataDecodeParam* pInfo = (XMLDataDecodeParam*)pParam;

	return BrTRUE;
}

BrBOOL CDocxVML::readDrawInfo(XMLDataDecodeParam*  pInfo)
{
	for( BrINT32 i = 0; pInfo->pElementData->pAttributePairs[i]; i+=2)
	{
		DRAW_RESULT nResult = readObjectInfo(pInfo->pElementData->pAttributePairs[i], pInfo->pElementData->pAttributePairs[i+1]);
		if( DRAW_ETC == nResult )
		{
			const BrCHAR *pStr = pInfo->pElementData->pAttributePairs[i];
			switch(pStr[0])
			{
			case 'a':
				if( 0 == strcmp(pStr, X_DOC_DRAW_ROUNDRECT_ARCSIZE) )
				{
					const BrCHAR *pAttrStr = pInfo->pElementData->pAttributePairs[i+1];
					BrINT32 nLen = BrStrLen(pAttrStr);
					BrFLOAT fArcSize = 0.0f;
					BrINT32 bufCount = nLen + 1;
					if(pAttrStr[nLen-1] == 'f')
					{
						BrCHAR *pBuf = (BrCHAR*)BrMalloc(bufCount);
						memset(pBuf, 0, bufCount);
						memcpy(pBuf, pAttrStr, nLen);
						pBuf[nLen] = 0;

						fArcSize = BrAtoi(pBuf)/65536.0;
						BR_SAFE_FREE(pBuf);
					}
					else if (pAttrStr[nLen-1] == '%')
					{
						BrCHAR *pBuf = (BrCHAR*)BrMalloc(bufCount);
						memset(pBuf, 0, bufCount);
						memcpy(pBuf, pAttrStr, nLen);
						pBuf[nLen] = 0;

						fArcSize = BrAtoi(pBuf)/100.0;
						BR_SAFE_FREE(pBuf);
					}
					else
						fArcSize = BrAtof(pAttrStr);

					m_bRoundRect = BrTRUE;
					m_nArcSize = fArcSize * 100000;
				}
				break;
			}
		}
		else if (nResult == DRAW_FAIL)
			return BrFALSE;
	}

	pInfo->callbackParam.wParam = DOCX_DRAWINFO_CHILD;
	pInfo->callbackParam.pCurrentInstance = this;

	return BrTRUE;
}

CFrame* CDocxVML::convertDraw(const BrCHAR* pCurPackagePartName)
{
	BRect oRect;
	CDocxDrawAttr *pDrawAttr = (CDocxDrawAttr*)this;
	
	if(!pDrawAttr)
		return BrNULL;
	
	pDrawAttr->m_pStyle->getDrawRect(oRect, m_bInGroup);

	CFrame *pFrame = BrNULL;
	if( m_nPenID > 0)
		pFrame = m_pDocxConv->createPenFreeDrawFrame(m_nPenID, oRect);
	else 
	{
		if(m_pFill)
			pFrame = m_pFill->convertFillAttribute(pCurPackagePartName, &oRect, m_nShapeType);
		else
		{
			if(m_pImageData && m_pImageData->m_pID)	
			{

				BrBYTE bClass = PICTUREFRAME;

				pFrame = m_pDocxConv->createImage(oRect, pCurPackagePartName, m_pImageData->m_pID, (m_pStyle->m_nPosition == 0) ? BrTRUE : BrFALSE, BrFALSE, bClass, SHAPE_Rectangle, m_pImageData);
				m_pDocxConv->m_pFrameForOLE = pFrame;

			}
			else
			{
				if(m_pDocxConv->m_bComment)
					pFrame = m_pDocxConv->createFrame(FLOATFRAME, &oRect, BrFALSE, 0, BrTRUE);
				else
					pFrame = m_pDocxConv->createFrame(FLOATFRAME, &oRect, BrFALSE, m_pDocxConv->m_pCurPage ? m_pDocxConv->m_pCurPage->getPageNum() : 1, BrTRUE);

				if( BrNULL == pFrame->getBorder() )
					pFrame->setBorder( BrShape::createShape((int)m_nShapeType, *pFrame->getFrameRect() ));
			}
		}
	}
	pDrawAttr->convertAttribute(pFrame, m_pDocxConv);

	if(!m_bInGroup && (pDrawAttr->m_pStyle->m_nWidthPercent != 0 || pDrawAttr->m_pStyle->m_nHeightPercent != 0))
	{
		pFrame->setWidthRelativeType(pDrawAttr->m_pStyle->m_nWidthRelative);
		pFrame->setWidthRelative(pDrawAttr->m_pStyle->m_nWidthPercent);
		pFrame->setHeightRelativeType(pDrawAttr->m_pStyle->m_nHeightRelative);
		pFrame->setHeightRelative(pDrawAttr->m_pStyle->m_nHeightPercent);

		pFrame->setOrgHeight(pDrawAttr->m_pStyle->m_nHeight);
		pFrame->setOrgWidth(pDrawAttr->m_pStyle->m_nWidth);
	}

	BrShape *pShape = pFrame->getBorder();
	if( !pShape)
		return pFrame;

	if(msosptRoundRectangle == pShape->getBorderStyle())//[2012.09.13][������][TID:9302]RoudRect AdjustValue ����.
	{	
		pShape->setOffice2007Shape(BrTRUE);//[2012.09.13][������][TID:9302]RoudRect�� ��� 2007shape Setting �ʿ���.(�������� DML�� �׷��� ���� ��µ�.)
		pShape->setRuleInfo(0, m_nArcSize);
	}
	//[2013.05.28][������] VML ������ Default�� ������ �Բ� �ؽ�Ʈȸ�� ����.
	pFrame->setDoNotRotateText(BrTRUE);
	if(m_pAltText)
	{
		BString altText;
		altText.setMultiByte(CP_UTF8, m_pAltText);
		pFrame->setAltTextDescription(m_pAltText);
	}

	return pFrame;
}
//////////////////////////////////////////////
CDocxVMLLine::CDocxVMLLine(CDocxConv *pDocxConv, BrBOOL bInGroup)
{
	pointSetBit.reset();
	m_pDocxConv = pDocxConv;
	m_bInGroup = bInGroup;

	m_nFrom.x = m_nFrom.y = 0;
	m_nTo.x = m_nTo.y = 0;
	m_nRegroupID = 0;
	//[M19258][toypilot]stroked flag�� default = ture
	//m_bStroked = m_pDocxConv->getDefaultStorke();
}

CDocxVMLLine::~CDocxVMLLine()
{
}

BrBOOL CDocxVMLLine::CallbackStartElement(LPVOID pParam)
{
	XMLDataDecodeParam* pInfo = (XMLDataDecodeParam*)pParam;

	pInfo->callbackParam.pCurrentInstance = this;

	switch( pInfo->callbackParam.wParam )
	{
	case DOCX_DRAWINFO:
		return readDrawAttribute(pInfo);
	}

	return BrTRUE;
}

BrBOOL CDocxVMLLine::readDrawLineInfo(XMLDataDecodeParam*  pInfo)
{
	if( !pInfo->pElementData->pAttributePairs)
		return BrFALSE;

	for( BrINT32 i = 0; pInfo->pElementData->pAttributePairs[i]; i+= 2)
	{
		DRAW_RESULT nResult = readObjectInfo(pInfo->pElementData->pAttributePairs[i], pInfo->pElementData->pAttributePairs[i+1]);
		if( DRAW_ETC == nResult )
		{
			const BrCHAR *pStr = pInfo->pElementData->pAttributePairs[i];
			switch(pStr[0])
			{
			case 'f':
				if( 0 == strcmp(pStr, X_DOC_DRAW_LINE_FROM) )
				{
					BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
					BrCHAR *pBuf = (BrCHAR*)BrMalloc(nLen+1);
					memcpy(pBuf, pInfo->pElementData->pAttributePairs[i+1], nLen);
					pBuf[nLen] = 0;

					BrCHAR seps[]   = ",";
					char* pContext = BrNULL;
					BrCHAR *ch = strtok_s(pBuf, seps, &pContext);
					BrCHAR* pPtPos = NULL;
					BrCHAR* pInPos = NULL;
					BrINT32 nPtPos;
					BrINT32 nInPos;
					if( ch )
					{
						if(pBuf[0] == ',')
						{
							m_nFrom.x = 0;

							pPtPos = strstr(ch, "pt");
							pInPos = strstr(ch, "in");
							if(pPtPos)
							{
								nPtPos = (BrINT32)(pPtPos - ch);
								ch[nPtPos] = 0;
								m_nFrom.y = CDocxUtil::PTtoTWIPDocx(BrAtof(ch));
							}
							else if(pInPos)
							{
								nInPos = (BrINT32)(pInPos - ch);
								ch[nInPos] = 0;
								m_nFrom.y = INCHtoTWIP(BrAtoi(ch));
							}
							else if(!pPtPos && !pInPos)
								m_nFrom.y = BrAtoi(ch);

							pointSetBit.set(FromToSetBit_From_Y, 1);
						}
						else
						{
							pPtPos = strstr(ch, "pt");
							pInPos = strstr(ch, "in");
							if(pPtPos)
							{
								nPtPos = (BrINT32)(pPtPos - ch);
								ch[nPtPos] = 0;
								m_nFrom.x = CDocxUtil::PTtoTWIPDocx(BrAtof(ch));
							}
							else if(pInPos)
							{
								nInPos = (BrINT32)(pInPos - ch);
								ch[nInPos] = 0;
								m_nFrom.x = INCHtoTWIP(BrAtoi(ch));
							}
							else if(!pPtPos && !pInPos)
								m_nFrom.x = BrAtoi(ch);
							pointSetBit.set(FromToSetBit_From_X, 1);
							ch = strtok_s(NULL, seps, &pContext);
							if( ch )
							{
								pPtPos = strstr(ch, "pt");
								pInPos = strstr(ch, "in");
								if(pPtPos)
								{
									nPtPos = (BrINT32)(pPtPos - ch);
									ch[nPtPos] = 0;
									m_nFrom.y = CDocxUtil::PTtoTWIPDocx(BrAtof(ch));
								}
								else if(pInPos)
								{
									nInPos = (BrINT32)(pInPos - ch);
									ch[nInPos] = 0;
									m_nFrom.y = INCHtoTWIP(BrAtoi(ch));
								}
								else if(!pPtPos && !pInPos)
									m_nFrom.y = BrAtoi(ch);
								pointSetBit.set(FromToSetBit_From_Y, 1);
							}
						}
					}
					BrFree(pBuf);
				}
				break;

			case 't':
				if( 0 == strcmp(pStr, X_DOC_DRAW_LINE_TO) )
				{
					BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
					BrCHAR *pBuf = (BrCHAR*)BrMalloc(nLen+1);
					memcpy(pBuf, pInfo->pElementData->pAttributePairs[i+1], nLen);
					pBuf[nLen] = 0;

					BrCHAR seps[]   = ",";
					char* pContext = BrNULL;
					BrCHAR *ch = strtok_s(pBuf, seps, &pContext);
					BrCHAR* pPtPos = NULL;
					BrCHAR* pInPos = NULL;
					BrINT32 nPtPos;
					BrINT32 nInPos;
					if( ch )
					{
						if(pBuf[0] == ',')
						{
							m_nTo.x  = 0;

							pPtPos = strstr(ch, "pt");
							pInPos = strstr(ch, "in");
							if(pPtPos)
							{
								nPtPos = (BrINT32)(pPtPos - ch);
								ch[nPtPos] = 0;
								m_nTo.y = CDocxUtil::PTtoTWIPDocx(BrAtof(ch));
							}
							else if(pInPos)
							{
								nInPos = (BrINT32)(pInPos - ch);
								ch[nInPos] = 0;
								m_nTo.y = INCHtoTWIP(BrAtoi(ch));
							}
							else if(!pPtPos && !pInPos)
								m_nTo.y = BrAtoi(ch);

							pointSetBit.set(FromToSetBit_To_Y, 1);
						}
						else
						{
							pPtPos = strstr(ch, "pt");
							pInPos = strstr(ch, "in");
							if(pPtPos)
							{
								nPtPos = (BrINT32)(pPtPos - ch);
								ch[nPtPos] = 0;
								m_nTo.x = CDocxUtil::PTtoTWIPDocx(BrAtof(ch));
							}
							else if(pInPos)
							{
								nInPos = (BrINT32)(pInPos - ch);
								ch[nInPos] = 0;
								m_nTo.x = INCHtoTWIP(BrAtoi(ch));
							}
							else if(!pPtPos && !pInPos)
								m_nTo.x = BrAtoi(ch);

							pointSetBit.set(FromToSetBit_To_X, 1);
							ch = strtok_s(NULL, seps, &pContext);
							if( ch )
							{
								pPtPos = strstr(ch, "pt");
								pInPos = strstr(ch, "in");
								if(pPtPos)
								{
									nPtPos = (BrINT32)(pPtPos - ch);
									ch[nPtPos] = 0;
									m_nTo.y = CDocxUtil::PTtoTWIPDocx(BrAtof(ch));
								}
								else if(pInPos)
								{
									nInPos = (BrINT32)(pInPos - ch);
									ch[nInPos] = 0;
									m_nTo.y = INCHtoTWIP(BrAtoi(ch));
								}
								else if(!pPtPos && !pInPos)
									m_nTo.y = BrAtoi(ch);

								pointSetBit.set(FromToSetBit_To_Y, 1);
							}
						}
					}
					BrFree(pBuf);
				}
				break;
			}
		}
		else if (nResult == DRAW_FAIL)
			return BrFALSE;
	}
	return BrTRUE;
}

CFrame* CDocxVMLLine::convertDrawLine()
{
	BrBOOL bAnchorType = BrFALSE;
	BrBOOL bFlipX = BrFALSE;
	BRect Rect;

	CDocxDrawAttr *pDrawAttr = (CDocxDrawAttr*)this;
	if(m_bInGroup)
		Rect.setRect(m_nFrom.x, m_nFrom.y, m_nTo.x, m_nTo.y);
	else
		Rect.setRect(0, 0, m_nTo.x - m_nFrom.x, m_nTo.y - m_nFrom.y);

	CFrame *pFrame = m_pDocxConv->createFrame(FLOATFRAME, &Rect, bAnchorType, m_pDocxConv->m_pCurPage->getPageNum(), BrTRUE);
	if(!pFrame)
		return BrNULL;

	BrShape *pBwpShape = BrShape::createShape(SHAPE_Line, &Rect);
	if( !pBwpShape)
		return BrNULL;
	pFrame->setBorder( pBwpShape );

	pDrawAttr->convertGrapAtt(pFrame, BrTRUE);

	if(!pDrawAttr->m_pStyle)
	{
		//�Լ� ���� �������� ��üũ�� �����ص� �ش� �κп� ������ ��� �޸𸮸� ħ���ϴ� ������ ����
		BRTHREAD_ASSERT(0);
		return BrNULL;
	}
	else
	{
		pDrawAttr->m_pStyle->convertStyleAttr(pFrame, m_pDocxConv);
	}

	if( pDrawAttr->m_pStyle->m_nPosition == 0 )
	{
		pFrame->setAnchorFlag(BrTRUE);
		if(!pDrawAttr->m_bInGroup)	
			m_pDocxConv->m_nCurParaHgt += pFrame->height();
	}
	else
	{
		if(pDrawAttr->m_pStyle)
			pDrawAttr->m_pStyle->ConvertFramePosition(pFrame, m_nFrom.x, m_nFrom.y);
		
		if(pDrawAttr->m_nWrappingMode > -1)
			pFrame->setRunArroundType(static_cast<RunAroundTypes>(pDrawAttr->m_nWrappingMode));
	}

	return pFrame;
}



//////////////////////////////////////////////
CDocxVMLPolyLine::CDocxVMLPolyLine(CDocxConv *pDocxConv, BrBOOL bInGroup)
{
	m_pDocxConv = pDocxConv;

	m_bCloseure = BrFALSE;
	m_bCurve = BrFALSE;

	m_nCoordSizeX = 1000;
	m_nCoordSizeY = 1000;

	m_nCount = 0;
	m_pPoints = NULL;
	m_bInGroup = bInGroup;
	m_bStroked = BrTRUE;
}

CDocxVMLPolyLine::~CDocxVMLPolyLine()
{
	if(m_pPoints)		BR_SAFE_FREE(m_pPoints);
}

BrBOOL CDocxVMLPolyLine::CallbackStartElement(LPVOID pParam)
{
	XMLDataDecodeParam* pInfo = (XMLDataDecodeParam*)pParam;
	switch( pInfo->callbackParam.wParam )
	{
	case DOCX_DRAWINFO:
		return readDrawAttribute(pInfo);
	}

	return BrTRUE;
}

BrBOOL CDocxVMLPolyLine::readDrawPolyLineInfo(XMLDataDecodeParam*  pInfo)
{
	if( !pInfo->pElementData->pAttributePairs)
		return BrFALSE;

	BrINT32 nLen;
	BrCHAR *pBuf;
	for( BrINT32 i = 0; pInfo->pElementData->pAttributePairs[i]; i+= 2)
	{
		DRAW_RESULT nResult = readObjectInfo(pInfo->pElementData->pAttributePairs[i], pInfo->pElementData->pAttributePairs[i+1]);
		if( DRAW_ETC == nResult )
		{
			const BrCHAR *pStr = pInfo->pElementData->pAttributePairs[i];
			switch(pStr[0])
			{
			case 'p':
				if( 0 == strcmp(pStr, X_DOC_DRAW_POLYLINE_POINTS) )
				{
					nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
					if(nLen == 0)
						continue;
					pBuf = (BrCHAR*)BrMalloc(nLen+1);
					memcpy(pBuf, pInfo->pElementData->pAttributePairs[i+1], nLen);
					pBuf[nLen] = 0;
					BrCHAR *pTmp = pBuf;
					BrCHAR* pMatch = strchr(pTmp, ',');
					if( !pMatch) {//2012-10-04 �Ｚ���ȹ��� ���� ���� - �ݵ�� �Ѱ��̻��� ','�� �����ؾ����� ������ ��! (SPEC)
						BrFree(pBuf);
						SET_ERROR((PoError)kPoErrCorruptFile, "Adjust Value incorrect");
						BoraPackageBase::CurruptedXmlParser(m_pDocxConv);
						return BrFALSE;
					}

					BrCHAR cCh[64];
					BrINT32 nTotalLen = BrStrLen(pTmp);

					BrINT32 nCount = 0;
					BrINT32 nPos;
					while(pTmp < pBuf + nTotalLen)
					{
						pMatch = strchr(pTmp, ',');
						if( pMatch )
							nPos = (BrINT32)(pMatch - pTmp);
						else
							nPos = BrStrLen(pTmp);

						pTmp += (nPos+1);
						nCount++;
					}

					m_nCount = nCount;
					m_pPoints = (BrINT32*)BrMalloc(nCount*BrSizeOf(BrINT32));

					nCount = 0;
					pTmp = pBuf;
					BrCHAR* pPtPos = NULL;
					BrCHAR* pInPos = NULL;
					BrINT32 nPtPos;
					BrINT32 nInPos;
					while(pTmp < pBuf + nTotalLen)
					{
						pMatch = strchr(pTmp, ',');
						if( pMatch )
							nPos = (BrINT32)(pMatch - pTmp);
						else
							nPos = BrStrLen(pTmp);

						memset(cCh, 0, 20);
						strncpy_s(cCh, 20, pTmp, nPos);
						cCh[nPos] = 0;

						pPtPos = strstr(cCh, "pt");
						pInPos = strstr(cCh, "in");
						if(pPtPos)
						{
							nPtPos = (BrINT32)(pPtPos - cCh);
							cCh[nPtPos] = 0;
							m_pPoints[nCount++] = CDocxUtil::PTtoTWIPDocx(BrAtof(cCh));
						}
						else if(pInPos)
						{
							nInPos = (BrINT32)(pInPos - cCh);
							cCh[nInPos] = 0;
							m_pPoints[nCount++] = INCHtoTWIP(BrAtoi(cCh));
						}
						else if(!pPtPos && !pInPos)
							m_pPoints[nCount++] = BrAtoi(cCh);

						pTmp += (nPos+1);
					}

					BrFree(pBuf);
				}
				break;
			case 'c':
				if( 0 == strcmp(pStr, X_DOC_DRAW_SHAPE_COORDSIZE) )
				{
					nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
					pBuf = (BrCHAR*)BrMalloc(nLen+1);
					memcpy(pBuf, pInfo->pElementData->pAttributePairs[i+1], nLen);
					pBuf[nLen] = 0;

					BrCHAR seps[]   = ",";
					char* pContext = BrNULL;
					BrCHAR *ch = strtok_s(pBuf, seps, &pContext);
					if( ch )
					{
						if(pBuf[0] == ',')
						{
							m_nCoordSizeX = 1000;
							m_nCoordSizeY = BrAtoi(ch);
						}
						else
						{
							m_nCoordSizeX = BrAtoi(ch);
							ch = strtok_s(NULL, seps, &pContext);
							if(ch)
								m_nCoordSizeY = BrAtoi(ch);
						}
					}
					BrFree(pBuf);
				}
				break;
			}
		}
		else if (nResult == DRAW_FAIL)
			return BrFALSE;
	}

	return BrTRUE;
}

CFrame* CDocxVMLPolyLine::convertDrawPolyLine()
{
	//jjoo:2009-07-01:polyline������ �׷����� ����� shape(docx Ÿ��)�� �Ӽ��� ���Ѵ�.
	//�׷��Ƿ� ���⼭�� �׷쿡 ���� ó���� ���� �ʾƵ� �ȴ�.
	BrINT32 i = 0, j = 0, nMinX = 0, nMinY = 0;
	BrINT32 nCount = m_nCount/2;
	BrPOINT *pPoints = (BrPOINT*)BrMalloc(nCount*BrSizeOf(BrPOINT));
	for( i = 0, j = 0; i < nCount; i++)
	{
		pPoints[i].x = m_pPoints[j++];
		pPoints[i].y = m_pPoints[j++];

		if( 0 == i )
		{
			nMinX = pPoints[i].x;
			nMinY = pPoints[i].y;
		}
		else
		{
			nMinX = (nMinX > pPoints[i].x) ? pPoints[i].x : nMinX;
			nMinY = (nMinY > pPoints[i].y) ? pPoints[i].y : nMinY;
		}
	}

	BrBOOL bAnchorType = BrFALSE;
	BrBOOL bCreatEds = BrFALSE;
	BRect Rect(0, 0, m_nCoordSizeX, m_nCoordSizeY);
	CFrame *pFrame = m_pDocxConv->createFrame(FLOATFRAME, &Rect, bAnchorType, m_pDocxConv->m_pCurPage->getPageNum(), bCreatEds);
	if(!pFrame)
	{
		BR_SAFE_FREE(pPoints);
		return BrNULL;
	}

	BrShape *pBwpShape = BrShape::createShape((ShapeType)SHAPE_NotchedCircularArrow, *pFrame->getFrameRect());
	pFrame->setBorder( pBwpShape );

	//2012-09-18 convertGrapAttForDraw�Լ��� ����
	CDocxDrawAttr *pDrawAttr = (CDocxDrawAttr*)this;
	pDrawAttr->convertGrapAtt(pFrame, BrTRUE);

	BrShape* pSh = pFrame->getBorder();
	if(pSh)
	{
		//vertex
		BrShapeProperty sPro;
		BArray<BrShapeVertices>* pCoordinates = BrNEW BArray<BrShapeVertices>;
		pCoordinates->resize(nCount);
		for(BrINT32 i=0; i < nCount; i++)
		{
			BrShapeVertices* pCoord = pCoordinates->GetAt(i);

			pCoord->vertex1.nType = eShapeNormalVertex;
			pCoord->vertex1.nValue = pPoints[i].x - nMinX;
			pCoord->vertex2.nType = eShapeNormalVertex;
			pCoord->vertex2.nValue = pPoints[i].y - nMinY;
		}
		sPro.nType = eShapeCoordinates;
		sPro.pPro = pCoordinates;

		pSh->getGeometryAttrs().Add(sPro);

		//segment
		BArray<BrShapeSegment>*	pSegments = BrNEW BArray<BrShapeSegment>;
		pSegments->resize(3);
		BrShapeSegment* pSegment = pSegments->GetAt(0);
		pSegment->nCmd = eGlyphPathMoveTo;
		pSegment->nCnt = 1;
		pSegment = pSegments->GetAt(1);
		pSegment->nCmd = eGlyphPathLineTo;
		pSegment->nCnt = nCount - 1;
		pSegment = pSegments->GetAt(2);
		pSegment->nCmd = 0;

		sPro.nType = eShapeSegment;
		sPro.pPro = pSegments;

		pSh->getGeometryAttrs().Add(sPro);

		//set viewbox
		if(m_nCoordSizeX ||m_nCoordSizeY)
		{
			BrRect *pRect = (BrRect*) BrMalloc(BrSizeOf(BrRect));
			memset(pRect,0,BrSizeOf(BrRect));

			if(m_nCoordSizeX)
				pRect->right = m_nCoordSizeX;

			if(m_nCoordSizeY)
				pRect->bottom = m_nCoordSizeY;

			sPro.nType = eShapeViewBox;
			sPro.pPro = pRect;

			pSh->getGeometryAttrs().Add(sPro);
		}
	}

	if(pDrawAttr->m_pStyle)
	{
		//jjoo:2009-05-28:Style�� Position�� static(=0)�̸� �ؽ�Ʈ �پ��̴�.
		if( pDrawAttr->m_pStyle->m_nPosition == 0 )
		{
			pFrame->setAnchorFlag(BrTRUE);
			if(!m_bInGroup)	
				m_pDocxConv->m_nCurParaHgt += pFrame->height();
		}
		else
		{
			//jjoo:2009-07-02:polyline���� Margin-left�� Margin-top���� ����.
			//�տ��� ����� nMinX�� nMinY�� Margin-left�� Margin-top���� setting
			pDrawAttr->m_pStyle->m_nMarginLeft = nMinX;
			pDrawAttr->m_pStyle->m_nMarginTop = nMinY;
			m_pDocxConv->setFloatingFrameInfo(pFrame, pDrawAttr->m_pStyle);
		}
	}

	BrFree(pPoints);
	pFrame->setAllowOverlap(m_bAllowOverlap);

	return pFrame;
}

/////////////////////////////////////////////////////////////////////////
//DrawObject
CDocxOfficeDraw::CDocxOfficeDraw(CDocxConv *pDocxConv, CDocxTextRun *pTextRun, CFrame* a_pInkMLFrame)
{
	m_pDocxConv = pDocxConv;
	m_pTextRun = pTextRun;

	m_bInGroup = BrFALSE;
	m_pDocxShape = BrNULL;
	m_pInkMLFrame = a_pInkMLFrame;

#ifdef USE_DOCX_UNIQUEID
	m_nCollaborationSPID = -1;
#endif // !USE_DOCX_UNIQUEID

}

CDocxOfficeDraw::~CDocxOfficeDraw()
{

}

BrBOOL CDocxOfficeDraw::CallbackStartElement(LPVOID pParam)
{
	XMLDataDecodeParam* pInfo = (XMLDataDecodeParam*)pParam;
	pInfo->callbackParam.pCurrentInstance = this;

	switch( pInfo->callbackParam.wParam )
	{
	case DOCX_OLEOBJECT:
	case DOCX_VMLOBJECT:
		return readDrawObject(pInfo);
	}

	return BrTRUE;
}

BrBOOL CDocxOfficeDraw::CallbackEndElement(LPVOID pParam)
{
	XMLDataDecodeParam* pInfo = (XMLDataDecodeParam*)pParam;
	const char *pName = trimNamespace(pInfo->pElementData->pElementName);

	CFrame *pFrame = BrNULL;
	switch(pName[0])
	{
	case 'r':
	case 'o':
		if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_RECT) || 
			0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_ROUNDRECT) || 
			0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_OVAL) )
		{
			if( strcmp(pInfo->pCurPackagePartName, "word/numbering.xml") == 0 )
				break;

			CDocxVML *pDocxDraw = (CDocxVML *)pInfo->callbackParam.pCurrentInstance;
			if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_ROUNDRECT))
				pDocxDraw->m_nShapeType = SHAPE_RoundRectangle;
			if(pDocxDraw && pDocxDraw->m_pStyle && pDocxDraw->m_pStyle->m_bVisibility)
			{
				pFrame = pDocxDraw->convertDraw(pInfo->pCurPackagePartName);
			}

			BrDELETE pDocxDraw;
		}
		break;

	case 'l':
		if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_LINE) )
		{
			CDocxVMLLine *pDocxDrawLine = (CDocxVMLLine *)pInfo->callbackParam.pCurrentInstance;
			if(pDocxDrawLine && pDocxDrawLine->m_pStyle && pDocxDrawLine->m_pStyle->m_bVisibility)
			{
				pFrame = pDocxDrawLine->convertDrawLine();
			}

			BrDELETE pDocxDrawLine;
		}
		break;
	case 'p':
		if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_POLYLINE) )
		{
			CDocxVMLPolyLine *pDrawPoly = (CDocxVMLPolyLine *)pInfo->callbackParam.pCurrentInstance;
			if(pDrawPoly && pDrawPoly->m_pStyle && pDrawPoly->m_pStyle->m_bVisibility)
			{
				pFrame = pDrawPoly->convertDrawPolyLine();
			}

			BrDELETE pDrawPoly;
		}
		break;

	case 'g':
		if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_GROUP))
		{
			CDocxGroup *pDocxGroup = (CDocxGroup *)pInfo->callbackParam.pCurrentInstance;

			if( pDocxGroup && pDocxGroup->m_pStyle && pDocxGroup->m_pStyle->m_nPosition == 0 )
			{
				if(pDocxGroup->m_pGroupFrame)
				{
					pDocxGroup->m_pGroupFrame->setAnchorFlag(BrTRUE);

					if(!m_bInGroup)	
						m_pDocxConv->m_nCurParaHgt += pDocxGroup->m_pGroupFrame->height();
				}
			}
			else
			{
				if(pDocxGroup)
					m_pDocxConv->setFloatingFrameInfo(pDocxGroup->m_pGroupFrame, pDocxGroup->m_pStyle, pDocxGroup->m_nWrappingMode);
			}

			if(pDocxGroup && pDocxGroup->m_pStyle && pDocxGroup->m_pStyle->m_bVisibility)
			{
				pFrame = pDocxGroup->m_pGroupFrame;

#ifdef DOCX_SPID
				if(pDocxGroup->m_pID)
				{
					BrCHAR pBuf[8] = {0};
					BrUINT32 nSize = BrStrLen(pDocxGroup->m_pID);

					for(BrINT32 i = 8, j = 0 ; i < nSize ; i++, j++)
						pBuf[j] = pDocxGroup->m_pID[i];
					
					pFrame->setDocxSpid(BrAtoi(pBuf));
				}
#endif //DOCX_SPID
				pDocxGroup->m_pGroupFrame = BrNULL;
			}

			BrDELETE pDocxGroup;
		}
		break;

	case 'O':
		if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_OLEOBJECT)) //o:OLEObject
		{
			BrCHAR *rID = BrNULL;
			BrCHAR* pProgID = BrNULL;
			BrBOOL drawAspect = 1; //0 == contents, 1 == icon
			if( pInfo->pElementData->pAttributePairs)
			{
				for( BrINT32 i = 0; pInfo->pElementData->pAttributePairs[i]; i+= 2)
				{
					if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], X_RID) )
					{
						BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
						if(rID == BrNULL)
							rID = (BrCHAR*)BrMalloc(nLen+1);
						memcpy(rID, pInfo->pElementData->pAttributePairs[i+1], nLen);
						rID[nLen] = 0;
					}
					else if(0 == strcmp(pInfo->pElementData->pAttributePairs[i], "ProgID"))
					{
						BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
						if(pProgID == BrNULL)
							pProgID = (BrCHAR*)BrMalloc(nLen+1);
						memcpy(pProgID, pInfo->pElementData->pAttributePairs[i+1], nLen);
						pProgID[nLen] = 0;
					}
					else if (0 == strcmp(pInfo->pElementData->pAttributePairs[i], "DrawAspect"))
					{
						if (0 == strcmp(pInfo->pElementData->pAttributePairs[i + 1], "Content"))
							drawAspect = 0;
					}
				}
			}
			if(!rID)
			{
				BR_SAFE_FREE(pProgID);
				break;
			}
			BString strRelID(rID);
			BString	strCurPartName(pInfo->pCurPackagePartName);
			if( m_pDocxConv->m_pFrameForOLE) //[M-17013]
			{
				m_pDocxConv->m_pFrameForOLE->setSubFrame(m_pDocxConv->m_pPackage->GetOLELoader(strCurPartName, strRelID));
				m_pDocxConv->m_pFrameForOLE->setOLE(BrTRUE);
				m_pDocxConv->m_pFrameForOLE->setClass(OLEFRAME);
				if(pProgID)
				{
					BrOLEFileLoader* pFileLoader = (BrOLEFileLoader*) m_pDocxConv->m_pFrameForOLE->getSubFrame();
					if(pFileLoader)
					{
						BString strProID(pProgID);
						pFileLoader->SetProgID(strProID);
						pFileLoader->SetShowAsIcon(drawAspect);
					}					
				}
				//Test LoadOLE
				//((BrOLELoadingBase*)m_pDocxConv->m_pFrameForOLE->getSubFrame())->LoadOLE();
			}
			BR_SAFE_FREE (rID);
			BR_SAFE_FREE(pProgID);
		}
		break;
	case 's':
		if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_SHAPE) )
		{
			if( strcmp(pInfo->pCurPackagePartName, "word/numbering.xml") == 0 )
				m_pDocxShape->m_bBullet = BrTRUE;

			if(m_pInkMLFrame)
				AddInkMLImage(pInfo);
			else if(m_pDocxShape && m_pDocxShape->m_bBullet && !m_pDocxConv)
				break;
			else
				pFrame = convertDrawShape(pInfo);
			
		}
		break;
	}

	if( pFrame )
	{
#ifdef USE_DOCX_UNIQUEID
		if(m_nCollaborationSPID != -1)
		{
			pFrame->setSpid(m_nCollaborationSPID);
		}
#endif // !USE_DOCX_UNIQUEID

		AddShapeCRNode(pFrame);
		m_pDocxConv->setDrawObjInfo(pFrame, m_pTextRun->m_wBwpTextID);//[2012.06.22][������][TID:7270] ���� TextAttr ���� ����
		//[2013.02.27][������][M-24467] �׷�� VML���� Rotation ����
 		if(pFrame->isGroup())
		{
			theBWordDoc->getCmdEngine()->convertGroupSubFramesMSToBWP(pFrame);
			setChildFrameGroupParent(pFrame);
		}
	}

	return BrTRUE;
}

BrBOOL CDocxOfficeDraw::AddShapeCRNode(CFrame* a_pFrame)
{
	if(a_pFrame == BrNULL)
		return BrFALSE;
	if(a_pFrame->GetClass() == OLEFRAME || a_pFrame->GetClass() == PENDRAWFRAME)
		return BrTRUE;

	BrShape* pBrShape = (BrShape*)a_pFrame->getBorder();
	BrINT32 nShapeType = pBrShape->getBorderStyle();

	//wordArt�� ���
	if((nShapeType >= SHAPE_TextPlainText && nShapeType<=SHAPE_TextCanDown) || a_pFrame->GetClass() == PICTUREFRAME || a_pFrame->isGroup()|| (m_pDocxShape && m_pDocxShape->m_bBullet))
		return BrTRUE;

	CLineList* pLineList = (CLineList*)a_pFrame->getSubFrame();
	if(pLineList && pLineList->getTotalLine() > 0)
		return BrTRUE;

	if(pLineList == BrNULL)
		pLineList = ftLibrary::CreateLineList(a_pFrame);

	CLine* pLine = ftLibrary::CreateLine(pLineList);
	ftLibrary::AddCharSet(pLine, ASCII_CODE_CR);

	return BrTRUE;
}

//BrBOOL CDocxOfficeDraw::ReCalcDrawBoundary(CFrame*	a_pGroupFrame)
//{
//	CFrameList* pFrameList = a_pGroupFrame->getSubFrame();
//	BrINT32 i, nSize = pFrameList->getTotalFrame();
//	BRect oSubRc(0, 0, 0, 0);
//
//	CFrame* pFrame = pFrameList->getFirst();
//	for(i = 0; i < nSize; i++ )
//	{
//		BRect* pRc = pFrame->getFrameRect();
//		if( oSubRc.nLeft > pRc->nLeft )
//			oSubRc.nLeft = pRc->nLeft;
//		if( oSubRc.nTop > pRc->nTop )
//			oSubRc.nTop = pRc->nTop;
//		if( oSubRc.nBottom < pRc->nBottom )
//			oSubRc.nBottom = pRc->nBottom;
//		if( oSubRc.nRight < pRc->nRight )
//			oSubRc.nRight = pRc->nRight;
//
//		pFrame = pFrame->getNext();
//	}
//
//	if(oSubRc != *a_pGroupFrame->getFrameRect())
//	{
//		int k = 0; 
//	}
//}

BrBOOL CDocxOfficeDraw::readDrawObject(XMLDataDecodeParam* pInfo)
{
	const char* pName = trimNamespace(pInfo->pElementData->pElementName);
	switch(pName[0])
	{
#ifdef USE_DOCX_UNIQUEID
	case 'C':
		if( 0 == strcmp(pInfo->pElementData->pElementName, "v:CollaborationSPID"))
		{
			if( pInfo->pElementData->pAttributePairs)
			{
				for( BrINT32 i = 0; pInfo->pElementData->pAttributePairs[i]; i+= 2)
				{
					if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], X_VALUE) )
					{
						m_nCollaborationSPID = BrAtoi(pInfo->pElementData->pAttributePairs[i+1]);
					}
				}
			}
		}
		break;
#endif // USE_DOCX_UNIQUEID
	case 'g':
		if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_GROUP))
		{
			CDocxGroup *pDocxGroup = BrNEW CDocxGroup(m_pDocxConv);
			if(!pDocxGroup)
			{
				pInfo->nElementOption |= BR_XML_SKIP_ELEMENT;
				return BrFALSE;
			}

			pDocxGroup->readDrawGroupInfo(pInfo);
			pDocxGroup->MakeDrawGroup();

			pInfo->callbackParam.pCurrentInstance = pDocxGroup;
			pInfo->nElementOption |= BR_XML_NEED_END_ELEMENT;
		}
		else
			pInfo->nElementOption |= BR_XML_SKIP_ELEMENT;
		break;
	case 'l':
		if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_LINE)) //line
		{
			CDocxVMLLine *pDrawLine = BrNEW CDocxVMLLine(m_pDocxConv);
			if(!pDrawLine)
			{
				pInfo->nElementOption |= BR_XML_SKIP_ELEMENT;
				return BrFALSE;
			}
			pDrawLine->readDrawLineInfo(pInfo);

			pInfo->callbackParam.wParam = DOCX_DRAWINFO;
			pInfo->callbackParam.pCurrentInstance = pDrawLine;
			pInfo->nElementOption |= BR_XML_NEED_END_ELEMENT;
		}
		break;
	case 'o':
		if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_OVAL)) //circle
		{
			CDocxVML *pDrawEllipse = BrNEW CDocxVML(m_pDocxConv);		
			if(!pDrawEllipse)
			{
				pInfo->nElementOption |= BR_XML_SKIP_ELEMENT;
				return BrFALSE;
			}
			pDrawEllipse->m_nShapeType = SHAPE_Ellipse;
			pDrawEllipse->readDrawInfo(pInfo);

			pInfo->callbackParam.wParam = DOCX_DRAWINFO;
			pInfo->callbackParam.pCurrentInstance = pDrawEllipse;
			pInfo->nElementOption |= BR_XML_NEED_END_ELEMENT;
		}
		else
			pInfo->nElementOption |= BR_XML_SKIP_ELEMENT;

		break;
	case 'O':
		if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_OLEOBJECT)) //o:OLEObject
		{
#ifdef SUPPORT_2007_OLE 
			BrCHAR *rID = BrNULL;
			BrCHAR* pProgID = BrNULL;
			BrBOOL drawAspect = 1; //0 == contents, 1 == icon
			if( pInfo->pElementData->pAttributePairs)
			{
				for( BrINT32 i = 0; pInfo->pElementData->pAttributePairs[i]; i+= 2)
				{
					if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], X_RID) )
					{
						BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
						if(rID == BrNULL)
							rID = (BrCHAR*)BrMalloc(nLen+1);
						memcpy(rID, pInfo->pElementData->pAttributePairs[i+1], nLen);
						rID[nLen] = 0;
					}
					else if(0 == strcmp(pInfo->pElementData->pAttributePairs[i], "ProgID"))
					{
						BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
						if(pProgID == BrNULL)
							pProgID = (BrCHAR*)BrMalloc(nLen+1);
						memcpy(pProgID, pInfo->pElementData->pAttributePairs[i+1], nLen);
						pProgID[nLen] = 0;
					}
					else if (0 == strcmp(pInfo->pElementData->pAttributePairs[i], "DrawAspect"))
					{
						if (0 == strcmp(pInfo->pElementData->pAttributePairs[i + 1], "Content"))
							drawAspect = 0;
					}
				}
			}
			if(!rID)
			{
				BR_SAFE_FREE(pProgID);
				break;
			}
			BString strRelID(rID);
			BString	strCurPartName(pInfo->pCurPackagePartName);
			if( m_pDocxConv->m_pFrameForOLE) //[M-17013]
			{
				m_pDocxConv->m_pFrameForOLE->setSubFrame(m_pDocxConv->m_pPackage->GetOLELoader(strCurPartName, strRelID));
				m_pDocxConv->m_pFrameForOLE->setOLE(BrTRUE);
				m_pDocxConv->m_pFrameForOLE->setClass(OLEFRAME);
				if(pProgID)
				{
					BrOLEFileLoader* pFileLoader = (BrOLEFileLoader*) m_pDocxConv->m_pFrameForOLE->getSubFrame();
					if(pFileLoader)
					{
						BString strProID(pProgID);
						pFileLoader->SetProgID(strProID);
						pFileLoader->SetShowAsIcon(drawAspect);
					}					
				}
				//Test LoadOLE
				//((BrOLELoadingBase*)m_pDocxConv->m_pFrameForOLE->getSubFrame())->LoadOLE();
			}
			BR_SAFE_FREE (rID);
			BR_SAFE_FREE(pProgID);
#else
			BCOfficeXGraphicData*	pGraphicData = BrNEW BCOfficeXGraphicOle(m_pDocxConv->m_pPackage);

			((BCOfficeXGraphicOle*)pGraphicData)->m_strSrcPartName = pInfo->pCurPackagePartName;

			for (BrINT32 i = 0; pInfo->pElementData->pAttributePairs[i]; i += 2)
			{
				if( strcmp("r:id", pInfo->pElementData->pAttributePairs[i])==0 )
					((BCOfficeXGraphicOle*)pGraphicData)->m_strRelID = pInfo->pElementData->pAttributePairs[i+1];
				else if( strcmp("imgH", pInfo->pElementData->pAttributePairs[i])==0 )
					((BCOfficeXGraphicOle*)pGraphicData)->m_nImgWidth = (BrLONG)EMUtoTWIP_DOUBLE(strtod(pInfo->pElementData->pAttributePairs[i+1], BrNULL));
				else if( strcmp("imgW", pInfo->pElementData->pAttributePairs[i])==0 )
					((BCOfficeXGraphicOle*)pGraphicData)->m_nImgHeight = (BrLONG)EMUtoTWIP_DOUBLE(strtod(pInfo->pElementData->pAttributePairs[i+1], BrNULL));
				else if( strcmp("name", pInfo->pElementData->pAttributePairs[i])==0 )
					((BCOfficeXGraphicOle*)pGraphicData)->m_strObjName = pInfo->pElementData->pAttributePairs[i+1];
				else if( strcmp("progId", pInfo->pElementData->pAttributePairs[i])==0 )
					((BCOfficeXGraphicOle*)pGraphicData)->m_strPropID = pInfo->pElementData->pAttributePairs[i+1];
				else if( strcmp("spid", pInfo->pElementData->pAttributePairs[i])==0 )
					((BCOfficeXGraphicOle*)pGraphicData)->m_strShapeID = pInfo->pElementData->pAttributePairs[i+1];
				else if( strcmp("showAsIcon", pInfo->pElementData->pAttributePairs[i])==0 )
					((BCOfficeXGraphicOle*)pGraphicData)->m_bShowAsIcon = BrAtoi((BrCHAR*)pInfo->pElementData->pAttributePairs[i+1]);
			}

			pInfo->callbackParam.pCurrentInstance = pGraphicData;
			pInfo->callbackParam.wParam = DOCX_DRAWINFO;
			pInfo->nElementOption |= BR_XML_NEED_END_ELEMENT;
#endif

		}
		else
			pInfo->nElementOption |= BR_XML_SKIP_ELEMENT;

		break;
	case 'p':
		if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_POLYLINE)) //polyline
		{
			CDocxVMLPolyLine *pDrawPoly = BrNEW CDocxVMLPolyLine(m_pDocxConv);
			if(!pDrawPoly)
			{
				pInfo->nElementOption |= BR_XML_SKIP_ELEMENT;
				return BrFALSE;
			}
			pDrawPoly->readDrawPolyLineInfo(pInfo);

			pInfo->callbackParam.wParam = DOCX_DRAWINFO;
			pInfo->callbackParam.pCurrentInstance =pDrawPoly;
			pInfo->nElementOption |= BR_XML_NEED_END_ELEMENT;
		}
		else//X_DOC_DRAW_PATH
			pInfo->nElementOption |= BR_XML_SKIP_ELEMENT;

		break;
	case 'r':
		if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_RECT) ||//v:rect rectangle
			0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_ROUNDRECT)) //round rectangle
		{
			CDocxVML *pDrawRect = BrNEW CDocxVML(m_pDocxConv);
			if(!pDrawRect)
			{
				pInfo->nElementOption |= BR_XML_SKIP_ELEMENT;
				return BrFALSE;
			}

			pDrawRect->readDrawInfo(pInfo);

			pInfo->callbackParam.wParam = DOCX_DRAWINFO;
			pInfo->callbackParam.pCurrentInstance = pDrawRect;
			pInfo->nElementOption |= BR_XML_NEED_END_ELEMENT;
		}
		else
			pInfo->nElementOption |= BR_XML_SKIP_ELEMENT;
		break;
	case 's':
		//shapetype�� �ִ� �Ӽ��� setting
		if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_SHAPETYPE))
		{
			if( !m_pDocxShape) {
				m_pDocxShape = BrNEW CDocxShape(m_pDocxConv, BrTRUE);
				if(!m_pDocxShape)
				{
					pInfo->nElementOption |= BR_XML_SKIP_ELEMENT;
					return BrFALSE;
				}

				((CDocxDrawAttr*)m_pDocxShape)->readDrawShapeType(pInfo);
			}
		}
		else if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_SHAPE))
		{
			if( !m_pDocxShape) {
				m_pDocxShape = BrNEW CDocxShape(m_pDocxConv, BrTRUE);
				if(!m_pDocxShape)
				{
					pInfo->nElementOption |= BR_XML_SKIP_ELEMENT;
					return BrFALSE;
				}
				//m_pDocxShape->m_bStroked = m_pDocxConv->getDefaultStorke();
			}

			m_pDocxShape->readDrawShapeInfo(pInfo);

			pInfo->callbackParam.wParam = DOCX_DRAWINFO;
			pInfo->callbackParam.pCurrentInstance = (CDocxDrawAttr*)m_pDocxShape;
			pInfo->nElementOption |= BR_XML_NEED_END_ELEMENT;
		}
		else if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_STROKE))
		{
			CDocxDrawAttr *pDrawAttr = (CDocxDrawAttr*)m_pDocxShape;
			if(!pDrawAttr->m_pStroke ) {
				pDrawAttr->m_pStroke = BrNEW CDocxDrawStroke();
				if(!pDrawAttr->m_pStroke)
				{
					pInfo->nElementOption |= BR_XML_SKIP_ELEMENT;
					return BrFALSE;
				}
			}

			pDrawAttr->m_pStroke->readStrokeInfo(pInfo);
		}
		else
			pInfo->nElementOption |= BR_XML_SKIP_ELEMENT;

		break;		
	default:
		pInfo->nElementOption |= BR_XML_SKIP_ELEMENT;
		break;
	}

	return BrTRUE;
}

CFrame*	CDocxOfficeDraw::convertDrawGroup(CDocxGroup *pDocxGroup, BrBOOL bInGroup)
{
	if(!pDocxGroup || !pDocxGroup->m_pStyle)
		return NULL;

	CDocxDrawStyle* pStyle = pDocxGroup->m_pStyle;
	CFrame *pFrame = NULL;

	if(pStyle->m_nWidthPercent)
	{
		BrLONG basicFrameWidth = m_pDocxConv->m_pCurPage->getBFrameList()->getLast()->getFrameRect()->getWidth();
		pDocxGroup->m_pStyle->m_nWidth = (BrINT32)(basicFrameWidth * pStyle->m_nWidthPercent);
	}
	//[2012-08-17][toypilot][T-8434]group���� ��� ��ġ ���� ����
	if (pStyle->m_dMarginTopPercent && (!pStyle->m_bMarginTop || pStyle->m_nMarginTop == 0))
	{
		BrLONG basicHeight = 0;
		if (MSO_PAGE == pStyle->m_nPosVerRel)
			basicHeight = m_pDocxConv->m_pCurPage->getPaperSize()->height();

		pStyle->m_nMarginTop = (BrINT32)((basicHeight * pStyle->m_dMarginTopPercent) / 100);
	}
	if (pStyle->m_dMarginLeftPercent && (!pStyle->m_bMarginLeft || pStyle->m_nMarginLeft == 0))
	{
		BrLONG basicWidth = 0;
		if (MSO_PAGE == pStyle->m_nPosHorRel)
			basicWidth = m_pDocxConv->m_pCurPage->getPaperSize()->width();
		pStyle->m_nMarginLeft = (BrINT32)((basicWidth * pStyle->m_dMarginLeftPercent) / 100);
	}


	BrBOOL bAnchorType = BrFALSE;
	BRect Rect;
	if(bInGroup)
		Rect.setRect(pStyle->m_nLeft, pStyle->m_nTop,
		pStyle->m_nLeft+pStyle->m_nWidth, pStyle->m_nTop+pStyle->m_nHeight);
	else
		Rect.setRect(pStyle->m_nMarginLeft, pStyle->m_nMarginTop, 
		pStyle->m_nMarginLeft+pStyle->m_nWidth, pStyle->m_nMarginTop+pStyle->m_nHeight);

	pFrame = m_pDocxConv->createFrame(GROUPFRAME, &Rect, bAnchorType, m_pDocxConv->m_pCurPage->getPageNum(), BrTRUE);
	if(!pFrame)
		return NULL;

	//hnsong:2011-12-28 
	//�̹� createFrame���� group�϶� shape�� ����� �ִ�! �� �ٽ� �������? �ƴϸ� �ȿ��� �� �������?
	//�ϴ� �ۿ��� ����� ���� ������!!
	//BrShape *pBwpShape = NULL;
	//pBwpShape = BrShape::createShape(SHAPE_Rectangle, *pFrame->getFrameRect());
	//pFrame->setBorder( pBwpShape );

	pDocxGroup->convertGrapAttForGroup(pFrame);

	//jjoo:2009-05-28:Style�� Position�� static(=0)�̸� �ؽ�Ʈ �پ��̴�.
	if( pStyle->m_nPosition == 0 )
	{
		pFrame->setAnchorFlag(BrTRUE);
		if(!bInGroup)	
			m_pDocxConv->m_nCurParaHgt += pFrame->height();
	}
	else
		m_pDocxConv->setFloatingFrameInfo(pFrame, pStyle, pDocxGroup->m_nWrappingMode);

	if(pStyle->m_nZIndex)		//MistY - 2008.08.12
	{
		if( (pStyle->m_nZIndex< 0) && (pStyle->m_nZIndex != DEF_Z_INDEX) )	
			pFrame->setUnderBasic(TRUE);
		pFrame->setZindex(pStyle->m_nZIndex);
	}

	//jjoo:2008-11-06
	//if(BrStrLen(pDocxGroup->m_cID))	//MistY - 2008.08.13
	//	pFrame->m_lspid = BrAtoi(&pDocxGroup->m_cID[8]);
	if(pDocxGroup->m_pSPID)
		pFrame->setSpid(BrAtoi(&pDocxGroup->m_pSPID[8]));
	else
	{
		if(pDocxGroup->m_pID)
			pFrame->setSpid(BrAtoi(&pDocxGroup->m_pID[8]));
	}
	//~jjoo

	// nkyumi.10-08-09.�׷� ���� ������ �ʿ��ؼ� �߰�
	pFrame->setCoordOriginX(pDocxGroup->m_nCoordOriginX);
	pFrame->setCoordOriginY(pDocxGroup->m_nCoordOriginY);
	pFrame->setCoordSizeX(pDocxGroup->m_nCoordSizeX);
	pFrame->setCoordSizeY(pDocxGroup->m_nCoordSizeY);

	return pFrame;
}

CFrame* CDocxOfficeDraw::convertDrawShape(XMLDataDecodeParam* pInfo, BrCHAR* a_pCurPackagePartName)
{
	CDocxShape *pDocxShape = BrNULL;
	const BrCHAR* pCurPackagePartName  = BrNULL;
	if(pInfo)
	{
		pCurPackagePartName = pInfo->pCurPackagePartName;
		pDocxShape = (CDocxShape *)pInfo->callbackParam.pCurrentInstance;
	}
	else if(m_pDocxShape && m_pDocxShape->m_bBullet)
	{
		pDocxShape = m_pDocxShape;
		pCurPackagePartName = a_pCurPackagePartName;
	}
	

	if(!pDocxShape ) 
		return BrNULL;

	CFrame *pFrame = BrNULL;
	if( pDocxShape->m_pStyle && pDocxShape->m_pStyle->m_bVisibility)
		pFrame = pDocxShape->convertShape(pCurPackagePartName);
	//[2013.11.30][������]
	//http://qats.infraware.net/mantisbt/view.php?id=44337
	//�������� �ش� �̽� ������ Frame�Ȱ����� ��� �����޶�� �Ͽ� Delete���� NumPicBullet���� �ű�
	if(m_pDocxShape && !m_pDocxShape->m_bBullet)
	{
		if( m_pDocxShape == pDocxShape)
			m_pDocxShape = BrNULL;
		BrDELETE pDocxShape;
	}
		
	return pFrame;
}

BrBOOL CDocxOfficeDraw::AddInkMLImage(XMLDataDecodeParam* pInfo)
{
	if(!pInfo || !m_pDocxConv || !m_pInkMLFrame)
		return BrFALSE;
	const BrCHAR* pCurPackagePartName = pInfo->pCurPackagePartName;
	CDocxShape *pDocxShape = (CDocxShape *)pInfo->callbackParam.pCurrentInstance;
	if(!pDocxShape || !pDocxShape->m_pImageData)
		return BrFALSE;
	
	BrShape* pBwpShape = BrShape::createShape(SHAPE_Rectangle, *m_pInkMLFrame->getFrameRect());
	pBwpShape->setOffice2007Shape(BrTRUE);
	m_pInkMLFrame->setBorder( pBwpShape );

	BString strPartName(pCurPackagePartName);
	BString strRelID(pDocxShape->m_pImageData->m_pID);
	BrGrapAtt* pGrapAtt = m_pInkMLFrame->getBorder();
	BrImageAttr* pImgAttr = pGrapAtt->getBrush()->getImageAttr();

	pImgAttr->setImageLoader(m_pDocxConv->m_pPackage->GetImageLoader(strPartName, strRelID, 0.0, 0.0, 0.0, 0.0));
	pGrapAtt->getBrush()->setStyle(BMV_FILLTYPE_IMAGE);
	if( m_pDocxShape == pDocxShape)
		m_pDocxShape = BrNULL;

	BrDELETE pDocxShape;

	return BrTRUE;
}

BrBOOL CDocxOfficeDraw::setChildFrameGroupParent(CFrame* groupFrame)
{
	if(!groupFrame)
		return BrFALSE;
	CFrameList* childFrameList = (CFrameList*)groupFrame->getSubFrame();
	CFrame* pChildFrame = childFrameList->getFirst();
	while(pChildFrame) //Group ���� �θ��� instance ���� �ڽ������ӿ� ����
	{
		if(pChildFrame->isGroup())
		{
			CFrameList* pSubFrameList = (CFrameList*)pChildFrame->getSubFrame();
			setChildFrameGroupParent(pChildFrame);
		}
		pChildFrame->setGroupParent(groupFrame);
		pChildFrame = childFrameList->getNext(pChildFrame);
	}

	return BrTRUE;
}


/////////////////////////////////////////////////////////////////////////
CDocxBlipInfo::CDocxBlipInfo()
{
	m_pID = NULL;
	m_pStrPrstGeom = NULL;
	m_x = m_y = m_cx = m_cy = 0;

	m_bflipV = BrFALSE;
	m_bflipH = BrFALSE;
	m_nRot = 0;
}

CDocxBlipInfo::~CDocxBlipInfo()
{
	if( m_pID ) BrFree(m_pID);
	if( m_pStrPrstGeom ) BrFree(m_pStrPrstGeom);
}

BrBOOL CDocxBlipInfo::CallbackStartElement(LPVOID pParam)
{
	XMLDataDecodeParam* pInfo = (XMLDataDecodeParam*)pParam;
	
	switch( pInfo->callbackParam.wParam )
	{
	case DOCX_DRAW_DRAWING_PICTURE:
		readBlipInfo(pInfo);
		break;
	}

	return BrTRUE;
}

BrBOOL CDocxBlipInfo::readBlipInfo(XMLDataDecodeParam *pNode)
{
	if( 0 == strcmp(pNode->pElementData->pElementName, X_DOC_DRAW_DRAWING_BLIPFILL))
	{//depth + 5
		pNode->callbackParam.wParam = DOCX_DRAW_DRAWING_PICTURE;
		pNode->callbackParam.pCurrentInstance = this;
	}
	else if( 0 == strcmp(pNode->pElementData->pElementName, X_DOC_DRAW_DRAWING_BLIP))
	{//depth + 6
		if( pNode->pElementData->pAttributePairs )
		{
			for (BrINT32 i = 0; pNode->pElementData->pAttributePairs[i]; i += 2)
			{
				//BrTrace("%s:%s", pNode->pElementData->pAttributePairs[i], pNode->pElementData->pAttributePairs[i+1]);
				if( 0 == strcmp(pNode->pElementData->pAttributePairs[i], "r:embed"))
				{
					BrINT32 nLen = BrStrLen(pNode->pElementData->pAttributePairs[i+1]);
					m_pID = (BrCHAR*)BrMalloc(nLen+1);
					memcpy(m_pID, pNode->pElementData->pAttributePairs[i+1], nLen);
					m_pID[nLen] = 0;
				}
			}
		}
	}
	else if( 0 == strcmp(pNode->pElementData->pElementName, X_DOC_DRAW_DRAWING_SPPR))
	{//depth + 6
		pNode->callbackParam.wParam = DOCX_DRAW_DRAWING_PICTURE;
		pNode->callbackParam.pCurrentInstance = this;
	}
	else if( 0 == strcmp(pNode->pElementData->pElementName, X_DOC_DRAW_DRAWING_PRSTGEOM))	//jjoo:Drawing
	{//depth + 6
		if( pNode->pElementData->pAttributePairs )
		{
			for (BrINT32 i = 0; pNode->pElementData->pAttributePairs[i]; i += 2)
			{
				//BrTrace("%s:%s", pNode->pElementData->pAttributePairs[i], pNode->pElementData->pAttributePairs[i+1]);
				if( 0 == strcmp(pNode->pElementData->pAttributePairs[i], "prst"))
				{
					BrINT32 nLen = BrStrLen(pNode->pElementData->pAttributePairs[i+1]);
					m_pStrPrstGeom = (BrCHAR*)BrMalloc(nLen+1);
					memcpy(m_pStrPrstGeom, pNode->pElementData->pAttributePairs[i+1], nLen);
					m_pStrPrstGeom[nLen] = 0;
				}
			}
		}
	}
	else if( 0 == strcmp(pNode->pElementData->pElementName, X_DOC_DRAW_DRAWING_XFRM))
	{//depth + 7
		if( pNode->pElementData->pAttributePairs )
		{
			for (BrINT32 i = 0; pNode->pElementData->pAttributePairs[i]; i += 2)
			{
				//BrTrace("%s:%s", pNode->pElementData->pAttributePairs[i], pNode->pElementData->pAttributePairs[i+1]);
				if( 0 == strcmp(pNode->pElementData->pAttributePairs[i], "flipV"))
				{
					if(BrAtoi(pNode->pElementData->pAttributePairs[i+1]))
						m_bflipV = BrTRUE;
				}
				else if( 0 == strcmp(pNode->pElementData->pAttributePairs[i], "flipH"))
				{
					if(BrAtoi(pNode->pElementData->pAttributePairs[i+1]))
						m_bflipH = BrTRUE;
				}
				else if( 0 == strcmp(pNode->pElementData->pAttributePairs[i], "rot"))
				{
					m_nRot = (BrINT32)BrMulDiv(BrAtoi(pNode->pElementData->pAttributePairs[i+1]) , 1, 60000);
				}
			}
		}

		pNode->callbackParam.wParam = DOCX_DRAW_DRAWING_PICTURE;
		pNode->callbackParam.pCurrentInstance = this;
	}
	else if( 0 == strcmp(pNode->pElementData->pElementName, X_DOC_DRAW_DRAWING_OFFSET))
	{//depth + 8
		if( pNode->pElementData->pAttributePairs )
		{
			for (BrINT32 i = 0; pNode->pElementData->pAttributePairs[i]; i += 2)
			{
				//BrTrace("%s:%s", pNode->pElementData->pAttributePairs[i], pNode->pElementData->pAttributePairs[i+1]);
				if( 0 == strcmp(pNode->pElementData->pAttributePairs[i], "x"))
				{
					m_x = CDocxUtil::MSEMUtoTWIP(BrAtoi(pNode->pElementData->pAttributePairs[i+1]));
				}
				else if( 0 == strcmp(pNode->pElementData->pAttributePairs[i], "y"))
				{
					m_y = CDocxUtil::MSEMUtoTWIP(BrAtoi(pNode->pElementData->pAttributePairs[i+1]));
				}
			}
		}
	}
	else if( 0 == strcmp(pNode->pElementData->pElementName, X_DOC_DRAW_DRAWING_EXTEND))
	{//depth + 8
		if( pNode->pElementData->pAttributePairs )
		{
			for (BrINT32 i = 0; pNode->pElementData->pAttributePairs[i]; i += 2)
			{
				//BrTrace("%s:%s", pNode->pElementData->pAttributePairs[i], pNode->pElementData->pAttributePairs[i+1]);
				if( 0 == strcmp(pNode->pElementData->pAttributePairs[i], "cx"))
				{
					m_cx = CDocxUtil::MSEMUtoTWIP(BrAtoi(pNode->pElementData->pAttributePairs[i+1]));
				}
				else if( 0 == strcmp(pNode->pElementData->pAttributePairs[i], "cy"))
				{
					m_cy = CDocxUtil::MSEMUtoTWIP(BrAtoi(pNode->pElementData->pAttributePairs[i+1]));
				}
			}
		}
	}

	return BrTRUE;
}

//////////////////////////////////////////////////////////////////////////
CDocxDrawAttr::CDocxDrawAttr()
{
	m_pStyle = NULL;
	m_pStroke = NULL;
	m_pFill = BrNULL;
	m_pShadow = BrNULL;

	m_pShap3DInfo = BrNULL;

	m_pID = NULL;
	m_pSPID = NULL;
	m_pFillColor = NULL;

	m_bAnchorLock = BrFALSE;
	m_bInGroup = BrFALSE;
	m_bAllowOverlap = BrTRUE;
	m_bFilled = BrTRUE;
	m_bStroked = BrTRUE;

	m_nWrappingMode = -1;
	m_bAllowInCell = BrTRUE;
	//m_pAdjArray = BrNULL;

	//������ �Ӽ�
	m_bHR = BrFALSE;
	m_nHRAlign = MSO_LEFT;
	m_bHRStd = BrFALSE;
	m_bHRNoShade = BrFALSE;
	m_HRWidthPercent = 1000;
	m_pAltText = BrNULL;
	m_nWrapType = BR_WRAP_TEXT_BOTH_SIDES;
	m_nPenID = 0;
	m_pImageData = BrNULL;
	m_nSPT = 0;
	m_pDocxConv = BrNULL;
}

CDocxDrawAttr::~CDocxDrawAttr()
{
	if(m_pID)			BR_SAFE_FREE(m_pID);
	if(m_pSPID)			BR_SAFE_FREE(m_pSPID);
	if(m_pFillColor)	BR_SAFE_FREE(m_pFillColor);

	if( m_pStyle )		BR_SAFE_DELETE(m_pStyle);
	if( m_pStroke )		BR_SAFE_DELETE(m_pStroke);
	if(m_pFill)			BR_SAFE_DELETE(m_pFill);
	if(m_pShadow)		BR_SAFE_DELETE(m_pShadow);

	if(m_pShap3DInfo)	BR_SAFE_DELETE(m_pShap3DInfo);

	//BR_SAFE_DELETE(m_pAdjArray);
	if(m_pImageData)	BR_SAFE_DELETE(m_pImageData);
}

void CDocxDrawAttr::calcDrawMargin(CDocxConv *pDocxConv)
{
	//[2012-08-17][toypilot][T-8434]group���� ��� ��ġ ���� ����
	if(m_pStyle->m_dMarginTopPercent && (!m_pStyle->m_bMarginTop || m_pStyle->m_nMarginTop == 0))
	{
		BrLONG basicHeight = 0;
		if( MSO_PAGE == m_pStyle->m_nPosVerRel)
			basicHeight = pDocxConv->m_pCurPage->getPaperSize()->height();

		m_pStyle->m_nMarginTop = (BrINT32)((basicHeight * m_pStyle->m_dMarginTopPercent) / 100);
	}
	if(m_pStyle->m_dMarginLeftPercent && (!m_pStyle->m_bMarginLeft || m_pStyle->m_nMarginLeft == 0))
	{
		BrLONG basicWidth = 0;
		if( MSO_PAGE == m_pStyle->m_nPosHorRel)
			basicWidth = m_pDocxConv->m_pCurPage->getPaperSize()->width();
		m_pStyle->m_nMarginLeft = (BrINT32)((basicWidth * m_pStyle->m_dMarginLeftPercent) / 100);
	}
}

DRAW_RESULT CDocxDrawAttr::readObjectInfo(const BrCHAR *pName, const BrCHAR *pValue, BrBOOL a_bShapeType)
{
	DRAW_RESULT  nResult = DRAW_SUCCESS;
	switch(pName[0])
	{
	case 'a':
		if( 0 == strcmp(pName, X_DOC_DRAW_ROUNDRECT_ARCSIZE) )
			nResult = DRAW_ETC;
		//[2013.04.08][������][TID:12537][VML_AdjustValue.docx] AdjustValue ���� �Ǿ� ������ ShapeType�� �ִ� ���� ���� �;���.
		else if( 0 == strcmp(pName, X_DOC_DRAW_SHAPE_ADJ) )
		{
			if ( a_bShapeType == BrTRUE)
			{
				if(m_pDocxConv && !m_pDocxConv->m_pShapeTypeAdjArray)
				{
					m_pDocxConv->m_pShapeTypeAdjArray = shapeAdjustParser(pValue);
					if ( m_pDocxConv->m_pShapeTypeAdjArray == BrNULL )
						return DRAW_FAIL;
				}
			}
			else
			{
				if(m_pDocxConv && !m_pDocxConv->m_pShapeAdjArray)
				{
					m_pDocxConv->m_pShapeAdjArray = shapeAdjustParser(pValue);
					if ( m_pDocxConv->m_pShapeAdjArray == BrNULL )
						return DRAW_FAIL;
				}
			}
		}
		else if( 0 == strcmp(pName, "alt") )
		{
			BrINT32 nLen = BrStrLen(pValue);
			if(0 >= nLen || nLen > 4095)
				break;

			m_pAltText = (BrCHAR*)BrMalloc(nLen+1);
			memset(m_pAltText, 0, nLen+1);
			memcpy(m_pAltText, pValue, nLen );

			const BrCHAR *pAttrStr = pValue;
			BrCHAR seps[] = " ";			
		}
		else
			nResult = DRAW_ETC;
		break;
	case 'f':	
		if( 0 == strcmp(pName, X_DOC_DRAW_FILLCOLOR) )
		{
			BrINT32 nLen = BrStrLen(pValue);
			m_pFillColor = (BrCHAR*)BrMalloc(nLen+1);
			memcpy(m_pFillColor, pValue, nLen);
			m_pFillColor[nLen] = 0;
		}
		else if( 0 == strcmp(pName, X_DOC_DRAW_FILLED) )
		{
			m_bFilled = BrTRUE;
			//�ش� val��(true, t, f, false)�� �ü� ����
			BrINT32 nLen = BrStrLen(pValue);
			if(nLen > 5 ) {//2012-10-04 �Ｚ���ȹ��� ���� ����
				SET_ERROR((PoError)kPoErrCorruptFile, "Filled Value incorrect");
				BoraPackageBase::CurruptedXmlParser(m_pDocxConv);
				return DRAW_FAIL;
			}

			BrCHAR buf[10];
			memcpy(buf, pValue, nLen);
			buf[nLen] = 0;

			BrXMLDTDUtil::setVMLBoolData((BrCHAR *)buf,nLen,m_bFilled);
		}
		else
			nResult = DRAW_ETC;
		break;
	case 'i':
		if( 0 == strcmp(pName, X_DOC_DRAW_ID) )
		{
			BrINT32 nLen = BrStrLen(pValue);
			m_pID = (BrCHAR*)BrMalloc(nLen+1);
			memcpy(m_pID, pValue, nLen );
			m_pID[nLen] = 0;
			//if( SHAPE_StraightConnector1 == BrAtoi(&m_pID[8]))
			//	m_bStroked = BrTRUE;
		}
		else
			nResult = DRAW_ETC;
		break;

	case 's':
		if( 0 == strcmp(pName, X_DOC_DRAW_SPID) )
		{
			BrINT32 nLen = BrStrLen(pValue);
			m_pSPID = (BrCHAR*)BrMalloc(nLen+1);
			memcpy(m_pSPID, pValue, nLen );
			m_pSPID[nLen] = 0;
		}
		else if( 0 == strcmp(pName, X_DOC_DRAW_STYLE) )
		{
			m_pStyle = BrNEW CDocxDrawStyle(m_pDocxConv);
			m_pStyle->readStyleInfo(pValue);
		}
		else if( 0 == strcmp(pName, X_DOC_DRAW_STROKED) )
		{
			//�ش� val��(true, t, f, false)�� �ü� ����
			BrINT32 nLen = BrStrLen(pValue);
			if(nLen > 5 ) {//2012-10-04 �Ｚ���ȹ��� ���� ����
				SET_ERROR((PoError)kPoErrCorruptFile, "Stroked Value incorrect");
				BoraPackageBase::CurruptedXmlParser(m_pDocxConv);
				return DRAW_FAIL;
			}

			BrCHAR buf[10];
			memcpy(buf, pValue, nLen);
			buf[nLen] = 0;

			BrXMLDTDUtil::setVMLBoolData((BrCHAR *)buf,nLen,m_bStroked);
		}
		else if( 0 == strcmp(pName, X_DOC_DRAW_STROKECOLOR) )
		{
			if(!m_pStroke )
				m_pStroke = BrNEW CDocxDrawStroke();

			BrINT32 nLen = BrStrLen(pValue);
			m_pStroke->m_pStrokeColor = (BrCHAR*)BrMalloc(nLen+1);
			memcpy(m_pStroke->m_pStrokeColor, pValue, nLen);		
			m_pStroke->m_pStrokeColor[nLen] = 0;

			//m_bStroked�� �⺻ ���� TRUE �̸�, X_DOC_DRAW_STROKECOLOR���� ������ m_bStroked���� ������ ���� ����
			//m_bStroked = (m_bStroked == BrFALSE) ? BrTRUE : m_bStroked;
		}
		else if( 0 == strcmp(pName, X_DOC_DRAW_STROKEWEIGHT) )
		{
			if(!m_pStroke )
				m_pStroke = BrNEW CDocxDrawStroke();

			m_pStroke->m_nStrokeWeight = CDocxUtil::PTtoTWIPDocx(BrAtof(pValue) );
			//m_bStroked�� �⺻ ���� TRUE �̸�, X_DOC_DRAW_STROKEWEIGHT���� ������ m_bStroked���� ������ ���� ����
			//m_bStroked = (m_bStroked == BrFALSE) ? BrTRUE : m_bStroked;
		}
		else
			nResult = DRAW_ETC;
		break;
	case 'h':
		if( 0 == strcmp(pName, X_DOC_DRAW_HYPERLINK) )
		{
			DocxRelationField* pDocxRelationField = BrNEW DocxRelationField( eFieldCode_DRAWINGHYPERLINK,(BrCHAR*)pValue, m_pDocxConv->getDocxLoader());
			pDocxRelationField->CreateStartLink(m_pDocxConv->getCurLineList(), 0, m_pDocxConv->m_nCaptionIDForEndLink);
			DocxFieldManager * pDocxFieldManager = m_pDocxConv->getDocxLoader()->getDocxFieldManager();
			pDocxFieldManager->push(pDocxRelationField);
		}		
		else
			nResult = DRAW_ETC;

		break;
	case 'o':
		if( 0 == strcmp(pName, X_DOC_DRAW_ALLOWOVERLAP) )
		{
			//�ش� val��(true, t, f, false)�� �ü� ����
			BrINT32 nLen = BrStrLen(pValue);
			if(nLen > 5 ) {//2012-10-04 �Ｚ���ȹ��� ���� ����
				SET_ERROR((PoError)kPoErrCorruptFile, "AllowOverlap Value incorrect");
				BoraPackageBase::CurruptedXmlParser(m_pDocxConv);
				return DRAW_FAIL;
			}

			BrCHAR buf[10];
			memcpy(buf, pValue, nLen);
			buf[nLen] = 0;

			BrXMLDTDUtil::setVMLBoolData((BrCHAR *)buf,nLen,m_bAllowOverlap);
		}
		else if(0 == strcmp(pName, X_DOC_DRAW_SHAPE_ALLOWINCELL))
		{
			BrINT32 nLen = BrStrLen(pValue);
			if(nLen > 5 ) {
				SET_ERROR((PoError)kPoErrCorruptFile, "Stroked Value incorrect");
				BoraPackageBase::CurruptedXmlParser(m_pDocxConv);
				return DRAW_FAIL;
			}

			BrCHAR buf[10];
			memcpy(buf, pValue, nLen);
			buf[nLen] = 0;
			BrXMLDTDUtil::setVMLBoolData((BrCHAR *)buf,nLen,m_bAllowInCell);
		}

		else if(0 == strcmp(pName, X_DOC_DRAW_RECT_HR))
		{
				BrINT32 nLen = BrStrLen(pValue);
			if(nLen > 5 ) {
				SET_ERROR((PoError)kPoErrCorruptFile, "HR Value incorrect");
				BoraPackageBase::CurruptedXmlParser(m_pDocxConv);
				return DRAW_FAIL;
			}
			BrXMLDTDUtil::setVMLBoolData((BrCHAR *)pValue,nLen,m_bHR);
		}

		else if(0 == strcmp(pName, X_DOC_DRAW_RECT_HRPCT))
		{
			m_HRWidthPercent = BrAtof(pValue);
		}
		else if(0 == strcmp(pName, X_DOC_DRAW_RECT_HRALIGN))
		{

			if( 0 == strcmp(pValue, "left") )
				m_nHRAlign = MSO_LEFT;
			else if( 0 == strcmp(pValue, "center") )
				m_nHRAlign = MSO_CENTER;
			else if( 0 == strcmp(pValue, "right") )
				m_nHRAlign = MSO_RIGHT;
		}
		else if(0 == strcmp(pName, X_DOC_DRAW_RECT_HRSTD))
		{
			//�ش� val��(true, t, f, false)�� �ü� ����
			BrINT32 nLen = BrStrLen(pValue);
			if(nLen > 5 ) {//2012-10-04 �Ｚ���ȹ��� ���� ����
				SET_ERROR((PoError)kPoErrCorruptFile, "HRStd Value incorrect");
				BoraPackageBase::CurruptedXmlParser(m_pDocxConv);
				return DRAW_FAIL;
			}

			BrXMLDTDUtil::setVMLBoolData((BrCHAR *)pValue,nLen,m_bHRStd);
		}
		else if(0 == strcmp(pName, X_DOC_DRAW_RECT_HRNOSHADE  ))
		{
			//�ش� val��(true, t, f, false)�� �ü� ����
			BrINT32 nLen = BrStrLen(pValue);
			if(nLen > 5 ) {//2012-10-04 �Ｚ���ȹ��� ���� ����
				SET_ERROR((PoError)kPoErrCorruptFile, "HRNoShade Value incorrect");
				BoraPackageBase::CurruptedXmlParser(m_pDocxConv);
				return DRAW_FAIL;
			}

			BrXMLDTDUtil::setVMLBoolData((BrCHAR *)pValue,nLen,m_bHRNoShade);
		}
		else if(0 == strcmp(pName, X_DOC_DRAW_SHAPE_SPT))
		{
			m_nSPT = BrAtoi(pValue);
		}
		break;
	default:
		nResult = DRAW_ETC;
		break;
	}

	return nResult;
}

BrBOOL CDocxDrawAttr::CallbackStartElement(LPVOID pParam)
{
	XMLDataDecodeParam* pInfo = (XMLDataDecodeParam*)pParam;
	switch( pInfo->callbackParam.wParam )
	{
	case DOCX_DRAWINFO:
		return readDrawAttribute(pInfo);
	}
	return BrTRUE;
}

BrBOOL CDocxDrawAttr::readDrawAttribute(XMLDataDecodeParam*  pInfo)
{
	const BrCHAR *pName = trimNamespace(pInfo->pElementData->pElementName);
	switch(pName[0])
	{
	case 'a':
		if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_ANCHORLOCK))
		{
			m_bAnchorLock = BrTRUE;
		}
		break;

	case 'e':
		if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_EXTRUSION))
		{
			if( pInfo->pElementData->pAttributePairs )
			{
				m_pShap3DInfo = read3DDrawInfo(pInfo);
			}
		}
		break;
	case 'f':	
		if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_FILL)) //v:fill
		{
			if(BrNULL == m_pFill)
				m_pFill = BrNEW CDocxDrawFill(m_pDocxConv);

			m_pFill->readFillInfo(pInfo);
		}
		else if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_FILL_OFILL) )
		{
			if( BrNULL == m_pFill->m_pFillExt)
				m_pFill->m_pFillExt = BrNEW CDocxDrawFillExt();

			m_pFill->m_pFillExt->readFillExtInfo(pInfo);
		}
		break;
	case 'i':
		if(0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_IMAGEDATA) || 0 == strcmp(pInfo->pElementData->pElementName, "v:imageData"))
		{
			if(BrNULL == m_pImageData)
				m_pImageData = BrNEW CDocxImageData();

			m_pImageData->readImageDataInfo(pInfo);
		}
		break;
	case 's':		
		if(  0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_SHADOW) )
		{
			if( BrNULL == m_pShadow)
				m_pShadow = BrNEW CDocxDrawShadow();

			m_pShadow->readShadowInfo(pInfo);
		}
		else if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_STROKE))
		{
			if(!m_pStroke )
				m_pStroke = BrNEW CDocxDrawStroke();

			m_pStroke->readStrokeInfo(pInfo);
		}
		break;
	case 't':
		if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_TEXTBOX)) //textbox
		{	
			if( !m_pStyle )
				m_pStyle  = BrNEW CDocxDrawStyle();

			if(m_pDocxConv)
				m_pDocxConv->m_nDoingType |= DOC_CON_TEXTBOX;
			m_pStyle->readTextBoxInfo(pInfo);

			if(m_pID && 0 == m_pStyle->m_pTextBox->m_nTxBxID)
			{
				m_pStyle->m_pTextBox->m_nTxBxID = BrAtoi(&m_pID[8]);
			}

			pInfo->callbackParam.wParam = DOCX_TEXTBOX;
			pInfo->callbackParam.pCurrentInstance = m_pStyle;
			pInfo->nElementOption |= BR_XML_NEED_END_ELEMENT;
		}
		break;

	case 'w':
		if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_WRAP))
		{
			if( pInfo->pElementData->pAttributePairs )
			{
				for (BrINT32 i = 0; pInfo->pElementData->pAttributePairs[i]; i += 2)
				{
					if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], X_DOC_DRAW_TYPE))
					{
						if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i+1], X_DOC_DRAW_WRAP_TOPANDBOTTOM))
						{
							m_nWrappingMode = FULL_RUN_AROUND;
						}
						else if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i+1], X_DOC_DRAW_WRAP_NONE))
						{
							m_nWrappingMode = NO_RUN_AROUND;
						}
						else if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i+1], X_DOC_DRAW_WRAP_TIGHT))
						{
							m_nWrappingMode = TIGHT_RUN_AROUND;
							
						}
						else if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i+1], X_DOC_DRAW_WRAP_THROUGH))
						{
							m_nWrappingMode = THROUGH_RUN_AROUND;
						}
						else
						{
							m_nWrappingMode = PART_RUN_AROUND;;
						}
					}
					else if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], "anchorx"))
					{
					}
					else if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], "anchory"))
					{
					}
					else if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], "side"))
					{						
						if(0 == strcmp(pInfo->pElementData->pAttributePairs[i+1], "largest"))
							m_nWrapType = BR_WRAP_TEXT_LARGEST_ONLY;
						else if(0 == strcmp(pInfo->pElementData->pAttributePairs[i+1], "left"))
							m_nWrapType = BR_WRAP_TEXT_LEFT_ONLY;
						else if(0 == strcmp(pInfo->pElementData->pAttributePairs[i+1], "right"))
							m_nWrapType = BR_WRAP_TEXT_RIGHT_ONLY;
						else
							m_nWrapType = BR_WRAP_TEXT_BOTH_SIDES;
					}
				}
			}
		}
		break;
	}

	return BrTRUE;
}

BrBOOL	CDocxDrawAttr::readDrawShapeType(XMLDataDecodeParam* pInfo)
{
	if( pInfo->pElementData->pAttributePairs)
	{
		for( BrINT32 i = 0; pInfo->pElementData->pAttributePairs[i]; i+= 2)
		{
			DRAW_RESULT nResult = readObjectInfo(pInfo->pElementData->pAttributePairs[i], pInfo->pElementData->pAttributePairs[i+1], BrTRUE);
			if( DRAW_ETC == nResult )
			{
				//const BrCHAR *pStr = pInfo->pElementData->pAttributePairs[i];
				//switch(pStr[0])
				//{
				//default:
				//	break;
				//}
			}
			else if (nResult == DRAW_FAIL)
				return BrFALSE;
		}
	}

	return BrTRUE;
}

/////converting
void CDocxDrawAttr::convertAttribute(CFrame *pFrame, CDocxConv *pDocxConv)
{
	//jjoo:2008-11-06
	//if(BrStrLen(pDocxDraw->m_pID))	//MistY - 2008.08.13
	//	pFrame->m_lspid = BrAtoi(&pDocxDraw->m_pID[8]);
	if(m_pSPID)
		pFrame->setSpid(BrAtoi(&m_pSPID[8]));
	else
	{
		if(!pFrame->isWatermark())
		{
			if(m_pID)
				pFrame->setSpid(BrAtoi(&m_pID[8]));
#ifdef DOCX_SPID
			if(m_pID && IsDigit(m_pID[8]))
			{
				BrCHAR pBuf[128] = {0};
				BrUINT32 nSize = BrStrLen(m_pID);

				for(BrINT32 i = 8, j = 0 ; i < nSize ; i++, j++)
					pBuf[j] = m_pID[i];

				pFrame->setDocxSpid(BrAtoi(pBuf));
			}
#endif //DOCX_SPID
		}
		else
		{
			if(m_pID)
				pFrame->setSpid(BrAtoi(m_pID));
		}
		
	}

	calcDrawMargin(pDocxConv);
	m_pStyle->convertStyleAttr(pFrame, pDocxConv);
	//jjoo:2009-05-28:Style�� Position�� static(=0)�̸� �ؽ�Ʈ �پ��̴�.
	if( m_pStyle->m_nPosition == 0 )
	{
		pFrame->setAnchorFlag(BrTRUE);
		if(!m_bInGroup)	
			pDocxConv->m_nCurParaHgt += pFrame->height();
	}
	else
	{
		pDocxConv->setFloatingFrameInfo(pFrame, m_pStyle, m_nWrappingMode);

		if(m_nWrappingMode == TIGHT_RUN_AROUND || m_nWrappingMode == THROUGH_RUN_AROUND || m_nWrappingMode == PART_RUN_AROUND)
			pFrame->setWrapTextType(m_nWrapType);

		pFrame->setAllowOverlap(m_bAllowOverlap);
		pFrame->setPlaceInCell(m_bAllowInCell);
	}

	((CDocxDrawAttr*)this)->convertGrapAtt(pFrame);

	if(  m_pShap3DInfo && pFrame->getBorder() ) {
		if( m_pShap3DInfo->m_pMsod3DObject ) {
			BrShape *pBwpShape = pFrame->getBorder();
			pBwpShape->set3DObjectProp(m_pShap3DInfo->m_pMsod3DObject);
			pBwpShape->set3DStyleProp(m_pShap3DInfo->m_pMsod3DStyle);
			m_pShap3DInfo->m_pMsod3DObject = BrNULL;
			m_pShap3DInfo->m_pMsod3DStyle = BrNULL;
			pBwpShape->reCreateShape(pFrame->getFrameRect());
		}
	}
	//[2013.06.10][������] ������ Setting
	if(m_bHR)
	{
		pFrame->setHorizontalLine(BrTRUE);
		pFrame->setPercentWidth(m_HRWidthPercent/10);
		pFrame->setAlignOfHorizontalLine(m_nHRAlign);
		pFrame->setHorizontalLineStd(m_bHRStd);

		if(!m_bHRNoShade)
		{
			//[2013.06.13][������] ������ �ܻ�������� ���� �� Line�� ����־���.
			BrPenObj* pPenObj = pFrame->getBorder()->getPen();
			BrBrushObj* pBrushObj = pFrame->getBorder()->getBrush();

			if(m_pFillColor) //�׸����ε� �������� ��� ���� ������ �ʾ� Crash
				pPenObj->setColor(CUtil::getColor(m_pFillColor));
			pPenObj->setLineWidth(5);
			pPenObj->setLineStyle(BMV_LINESTYLE_SIMPLE);
			pPenObj->setDashStyle(BMV_DASHSTYLE_SOLID);
		
			pBrushObj->setForeColor(NONE_COLOR_BITS);
			pBrushObj->setStyle(BMV_FILLTYPE_NOFILL);
		}			
	}
	if(m_pAltText)
	{
		BString altText;
		altText.setMultiByte(CP_UTF8, m_pAltText);
		pFrame->setAltTextDescription(m_pAltText);
	}

}

void CDocxDrawAttr::convertGrapAtt(CFrame *pFrame, BrBOOL bLine) 
{
	if(!pFrame)
		return;

	BrGrapAtt *pGrapAtt = (BrGrapAtt*)pFrame->getBorder();
	if( !pGrapAtt)
		return;

	pGrapAtt->setOffice2007ShapeDocx(1);
	//pGrapAtt->setOffice2007Shape(1); //VML �϶��� Office2007ShapeDocx�� setting�ϸ� �ȴ�!!

	//line Attribute
	BrPenObj *pPenObj = pGrapAtt->getPen();

	//[2013-01-29][toypilot]
	//�̹����� �������� stroked�� �ٸ��� ���ȴ�.
	//���������� stroked�� ���� ��쿡�� �⺻ ���� ��Ÿ������,
	//�̹����� ��쿡�� stroked�� ���� ��� �ƹ��͵� ǥ������ �ʴ´�.
	if(	m_bStroked)
	{
		//MS ����� ������ �ʱ�ȭ
		if(pFrame->isPureImage())
		{
			pPenObj->setLineStyle(BMV_LINESTYLE_NOLINE);
			pPenObj->setDashStyle(BMV_DASHSTYLE_NOLINE);
			pPenObj->setColor(NONE_COLOR_BITS);
		}
		else
		{
			pPenObj->setLineStyle(BMV_LINESTYLE_SIMPLE);
			pPenObj->setDashStyle(BMV_DASHSTYLE_SOLID);
			pPenObj->setColor(RGB_BLACK);
		}

		if(m_pStroke)
		{
			if(m_pStroke->m_pStrokeColor)
				pPenObj->setColor(CUtil::getColor(m_pStroke->m_pStrokeColor) );
			pPenObj->setLineWidth(m_pStroke->m_nStrokeWeight);
			if(m_pStroke->m_pOpacity)
			{//[2012.09.12][������][TID:9276] Gradient �ϋ� ������ 0�̸� �ȵ�.	
				BrINT32 nSize = BrStrLen(m_pStroke->m_pOpacity);
				BrINT32 nVal = 0;
				if(m_pStroke->m_pOpacity[0] == '.' || m_pStroke->m_pOpacity[1] == '.')
				{
					nVal = (BrINT32)(BrFRound((BrFLOAT)(BrAtof(m_pStroke->m_pOpacity) * 255.0)));
				}
				else if(m_pStroke->m_pOpacity[nSize-1] == 'f')
				{
					nVal = (BrINT32)(BrFRound((BrFLOAT)(BrAtoi(m_pStroke->m_pOpacity) / 65536.0 * 255.0)));
				}
				else if(m_pStroke->m_pOpacity[0] == '1')	//[2012.11.03][������][M14786]1 or 1.0 �϶� ���������� Setting �Ǿ� ��.
					nVal = 255;

				pGrapAtt->getPen()->setTransparent(nVal); //0(����) ~ 255(������)
			}
			if(m_pStroke->m_pDashStyle)
			{
				//[toypilot]vml������ endcap������ �Ұ����ϱ� ������ cap������ �ǹ̰� ���� round�ÿ��� round line style�� ��
				//���� PO���� roundó���� dot�� �� �� �־ bRoundDot���� ������ ǥ�� ���� ���� �ʿ�
				BrINT32	nRoundDot = BrFALSE;
				if(m_pStroke->m_pEndCap)
					nRoundDot = getEndCap(m_pStroke->m_pEndCap);
				pPenObj->setDashStyle(getDashStyle(m_pStroke->m_pDashStyle, nRoundDot? true : false));
			}
			if(m_pStroke->m_pLineStyle)
				pPenObj->setLineStyle(getLineStyle(m_pStroke->m_pLineStyle));

			
			if( m_pStroke->m_pArrow)
				m_pStroke->m_pArrow->convertArrow(pGrapAtt);
		}
	}
	else
	{
		pPenObj->setLineStyle(BMV_LINESTYLE_NOLINE);
		pPenObj->setDashStyle(BMV_DASHSTYLE_NOLINE);
		pPenObj->setColor(NONE_COLOR_BITS);
	}

	//Fill Attribute
	BrBrushObj *pBrushObj = pGrapAtt->getBrush();
	
	if(m_bFilled)
	{
		if(m_pFillColor)
			pBrushObj->setForeColor(CUtil::getColor(m_pFillColor));
		else
		{
			if(pFrame->isPureImage())
				pBrushObj->setForeColor(NONE_COLOR_BITS);
			else
				pBrushObj->setForeColor(RGB_WHITE);
		}
	}
	else
		pBrushObj->setStyle(BMV_FILLTYPE_NOFILL);

	if( m_pFill && m_bFilled == BrTRUE)
		m_pFill->convertFillInfo(pFrame, pGrapAtt, m_pDocxConv->m_pPackage);

	if(m_pFill && m_pFill->m_bRecolor)
	{
		BrImageAttr* pImageAttr = pGrapAtt->getBrush()->getImageAttr();
		if(pImageAttr && m_pImageData)
			CDocxUtil::convertImageAttribute(m_pImageData, pImageAttr);
	}

	//jjoo:2008-06-04:rotation setting
	if(m_pStyle)
	{


		if( bLine) {
			//[2012.01.17][TID : 3405][���ؼ�] ���׸��⿡�� ����/�¿� ���� �Ӽ� ����
			if(m_pStyle->m_bFlipY)
				pGrapAtt->setFlipY(BrTRUE);		//mirror

			if(m_pStyle->m_bFlipX)
				pGrapAtt->setFlipY(BrTRUE);		//flip
		}
		else {
			//Flip Setting
			if(m_pStyle->m_bFlipX)
			{
				//pFrame->getBorder()->m_bFlip = BrTRUE;
				pGrapAtt->setFlipX(BrTRUE);
			}
			if(m_pStyle->m_bFlipY) 
			{
				//pFrame->getBorder()->m_bMirror = BrTRUE;
				pGrapAtt->setFlipY(BrTRUE);
			}
		}

		if(m_pStyle->m_nRotation)
		{
			if(m_pStyle->m_bFlipY || m_pStyle->m_bFlipX)
				pGrapAtt->setRotation(360 - m_pStyle->m_nRotation);
			else
				pGrapAtt->setRotation(m_pStyle->m_nRotation);
		}

		if(m_pShadow && m_pShadow->m_bShadow)
			m_pShadow->convertShadowInfo(m_pStyle, pGrapAtt, pFrame->isWordArt());
	}
}

BrINT32 CDocxDrawAttr::getDashStyle(BrCHAR *pDashStyle, BrBOOL bRoundDot)
{
	BrINT32 nLineStyle = BMV_DASHSTYLE_SOLID;
	if( !pDashStyle)
		return nLineStyle;

	if( 0 == CUtil::StrIcmp(pDashStyle, "1 1") )
	{
		if(bRoundDot)
			nLineStyle = BMV_DASHSTYLE_ROUND_DOT;
		else
			nLineStyle = BMV_DASHSTYLE_SQUARE_DOT;
	}
	else if( 0 == CUtil::StrIcmp(pDashStyle, "longDashDotDot") )
		nLineStyle = BMV_DASHSTYLE_LONG_DASH_DOT_DOT;
	else if( 0 == CUtil::StrIcmp(pDashStyle, "longDashDot") )
		nLineStyle = BMV_DASHSTYLE_LONG_DASH_DOT;
	else if( 0 == CUtil::StrIcmp(pDashStyle, "dashDot") )
		nLineStyle = BMV_DASHSTYLE_DASH_DOT;
	else if( 0 == CUtil::StrIcmp(pDashStyle, "longDash") )
		nLineStyle = BMV_DASHSTYLE_LONG_DASH;
	else if( 0 == CUtil::StrIcmp(pDashStyle, "dash") )
		nLineStyle = BMV_DASHSTYLE_DASH;
	else if( 0 == CUtil::StrIcmp(pDashStyle, "shortDash") )
		nLineStyle = BMV_DASHSTYLE_DASH;
	else if( 0 == CUtil::StrIcmp(pDashStyle, "shortDot") )
		nLineStyle = BMV_DASHSTYLE_SQUARE_DOT;
	else if( 0 == CUtil::StrIcmp(pDashStyle, "shortDashDot") )
		nLineStyle = BMV_DASHSTYLE_DASH_DOT;
	else if( 0 == CUtil::StrIcmp(pDashStyle, "shortDashDotDot") )
		nLineStyle = BMV_DASHSTYLE_DASH_DOT_DOT;
	else if( 0 == CUtil::StrIcmp(pDashStyle, "dot") )
		nLineStyle = BMV_DASHSTYLE_SQUARE_DOT;

	return nLineStyle;
}

BrINT32 CDocxDrawAttr::getLineStyle(BrCHAR *pLineStyle)
{
	BrINT32 nLineStyle = BMV_LINESTYLE_SIMPLE;
	if( !pLineStyle)
		return nLineStyle;

	if( 0 == CUtil::StrIcmp(pLineStyle, "thinThin") )
		nLineStyle = BMV_LINESTYLE_DOUBLE;
	else if( 0 == CUtil::StrIcmp(pLineStyle, "thinThick") )
		nLineStyle = BMV_LINESTYLE_THINTHICK;
	else if( 0 == CUtil::StrIcmp(pLineStyle, "thickThin") )
		nLineStyle = BMV_LINESTYLE_THICKTHIN;
	else if( 0 == CUtil::StrIcmp(pLineStyle, "thickBetweenThin") )
		nLineStyle = BMV_LINESTYLE_TRIPLE;

	return nLineStyle;
}

BrINT32 CDocxDrawAttr::getEndCap(BrCHAR *pEndCap)
{
	BrINT32 nEndCap = eNoneLineCap;
	if( !pEndCap)
		return nEndCap;

	if( 0 == CUtil::StrIcmp(pEndCap, "flat") )
		nEndCap = eNoneLineCap;
	else if( 0 == CUtil::StrIcmp(pEndCap, "square") )
		nEndCap = eSquareLineCap;
	else if( 0 == CUtil::StrIcmp(pEndCap, "round") )
		nEndCap = eRoundLineCap;

	return nEndCap;
}

BrINT32	CDocxDrawAttr::getJoinStyle(BrCHAR *pJoinStyle)
{
	BrINT32 nJoinStyle = eRoundLineJoin;
	if( !pJoinStyle)
		return nJoinStyle;

	if( 0 == CUtil::StrIcmp(pJoinStyle, "round") )
		nJoinStyle = eRoundLineJoin;
	else if( 0 == CUtil::StrIcmp(pJoinStyle, "bevel") )
		nJoinStyle = eBevelLineJoin;
	else if( 0 == CUtil::StrIcmp(pJoinStyle, "miter") )
		nJoinStyle = eMiterLineJoin;

	return nJoinStyle;
}

BIntArray * CDocxDrawAttr::shapeAdjustParser(const BrCHAR * pValue)
{
	BrINT32 nLen = BrStrLen(pValue);
	if( nLen >= 64) {
		SET_ERROR((PoError)kPoErrCorruptFile, "Adjust Value incorrect");
		BoraPackageBase::CurruptedXmlParser(m_pDocxConv);
		return BrNULL;
	}
	BIntArray * pShapeAdjArray = BrNEW BIntArray;

	BrCHAR* pBuf = (BrCHAR*)BrMalloc(nLen+1);
	memcpy(pBuf, pValue, nLen);
	pBuf[nLen] = 0;
	BrCHAR *pTmp = pBuf;

	BrCHAR cCh[64];
	BrINT32 nTotalLen = BrStrLen(pTmp);

	BrCHAR* pMatch = NULL;
	BrINT32 nPos;
	BrINT32 i = 0;
	while(pTmp < pBuf + nTotalLen)
	{
		pMatch = strchr(pTmp, _T(','));
		if( pMatch )
			nPos = (BrINT32)(pMatch - pTmp);
		else
			nPos = BrStrLen(pTmp);

		memset(cCh, 0, 64 );
		memcpy(cCh, pTmp, nPos);
		cCh[nPos] = 0;
		//[2013.04.08][������]][TID:12537] AdjustValue ���� �Ǿ� ������ ShapeType�� �ִ� ���� ���� �;���.
		if(pShapeAdjArray->size() == i)
			pShapeAdjArray->InsertAt(i, BrAtoi(cCh));
		else if( nPos != 0)
			pShapeAdjArray->SetAt(i, BrAtoi(cCh));

		pTmp += (nPos+1);
		i++;
	}
	BrFree(pBuf);

	return pShapeAdjArray;
}

//////////////////////////////////////////////////////////////////////////
CDocxGroup::CDocxGroup(CDocxConv *pDocxConv, BrBOOL bInGroup)
{
	m_pDocxConv = pDocxConv;
	m_bStroked = m_pDocxConv->getDocxLoader()->m_pSettings ? m_pDocxConv->getDocxLoader()->m_pSettings->m_bStroked : BrFALSE;
	m_bInGroup = bInGroup;

#ifdef XML_DOC_TYPE_DEF//[2012.10.09][TID:9464][������] DTD�Լ� �߰�.
	m_pType = BrNULL;
#else	
	memset(m_pType, 0, 20);
	memset(m_cConnectorType, 0, 20);
#endif
	m_nCoordSizeX = 1000;
	m_nCoordSizeY = 1000;
	m_nCoordOriginX = 0;
	m_nCoordOriginY = 0;

	m_pPath = NULL;
	m_pGroupFrame = NULL;
	m_pDocxShape = BrNULL;
	m_bCanvasFirstShape = BrTRUE;
}

CDocxGroup::~CDocxGroup()
{
#ifdef XML_DOC_TYPE_DEF//[2012.10.09][TID:9464][������] DTD�Լ� �߰�.
	if(m_pType)			BR_SAFE_FREE(m_pType);
#endif
}

BrBOOL CDocxGroup::CallbackStartElement(LPVOID pParam)
{
	XMLDataDecodeParam* pInfo = (XMLDataDecodeParam*)pParam;
	const char* pName = trimNamespace(pInfo->pElementData->pElementName);
	switch(pName[0])
	{
	case 'g':
		if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_GROUP))
		{
			CDocxGroup *pDocxGroup = BrNEW CDocxGroup(m_pDocxConv, BrTRUE);
			pDocxGroup->readDrawGroupInfo(pInfo);
			MakeRectDrawInGroup(pDocxGroup->m_pStyle);
			pDocxGroup->MakeDrawGroup();

			pInfo->callbackParam.pCurrentInstance = pDocxGroup;
			pInfo->nElementOption |= BR_XML_NEED_END_ELEMENT;
		}
		break;
	case 'l':
		if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_LINE)) //line
		{
			CDocxVMLLine *pDrawLine = BrNEW CDocxVMLLine(m_pDocxConv, BrTRUE);
			if(!pDrawLine)
			{
				pInfo->nElementOption |= BR_XML_SKIP_ELEMENT;
				return BrFALSE;
			}

			pDrawLine->readDrawLineInfo(pInfo);

			pInfo->callbackParam.wParam = DOCX_DRAWINFO;
			pInfo->callbackParam.pCurrentInstance = (CDocxDrawAttr*)pDrawLine;
			pInfo->nElementOption |= BR_XML_NEED_END_ELEMENT;
		}
		break;
	case 's':
		//hnsong:2012-10-26 shapetype+shape�� ������ ó���ǵ��� ����
		//shapetype�� �ִ� �Ӽ��� setting
 		if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_SHAPETYPE))
		{//hnsong:2012-09-21 modify
			if( !m_pDocxShape) {
				m_pDocxShape = BrNEW CDocxShape(m_pDocxConv, BrTRUE);
				if(!m_pDocxShape)
				{
					pInfo->nElementOption |= BR_XML_SKIP_ELEMENT;
					return BrFALSE;
				}

				((CDocxDrawAttr*)m_pDocxShape)->readDrawShapeType(pInfo);
			}
		}
 		else if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_SHAPE))
		{
			if( !m_pDocxShape) {
				m_pDocxShape = BrNEW CDocxShape(m_pDocxConv, BrTRUE);
				if(!m_pDocxShape)
				{
					pInfo->nElementOption |= BR_XML_SKIP_ELEMENT;
					return BrFALSE;
				}
			}

			m_pDocxShape->readDrawShapeInfo(pInfo);

			pInfo->callbackParam.wParam = DOCX_DRAWINFO;
			pInfo->callbackParam.pCurrentInstance = (CDocxDrawAttr*)m_pDocxShape;
			pInfo->nElementOption |= BR_XML_NEED_END_ELEMENT;
		}
		break;

	case 'o':
		if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_OVAL)) //circle
		{
			CDocxVML *pDrawEllipse = BrNEW CDocxVML(m_pDocxConv, BrTRUE);
			if(!pDrawEllipse)
			{
				pInfo->nElementOption |= BR_XML_SKIP_ELEMENT;
				return BrFALSE;
			}
			pDrawEllipse->readDrawInfo(pInfo);

			pInfo->callbackParam.wParam = DOCX_DRAWINFO;
			pInfo->callbackParam.pCurrentInstance = (CDocxDrawAttr*)pDrawEllipse;
			pInfo->nElementOption |= BR_XML_NEED_END_ELEMENT;
		}
		break;

	case 'p':
		if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_POLYLINE)) //polyline
		{
			CDocxVMLPolyLine *pDrawPoly = BrNEW CDocxVMLPolyLine(m_pDocxConv, BrTRUE);
			if(!pDrawPoly)
			{
				pInfo->nElementOption |= BR_XML_SKIP_ELEMENT;
				return BrFALSE;
			}
			pDrawPoly->readDrawPolyLineInfo(pInfo);

			pInfo->callbackParam.wParam = DOCX_DRAWINFO;
			pInfo->callbackParam.pCurrentInstance = (CDocxDrawAttr*)pDrawPoly;
			pInfo->nElementOption |= BR_XML_NEED_END_ELEMENT;
		}
		break;
	case 'r':
		if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_RECT) ||//v:rect rectangle
			0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_ROUNDRECT)) //round rectangle
		{
			CDocxVML *pDrawRect = BrNEW CDocxVML(m_pDocxConv, BrTRUE);
			if(!pDrawRect)
			{
				pInfo->nElementOption |= BR_XML_SKIP_ELEMENT;
				return BrFALSE;
			}

			pDrawRect->readDrawInfo(pInfo);

			pInfo->callbackParam.wParam = DOCX_DRAWINFO;
			pInfo->callbackParam.pCurrentInstance = (CDocxDrawAttr*)pDrawRect;
			pInfo->nElementOption |= BR_XML_NEED_END_ELEMENT;
		}
		break;
	case 'w':
		if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_WRAP))
		{
			if( !pInfo->pElementData->pAttributePairs )
				break;

			CDocxDrawAttr *pDrawAttr = (CDocxDrawAttr*)this;
			for (BrINT32 i = 0; pInfo->pElementData->pAttributePairs[i]; i += 2)
			{
				if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], X_DOC_DRAW_TYPE))
				{
					if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i+1], X_DOC_DRAW_WRAP_TOPANDBOTTOM))
					{
						pDrawAttr->m_nWrappingMode = FULL_RUN_AROUND;
					}
					else if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i+1], X_DOC_DRAW_WRAP_NONE))
					{
						pDrawAttr->m_nWrappingMode = NO_RUN_AROUND;
					}
					else if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i+1], X_DOC_DRAW_WRAP_TIGHT))
					{
						pDrawAttr->m_nWrappingMode = TIGHT_RUN_AROUND;
					}
					else if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i+1], X_DOC_DRAW_WRAP_THROUGH))
					{
						pDrawAttr->m_nWrappingMode = THROUGH_RUN_AROUND;
					}
					else		// "square"
					{
						pDrawAttr->m_nWrappingMode = PART_RUN_AROUND;
					}
				}
				else if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], "anchorx"))
				{
				}
				else if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], "anchory"))
				{
				}
				else if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], "side"))
				{
				}
			}
		}
		break;
	case 'a':
		if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_ANCHORLOCK))
		{
			CDocxDrawAttr *pDrawAttr = (CDocxDrawAttr*)this;
			pDrawAttr->m_bAnchorLock = BrTRUE;
		}
		break;
	}

	return BrTRUE;
}

BrBOOL	CDocxGroup::MakeDrawGroup()
{
	if(!m_pStyle)
		return BrFALSE;

// 	if(m_pStyle->m_nWidthPercent)
// 	{
// 		BrLONG basicFrameWidth = m_pDocxConv->m_pCurPage->getBFrameList()->getLast()->getFrameRect()->getWidth();
// 		m_pStyle->m_nWidth = (BrINT32)(basicFrameWidth * m_pStyle->m_nWidthPercent);
// 	}
	//[2012-08-17][toypilot][T-8434]group���� ��� ��ġ ���� ����
	if (m_pStyle->m_dMarginTopPercent && (!m_pStyle->m_bMarginTop || m_pStyle->m_nMarginTop == 0))
	{
		BrLONG basicHeight = 0;
		if (MSO_PAGE == m_pStyle->m_nPosVerRel)
			basicHeight = m_pDocxConv->m_pCurPage->getPaperSize()->height();

		m_pStyle->m_nMarginTop = (BrINT32)((basicHeight * m_pStyle->m_dMarginTopPercent) / 100);
	}
	if (m_pStyle->m_dMarginLeftPercent && (!m_pStyle->m_bMarginLeft || m_pStyle->m_nMarginLeft == 0))
	{
		BrLONG basicWidth = 0;
		if (MSO_PAGE == m_pStyle->m_nPosHorRel)
			basicWidth = m_pDocxConv->m_pCurPage->getPaperSize()->width();
		m_pStyle->m_nMarginLeft = (BrINT32)((basicWidth * m_pStyle->m_dMarginLeftPercent) / 100);
	}

	BrBOOL bAnchorType = BrFALSE;
	BRect Rect;
	if(m_bInGroup)
		Rect.setRect(m_pStyle->m_nLeft, m_pStyle->m_nTop,
		m_pStyle->m_nLeft+m_pStyle->m_nWidth, m_pStyle->m_nTop+m_pStyle->m_nHeight);
	else
		Rect.setRect(m_pStyle->m_nMarginLeft, m_pStyle->m_nMarginTop, 
		m_pStyle->m_nMarginLeft+m_pStyle->m_nWidth, m_pStyle->m_nMarginTop+m_pStyle->m_nHeight);

	m_pGroupFrame = m_pDocxConv->createFrame(GROUPFRAME, &Rect, bAnchorType, m_pDocxConv->m_pCurPage->getPageNum(), BrTRUE);
	if(!m_pGroupFrame)
		return NULL;

	CFrameList* pSubFrameList = (CFrameList*)m_pGroupFrame->getSubFrame();
	if(pSubFrameList)
		pSubFrameList->setParentFrame(m_pGroupFrame);

	//[2013.07.24][������][M34552]Canvas Frame Check
	if(m_pType && strcmp("canvas", m_pType) == 0)
		m_pGroupFrame->setDrawingCanvas(BrTRUE);
	
	convertGrapAttForGroup(m_pGroupFrame);

	if(m_pStyle->m_nZIndex)		//MistY - 2008.08.12
	{
		if( (m_pStyle->m_nZIndex< 0) && (m_pStyle->m_nZIndex != DEF_Z_INDEX) )	
			m_pGroupFrame->setUnderBasic(TRUE);
		m_pGroupFrame->setZindex(m_pStyle->m_nZIndex);
	}

	//jjoo:2008-11-06
	//if(BrStrLen(pDocxGroup->m_pID))	//MistY - 2008.08.13
	//	pFrame->m_lspid = BrAtoi(&pDocxGroup->m_pID[8]);
	if(m_pSPID)
		m_pGroupFrame->setSpid(BrAtoi(&m_pSPID[8]));
	else
	{
		if(m_pID)
			m_pGroupFrame->setSpid(BrAtoi(&m_pID[8]));
	}
	//~jjoo

	// nkyumi.10-08-09.�׷� ���� ������ �ʿ��ؼ� �߰�
	m_pGroupFrame->setCoordOriginX(m_nCoordOriginX);
	m_pGroupFrame->setCoordOriginY(m_nCoordOriginY);
	m_pGroupFrame->setCoordSizeX(m_nCoordSizeX);
	m_pGroupFrame->setCoordSizeY(m_nCoordSizeY);
	return BrTRUE;
}

void CDocxGroup::convertGrapAttForGroup(CFrame *pFrame)
{
	if(!pFrame)
		return;

	BrGrapAtt* pGrapAtt = (BrGrapAtt*)pFrame->getBorder();
	if(!pGrapAtt)
		return;

	pGrapAtt->setOffice2007ShapeDocx(0);
	pGrapAtt->setOffice2007Shape(0);
	pGrapAtt->getPen()->setLineType(BMV_DASHSTYLE_NONE);

	if(!m_pStyle)
		return;

	//jjoo:2008-06-04:rotation setting

	if(m_pStyle->m_bFlipX)
	{
		//pFrame->getBorder()->m_bFlip = BrTRUE;
		pGrapAtt->setFlipX(BrTRUE);
	}

	if(m_pStyle->m_bFlipY) 
	{
		//pFrame->getBorder()->m_bMirror = BrTRUE;
		pGrapAtt->setFlipY(BrTRUE);
	}

	if(m_pStyle->m_nRotation)
	{
		//[2012.01.05][TID : 3067][���ؼ�] �Ʒ� �κ��� �׷쵵�� ȸ���� ���� �ߺ����� �����ϴ� �κ��̸� ���Ŀ� grapAtt���� ���� �� ���� ��� �����ؾ� ��
		pFrame->SetRotation(m_pStyle->m_nRotation);
		pGrapAtt->setRotation(m_pStyle->m_nRotation);
	}

	if(m_pStyle->m_bFlipY)
	{
		pGrapAtt->setRotation(360 - pFrame->GetRotation());
		pFrame->SetRotation(360 - pFrame->GetRotation());
	}
}


BrBOOL CDocxGroup::CallbackEndElement(LPVOID pParam)
{
	XMLDataDecodeParam* pInfo = (XMLDataDecodeParam*)pParam;
	const char *pName = trimNamespace(pInfo->pElementData->pElementName);

	CFrame *pFrame = NULL;
	switch(pName[0])
	{
	case 'g':
		if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_GROUP))
		{
			CDocxGroup *pDocxGroup = (CDocxGroup *)pInfo->callbackParam.pCurrentInstance;

			pFrame = pDocxGroup->m_pGroupFrame;
			////�ֻ��� group�� ��
			//if( BrFALSE == m_bInGroup && m_pStyle->m_nZIndex)	{
			//	if(pFrame && (!(pFrame->getZindex()) || pFrame->getZindex() == DEF_Z_INDEX) )
			//		pFrame->setZindex(m_pStyle->m_nZIndex);
			//}

			//[2013.03.14][������][M-25579] �׷��� �ߺ��ؼ� ������ �� �߰��� �׷������� ȸ�� ����
			if( pFrame )
			{
				if(pFrame->isGroup())
					theBWordDoc->getCmdEngine()->convertGroupSubFramesMSToBWP(pFrame);
			}

			BrDELETE pDocxGroup;
		}
		break;

	case 'l':
		if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_LINE) )
		{
			CDocxVMLLine *pDrawLine = (CDocxVMLLine *)pInfo->callbackParam.pCurrentInstance;

			//jjoo:2008-08-08:������ Rect�� From, To�� �����ϹǷ�
			MakeRectDrawInGroup(pDrawLine->m_pStyle);
			if(pDrawLine->pointSetBit[FromToSetBit_From_X])
				pDrawLine->m_nFrom.x = (BrINT32)(m_pStyle->m_nLeft + (pDrawLine->m_nFrom.x - m_nCoordOriginX) * ((BrDOUBLE)m_pStyle->m_nWidth/m_nCoordSizeX)) + m_pStyle->m_nMarginLeft;
			else
				pDrawLine->m_nFrom.x = (BrINT32)(pDrawLine->m_pStyle->m_nLeft);// + (pDrawLine->m_pStyle->m_nLeft - m_nCoordOriginX) * ((BrDOUBLE)pDrawLine->m_pStyle->m_nWidth/m_nCoordSizeX)) + pDrawLine->m_pStyle->m_nMarginLeft;

			if(pDrawLine->pointSetBit[FromToSetBit_From_Y])
				pDrawLine->m_nFrom.y = (BrINT32)(m_pStyle->m_nTop + (pDrawLine->m_nFrom.y - m_nCoordOriginY) * ((BrDOUBLE)m_pStyle->m_nHeight/m_nCoordSizeY)) + m_pStyle->m_nMarginTop;
			else
				pDrawLine->m_nFrom.y = (BrINT32)(pDrawLine->m_pStyle->m_nTop);// + (pDrawLine->m_pStyle->m_nTop - m_nCoordOriginY) * ((BrDOUBLE)pDrawLine->m_pStyle->m_nWidth/m_nCoordSizeX)) + pDrawLine->m_pStyle->m_nMarginTop;

			if(pDrawLine->pointSetBit[FromToSetBit_To_X])
				pDrawLine->m_nTo.x = (BrINT32)(m_pStyle->m_nLeft + (pDrawLine->m_nTo.x - m_nCoordOriginX) * ((BrDOUBLE)m_pStyle->m_nWidth/m_nCoordSizeX)) + m_pStyle->m_nMarginLeft;
			else
				pDrawLine->m_nTo.x = (BrINT32)(pDrawLine->m_pStyle->m_nLeft + pDrawLine->m_pStyle->m_nWidth);// + ((pDrawLine->m_pStyle->m_nLeft + pDrawLine->m_pStyle->m_nWidth) - m_nCoordOriginX) * ((BrDOUBLE)pDrawLine->m_pStyle->m_nWidth/m_nCoordSizeX)) + pDrawLine->m_pStyle->m_nMarginLeft;

			if(pDrawLine->pointSetBit[FromToSetBit_To_Y])
				pDrawLine->m_nTo.y = (BrINT32)(m_pStyle->m_nTop + (pDrawLine->m_nTo.y - m_nCoordOriginY) * ((BrDOUBLE)m_pStyle->m_nHeight/m_nCoordSizeY)) + m_pStyle->m_nMarginTop;
			else
				pDrawLine->m_nTo.y = (BrINT32)(pDrawLine->m_pStyle->m_nTop + pDrawLine->m_pStyle->m_nHeight);// + ((pDrawLine->m_pStyle->m_nTop + pDrawLine->m_pStyle->m_nHeight) - m_nCoordOriginY) * ((BrDOUBLE)pDrawLine->m_pStyle->m_nHeight/m_nCoordSizeY)) + pDrawLine->m_pStyle->m_nMarginTop;

			pFrame = pDrawLine->convertDrawLine();

			BrDELETE pDrawLine;
		}
		break;

	case 'p':
		if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_POLYLINE) )
		{
			CDocxVMLPolyLine *pDrawPoly = (CDocxVMLPolyLine *)pInfo->callbackParam.pCurrentInstance;
			if(pDrawPoly && pDrawPoly->m_pStyle && pDrawPoly->m_pStyle->m_bVisibility)
			{
				MakeRectDrawInGroup(pDrawPoly->m_pStyle);

				pFrame = pDrawPoly->convertDrawPolyLine();
			}

			BrDELETE pDrawPoly;
		}
		break;
	case 'r':
	case 'o':
		if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_RECT) ||
			0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_ROUNDRECT) ||
			0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_OVAL) )
		{
			CDocxVML *pDocxDraw = (CDocxVML *)pInfo->callbackParam.pCurrentInstance;
			if(pDocxDraw && pDocxDraw->m_pStyle && pDocxDraw->m_pStyle->m_bVisibility)
			{
				MakeRectDrawInGroup(pDocxDraw->m_pStyle);
				pFrame = pDocxDraw->convertDraw(pInfo->pCurPackagePartName);
			}

			BrDELETE pDocxDraw;
		}
		break;
	case 's':
		if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_SHAPE) )
		{
			CDocxShape *pDocxShape = (CDocxShape *)pInfo->callbackParam.pCurrentInstance;
			if(pDocxShape && pDocxShape->m_pStyle && pDocxShape->m_pStyle->m_bVisibility)
			{
				if( m_pType && strcmp(m_pType, "canvas") == 0 && m_bCanvasFirstShape )
				{
					m_bCanvasFirstShape = BrFALSE;
					break;
				}				
				MakeRectDrawInGroup(pDocxShape->m_pStyle);
				pFrame = pDocxShape->convertShape(pInfo->pCurPackagePartName, BrTRUE);
			}

			if( m_pDocxShape == pDocxShape)
				m_pDocxShape = BrNULL;

			BrDELETE pDocxShape;
		}
		break;
	}

	if(!pFrame)
		return BrFALSE;


	//[2012.01.17][TID : 3431][���ؼ�] �׷� �������� ������ �ִ� ����/�¿� ���� �Ӽ��� ���� �����ӿ� ����
	BrGrapAtt* pGroupGrapAtt = (BrGrapAtt*)m_pGroupFrame->getBorder();
	BrGrapAtt* pGrapAtt = (BrGrapAtt*)pFrame->getBorder();
	
	if(pGroupGrapAtt && pGrapAtt)
	{
		if(pGroupGrapAtt->getFlipX())
		{
			if(pGrapAtt->getFlipX())
				pGrapAtt->setFlipX(BrFALSE);
			else
				pGrapAtt->setFlipX(BrTRUE);
		}

		if(pGroupGrapAtt->getFlipY())
		{
			if(pGrapAtt->getFlipY())
				pGrapAtt->setFlipY(BrFALSE);
			else
				pGrapAtt->setFlipY(BrTRUE);
		}
	}

	CFrameList *pFrameList = (CFrameList*)m_pGroupFrame->getSubFrame();

	if(pFrameList)
		pFrameList->insertAtTail(pFrame,pFrame->getZindex());//MistY - 2008.08.12 

	return BrTRUE;
}


void CDocxGroup::MakeRectDrawInGroup(CDocxDrawStyle	*pStyle)
{
	// if(pStyle->m_nLeft > 0)
	//	pStyle->m_nLeft = (BrINT32)((BrDOUBLE)pStyle->m_nLeft * (BrDOUBLE)m_pStyle->m_nLeft / m_nCoordOriginX);
	//pStyle->m_nLeft = (BrINT32)(m_pStyle->m_nLeft + (pStyle->m_nLeft - m_nCoordOriginX) * ((BrDOUBLE)m_pStyle->m_nWidth/m_nCoordSizeX));
	pStyle->m_nLeft = (BrINT32)(m_pStyle->m_nLeft + (pStyle->m_nLeft - m_nCoordOriginX) * ((BrDOUBLE)m_pStyle->m_nWidth/m_nCoordSizeX)) + m_pStyle->m_nMarginLeft;	//jjoo:2008-08-08

	// if(pStyle->m_nTop > 0)
	//	pStyle->m_nTop = (BrINT32)((BrDOUBLE)pStyle->m_nTop * (BrDOUBLE)m_pStyle->m_nTop / m_nCoordOriginY);
	//pStyle->m_nTop = (BrINT32)(m_pStyle->m_nTop + (pStyle->m_nTop - m_nCoordOriginY) * ((BrDOUBLE)m_pStyle->m_nHeight/m_nCoordSizeY));
	pStyle->m_nTop = (BrINT32)(m_pStyle->m_nTop + (pStyle->m_nTop - m_nCoordOriginY) * ((BrDOUBLE)m_pStyle->m_nHeight/m_nCoordSizeY)) + m_pStyle->m_nMarginTop;	//jjoo:2008-08-08

	if(pStyle->m_nWidth > 0)
		pStyle->m_nWidth = (BrINT32)((BrDOUBLE)pStyle->m_nWidth * (BrDOUBLE)m_pStyle->m_nWidth / m_nCoordSizeX);

	if(pStyle->m_nHeight > 0)
		pStyle->m_nHeight = (BrINT32)((BrDOUBLE)pStyle->m_nHeight * (BrDOUBLE)m_pStyle->m_nHeight / m_nCoordSizeY);


}

BrBOOL CDocxGroup::readDrawGroupInfo(XMLDataDecodeParam*  pInfo)
{
	if( !pInfo->pElementData->pAttributePairs)
		return BrFALSE;

	BrCHAR *pBuf;
	for( BrINT32 i = 0; pInfo->pElementData->pAttributePairs[i]; i+= 2)
	{
		DRAW_RESULT nResult = readObjectInfo(pInfo->pElementData->pAttributePairs[i], pInfo->pElementData->pAttributePairs[i+1]);
		if( DRAW_ETC == nResult )
		{
			const BrCHAR *pStr = pInfo->pElementData->pAttributePairs[i];
			switch(pStr[0])
			{
			case 'c':
				if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], X_DOC_DRAW_SHAPE_COORDSIZE) )
				{
					BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
					pBuf = (BrCHAR*)BrMalloc(nLen+1);
					memcpy(pBuf, pInfo->pElementData->pAttributePairs[i+1], nLen);
					pBuf[nLen] = 0;
					BrCHAR *pTmp = pBuf;

					BrCHAR seps[]   = ",";
					char* pContext = BrNULL;
					BrCHAR *ch = strtok_s(pTmp, seps, &pContext);
					if( ch )
					{
						if(pBuf[0] == ',')
						{
							m_nCoordSizeX = 1000;
							m_nCoordSizeY = BrAtoi(ch);
						}
						else
						{
							m_nCoordSizeX = BrAtoi(ch);
							ch = strtok_s(NULL, seps, &pContext);
							if(ch)
								m_nCoordSizeY = BrAtoi(ch);
						}
					}
					BrFree(pBuf);
				}
				else if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], X_DOC_DRAW_SHAPE_COORDORIGIN) )
				{
					BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
					pBuf = (BrCHAR*)BrMalloc(nLen+1);
					memcpy(pBuf, pInfo->pElementData->pAttributePairs[i+1], nLen);
					pBuf[nLen] = 0;
					BrCHAR *pTmp = pBuf;
					BrCHAR seps[]   = ",";
					char* pContext = BrNULL;
					BrCHAR *ch = strtok_s(pTmp, seps, &pContext);
					if( ch )
					{
						if(pBuf[0] == ',')
						{
							m_nCoordOriginX = 0;
							m_nCoordOriginY = BrAtoi(ch);
						}
						else
						{
							m_nCoordOriginX = BrAtoi(ch);

							ch = strtok_s(NULL, seps, &pContext);
							if(ch)
								m_nCoordOriginY = BrAtoi(ch);
						}
					}
					BrFree(pBuf);
				}
				break;
			case 'e':
				if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], X_DOC_DRAW_GROUP_TYPE) )
				{
					BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
#ifdef XML_DOC_TYPE_DEF//[2012.10.09][TID:9464][������] DTD�Լ� �߰�.
					EDTD_RESULT nRet = BrXMLDTDUtil::VMLDocTypeDefintion(eATTValueTypeString,eATTValueSubTypeString_ShapeType, pInfo->pElementData->pAttributePairs[i], pInfo->pElementData->pAttributePairs[i+1],m_pDocxConv);

					switch(nRet)
					{
					case DTD_SUCCESS:
						m_pType = (BrCHAR*)BrMalloc(nLen+1);
						memcpy(m_pType, pInfo->pElementData->pAttributePairs[i+1], nLen );
						m_pType[nLen] = 0;
						break;
					case DTD_NEED_DEFAULT_VALUE:
						break;
					case DTD_FAIL:
					case DTD_IGNOREELEMENT:
						return BrFALSE;
					}

#else
					memcpy(m_pType, pInfo->pElementData->pAttributePairs[i+1], nLen );
					m_pType[nLen] = 0;
#endif
				}
				break;
			}
		}
		else if (nResult == DRAW_FAIL)
			return BrFALSE;
	}

	return BrTRUE;
}

/////////////////////////////////////////////////////////////////////////
CDocxDrawingML::CDocxDrawingML(CDocxConv* pDocxConv)
{
	m_pDocxConv = pDocxConv;
	m_pShape = NULL;
	m_pShapePic = NULL;
	m_pShapeGroup = NULL;
	m_pGraphicData = NULL;
	
#ifdef IMPORT_DIAGRAMX	//MistY - 2009.04.25
	m_pGraphicDataDgm = NULL;	
#endif
	
	m_pPenShapeName = BrNULL; 

	m_bFloating = BrFALSE;
	m_fPosHPercent = 0;
	m_fPosVPercent = 0;
	m_nLocationTypeH = LT_ABSOLUTE;
	m_nLocationTypeV = LT_ABSOLUTE;
	m_bFallbackH = BrFALSE;
	m_bFallbackV = BrFALSE;
	m_nPosHRel = RT_PAGE;
	m_nPosVRel = RT_PAGE;
	m_bAllowOverlap = BrTRUE;
	m_nPosHAlign = MSO_ABSOLUTE;
	m_nPosVAlign = MSO_ABSOLUTE;
	m_nPosOffsetH = 0;
	m_nPosOffsetV = 0;
	m_bPosOffsetH = BrFALSE;
	m_bPosOffsetV = BrFALSE;
	m_nWrappingMode = 0;
	m_nAnchorBehindDoc = 0;
	m_bAnchorLocked = 0;
	m_nRelativeHeight = 0;
	m_rWrapRect.nLeft = m_rWrapRect.nRight = 180;
	m_rWrapRect.nTop = m_rWrapRect.nBottom = 0;
	m_rEffectExtent.setRect(0, 0, 0, 0);
	m_extent.cx = m_extent.cy = -1;
	m_simplePos.cx = m_simplePos.cy = 0;
	m_nPenID = 1;
	m_bLayoutInCell = BrFALSE;
	m_bHidden = BrFALSE;

	m_nPctWidth = 0;
	m_nPctHeight = 0;
	m_nSizeHRel = 0;
	m_nSizeVRel = 0;
	m_pGraphicFrameLocks = BrNULL;
	m_nObjectID = 0;
	m_pObjectName = BrNULL;
	m_pDescr = BrNULL;
	m_pTitle = BrNULL;
	m_pWrapText = BrNULL;

	m_nDistT = m_nDistB = m_nDistL = m_nDistR = 0;
	validation.DataBits.drawingValidate = 0;
	m_p3DShape = BrNULL;
}

CDocxDrawingML::~CDocxDrawingML()
{
	if(m_pShape)		BR_SAFE_DELETE(m_pShape);
	if(m_pShapePic)		BR_SAFE_DELETE(m_pShapePic);
	if(m_pShapeGroup)	BR_SAFE_DELETE(m_pShapeGroup);
	if(m_pGraphicData)	BR_SAFE_DELETE(m_pGraphicData);
	BR_SAFE_DELETE(m_pGraphicFrameLocks);
	BR_SAFE_FREE(m_pWrapText);
	BR_SAFE_FREE(m_pObjectName);
	BR_SAFE_FREE(m_pDescr);
	BR_SAFE_FREE(m_pTitle);
	
#ifdef IMPORT_DIAGRAMX	//MistY - 2009.04.25
	if(m_pGraphicDataDgm)		BR_SAFE_DELETE(m_pGraphicDataDgm);
#endif
	m_PolygonData.RemoveAll();
}

BrBOOL CDocxDrawingML::CallbackStartElement(LPVOID pParam)
{
	XMLDataDecodeParam* pInfo = (XMLDataDecodeParam*)pParam;

	switch( pInfo->callbackParam.wParam )
	{
	case DOCX_DRAW_DRAWING:
		readDrawingInfo(pInfo);
		break;
	}

	return BrTRUE;
}

BrBOOL CDocxDrawingML::CallbackEndElement(LPVOID pParam)
{
	XMLDataDecodeParam* pInfo = (XMLDataDecodeParam*)pParam;

	if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_DRAWING_POSOFFSET))
	{
		BrINT32 nStrLen = BrStrLen(pInfo->pElementData->pTextData);
		BrCHAR *pStrPosOffset = (BrCHAR*)BrMalloc(nStrLen+1);
		memcpy(pStrPosOffset, pInfo->pElementData->pTextData, nStrLen);
		pStrPosOffset[nStrLen] = 0;

		BrINT32	nVal = CDocxUtil::MSEMUtoTWIP(BrAtoi(pStrPosOffset));
		if(m_bPosOffsetH)
		{
			m_nPosOffsetH = nVal;
			m_nLocationTypeH = LT_ABSOLUTE;
		}

		if(m_bPosOffsetV)
		{
			m_nPosOffsetV = nVal;
			m_nLocationTypeV = LT_ABSOLUTE;
		}

		BrFree(pStrPosOffset);
	}
	else if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_DRAWING_ANCHOR))
	{
		
	}
	else if( 0 == strcmp(pInfo->pElementData->pElementName, E_AM3D_MODEL3D))
	{
		if(m_p3DShape)
		{
			HCM_XMLNODE sourcrURL = cmXMLNode_GetNodeByTagName(m_p3DShape->m_pModel3DDom->GetDOMDocument(), "am3d:attrSrcUrl");
			if(sourcrURL)
			{
				HCM_XMLATTRIBUTE embedAttr = cmXMLElement_GetAttribute(sourcrURL, "r:id");
				if(embedAttr)
				{
					domAttr* attributeNode = (domAttr*)embedAttr;
					m_p3DShape->m_strAttrSrcUrl = attributeNode->GetNodeValue()->GetBuffer();
				}
			}
		}
	}
	else if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_DRAWING_ALIGN))
	{
		BrINT32 nStrLen = BrStrLen(pInfo->pElementData->pTextData);
		BrCHAR* pStr = (BrCHAR*)BrMalloc(nStrLen+1);
		memcpy(pStr, pInfo->pElementData->pTextData, nStrLen);
		pStr[nStrLen] = 0;

		if(m_bPosOffsetH)
		{
			m_nLocationTypeH = LT_ALIGNMENT;

			if( 0 == strcmp(pStr, "left") )
				m_nPosHAlign = ALG_LEFT;
			else if( 0 == strcmp(pStr, "center") )
				m_nPosHAlign = ALG_CENTER;
			else if( 0 == strcmp(pStr, "right") )
				m_nPosHAlign = ALG_RIGHT;
			else if( 0 == strcmp(pStr, "inside") )
			{
				m_nLocationTypeH = LT_BOOKLAYOUT;
				m_nPosHAlign = ALG_INSIDE;
			}
			else if( 0 == strcmp(pStr, "outside") )
			{	m_nLocationTypeH = LT_BOOKLAYOUT;
			m_nPosHAlign = ALG_OUTSIDE;
			}
		}

		if(m_bPosOffsetV)
		{
			m_nLocationTypeV = LT_ALIGNMENT;

			if( 0 == strcmp(pStr, "top") )
				m_nPosVAlign = ALG_TOP;
			else if( 0 == strcmp(pStr, "center") )
				m_nPosVAlign = ALG_CENTER;
			else if( 0 == strcmp(pStr, "bottom") )
				m_nPosVAlign = ALG_BOTTOM;
			else if( 0 == strcmp(pStr, "inside") )
				m_nPosVAlign = ALG_INSIDE;
			else if( 0 == strcmp(pStr, "outside") )
				m_nPosVAlign = ALG_OUTSIDE;
		}

		BrFree(pStr);
	}
	else if( 0 == strcmp(pInfo->pElementData->pElementName, "wp14:pctPosHOffset"))
	{
		m_bFallbackH = BrTRUE;
		m_nLocationTypeH = LT_RELATIVE;
		BrINT32 nStrLen = BrStrLen(pInfo->pElementData->pTextData);
		BrCHAR *pStrPctOffset = (BrCHAR*)BrMalloc(nStrLen+1);
		memcpy(pStrPctOffset, pInfo->pElementData->pTextData, nStrLen);
		pStrPctOffset[nStrLen] = 0;

		BrFLOAT	nVal = BrAtoi(pStrPctOffset);
		if(m_bPosOffsetH)
			m_fPosHPercent = nVal / 1000.0;

		BrFree(pStrPctOffset);
	}
	else if( 0 == strcmp(pInfo->pElementData->pElementName, "wp14:pctPosVOffset"))
	{
		m_bFallbackV = BrTRUE;
		m_nLocationTypeV = LT_RELATIVE;
		BrINT32 nStrLen = BrStrLen(pInfo->pElementData->pTextData);
		BrCHAR *pStrPctOffset = (BrCHAR*)BrMalloc(nStrLen+1);
		memcpy(pStrPctOffset, pInfo->pElementData->pTextData, nStrLen);
		pStrPctOffset[nStrLen] = 0;

		BrFLOAT	nVal = BrAtoi(pStrPctOffset);

		if(m_bPosOffsetV)
			m_fPosVPercent = nVal / 1000.0;

		BrFree(pStrPctOffset);
	}
	else if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_DRAWING_POSITIONH))
	{
		validation.DataBits.flags.WP_positionH = 1;
 		m_bPosOffsetH = BrFALSE;
	}
	else if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_DRAWING_POSITIONV))
	{
		validation.DataBits.flags.WP_positionV = 1;
 		m_bPosOffsetV = BrFALSE;
	}
	else if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_DRAWING_PCTWIDTH	))
	{	//[2013.05.21][������][TID:15445] ���� ��� ũ�� ����
		m_nPctWidth = BrAtoi(pInfo->pElementData->pTextData);
	}
	else if( 0 == strcmp(pInfo->pElementData->pElementName, X_DOC_DRAW_DRAWING_PCTHEIGHT ))
	{
		m_nPctHeight = BrAtoi(pInfo->pElementData->pTextData);
	}

	return BrTRUE;
}

BrBOOL CDocxDrawingML::readDrawingInfo(XMLDataDecodeParam* pNode)
{
	if( 0 == strcmp(pNode->pElementData->pElementName, X_DOC_DRAW_DRAWING_INLINE))//wp:inline
	{//depth+1
		m_bFloating = BrFALSE;
	}
	else if( 0 == strcmp(pNode->pElementData->pElementName, X_DOC_DRAW_DRAWING_ANCHOR))//wp:anchor
	{//depth+1
		if( pNode->pElementData->pAttributePairs )
		{
			for (BrINT32 i = 0; pNode->pElementData->pAttributePairs[i]; i += 2)
			{
				//BrTrace("%s:%s", pNode->pElementData->pAttributePairs[i], pNode->pElementData->pAttributePairs[i+1]);
				if( 0 == strcmp(pNode->pElementData->pAttributePairs[i], "behindDoc"))
				{
					m_nAnchorBehindDoc = BrAtoi(pNode->pElementData->pAttributePairs[i+1]);
				}
				else if( 0 == strcmp(pNode->pElementData->pAttributePairs[i], "allowOverlap"))
				{
					BrLONG nVal = BrAtol(pNode->pElementData->pAttributePairs[i+1]);
					if(!nVal)
						m_bAllowOverlap = BrFALSE;
				}
				else if( 0 == strcmp(pNode->pElementData->pAttributePairs[i], "relativeHeight"))
				{
					m_nRelativeHeight = BrAtol(pNode->pElementData->pAttributePairs[i+1]);
				}//[2012.08.10][������][TID:8490]�ؽ�Ʈ���� ��������.
				else if(  0 == strcmp(pNode->pElementData->pAttributePairs[i], "distT"))//Top
				{
					BrLONG nTempval = BrAtol(pNode->pElementData->pAttributePairs[i+1]);
					m_nDistT = BrMulDiv2(nTempval, 1440,  254 * 3600); // 360000 EMU
				}
				else if(  0 == strcmp(pNode->pElementData->pAttributePairs[i], "distB"))//Bottom
				{
					BrLONG nTempval = BrAtol(pNode->pElementData->pAttributePairs[i+1]);
					m_nDistB = BrMulDiv2(nTempval, 1440,  254 * 3600); // 360000 EMU
				}
				else if(  0 == strcmp(pNode->pElementData->pAttributePairs[i], "distL"))//Left
				{
					BrLONG nTempval = BrAtol(pNode->pElementData->pAttributePairs[i+1]);
					m_nDistL = BrMulDiv2(nTempval, 1440,  254 * 3600); // 360000 EMU
				}
				else if(  0 == strcmp(pNode->pElementData->pAttributePairs[i], "distR"))//Right
				{
					BrLONG nTempval = BrAtol(pNode->pElementData->pAttributePairs[i+1]);
					m_nDistR = BrMulDiv2(nTempval, 1440,  254 * 3600); // 360000 EMU
				}
				else if( 0 == strcmp(pNode->pElementData->pAttributePairs[i], "layoutInCell"))//layoutInCell
				{
					BrINT32 nTempval = BrAtol(pNode->pElementData->pAttributePairs[i+1]);
					m_bLayoutInCell = (nTempval == 0) ? BrFALSE : BrTRUE;
				}
				else if( 0 == strcmp(pNode->pElementData->pAttributePairs[i], "locked"))//locked
				{
					BrINT32 nTempval = BrAtol(pNode->pElementData->pAttributePairs[i+1]);
					m_bAnchorLocked = (nTempval == 0) ? BrFALSE : BrTRUE;
				}
			}

		}
		m_bFloating = BrTRUE;
	}
	else if( 0 == strcmp(pNode->pElementData->pElementName, X_DOC_DRAW_DRAWING_POSITIONH) || 0 == strcmp(pNode->pElementData->pElementName, X_DOC_DRAW_DRAWING_POSITIONV) ||
		(0 == strcmp(pNode->pElementData->pElementName, X_DOC_DRAW_DRAWING_SIZERELH)) || (0 == strcmp(pNode->pElementData->pElementName, X_DOC_DRAW_DRAWING_SIZERELV)))
	{//depth+2
		if( pNode->pElementData->pAttributePairs )
		{
			int nPosRel = 0;
			BrCHAR *pStrPos = NULL;
			for (BrINT32 i = 0; pNode->pElementData->pAttributePairs[i]; i += 2)
			{
				//BrTrace("%s:%s", pNode->pElementData->pAttributePairs[i], pNode->pElementData->pAttributePairs[i+1]);
				if( 0 == strcmp(pNode->pElementData->pAttributePairs[i], "relativeFrom"))
				{
					BR_SAFE_FREE(pStrPos);
					BrINT nLen = BrStrLen(pNode->pElementData->pAttributePairs[i+1]);
					pStrPos = (BrCHAR*)BrMalloc(nLen+1);
					if(!pStrPos)
						return SetErrorFReturn(CFilterError(kPoErrMemory));
					memset(pStrPos, 0, nLen+1);
					memcpy(pStrPos, pNode->pElementData->pAttributePairs[i+1], nLen);
				}
			}

			if(  0 == strcmp(pNode->pElementData->pElementName, X_DOC_DRAW_DRAWING_POSITIONH) )
			{
				if(!m_bFallbackH && pStrPos)
				{
					m_bPosOffsetH = BrTRUE;

					if( 0 == strcmp(pStrPos, "margin") )
						m_nPosHRel = RT_MARGIN;
					else if( 0 == strcmp(pStrPos, "page") )
						m_nPosHRel = RT_PAGE;
					else if( 0 == strcmp(pStrPos, "column") )
						m_nPosHRel = RT_COLUMN;
					else if( 0 == strcmp(pStrPos, "character") )
						m_nPosHRel = RT_CHARACTER;
					else if( 0 == strcmp(pStrPos, "leftMargin") )
						m_nPosHRel = RT_LEFT_MARGIN;
					else if( 0 == strcmp(pStrPos, "rightMargin") )
						m_nPosHRel = RT_RIGHT_MARGIN;
					else if( 0 == strcmp(pStrPos, "insideMargin") )
						m_nPosHRel = RT_PADDING;
					else if(  0 == strcmp(pStrPos, "outsideMargin") )
						m_nPosHRel = RT_OUTSIDE_MARGIN;
				}
			}
			else if(0 == strcmp(pNode->pElementData->pElementName, X_DOC_DRAW_DRAWING_POSITIONV))
			{
				if(!m_bFallbackV && pStrPos)
				{
					m_bPosOffsetV = BrTRUE;

					if( 0 == strcmp(pStrPos, "margin") )
						m_nPosVRel = RT_MARGIN;
					else if( 0 == strcmp(pStrPos, "page") )
						m_nPosVRel = RT_PAGE;
					else if( 0 == strcmp(pStrPos, "paragraph") )
						m_nPosVRel = RT_PARAGRAPH;
					else if( 0 == strcmp(pStrPos, "line") )
						m_nPosVRel = RT_LINE;
					else if( 0 == strcmp(pStrPos, "topMargin") )
						m_nPosVRel = RT_TOP_MARGIN;
					else if( 0 == strcmp(pStrPos, "bottomMargin") )
						m_nPosVRel = RT_BOTTOM_MARGIN;
					else if( 0 == strcmp(pStrPos, "insideMargin") )
						m_nPosVRel = RT_PADDING;
					else if( 0 == strcmp(pStrPos, "outsideMargin") )
						m_nPosVRel = RT_OUTSIDE_MARGIN;
				}
			}
			else if(0 == strcmp(pNode->pElementData->pElementName, X_DOC_DRAW_DRAWING_SIZERELH))
			{	//[2013.05.21][������][TID:15445] ���� ��� ũ�� ����
				if( 0 == strcmp(pStrPos, "margin") )
					m_nSizeHRel = RT_MARGIN;
				else if( 0 == strcmp(pStrPos, "page") )
					m_nSizeHRel = RT_PAGE;
				else if( 0 == strcmp(pStrPos, "leftMargin") )
					m_nSizeHRel = RT_LEFT_MARGIN;
				else if( 0 == strcmp(pStrPos, "rightMargin") )
					m_nSizeHRel = RT_RIGHT_MARGIN;
				else if( 0 == strcmp(pStrPos, "insideMargin") )
					m_nSizeHRel = RT_PADDING;
				else if( 0 == strcmp(pStrPos, "outsideMargin") )
					m_nSizeHRel = RT_OUTSIDE_MARGIN;
			}
			else if(0 == strcmp(pNode->pElementData->pElementName, X_DOC_DRAW_DRAWING_SIZERELV))
			{	
				if( 0 == strcmp(pStrPos, "margin") )
					m_nSizeVRel = RT_MARGIN;
				else if( 0 == strcmp(pStrPos, "page") )
					m_nSizeVRel = RT_PAGE;
				else if( 0 == strcmp(pStrPos, "topMargin") )
					m_nSizeVRel = RT_TOP_MARGIN;
				else if( 0 == strcmp(pStrPos, "bottomMargin") )
					m_nSizeVRel = RT_BOTTOM_MARGIN;
				else if( 0 == strcmp(pStrPos, "insideMargin") )
					m_nSizeVRel = RT_PADDING;
				else if( 0 == strcmp(pStrPos, "outsideMargin") )
					m_nSizeVRel = RT_OUTSIDE_MARGIN;
			}

			BrFree(pStrPos);
		}

		pNode->nElementOption |= BR_XML_NEED_END_ELEMENT;
	}
	else if( 0 == strcmp(pNode->pElementData->pElementName, X_DOC_DRAW_DRAWING_POSOFFSET))
	{
		pNode->nElementOption |= BR_XML_NEED_END_ELEMENT;
	}
	else if( 0 == strcmp(pNode->pElementData->pElementName, X_DOC_DRAW_DRAWING_ALIGN))
	{
		pNode->nElementOption |= BR_XML_NEED_END_ELEMENT;
	}
	else if( 0 == strcmp(pNode->pElementData->pElementName, X_DOC_DRAW_DRAWING_GRAPIC))
	{//depth+2
		validation.DataBits.flags.WP_graphic = 1;
	}
	else if( 0 == strcmp(pNode->pElementData->pElementName, X_DOC_DRAW_DRAWING_WRAPNONE))
	{//depth+2
		m_nWrappingMode = 3;
	}
	else if( 0 == strcmp(pNode->pElementData->pElementName, X_DOC_DRAW_DRAWING_WRAPSQUARE))
	{//depth+2
		if( pNode->pElementData->pAttributePairs )
		{
			for (BrINT32 i = 0; pNode->pElementData->pAttributePairs[i]; i += 2)
			{
				if( 0 == strcmp(pNode->pElementData->pAttributePairs[i], "wrapText"))
				{
					BrINT32 nLen = BrStrLen(pNode->pElementData->pAttributePairs[i+1]);
					m_pWrapText = (BrCHAR*)BrMalloc(nLen+1);
					memcpy(m_pWrapText, pNode->pElementData->pAttributePairs[i+1], nLen);
					m_pWrapText[nLen] = 0;	
				}
			}
		}
		m_nWrappingMode = 2;
	}
	else if( 0 == strcmp(pNode->pElementData->pElementName, X_DOC_DRAW_DRAWING_WRAPTHROUGH))
	{//depth+2
		if( pNode->pElementData->pAttributePairs )
		{
			for (BrINT32 i = 0; pNode->pElementData->pAttributePairs[i]; i += 2)
			{
				if( 0 == strcmp(pNode->pElementData->pAttributePairs[i], "wrapText"))
				{
					BrINT32 nLen = BrStrLen(pNode->pElementData->pAttributePairs[i+1]);
					m_pWrapText = (BrCHAR*)BrMalloc(nLen+1);
					memcpy(m_pWrapText, pNode->pElementData->pAttributePairs[i+1], nLen);
					m_pWrapText[nLen] = 0;	
				}
			}
		}
		m_nWrappingMode = 5;
	}
	else if( 0 == strcmp(pNode->pElementData->pElementName, X_DOC_DRAW_DRAWING_WRAPTIGHT))
	{//depth+2
		if( pNode->pElementData->pAttributePairs )
		{
			for (BrINT32 i = 0; pNode->pElementData->pAttributePairs[i]; i += 2)
			{
				if( 0 == strcmp(pNode->pElementData->pAttributePairs[i], "wrapText"))
				{
					BrINT32 nLen = BrStrLen(pNode->pElementData->pAttributePairs[i+1]);
					m_pWrapText = (BrCHAR*)BrMalloc(nLen+1);
					memcpy(m_pWrapText, pNode->pElementData->pAttributePairs[i+1], nLen);
					m_pWrapText[nLen] = 0;	
				}
			}
		}
		m_nWrappingMode = 4;
	}
	else if( 0 == strcmp(pNode->pElementData->pElementName, "wp:wrapPolygon"))
	{//depth+3
		if( pNode->pElementData->pAttributePairs )
		{
			if(pNode->pElementData->pAttributePairs[0] && 0 == strcmp(pNode->pElementData->pAttributePairs[0], "edited"))
			{
				//����
			}
		}
	}
	else if( 0 == strcmp(pNode->pElementData->pElementName, "wp:start"))
	{
		BPoint nPolygon(0,0);
		for (BrINT32 i = 0; pNode->pElementData->pAttributePairs[i]; i += 2)
		{
			if( 0 == strcmp(pNode->pElementData->pAttributePairs[i], "x"))
			{
				nPolygon.setX(BrAtoi(pNode->pElementData->pAttributePairs[i+1]));
			}
			else if (0 == strcmp(pNode->pElementData->pAttributePairs[i], "y"))
			{
				nPolygon.setY(BrAtoi(pNode->pElementData->pAttributePairs[i+1]));
			}
		}
		m_PolygonData.Add(nPolygon);
	}
	else if( 0 == strcmp(pNode->pElementData->pElementName, "wp:lineTo"))
	{
		BPoint nPolygon(0,0);
		for (BrINT32 i = 0; pNode->pElementData->pAttributePairs[i]; i += 2)
		{
			if( 0 == strcmp(pNode->pElementData->pAttributePairs[i], "x"))
			{
				nPolygon.setX(BrAtoi(pNode->pElementData->pAttributePairs[i+1]));
			}
			else if (0 == strcmp(pNode->pElementData->pAttributePairs[i], "y"))
			{
				nPolygon.setY(BrAtoi(pNode->pElementData->pAttributePairs[i+1]));
			}
		}
		m_PolygonData.Add(nPolygon);
	}
	else if( 0 == strcmp(pNode->pElementData->pElementName, X_DOC_DRAW_DRAWING_WRAPTOPANDBOTTOM))
	{//depth+2
		m_nWrappingMode = 1;
	}
	else if( 0 == strcmp(pNode->pElementData->pElementName, X_DOC_DRAW_DRAWING_EXTENT))
	{//depth+2
		validation.DataBits.flags.WP_extent = 1;
		if( pNode->pElementData->pAttributePairs )
		{
			for (BrINT32 i = 0; pNode->pElementData->pAttributePairs[i]; i += 2)
			{
				//BrTrace("%s:%s", pNode->pElementData->pAttributePairs[i], pNode->pElementData->pAttributePairs[i+1]);
				if( 0 == strcmp(pNode->pElementData->pAttributePairs[i], "cx"))
				{
					int cx = CDocxUtil::MSEMUtoTWIP(BrAtoi(pNode->pElementData->pAttributePairs[i + 1]));
					if(cx < 0)
						return SetErrorFReturn(CFilterError(kPoErrCorruptFile));
					m_extent.cx = cx;
				}
				else if( 0 == strcmp(pNode->pElementData->pAttributePairs[i], "cy"))
				{
					int cy = CDocxUtil::MSEMUtoTWIP(BrAtoi(pNode->pElementData->pAttributePairs[i + 1]));
					if(cy < 0)
						return SetErrorFReturn(CFilterError(kPoErrCorruptFile));
					m_extent.cy = cy;
				}
			}
		}
	}
	else if (0 == strcmp(pNode->pElementData->pElementName, X_DOC_DRAW_DRAWING_SIMPLEPOS))
	{//depth+2
		if (pNode->pElementData->pAttributePairs)
		{
			for (BrINT32 i = 0; pNode->pElementData->pAttributePairs[i]; i += 2)
			{
				//BrTrace("%s:%s", pNode->pElementData->pAttributePairs[i], pNode->pElementData->pAttributePairs[i+1]);
				if (0 == strcmp(pNode->pElementData->pAttributePairs[i], "cx"))
				{
					int cx = CDocxUtil::MSEMUtoTWIP(BrAtoi(pNode->pElementData->pAttributePairs[i + 1]));
					if (cx < 0)
						return SetErrorFReturn(CFilterError(kPoErrCorruptFile));
					m_simplePos.cx = cx;
				}
				else if (0 == strcmp(pNode->pElementData->pAttributePairs[i], "cy"))
				{
					int cy = CDocxUtil::MSEMUtoTWIP(BrAtoi(pNode->pElementData->pAttributePairs[i + 1]));
					if (cy < 0)
					return SetErrorFReturn(CFilterError(kPoErrCorruptFile));
					m_simplePos.cy = cy;
				}
			}
		}
	}
	else if( 0 == strcmp(pNode->pElementData->pElementName, X_DOC_DRAW_DRAWING_EFFECTEXTENT))
	{//depth+2
		if( pNode->pElementData->pAttributePairs )
		{
			for (BrINT32 i = 0; pNode->pElementData->pAttributePairs[i]; i += 2)
			{
				//BrTrace("%s:%s", pNode->pElementData->pAttributePairs[i], pNode->pElementData->pAttributePairs[i+1]);
				if( 0 == strcmp(pNode->pElementData->pAttributePairs[i], "l"))
				{
					m_rEffectExtent.nLeft = CDocxUtil::MSEMUtoTWIP(BrAtoi(pNode->pElementData->pAttributePairs[i+1]));
				}
				else if( 0 == strcmp(pNode->pElementData->pAttributePairs[i], "t"))
				{
					m_rEffectExtent.nTop = CDocxUtil::MSEMUtoTWIP(BrAtoi(pNode->pElementData->pAttributePairs[i+1]));
				}
				else if( 0 == strcmp(pNode->pElementData->pAttributePairs[i], "r"))
				{
					m_rEffectExtent.nRight = CDocxUtil::MSEMUtoTWIP(BrAtoi(pNode->pElementData->pAttributePairs[i+1]));
				}
				else if( 0 == strcmp(pNode->pElementData->pAttributePairs[i], "b"))
				{
					m_rEffectExtent.nBottom = CDocxUtil::MSEMUtoTWIP(BrAtoi(pNode->pElementData->pAttributePairs[i+1]));
				}
			}
		}
	}
	else if( 0 == strcmp(pNode->pElementData->pElementName, X_DOC_DRAW_DRAWING_DOCPR))
	{//depth+2 hnsong:2012-08-24 PenMode�� ������ Descriptioin�� ����(2013-01-03, VMLȣȯ)�� ����.. �о Ȯ������!!
BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
		if( !pNode->pElementData->pAttributePairs )
			return BrTRUE;
		validation.DataBits.flags.WP_docPr = 1;

		for (BrINT32 i = 0; pNode->pElementData->pAttributePairs[i]; i += 2)
		{
			BTrace("%s:%s", pNode->pElementData->pAttributePairs[i], pNode->pElementData->pAttributePairs[i+1]);
			const BrCHAR* pAttrName = pNode->pElementData->pAttributePairs[i];
			if( 0 == strcmp(pAttrName, "descr")) 
			{			
				BrINT32 nLen = BrStrLen(pNode->pElementData->pAttributePairs[i+1]);
				m_pDescr = (BrCHAR*)BrMalloc(nLen+1);
				memcpy(m_pDescr, pNode->pElementData->pAttributePairs[i+1], nLen);
				m_pDescr[nLen] = 0;
			
				const BrCHAR* pAttrCont = pNode->pElementData->pAttributePairs[i+1];
				BrCHAR seps[] = " ";
				//2012-11-12 m-17560 toypilot docpr name ���� ��� �״� ���� ����
				nLen = BrStrLen(pAttrCont);
				if(0 >= nLen)
					break;
				char* pContext = BrNULL;
				BrCHAR *pCont = strtok_s((BrCHAR*)pAttrCont, seps, &pContext);
				if( !pCont) //[M-24358] hnsong:2013-02-27
					break;

				if( 0 == strcmp(pCont, "PenDraw"))
				{
					m_pPenShapeName = BrNEW BString(pAttrCont);
					m_nPenID = BrAtoi(pAttrCont+8);
					break;
				}
			}
			else if( 0 == strcmp(pNode->pElementData->pAttributePairs[i], "title"))
			{
				BrINT32 nLen = BrStrLen(pNode->pElementData->pAttributePairs[i+1]);
				m_pTitle = (BrCHAR*)BrMalloc(nLen+1);
				memcpy(m_pTitle, pNode->pElementData->pAttributePairs[i+1], nLen);
				m_pTitle[nLen] = 0;	
			}
			else if( 0 == strcmp(pNode->pElementData->pAttributePairs[i], "hidden"))
				BrXMLDTDUtil::setVMLBoolData((BrCHAR*)pNode->pElementData->pAttributePairs[i+1], BrStrLen(pNode->pElementData->pAttributePairs[i+1]), m_bHidden);
			else if( 0 == strcmp(pNode->pElementData->pAttributePairs[i], "id"))
				m_nObjectID = BrAtoi(pNode->pElementData->pAttributePairs[i+1]);
			else if( 0 == strcmp(pNode->pElementData->pAttributePairs[i], "name"))
 			{
  				BrINT32 nLen = BrStrLen(pNode->pElementData->pAttributePairs[i+1]);
 				m_pObjectName = (BrCHAR*)BrMalloc(nLen+1);
 				memcpy(m_pObjectName, pNode->pElementData->pAttributePairs[i+1], nLen);
 				m_pObjectName[nLen] = 0;			
 			}
		}
	}
	else if( 0 == strcmp(pNode->pElementData->pElementName, X_DOC_DRAW_DRAWING_GRAPICDATA))
	{//depth+3
	}
	else if( 0 == strcmp(pNode->pElementData->pElementName, E_AM3D_MODEL3D))
	{
		m_p3DShape = BrNEW BCOfficeXGraphicModel3D(m_pDocxConv->m_pPackage);
		m_p3DShape->m_strSrcPartName = pNode->pCurPackagePartName;

		for (BrINT32 i = 0; pNode->pElementData->pAttributePairs[i]; i += 2)
		{
			if( strcmp("r:embed", pNode->pElementData->pAttributePairs[i])==0 )
				m_p3DShape->m_str3DGLBRelID = pNode->pElementData->pAttributePairs[i+1];
		}

		domDocument* pDOMDocument = BrNEW domDocument();
		pDOMDocument->SetDocType(EBDT_XML);
		m_p3DShape->m_pModel3DDom = BrNEW DOMBuilderOnSAX(pDOMDocument, pNode);

		pNode->callbackParam.wParam = 0;
		pNode->callbackParam.pCurrentInstance = m_p3DShape->m_pModel3DDom;
		pNode->nElementOption |= BR_XML_NEED_END_ELEMENT;
	}
	else if( 0 == strcmp(pNode->pElementData->pElementName, X_DOC_DRAW_DRAWING_WPG_WGP))
	{
		m_pShapeGroup = BrNEW BCOfficeXShapeGroup(m_pDocxConv->m_pPackage, m_pDocxConv);

		pNode->callbackParam.wParam = 0;
		pNode->callbackParam.pCurrentInstance = m_pShapeGroup;
		pNode->nElementOption |= BR_XML_NEED_END_ELEMENT;
	}
	//[2013.04.18][������][TID:14747] DML �׸��� ĵ���� -> Group Shape���� �����Ͽ� ����
	else if( 0 == strcmp(pNode->pElementData->pElementName, X_DOC_DRAW_DRAWING_WPC_WPC))
	{
		m_pShapeGroup = BrNEW BCOfficeXShapeGroup(m_pDocxConv->m_pPackage, m_pDocxConv);

		m_pShapeGroup->m_bDMLCanvas = BrTRUE;

		pNode->callbackParam.wParam = 0;
		pNode->callbackParam.pCurrentInstance = m_pShapeGroup;
		pNode->nElementOption |= BR_XML_NEED_END_ELEMENT;
	}
	else if( 0 == strcmp(pNode->pElementData->pElementName, X_DOC_DRAW_DRAWING_WPS_WSP))
	{//depth+4
		m_pShape = BrNEW BCOfficeXShapeNormal(m_pDocxConv->m_pPackage, m_pDocxConv);

		if(pNode->pElementData->pAttributePairs )
		{
			for (BrINT32 i = 0; pNode->pElementData->pAttributePairs[i]; i += 2)
			{
				const BrCHAR* pAttrName = pNode->pElementData->pAttributePairs[i];
				if( 0 == strcmp(pAttrName, "normalEastAsianFlow")) 
					BrXMLDTDUtil::setVMLBoolData((BrCHAR*)pNode->pElementData->pAttributePairs[i+1], BrStrLen(pNode->pElementData->pAttributePairs[i+1]), m_pShape->m_bNormalEastAsianFlow);
			}
		}

		pNode->callbackParam.wParam = 0;
		pNode->callbackParam.pCurrentInstance = m_pShape;
		pNode->nElementOption |= BR_XML_NEED_END_ELEMENT;
	}
	else if( 0 == strcmp(pNode->pElementData->pElementName, X_DOC_DRAW_DRAWING_PIC))	//<pic:pic>
	{//depth+4
		m_pShapePic = BrNEW BCOfficeXShapePic(m_pDocxConv->m_pPackage);

		pNode->callbackParam.wParam = 0;
		pNode->callbackParam.pCurrentInstance = m_pShapePic;
		pNode->nElementOption |= BR_XML_NEED_END_ELEMENT;
	}
	else if( 0 == strcmp(pNode->pElementData->pElementName, X_DOC_DRAW_DRAWING_LOCKEDCANVAS))
	{//depth+4
		m_pShapeGroup = BrNEW BCOfficeXShapeGroup(m_pDocxConv->m_pPackage);

		m_pShapeGroup->m_bLockedCanvas = BrTRUE;

		pNode->callbackParam.wParam = 0;
		pNode->callbackParam.pCurrentInstance = m_pShapeGroup;
		pNode->nElementOption |= BR_XML_NEED_END_ELEMENT;
	}
	else if( 0 == strcmp(pNode->pElementData->pElementName, "w14:contentPart"))
	{
#ifdef SUPPORT_INKML
		m_pShape = BrNEW BCOfficeXContentPart();
		((BCOfficeXContentPart*)m_pShape)->ReadContentPart(pNode);
#endif	//SUPPORT_INKML
	}
	else if( strcmp(pNode->pElementData->pElementName, "c:chart") ==0 )
	{
		const BrCHAR* pIdName;
		m_pGraphicData = BrNEW BCOfficeXGraphicChart(m_pDocxConv->m_pPackage);
		for (BrINT32 i = 0; pNode->pElementData->pAttributePairs[i]; i += 2)
		{
			pIdName = trimNamespace(pNode->pElementData->pAttributePairs[i]);
			if( strcmp("id", pIdName) == 0 )
				((BCOfficeXGraphicChart*)m_pGraphicData)->m_strChartID = pNode->pElementData->pAttributePairs[i+1];
		}
		((BCOfficeXGraphicChart*)m_pGraphicData)->m_strSrcPartName = pNode->pCurPackagePartName;
		pNode->callbackParam.pCurrentInstance = m_pGraphicData;
		pNode->callbackParam.wParam = 0;
	}
	else if( strcmp(pNode->pElementData->pElementName, "cx:chart") ==0 )
	{
		const BrCHAR* pIdName;
		m_pGraphicData = BrNEW BCOfficeXGraphicChartEx(m_pDocxConv->m_pPackage);
		for (BrINT32 i = 0; pNode->pElementData->pAttributePairs[i]; i += 2)
		{
			pIdName = trimNamespace(pNode->pElementData->pAttributePairs[i]);
			if( strcmp("id", pIdName) == 0 )
				((BCOfficeXGraphicChartEx*)m_pGraphicData)->m_strChartID = pNode->pElementData->pAttributePairs[i+1];
		}
		((BCOfficeXGraphicChartEx*)m_pGraphicData)->m_strSrcPartName = pNode->pCurPackagePartName;
		pNode->callbackParam.pCurrentInstance = m_pGraphicData;
		pNode->callbackParam.wParam = 0;
	}
#ifdef IMPORT_DIAGRAMX	//MistY - 2009.04.25
	else if( 0 == strcmp(pNode->pElementData->pElementName, "dgm:relIds"))
	{
		BCOfficeXShapeGraphicFrame *pGraphicFrame =  BrNEW BCOfficeXShapeGraphicFrame (m_pDocxConv->m_pPackage);
		pGraphicFrame->m_pNVGraphicProperty = BrNEW BCOfficeXNonVisualGraphicFrameProperties(m_pDocxConv->m_pPackage);
		pGraphicFrame->m_offset.x = (BrINT32)((m_nPosOffsetH-0.5)*(BrFLOAT)254*3600/(double)1440);
		pGraphicFrame->m_offset.y = (BrINT32)((m_nPosOffsetV-0.5)*(BrFLOAT)254*3600/(double)1440);

		pGraphicFrame->m_extent.cx = (BrLONG)((m_extent.cx-0.5)*(BrFLOAT)254*3600/(double)1440);
		pGraphicFrame->m_extent.cy = (BrLONG)((m_extent.cy-0.5)*(BrFLOAT)254*3600/(double)1440);
//[2011.09.28][�̻�][TID:375] �ܵ� Smart Art �۾� Merge
#ifdef DANDONG_SMARTART
		// [2011.8.17][dandong1]
		if(m_pDocxConv->getDocxLoader()->m_pTheme != BrNULL) {//[2011.12.12][������][TID:1275] �ܵ� SmartArt Export Merge
			pGraphicFrame->m_pUsedScheme = m_pDocxConv->getDocxLoader()->m_pTheme->GetSchemeColor();
			// [DanDong2] [2014.09.24] docx����ó������ theme.xml�� �ð�� ��ü�� ã�� ���ϴ� ���� ����.
			// theme.xml���� ���� ��ü������ �����ϱ� ���� pGraphicFrame->m_SchemeFonts�� theme.xml�κ��� 
			// ���� ��ü������ �����Ѵ�.
			pGraphicFrame->m_SchemeFonts = m_pDocxConv->getDocxLoader()->m_pTheme->m_SchemeFonts;
		}
#endif
		m_pGraphicDataDgm = BrNEW BCOfficeXGraphicDiagram((BCOfficeXShapeGraphicFrame*)pGraphicFrame, m_pDocxConv->m_pPackage);
		for (BrINT32 i = 0; pNode->pElementData->pAttributePairs[i]; i += 2)
		{
			if( strcmp("r:dm", pNode->pElementData->pAttributePairs[i])==0 )
				((BCOfficeXGraphicDiagram*)m_pGraphicDataDgm)->m_strDMID = pNode->pElementData->pAttributePairs[i+1];
			else if(strcmp("r:lo", pNode->pElementData->pAttributePairs[i])==0)
				((BCOfficeXGraphicDiagram*)m_pGraphicDataDgm)->m_strLOID = pNode->pElementData->pAttributePairs[i+1];
			else if(strcmp("r:qs", pNode->pElementData->pAttributePairs[i])==0)
				((BCOfficeXGraphicDiagram*)m_pGraphicDataDgm)->m_strQSID = pNode->pElementData->pAttributePairs[i+1];
			else if(strcmp("r:cs", pNode->pElementData->pAttributePairs[i])==0)
				((BCOfficeXGraphicDiagram*)m_pGraphicDataDgm)->m_strCSID = pNode->pElementData->pAttributePairs[i+1];				
		}

		if(!((BCOfficeXGraphicDiagram*)m_pGraphicDataDgm)->ReadData((BrCHAR*)pNode->pCurPackagePartName))
		{
			BrDELETE m_pGraphicDataDgm;
			m_pGraphicDataDgm = BrNULL;
		}
		pNode->callbackParam.pCurrentInstance = m_pGraphicDataDgm;
		pNode->callbackParam.wParam = 0;
	}
#endif //IMPORT_DIAGRAMX
	else if(0 == strcmp(pNode->pElementData->pElementName, "a:hlinkClick" ) ) 
	{
		if( pNode->pElementData->pAttributePairs )
		{
			DocxRelationField* pDocxRelationField = BrNEW DocxRelationField(m_pDocxConv->m_pPackage, (char*)(BR_XML_Parser_Callback_Info*)pNode->pCurPackagePartName, eFieldCode_DRAWINGHYPERLINK, m_pDocxConv->getDocxLoader());
			for( BrINT32 i = 0; pNode->pElementData->pAttributePairs[i]; i += 2)
			{
				if( 0 == strcmp(pNode->pElementData->pAttributePairs[i], X_RID) )
				{					
					BrINT32 nLen = BrStrLen(pNode->pElementData->pAttributePairs[i+1]);
					BrCHAR *pBuf = (BrCHAR*)BrMalloc(nLen+1);
					memcpy(pBuf, pNode->pElementData->pAttributePairs[i+1], nLen);
					pBuf[nLen] = 0;

					pDocxRelationField->SetRelID(pBuf);
					pDocxRelationField->CreateStartLink(m_pDocxConv->getCurLineList(), 0, m_pDocxConv->m_nCaptionIDForEndLink);
					DocxFieldManager * pDocxFieldManager = m_pDocxConv->getDocxLoader()->getDocxFieldManager();
					pDocxFieldManager->push(pDocxRelationField);

					BR_SAFE_FREE(pBuf);
					break;
				}
			}
		}
		pNode->nElementOption |= BR_XML_NEED_END_ELEMENT;
	}
	else if(strcmp(pNode->pElementData->pElementName, "a:graphicFrameLocks")==0)
	{
		m_pGraphicFrameLocks = BrNEW BCOfficeXGraphicFrameLocks(m_pDocxConv->m_pPackage);
		if( pNode->pElementData->pAttributePairs )
		{
			for( BrINT32 i = 0; pNode->pElementData->pAttributePairs[i]; i += 2)
			{
				if( 0 == strcmp(pNode->pElementData->pAttributePairs[i], "noChangeAspect") )
				{
					OOXMLSTHandler::SetSTOnOff(pNode->pElementData->pAttributePairs[i+1], m_pGraphicFrameLocks->m_bNoChangeAspect);
				}
			}
		}
	}
	return BrTRUE;
}

BrSize	CDocxDrawingML::ConvertRelativeToAbsoluteSize(CPage* a_pCurPage)
{
	FrameConvertHandler FrameConverter;

	return FrameConverter.ConvertRelativeToAbsoluteSize(a_pCurPage,m_nSizeHRel,m_nPctWidth, m_nSizeVRel,m_nPctHeight);
}

BrBOOL	CDocxDrawingML::ConvertRelativeToAbsolutePosition(CFrame* a_pFrame, CPage* a_pCurPage)
{
	FrameConvertHandler FrameConverter;

	return FrameConverter.ConvertRelativeToAbsolutePosition(a_pFrame, m_nPosHRel, m_nPosHAlign, m_nPosVRel, m_nPosVAlign, m_nPosOffsetH, m_nPosOffsetV, m_pDocxConv->m_pCurSectionInformation);
}

BrBOOL	CDocxDrawingML::ConvertFramePosition(CFrame* a_pFrame)
{
	FrameConvertHandler FrameConverter;

	BrFLOAT nValueH, nValueV = 0;

	switch(m_nLocationTypeH)
	{
	case LT_ABSOLUTE:
		nValueH = TWIPtoMM_DOUBLE(m_nPosOffsetH);
		break;
	case LT_ALIGNMENT:
	case LT_BOOKLAYOUT:
		nValueH = m_nPosHAlign;
		break;
	case LT_RELATIVE:
		nValueH = m_fPosHPercent;
		break;
	}

	switch(m_nLocationTypeV)
	{
	case LT_ABSOLUTE:
		nValueV = TWIPtoMM_DOUBLE(m_nPosOffsetV);
		break;
	case LT_ALIGNMENT:
		nValueV = m_nPosVAlign;
		break;
	case LT_RELATIVE:
		nValueV = m_fPosVPercent;
		break;
	}

	return FrameConverter.ConvertFramePosition(a_pFrame, m_nLocationTypeH, m_nLocationTypeV, m_nPosHRel, m_nPosVRel, nValueH, nValueV);
}

CShape3DInfo* read3DDrawInfo(XMLDataDecodeParam*  pInfo)
{
	CMsod_3DObject *pMsod3DObject = BrNEW CMsod_3DObject;
	CMsod_3DStyle *pMsod3DStyle = BrNULL;
	for (BrINT32 i = 0; pInfo->pElementData->pAttributePairs[i]; i += 2)
	{
		if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], "on") && 
			0 == strcmp(pInfo->pElementData->pAttributePairs[i+1], "t")) {
			pMsod3DObject->m_fc3DLightFace = 0x80008;
		}
		else if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], "color")) {
			pMsod3DObject->m_c3DExtrusionColor = CDocxUtil::getColor2((BrCHAR*)pInfo->pElementData->pAttributePairs[i+1]);
		}
		else if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], "specularity")) {
			pMsod3DObject->m_c3DSpecularAmt = BrAtoi(pInfo->pElementData->pAttributePairs[i+1]) >> 16;
		}
		else if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], "diffusity")) {
			pMsod3DObject->m_c3DDiffuseAmt = BrAtoi(pInfo->pElementData->pAttributePairs[i+1]) >> 16;
		}
		else if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], "metal") && 
			0 == strcmp(pInfo->pElementData->pAttributePairs[i+1], "t")) {
			pMsod3DObject->m_fc3DMetallic = BrTRUE;
		}
		else if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], "backdepth")) {
			BrINT32 nValue;
			BrCHAR pLast[10];
			memset(pLast, 0, 10);
			strncpy_s(pLast, 10, (BrCHAR*)(pInfo->pElementData->pAttributePairs[i+1]+BrStrLen(pInfo->pElementData->pAttributePairs[i+1])-2),  2);
			if( 0 == strcmp(pLast, "in") ) {
				nValue = BrAtoi(pInfo->pElementData->pAttributePairs[i+1]);
				pMsod3DObject->m_c3DExtrudeBackward = C3D_DEF_EXTRUSION * 2 * nValue;
			}
			else if( 0 == strcmp(pLast, "pt") ) {
				nValue = BrAtoi(pInfo->pElementData->pAttributePairs[i+1]);
				pMsod3DObject->m_c3DExtrudeBackward = BrMulDiv( nValue, 914400, 72 );
			}
			else
				pMsod3DObject->m_c3DExtrudeBackward = BrAtoi(pInfo->pElementData->pAttributePairs[i+1]);
		}
		else if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], "brightness")) {
			if( !pMsod3DStyle )
				pMsod3DStyle = BrNEW CMsod_3DStyle;
			pMsod3DStyle->m_c3DAmbientIntensity  = BrAtoi(pInfo->pElementData->pAttributePairs[i+1])/65536.0;
		}
		else if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], "lightlevel")) {
			if( !pMsod3DStyle )
				pMsod3DStyle = BrNEW CMsod_3DStyle;
			pMsod3DStyle->m_c3DKeyIntensity = BrAtoi(pInfo->pElementData->pAttributePairs[i+1]);
		}
		else if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], "lightlevel2")) {
			if( !pMsod3DStyle )
				pMsod3DStyle = BrNEW CMsod_3DStyle;
			pMsod3DStyle->m_c3DFillIntensity = BrAtoi(pInfo->pElementData->pAttributePairs[i+1]);
		}
		else if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], "lightposition2")) {
			if( !pMsod3DStyle )
				pMsod3DStyle = BrNEW CMsod_3DStyle;

			BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
			BrCHAR *pBuf = (BrCHAR*)BrMalloc(nLen+1);
			memcpy(pBuf, pInfo->pElementData->pAttributePairs[i+1], nLen);
			pBuf[nLen] = 0;
			BrCHAR *pTmp = pBuf;

			BrCHAR seps[]   = ",";
			char* pContext = BrNULL;
			BrCHAR *ch = strtok_s(pTmp, seps, &pContext);
			if( ch )
			{
				if(pBuf[0] == ',')
				{
					pMsod3DStyle->m_c3DFillY = BrAtoi(ch);
				}
				else
				{
					pMsod3DStyle->m_c3DFillX = BrAtoi(ch);
					ch = strtok_s(NULL, seps, &pContext);
					if(ch)
						pMsod3DStyle->m_c3DFillY = BrAtoi(ch);
				}
			}
			BrFree(pBuf);
		}
		else if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], "lightposition")) {
			if( !pMsod3DStyle )
				pMsod3DStyle = BrNEW CMsod_3DStyle;

			BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
			BrCHAR *pBuf = (BrCHAR*)BrMalloc(nLen+1);
			memcpy(pBuf, pInfo->pElementData->pAttributePairs[i+1], nLen);
			pBuf[nLen] = 0;
			BrCHAR *pTmp = pBuf;

			BrCHAR seps[]   = ",";
			char* pContext = BrNULL;
			BrCHAR *ch = strtok_s(pTmp, seps, &pContext);
			if( ch )
			{
				if(pBuf[0] == ',')
				{
					pMsod3DStyle->m_c3DKeyY = BrAtoi(ch);
				}
				else
				{
					pMsod3DStyle->m_c3DKeyX = BrAtoi(ch);
					ch = strtok_s(NULL, seps, &pContext);
					if(ch)
						pMsod3DStyle->m_c3DKeyY = BrAtoi(ch);
				}
			}
			BrFree(pBuf);
		}
		else if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], "skewangle")) {
			if( !pMsod3DStyle )
				pMsod3DStyle = BrNEW CMsod_3DStyle;
			pMsod3DStyle->m_c3DSkewAngle = BrAtoi(pInfo->pElementData->pAttributePairs[i+1]);
		}
		else if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], "skewamt")) {
			if( !pMsod3DStyle )
				pMsod3DStyle = BrNEW CMsod_3DStyle;
			pMsod3DStyle->m_c3DSkewAmount = BrAtoi(pInfo->pElementData->pAttributePairs[i+1]);
		}
		else if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], "render")) {
			if( !pMsod3DStyle )
				pMsod3DStyle = BrNEW CMsod_3DStyle;

			if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i+1], "fullRender") )
				pMsod3DStyle->m_c3DRenderMode = msoFullRender;
			else if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i+1], "wireFrame") )
				pMsod3DStyle->m_c3DRenderMode = msoWireframe;
			else if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i+1], "boundingCube") )
				pMsod3DStyle->m_c3DRenderMode = msoBoundingCube;
		}
		else if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], "type")) {
			if( !pMsod3DStyle )
				pMsod3DStyle = BrNEW CMsod_3DStyle;

			if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i+1], "perspective") )
			{
				pMsod3DStyle->m_fc3DParallel = BrFALSE;
				pMsod3DStyle->m_c3DFov = 65;
				pMsod3DStyle->m_fc3DFillHarsh = 0x40000;		//word ���ð� ����
			}

		}
		else if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], "rotationangle")) {
			if( !pMsod3DStyle )
				pMsod3DStyle = BrNEW CMsod_3DStyle;

			BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
			BrCHAR *pBuf = (BrCHAR*)BrMalloc(nLen+1);
			memcpy(pBuf, pInfo->pElementData->pAttributePairs[i+1], nLen);
			pBuf[nLen] = 0;
			BrCHAR *pTmp = pBuf;

			BrCHAR seps[]   = ",";
			char* pContext = BrNULL;
			BrCHAR *ch = strtok_s(pTmp, seps, &pContext);
			if( ch )
			{
				if(pBuf[0] == ',')
				{//�ʱⰪ�� init�� ����
					pMsod3DStyle->m_c3DYRotationAngle = BrAtoi(ch);
				}
				else
				{
					pMsod3DStyle->m_c3DXRotationAngle = BrAtoi(ch);
					ch = strtok_s(NULL, seps, &pContext);
					if(ch)
						pMsod3DStyle->m_c3DYRotationAngle = BrAtoi(ch);
				}
			}
			BrFree(pBuf);
		}
		else if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], "viewpointorigin")) {
			if( !pMsod3DStyle )
				pMsod3DStyle = BrNEW CMsod_3DStyle;

			BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
			BrCHAR *pBuf = (BrCHAR*)BrMalloc(nLen+1);
			memcpy(pBuf, pInfo->pElementData->pAttributePairs[i+1], nLen);
			pBuf[nLen] = 0;
			BrCHAR *pTmp = pBuf;

			BrCHAR seps[]   = ",";
			char* pContext = BrNULL;
			BrCHAR *ch = strtok_s(pTmp, seps, &pContext);
			BrDOUBLE nValue;
			if( ch )
			{
				if(pBuf[0] == ',')
				{//�ʱⰪ�� init�� ����
					pMsod3DStyle->m_c3DOriginY = BrAtof(ch) * 65536.0;
				}
				else
				{
					nValue = 65536.0 * BrAtof(ch);
					pMsod3DStyle->m_c3DOriginX = nValue;
					ch = strtok_s(NULL, seps, &pContext);
					if(ch) {
						nValue = 65536.0 * BrAtof(ch);
						pMsod3DStyle->m_c3DOriginY = nValue;
					}
				}
			}
			BrFree(pBuf);
		}
		else if( 0 == strcmp(pInfo->pElementData->pAttributePairs[i], "viewpoint")) {
			if( !pMsod3DStyle )
				pMsod3DStyle = BrNEW CMsod_3DStyle;

			BrINT32 nLen = BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
			BrCHAR *pBuf = (BrCHAR*)BrMalloc(nLen+1);
			memcpy(pBuf, pInfo->pElementData->pAttributePairs[i+1], nLen);
			pBuf[nLen] = 0;
			BrCHAR *pTmp = pBuf;

			BrCHAR seps[]   = ",";
			char* pContext = BrNULL;
			BrCHAR *ch = strtok_s(pTmp, seps, &pContext);
			if( ch )
			{
				if(pBuf[0] == ',')
				{//�ʱⰪ�� init�� ����
					pMsod3DStyle->m_c3DYViewpoint = (BrLONG)MMtoEMU_DOUBLE(BrAtof(ch)) * 10;
				}
				else
				{
					pMsod3DStyle->m_c3DXViewpoint = (BrLONG)MMtoEMU_DOUBLE(BrAtof(ch)) * 10;
					ch = strtok_s(NULL, seps, &pContext);
					if(ch)
						pMsod3DStyle->m_c3DYViewpoint = (BrLONG)MMtoEMU_DOUBLE(BrAtof(ch)) * 10;
				}
			}
			BrFree(pBuf);
		}
	}

	CShape3DInfo *pDocx3D = BrNEW CShape3DInfo();

	if( pMsod3DObject ) {
		pDocx3D->m_pMsod3DObject = pMsod3DObject;
		pMsod3DObject = BrNULL;
	}
	if( pMsod3DStyle ) {
		pDocx3D->m_pMsod3DStyle = pMsod3DStyle;
		pMsod3DStyle = BrNULL;
	}
	return pDocx3D;
}


#endif//#ifdef IMPORT_DOCX
