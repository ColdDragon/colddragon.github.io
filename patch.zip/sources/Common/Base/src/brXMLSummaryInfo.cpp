#include <basePCH.hpp>

#include "brXMLSummaryInfo.h"
#include "ssconstants.h"
#include "brSummaryInfoData.h"
#include "package_partname.h"
#include "package_relationship.h"
#include "package_relationship_collection.h"
#include "package_uri_helper.h"
#include "brxmlnode.h"
#include "brxmlwriter.h"
#include "brxmlpackage.h"
#include "packageBase.h"
#include "bwpObjApi.h"
#include "shtObjApi.h"
#include "Error/ErrorHandle.h"
#define APP_VERSION_LEN    20

CBrXMLCoreSummaryImporter::CBrXMLCoreSummaryImporter()
{
	m_pData = BrNEW CBrXMLSummaryCoreData();

}

CBrXMLCoreSummaryImporter::~CBrXMLCoreSummaryImporter()
{
	if(m_pData)
		BR_SAFE_DELETE(m_pData);

}

BrBOOL	CBrXMLCoreSummaryImporter::CallbackStartElement(LPVOID pParam)
{
	XMLDataDecodeParam* pInfo = (XMLDataDecodeParam*)pParam;


	return BrTRUE;
}

BrBOOL  CBrXMLCoreSummaryImporter::ReadCoreInfo(BoraPackageBase *pPackage)
{
	CallbackParam	param;
	memset(&param, 0, BrSizeOf(CallbackParam));
	param.pCurrentInstance = this;

	BrBOOL bRet = BrFALSE;
	PackageRelationship* pRel = pPackage->getRelationships()->relationshipsByType_get(CORE_PROPERTIES_PART_TYPE);
	if (pRel)
	{
		BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
		if( pPackage->ReadPackageByPartname(pPartName->getName().data(), &param) )
			bRet = BrTRUE;
		BrDELETE pPartName;
	}
	return bRet;
}

BString*	CBrXMLCoreSummaryImporter::getString(const BrCHAR* pTextData)
{
	BrINT32 nRetSize  = 0;
	BString *pStr = BrNEW BString();
	BrINT32 nBufferSize = BrSizeOf(BrUSHORT)*(BrStrLen(pTextData) * 4 + 1);
	BrUSHORT* pOutput = (BrUSHORT*)BrMalloc(nBufferSize);
	memset(pOutput, 0, nBufferSize);
	nRetSize = BrMultiByteToWideChar( CP_UTF8, (BrLPCSTR)pTextData, BrStrLen(pTextData), (BrLPWSTR)pOutput, BrStrLen(pTextData));
	for (BrINT i = 0; i < nRetSize; i++)
		pStr->append(BChar(pOutput[i]));
	BrFree(pOutput);
	return pStr;

}

BrBOOL	CBrXMLCoreSummaryImporter::CallbackEndElement(LPVOID pParam)
{
	XMLDataDecodeParam* pInfo = (XMLDataDecodeParam*)pParam;
	const BrCHAR* pElementName = trimNamespace(pInfo->pElementData->pElementName);
	BString* tmpStr = getString(pInfo->pElementData->pTextData);
	


	switch(pElementName[0])
	{
	case 'c':
		switch(pElementName[1])
		{
		case 'a'://category
			if(0 == memcmp(&pElementName[2],"tegory",6))
				m_pData->SetCategory( tmpStr);
			break;
		case 'o':
			if(0 == memcmp(&pElementName[7],"Status",6))//contentStatus
			{	
				m_pData->SetContentStatus(tmpStr);
				break;
			}
			else if(0 == memcmp(&pElementName[7],"Type",4))//contentType
			{
				m_pData->SetContentType( tmpStr);
				break;
			}
			break;
		case 'r':
			if(0 == memcmp(&pElementName[2],"eated",5))//created
			{
				m_pData->SetCreatedTime( tmpStr);
				break;
			}
			else if(0 == memcmp(&pElementName[2],"eator",5))//creator
			{
				m_pData->SetCreator( tmpStr);
				break;
			}
			break;
		}
		break;
	case 'd':
		if(0 == memcmp(&pElementName[1],"escription",10))//description
			m_pData->SetDescription(tmpStr);	
		break;
	case 'i':
		if(0 == memcmp(&pElementName[1],"dentifier",9))//identifier
			m_pData->SetIdentifier( tmpStr);
		break;
	case 'k':
		if(0 == memcmp(&pElementName[1],"eyword",6))//keyword
			m_pData->SetKeyword( tmpStr);
		break;
	case 'l':
		if(0 == memcmp(&pElementName[1],"anguage",6))//language
		{
			m_pData->SetLanguage( tmpStr);
			break;
		}
		else if(0 == memcmp(&pElementName[1],"astModifiedBy",13))//lastModifiedBy
		{
			m_pData->SetLastModifiedBy(tmpStr);
			break;
		}
		else if(0 == memcmp(&pElementName[1],"astPrinted",10))//lastPrinted
		{
			m_pData->SetLastPrintedTime( tmpStr);
			break;
		}
		break;
	case 'm':
		if(0 == memcmp(&pElementName[1],"odified",7))//modified
			m_pData->SetLastModifiedTime( tmpStr);			
		break;
	case 'r':
		if(0 == memcmp(&pElementName[1],"evision",7))//revision
			m_pData->SetRevisionNum(strtol(tmpStr->data(), BrNULL, 10));
		break;
	case 's':
		if(0 == memcmp(&pElementName[1],"ubject",6))//subject
			m_pData->SetSubject( tmpStr);
		break;
	case 't':
		if(0 == memcmp(&pElementName[1],"itle",4))//title
			m_pData->SetTitle( tmpStr);
		break;
	case 'v':
		if(0 == memcmp(&pElementName[1],"ersion",6))//version
			m_pData->SetVersion( tmpStr);
		break;
	}	

	BR_SAFE_DELETE(tmpStr);
	
	return BrTRUE;
}

CBrXMLAppImporter::CBrXMLAppImporter()
{
	m_pData = BrNEW	CBrXMLSummaryAppData();
}
CBrXMLAppImporter::~CBrXMLAppImporter()
{
	if(m_pData)
		BR_SAFE_DELETE(m_pData);
}
BrBOOL  CBrXMLAppImporter::ReadAppInfo(BoraPackageBase *pPackage)
{
	CallbackParam	param;
	memset(&param, 0, BrSizeOf(CallbackParam));
	param.pCurrentInstance = this;

	BrBOOL bRet = BrFALSE;
	if (!pPackage->getRelationships()) return bRet;
	PackageRelationship* pRel = pPackage->getRelationships()->relationshipsByType_get(EXTENDED_PROPERTIES_PART_TYPE);
	if (pRel)
	{
		BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
		if( pPackage->ReadPackageByPartname(pPartName->getName().data(), &param) )
			bRet = BrTRUE;
		BrDELETE pPartName;
	}

	CBrSummaryData* pSummaryData = CreateSummaryData();

	// [Dandong][2014-01-23] Kingsoft Office ���� ������ Sheet ������ core.xml �� �������� �����Ƿ�
	// CORE_PROPERTIES_PART �� �������� �����ϴ� ��쿡�� Import �ϵ��� ����.
	pRel = pPackage->getRelationships()->relationshipsByType_get(CORE_PROPERTIES_PART_TYPE);
	if(bRet && pRel)
	{
		CBrXMLCoreSummaryImporter *pCoreImporter = BrNEW CBrXMLCoreSummaryImporter();
		bRet = pCoreImporter->ReadCoreInfo(pPackage);
		if(bRet)
		{
			if(pSummaryData)
			{
				pSummaryData->setData(pCoreImporter->m_pData, m_pData);
				BR_SAFE_DELETE(pCoreImporter);
			}
				
		}
	}

	//[ZPD-9651] ���� ������ ����� on off ���� ����
	pRel = pPackage->getRelationships()->relationshipsByType_get(THUMBNAIL_PART_TYPE);
	if(pRel)
	{
		if(pSummaryData)
			pSummaryData->setSavePreview(BrTRUE);
	}
	else
	{
		if(pSummaryData)
			pSummaryData->setSavePreview(BrFALSE);
	}

	return bRet;
}

BrBOOL	CBrXMLAppImporter::CallbackStartElement(LPVOID pParam)
{
	XMLDataDecodeParam* pInfo = (XMLDataDecodeParam*)pParam;

	return BrTRUE;
}

BString*	CBrXMLAppImporter::getString(const BrCHAR* pTextData)
{
	BrINT32 nRetSize  = 0;
	BString *pStr = BrNEW BString();
	BrINT32 nBufferSize = BrSizeOf(BrUSHORT)*(BrStrLen(pTextData) * 4 + 1);
	BrUSHORT* pOutput = (BrUSHORT*)BrMalloc(nBufferSize);
	memset(pOutput, 0, nBufferSize);
	nRetSize = BrMultiByteToWideChar( CP_UTF8, (BrLPCSTR)pTextData, BrStrLen(pTextData), (BrLPWSTR)pOutput, BrStrLen(pTextData));
		for (BrINT i = 0; i < nRetSize; i++)
			pStr->append(BChar(pOutput[i]));
	BrFree(pOutput);
	return pStr;

}

BrBOOL	CBrXMLAppImporter::CallbackEndElement(LPVOID pParam)
{
	XMLDataDecodeParam* pInfo = (XMLDataDecodeParam*)pParam;

	const BrCHAR* pElementName = trimNamespace(pInfo->pElementData->pElementName);

	BString* tmpStr = getString(pInfo->pElementData->pTextData);

	switch(pElementName[0])
	{
	case 'A':
		if(0 == memcmp(&pElementName[1],"pplication",10))//application
		{
			m_pData->setApplication(tmpStr);
			break;
		}
		else if(0 == memcmp(&pElementName[1],"ppVersion",9))//appVersion
		{
			m_pData->setAppVersion(BrAtof(tmpStr->data()));
			break;
		}

		break;
	case 'C':
		switch(pElementName[1])
		{
		case 'h':
			if(0 == memcmp(&pElementName[2],"aracters",8))//characters
				m_pData->setCharacters(strtol(tmpStr->data(), BrNULL, 10));
			else if(0 == memcmp(&pElementName[2],"aractersWithSpaces",18))//charactersWithSpaces
				m_pData->setCharactersWithSpaces(strtol(tmpStr->data(), BrNULL, 10));
			break;
		case 'o':
			if(0 == memcmp(&pElementName[2],"mpany",5))//company
			{	
				m_pData->setCompany(tmpStr);
				break;
			}
			break;
		}
		break;
	case 'D':
		if(0 == memcmp(&pElementName[1],"ocSecurity",10))//docSecurity
			m_pData->setDocSecurity(BrAtoi(tmpStr->data()));	
		break;
	case 'H':
		switch(pElementName[1])
		{
		case 'i':
			if(0 == memcmp(&pElementName[2],"ddenSlides",10))//hiddenSlides
				m_pData->setHiddenSlides(strtol(tmpStr->data(), BrNULL, 10));
			break;
		case 'l':
			if(0 == memcmp(&pElementName[2],"inks",4))//hLinks
				m_pData->setHLinks(strtol(tmpStr->data(), BrNULL, 10));
			break;
		case 'y':
			if(0 == memcmp(&pElementName[2],"perlinkBase",11))//HyperlinkBase
				m_pData->setHyperlinkBase(tmpStr);
			else if(0 == memcmp(&pElementName[2],"perlinksChanged",15))//HyperlinksChanged
			{
				BrBOOL tmpBool = BrTRUE;
				if(0 == strcmp(tmpStr->data(),"false"))
					tmpBool = BrFALSE;

				m_pData->setHyperlinksChanged(tmpBool);
			}
			break;
		}
		break;
	case 'L':
		if(0 == memcmp(&pElementName[1],"ines",4))//lines
			m_pData->setLines(strtol(tmpStr->data(), BrNULL, 10));
		else if( 0 == memcmp(&pElementName[1],"inksUpToDate",12))//linksUpToDate
		{
			BrBOOL tmpBool = BrTRUE;
			if(0 == strcmp(tmpStr->data(),"false"))
				tmpBool = BrFALSE;

			m_pData->setLinksUpToDate(tmpBool);
		}
		break;
	case 'M':
		if(0 == memcmp(&pElementName[1],"anager",6))//manager
			m_pData->setManager( tmpStr);
		break;
	case 'P':
		if(0 == memcmp(&pElementName[1],"ages",4))//pages
		{
			m_pData->setPages(strtol(tmpStr->data(), BrNULL, 10));
			break;
		}
		else if(0 == memcmp(&pElementName[1],"aragraphs",9))//Paragraphs
		{
			m_pData->setParas(strtol(tmpStr->data(), BrNULL, 10));
			break;
		}
		break;
	case 'S':
		if(0 == memcmp(&pElementName[1],"caleCrop",8))//scaleCrop
		{
			BrBOOL tmpBool = BrTRUE;
			if(0 == strcmp(tmpStr->data(),"false"))
				tmpBool = BrFALSE;

			m_pData->setScaleCrop(tmpBool);
			break;
		}
		else if(0 == memcmp(&pElementName[1],"haredDoc",8))//SharedDoc
		{
			BrBOOL tmpBool = BrTRUE;
			if(0 == strcmp(tmpStr->data(),"false"))
				tmpBool = BrFALSE;

			m_pData->setSharedDoc(tmpBool);
			break;
		}
		else if(0 == memcmp(&pElementName[1],"lides",5))//Slides
		{
			m_pData->setSlides(strtol(tmpStr->data(), BrNULL, 10));
			break;
		}
		break;
	case 'T':
		if(0 == memcmp(&pElementName[1],"emplate",7))//template
		{
			m_pData->setTemplate(tmpStr);
			break;
		}
		else if(0 == memcmp(&pElementName[1],"otalTime",8))//TotalTime
		{
			m_pData->setTotalTime( tmpStr);
			break;
		}
		break;
	case 'W':
		if(0 == memcmp(&pElementName[1],"ords",4))//Words
			m_pData->setWords(strtol(tmpStr->data(), BrNULL, 10));
		break;
	}

	BR_SAFE_DELETE(tmpStr);
	return BrTRUE;
}

CBrSummaryData* CBrXMLAppImporter::CreateSummaryData()
{
	CBrSummaryData* pSummaryData = BrNULL;
	if(!poBwp_hasBoraDoc())
		pSummaryData = poSheet_GetSummaryData();
	else
		pSummaryData = poBwp_GetSummaryData();
	return pSummaryData;
}

#ifdef XML_EXPORT
CBrXMLSummaryWriter::CBrXMLSummaryWriter() : m_pPackage(BrNULL), m_pXmlWriter(BrNULL)
{
}
CBrXMLSummaryWriter::~CBrXMLSummaryWriter()
{
}

BrBOOL CBrXMLSummaryWriter::createSummaryInfo(CBrXmlPackage *pPackage, CBrXmlWriter *pXmlWriter, BrBOOL a_bSaveThmx)
{
	BrBOOL bRet = BrTRUE;

	if (!pPackage || !pXmlWriter)
	{
		ERR_TRACE_EX(kPoErrInternal);
		return BrFALSE;
	}

	m_pPackage = pPackage;
	m_pXmlWriter = pXmlWriter;

	if (!poBwp_hasBoraDoc())  //sheet
	{
		CBrXMLSummaryAppData pSummaryAppData;
		bRet = pSummaryAppData.convertData(CreateSummaryData());
		CBrXMLSummaryCoreData pSummaryCoreData;
		bRet = pSummaryCoreData.convertData(CreateSummaryData());
		bRet = createDocPropsApp(&pSummaryAppData);
		bRet = createDocPropsCore(&pSummaryCoreData);
	}
	else
	{
		CBrXMLSummaryAppData pSummaryAppData;
		CBrSummaryData* pSummaryData = CreateSummaryData();

		//setting last modifid author
		if(poBwp_getDocType() == BORA_DOCTYPE_DOCX )
		{
			BString curAuthor = poBwp_GetCurAuthor();
			if(!pSummaryData->getLastAuthor())
				pSummaryData->setLastAuthor(&curAuthor);
		}

		if(poBwp_IsCreatedNewDoc())
			pSummaryData->CreateNewDocData();
		bRet = pSummaryAppData.convertData(pSummaryData);
		CBrXMLSummaryCoreData pSummaryCoreData;
		bRet = pSummaryCoreData.convertData(pSummaryData);

		if(a_bSaveThmx == BrFALSE)
		{
			bRet = createDocPropsApp(&pSummaryAppData);
			bRet = createDocPropsCore(&pSummaryCoreData);
		}
	}


	return bRet;
}


BrBOOL CBrXMLSummaryWriter::createDocPropsApp(CBrXMLSummaryAppData *pSummaryAppData)
{
	BDataStream *pAr = m_pPackage->createOnePakage(OFFICEX_PARTNAME_APP);
	
	if(!pAr) {
#ifdef BWP_EXERN_DONE
		theBWordDoc->SetErrorCode(kPoErrMemory);
#endif
		ERR_TRACE(kPoErrMemory);
		return BrFALSE;
	}

	if(!pSummaryAppData) {
#ifdef BWP_EXERN_DONE
		theBWordDoc->SetErrorCode(kPoErrMemory);
#endif
		ERR_TRACE(kPoErrMemory);
		return BrFALSE;
	}
	m_pXmlWriter->setDataStream(pAr);

	CBrXmlElement_TC *pEleRoot = m_pXmlWriter->createElement_TC(TAGNAME_PROPERTIES, BrTRUE);
	if( !m_pXmlWriter->createNameSpaceAttribute_TC(pEleRoot, "xmlns", OFFICEX_PART_APP) ) return BrFALSE;
	if( !m_pXmlWriter->createNameSpaceAttribute_TC(pEleRoot, "xmlns:vt") ) return BrFALSE;

	CBrXmlElement_TC *pObj = m_pXmlWriter->createElement_TC(pEleRoot, "Application");
	pObj->setContent(pSummaryAppData->getApplication());

	pObj = m_pXmlWriter->createElement_TC(pEleRoot, "AppVersion");
	pObj->setContent(pSummaryAppData->getAppVersion());
	pObj->addContent(".000");

	pObj = m_pXmlWriter->createElement_TC(pEleRoot, "Characters");
	pObj->setContent(pSummaryAppData->getCharacters());

	pObj = m_pXmlWriter->createElement_TC(pEleRoot, "CharactersWithSpaces");
	pObj->setContent(pSummaryAppData->getCharactersWithSpaces());

	if(pSummaryAppData->getCompany())
	{
		pObj = m_pXmlWriter->createElement_TC(pEleRoot, "Company");
		pObj->setContent(pSummaryAppData->getCompany());
	}

	pObj = m_pXmlWriter->createElement_TC(pEleRoot, "DocSecurity");
	pObj->setContent(pSummaryAppData->getDocSecurity());

	pObj = m_pXmlWriter->createElement_TC(pEleRoot, "HyperlinksChanged");
	if(pSummaryAppData->getHyperlinksChanged())
		pObj->setContent("true");
	else
		pObj->setContent("false");

	pObj = m_pXmlWriter->createElement_TC(pEleRoot, "Lines");
	pObj->setContent(pSummaryAppData->getLines());

	pObj = m_pXmlWriter->createElement_TC(pEleRoot, "LinksUpToDate");
	if(pSummaryAppData->getLinksUpToDate())
		pObj->setContent("true");
	else
		pObj->setContent("false");

	if(pSummaryAppData->getManager())
	{
		pObj = m_pXmlWriter->createElement_TC(pEleRoot, "Manager");
		pObj->setContent(pSummaryAppData->getManager());
	}

	pObj = m_pXmlWriter->createElement_TC(pEleRoot, "Pages");
	pObj->setContent(pSummaryAppData->getPages());

	pObj = m_pXmlWriter->createElement_TC(pEleRoot, "Paragraphs");
	pObj->setContent(pSummaryAppData->getParas());

	pObj = m_pXmlWriter->createElement_TC(pEleRoot, "Words");
	pObj->setContent(pSummaryAppData->getWords());


	//default Write
	pObj = m_pXmlWriter->createElement_TC(pEleRoot, "TotalTime");
	pObj->setContent(0);

	pObj = m_pXmlWriter->createElement_TC(pEleRoot, "MMClips");
	pObj->setContent(0);

	pObj = m_pXmlWriter->createElement_TC(pEleRoot, "ScaleCrop");
	pObj->setContent("false");

	pObj = m_pXmlWriter->createElement_TC(pEleRoot, "HeadingPairs");
	CBrXmlElement_TC *pVector = createVectorElement(pObj,"2","variant");
	if(!createVectorVariantElement(pVector, "vt:lpstr","Title"))		return BrFALSE;
	if(!createVectorVariantElement(pVector, "vt:i4", "1"))			return BrFALSE;

	pObj = m_pXmlWriter->createElement_TC(pEleRoot, "TitlesOfParts");
	pVector = createVectorElement(pObj, "1","lpstr");
	CBrXmlElement_TC *pVariantObj = m_pXmlWriter->createElement_TC(pVector, "vt:lpstr");
	pVariantObj->setContent("Title text");


	pObj = m_pXmlWriter->createElement_TC(pEleRoot, "SharedDoc");
	pObj->setContent("false");

	BrBOOL bRet = m_pXmlWriter->saveXmlData_TC();
	if(bRet)
	{
		bRet = m_pPackage->closePackage(bRet);
		if(!bRet)
			SetErrorFReturn(CFilterError(kPoErrFileWrite));
	}
	else
		SetErrorFReturn(CFilterError(kPoErrFileWrite));

#ifdef SPECIALBASE_STD_MEMORY_RELEASE
	m_pXmlWriter->destoryRootElement_TC();
#endif	// SPECIALBASE_STD_MEMORY_RELEASE

	return bRet;
}
BrBOOL CBrXMLSummaryWriter::createDocPropsCore(CBrXMLSummaryCoreData *pSummaryCoreData)
{
	BDataStream *pAr = m_pPackage->createOnePakage(OFFICEX_PARTNAME_CORE);

	if(!pAr) {
		poBwp_SetErrorCode(kPoErrMemory);
		ERR_TRACE(kPoErrMemory);
		return BrFALSE;
	}

	if(!pSummaryCoreData) {
		poBwp_SetErrorCode(kPoErrMemory);
		ERR_TRACE(kPoErrMemory);
	}

	m_pXmlWriter->setDataStream(pAr);

	CBrXmlElement_TC *pEleRoot = m_pXmlWriter->createElement_TC(TAGNAME_PROPERTIES_CORE, BrTRUE);
	if( !m_pXmlWriter->createNameSpaceAttribute_TC(pEleRoot, "xmlns:cp") ) return BrFALSE;
	if( !m_pXmlWriter->createNameSpaceAttribute_TC(pEleRoot, "xmlns:dc") ) return BrFALSE;
	if( !m_pXmlWriter->createNameSpaceAttribute_TC(pEleRoot, "xmlns:dcterms") ) return BrFALSE;
	if( !m_pXmlWriter->createNameSpaceAttribute_TC(pEleRoot, "xmlns:dcmitype") ) return BrFALSE;
	if( !m_pXmlWriter->createNameSpaceAttribute_TC(pEleRoot,"xmlns:xsi") ) return BrFALSE;

	CBrXmlElement_TC *pObj = m_pXmlWriter->createElement_TC(pEleRoot, "cp:revision");
	pObj->setContent(pSummaryCoreData->GetRevisionNum());

	if(pSummaryCoreData->GetCategory())
	{
		pObj = m_pXmlWriter->createElement_TC(pEleRoot, "cp:category");
		pObj->setContent(pSummaryCoreData->GetCategory());
	}

	if(pSummaryCoreData->GetContentStatus())
	{
		pObj = m_pXmlWriter->createElement_TC(pEleRoot, "cp:contentStatus");
		pObj->setContent(pSummaryCoreData->GetContentStatus());
	}

	if(pSummaryCoreData->GetCreator())
	{
		pObj = m_pXmlWriter->createElement_TC(pEleRoot, "dc:creator");
		pObj->setContent(pSummaryCoreData->GetCreator());
	}

	if(pSummaryCoreData->GetDescription())
	{
		pObj = m_pXmlWriter->createElement_TC(pEleRoot, "dc:description");
		pObj->setContent(pSummaryCoreData->GetDescription());
	}

	if(pSummaryCoreData->GetKeyword())
	{
		pObj = m_pXmlWriter->createElement_TC(pEleRoot, "cp:keywords");
		pObj->setContent(pSummaryCoreData->GetKeyword());
	}

	if(pSummaryCoreData->GetLastModifiedBy())
	{
		pObj = m_pXmlWriter->createElement_TC(pEleRoot, "cp:lastModifiedBy");
		pObj->setContent(pSummaryCoreData->GetLastModifiedBy());
	}

	if(pSummaryCoreData->GetTitle())
	{
		pObj = m_pXmlWriter->createElement_TC(pEleRoot, "dc:title");
		pObj->setContent(pSummaryCoreData->GetTitle());
	}

	if(pSummaryCoreData->GetVersion())
	{
		pObj = m_pXmlWriter->createElement_TC(pEleRoot, "cp:version");
		pObj->setContent(pSummaryCoreData->GetVersion());
	}

	if(pSummaryCoreData->GetSubject())
	{
		pObj = m_pXmlWriter->createElement_TC(pEleRoot, "dc:subject");
		pObj->setContent(pSummaryCoreData->GetSubject());
	}

	char chAppName[APP_VERSION_LEN] = { 0, };
	BOnGetAppVersion(chAppName);
	BString strVersion(chAppName);

	if (!strVersion.isEmpty())
	{
		pObj = m_pXmlWriter->createElement_TC(pEleRoot, "cp:version");
		pObj->setContent(strVersion);
	}

	if(pSummaryCoreData->GetCreatedTime())
	{
		pObj = m_pXmlWriter->createElement_TC(pEleRoot, "dcterms:created");
		pObj->addAttributeNode("xsi:type", "dcterms:W3CDTF");
		pObj->setContent(pSummaryCoreData->GetCreatedTime());//����ð�
	}

	if(pSummaryCoreData->GetLastModifiedTime())
	{
		pObj = m_pXmlWriter->createElement_TC(pEleRoot, "dcterms:modified");
		pObj->addAttributeNode("xsi:type", "dcterms:W3CDTF");
		pObj->setContent(pSummaryCoreData->GetLastModifiedTime());//����ð�
	}
	
	BrBOOL bRet = m_pXmlWriter->saveXmlData_TC();
	if(bRet)
	{
		bRet = m_pPackage->closePackage(bRet);
		if(!bRet)
			SetErrorFReturn(CFilterError(kPoErrFileWrite));
	}
	else
		SetErrorFReturn(CFilterError(kPoErrFileWrite));

#ifdef SPECIALBASE_STD_MEMORY_RELEASE
	m_pXmlWriter->destoryRootElement_TC();
#endif	// SPECIALBASE_STD_MEMORY_RELEASE

	return bRet;
}

CBrXmlElement_TC * CBrXMLSummaryWriter::createVectorElement(CBrXmlElement_TC *pEleRoot,char *pSz, char* pBaseType)
{
	CBrXmlElement_TC *pVectorEle = m_pXmlWriter->createElement_TC(pEleRoot, "vt:vector");
	pVectorEle->addAttributeNode("size", pSz);
	pVectorEle->addAttributeNode("baseType", pBaseType);

	return pVectorEle;
}
BrBOOL CBrXMLSummaryWriter::createVectorVariantElement(CBrXmlElement_TC *pVectorEle,char *pChildElementName, char* pChildContents)
{
	CBrXmlElement_TC *pVariant = m_pXmlWriter->createElement_TC(pVectorEle, "vt:variant");
	CBrXmlElement_TC *pVariantObj = m_pXmlWriter->createElement_TC(pVariant, pChildElementName);
	pVariantObj->setContent(pChildContents);

	return BrTRUE;
}

CBrSummaryData* CBrXMLSummaryWriter::CreateSummaryData()
{
	CBrSummaryData* pSummaryData = BrNULL;
	if(!poBwp_hasBoraDoc())
		pSummaryData = poSheet_GetSummaryData();
	else
		pSummaryData = poBwp_GetSummaryData();
	return pSummaryData;
}
#endif//#ifdef XML_EXPORT

