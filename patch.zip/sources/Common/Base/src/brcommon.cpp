#include <basePCH.hpp>
#include "send_to_callback.h"
#include <setjmp.h>
#include "Shapetype.h"
#include "bmvinterface.h"
#include "bmvinterface_tool.h"
#include "cmnFunc.h"
#include "painter.h"
#include "prmemory.h"
#include "bmvstream.h"
#include "bheaptrace.h"
#include "BrCeZip.h"
#include "BaseConstants.h"
#include "BaseDefines.h"
#include "BaseTypes_i.h"
#include "ThreadDefines_i.h"
#include "butil.h"
#include "BrShapeUtil.h"
#include "prmemory_manager.h"
#include "binterfacehandle.h"
#include "BFile.h"
#include "OfficeCrypto/OfficeCryptoCommon/brCodec.h"
#include "bwpObjApi.h"
#include "brmcoreimp.h"
#include "Error/ErrorHandle.h"  // SetThreadAtomError
#include "Error/CPublicErrorObj.h"
#include "BrSafeRound.h"

#include "../System/simd/memory/memoryManipulation.h"
#include "POFileManager.h"

#include "BoraFont.h"

#include <chrono>

// BrAtof �Լ� ������ ���� define
#define BrDBL_MIN_EXP				(-1021)                 /* min binary exponent */
#define BrDBL_MAX_EXP				1024                    /* max binary exponent */
#define BrERANGE					34

// �޸� ������ bmp���� ����, ������� �ʴ� ��� txt���Ϸ� ������
//#define SAVE_BMP_TO_MEMINFO
#ifndef NOT_USE_GLOBAL_VARIABLE
extern B_MEM_POOL* gpMemPool;

// (BoraThread ���ô� B_Init�� ������ ��츸 ���(BoraThread Manager������))
extern BrJumpBuf	gJumpBuf; //for exception 
extern BrBOOL		gbMakeTmpDirectory;
//static BrCHAR	gTempPath[BRMAX_FULLPATH_LENGTH];

BrINT32 getLCDWidth(), getLCDHeight(), gnBits;
BrINT16	gnBoraResolution;
BrINT16	g_nExportPDFRes;

void*		g_pZipHandle = BrNULL;
void*		g_pEmZipHandle = BrNULL;
BrBOOL		g_bIsEmZip = BrFALSE;
#endif //!NOT_USE_GLOBAL_VARIABLE


#ifdef __arm__
extern "C" void br_memset16_arm(uint16_t* dst, uint16_t value, int count);
extern "C" void br_memset32_arm(uint32_t* dst, uint32_t value, int count);
#endif //__arm__

extern "C" void br_memset16_simd(uint16_t* dst, uint16_t value, int count);
extern "C" void br_memset32_simd(uint32_t* dst, uint32_t value, int count);

/*// ihwa
BrLPVOID BMallocEx(BrINT32 size)
{
	return BMalloc(size);
}
void BFreeEx(BrLPVOID ptr)
{
	BFree(ptr);
}
*/


const BrBYTE g_bPatterns[g_nPatternCnt*8] =
{
    (BrBYTE)0xff, (BrBYTE)0xff, (BrBYTE)0xff, (BrBYTE)0xf7, (BrBYTE)0xff, (BrBYTE)0xff, (BrBYTE)0xff, (BrBYTE)0x7f, // 5%							0
    (BrBYTE)0xff, (BrBYTE)0xf7, (BrBYTE)0xff, (BrBYTE)0x7f, (BrBYTE)0xff, (BrBYTE)0xf7, (BrBYTE)0xff, (BrBYTE)0x7f, // 10%
    (BrBYTE)0xff, (BrBYTE)0xdd, (BrBYTE)0xff, (BrBYTE)0x77, (BrBYTE)0xff, (BrBYTE)0xdd, (BrBYTE)0xff, (BrBYTE)0x77, // 20%
    (BrBYTE)0xdd, (BrBYTE)0x77, (BrBYTE)0xdd, (BrBYTE)0x77, (BrBYTE)0xdd, (BrBYTE)0x77, (BrBYTE)0xdd, (BrBYTE)0x77, // 25%
    (BrBYTE)0xee, (BrBYTE)0x55, (BrBYTE)0xbb, (BrBYTE)0x55, (BrBYTE)0xee, (BrBYTE)0x55, (BrBYTE)0xbb, (BrBYTE)0x55, // 30%
	(BrBYTE)0xea, (BrBYTE)0x55, (BrBYTE)0xaa, (BrBYTE)0x55, (BrBYTE)0xae, (BrBYTE)0x55, (BrBYTE)0xaa, (BrBYTE)0x55, // 40%
    (BrBYTE)0xaa, (BrBYTE)0x55, (BrBYTE)0xaa, (BrBYTE)0x55, (BrBYTE)0xaa, (BrBYTE)0x55, (BrBYTE)0xaa, (BrBYTE)0x55, // 50%
    (BrBYTE)0x22, (BrBYTE)0x88, (BrBYTE)0x22, (BrBYTE)0x88, (BrBYTE)0x22, (BrBYTE)0x88, (BrBYTE)0x22, (BrBYTE)0x88, // 70%
    (BrBYTE)0xdd, (BrBYTE)0x77, (BrBYTE)0xdd, (BrBYTE)0x77, (BrBYTE)0xdd, (BrBYTE)0x77, (BrBYTE)0xdd, (BrBYTE)0x77, // 25%
    (BrBYTE)0xff, (BrBYTE)0xff, (BrBYTE)0x00, (BrBYTE)0x00, (BrBYTE)0xff, (BrBYTE)0xff, (BrBYTE)0x00, (BrBYTE)0x00, // Dark horizontal
    (BrBYTE)0x33, (BrBYTE)0x33, (BrBYTE)0x33, (BrBYTE)0x33, (BrBYTE)0x33, (BrBYTE)0x33, (BrBYTE)0x33, (BrBYTE)0x33, // Dark Vertical				10
    (BrBYTE)0x7c, (BrBYTE)0xf8, (BrBYTE)0xf1, (BrBYTE)0xe3, (BrBYTE)0xc7, (BrBYTE)0x8f, (BrBYTE)0x1f, (BrBYTE)0x3e, // Wide downward diagonal
    (BrBYTE)0x3e, (BrBYTE)0x1f, (BrBYTE)0x8f, (BrBYTE)0xc7, (BrBYTE)0xe3, (BrBYTE)0xf1, (BrBYTE)0xf8, (BrBYTE)0x7c, // Wide upward diagonal
    (BrBYTE)0x66, (BrBYTE)0x99, (BrBYTE)0x99, (BrBYTE)0x66, (BrBYTE)0x66, (BrBYTE)0x99, (BrBYTE)0x99, (BrBYTE)0x66, // Small checker board
    (BrBYTE)0x66, (BrBYTE)0x00, (BrBYTE)0x99, (BrBYTE)0x00, (BrBYTE)0x66, (BrBYTE)0x00, (BrBYTE)0x99, (BrBYTE)0x00, // Trellis
    (BrBYTE)0xff, (BrBYTE)0xff, (BrBYTE)0xff, (BrBYTE)0x00, (BrBYTE)0xff, (BrBYTE)0xff, (BrBYTE)0xff, (BrBYTE)0x00, // Light horizontal
    (BrBYTE)0x77, (BrBYTE)0x77, (BrBYTE)0x77, (BrBYTE)0x77, (BrBYTE)0x77, (BrBYTE)0x77, (BrBYTE)0x77, (BrBYTE)0x77, // Light vertical
    (BrBYTE)0xee, (BrBYTE)0xdd, (BrBYTE)0xbb, (BrBYTE)0x77, (BrBYTE)0xee, (BrBYTE)0xdd, (BrBYTE)0xbb, (BrBYTE)0x77, // Light downward diagonal
    (BrBYTE)0x77, (BrBYTE)0xbb, (BrBYTE)0xdd, (BrBYTE)0xee, (BrBYTE)0x77, (BrBYTE)0xbb, (BrBYTE)0xdd, (BrBYTE)0xee, // Light upward diagonal
    (BrBYTE)0x77, (BrBYTE)0x77, (BrBYTE)0x77, (BrBYTE)0x00, (BrBYTE)0x77, (BrBYTE)0x77, (BrBYTE)0x77, (BrBYTE)0x00, // Small grid
    (BrBYTE)0xee, (BrBYTE)0x55, (BrBYTE)0xbb, (BrBYTE)0x55, (BrBYTE)0xee, (BrBYTE)0x55, (BrBYTE)0xbb, (BrBYTE)0x55, // 30%							20
    (BrBYTE)0xff, (BrBYTE)0xdd, (BrBYTE)0xff, (BrBYTE)0x77, (BrBYTE)0xff, (BrBYTE)0xdd, (BrBYTE)0xff, (BrBYTE)0x77, // 20%
    (BrBYTE)0xff, (BrBYTE)0xf7, (BrBYTE)0xff, (BrBYTE)0x7f, (BrBYTE)0xff, (BrBYTE)0xf7, (BrBYTE)0xff, (BrBYTE)0x7f, // 10%
    (BrBYTE)0xff, (BrBYTE)0xff, (BrBYTE)0xff, (BrBYTE)0xf7, (BrBYTE)0xff, (BrBYTE)0xff, (BrBYTE)0xff, (BrBYTE)0x7f, // 5%
	(BrBYTE)0xea, (BrBYTE)0x55, (BrBYTE)0xaa, (BrBYTE)0x55, (BrBYTE)0xae, (BrBYTE)0x55, (BrBYTE)0xaa, (BrBYTE)0x55, // 40%
    (BrBYTE)0xaa, (BrBYTE)0x44, (BrBYTE)0xaa, (BrBYTE)0x11, (BrBYTE)0xaa, (BrBYTE)0x44, (BrBYTE)0xaa, (BrBYTE)0x11, // 60%
    (BrBYTE)0x00, (BrBYTE)0x22, (BrBYTE)0x00, (BrBYTE)0x88, (BrBYTE)0x00, (BrBYTE)0x22, (BrBYTE)0x00, (BrBYTE)0x88, // 75%
    (BrBYTE)0x00, (BrBYTE)0x01, (BrBYTE)0x00, (BrBYTE)0x10, (BrBYTE)0x00, (BrBYTE)0x01, (BrBYTE)0x00, (BrBYTE)0x10, // 80%
    (BrBYTE)0x80, (BrBYTE)0x00, (BrBYTE)0x00, (BrBYTE)0x00, (BrBYTE)0x08, (BrBYTE)0x00, (BrBYTE)0x00, (BrBYTE)0x00, // 90%
    (BrBYTE)0xf0, (BrBYTE)0xf0, (BrBYTE)0xf0, (BrBYTE)0xf0, (BrBYTE)0x0f, (BrBYTE)0x0f, (BrBYTE)0x0f, (BrBYTE)0x0f, // Large checker board
    (BrBYTE)0x7f, (BrBYTE)0x7f, (BrBYTE)0x7f, (BrBYTE)0x7f, (BrBYTE)0x7f, (BrBYTE)0x7f, (BrBYTE)0x7f, (BrBYTE)0x00, // Large Grid					30
    (BrBYTE)0xff, (BrBYTE)0x7f, (BrBYTE)0xff, (BrBYTE)0x7f, (BrBYTE)0xff, (BrBYTE)0x7f, (BrBYTE)0xff, (BrBYTE)0x55, // Dotted grid
    (BrBYTE)0xf7, (BrBYTE)0xf7, (BrBYTE)0xf7, (BrBYTE)0x00, (BrBYTE)0x7f, (BrBYTE)0x7f, (BrBYTE)0x7f, (BrBYTE)0x00, // Horizontal brick
    (BrBYTE)0x7e, (BrBYTE)0xbd, (BrBYTE)0xdb, (BrBYTE)0xe7, (BrBYTE)0xf7, (BrBYTE)0xfb, (BrBYTE)0xfd, (BrBYTE)0xfe, // Diagonal brick
	(BrBYTE)0xaa, (BrBYTE)0xaa, (BrBYTE)0xaa, (BrBYTE)0xaa, (BrBYTE)0xaa, (BrBYTE)0xaa, (BrBYTE)0xaa, (BrBYTE)0xaa, // Narrow vertical
    (BrBYTE)0xff, (BrBYTE)0x00, (BrBYTE)0xff, (BrBYTE)0x00, (BrBYTE)0xff, (BrBYTE)0x00, (BrBYTE)0xff, (BrBYTE)0x00, // Narrow horizontal			35
    (BrBYTE)0xf7, (BrBYTE)0xf7, (BrBYTE)0xf7, (BrBYTE)0xf7, (BrBYTE)0x7f, (BrBYTE)0x7f, (BrBYTE)0x7f, (BrBYTE)0x7f, // Dashed vertical
    (BrBYTE)0xff, (BrBYTE)0xff, (BrBYTE)0xff, (BrBYTE)0xf0, (BrBYTE)0xff, (BrBYTE)0xff, (BrBYTE)0xff, (BrBYTE)0x0f, // Dashed horizontal
    (BrBYTE)0x66, (BrBYTE)0xcc, (BrBYTE)0x99, (BrBYTE)0x33, (BrBYTE)0x66, (BrBYTE)0xcc, (BrBYTE)0x99, (BrBYTE)0x33, // Dark downward diagonal
    (BrBYTE)0x66, (BrBYTE)0x33, (BrBYTE)0x99, (BrBYTE)0xcc, (BrBYTE)0x66, (BrBYTE)0x33, (BrBYTE)0x99, (BrBYTE)0xcc, // Dark upward diagonal
    (BrBYTE)0xff, (BrBYTE)0xff, (BrBYTE)0xee, (BrBYTE)0xdd, (BrBYTE)0xbb, (BrBYTE)0x77, (BrBYTE)0xff, (BrBYTE)0xff, // Dashed downward diagonal		40
    (BrBYTE)0xff, (BrBYTE)0xff, (BrBYTE)0x77, (BrBYTE)0xbb, (BrBYTE)0xdd, (BrBYTE)0xee, (BrBYTE)0xff, (BrBYTE)0xff, // Dashed upward diagonal
    (BrBYTE)0xff, (BrBYTE)0xef, (BrBYTE)0xc7, (BrBYTE)0x83, (BrBYTE)0x01, (BrBYTE)0x83, (BrBYTE)0xc7, (BrBYTE)0xef, // Solid diamond


    (BrBYTE)0xfe, (BrBYTE)0x7d, (BrBYTE)0xbb, (BrBYTE)0xd7, (BrBYTE)0xef, (BrBYTE)0xd7, (BrBYTE)0xbb, (BrBYTE)0x7d, // Outlined diamond
    (BrBYTE)0xff, (BrBYTE)0xdd, (BrBYTE)0xff, (BrBYTE)0xf7, (BrBYTE)0xff, (BrBYTE)0xdd, (BrBYTE)0xff, (BrBYTE)0x7f, // Dotted diamond
    (BrBYTE)0x72, (BrBYTE)0xf3, (BrBYTE)0x3f, (BrBYTE)0x27, (BrBYTE)0xe4, (BrBYTE)0xfc, (BrBYTE)0xcf, (BrBYTE)0x4e, // Large confetti
    (BrBYTE)0xfb, (BrBYTE)0xdf, (BrBYTE)0xfe, (BrBYTE)0xef, (BrBYTE)0xfd, (BrBYTE)0xbf, (BrBYTE)0xf7, (BrBYTE)0x7f, // Small confetti
    (BrBYTE)0xe7, (BrBYTE)0xdb, (BrBYTE)0xbd, (BrBYTE)0x7e, (BrBYTE)0xe7, (BrBYTE)0xdb, (BrBYTE)0xbd, (BrBYTE)0x7e, // Zig zag
    (BrBYTE)0x7f, (BrBYTE)0xfe, (BrBYTE)0x7f, (BrBYTE)0xff, (BrBYTE)0xef, (BrBYTE)0xf7, (BrBYTE)0xef, (BrBYTE)0xff, // Divot
    (BrBYTE)0x3f, (BrBYTE)0xda, (BrBYTE)0xe7, (BrBYTE)0xff, (BrBYTE)0x3f, (BrBYTE)0xda, (BrBYTE)0xe7, (BrBYTE)0xff, // Wave
    (BrBYTE)0xfe, (BrBYTE)0xfe, (BrBYTE)0xfd, (BrBYTE)0xf3, (BrBYTE)0xcf, (BrBYTE)0xb7, (BrBYTE)0x7b, (BrBYTE)0xfc, // Shingle						50
    (BrBYTE)0xae, (BrBYTE)0xdd, (BrBYTE)0xeb, (BrBYTE)0x77, (BrBYTE)0xba, (BrBYTE)0xdd, (BrBYTE)0xab, (BrBYTE)0x77, // Weave
    (BrBYTE)0x0f, (BrBYTE)0x0f, (BrBYTE)0x0f, (BrBYTE)0x0f, (BrBYTE)0xaa, (BrBYTE)0x55, (BrBYTE)0xaa, (BrBYTE)0x55, // Plaid
    (BrBYTE)0x07, (BrBYTE)0x07, (BrBYTE)0x67, (BrBYTE)0x88, (BrBYTE)0x70, (BrBYTE)0x70, (BrBYTE)0x76, (BrBYTE)0x88, // Sphere

	(BrBYTE)0x55, (BrBYTE)0xAA, (BrBYTE)0xDD, (BrBYTE)0xAA, (BrBYTE)0x55, (BrBYTE)0xAA, (BrBYTE)0xDD, (BrBYTE)0xAA, // 35%
	(BrBYTE)0x00, (BrBYTE)0x10, (BrBYTE)0x00, (BrBYTE)0x40, (BrBYTE)0x00, (BrBYTE)0x01, (BrBYTE)0x00, (BrBYTE)0x04, // 85%
};

const BrUINT32 g_nPreAlphaTable[256] =
{
	0x00000000, 0x00010101, 0x00020202, 0x00030303, 0x00040404, 0x00050505, 0x00060606, 0x00070707,
	0x00080808, 0x00090909, 0x000A0A0A, 0x000B0B0B, 0x000C0C0C, 0x000D0D0D, 0x000E0E0E, 0x000F0F0F,
	0x00101010, 0x00111111, 0x00121212, 0x00131313, 0x00141414, 0x00151515, 0x00161616, 0x00171717,
	0x00181818, 0x00191919, 0x001A1A1A, 0x001B1B1B, 0x001C1C1C, 0x001D1D1D, 0x001E1E1E, 0x001F1F1F,
	0x00202020, 0x00212121, 0x00222222, 0x00232323, 0x00242424, 0x00252525, 0x00262626, 0x00272727,
	0x00282828, 0x00292929, 0x002A2A2A, 0x002B2B2B, 0x002C2C2C, 0x002D2D2D, 0x002E2E2E, 0x002F2F2F,
	0x00303030, 0x00313131, 0x00323232, 0x00333333, 0x00343434, 0x00353535, 0x00363636, 0x00373737,
	0x00383838, 0x00393939, 0x003A3A3A, 0x003B3B3B, 0x003C3C3C, 0x003D3D3D, 0x003E3E3E, 0x003F3F3F,
	0x00404040, 0x00414141, 0x00424242, 0x00434343, 0x00444444, 0x00454545, 0x00464646, 0x00474747,
	0x00484848, 0x00494949, 0x004A4A4A, 0x004B4B4B, 0x004C4C4C, 0x004D4D4D, 0x004E4E4E, 0x004F4F4F,
	0x00505050, 0x00515151, 0x00525252, 0x00535353, 0x00545454, 0x00555555, 0x00565656, 0x00575757,
	0x00585858, 0x00595959, 0x005A5A5A, 0x005B5B5B, 0x005C5C5C, 0x005D5D5D, 0x005E5E5E, 0x005F5F5F,
	0x00606060, 0x00616161, 0x00626262, 0x00636363, 0x00646464, 0x00656565, 0x00666666, 0x00676767,
	0x00686868, 0x00696969, 0x006A6A6A, 0x006B6B6B, 0x006C6C6C, 0x006D6D6D, 0x006E6E6E, 0x006F6F6F,
	0x00707070, 0x00717171, 0x00727272, 0x00737373, 0x00747474, 0x00757575, 0x00767676, 0x00777777,
	0x00787878, 0x00797979, 0x007A7A7A, 0x007B7B7B, 0x007C7C7C, 0x007D7D7D, 0x007E7E7E, 0x007F7F7F,
	0x00808081, 0x00818182, 0x00828283, 0x00838384, 0x00848485, 0x00858586, 0x00868687, 0x00878788,
	0x00888889, 0x0089898A, 0x008A8A8B, 0x008B8B8C, 0x008C8C8D, 0x008D8D8E, 0x008E8E8F, 0x008F8F90,
	0x00909091, 0x00919192, 0x00929293, 0x00939394, 0x00949495, 0x00959596, 0x00969697, 0x00979798,
	0x00989899, 0x0099999A, 0x009A9A9B, 0x009B9B9C, 0x009C9C9D, 0x009D9D9E, 0x009E9E9F, 0x009F9FA0,
	0x00A0A0A1, 0x00A1A1A2, 0x00A2A2A3, 0x00A3A3A4, 0x00A4A4A5, 0x00A5A5A6, 0x00A6A6A7, 0x00A7A7A8,
	0x00A8A8A9, 0x00A9A9AA, 0x00AAAAAB, 0x00ABABAC, 0x00ACACAD, 0x00ADADAE, 0x00AEAEAF, 0x00AFAFB0,
	0x00B0B0B1, 0x00B1B1B2, 0x00B2B2B3, 0x00B3B3B4, 0x00B4B4B5, 0x00B5B5B6, 0x00B6B6B7, 0x00B7B7B8,
	0x00B8B8B9, 0x00B9B9BA, 0x00BABABB, 0x00BBBBBC, 0x00BCBCBD, 0x00BDBDBE, 0x00BEBEBF, 0x00BFBFC0,
	0x00C0C0C1, 0x00C1C1C2, 0x00C2C2C3, 0x00C3C3C4, 0x00C4C4C5, 0x00C5C5C6, 0x00C6C6C7, 0x00C7C7C8,
	0x00C8C8C9, 0x00C9C9CA, 0x00CACACB, 0x00CBCBCC, 0x00CCCCCD, 0x00CDCDCE, 0x00CECECF, 0x00CFCFD0,
	0x00D0D0D1, 0x00D1D1D2, 0x00D2D2D3, 0x00D3D3D4, 0x00D4D4D5, 0x00D5D5D6, 0x00D6D6D7, 0x00D7D7D8,
	0x00D8D8D9, 0x00D9D9DA, 0x00DADADB, 0x00DBDBDC, 0x00DCDCDD, 0x00DDDDDE, 0x00DEDEDF, 0x00DFDFE0,
	0x00E0E0E1, 0x00E1E1E2, 0x00E2E2E3, 0x00E3E3E4, 0x00E4E4E5, 0x00E5E5E6, 0x00E6E6E7, 0x00E7E7E8,
	0x00E8E8E9, 0x00E9E9EA, 0x00EAEAEB, 0x00EBEBEC, 0x00ECECED, 0x00EDEDEE, 0x00EEEEEF, 0x00EFEFF0,
	0x00F0F0F1, 0x00F1F1F2, 0x00F2F2F3, 0x00F3F3F4, 0x00F4F4F5, 0x00F5F5F6, 0x00F6F6F7, 0x00F7F7F8,
	0x00F8F8F9, 0x00F9F9FA, 0x00FAFAFB, 0x00FBFBFC, 0x00FCFCFD, 0x00FDFDFE, 0x00FEFEFF, 0x01000000,
};

const BrBYTE g_nAlphaInvertTable[256] =
{
	0xFF, 0xFE, 0xFD, 0xFC, 0xFB, 0xFA, 0xF9, 0xF8,
	0xF7, 0xF6, 0xF5, 0xF4, 0xF3, 0xF2, 0xF1, 0xF0,
	0xEF, 0xEE, 0xED, 0xEC, 0xEB, 0xEA, 0xE9, 0xE8,
	0xE7, 0xE6, 0xE5, 0xE4, 0xE3, 0xE2, 0xE1, 0xE0,
	0xDF, 0xDE, 0xDD, 0xDC, 0xDB, 0xDA, 0xD9, 0xD8,
	0xD7, 0xD6, 0xD5, 0xD4, 0xD3, 0xD2, 0xD1, 0xD0,
	0xCF, 0xCE, 0xCD, 0xCC, 0xCB, 0xCA, 0xC9, 0xC8,
	0xC7, 0xC6, 0xC5, 0xC4, 0xC3, 0xC2, 0xC1, 0xC0,
	0xBF, 0xBE, 0xBD, 0xBC, 0xBB, 0xBA, 0xB9, 0xB8,
	0xB7, 0xB6, 0xB5, 0xB4, 0xB3, 0xB2, 0xB1, 0xB0,
	0xAF, 0xAE, 0xAD, 0xAC, 0xAB, 0xAA, 0xA9, 0xA8,
	0xA7, 0xA6, 0xA5, 0xA4, 0xA3, 0xA2, 0xA1, 0xA0,
	0x9F, 0x9E, 0x9D, 0x9C, 0x9B, 0x9A, 0x99, 0x98,
	0x97, 0x96, 0x95, 0x94, 0x93, 0x92, 0x91, 0x90,
	0x8F, 0x8E, 0x8D, 0x8C, 0x8B, 0x8A, 0x89, 0x88,
	0x87, 0x86, 0x85, 0x84, 0x83, 0x82, 0x81, 0x80,
	0x7F, 0x7E, 0x7D, 0x7C, 0x7B, 0x7A, 0x79, 0x78,
	0x77, 0x76, 0x75, 0x74, 0x73, 0x72, 0x71, 0x70,
	0x6F, 0x6E, 0x6D, 0x6C, 0x6B, 0x6A, 0x69, 0x68,
	0x67, 0x66, 0x65, 0x64, 0x63, 0x62, 0x61, 0x60,
	0x5F, 0x5E, 0x5D, 0x5C, 0x5B, 0x5A, 0x59, 0x58,
	0x57, 0x56, 0x55, 0x54, 0x53, 0x52, 0x51, 0x50,
	0x4F, 0x4E, 0x4D, 0x4C, 0x4B, 0x4A, 0x49, 0x48,
	0x47, 0x46, 0x45, 0x44, 0x43, 0x42, 0x41, 0x40,
	0x3F, 0x3E, 0x3D, 0x3C, 0x3B, 0x3A, 0x39, 0x38,
	0x37, 0x36, 0x35, 0x34, 0x33, 0x32, 0x31, 0x30,
	0x2F, 0x2E, 0x2D, 0x2C, 0x2B, 0x2A, 0x29, 0x28,
	0x27, 0x26, 0x25, 0x24, 0x23, 0x22, 0x21, 0x20,
	0x1F, 0x1E, 0x1D, 0x1C, 0x1B, 0x1A, 0x19, 0x18,
	0x17, 0x16, 0x15, 0x14, 0x13, 0x12, 0x11, 0x10,
	0x0F, 0x0E, 0x0D, 0x0C, 0x0B, 0x0A, 0x09, 0x08,
	0x07, 0x06, 0x05, 0x04, 0x03, 0x02, 0x01, 0x00,
};

//ZPD-3340, default res str for BrResStringID enum
char const * g_brResStr [ BR_RESSTR_MAX ] = {
	/*0*/ "",	//BR_RESSTR_NONE = 0,
	/*1*/ "\xec\xa0\x9c\xeb\xaa\xa9\xec\x9d\x84 \xec\x9e\x85\xeb\xa0\xa5\xed\x95\x98\xeb\xa0\xa4\xeb\xa9\xb4 \xeb\x91\x90\xeb\xb2\x88 \xed\x83\xad\xed\x95\x98\xec\x84\xb8\xec\x9a\x94", //"������ �Է��Ϸ��� �ι� ���ϼ���",
	/*2*/ "\xeb\xb6\x80\xec\xa0\x9c\xeb\xaa\xa9\xec\x9d\x84 \xec\x9e\x85\xeb\xa0\xa5\xed\x95\x98\xeb\xa0\xa4\xeb\xa9\xb4 \xeb\x91\x90 \xeb\xb2\x88 \xed\x83\xad\xed\x95\x98\xec\x84\xb8\xec\x9a\x94", //"�������� �Է��Ϸ��� �� �� ���ϼ���",
	/*3*/ "\xed\x85\x8d\xec\x8a\xa4\xed\x8a\xb8\xeb\xa5\xbc \xec\x9e\x85\xeb\xa0\xa5\xed\x95\x98\xeb\xa0\xa4\xeb\xa9\xb4 \xeb\x91\x90 \xeb\xb2\x88 \xed\x83\xad\xed\x95\x98\xec\x84\xb8\xec\x9a\x94", //"�ؽ�Ʈ�� �Է��Ϸ��� �� �� ���ϼ���",
	/*4*/ "Insert Text Here",
	/*5*/ "Date",
	/*6*/ "slide number",
	/*7*/ "Footer",
	/*8*/ "Document title",
	/*9*/ "Document subtitle",
	/*10*/ "Author name",
	/*11*/ "School",
	/*12*/ "Page",
	/*13*/ "Pg.",
	/*14*/ "Add a heading to your document",
	/*15*/ "Header",
	/*16*/ "Click on the icon to add a chart",
	/*17*/ "Click on the icon to add a table",
	/*18*/ "Click on the icon to add a media",
	/*19*/ "Click on the icon to add a picture",
	/*20*/ "Click on the icon to add a camera",
	/*21*/ "Click on the icon to add a online image",
	/*22*/ "Master Title",
	/*23*/ "Master subTitle",
	/*24*/ "Chart",
	/*25*/ "Table",
	/*26*/ "Media",
	/*27*/ "Picture",
	/*28*/ "Camera",
	/*29*/ "Online image",
	/*30*/ "Footer",	
	/*31*/ "Office Theme",
	/*32*/ "Title Slide",
	/*33*/ "Title and content",
	/*34*/ "Section headers",
	/*35*/ "Two Object",
	/*36*/ "two Text Two Object",
	/*37*/ "Title Only",
	/*38*/ "Blank",
	/*39*/ "Caption and Contents",
	/*40*/ "Caption and Image",
	/*41*/ "Title and Sero Text",
	/*42*/ "Sero Title and Text",
	/*43*/	"Custom Layout",
	/*44*/ "Click to edit Master text styles.",
	/*45*/ "Second level",
	/*46*/ "Third level",
	/*47*/ "Fourth level",
	/*48*/ "Fifth level",
	/*49*/ "User_Degin",
	/**/			//object name (ZPD-3340)
	/*50*/ "Table",
	/*51*/ "Group",
	/*52*/ "Ink",
	/*53*/ "Chart",
	/*54*/ "Audio",
	/*55*/ "Video",
	/*56*/ "Media",
	/*57*/ "OLE",
	/*58*/ "Picture",
	/*59*/ "Text Box",
	/*60*/ "Shape",
	/**/	//placeholder name
	/*61*/ "Vertical Title Placeholder",
	/*62*/ "Title Placeholder",
	/*63*/ "Vertical Text Placeholder",
	/*64*/ "Text Placeholder",
	/*65*/ "Title",
	/*66*/ "Subtitle",
	/*67*/ "Content Placeholder",
	/*68*/ "Chart Placeholder",
	/*69*/ "Table Placeholder",
	/*70*/ "Clip Art Placeholder",
	/*71*/ "Media Placeholder",
	/*72*/ "Picture Placeholder",
	/*73*/ "Camera Placeholder",
	/*74*/ "Footer Placeholder",
	/*75*/ "Header Placeholder",
	/*76*/ "Date Placeholder",
	/*77*/ "Diagram Placeholder",
	/*78*/ "Online Image Placeholder",
	/*79*/ "Slide Number Placeholder",
	/*80*/ "Table Of Contents",
	/*81*/ "Contents",
	/*82*/ "No table of contents entries found.",
	/*83*/ "Type chapter title(level )",
	/*84*/ "Pg.",
	/*85*/ "Heading",
	/*86*/ "",
	/**
	//		//Comment
	/*87*/ "Comment",
	/*88*/ "",
	/*89*/ "",
	/*90*/ "",
	/*91*/ "",
	/*92*/ "",
	/*93*/ "",
	/*94*/ "",
	/*95*/ "",
	/*96*/ "",
	/*97*/ "",
	/*98*/ "",
	/*99*/ "",
	/*100*/ "",
	//---[Line & FreeDraw]------------------------------------------------------
	/*101*/ "Line",
	/*102*/ "Arrow",
	/*103*/ "Double Arrow",
	/*104*/ "Elbow Connector",
	/*105*/ "Elbow Arrow Connector",
	/*106*/ "Elbow Double Arrow Connector",
	/*107*/ "Curved Connector",
	/*108*/ "Curved Arrow Connector",
	/*109*/ "Curved Double Arrow Connector",
	/*110*/ "Curve",
	/*111*/ "FreeForm",
	/*112*/ "Scribble",
	/*113*/ "FreeDraw",
	//---[Rectangle]------------------------------------------------------------
	/*114*/ "Rectangle",
	/*115*/ "Rounded Rectangle",
	/*116*/ "Snip Single Corner Rectangle",
	/*117*/ "Snip Same Side Corner Rectangle",
	/*118*/ "Snip Diagonal Corner Rectangle",
	/*119*/ "Snip and Round Single Corner Rectangle",
	/*120*/ "Round Single Corner Rectangle",
	/*121*/ "Round Same Side Corner Rectangle",
	/*122*/ "Round Diagonal Corner Rectangle",
	//---[Basic]----------------------------------------------------------------
	/*123*/ "Oval",
	/*124*/ "Isosceles Triangle",
	/*125*/ "Right Triangle",
	/*126*/ "Parallelogram",
	/*127*/ "Trapezoid",
	/*128*/ "Diamond",
	/*129*/ "Regular Pentagon",
	/*130*/ "Hexagon",
	/*131*/ "Heptagon",
	/*132*/ "Octagon",
	/*133*/ "Decagon",
	/*134*/ "Dodecagon",
	/*135*/ "Pie",
	/*136*/ "Chord",
	/*137*/ "Teardrop",
	/*138*/ "Frame",
	/*139*/ "Half Frame",
	/*140*/ "L-Shape",
	/*141*/ "Diagonal Stripe",
	/*142*/ "Plus",
	/*143*/ "Plaque",
	/*144*/ "Can",
	/*145*/ "Cube",
	/*146*/ "Bevel",
	/*147*/ "Donut",
	/*148*/ "\"No\" Symbol",
	/*149*/ "Block Arc",
	/*150*/ "Folded Corner",
	/*151*/ "Smiley Face",
	/*152*/ "Heart",
	/*153*/ "Lighting Bolt",
	/*154*/ "Sun",
	/*155*/ "Moon",
	/*156*/ "Cloud",
	/*157*/ "Arc",
	/*158*/ "Double Bracket",
	/*159*/ "Double Brace",
	/*160*/ "Left Bracket",
	/*161*/ "Right Bracket",
	/*162*/ "Left Brace",
	/*163*/ "Right Brace",
	//---[Arrow]----------------------------------------------------------------
	/*164*/ "Right Arrow",
	/*165*/ "Left Arrow",
	/*166*/ "Up Arrow",
	/*167*/ "Down Arrow",
	/*168*/ "Left-Right Arrow",
	/*169*/ "Up-Down Arrow",
	/*170*/ "Quad Arrow",
	/*171*/ "Left-Right-Up Arrow",
	/*172*/ "Bent Arrow",
	/*173*/ "U-Turn Arrow",
	/*174*/ "Left-Up Arrow",
	/*175*/ "Bent-Up Arrow",
	/*176*/ "Curved Right Arrow",
	/*177*/ "Curved Left Arrow",
	/*178*/ "Curved Up Arrow",
	/*179*/ "Curved Down Arrow",
	/*180*/ "Striped Right Arrow",
	/*181*/ "Notched Right Arrow",
	/*182*/ "Pentagon",
	/*183*/ "Chevron Up",
	/*184*/ "Right Arrow Callout",
	/*185*/ "Down Arrow Callout",
	/*186*/ "Left Arrow Callout",
	/*187*/ "Up Arrow Callout",
	/*188*/ "Left-Right Arrow Callout",
	/*189*/ "Up-Down Arrow Callout",
	/*190*/ "Quad Arrow Callout",
	/*191*/ "Circular Arrow",
	//---[Math]-----------------------------------------------------------------
	/*192*/ "Plus",
	/*193*/ "Minus",
	/*194*/ "Multiply",
	/*195*/ "Division",
	/*196*/ "Equal",
	/*197*/ "Not Equal",
	//---[Flow Chart]-----------------------------------------------------------
	/*198*/ "Process",
	/*199*/ "Alternate Process",
	/*200*/ "Decision",
	/*201*/ "Data",
	/*202*/ "Predefined Process",
	/*203*/ "Internal Storage",
	/*204*/ "Document",
	/*205*/ "Multidocument",
	/*206*/ "Terminator",
	/*207*/ "Preparation",
	/*208*/ "Manual Input",
	/*209*/ "Manual Operation",
	/*210*/ "Connector",
	/*211*/ "Off-page Connector",
	/*212*/ "Card",
	/*213*/ "Punched Tape",
	/*214*/ "Summing Junction",
	/*215*/ "Or",
	/*216*/ "Collate",
	/*217*/ "Sort",
	/*218*/ "Extract",
	/*219*/ "Merge",
	/*220*/ "Stored Data",
	/*221*/ "Delay",
	/*222*/ "Sequential Access Storage",
	/*223*/ "Magnetic Disk",
	/*224*/ "Direct Access Storage",
	/*225*/ "Display",
	//---[Star]-----------------------------------------------------------------
	/*226*/ "Explosion 1",
	/*227*/ "Explosion 2",
	/*228*/ "4-Point Star",
	/*229*/ "5-Point Star",
	/*230*/ "6-Point Star",
	/*231*/ "7-Point Star",
	/*232*/ "8-Point Star",
	/*233*/ "10-Point Star",
	/*234*/ "12-Point Star",
	/*235*/ "16-Point Star",
	/*236*/ "24-Point Star",
	/*237*/ "32-Point Star",
	/*238*/ "Up Ribbon",
	/*239*/ "Down Ribbon",
	/*240*/ "Curved Up Ribbon",
	/*241*/ "Curved Down Ribbon",
	/*242*/ "Vertical Scroll",
	/*243*/ "Horizontal Scroll",
	/*244*/ "Waves",
	/*245*/ "Double Wave",
	//---[Description]----------------------------------------------------------
	/*246*/ "Rectangular Callout",
	/*247*/ "Rounded Rectangular Callout",
	/*248*/ "Oval Callout",
	/*249*/ "Cloud Callout",
	/*250*/ "Line Callout 1",
	/*251*/ "Line Callout 2",
	/*252*/ "Line Callout 3",
	/*253*/ "Line Callout 1 (Accent Bar)",
	/*254*/ "Line Callout 2 (Accent Bar)",
	/*255*/ "Line Callout 3 (Accent Bar)",
	/*256*/ "Line Callout 1 (No Border)",
	/*257*/ "Line Callout 2 (No Border)",
	/*258*/ "Line Callout 3 (No Border)",
	/*259*/ "Line Callout 1 (Border and Accent Bar)",
	/*260*/ "Line Callout 2 (Border and Accent Bar)",
	/*261*/ "Line Callout 3 (Border and Accent Bar)",
	//---[Action Button]--------------------------------------------------------
	/*262*/ "Back or Previous",
	/*263*/ "Forward or Next",
	/*264*/ "Beginning",
	/*265*/ "End",
	/*266*/ "Home",
	/*267*/ "Information",
	/*268*/ "Return",
	/*269*/ "Movie",
	/*270*/ "Document",
	/*271*/ "Sound",
	/*272*/ "Help",
	/*273*/ "Custom",
	/*274*/"",
	/*275*/"",
	/*276*/"",
	/*277*/"",
	/*278*/"",
	/*279*/"",
	/*280*/"",
	/*281*/"",
	/*282*/"",
	/*283*/"",
	/*284*/"",
	/*285*/"",
	/*286*/"",
	/*287*/"",
	/*288*/"",
	/*289*/"",
	/*290*/"",
	/*291*/"",
	/*292*/"",
	/*293*/"",
	/*294*/"",
	/*295*/"",
	/*296*/"",
	/*297*/"",
	/*298*/"",
	/*299*/"",
	/*300*/"Monday",
	/*301*/"Tuesday",
	/*302*/"Wednesday",
	/*303*/"Thursday",
	/*304*/"Friday",
	/*305*/"Saturday",
	/*306*/"Sunday",
	/*307*/"AM",
	/*308*/"PM",
	/*309*/"January",
	/*310*/"February",
	/*311*/"March",
	/*312*/"April",
	/*313*/"May",
	/*314*/"June",
	/*315*/"July",
	/*316*/"August",
	/*317*/"September",
	/*318*/"October",
	/*319*/"November",
	/*320*/"December",
	/*321*/"Diagram",		//[150601][ZPD-12358][Tony] SmartArt Object name
	/*322*/"[Text]",		//[160212][ZPD-22871][Tony] SmartArt PlaceHolder Text
	/*323*/"\xec\x97\xb4", //"��",
	/*324*/"\xec\x9a\x94\xec\x95\xbd", //"���",
	/*325*/"Loading...",
	/*326*/"Sheet",
	/*327*/"F",
	/*328*/"",
	/*329*/"",
	/*330*/"",
	/*331*/"",
	/*332*/"",
	/*333*/"",
	/*334*/"",
	/*335*/"",
	/*336*/"",
	/*337*/"",
	/*338*/"",
	/*339*/"",
	/*340*/"",
	/*341*/"",
	/*342*/"",
	/*343*/"",
	/*344*/"",
	/*345*/"",
	/*346*/"",
	/*347*/"",
	/*348*/"",
	/*349*/"",
	/*350*/"",	// BR_RESSTR_CHART_TITLE
	/*351*/"",	// BR_RESSTR_CHART_AXIS_TITLE
	/*352*/"",	// BR_RESSTR_CHART_SERIES
	/*353*/"",	// BR_RESSTR_CHART_LABEL_OTHER
	/*354*/"",	// BR_RESSTR_CHART_SERIES_TL_POLYNORMIAL
	/*355*/"",	// BR_RESSTR_CHART_SERIES_TL_EXPONENTIAL
	/*356*/"",	// BR_RESSTR_CHART_SERIES_TL_LOGARITHMIC
	/*357*/"",	// BR_RESSTR_CHART_SERIES_TL_POWER
	/*358*/"",	// BR_RESSTR_CHART_SERIES_TL_MOVING_AVERAGE
	/*359*/"",	// BR_RESSTR_CHART_SERIES_TL_LINEAR
	/*360*/"",	// BR_RESSTR_CHART_AXISUNIT_HUNDREDS
	/*361*/"",	// BR_RESSTR_CHART_AXISUNIT_THOUSANDS
	/*362*/"",	// BR_RESSTR_CHART_AXISUNIT_MILLIONS
	/*363*/"",	// BR_RESSTR_CHART_AXISUNIT_BILLIONS
	/*364*/"",	// BR_RESSTR_CHART_AXISUNIT_TRILLIONS
	/*365*/"",	// BR_RESSTR_CHART_AREA
	/*366*/"",	// BR_RESSTR_CHART_PLOT_AREA
	/*367*/"",	// BR_RESSTR_CHART_HORIZONTAL_AXIS
	/*368*/"",	// BR_RESSTR_CHART_VERTICAL_AXIS
	/*369*/"",	// BR_RESSTR_CHART_DEPTH_AXIS
	/*370*/"",	// BR_RESSTR_CHART_HORIZONTAL_AXIS_TITLE
	/*371*/"",	// BR_RESSTR_CHART_VERTICAL_AXIS_TITLE
	/*372*/"",	// BR_RESSTR_CHART_DEPTH_AXIS_TITLE
	/*373*/"",	// BR_RESSTR_CHART_LEGEND
	/*374*/"",	// BR_RESSTR_CHART_WALL
	/*375*/"",	// BR_RESSTR_CHART_BACKWALL
	/*376*/"",	// BR_RESSTR_CHART_SIDEWALL
	/*377*/"",	// BR_RESSTR_CHART_FLOOR
	/*378*/"",	// BR_RESSTR_CHART_ELEMENT
	/*379*/"",	// BR_RESSTR_CHART_ITEM		
	/*380*/"",	// BR_RESSTR_CHART_COLUMN	
	/*381*/"",	// BR_RESSTR_CHART_HIGH		
	/*382*/"",	// BR_RESSTR_CHART_LOW		
	/*383*/"",	// BR_RESSTR_CHART_CLOSE	
	/*384*/"",	// BR_RESSTR_CHART_SALES	
	/*385*/"",	// BR_RESSTR_CHART_1QTR		
	/*386*/"",	// BR_RESSTR_CHART_2QTR		
	/*387*/"",	// BR_RESSTR_CHART_3QTR		
	/*388*/"",	// BR_RESSTR_CHART_4QTR		
	/*389*/"",	// BR_RESSTR_CHART_XVALUES	
	/*390*/"",	// BR_RESSTR_CHART_YVALUES	
	/*391*/"",	// BR_RESSTR_CHART_SIZE		
	/*392*/"",	// BR_RESSTR_CHART_VOLUME	
	/*393*/"",	// BR_RESSTR_CHART_OPEN		
	/*394*/"",
	/*395*/"",
	/*396*/"",
	/*397*/"",
	/*398*/"",
	/*399*/"",
	/*400*/"\x31\x32\xec\x9b\x94", //"12��",/*------------Word Quick Table-------------------*/
	/*401*/"\x35\xec\x9b\x94", //"5��",
	/*402*/"\xec\x9b\x94", //"��",
	/*403*/"\xed\x99\x94", //"ȭ",
	/*404*/"\xec\x88\x98", //"��",
	/*405*/"\xeb\xaa\xa9", //"��",
	/*406*/"\xea\xb8\x88", //"��",
	/*407*/"\xed\x86\xa0", //"��",
	/*408*/"\xec\x9d\xbc", //"��",
	/*409*/"\xec\x9b\x94\xec\x9a\x94\xec\x9d\xbc", //"������",
	/*410*/"\xed\x99\x94\xec\x9a\x94\xec\x9d\xbc", //"ȭ����",
	/*411*/"\xec\x88\x98\xec\x9a\x94\xec\x9d\xbc", //"������",
	/*412*/"\xeb\xaa\xa9\xec\x9a\x94\xec\x9d\xbc", //"�����",
	/*413*/"\xea\xb8\x88\xec\x9a\x94\xec\x9d\xbc", //"�ݿ���",
	/*414*/"\xed\x86\xa0\xec\x9a\x94\xec\x9d\xbc", //"�����",
	/*415*/"\xec\x9d\xbc\xec\x9a\x94\xec\x9d\xbc", //"�Ͽ���",
	/*416*/"College",//BR_RESSTR_WQT5_6_COLLEGE
	/*417*/"New students",
	/*418*/"Graduating students",
	/*419*/"Undergraduate",//BR_RESSTR_WQT5_6_UNDERGRADUATE
	/*420*/"Change",
	/*421*/"\xec\x97\xb0\xed\x9d\xac \xeb\x8c\x80\xed\x95\x99\xea\xb5\x90", //"���� ���б�",
	/*422*/"\xec\x97\x98 \xeb\x8c\x80\xed\x95\x99", //"�� ����",
	/*423*/"\xeb\xa9\x94\xec\x9d\xb4\xed\x94\x8c \xed\x95\x99\xec\x9b\x90", //"������ �п�",
	/*424*/"\xed\x91\xb8\xeb\xa5\xb8 \xeb\x8c\x80\xed\x95\x99", //"Ǫ�� ����",
	/*425*/"\xec\x98\xa4\xed\x81\xac \xec\x97\xb0\xea\xb5\xac\xec\x86\x8c", //"��ũ ������",
	/*426*/"\xec\xa1\xb8\xec\x97\x85", //"����",
	/*427*/"\xec\xb4\x9d\xea\xb3\x84", //"�Ѱ�",
	/*428*/"\xeb\xac\xb8\xec\x9e\x90", //"����",
	/*429*/"\xeb\x8c\x80\xeb\xac\xb8\xec\x9e\x90", //"�빮��",
	/*430*/"\xec\x86\x8c\xeb\xac\xb8\xec\x9e\x90", //"�ҹ���",
	/*431*/"\xec\x95\x8c\xed\x8c\x8c", //"����",
	/*432*/"\xeb\x89\xb4", //"��",
	/*433*/"\xeb\xb2\xa0\xed\x83\x80", //"��Ÿ",
	/*434*/"\xed\x81\xac\xec\x82\xac\xec\x9d\xb4", //"ũ����",
	/*435*/"\xea\xb0\x90\xeb\xa7\x88", //"����",
	/*436*/"\xec\x98\xa4\xeb\xaf\xb8\xed\x81\xac\xeb\xa1\xa0", //"����ũ��",
	/*437*/"\xeb\x8d\xb8\xed\x83\x80", //"��Ÿ",
	/*438*/"\xed\x8c\x8c\xec\x9d\xb4", //"����",
	/*439*/"\xec\x97\xa1\xec\x8b\xa4\xeb\xa1\xa0", //"���Ƿ�",
	/*440*/"\xeb\xa1\x9c", //"��",
	/*441*/"\xec\xa0\x9c\xed\x83\x80", //"��Ÿ",
	/*442*/"\xec\x8b\x9c\xea\xb7\xb8\xeb\xa7\x88", //"�ñ׸�",
	/*443*/"\xec\x97\x90\xed\x83\x80", //"��Ÿ",
	/*444*/"\xed\x83\x80\xec\x9a\xb0", //"Ÿ��",
	/*445*/"\xed\x85\x8c\xed\x83\x80", //"��Ÿ",
	/*446*/"\xec\x9e\x85\xec\x8b\xa4\xeb\xa1\xa0", //"�ԽǷ�",
	/*447*/"\xec\x9d\xb4\xec\x98\xa4\xed\x83\x80", //"�̿�Ÿ",
	/*448*/"\xed\x99\x94\xec\x9d\xb4", //"ȭ��",
	/*449*/"\xec\xb9\xb4\xed\x8c\x8c", //"ī��",
	/*450*/"\xec\xb9\xb4\xec\x9d\xb4", //"ī��",
	/*451*/"\xeb\x9e\x8c\xeb\x8b\xa4", //"����",
	/*452*/"\xed\x94\x84\xec\x82\xac\xec\x9d\xb4", //"������",
	/*453*/"\xeb\xae\xa4", //"��",
	/*454*/"\xec\x98\xa4\xeb\xa9\x94\xea\xb0\x80", //"���ް�",
	/*455*/"\xed\x95\xad\xeb\xaa\xa9", //"�׸�",
	/*456*/"\xeb\xaa\xa8\xec\xa7\x91", //"����",
	/*457*/"\xec\xb1\x85", //"å",
	/*458*/"\xec\x9e\xa1\xec\xa7\x80", //"����",
	/*459*/"\xed\x95\x84\xea\xb8\xb0\xec\x9e\xa5", //"�ʱ���",
	/*460*/"\xec\x88\x98\xec\xb2\xa9", //"��ø",
	/*461*/"\xed\x8e\x9c", //"��",
	/*462*/"\xec\x97\xb0\xed\x95\x84", //"����",
	/*463*/"\xed\x98\x95\xea\xb4\x80\xed\x8e\x9c", //"������",
	/*464*/"\x32\xea\xb0\x80\xec\xa7\x80 \xec\x83\x89", //"2���� ��",
	/*465*/"\x31\xec\x8c\x8d", //"1��",
	/*466*/"\xec\xb1\x85", //"å",
	/*467*/"\xec\x8b\x9c \xeb\x98\x90\xeb\x8a\x94 \xec\x9d\x8d\x2f\xeb\xa9\xb4", //"�� �Ǵ� ��/��",
	/*468*/"\xec\x9a\x94\xec\xa0\x90 \x41", //"���� A",
	/*469*/"\xec\x9a\x94\xec\xa0\x90 \x42", //"���� B",
	/*470*/"\xec\x9a\x94\xec\xa0\x90 \x43", //"���� C",
	/*471*/"\xec\x9a\x94\xec\xa0\x90 \x44", //"���� D",
	/*472*/"\xec\x9a\x94\xec\xa0\x90 \x45", //"���� E",//BR_RESSTR_WQT9_POINT_E
	/*473*/"\xec\xa7\x80\xeb\xb0\xa9\xeb\x8c\x80 \xec\x9e\x85\xed\x95\x99\x2c \x32\x30\x30\x35\xeb\x85\x84\x5c\x6e", //"����� ����, 2005��\n",
	/*474*/"\xec\x9b\x90\xeb\xb3\xb8\x3a \xed\x91\x9c\xec\x8b\x9c\xec\x9a\xa9\xec\x9c\xbc\xeb\xa1\x9c\xeb\xa7\x8c \xec\xa0\x9c\xea\xb3\xb5\xeb\x90\x98\xeb\x8a\x94 \xea\xb0\x80\xec\x83\x81 \xeb\x8d\xb0\xec\x9d\xb4\xed\x84\xb0\x5c\x6e\x5c\x6e", //"����: ǥ�ÿ����θ� �����Ǵ� ���� ������\n\n",
	/*475*/"\xea\xb7\xb8\xeb\xa6\xac\xec\x8a\xa4\xec\x96\xb4 \xec\x95\x8c\xed\x8c\x8c\xeb\xb2\xb3\x5c\x6e", //"�׸����� ���ĺ�\n",
	/*476*/"",//BR_RESSTR_WQT_MAX
	/*477*/"",
	/*478*/"",
	/*479*/"",
	/*480*/"",
	/*481*/"",
	/*482*/"",
	/*483*/"",
	/*484*/"",
	/*485*/"",
	/*486*/"",
	/*487*/"",
	/*488*/"",
	/*489*/"",
	/*490*/"",
	/*491*/"",
	/*492*/"",
	/*493*/"",
	/*494*/"",
	/*495*/"",
	/*496*/"",
	/*497*/"",
	/*498*/"",
	/*499*/"",/*------------Word Quick Table-------------------*/
	//PivotTable 2020-04-28 : bmvinterface.h BrResStringID 22��
	"", "", "", "", "", "", "", "", "", "",
	"", "", "", "", "", "", "", "", "", "",
	"", "",
	//PivotTable
	/*522*/"\xed\x8e\x98\xec\x9d\xb4\xec\xa7\x80 \xeb\x82\x98\xeb\x88\x84\xea\xb8\xb0",  //"������ ������",
	/*523*/"\xeb\x8b\xa8 \xeb\x82\x98\xeb\x88\x84\xea\xb8\xb0",  //"�� ������",
	/*524*/"\xea\xb5\xac\xec\x97\xad \xeb\x82\x98\xeb\x88\x84\xea\xb8\xb0\x28\xeb\x8b\xa4\xec\x9d\x8c \xed\x8e\x98\xec\x9d\xb4\xec\xa7\x80\xeb\xb6\x80\xed\x84\xb0\x29",  //"���� ������(���� ����������)",
	/*525*/"\xea\xb5\xac\xec\x97\xad \xeb\x82\x98\xeb\x88\x84\xea\xb8\xb0\x28\xec\x9d\xb4\xec\x96\xb4\xec\x84\x9c\x29",  //"���� ������(�̾)",
	/*526*/"\xea\xb5\xac\xec\x97\xad \xeb\x82\x98\xeb\x88\x84\xea\xb8\xb0\x28\xeb\x8b\xa4\xec\x9d\x8c \xec\xa7\x9d\xec\x88\x98 \xed\x8e\x98\xec\x9d\xb4\xec\xa7\x80\xeb\xb6\x80\xed\x84\xb0\x29",  //"���� ������(���� ¦�� ����������)",
	/*527*/"\xea\xb5\xac\xec\x97\xad \xeb\x82\x98\xeb\x88\x84\xea\xb8\xb0\x28\xeb\x8b\xa4\xec\x9d\x8c \xed\x99\x80\xec\x88\x98 \xed\x8e\x98\xec\x9d\xb4\xec\xa7\x80\xeb\xb6\x80\xed\x84\xb0\x29",  //"���� ������(���� Ȧ�� ����������)",
	/*528*/"\xea\xb5\xac\xec\x97\xad\xec\x9d\x98 \xeb\x81\x9d",  //"������ ��",
	/*529*/"\xed\x8e\x98\xec\x9d\xb4\xec\xa7\x80 \xec\x8a\xa4\xed\x83\x80\xec\x9d\xbc \xeb\x82\x98\xeb\x88\x84\xea\xb8\xb0",  //"������ ��Ÿ�� ������",
	////hwp chart s//
	"Valid range is from %s to %s",    //  "Valid range is from %s to %s",    //  BR_RESSTR_HWP_CHART_RANGE_ERROR,
	"Invalid value",    //  "Invalid value",    //  BR_RESSTR_HWP_CHART_INVALID_VALUE,
	"Invalid format code '%s' (%d).",    //  "Invalid format code '%s' (%d).",    //  BR_RESSTR_HWP_CHART_INVALID_FORMAT_CODE,
	"Maximum must be greater than minimum.",    //  "Maximum must be greater than minimum.",    //  BR_RESSTR_HWP_CHART_MINMAX_ERROR,
	"Value must not be less than %s",    //  "Value must not be less than %s",    //  BR_RESSTR_HWP_CHART_MIN_ERROR,
	"twips|t",    //  "twips|t",    //  BR_RESSTR_HWP_CHART_INPUT_TWIPS,
	"point|pt|p",    //  "point|pt|p",    //  BR_RESSTR_HWP_CHART_INPUT_POINTS,
	"inch|in|i|",    //  "inch|in|i|",    //  BR_RESSTR_HWP_CHART_INPUT_INCHES,
	"mm|m",    //  "mm|m",    //  BR_RESSTR_HWP_CHART_INPUT_MMS,
	"cm|c",    //  "cm|c",    //  BR_RESSTR_HWP_CHART_INPUT_CMS,
	"deg|d",    //  "deg|d",    //  BR_RESSTR_HWP_CHART_INPUT_DEGREES,
	"rad|r",    //  "rad|r",    //  BR_RESSTR_HWP_CHART_INPUT_RADIANS,
	"gr|g",    //  "gr|g",    //  BR_RESSTR_HWP_CHART_INPUT_GRADS,
	"twips",    //  "twips",    //  BR_RESSTR_HWP_CHART_OUTPUT_TWIPS,
	"pt",    //  "pt",    //  BR_RESSTR_HWP_CHART_OUTPUT_POINTS,
	"in",    //  "in",    //  BR_RESSTR_HWP_CHART_OUTPUT_INCHES,
	"mm",    //  "mm",    //  BR_RESSTR_HWP_CHART_OUTPUT_MMS,
	"cm",    //  "cm",    //  BR_RESSTR_HWP_CHART_OUTPUT_CMS,
	" d",    //  " d",    //  BR_RESSTR_HWP_CHART_OUTPUT_DEGREES,
	" r",    //  " r",    //  BR_RESSTR_HWP_CHART_OUTPUT_RADIANS,
	" g",    //  " g",    //  BR_RESSTR_HWP_CHART_OUTPUT_GRADS,
	"General",    //  "General",    //  BR_RESSTR_HWP_CHART_General,
	"AM",    //  "AM",    //  BR_RESSTR_HWP_CHART_UpperAM,
	"PM",    //  "PM",    //  BR_RESSTR_HWP_CHART_UpperPM,
	"A",    //  "A",    //  BR_RESSTR_HWP_CHART_UpperA,
	"P",    //  "P",    //  BR_RESSTR_HWP_CHART_UpperP,
	"am",    //  "am",    //  BR_RESSTR_HWP_CHART_LowerAM,
	"pm",    //  "pm",    //  BR_RESSTR_HWP_CHART_LowerPM,
	"a",    //  "a",    //  BR_RESSTR_HWP_CHART_LowerA,
	"p",    //  "p",    //  BR_RESSTR_HWP_CHART_LowerP,
	"[Red]",    //  "[Red]",    //  BR_RESSTR_HWP_CHART_NegativeColor,
	"January",    //  "January",    //  BR_RESSTR_HWP_CHART_JANUARY,
	"February",    //  "February",    //  BR_RESSTR_HWP_CHART_FEBRUARY,
	"March",    //  "March",    //  BR_RESSTR_HWP_CHART_MARCH,
	"April",    //  "April",    //  BR_RESSTR_HWP_CHART_APRIL,
	"May",    //  "May",    //  BR_RESSTR_HWP_CHART_MAY,
	"June",    //  "June",    //  BR_RESSTR_HWP_CHART_JUNE,
	"July",    //  "July",    //  BR_RESSTR_HWP_CHART_JULY,
	"August",    //  "August",    //  BR_RESSTR_HWP_CHART_AUGUST,
	"September",    //  "September",    //  BR_RESSTR_HWP_CHART_SEPTEMBER,
	"October",    //  "October",    //  BR_RESSTR_HWP_CHART_OCTOBER,
	"November",    //  "November",    //  BR_RESSTR_HWP_CHART_NOVEMBER,
	"December",    //  "December",    //  BR_RESSTR_HWP_CHART_DECEMBER,
	"Jan",    //  "Jan",    //  BR_RESSTR_HWP_CHART_JANUARY_ABBREVIATION,
	"Feb",    //  "Feb",    //  BR_RESSTR_HWP_CHART_FEBRUARY_ABBREVIATION,
	"Mar",    //  "Mar",    //  BR_RESSTR_HWP_CHART_MARCH_ABBREVIATION,
	"Apr",    //  "Apr",    //  BR_RESSTR_HWP_CHART_APRIL_ABBREVIATION,
	"May",    //  "May",    //  BR_RESSTR_HWP_CHART_MAY_ABBREVIATION,
	"Jun",    //  "Jun",    //  BR_RESSTR_HWP_CHART_JUNE_ABBREVIATION,
	"Jul",    //  "Jul",    //  BR_RESSTR_HWP_CHART_JULY_ABBREVIATION,
	"Aug",    //  "Aug",    //  BR_RESSTR_HWP_CHART_AUGUST_ABBREVIATION,
	"Sep",    //  "Sep",    //  BR_RESSTR_HWP_CHART_SEPTEMBER_ABBREVIATION,
	"Oct",    //  "Oct",    //  BR_RESSTR_HWP_CHART_OCTOBER_ABBREVIATION,
	"Nov",    //  "Nov",    //  BR_RESSTR_HWP_CHART_NOVEMBER_ABBREVIATION,
	"Dec",    //  "Dec",    //  BR_RESSTR_HWP_CHART_DECEMBER_ABBREVIATION,
	"Sunday",    //  "Sunday",    //  BR_RESSTR_HWP_CHART_SUNDAY,
	"Monday",    //  "Monday",    //  BR_RESSTR_HWP_CHART_MONDAY,
	"Tuesday",    //  "Tuesday",    //  BR_RESSTR_HWP_CHART_TUESDAY,
	"Wednesday",    //  "Wednesday",    //  BR_RESSTR_HWP_CHART_WEDNESDAY,
	"Thursday",    //  "Thursday",    //  BR_RESSTR_HWP_CHART_THURSDAY,
	"Friday",    //  "Friday",    //  BR_RESSTR_HWP_CHART_FRIDAY,
	"Saturday",    //  "Saturday",    //  BR_RESSTR_HWP_CHART_SATURDAY,
	"Sun",    //  "Sun",    //  BR_RESSTR_HWP_CHART_SUNDAY_ABBREVIATION,
	"Mon",    //  "Mon",    //  BR_RESSTR_HWP_CHART_MONDAY_ABBREVIATION,
	"Tue",    //  "Tue",    //  BR_RESSTR_HWP_CHART_TUESDAY_ABBREVIATION,
	"Wed",    //  "Wed",    //  BR_RESSTR_HWP_CHART_WEDNESDAY_ABBREVIATION,
	"Thur",    //  "Thur",    //  BR_RESSTR_HWP_CHART_THURSDAY_ABBREVIATION,
	"Fri",    //  "Fri",    //  BR_RESSTR_HWP_CHART_FRIDAY_ABBREVIATION,
	"Sat",    //  "Sat",    //  BR_RESSTR_HWP_CHART_SATURDAY_ABBREVIATION,
	"Sunday",    //  "Sunday",    //  BR_RESSTR_HWP_CHART_ALT_SUNDAY,
	"Monday",    //  "Monday",    //  BR_RESSTR_HWP_CHART_ALT_MONDAY,
	"Tuesday",    //  "Tuesday",    //  BR_RESSTR_HWP_CHART_ALT_TUESDAY,
	"Wednesday",    //  "Wednesday",    //  BR_RESSTR_HWP_CHART_ALT_WEDNESDAY,
	"Thursday",    //  "Thursday",    //  BR_RESSTR_HWP_CHART_ALT_THURSDAY,
	"Friday",    //  "Friday",    //  BR_RESSTR_HWP_CHART_ALT_FRIDAY,
	"Saturday",    //  "Saturday",    //  BR_RESSTR_HWP_CHART_ALT_SATURDAY,
	"Sun",    //  "Sun",    //  BR_RESSTR_HWP_CHART_ALT_SUNDAY_ABBREVIATION,
	"Mon",    //  "Mon",    //  BR_RESSTR_HWP_CHART_ALT_MONDAY_ABBREVIATION,
	"Tue",    //  "Tue",    //  BR_RESSTR_HWP_CHART_ALT_TUESDAY_ABBREVIATION,
	"Wed",    //  "Wed",    //  BR_RESSTR_HWP_CHART_ALT_WEDNESDAY_ABBREVIATION,
	"Thur",    //  "Thur",    //  BR_RESSTR_HWP_CHART_ALT_THURSDAY_ABBREVIATION,
	"Fri",    //  "Fri",    //  BR_RESSTR_HWP_CHART_ALT_FRIDAY_ABBREVIATION,
	"Sat",    //  "Sat",    //  BR_RESSTR_HWP_CHART_ALT_SATURDAY_ABBREVIATION,
	"Su",    //  "Su",    //  BR_RESSTR_HWP_CHART_SUNDAY_HEADING,
	"Mo",    //  "Mo",    //  BR_RESSTR_HWP_CHART_MONDAY_HEADING,
	"Tu",    //  "Tu",    //  BR_RESSTR_HWP_CHART_TUESDAY_HEADING,
	"We",    //  "We",    //  BR_RESSTR_HWP_CHART_WEDNESDAY_HEADING,
	"Th",    //  "Th",    //  BR_RESSTR_HWP_CHART_THURSDAY_HEADING,
	"Fr",    //  "Fr",    //  BR_RESSTR_HWP_CHART_FRIDAY_HEADING,
	"Sa",    //  "Sa",    //  BR_RESSTR_HWP_CHART_SATURDAY_HEADING,
	"mmmm",    //  "mmmm",    //  BR_RESSTR_HWP_CHART_MonthNameFormatCode,
	"mmm",    //  "mmm",    //  BR_RESSTR_HWP_CHART_MonthAbbrFormatCode,
	"mm",    //  "mm",    //  BR_RESSTR_HWP_CHART_MonthNumber2FormatCode,
	"m",    //  "m",    //  BR_RESSTR_HWP_CHART_MonthNumber1FormatCode,
	"dddd",    //  "dddd",    //  BR_RESSTR_HWP_CHART_DayNameFormatCode,
	"ddd",    //  "ddd",    //  BR_RESSTR_HWP_CHART_DayAbbrFormatCode,
	"dd",    //  "dd",    //  BR_RESSTR_HWP_CHART_DayNumber2FormatCode,
	"d",    //  "d",    //  BR_RESSTR_HWP_CHART_DayNumber1FormatCode,
	"WW",    //  "WW",    //  BR_RESSTR_HWP_CHART_AltDayNameFormatCode,
	"W",    //  "W",    //  BR_RESSTR_HWP_CHART_AltDayAbbrFormatCode,
	"yyyy",    //  "yyyy",    //  BR_RESSTR_HWP_CHART_YearNumber4FormatCode,
	"yy",    //  "yy",    //  BR_RESSTR_HWP_CHART_YearNumber2FormatCode,
	"hh",    //  "hh",    //  BR_RESSTR_HWP_CHART_HourNumber2FormatCode,
	"h",    //  "h",    //  BR_RESSTR_HWP_CHART_HourNumber1FormatCode,
	"mm",    //  "mm",    //  BR_RESSTR_HWP_CHART_MinuteNumber2FormatCode,
	"m",    //  "m",    //  BR_RESSTR_HWP_CHART_MinuteNumber1FormatCode,
	"ss",    //  "ss",    //  BR_RESSTR_HWP_CHART_SecondNumber2FormatCode,
	"s",    //  "s",    //  BR_RESSTR_HWP_CHART_SecondNumber1FormatCode,
	"AM/PM",    //  "AM/PM",    //  BR_RESSTR_HWP_CHART_UpperAmpmFormatCode,
	"A/P",    //  "A/P",    //  BR_RESSTR_HWP_CHART_UpperApFormatCode,
	"am/pm",    //  "am/pm",    //  BR_RESSTR_HWP_CHART_LowerAmpmFormatCode,
	"a/p",    //  "a/p",    //  BR_RESSTR_HWP_CHART_LowerApFormatCode,
	"Black",    //  "Black",    //  BR_RESSTR_HWP_CHART_Black,
	"Blue",    //  "Blue",    //  BR_RESSTR_HWP_CHART_Blue,
	"Cyan",    //  "Cyan",    //  BR_RESSTR_HWP_CHART_Cyan,
	"Green",    //  "Green",    //  BR_RESSTR_HWP_CHART_Green,
	"Magenta",    //  "Magenta",    //  BR_RESSTR_HWP_CHART_Magenta,
	"Red",    //  "Red",    //  BR_RESSTR_HWP_CHART_Red,
	"White",    //  "White",    //  BR_RESSTR_HWP_CHART_White,
	"Yellow",    //  "Yellow",    //  BR_RESSTR_HWP_CHART_Yellow,
	"Color",    //  "Color",    //  BR_RESSTR_HWP_CHART_Color,
	"\xed\x95\xa8\xec\xb4\x88\xeb\xa1\xac\xeb\x8f\x8b\xec\x9b\x80", //"���ʷҵ���",    //  "���ʷҵ���",    //  BR_RESSTR_HWP_CHART_DEFAULT_FONT_NAME,
	"R%d",    //  "R%d",    //  BR_RESSTR_HWP_CHART_ROWLABELFORMAT,
	"Item%d",    //  "Item%d",    //  BR_RESSTR_HWP_CHART_ROWLABELFORMAT_LTS,
	"C%d",    //  "C%d",    //  BR_RESSTR_HWP_CHART_COLLABELFORMAT,
	"Q%d",    //  "Q%d",    //  BR_RESSTR_HWP_CHART_COLLABELFORMAT_LTS,
	"<=",    //  "<=",    //  BR_RESSTR_HWP_CHART_LessEqualFormatOp,
	">=",    //  ">=",    //  BR_RESSTR_HWP_CHART_GreaterEqualFormatOp,
	"<>",    //  "<>",    //  BR_RESSTR_HWP_CHART_NotEqualFormatOp,
	"<",    //  "<",    //  BR_RESSTR_HWP_CHART_LessFormatOp,
	"=",    //  "=",    //  BR_RESSTR_HWP_CHART_EqualFormatOp,
	">",    //  ">",    //  BR_RESSTR_HWP_CHART_GreaterFormatOp,
	"0",    //  "0",    //  BR_RESSTR_HWP_CHART_DigitFormatCode,
	"#",    //  "#",    //  BR_RESSTR_HWP_CHART_DigitIfNeededFormatCode,
	"?",    //  "?",    //  BR_RESSTR_HWP_CHART_DigitOrSpaceFormatCode,
	"%",    //  "%",    //  BR_RESSTR_HWP_CHART_PercentFormatCode,
	"/",    //  "/",    //  BR_RESSTR_HWP_CHART_FractionFormatCode,
	"\\",    //  "\\",    //  BR_RESSTR_HWP_CHART_LiteralFormatCode,
	"\"\"",    //  "\"\"",    //  BR_RESSTR_HWP_CHART_StringFormatCode,
	"@",    //  "@",    //  BR_RESSTR_HWP_CHART_TextFormatCode,
	"*",    //  "*",    //  BR_RESSTR_HWP_CHART_FillFormatCode,
	"_",    //  "_",    //  BR_RESSTR_HWP_CHART_SpaceFormatCode,
	"[",    //  "[",    //  BR_RESSTR_HWP_CHART_LBracketFormatCode,
	"]",    //  "]",    //  BR_RESSTR_HWP_CHART_RBracketFormatCode,
	"+",    //  "+",    //  BR_RESSTR_HWP_CHART_UPlusFormatCode,
	"-",    //  "-",    //  BR_RESSTR_HWP_CHART_UMinusFormatCode,
	" _-\"\"",    //  " _-\"\"",    //  BR_RESSTR_HWP_CHART_LocalFormatSymbols,
	"ggg",    //  "ggg",    //  BR_RESSTR_HWP_CHART_EraName3FormatCode,
	"gg",    //  "gg",    //  BR_RESSTR_HWP_CHART_EraName2FormatCode,
	"g",    //  "g",    //  BR_RESSTR_HWP_CHART_EraName1FormatCode,
	"ee",    //  "ee",    //  BR_RESSTR_HWP_CHART_EraYear2FormatCode,
	"e",    //  "e",    //  BR_RESSTR_HWP_CHART_EraYear1FormatCode,
	";",    //  ";",    //  BR_RESSTR_HWP_CHART_ERA_LONG_NAMES,
	";",    //  ";",    //  BR_RESSTR_HWP_CHART_ERA_SHORT_NAMES,
	";",    //  ";",    //  BR_RESSTR_HWP_CHART_ERA_DATES,
	"Start",    //  "Start",    //  BR_RESSTR_HWP_CHART_VALTYPE_START,
	"String",    //  "String",    //  BR_RESSTR_HWP_CHART_VALTYPE_STRING,
	"Short Integer",    //  "Short Integer",    //  BR_RESSTR_HWP_CHART_VALTYPE_SHORT,
	"Long Integer",    //  "Long Integer",    //  BR_RESSTR_HWP_CHART_VALTYPE_LONG,
	"Numeric",    //  "Numeric",    //  BR_RESSTR_HWP_CHART_VALTYPE_DECIMAL,
	"Short Float",    //  "Short Float",    //  BR_RESSTR_HWP_CHART_VALTYPE_FLOAT,
	"Long Float",    //  "Long Float",    //  BR_RESSTR_HWP_CHART_VALTYPE_DOUBLE,
	"Date",    //  "Date",    //  BR_RESSTR_HWP_CHART_VALTYPE_DATE,
	"Time",    //  "Time",    //  BR_RESSTR_HWP_CHART_VALTYPE_TIME,
	"Time Stamp",    //  "Time Stamp",    //  BR_RESSTR_HWP_CHART_VALTYPE_DATETIME,
	"Picture",    //  "Picture",    //  BR_RESSTR_HWP_CHART_VALTYPE_PICTURE,
	"Binary",    //  "Binary",    //  BR_RESSTR_HWP_CHART_VALTYPE_BYTES,
	"Unspecified",    //  "Unspecified",    //  BR_RESSTR_HWP_CHART_VALTYPE_ANY,
	"End",    //  "End",    //  BR_RESSTR_HWP_CHART_VALTYPE_END,
	"E",    //  "E",    //  BR_RESSTR_HWP_CHART_UpperExponent,
	"e",    //  "e",    //  BR_RESSTR_HWP_CHART_LowerExponent,
	"Error : %s",    //  "Error : %s",    //  BR_RESSTR_HWP_CHART_ERROR_FORMAT,
	"NxCh",    //  "NxCh",    //  BR_RESSTR_HWP_CHART_SERVERBASENAME,
	"<embedded>",    //  "<embedded>",    //  BR_RESSTR_HWP_CHART_FROM_EMBEDDED,
	"%s %d",    //  "%s %d",    //  BR_RESSTR_HWP_CHART_EMBEDDED_NAME_FORMAT,
	"",    //  "",    //  BR_RESSTR_HWP_CHART_FORMATS_START,
	"\xec\x9d\xbc\xeb\xb0\x98", //"�Ϲ�",    //  "General",    //  BR_RESSTR_HWP_CHART_GENERAL_FORMATS,
	" \xec\x9d\xbc\xeb\xb0\x98", //" �Ϲ�",    //  " General",    //  BR_RESSTR_HWP_CHART_GENERAL_FORMAT1,
	"End",    //  "End",    //  BR_RESSTR_HWP_CHART_GENERAL_FORMATS_END,
	"\xec\x88\xab\xec\x9e\x90", //"����",    //  "Number",    //  BR_RESSTR_HWP_CHART_NUMBER_FORMATS,
	"N0",    //  "N0",    //  BR_RESSTR_HWP_CHART_NUMBER_FORMAT1,
	"N0.00",    //  "N0.00",    //  BR_RESSTR_HWP_CHART_NUMBER_FORMAT2,
	"N#,##0",    //  "N#,    //  BR_RESSTR_HWP_CHART_NUMBER_FORMAT3,
	"N#,##0.00",    //  "N#,    //  BR_RESSTR_HWP_CHART_NUMBER_FORMAT4,
	"N#,##0;(#,##0)",    //  "N#,    //  BR_RESSTR_HWP_CHART_NUMBER_FORMAT5,
	"N#,##0.00;(#,##0.00)",    //  "N#,    //  BR_RESSTR_HWP_CHART_NUMBER_FORMAT6,
	"N#,##0;[Red](#,##0)",    //  "N#,    //  BR_RESSTR_HWP_CHART_NUMBER_FORMAT7,
	"N#,##0.00;[Red](#,##0.00)",    //  "N#,    //  BR_RESSTR_HWP_CHART_NUMBER_FORMAT8,
	"End",    //  "End",    //  BR_RESSTR_HWP_CHART_NUMBER_FORMATS_END,
	"\xed\x86\xb5\xed\x99\x94", //"��ȭ",    //  "Currency",    //  BR_RESSTR_HWP_CHART_CURRENCY_FORMATS,
	" SystemCurrencyFormats",    //  " SystemCurrencyFormats",    //  BR_RESSTR_HWP_CHART_CURRENCY_FORMAT1,
	"End",    //  "End",    //  BR_RESSTR_HWP_CHART_CURRENCY_FORMATS_END,
	"\xeb\x82\xa0\xec\xa7\x9c", //"��¥",    //  "Date",    //  BR_RESSTR_HWP_CHART_DATE_FORMATS,
	" ShortSystemDateFormat",    //  " ShortSystemDateFormat",    //  BR_RESSTR_HWP_CHART_DATE_FORMAT1,
	" LongSystemDateFormat",    //  " LongSystemDateFormat",    //  BR_RESSTR_HWP_CHART_DATE_FORMAT2,
	"Dd-mmm-yy",    //  "Dd-mmm-yy",    //  BR_RESSTR_HWP_CHART_DATE_FORMAT3,
	"Dd-mmm",    //  "Dd-mmm",    //  BR_RESSTR_HWP_CHART_DATE_FORMAT4,
	"Dmmm-yy",    //  "Dmmm-yy",    //  BR_RESSTR_HWP_CHART_DATE_FORMAT5,
	"End",    //  "End",    //  BR_RESSTR_HWP_CHART_DATE_FORMATS_END,
	"\xec\x8b\x9c\xea\xb0\x84", //"�ð�",    //  "Time",    //  BR_RESSTR_HWP_CHART_TIME_FORMATS,
	" SystemTimeFormat",    //  " SystemTimeFormat",    //  BR_RESSTR_HWP_CHART_TIME_FORMAT1,
	" SystemTimeWithSecondsFormat",    //  " SystemTimeWithSecondsFormat",    //  BR_RESSTR_HWP_CHART_TIME_FORMAT2,
	"Thh:mm AM/PM",    //  "Thh:mm AM/PM",    //  BR_RESSTR_HWP_CHART_TIME_FORMAT3,
	"Thh:mm:ss AM/PM",    //  "Thh:mm:ss AM/PM",    //  BR_RESSTR_HWP_CHART_TIME_FORMAT4,
	"Thh:mm",    //  "Thh:mm",    //  BR_RESSTR_HWP_CHART_TIME_FORMAT5,
	"Thh:mm:ss",    //  "Thh:mm:ss",    //  BR_RESSTR_HWP_CHART_TIME_FORMAT6,
	"Tmm:ss",    //  "Tmm:ss",    //  BR_RESSTR_HWP_CHART_TIME_FORMAT7,
	"T[h]:mm:ss",    //  "T[h]:mm:ss",    //  BR_RESSTR_HWP_CHART_TIME_FORMAT8,
	" SystemDateTimeFormat",    //  " SystemDateTimeFormat",    //  BR_RESSTR_HWP_CHART_TIME_FORMAT9,
	"End",    //  "End",    //  BR_RESSTR_HWP_CHART_TIME_FORMATS_END,
	"\xeb\xb0\xb1\xeb\xb6\x84\xec\x9c\xa8", //"�����",    //  "Percentage",    //  BR_RESSTR_HWP_CHART_PERCENTAGE_FORMATS,
	"N0%",    //  "N0%",    //  BR_RESSTR_HWP_CHART_PERCENTAGE_FORMAT1,
	"N0.0%",    //  "N0.0%",    //  BR_RESSTR_HWP_CHART_PERCENTAGE_FORMAT2,
	"N0.00%",    //  "N0.00%",    //  BR_RESSTR_HWP_CHART_PERCENTAGE_FORMAT3,
	"End",    //  "End",    //  BR_RESSTR_HWP_CHART_PERCENTAGE_FORMATS_END,
	"\xeb\xb6\x84\xec\x88\x98", //"�м�",    //  "Fraction",    //  BR_RESSTR_HWP_CHART_FRACTION_FORMATS,
	"N# ?/?",    //  "N# ?/?",    //  BR_RESSTR_HWP_CHART_FRACTION_FORMAT1,
	"N# ?/??",    //  "N# ?/??",    //  BR_RESSTR_HWP_CHART_FRACTION_FORMAT2,
	"End",    //  "End",    //  BR_RESSTR_HWP_CHART_FRACTION_FORMATS_END,
	"\xea\xb3\xbc\xed\x95\x99", //"����",    //  "Scientific",    //  BR_RESSTR_HWP_CHART_SCIENTIFIC_FORMATS,
	"N0.00E+00",    //  "N0.00E+00",    //  BR_RESSTR_HWP_CHART_SCIENTIFIC_FORMAT1,
	"N##0.0E+0",    //  "N##0.0E+0",    //  BR_RESSTR_HWP_CHART_SCIENTIFIC_FORMAT2,
	"End",    //  "End",    //  BR_RESSTR_HWP_CHART_SCIENTIFIC_FORMATS_END,
	"",    //  "",    //  BR_RESSTR_HWP_CHART_FORMATS_END,
	"Bool",    //  "Bool",    //  BR_RESSTR_HWP_CHART_BOOLEAN_FORMATS,
	"B\\T;\\T;\\F",    //  "B\\T;\\T;\\F",    //  BR_RESSTR_HWP_CHART_BOOLEAN_FORMAT1,
	"B\"\"True\"\";\"\"True\"\";\"\"False\"\"",    //  "B\"\"True\"\";\"\"True\"\";\"\"False\"\"",    //  BR_RESSTR_HWP_CHART_BOOLEAN_FORMAT2,
	"B\\Y;\\Y;\\N",    //  "B\\Y;\\Y;\\N",    //  BR_RESSTR_HWP_CHART_BOOLEAN_FORMAT3,
	"B\"\"Yes\"\";\"\"Yes\"\";\"\"No\"\"",    //  "B\"\"Yes\"\";\"\"Yes\"\";\"\"No\"\"",    //  BR_RESSTR_HWP_CHART_BOOLEAN_FORMAT4,
	"End",    //  "End",    //  BR_RESSTR_HWP_CHART_BOOLEAN_FORMATS_END,
	"\xea\xb3\x84\xec\x97\xb4\x25\x64", //"�迭%d",    //  "Series%d",    //  BR_RESSTR_HWP_CHART_DEFAULT_SERIES_NAME,
	"\xeb\x8d\xb0\xec\x9d\xb4\xed\x84\xb0\xed\x8f\xac\xec\x9d\xb8\xed\x8a\xb8\x25\x64", //"����������Ʈ%d",    //  "Datapoint%d",    //  BR_RESSTR_HWP_CHART_DEFAULT_DATAPOINT_NAME,
	"\xed\x95\xad\xeb\xaa\xa9 \x28\x25\x73\x29 \xec\xb6\x95", //"�׸� (%s) ��",    //  "Category (%s) Axis",    //  BR_RESSTR_HWP_CHART_CATEGORY_AXIS_NAME,
	"\xea\xb0\x92 \x28\x25\x73\x29 \xec\xb6\x95", //"�� (%s) ��",    //  "Value (%s) Axis",    //  BR_RESSTR_HWP_CHART_VALUE_AXIS_NAME,
	"\xeb\x82\xa0\xec\xa7\x9c \x28\x25\x73\x29 \xec\xb6\x95", //"��¥ (%s) ��",    //  "Date (%s) Axis",    //  BR_RESSTR_HWP_CHART_DATE_AXIS_NAME,
	"\xea\xb0\x81\xeb\x8f\x84 \xec\xb6\x95", //"���� ��",    //  "Angle Axis",    //  BR_RESSTR_HWP_CHART_POLAR_AXIS_NAME,
	"\xeb\xb0\xa9\xec\x82\xac\xed\x98\x95 \xec\xb6\x95", //"����� ��",    //  "Radar Axis",    //  BR_RESSTR_HWP_CHART_RADAR_AXIS_NAME,
	"X",    //  "X",    //  BR_RESSTR_HWP_CHART_X_AXIS_ID,
	"Y",    //  "Y",    //  BR_RESSTR_HWP_CHART_Y_AXIS_ID,
	"\x32\xec\xb0\xa8 \x59", //"2�� Y",    //  "2nd Y",    //  BR_RESSTR_HWP_CHART_Y2_AXIS_ID,
	"Z",    //  "Z",    //  BR_RESSTR_HWP_CHART_Z_AXIS_ID,
	"0.0%",    //  "0.0%",    //  BR_RESSTR_HWP_CHART_PERCENT_FORMAT,
	"m/d",    //  "m/d",    //  BR_RESSTR_HWP_CHART_WEEK_FORMAT,
	"mmm",    //  "mmm",    //  BR_RESSTR_HWP_CHART_MONTH_FORMAT,
	"yyyy",    //  "yyyy",    //  BR_RESSTR_HWP_CHART_YEAR_FORMAT,
	"\x58 \xec\xb6\x95", //"X ��",    //  "X Axis",    //  BR_RESSTR_HWP_CHART_X_AXIS_NAME,
	"\x59 \xec\xb6\x95", //"Y ��",    //  "Y Axis",    //  BR_RESSTR_HWP_CHART_Y_AXIS_NAME,
	"\x32\xec\xb0\xa8 \x59 \xec\xb6\x95", //"2�� Y ��",    //  "Secondary Y Axis",    //  BR_RESSTR_HWP_CHART_Y2_AXIS_NAME,
	"\x5a \xec\xb6\x95", //"Z ��",    //  "Z Axis",    //  BR_RESSTR_HWP_CHART_Z_AXIS_NAME,
	"\x58 \xec\xb6\x95 \xec\xa0\x9c\xeb\xaa\xa9", //"X �� ����",    //  "X Axis Title",    //  BR_RESSTR_HWP_CHART_DEFAULT_XAXIS_TITLE,
	"\x59 \xec\xb6\x95 \xec\xa0\x9c\xeb\xaa\xa9", //"Y �� ����",    //  "Y Axis Title",    //  BR_RESSTR_HWP_CHART_DEFAULT_YAXIS_TITLE,
	"\x5a \xec\xb6\x95 \xec\xa0\x9c\xeb\xaa\xa9", //"Z �� ����",    //  "Z Axis Title",    //  BR_RESSTR_HWP_CHART_DEFAULT_ZAXIS_TITLE,
	"\x32\xec\xb0\xa8 \x59 \xec\xb6\x95 \xec\xa0\x9c\xeb\xaa\xa9", //"2�� Y �� ����",    //  "Secondary Y Axis Title",    //  BR_RESSTR_HWP_CHART_DEFAULT_Y2AXIS_TITLE,
	"\xec\xb0\xa8\xed\x8a\xb8\xeb\xa5\xbc \xea\xb7\xb8\xeb\xa6\xb4 \xec\x88\x98 \xec\x97\x86\xec\x8a\xb5\xeb\x8b\x88\xeb\x8b\xa4\x2e", //"��Ʈ�� �׸� �� �����ϴ�.",    //  "The requested chart cannot be drawn.",    //  BR_RESSTR_HWP_CHART_CANNOT_DRAW,
	"\xeb\x8d\xb0\xec\x9d\xb4\xed\x84\xb0\xea\xb0\x80 \xec\xb6\xa9\xeb\xb6\x84\xed\x95\x98\xec\xa7\x80 \xec\x95\x8a\xec\x8a\xb5\xeb\x8b\x88\xeb\x8b\xa4\x2e", //"�����Ͱ� ������� �ʽ��ϴ�.",    //  "Not Enough Data",    //  BR_RESSTR_HWP_CHART_INSUFFICIENT_DATA,
	"\xec\xb0\xa8\xed\x8a\xb8 \xec\xa0\x9c\xeb\xaa\xa9", //"��Ʈ ����",    //  "Chart Title",    //  BR_RESSTR_HWP_CHART_DEFAULT_TITLE,
	"\xea\xb0\x81\xec\xa3\xbc", //"����",    //  "Footnote",    //  BR_RESSTR_HWP_CHART_DEFAULT_FOOTNOTE,
	"h:mm AM/PM",    //  "h:mm AM/PM",    //  BR_RESSTR_HWP_CHART_HOUR_FORMAT,
	"mm:ss",    //  "mm:ss",    //  BR_RESSTR_HWP_CHART_MINUTE_FORMAT,
	"ss.00",    //  "ss.00",    //  BR_RESSTR_HWP_CHART_SECOND_FORMAT,
	"Y %d",    //  "Y %d",    //  BR_RESSTR_HWP_CHART_MULTIY_AXIS_ID,
	"\x32\xec\xb0\xa8 \x59 \x25\x64", //"2�� Y %d",    //  "2nd Y %d",    //  BR_RESSTR_HWP_CHART_MULTIY2_AXIS_ID,
	"",    //  "",    //  BR_RESSTR_HWP_CHART_ROTATE,
	"Created by v%s",    //  "Created by v%s",    //  BR_RESSTR_HWP_CHART_METAFILE_HEADER,
	"",    //  "",    //  BR_RESSTR_HWP_CHART_VTCH_HELP,
	"",    //  "",    //  BR_RESSTR_HWP_CHART_ALL_VTC,
	"",    //  "",    //  BR_RESSTR_HWP_CHART_VTC_EXTENSION,
	"",    //  "",    //  BR_RESSTR_HWP_CHART_BMP_EXTENSION,
	"",    //  "",    //  BR_RESSTR_HWP_CHART_WMF_EXTENSION,
	"",    //  "",    //  BR_RESSTR_HWP_CHART_LTSCH_HLP_FILE_USER,
	"\xea\xb0\x80\xeb\xa1\x9c \xea\xb0\x92 \xec\xb6\x95", //"���� �� ��",    //  "Horizontal Value Axis",    //  BR_RESSTR_HWP_CHART_AXIS_X1,
	"\xea\xb0\x80\xeb\xa1\x9c \xed\x95\xad\xeb\xaa\xa9 \xec\xb6\x95", //"���� �׸� ��",    //  "Horizontal Category Axis",    //  BR_RESSTR_HWP_CHART_AXIS_X2,
	"\xec\x84\xb8\xeb\xa1\x9c \xea\xb0\x92 \xec\xb6\x95", //"���� �� ��",    //  "Vertical Value Axis",    //  BR_RESSTR_HWP_CHART_AXIS_Y1,
	"\xec\x84\xb8\xeb\xa1\x9c \xed\x95\xad\xeb\xaa\xa9 \xec\xb6\x95", //"���� �׸� ��",    //  "Vertical Category Axis",    //  BR_RESSTR_HWP_CHART_AXIS_Y2,
	"\x32\xec\xb0\xa8 \xec\x84\xb8\xeb\xa1\x9c \xea\xb0\x92 \xec\xb6\x95", //"2�� ���� �� ��",    //  "Secondary Vertical Value Axis",    //  BR_RESSTR_HWP_CHART_AXIS_2Y1,
	"\x32\xec\xb0\xa8 \xec\x84\xb8\xeb\xa1\x9c \xed\x95\xad\xeb\xaa\xa9 \xec\xb6\x95", //"2�� ���� �׸� ��",    //  "Secondary Vertical Category Axis",    //  BR_RESSTR_HWP_CHART_AXIS_2Y2,
	"\xea\xb9\x8a\xec\x9d\xb4 \xec\xb6\x95", //"���� ��",    //  "Depth Axis",    //  BR_RESSTR_HWP_CHART_AXIS_Z,
	"\xea\xb8\xb0\xeb\xb3\xb8", //"�⺻",    //  "Default",    //  BR_RESSTR_HWP_CHART_FORMAT_GENERALS,
	"\xea\xb8\xb0\xeb\xb3\xb8", //"�⺻",    //  "Default",    //  BR_RESSTR_HWP_CHART_FORMAT_GENERAL1,
	"\xec\x88\xab\xec\x9e\x90", //"����",    //  "Number",    //  BR_RESSTR_HWP_CHART_FORMAT_NUMBERS,
	"0",    //  "0",    //  BR_RESSTR_HWP_CHART_FORMAT_NUMBER1,
	"0.00",    //  "0.00",    //  BR_RESSTR_HWP_CHART_FORMAT_NUMBER2,
	"#,##0",    //  "#,    //  BR_RESSTR_HWP_CHART_FORMAT_NUMBER3,
	"#,##0.00",    //  "#,    //  BR_RESSTR_HWP_CHART_FORMAT_NUMBER4,
	"#,##0;(#,##0)",    //  "#,    //  BR_RESSTR_HWP_CHART_FORMAT_NUMBER5,
	"#,##0.00;(#,##0.00)",    //  "#,    //  BR_RESSTR_HWP_CHART_FORMAT_NUMBER6,
	"#,##0;[Red](#,##0)",    //  "#,    //  BR_RESSTR_HWP_CHART_FORMAT_NUMBER7,
	"#,##0.00;[Red](#,##0.00)",    //  "#,    //  BR_RESSTR_HWP_CHART_FORMAT_NUMBER8,
	"\xed\x99\x94\xed\x8f\x90", //"ȭ��",    //  "Currency",    //  BR_RESSTR_HWP_CHART_FORMAT_CURRENCYS,
	"SystemCurrencyFormats",    //  "SystemCurrencyFormats",    //  BR_RESSTR_HWP_CHART_FORMAT_CURRENCY1,
	"\xeb\x82\xa0\xec\xa7\x9c", //"��¥",    //  "Date",    //  BR_RESSTR_HWP_CHART_FORMAT_DATES,
	"ShortSystemDateFormat",    //  "ShortSystemDateFormat",    //  BR_RESSTR_HWP_CHART_FORMAT_DATE1,
	"LongSystemDateFormat",    //  "LongSystemDateFormat",    //  BR_RESSTR_HWP_CHART_FORMAT_DATE2,
	"d-mmm-yy",    //  "d-mmm-yy",    //  BR_RESSTR_HWP_CHART_FORMAT_DATE3,
	"d-mmm",    //  "d-mmm",    //  BR_RESSTR_HWP_CHART_FORMAT_DATE4,
	"mmm-yy",    //  "mmm-yy",    //  BR_RESSTR_HWP_CHART_FORMAT_DATE5,
	"\xec\x8b\x9c\xea\xb0\x84", //"�ð�",    //  "Time",    //  BR_RESSTR_HWP_CHART_FORMAT_TIMES,
	"SystemTimeFormat",    //  "SystemTimeFormat",    //  BR_RESSTR_HWP_CHART_FORMAT_TIME1,
	"SystemTimeWithSecondsFormat",    //  "SystemTimeWithSecondsFormat",    //  BR_RESSTR_HWP_CHART_FORMAT_TIME2,
	"\x68\x68\x3a\x6d\x6d \xec\x98\xa4\xec\xa0\x84\x2f\xec\x98\xa4\xed\x9b\x84", //"hh:mm ����/����",    //  "hh:mm AM/PM",    //  BR_RESSTR_HWP_CHART_FORMAT_TIME3,
	"\x68\x68\x3a\x6d\x6d\x3a\x73\x73 \xec\x98\xa4\xec\xa0\x84\x2f\xec\x98\xa4\xed\x9b\x84", //"hh:mm:ss ����/����",    //  "hh:mm:ss AM/PM",    //  BR_RESSTR_HWP_CHART_FORMAT_TIME4,
	"hh:mm",    //  "hh:mm",    //  BR_RESSTR_HWP_CHART_FORMAT_TIME5,
	"hh:mm:ss",    //  "hh:mm:ss",    //  BR_RESSTR_HWP_CHART_FORMAT_TIME6,
	"mm:ss",    //  "mm:ss",    //  BR_RESSTR_HWP_CHART_FORMAT_TIME7,
	"[h]:mm:ss",    //  "h:mm:ss",    //  BR_RESSTR_HWP_CHART_FORMAT_TIME8,
	"SystemDateTimeFormat",    //  "SystemDateTimeFormat",    //  BR_RESSTR_HWP_CHART_FORMAT_TIME9,
	"\xeb\xb0\xb1\xeb\xb6\x84\xec\x9c\xa8", //"�����",    //  "Percentage",    //  BR_RESSTR_HWP_CHART_FORMAT_PERCENTS,
	"0%",    //  "0%",    //  BR_RESSTR_HWP_CHART_FORMAT_PERCENT1,
	"0.0%",    //  "0.0%",    //  BR_RESSTR_HWP_CHART_FORMAT_PERCENT2,
	"0.00%",    //  "0.00%",    //  BR_RESSTR_HWP_CHART_FORMAT_PERCENT3,
	"\xeb\xb9\x84\xec\x9c\xa8", //"����",    //  "Ratio",    //  BR_RESSTR_HWP_CHART_FORMAT_FRACTIONS,
	"# ?/?",    //  "# ?/?",    //  BR_RESSTR_HWP_CHART_FORMAT_FRACTION1,
	"# ?/??",    //  "# ?/??",    //  BR_RESSTR_HWP_CHART_FORMAT_FRACTION2,
	"\xea\xb3\xbc\xed\x95\x99\xec\x8b\x9d\xed\x91\x9c\xea\xb8\xb0", //"���н�ǥ��",    //  "Scientific Notation",    //  BR_RESSTR_HWP_CHART_FORMAT_SCIENTIFICS,
	"0.00E+00",    //  "0.00E+00",    //  BR_RESSTR_HWP_CHART_FORMAT_SCIENTIFIC1,
	"##0.0E+0",    //  "##0.0E+0",    //  BR_RESSTR_HWP_CHART_FORMAT_SCIENTIFIC2,
	"\xeb\xac\xb8\xec\x9e\x90", //"����",    //  "Text",    //  BR_RESSTR_HWP_CHART_FORMAT_TEXTS,
	"@",    //  "@",    //  BR_RESSTR_HWP_CHART_FORMAT_TEXT1,
	"\xeb\xaa\xa8\xeb\x93\xa0 \xea\xb3\x84\xec\x97\xb4", //"��� �迭",    //  "All Series",    //  BR_RESSTR_HWP_CHART_CHART_ALL_SERIES,
	"\xec\x84\xb8\xeb\xa1\x9c \xeb\xa7\x89\xeb\x8c\x80\xed\x98\x95", //"���� ������",    //  "Vertical Bar",    //  BR_RESSTR_HWP_CHART_CHTYPE_BAR,
	"\xea\xba\xbe\xec\x9d\x80\xec\x84\xa0\xed\x98\x95", //"��������",    //  "Line",    //  BR_RESSTR_HWP_CHART_CHTYPE_LINE,
	"\xec\x98\x81\xec\x97\xad\xed\x98\x95", //"������",    //  "Area",    //  BR_RESSTR_HWP_CHART_CHTYPE_AREA,
	"\xeb\x8b\xa8\xea\xb3\x84\xed\x98\x95", //"�ܰ���",    //  "Step",    //  BR_RESSTR_HWP_CHART_CHTYPE_STEP,
	"\xed\x98\xbc\xed\x95\xa9\xed\x98\x95", //"ȥ����",    //  "Combination",    //  BR_RESSTR_HWP_CHART_CHTYPE_COMBO,
	"\xea\xb0\x80\xeb\xa1\x9c \xeb\xa7\x89\xeb\x8c\x80\xed\x98\x95", //"���� ������",    //  "Horizontal Bar",    //  BR_RESSTR_HWP_CHART_CHTYPE_HORIZONTAL_BAR,
	"\xec\x9b\x90\xed\x98\x95", //"����",    //  "Pie",    //  BR_RESSTR_HWP_CHART_CHTYPE_PIE,
	"\xeb\x8f\x84\xeb\x84\x9b\xed\x98\x95", //"������",    //  "Doughnut",    //  BR_RESSTR_HWP_CHART_CHTYPE_DONUT,
	"\xeb\xb6\x84\xec\x82\xb0\xed\x98\x95", //"�л���",    //  "Scatter",    //  BR_RESSTR_HWP_CHART_CHTYPE_XY,
	"\xea\xb7\xb9\xec\xa2\x8c\xed\x91\x9c\xed\x98\x95", //"����ǥ��",    //  "Polar Coordinates",    //  BR_RESSTR_HWP_CHART_CHTYPE_POLAR,
	"\xeb\xb0\xa9\xec\x82\xac\xed\x98\x95", //"�����",    //  "Radar",    //  BR_RESSTR_HWP_CHART_CHTYPE_RADAR,
	"\xed\x92\x8d\xec\x84\xa0\xed\x98\x95", //"ǳ����",    //  "Bubble",    //  BR_RESSTR_HWP_CHART_CHTYPE_BUBBLE,
	"\xeb\xac\xb6\xec\x9d\x80 \xeb\xa7\x89\xeb\x8c\x80\xed\x98\x95", //"���� ������",    //  "Clustered Bar",    //  BR_RESSTR_HWP_CHART_CHTYPE_ZCLUSTERED_BAR,
	"\xec\xa3\xbc\xec\x8b\x9d\xed\x98\x95", //"�ֽ���",    //  "Stock",    //  BR_RESSTR_HWP_CHART_CHTYPE_HILO,
	"\xea\xb3\x84\xeb\x8b\xa8\xed\x98\x95", //"�����",    //  "Gantt",    //  BR_RESSTR_HWP_CHART_CHTYPE_GANTT,
	"\xeb\x93\xb1\xea\xb3\xa0\xec\x84\xa0\xed\x98\x95", //"�������",    //  "Contour",    //  BR_RESSTR_HWP_CHART_CHTYPE_CONTOUR,
	"\xed\x91\x9c\xeb\xa9\xb4\xed\x98\x95", //"ǥ����",    //  "Surface",    //  BR_RESSTR_HWP_CHART_CHTYPE_SURFACE,
	"\xed\x9d\xa9\xeb\xbf\x8c\xeb\xa6\xac\xea\xb8\xb0", //"��Ѹ���",    //  "Scatter",    //  BR_RESSTR_HWP_CHART_CHTYPE_SCATTER,
	"\xeb\xa7\x89\xeb\x8c\x80", //"����",    //  "Bar",    //  BR_RESSTR_HWP_CHART_CHMETHOD_BAR,
	"\xea\xb0\x80\xeb\xa1\x9c \xeb\xa7\x89\xeb\x8c\x80", //"���� ����",    //  "Horizontal Bar",    //  BR_RESSTR_HWP_CHART_CHMETHOD_HORIZONTAL_BAR,
	"\xea\xba\xbe\xec\x9d\x80\xec\x84\xa0", //"������",    //  "Line",    //  BR_RESSTR_HWP_CHART_CHMETHOD_LINE,
	"\xec\x98\x81\xec\x97\xad", //"����",    //  "Area",    //  BR_RESSTR_HWP_CHART_CHMETHOD_AREA,
	"\xeb\x8b\xa8\xea\xb3\x84", //"�ܰ�",    //  "Step",    //  BR_RESSTR_HWP_CHART_CHMETHOD_STEP,
	"\xeb\xb6\x84\xec\x82\xb0", //"�л�",    //  "Variance",    //  BR_RESSTR_HWP_CHART_CHMETHOD_XY,
	"\xed\x98\xbc\xed\x95\xa9 \xeb\xb0\xa9\xec\x82\xac", //"ȥ�� ���",    //  "Radar Combination",    //  BR_RESSTR_HWP_CHART_CHMETHOD_POLAR,
	"\xec\x84\xa0\x28\xeb\xb0\xa9\xec\x82\xac\xed\x98\x95\x29", //"��(�����)",    //  "Line (Radar)",    //  BR_RESSTR_HWP_CHART_CHMETHOD_RADAR_LINE,
	"\xec\x98\x81\xec\x97\xad\x28\xeb\xb0\xa9\xec\x82\xac\xed\x98\x95\x29", //"����(�����)",    //  "Area (Radar)",    //  BR_RESSTR_HWP_CHART_CHMETHOD_RADAR_AREA,
	"\xed\x92\x8d\xec\x84\xa0", //"ǳ��",    //  "Bubble",    //  BR_RESSTR_HWP_CHART_CHMETHOD_BUBBLE,
	"\xec\x9b\x90", //"��",    //  "Pie",    //  BR_RESSTR_HWP_CHART_CHMETHOD_PIE,
	"\xeb\x8f\x84\xeb\x84\x9b", //"����",    //  "Doughnut",    //  BR_RESSTR_HWP_CHART_CHMETHOD_DONUT,
	"\xeb\x88\x84\xec\xa0\x81 \xeb\xa7\x89\xeb\x8c\x80", //"���� ����",    //  "Stacked Bar",    //  BR_RESSTR_HWP_CHART_CHMETHOD_ZCLUSTERED_BAR,
	"\xec\xa3\xbc\xec\x8b\x9d\xed\x98\x95\x28\xea\xb8\xb0\xeb\xb3\xb8\x29", //"�ֽ���(�⺻)",    //  "Stock (Basic)",    //  BR_RESSTR_HWP_CHART_CHMETHOD_HILO,
	"\xec\xa3\xbc\xec\x8b\x9d\xed\x98\x95\x28\xec\x8b\xad\xec\x9e\x90\x29", //"�ֽ���(����)",    //  "Stock (Cross)",    //  BR_RESSTR_HWP_CHART_CHMETHOD_HLC,
	"\xec\xa3\xbc\xec\x8b\x9d\xed\x98\x95\x28\xed\x98\xbc\xed\x95\xa9\x29", //"�ֽ���(ȥ��)",    //  "Stock (Mixed)",    //  BR_RESSTR_HWP_CHART_CHMETHOD_OHLC,
	"\xec\xa3\xbc\xec\x8b\x9d\xed\x98\x95\x28\xeb\xa7\x89\xeb\x8c\x80\x29", //"�ֽ���(����)",    //  "Stock (Bar)",    //  BR_RESSTR_HWP_CHART_CHMETHOD_OHLC_BAR,
	"\xec\xa3\xbc\xec\x8b\x9d\xed\x98\x95\x28\xea\xba\xbe\xec\x9d\xb8\xec\x84\xa0\x29", //"�ֽ���(���μ�)",    //  "Stock (Line)",    //  BR_RESSTR_HWP_CHART_CHMETHOD_HLC_RIGHT,
	"\xea\xb3\x84\xeb\x8b\xa8 \xeb\xa7\x89\xeb\x8c\x80", //"��� ����",    //  "Gantt Bar",    //  BR_RESSTR_HWP_CHART_CHMETHOD_GANTT,
	"\xeb\x82\xa0\xec\xa7\x9c", //"��¥",    //  "Date",    //  BR_RESSTR_HWP_CHART_CHMETHOD_DATES,
	"\xeb\x93\xb1\xea\xb3\xa0\xec\x84\xa0 \xec\xb0\xa8", //"����� ��",    //  "Contour Difference",    //  BR_RESSTR_HWP_CHART_CHMETHOD_CONTOUR,
	"\xed\x91\x9c\xeb\xa9\xb4", //"ǥ��",    //  "Surface",    //  BR_RESSTR_HWP_CHART_CHMETHOD_SURFACE,
	"\xec\xa3\xbc\xec\x8b\x9d \xeb\xa7\x89\xeb\x8c\x80", //"�ֽ� ����",    //  "Hi Lo Bar",    //  BR_RESSTR_HWP_CHART_CHMETHOD_BARHILO,
	"\xec\xa3\xbc\xec\x8b\x9d \xea\xb0\x80\xeb\xa1\x9c \xeb\xa7\x89\xeb\x8c\x80", //"�ֽ� ���� ����",    //  "Hi Lo Horizontal Bar",    //  BR_RESSTR_HWP_CHART_CHMETHOD_HORIZONTAL_BARHILO,
	"\xec\xa3\xbc\xec\x8b\x9d \xeb\x88\x84\xec\xa0\x81 \xeb\xa7\x89\xeb\x8c\x80", //"�ֽ� ���� ����",    //  "Hi Lo Stacked Bar",    //  BR_RESSTR_HWP_CHART_CHMETHOD_ZCLUSTERED_BARHILO,
	"\x3c\xeb\x88\x84\xec\xa0\x81\x3e", //"<����>",    //  "<Stacked>",    //  BR_RESSTR_HWP_CHART_CHART_ORDER_STACK,
	"\x25\x67 \xea\xb9\x8c\xec\xa7\x80", //"%g ����",    //  "To %g",    //  BR_RESSTR_HWP_CHART_GRADIENT_MAX_FORMATS,
	"\x25\x67 \xeb\xb6\x80\xed\x84\xb0", //"%g ����",    //  "From %g",    //  BR_RESSTR_HWP_CHART_GRADIENT_MIN_FORMATS,
	"\x25\x67 \xec\x9d\xb4\xec\x83\x81", //"%g �̻�",    //  "Over %g",    //  BR_RESSTR_HWP_CHART_CONTOUR_MAX_FORMATS,
	"%g",    //  "%g",    //  BR_RESSTR_HWP_CHART_CONTOUR_VALUE_FORMATS,
	"\x32\xec\xb0\xa8\xec\x9b\x90 \xec\x98\x81\xec\x97\xad\xed\x98\x95", //"2���� ������",    //  "2-D Area",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_2D_1,
	"\x32\xec\xb0\xa8\xec\x9b\x90 \xec\x84\xb8\xeb\xa1\x9c \xeb\xa7\x89\xeb\x8c\x80\xed\x98\x95", //"2���� ���� ������",    //  "2-D Vertical Bar",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_2D_2,
	"\x32\xec\xb0\xa8\xec\x9b\x90 \xea\xba\xbe\xec\x9d\x80\xec\x84\xa0\xed\x98\x95", //"2���� ��������",    //  "2-D Line",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_2D_3,
	"\x32\xec\xb0\xa8\xec\x9b\x90 \xeb\x8b\xa8\xea\xb3\x84\xed\x98\x95", //"2���� �ܰ���",    //  "2-D Step",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_2D_4,
	"\x32\xec\xb0\xa8\xec\x9b\x90 \xed\x98\xbc\xed\x95\xa9\xed\x98\x95", //"2���� ȥ����",    //  "2-D Combination",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_2D_5,
	"\x32\xec\xb0\xa8\xec\x9b\x90 \xec\x9b\x90\xed\x98\x95", //"2���� ����",    //  "2-D Pie",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_2D_6,
	"\x32\xec\xb0\xa8\xec\x9b\x90 \xea\xb0\x80\xeb\xa1\x9c \xeb\xa7\x89\xeb\x8c\x80\xed\x98\x95", //"2���� ���� ������",    //  "2-D Horizontal Bar",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_2D_7,
	"\x32\xec\xb0\xa8\xec\x9b\x90 \xec\xa3\xbc\xec\x8b\x9d\xed\x98\x95", //"2���� �ֽ���",    //  "2-D Stock",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_2D_8,
	"\x32\xec\xb0\xa8\xec\x9b\x90 \xea\xb3\x84\xeb\x8b\xa8\xed\x98\x95", //"2���� �����",    //  "2-D Gantt",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_2D_9,
	"\x32\xec\xb0\xa8\xec\x9b\x90 \xed\x92\x8d\xec\x84\xa0\xed\x98\x95", //"2���� ǳ����",    //  "2-D Bubble",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_2D_10,
	"\x32\xec\xb0\xa8\xec\x9b\x90 \xeb\x93\xb1\xea\xb3\xa0\xec\x84\xa0\xed\x98\x95", //"2���� �������",    //  "2-D Contour",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_2D_11,
	"\x32\xec\xb0\xa8\xec\x9b\x90 \xeb\xb6\x84\xec\x82\xb0\xed\x98\x95", //"2���� �л���",    //  "2-D Scatter",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_2D_12,
	"\x32\xec\xb0\xa8\xec\x9b\x90 \xed\x98\xbc\xed\x95\xa9 \xeb\xb0\xa9\xec\x82\xac\xed\x98\x95", //"2���� ȥ�� �����",    //  "2-D Radar Combination",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_2D_13,
	"\x32\xec\xb0\xa8\xec\x9b\x90 \xeb\xb0\xa9\xec\x82\xac\xed\x98\x95", //"2���� �����",    //  "2-D Radar",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_2D_14,
	"\x33\xec\xb0\xa8\xec\x9b\x90 \xec\x98\x81\xec\x97\xad\xed\x98\x95", //"3���� ������",    //  "3-D Area",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_3D_1,
	"\x33\xec\xb0\xa8\xec\x9b\x90 \xec\x84\xb8\xeb\xa1\x9c \xeb\xa7\x89\xeb\x8c\x80\xed\x98\x95", //"3���� ���� ������",    //  "3-D Vertical Bar",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_3D_2,
	"\x33\xec\xb0\xa8\xec\x9b\x90 \xea\xba\xbe\xec\x9d\x80\xec\x84\xa0\xed\x98\x95", //"3���� ��������",    //  "3-D Line",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_3D_3,
	"\x33\xec\xb0\xa8\xec\x9b\x90 \xeb\x8b\xa8\xea\xb3\x84\xed\x98\x95", //"3���� �ܰ���",    //  "3-D Step",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_3D_4,
	"\x33\xec\xb0\xa8\xec\x9b\x90 \xed\x98\xbc\xed\x95\xa9\xed\x98\x95", //"3���� ȥ����",    //  "3-D Combination",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_3D_5,
	"\x33\xec\xb0\xa8\xec\x9b\x90 \xec\x9b\x90\xed\x98\x95", //"3���� ����",    //  "3-D Pie",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_3D_6,
	"\x33\xec\xb0\xa8\xec\x9b\x90 \xea\xb0\x80\xeb\xa1\x9c \xeb\xa7\x89\xeb\x8c\x80\xed\x98\x95", //"3���� ���� ������",    //  "3-D Horizontal Bar",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_3D_7,
	"\x33\xec\xb0\xa8\xec\x9b\x90 \xeb\x88\x84\xec\xa0\x81 \xeb\xa7\x89\xeb\x8c\x80\xed\x98\x95", //"3���� ���� ������",    //  "3-D Stacked Bar",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_3D_8,
	"\x33\xec\xb0\xa8\xec\x9b\x90 \xea\xb3\x84\xeb\x8b\xa8\xed\x98\x95", //"3���� �����",    //  "3-D Gantt",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_3D_9,
	"\x33\xec\xb0\xa8\xec\x9b\x90 \xeb\x8f\x84\xeb\x84\x9b\xed\x98\x95", //"3���� ������",    //  "3-D Doughnut",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_3D_10,
	"\x33\xec\xb0\xa8\xec\x9b\x90 \xed\x91\x9c\xeb\xa9\xb4\xed\x98\x95", //"3���� ǥ����",    //  "3-D Surface",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_3D_11,
	"\x33\xec\xb0\xa8\xec\x9b\x90 \xeb\xb6\x84\xec\x82\xb0\xed\x98\x95", //"3���� �л���",    //  "3-D Scatter",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_3D_12,
	"\xec\x98\x81\xec\x97\xad\xed\x98\x95", //"������",    //  "Area",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_2D_1_1,
	"\xec\x84\xb8\xeb\xa1\x9c \xeb\xa7\x89\xeb\x8c\x80\xed\x98\x95", //"���� ������",    //  "Vertical Bar",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_2D_2_1,
	"\xea\xba\xbe\xec\x9d\x80\xec\x84\xa0\xed\x98\x95", //"��������",    //  "Line",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_2D_3_1,
	"\xeb\x8b\xa8\xea\xb3\x84\xed\x98\x95", //"�ܰ���",    //  "Step",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_2D_4_1,
	"\xed\x98\xbc\xed\x95\xa9\xed\x98\x95", //"ȥ����",    //  "Combination",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_2D_5_1,
	"\xec\x9b\x90\xed\x98\x95", //"����",    //  "Pie",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_2D_6_1,
	"\xea\xb0\x80\xeb\xa1\x9c \xeb\xa7\x89\xeb\x8c\x80\xed\x98\x95", //"���� ������",    //  "Horizontal Bar",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_2D_7_1,
	"\xec\xa3\xbc\xec\x8b\x9d\xed\x98\x95", //"�ֽ���",    //  "Stock",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_2D_8_1,
	"\xea\xb3\x84\xeb\x8b\xa8\xed\x98\x95", //"�����",    //  "Gantt",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_2D_9_1,
	"\xed\x92\x8d\xec\x84\xa0\xed\x98\x95", //"ǳ����",    //  "Bubble",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_2D_10_1,
	"\xeb\x93\xb1\xea\xb3\xa0\xec\x84\xa0\xed\x98\x95", //"�������",    //  "Contour",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_2D_11_1,
	"\xeb\xb6\x84\xec\x82\xb0\xed\x98\x95", //"�л���",    //  "Scatter",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_2D_12_1,
	"\xed\x98\xbc\xed\x95\xa9 \xeb\xb0\xa9\xec\x82\xac\xed\x98\x95", //"ȥ�� �����",    //  "Radar Combination",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_2D_13_1,
	"\xeb\xb0\xa9\xec\x82\xac\xed\x98\x95", //"�����",    //  "Radar",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_2D_14_1,
	"\xeb\x8f\x84\xeb\x84\x9b\xed\x98\x95", //"������",    //  "Doughnut",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_3D_10_1,
	"\xed\x91\x9c\xeb\xa9\xb4\xed\x98\x95", //"ǥ����",    //  "Surface",    //  BR_RESSTR_HWP_CHART_WIZARD_GALLERY_3D_11_1,
	"\x33\xec\xb0\xa8\xec\x9b\x90 \xec\xaa\xbc\xea\xb0\x9c\xec\xa7\x84 \xec\x9b\x90\xed\x98\x95", //"3���� �ɰ��� ����",    //  "3-D Broken Pie",    //  BR_RESSTR_HWP_CHART_CUSTOM_CHARTTYPE01,
	"\xeb\xa1\x9c\xea\xb7\xb8 \xeb\x8b\xa8\xec\x9c\x84 \xea\xba\xbe\xec\x9d\x80\xec\x84\xa0\xed\x98\x95", //"�α� ���� ��������",    //  "Log Unit Line",    //  BR_RESSTR_HWP_CHART_CUSTOM_CHARTTYPE02,
	"\xeb\xb6\x80\xeb\x93\x9c\xeb\x9f\xac\xec\x9a\xb4 \xea\xba\xbe\xec\x9d\x80\xec\x84\xa0\xed\x98\x95", //"�ε巯�� ��������",    //  "Smoothed Line",    //  BR_RESSTR_HWP_CHART_CUSTOM_CHARTTYPE03,
	"\xeb\xb8\x94\xeb\x9f\xad \xec\x98\x81\xec\x97\xad\xed\x98\x95", //"���� ������",    //  "Block Area",    //  BR_RESSTR_HWP_CHART_CUSTOM_CHARTTYPE04,
	"\xec\x9b\x90\xeb\xbf\x94\xed\x98\x95", //"������",    //  "Horn",    //  BR_RESSTR_HWP_CHART_CUSTOM_CHARTTYPE05,
	"\xec\x9d\xb4\xec\xa4\x91 \xec\xb6\x95 \xed\x98\xbc\xed\x95\xa9\xed\x98\x95", //"���� �� ȥ����",    //  "vtDouble Axis Combination",    //  BR_RESSTR_HWP_CHART_CUSTOM_CHARTTYPE06,
	"\xec\xbb\xac\xeb\x9f\xac \xeb\x88\x84\xec\xa0\x81 \xeb\xa7\x89\xeb\x8c\x80\xed\x98\x95", //"�÷� ���� ������",    //  "Colored Stacked Bar",    //  BR_RESSTR_HWP_CHART_CUSTOM_CHARTTYPE07,
	"\xec\x9b\x90\xed\x98\x95", //"����",    //  "Pie",    //  BR_RESSTR_HWP_CHART_CUSTOM_CHARTTYPE08,
	"\xed\x98\xbc\xed\x95\xa9\xed\x98\x95\x5b\xea\xba\xbe\xec\x9d\x80\xec\x84\xa0\x2d\xec\x84\xb8\xeb\xa1\x9c\xeb\xa7\x89\xeb\x8c\x80\x5d", //"ȥ����[������-���θ���]",    //  "Combination Line-Vertical Bar",    //  BR_RESSTR_HWP_CHART_CUSTOM_CHARTTYPE09,
	"\xed\x98\xbc\xed\x95\xa9\xed\x98\x95\x5b\xec\x84\xb8\xeb\xa1\x9c\xeb\xa7\x89\xeb\x8c\x80\x2d\xec\x98\x81\xec\x97\xad\x5d", //"ȥ����[���θ���-����]",    //  "Combination Vertical Bar-Area",    //  BR_RESSTR_HWP_CHART_CUSTOM_CHARTTYPE10,
	"\x33\xec\xb0\xa8\xec\x9b\x90 \xed\x98\xbc\xed\x95\xa9\xed\x98\x95\x5b\xea\xba\xbe\xec\x9d\x80\xec\x84\xa0\x2d\xec\x84\xb8\xeb\xa1\x9c\xeb\xa7\x89\xeb\x8c\x80\x5d", //"3���� ȥ����[������-���θ���]",    //  "3-D Combination Line-Vertical Bar",    //  BR_RESSTR_HWP_CHART_CUSTOM_CHARTTYPE11,
	"\xed\x95\xad\xeb\xaa\xa9\x25\x64", //"�׸�%d",    //  no matching,    //  BR_RESSTR_HWP_CHART_DEFAULT_ITEM_NAME,
	//hwp chart e//

	//sheet ���� �м�-�հ�
	"\xed\x95\xa9\xea\xb3\x84", //"�հ�",
	"\xed\x8f\x89\xea\xb7\xa0", //"���",
	"\xea\xb0\x9c\xec\x88\x98", //"����",
	"\xec\xb4\x9d \x25", //"�� %",
	"\xeb\x88\x84\xea\xb3\x84", //"����",
};

extern PoError getErrorCode()
{
	PoError nErrorCode = kPoProcessSucess;
	if (poBwp_GetErrorCode(nErrorCode))
		return nErrorCode;
	return g_BoraThreadAtom.m_nErrorCode;
}

extern BrBOOL setErrorCode(PoError nErrorCode, char *pFileName, BrINT nLine, const char *pComment)
{
	PoError nDocErrorCode = kPoProcessSucess;
	if (poBwp_GetErrorCode(nDocErrorCode) && kPoProcessSucess == nDocErrorCode)
		poBwp_SetErrorCode(nErrorCode);
	SetThreadAtomError(nErrorCode);

	if (nErrorCode != kPoProcessSucess)
		SetErrorInfoList(nErrorCode, pFileName, nLine, NULL, pComment, false);

	BTrace("ErrorCode[0x%x] %s[%d] %s", nErrorCode, pFileName, nLine, pComment?pComment:"");
	
	return BrFALSE;
}

extern BrBOOL setCRCErrorCode(PoError nErrorCode, char *pFileName, BrINT nLine, const char *pComment)
{
	if (nErrorCode != kPoErrZIPCRC) //if not kinds of CRC error, just skip
		return BrFALSE;

	SetErrorInfoList(nErrorCode, pFileName, nLine, NULL, pComment, false);

	if(pComment)
		BTrace("%s[%d] %s", pFileName, nLine, pComment);
	else
		BTrace("%s[%d]", pFileName, nLine);

	return BrTRUE;
}

#include "../Error/ErrorHandle.h"
#include "../Error/CFilterErrorObj.h"

extern void SendEditErrorCode(ErrorObject *pError)
{
	SendBoraEditWarningCode(g_pBInterfaceHandle->m_pUIPROCESS_CBFUNC, pError);
}
/*
*	@author 	Andrew
*	@date  	2017.11.21
*	@brief  	������ ����Ʈ�� �����Ѵ�.
*/
extern void SaveErrorInfoList(BoraErrorResult* errorInfo)
{
	if ( g_pBInterfaceHandle->m_pErrorInfoList )
	{
		errorInfo->nErrorObejctListCount = g_pBInterfaceHandle->m_pErrorInfoList->size();
		errorInfo->pErrorObejctList = (ErrorObject**)calloc(errorInfo->nErrorObejctListCount, sizeof(ErrorObject*));
		errorInfo->nPOErrorValue = g_BoraThreadAtom.m_nErrorCode;
		for (int n=0;n<errorInfo->nErrorObejctListCount;n++)
		{
			errorInfo->pErrorObejctList[n] = g_pBInterfaceHandle->m_pErrorInfoList->at(n);			
			if ( errorInfo->nSystemIOError == 0 &&
				errorInfo->pErrorObejctList[n]->m_nFileIOError != 0 )
			{
				errorInfo->nSystemIOError = errorInfo->pErrorObejctList[n]->m_nFileIOError;
				errorInfo->nPOErrorValue = errorInfo->pErrorObejctList[n]->m_nPoErrorValue;
			}
		}		
	}
}

/*
*	@author 	Andrew
*	@date  	2016.11.02
*	@brief  	������ ����Ʈ�� �ʱ�ȭ�Ѵ�.
*/
extern void ClearErrorInfoList(BoraErrorResult* errorInfo)
{
	if ( errorInfo && errorInfo->pErrorObejctList )
		free(errorInfo->pErrorObejctList);

	if ( g_pBInterfaceHandle->m_pErrorInfoList )
	{
		for (int n=0;n<g_pBInterfaceHandle->m_pErrorInfoList->size();n++)
		{
			ErrorObject* pItem = g_pBInterfaceHandle->m_pErrorInfoList->at(n);
			//BrSysClloc���� �����Ͽ� BrSysFree�� ����
			BrSysFree(pItem->m_pMessage);
			BrSysFree(pItem->m_pFile);
			BrSysFree(pItem);
		}
		BR_SAFE_DELETE(g_pBInterfaceHandle->m_pErrorInfoList);
	}
}

#ifdef _WIN32
#include <windows.h>
#include <string>
#include <sstream>
#include <vector>
#include <Psapi.h>
#include <algorithm>
#include <iterator>

#pragma comment(lib, "psapi.lib")
#pragma comment(lib, "dbghelp.lib")

// Some versions of imagehlp.dll lack the proper packing directives themselves
// so we need to do it.
#pragma pack( push, before_imagehlp, 8 )
#include <imagehlp.h>
#pragma pack( pop, before_imagehlp )

struct module_data {
    std::string image_name;
    std::string module_name;
    void *base_address;
    DWORD load_size;
};

class symbol { 
    typedef IMAGEHLP_SYMBOL64 sym_type;
    sym_type *sym;
    static const int max_name_len = 1024;

public:
    symbol(HANDLE process, DWORD64 address) : sym((sym_type *)::operator new(sizeof(*sym) + max_name_len)) {
        memset(sym, '\0', sizeof(*sym) + max_name_len);
        sym->SizeOfStruct = sizeof(*sym);
        sym->MaxNameLength = max_name_len;
        DWORD64 displacement;

        SymGetSymFromAddr64(process, address, &displacement, sym);
    }

    std::string name() { return std::string(sym->Name); }
    std::string undecorated_name() { 
        if (*sym->Name == '\0')
            return "<couldn't map PC to fn name>";
        std::vector<char> und_name(max_name_len);
        UnDecorateSymbolName(sym->Name, &und_name[0], max_name_len, UNDNAME_COMPLETE);
        return std::string(&und_name[0], strlen(&und_name[0]));
    }
};

class get_mod_info {
    HANDLE process;
    static const int buffer_length = 4096;
public:
    get_mod_info(HANDLE h) : process(h) {}

    module_data operator()(HMODULE module) { 
        module_data ret;
        char temp[buffer_length];
        MODULEINFO mi;

        GetModuleInformation(process, module, &mi, sizeof(mi));
        ret.base_address = mi.lpBaseOfDll;
        ret.load_size = mi.SizeOfImage;

        GetModuleFileNameEx(process, module, temp, sizeof(temp));
        ret.image_name = temp;
        GetModuleBaseName(process, module, temp, sizeof(temp));
        ret.module_name = temp;
        std::vector<char> img(ret.image_name.begin(), ret.image_name.end());
        std::vector<char> mod(ret.module_name.begin(), ret.module_name.end());
        SymLoadModule64(process, 0, &img[0], &mod[0], (DWORD64)ret.base_address, ret.load_size);
        return ret;
    }
};

// if you use C++ exception handling: install a translator function
// with set_se_translator(). In the context of that function (but *not*
// afterwards), you can either do your stack dump, or save the CONTEXT
// record as a local copy. Note that you must do the stack dump at the
// earliest opportunity, to avoid the interesting stack-frames being gone
// by the time you do the dump.
char* DumpStackTrace()
{
	char* szMsg = BrNULL;
	CONTEXT             context;
	RtlCaptureContext( &context );

    HANDLE process = GetCurrentProcess();
    HANDLE hThread = GetCurrentThread();
    int frame_number=0;
    DWORD offset_from_symbol=0;
    IMAGEHLP_LINE64 line = {0};
    std::vector<module_data> modules;
    DWORD cbNeeded;
    std::vector<HMODULE> module_handles(1);

    // Load the symbols:
    // WARNING: You'll need to replace <pdb-search-path> with either NULL
    // or some folder where your clients will be able to find the .pdb file.
    if (!SymInitialize(process, NULL, false)) 
	{
		//YourMessage("Crash", "Unable to initialize symbol handler.\n\n");
  //      throw(std::logic_error("Unable to initialize symbol handler"));
		return BrNULL;
	}
    DWORD symOptions = SymGetOptions();
    symOptions |= SYMOPT_LOAD_LINES | SYMOPT_UNDNAME;
    SymSetOptions(symOptions);
    EnumProcessModules(process, &module_handles[0], module_handles.size() * sizeof(HMODULE), &cbNeeded);
    module_handles.resize(cbNeeded/sizeof(HMODULE));
    EnumProcessModules(process, &module_handles[0], module_handles.size() * sizeof(HMODULE), &cbNeeded);
    std::transform(module_handles.begin(), module_handles.end(), std::back_inserter(modules), get_mod_info(process));
	void *base = NULL;
	std::ostringstream module_names;
	for (int n=0;n<modules.size();n++)
	{
		module_names << modules[n].module_name << "\n";
		if ( !strcmp((const char*)modules[n].module_name.c_str(), "EngineDLL.dll") )
		{
			base = modules[n].base_address;
			break;
		}
	}
	if (!base)
		base = modules[0].base_address;

    // Setup stuff:
#ifdef _M_X64
    STACKFRAME64 frame;
    frame.AddrPC.Offset = context.Rip;
    frame.AddrPC.Mode = AddrModeFlat;
    frame.AddrStack.Offset = context.Rsp;
    frame.AddrStack.Mode = AddrModeFlat;    
    frame.AddrFrame.Offset = context.Rbp;
    frame.AddrFrame.Mode = AddrModeFlat;
#else
    STACKFRAME64 frame;
    frame.AddrPC.Offset = context.Eip;
    frame.AddrPC.Mode = AddrModeFlat;
    frame.AddrStack.Offset = context.Esp;
    frame.AddrStack.Mode = AddrModeFlat;    
    frame.AddrFrame.Offset = context.Ebp;
    frame.AddrFrame.Mode = AddrModeFlat;
#endif
    line.SizeOfStruct = sizeof line;
    IMAGE_NT_HEADERS *h = ImageNtHeader(base);
    DWORD image_type = h->FileHeader.Machine;
    int n = 0;

    // Build the string:
    //std::ostringstream builder;
	//builder << "base address:" << base <<"\n";
	std::string fnMsg;
	char pLines[8] = { 0, };
    do {
        if ( frame.AddrPC.Offset != 0 ) 
		{
            std::string fnName = symbol(process, frame.AddrPC.Offset).undecorated_name();			
            //builder << fnName;
			if (SymGetLineFromAddr64(process, frame.AddrPC.Offset, &offset_from_symbol, &line))
			{				
				sprintf_s(pLines, sizeof(pLines), "%d", line.LineNumber);
				fnName += ";";
				fnName += line.FileName;
				fnName += ";";
				fnName += pLines;
				fnName += ";";
				fnName += "\n";//[2021/02/17] Terminate log enter ����. ��ġ ���� ���� �κ��� ���� break������ ���� �־��µ�, ���� ������ ������Ź�帳�ϴ�.
				//builder << "  " /*<< line.FileName*/ << "(" << line.LineNumber << "), offset:" << frame.AddrPC.Offset << "\n";
			}
			else
			{
				fnName += ";unknown;-1;";
				//builder << ", offset:" << frame.AddrPC.Offset << "\n";
			}			
			fnMsg += fnName;
            if (fnName == "main")
                break;
            if (fnName == "RaiseException") {
                // This is what we get when compiled in Release mode:
                //YourMessage("Crash", "Your program has crashed.\n\n");
                return szMsg;
            }
        }
		else
		{
			//builder << "(No Symbols: PC == 0)";
		}
        if (!StackWalk64(image_type, process, hThread, &frame, &context, NULL, 
                            SymFunctionTableAccess64, SymGetModuleBase64, NULL))
            break;
        if (++n > 10)
            break;
    } while (frame.AddrReturn.Offset != 0);
    SymCleanup(process);

	int nLen = fnMsg.size();
	szMsg = (char*)BrSysCalloc(nLen + 1, sizeof(char));
	strcpy_s(szMsg, nLen+1, fnMsg.c_str());

    return szMsg;
}

UINT WriteMiniDumpFile()
{
	//Andrew 
	BOOL bUploadCrashDump = FALSE;
	if (bUploadCrashDump)
	{
		BOOL bMiniDumpSuccessful;
		HANDLE hDumpFile;
		MINIDUMP_EXCEPTION_INFORMATION ExpParam;

		HANDLE hProcess = GetCurrentProcess();
		DWORD dProcessId = GetCurrentProcessId();
		DWORD dThreadId = GetCurrentThreadId();
		
		char szFileName[1024] = { 0, };
		_snprintf_s(szFileName, sizeof(szFileName), sizeof(szFileName)-1, "%s/DUMP_%08x.dmp", (char*)BrGetTempPath(), BrGetTickCount());

		BString strDumpPath = CUtil::UTF8ToBString((BrCHAR*)szFileName); // temp folder path
		
		hDumpFile = CreateFileW((LPCWSTR)strDumpPath.unicode(), GENERIC_READ | GENERIC_WRITE,
			FILE_SHARE_WRITE | FILE_SHARE_READ, 0, CREATE_ALWAYS, 0, 0);

		ExpParam.ThreadId = dThreadId;
		ExpParam.ExceptionPointers = NULL;
		ExpParam.ClientPointers = FALSE;

		bMiniDumpSuccessful = MiniDumpWriteDump(hProcess, dProcessId,
			hDumpFile, MiniDumpNormal, &ExpParam, NULL, NULL);
			
		CloseHandle(hDumpFile);
		if (bMiniDumpSuccessful && BFile::Exist(strDumpPath))
			SendBaseResultCallback(-1, Bora_create_dump_file, 0, g_pBInterfaceHandle->m_pUIPROCESS_CBFUNC, (void*)szFileName, 1);
	}

	return TRUE;
}

char* printStack(const char* pMsg)
{	
	char* pDumpMsg = DumpStackTrace();
	WriteMiniDumpFile();
	return pDumpMsg;
}
#elif 0

#include "DbgHelp.h"
#include <WinBase.h>
#pragma comment(lib, "Dbghelp.lib")

/*
*	@author Andrew
*	@date  	2016.11.18
*	@return char* : ���� ����
*	@brief  ���� ȣ�� ���� ������ �о�´�.
*	@ref	http://stackoverflow.com/questions/590160/how-to-log-stack-frames-with-windows-x64
*/
char* printStack(const char* pMsg)
{
	int nMsgLen = 0;
	if ( pMsg )
		nMsgLen = strlen(pMsg);
	char *szMsg = BrNULL;
	typedef USHORT (WINAPI *CaptureStackBackTraceType)(__in ULONG, __in ULONG, __out PVOID*, __out_opt PULONG);
	HINSTANCE hDll = LoadLibrary(("kernel32.dll"));
	if ( hDll )
	{
		CaptureStackBackTraceType func = (CaptureStackBackTraceType)(GetProcAddress(hDll, "RtlCaptureStackBackTrace"));	
		if(func != NULL)
		{
			// Quote from Microsoft Documentation:
			// ## Windows Server 2003 and Windows XP:  
			// ## The sum of the FramesToSkip and FramesToCapture parameters must be less than 63.
			const int kMaxCallers = 62; 

			void         * callers_stack[ kMaxCallers ];
			unsigned short frames = 0;
			SYMBOL_INFO  * symbol;
			HANDLE         process;
			process = GetCurrentProcess();
			SymInitialize( process, NULL, TRUE );
			frames               = (func)( 0, kMaxCallers, callers_stack, NULL );
			if ( frames )
			{
				symbol               = ( SYMBOL_INFO * )BrSysCalloc( sizeof( SYMBOL_INFO ) + 256 * sizeof( char ), 1 );
				if (!symbol)//alloc�� �ȵǴٸ� heap�� ���� ���� ���̻� ������ �Ұ�
				{
					FreeLibrary(hDll);
					return BrNULL;
				}
				symbol->MaxNameLen   = 255;
				symbol->SizeOfStruct = sizeof( SYMBOL_INFO );

				//�������� ������ ����
				const unsigned short  MAX_CALLERS_SHOWN = 8;
				frames = frames < MAX_CALLERS_SHOWN? frames : MAX_CALLERS_SHOWN;
				DWORD displacement = 0;
				IMAGEHLP_LINE line;
				line.SizeOfStruct = sizeof(IMAGEHLP_LINE);
				int nBufferSize = frames * 1024 + nMsgLen;
				szMsg = (char*)BrSysCalloc(nBufferSize, sizeof(char));
				if ( szMsg )
				{
					char *pTmp = (char*)BrSysCalloc(1024, sizeof(char));
					if (pTmp)
					{
						BOOL ret = FALSE;
						for (unsigned int i = 2; i < frames; i++)
						{
							SymFromAddr(process, (DWORD64)(callers_stack[i]), 0, symbol);
							ret = SymGetLineFromAddr(process, (DWORD64)(callers_stack[i]), &displacement, &line);
							if (ret)
							{
#if defined (STB2018_ErrorCode) && !defined (WIN32)
								//#ifdef STB2018_ErrorCode
								char* pos = strrchr(line.FileName, '\\');
								if (pos != nullptr)
									line.FileName = pos;  //���� �̸��� ���. 
#endif //STB2018_ErrorCode
								memset(pTmp, 0, 1024);
								sprintf_s(pTmp, 1024, "%s;%s;%d;", symbol->Name, line.FileName, line.LineNumber);
							}
							else
							{
								//���� ���� ������ ��ȿ�� ��츸
								break;
								sprintf_s(pTmp, 1024, "%s;%s;%d;", symbol->Name, "unknown", -1);
							}
							strncat_s(szMsg, nBufferSize, pTmp, strlen(pTmp));
						}
						BrSysFree(pTmp);
					}
					if ( nMsgLen )
						strncat_s(szMsg, nBufferSize, pMsg, nMsgLen);

					strncat_s(szMsg, nBufferSize, "\0", strlen("\0"));
				}

				BrSysFree( symbol );
			}
		}
		//LoadLibrary������ FreeLibraryȣ��		
		FreeLibrary(hDll);
	}
	return szMsg;
}
#elif defined (__ANDROID__) || defined(__EMSCRIPTEN__)
char* printStack(const char* pMsg)
{
	//android not support backtrace
	return BrNULL;
}
//linux/mac
#elif defined(__unix__) || defined(__unix) || defined(unix) || (defined(__APPLE__) && defined(__MACH__))
#include <execinfo.h>
char* printStack(const char* pMsg)
{
	char *szMsg = BrNULL;
	void* frame_addrs[16];
	char** frame_strings;
	size_t backtrace_size;
	int i;
	backtrace_size = backtrace(frame_addrs, 16);
	frame_strings = backtrace_symbols(frame_addrs, backtrace_size);
	for ( i=0;i<backtrace_size;++i )
		BTrace("%d : [0x%x] %s", i, frame_addrs[i], frame_strings[i]);
	
	free(frame_strings);
	return szMsg;
}
#endif

void GetMemSizeInfo(unsigned long long nMemValue, char* pOut, int outSize)
{
#define GB	(double)(1024*1024*1024)
#define MB	(double)(1024*1024)
#define KB 	(double)(1024)

	if ( nMemValue > GB )
		sprintf_s(pOut, outSize, "%.2fGB", static_cast<double>(nMemValue / GB));
	else if ( nMemValue > MB )
		sprintf_s(pOut, outSize, "%.2fMB", static_cast<double>(nMemValue / MB));
	else if ( nMemValue > KB )
		sprintf_s(pOut, outSize, "%lluKB", static_cast<unsigned long long>(nMemValue / KB));
	else
		sprintf_s(pOut, outSize, "%lluBytes", nMemValue);	
}

//callstack�� errorlog�� �ִ� ������ �ܺο��� ������ �� �ִ� �Լ�
extern "C" void POLoadCallstack(bool a_bSet)
{
	if ( g_pBInterfaceHandle )
		g_pBInterfaceHandle->SetLoadCallstack(a_bSet);
}
/*
*	@author 	Andrew
*	@date  	2016.11.02
*	@params int $nErrorValue : poError ��
*	@params char* $file : ���ϸ�
*	@params int $line : ������ ����
*	@params char* $pMsg : �߰� �޽���
*	@brief  ERR_TRACE�� ȣ��� �������� ����Ʈ�� �����Ѵ�.
*			message {callstack};{pFilePath};{pMsg};{memoryInfo}
*/
extern void SetErrorInfoList(int nErrorValue, const char* file, int line, const char* pFilePath, const char* pMsg, bool bExtractStackInfo, int systemError, PO_ErrorClassType eClassType)
{
	if(g_pBInterfaceHandle == BrNULL || g_pErrorHandler == BrNULL)
		return;

	//�ݽ��� ����
	bool bShowStackInfo = bExtractStackInfo;	
#ifdef _WIN32//PC office���� ������ FreeLibrary�� ���� crash�� �߻��Ͽ� �⺻ ������ ����
	bShowStackInfo = false;
#endif
	bShowStackInfo = g_pBInterfaceHandle->IsLoadCallstack();

	char* pCallStack = NULL;
	int nCallStackLen = 0;
	if ( bShowStackInfo )
	{
		pCallStack = printStack(NULL);
		if ( pCallStack )
			nCallStackLen = strlen(pCallStack)+1;
#ifdef _WIN32
//		MessageBoxA(NULL, pCallStack, "Check Callstack", 0);
#endif
	}

	//���� i/o�� ���ϸ�
	int nFilePathLen = 0;
	if ( pFilePath )
		nFilePathLen = strlen(pFilePath)+1;

	//��Ÿ �޽���
	int nMsgLen = 0;
	if ( pMsg )
		nMsgLen = strlen(pMsg)+1;

	//�޸� ����
	BrCHAR	strMemMsg[128], strAlloc[16]={0,}, strAvail[16]={0,};
	GetMemSizeInfo(GetAllocatedMemory(), strAlloc, sizeof(strAlloc));
	GetMemSizeInfo(GetCurrentAvailableMemory(), strAvail, sizeof(strAvail));
	sprintf_s(strMemMsg, sizeof(strMemMsg), "Memory Info: [%s / %s]", strAlloc, strAvail);
	int nMemLen = strlen(strMemMsg)+1;

	int nBufferLen = nCallStackLen + nFilePathLen + nMsgLen + nMemLen;
	char* pBuffer = (char*)BrSysCalloc(nBufferLen, sizeof(char));
	if ( pBuffer )
	{
		if ( nCallStackLen > 0 )
		{
			strncat_s(pBuffer, nBufferLen, pCallStack, nCallStackLen-1);			
		}
		if ( nFilePathLen > 0 )
		{
			if ( strlen(pBuffer) > 0 )
				strncat_s(pBuffer, nBufferLen, ";", strlen(";"));
			strncat_s(pBuffer, nBufferLen, pFilePath, nFilePathLen-1);
		}
		if ( nMsgLen > 0 )
		{
			if ( strlen(pBuffer) > 0 )
				strncat_s(pBuffer, nBufferLen, ";", strlen(";"));
			strncat_s(pBuffer, nBufferLen, pMsg, nMsgLen-1);			
		}
		if ( nMemLen > 0 )
		{
			if ( strlen(pBuffer) > 0 )
				strncat_s(pBuffer, nBufferLen, ";", strlen(";"));
			strncat_s(pBuffer, nBufferLen, strMemMsg, nMemLen-1);
		}
	}
	if(eClassType == PO_EDITER_CLASS)
	{
#ifdef STB2018_ErrorCode
		char *ptr = const_cast<char*>(file);
#ifndef WIN32
		ptr = strrchr(ptr, '\\');   //���� ��δ� �����Ѵ�.
#endif //WIN32
		CEditErrorObj obj((PoError)nErrorValue, ptr, line, pBuffer);
		g_pErrorHandler->SetError(obj);
#endif //STB2018_ErrorCode
	}
	else
	{
		CPublicErrorObj obj((PoError)nErrorValue, file, line, pBuffer, systemError);
		g_pErrorHandler->SetError(obj);
	}

	if ( pCallStack )
		BrSysFree(pCallStack);
	if ( pBuffer )
		BrSysFree(pBuffer);
}

BrLONG BrRound(BrFLOAT iNum, BrLONG iDen)
{ return (BrLONG)((((iNum * 10) / iDen) + 5) / 10); }


BrLONG BrRound2(BrDOUBLE iNum, BrLONG iDen)
{ return (BrLONG)((((iNum * 10) / iDen) + 5) / 10); }

BrLONG BrFRound( BrFLOAT fVal )
{
	return postd::math::safe_round<BrFLOAT, BrLONG>(fVal);
}

BrFLOAT BrRounding(BrFLOAT iNum, BrLONG iDig)
{ return ( BrFloor( iNum * BrPow( float(10), iDig ) + 0.5f ) / BrPow( float(10), iDig ) ); }

BrDOUBLE BrGetSixteenFraction(BrUINT32 x)
{
	BrDOUBLE xx;
	BrINT16 i = (BrINT16)((x&0xFFFF0000) >> 16);
	if ( i<0 )
	{
		i += 1;
		xx = (BrDOUBLE)-i + (BrDOUBLE)(0x10000-x&0x0000FFFF) / (BrDOUBLE)(0x10000);
		xx = -xx;
	}
	else
		xx = (BrDOUBLE)i + (BrDOUBLE)(x&0x0000FFFF) / (BrDOUBLE)(0x10000);

	return xx;
}

BrINT32 BrMulDiv(BrINT32 multiplicand, BrINT32 multiplier, BrINT32 divisor)
{
#ifndef	BWP_EDITOR
	BRTHREAD_ASSERT(((BrUINT64)BrABS(multiplicand) * BrABS(multiplier)) <= __BRMAX(BrINT32));	// OverFlow �Դϴ�, BrMulDiv2 or BrMulDivDouble�� ����ϼ���.
   return BrFRound (((BrFLOAT)(multiplicand) * (BrFLOAT)(multiplier)) /  (BrFLOAT)(divisor));
#else
   return BrFRound ((BrFLOAT)(((double)(multiplicand) * (double)(multiplier)) /  (divisor)));
#endif
}

BrINT32 BrMulDiv2(BrINT32 multiplicand, BrINT32 multiplier, BrINT32 divisor)
{
	return BrFRound ((BrFLOAT)((double)(multiplicand) * (double)(multiplier)) /  (BrFLOAT)(divisor)); //long���� �Ѿ�� ���� ���ϱ��ϸ鼭 ����.
}

BrDOUBLE BrDRound( BrDOUBLE fVal )
{
	return( fVal > 0.0 ? ( fVal + 0.5 ) : -( -fVal + 0.5 ) );
}
//�� �Լ��� ���� ū ���� ��쿡�� ����ؾ���. �ӵ��� ������ �ֱ� ������.
BrDOUBLE BrMulDivDouble(BrDOUBLE multiplicand, BrDOUBLE multiplier, BrDOUBLE divisor)
{
   return BrDRound (((multiplicand) * (multiplier)) /  divisor);
}

BrDOUBLE BrMulDivDoubleNotDRound(BrDOUBLE multiplicand, BrDOUBLE multiplier, BrDOUBLE divisor)
{
	return ((multiplicand) * (multiplier)) /  divisor;
}

BrLONG twips2DeviceX(BrLONG iTwipsX, BrLONG nZoomIn, BrLONG iResX)
{ 
	return (BrLONG)BrMulDiv(iTwipsX, iResX * nZoomIn, 1440*ZOOM_10000 );
}

BrLONG twips2DeviceY(BrLONG iTwipsY, BrLONG nZoomIn, BrBOOL bDown, BrLONG iResY)
{
	if ( bDown )	
		return (BrLONG )(((BrFLOAT)iTwipsY * (BrFLOAT)iResY * (BrFLOAT)nZoomIn)/ ( 1440 * ZOOM_10000 ) );
	else	
		return (BrLONG )BrMulDiv(iTwipsY, iResY * nZoomIn, 1440*ZOOM_10000 ); 
}    
BrFLOAT twip2DeviceF(BrFLOAT fTwip, BrFLOAT nZoomIn, BrFLOAT iRes)
{
	return (fTwip * iRes*nZoomIn)/(1440.0*ZOOM_10000);
}
BrLONG Device2twips(BrLONG iTwips, BrLONG nZoomIn, BrLONG iResX)
{ 
	return (BrLONG)BrMulDiv(iTwips, 1440*ZOOM_10000 , iResX * nZoomIn);
}
BrFLOAT Device2twipsF(BrFLOAT fTwip, BrFLOAT nZoomIn, BrFLOAT iRes)
{
	return (fTwip * 1440.0*ZOOM_10000)/(iRes*nZoomIn);
}

BrINT32 getLogPixelsX(void) 
{
	return BrRound((BrFLOAT)(96 * 100), 100);
}

BrINT32 getLogPixelsY(void) 
{
	return BrRound((BrFLOAT)(96 * 100), 100);
}

BrUINT32 getDeviceScreenWidth()
{
	return getLCDWidth();
}

BrUINT32 getDeviceScreenHeight()
{
	return getLCDHeight();
}

BrUINT32 getRotateDeviceScreenWidth(BrINT32 nAngle)
{
	if(nAngle == 0 || nAngle == 180)	
		return getLCDWidth();
	else
		return getLCDHeight();	
}

BrUINT32 getRotateDeviceScreenHeight(BrINT32 nAngle)
{
	if(nAngle == 0 || nAngle == 180)	
		return getLCDHeight();
	else
		return getLCDWidth();	
}

void setResolution(BrINT16 nResolution)
{
	if (nResolution <= 0)
		return;

	gnBoraResolution = nResolution;
}

BrINT16 getResolution()
{
	return gnBoraResolution;
}

void setExportPDFRes(BrINT16 nResolution)
{
	if (nResolution <= 0)
		return;

	g_nExportPDFRes = nResolution;
}

BrINT16 getExportPDFRes()
{
	return g_nExportPDFRes;
}

void BrSwap(BrINT32* x1, BrINT32* x2)
{
	BrINT32 temp;
	temp = *x1;
	*x1 = *x2;
	*x2 = temp;
}

template<typename T> void BrNormalizePosEx(T & x1, T & y1, T & x2, T & y2)
{
	T dMax;

	if(x1 > x2)
	{			
		dMax = x1;
		x1 = x2;
		x2 = dMax;
	}

	if(y1 > y2)
	{
		dMax = y1;
		y1 = y2;
		y2 = dMax;
	}
}

void BrNormalizePos(BrINT & x1, BrINT & y1, BrINT & x2, BrINT & y2)
{
	BrNormalizePosEx(x1, y1, x2, y2);
}

void BrNormalizePos(BrFLOAT & x1, BrFLOAT & y1, BrFLOAT & x2, BrFLOAT & y2)
{
	BrNormalizePosEx(x1, y1, x2, y2);
}

void BrNormalizeDPos(BrDOUBLE & x1, BrDOUBLE & y1, BrDOUBLE & x2, BrDOUBLE & y2)
{
	BrNormalizePosEx(x1, y1, x2, y2);
}

void BrNormalizeVelocity(BrINT & nVelocityX, BrINT & nVelocityY)
{
	const BrINT32 telerance = 20;
	CBRVector vel(nVelocityX, nVelocityY, 0);
	vel.Normalize();
	
	// ���͸� ȸ�� �ؾ� �� �� ���� ������.... ū ���� �����Ƿ� x or y ���� 0���� ����. 
	if(RAD2DEG(vel.Angle(CBRVector(-1,0,0))) < telerance || RAD2DEG(vel.Angle(CBRVector(1,0,0))) < telerance)
		nVelocityY = 0;
	else if(RAD2DEG(vel.Angle(CBRVector(0,-1,0))) < telerance || RAD2DEG(vel.Angle(CBRVector(0,1,0))) < telerance)
		nVelocityX = 0;
}

const Br3DPoint get3DRotationAngle(const Br3DPoint rot)
{
	Br3DPoint rotation;

	rotation.x = (BrFLOAT)rot.x;
	rotation.y = -(BrFLOAT)rot.y;
	rotation.z = (BrFLOAT)rot.z;

	return rotation;
}

void BrRotateBoundary(BrRect & rect, BrINT32 nAngle)
{
	BrDOUBLE x1, x2, y1, y2;

	nAngle = nAngle % 360;

	x1 = rect.left;
	y1 = rect.top;
	x2 = rect.right;
	y2 = rect.bottom;

	switch(nAngle)
	{
	case 0:
	case 180:
		{
			BrNormalizeDPos(x1, y1, x2, y2);
			rect.left = x1;		rect.top = y1;
			rect.right = x2;	rect.bottom = y2;
		}
		break;
	case 90:
	case 270:
		{
			BrDOUBLE nWidth, nHeight, nHalfX1, nHalfX2, nHalfY1, nHalfY2, nCenterX, nCenterY;
			BrNormalizeDPos(x1, y1, x2, y2);
			
			nWidth = x2 - x1;
			nHeight = y2 - y1;
			nHalfX1 = nWidth / 2.f;
			nHalfX2 = nWidth - nHalfX1;
			nHalfY1 = nHeight / 2.f;
			nHalfY2 = nHeight - nHalfY1;
			nCenterX = x1 + nHalfX1;
			nCenterY = y1 + nHalfY1;
			rect.left = BrFRound(nCenterX - nHalfY1);
			rect.top = BrFRound(nCenterY - nHalfX1);
			rect.right = BrFRound(nCenterX + nHalfY2);
			rect.bottom = BrFRound(nCenterY + nHalfX2);
		}
		break;
	default:
		{
			BrDOUBLE nCenterX, nCenterY;
			BrDOUBLE dX, dY;
			BrDOUBLE dR = BrDEGtoRAD(nAngle);

			nCenterX = x1 + (x2 - x1) / 2.f;
			nCenterY = y1 + (y2 - y1) / 2.f;

			x1 = x1 - nCenterX;
			y1 = y1 - nCenterY;
			x2 = x2 - nCenterX;
			y2 = y2 - nCenterY;

			dX = (BrINT32)BrFRound((x1 * BrCos(dR) - y1 * BrSin(dR) + nCenterX));
			dY = (BrINT32)BrFRound((x1 * BrSin(dR) + y1 * BrCos(dR) + nCenterY));
			rect.left = rect.right = dX;
			rect.top = rect.bottom = dY;

			dX = (BrINT32)BrFRound((x2 * BrCos(dR) - y1 * BrSin(dR) + nCenterX));
			dY = (BrINT32)BrFRound((x2 * BrSin(dR) + y1 * BrCos(dR) + nCenterY));
			CUtil::BrBoundary(&rect, dX, dY);

			dX = (BrINT32)BrFRound((x1 * BrCos(dR) - y2 * BrSin(dR) + nCenterX));
			dY = (BrINT32)BrFRound((x1 * BrSin(dR) + y2 * BrCos(dR) + nCenterY));
			CUtil::BrBoundary(&rect, dX, dY);

			dX = (BrINT32)BrFRound((x2 * BrCos(dR) - y2 * BrSin(dR) + nCenterX));
			dY = (BrINT32)BrFRound((x2 * BrSin(dR) + y2 * BrCos(dR) + nCenterY));
			CUtil::BrBoundary(&rect, dX, dY);
		}
		break;
	}
}

void BrRotateBoundary(BrDOUBLE & x1, BrDOUBLE & y1, BrDOUBLE & x2, BrDOUBLE & y2, BrINT32 nAngle)
{
	BrRect rect;

	nAngle = nAngle % 360;

	switch(nAngle)
	{
	case 0:
	case 180:
		{
			BrNormalizeDPos(x1, y1, x2, y2);
			rect.left = x1;		rect.top = y1;
			rect.right = x2;	rect.bottom = y2;
		}
		break;
	case 90:
	case 270:
		{
			BrINT32 nWidth, nHeight, nHalfX1, nHalfX2, nHalfY1, nHalfY2, nCenterX, nCenterY;
			BrNormalizeDPos(x1, y1, x2, y2);

			nWidth = x2 - x1;
			nHeight = y2 - y1;
			nHalfX1 = nWidth / 2;
			nHalfX2 = nWidth - nHalfX1;
			nHalfY1 = nHeight / 2;
			nHalfY2 = nHeight - nHalfY1;
			nCenterX = x1 + nHalfX1;
			nCenterY = y1 + nHalfY1;
			rect.left = nCenterX - nHalfY1;
			rect.top = nCenterY - nHalfX1;
			rect.right = nCenterX + nHalfY2;
			rect.bottom = nCenterY + nHalfX2;
		}
		break;
	default:
		{
			BrDOUBLE nCenterX, nCenterY;
			BrINT32 dX, dY;
			BrDOUBLE dR = BrDEGtoRAD(nAngle);

			nCenterX = x1 + (x2 - x1)/2;
			nCenterY = y1 + (y2 - y1)/2;

			x1 = x1 - nCenterX;
			y1 = y1 - nCenterY;
			x2 = x2 - nCenterX;
			y2 = y2 - nCenterY;

			dX = (BrINT32)(x1 * BrCos(dR) - y1 * BrSin(dR) + nCenterX);
			dY = (BrINT32)(x1 * BrSin(dR) + y1 * BrCos(dR) + nCenterY);
			rect.left = rect.right = dX;
			rect.top = rect.bottom = dY;

			dX = (BrINT32)(x2 * BrCos(dR) - y1 * BrSin(dR) + nCenterX);
			dY = (BrINT32)(x2 * BrSin(dR) + y1 * BrCos(dR) + nCenterY);
			CUtil::BrBoundary(&rect, dX, dY);

			dX = (BrINT32)(x1 * BrCos(dR) - y2 * BrSin(dR) + nCenterX);
			dY = (BrINT32)(x1 * BrSin(dR) + y2 * BrCos(dR) + nCenterY);
			CUtil::BrBoundary(&rect, dX, dY);

			dX = (BrINT32)(x2 * BrCos(dR) - y2 * BrSin(dR) + nCenterX);
			dY = (BrINT32)(x2 * BrSin(dR) + y2 * BrCos(dR) + nCenterY);
			CUtil::BrBoundary(&rect, dX, dY);
		}
		break;
	}

	x1 = rect.left;
	y1 = rect.top;
	x2 = rect.right;
	y2 = rect.bottom;
}

//indong
void BrSkewBoundary(BrRect & rect , BrINT skewX, BrINT skewY)
{
	//rect�� ���� �̹��� rect���� ������

	/*
	shear
	1   g   ->     1   dRX
	h   1   ->    dRY   1
	*/


	// Todo.. 90 270
	BrDOUBLE nCenterX, nCenterY, x1, x2, y1, y2, dX, dY;
	nCenterX =  nCenterY = x1 = x2 = y1 = y2 = dX = dY = 0.0f;
	
	BrDOUBLE dRX = BrTan(BrDEGtoRAD(skewX));//g
	BrDOUBLE dRY = BrTan(BrDEGtoRAD(skewY));//h

	x1 = rect.left;
	y1 = rect.top;
	x2 = rect.right;
	y2 = rect.bottom;

	nCenterX = x1 + (x2 - x1) / 2.0f;
	nCenterY = y1 + (y2 - y1) / 2.0f;

	x1 = x1 - nCenterX;
	y1 = y1 - nCenterY;
	x2 = x2 - nCenterX;
	y2 = y2 - nCenterY;

	BrNormalizeDPos(x1, y1, x2, y2);

	//x1,y1
	dX = (x1 * 1) + (y1 * dRX) + nCenterX;
	dY = (x1 * dRY) + (y1 * 1) + nCenterY;
	rect.left = rect.right = dX;
	rect.top = rect.bottom = dY;

	//x2,y1
	dX = (x2 * 1) + (y1 * dRX) + nCenterX;
	dY = (x2 * dRY) + (y1 * 1) + nCenterY;
	CUtil::BrBoundary(&rect , dX , dY);

	//x1,y2
	dX = (x1 * 1) + (y2 * dRX) + nCenterX;
	dY = (x1 * dRY) + (y2 * 1) + nCenterY;
	CUtil::BrBoundary(&rect , dX , dY);

	//x2,y2
	dX = (x2 * 1) + (y2 * dRX) + nCenterX;
	dY = (x2 * dRY) + (y2 * 1) + nCenterY;
	CUtil::BrBoundary(&rect , dX , dY);
}

BrINT32 getPixelsPerPointX(BrUINT nScale, BrUINT16 iResX) 
{ 
	return BrRound((BrFLOAT)iResX * nScale, 7200); 
}

BrINT32 getPixelsPerPointY(BrUINT nScale, BrUINT16 iResY) 
{ 
	return BrRound((BrFLOAT)iResY * nScale, 7200); 
}
BrINT32 getPixelsPerHalfPointX(BrUINT nScale, BrUINT16 iResX) 
{ 
	return BrRound((BrFLOAT)iResX * nScale, 14400); 
}
BrINT32 getPixelsPerHalfPointY(BrUINT nScale, BrUINT16 iResY) 
{ 
	return BrRound((BrFLOAT)iResY * nScale, 14400); 
}


void Init_ShapeFlag(FSP* pFlag)
{
	memset(pFlag, 0, sizeof(FSP));
}

void copy_AdjustValue(AdjustValue* pToThis, AdjustValue* pValue) 
{
		pToThis->l01 = pValue->l01;
		pToThis->l02 = pValue->l02;
		pToThis->l03 = pValue->l03;
		pToThis->l04 = pValue->l04;
		pToThis->l05 = pValue->l05;
		pToThis->l06 = pValue->l06;
		pToThis->l07 = pValue->l07;
		pToThis->l08 = pValue->l08;
		pToThis->l09 = pValue->l09;
		pToThis->l10 = pValue->l10;

		pToThis->b01 = pValue->b01;
		pToThis->b02 = pValue->b02;
		pToThis->b03 = pValue->b03;
		pToThis->b04 = pValue->b04;
		pToThis->b05 = pValue->b05;
		pToThis->b06 = pValue->b06;
		pToThis->b07 = pValue->b07;
		pToThis->b08 = pValue->b08;
		pToThis->b09 = pValue->b09;
		pToThis->b10 = pValue->b10;
}

BrDOUBLE BrDEGtoRAD(BrDOUBLE degree)
{
	//return  (BrDOUBLE) degree*3.141592 / 180.0;
	return  (BrDOUBLE) degree*3.14159265358979323846 / 180.0;	
}

BrDOUBLE BrRADtoDEG(BrDOUBLE radian)
{
	//return  (BrDOUBLE) radian*180.0 / 3.141592;
	return  (BrDOUBLE) radian*180.0 / 3.14159265358979323846;
}

BrINT32 BrFixAngle( BrINT32 a )
{
    if ( a > 16*360 )
		a %= 16*360;
    else if ( a < -16*360 ) 
		a = -( (-a) % (16*360) );
    
    return a;
}

extern "C"
{
	BrDOUBLE BrSin(BrDOUBLE x)
	{
#ifdef USE_STD_LIB
		return sin ( x );
#endif
		BrDOUBLE xi, y, q, q2;
		BrINT32 sign;

		xi = x; sign = 1;
		while (xi < -1.57079632679489661923)
			xi += 6.28318530717958647692;
		while (xi > 4.71238898038468985769)
			xi -= 6.28318530717958647692;
		if (xi > 1.57079632679489661923)
		{
			xi -= 3.141592653589793238462643;
			sign = -1;
		}
		q = xi / 1.57079632679;
		q2 = q * q;
		y = ((((.00015148419  * q2
			- .00467376557) * q2
			+ .07968967928) * q2
			- .64596371106) * q2
			+1.57079631847) * q;
		return (sign < 0? -y : y);
	}

	BrDOUBLE BrCos(BrDOUBLE x)
	{
#ifdef USE_STD_LIB
		return cos(x);
#else
		return BrSin(x+HALFPI);
#endif
	}

	BrDOUBLE BrTan(BrDOUBLE x)
	{
#ifdef USE_STD_LIB
		return tan(x);
#else
		return BrSin(x)/BrCos(x);
#endif
	}

	BrDOUBLE BrAsin(BrDOUBLE x)
	{
#ifdef USE_STD_LIB
		return asin(x);
#else
		return asin_acos(x, 0);
#endif 
	}

	BrDOUBLE BrAcos(BrDOUBLE x)
	{
#ifdef USE_STD_LIB
		return acos(x);
#else
		return asin_acos(x, 1);
#endif 
	}

	BrDOUBLE BrAtan2(BrDOUBLE y, BrDOUBLE x)
	{
#ifdef USE_STD_LIB
		return atan2(y, x);
#else
		BrDOUBLE absx, absy, val;

		if (x == 0 && y == 0) {
			return 0;
		}
		absy = y < 0 ? -y : y;
		absx = x < 0 ? -x : x;
		if (absy - absx == absy) {
			/* x negligible compared to y */
			return y < 0 ? -M_PI_2 : M_PI_2;
		}
		if (absx - absy == absx) {
			/* y negligible compared to x */
			val = 0.0;
		}
		else    val = BrAtan(y/x);
		if (x > 0) {
			/* first or fourth quadrant; already correct */
			return val;
		}
		if (y < 0) {
			/* third quadrant */
			return val - M_PI;
		}
		return val + M_PI;
#endif
	}

	BrDOUBLE BrLog(BrDOUBLE x)
	{
#ifdef USE_STD_LIB
		return log (x);  //breakfree:[20111220] ���õ� �����Լ��� ǥ�� �����Լ� ������� �޶� Sheet ����Լ�(CRITBINOM)���� ���� ���� ���� (USE_STD_LIB ����Ҷ��� �ذ�Ǹ� ���õ� ���� �Լ��� ����ϴ� ��� ���� ������ �ʿ���
#else
		typedef union {
			BrDOUBLE d;
			unsigned short u[4];
		} DBL;

		BrDOUBLE y, z, z2;

		BrINT32 ix;
		DBL *xp, *yp;
		y=0.0;

		xp = (DBL *)&x;
		if (xp->d <= 0.0) return(y);
		y = 0.0;
		yp = (DBL *)&y;
		yp->u[3] = xp->u[3] & ~0100017; 
		ix = (yp->u[3] >> 4)-1023;
		if ((xp->d - yp->d) == 0.0) return( .693147180559945 * (BrDOUBLE)ix);
		xp->u[3] -= ++ix << 4; 
		xp->d *= 1.4142135623730950488;  
		z = (xp->d - 1.0) / (xp->d + 1.0);
		z2 = z * z;
		y = z  * (2.000000000046727 +	
			z2 * (0.666666635059382 +	
			z2 * (0.4000059794795   +	
			z2 * (0.28525381498     +
			z2 *  0.2376245609 ))));
		y = y + .693147180559945 * ((BrDOUBLE)ix	- 0.5);

		return(yp->d);
#endif
	}

	BrDOUBLE BrLog10(BrDOUBLE x)
	{
#ifdef USE_STD_LIB
		return log10 (x); //breakfree:[20111220] ���õ� �����Լ��� ǥ�� �����Լ� ������� �޶� Sheet ����Լ�(CRITBINOM)���� ���� ���� ���� (USE_STD_LIB ����Ҷ��� �ذ�Ǹ� ���õ� ���� �Լ��� ����ϴ� ��� ���� ������ �ʿ���
#else
		BrDOUBLE xi, y, q, q2;
		BrINT32 ex;

		if (x <= 0.0) return(0.); 
		ex = (BrINT32)0.0; xi = x;
		while (xi < 1.0 ) {
			xi *= 10.0;
			ex--;
		}
		while (xi > 10.0) {
			xi *= 0.1;
			ex++;
		}
		q = (xi - 3.16227766) / (xi + 3.16227766); q2 = q * q;
		y = ((((.191337714 * q2
			+ .094376476) * q2
			+ .177522071) * q2
			+ .289335524) * q2
			+ .868591718) * q + .5;
		y += (BrDOUBLE) ex;
		return(y);	
#endif
	}

	BrDOUBLE BrPow( BrDOUBLE x, BrINT32 y )
	{
#ifdef USE_STD_LIB
		return pow(x, (double)y);
#else
		BrDOUBLE pow = 1.0;
		BrINT32 i;

		if (x == 1.0 || y == 1)
			return x;

		for(i=1; i<=y; i++)
			pow *= x;

		return pow;
#endif
	}

	/*
	Cephes Math Library Release 2.1:  December, 1988
	Copyright 1984, 1987, 1988 by Stephen L. Moshier
	Direct inquiries to 30 Frost Street, Cambridge, MA 02140
	*/

	/*
	Cephes Math Library Release 2.8:  June, 2000
	Copyright 1984, 1995, 2000 by Stephen L. Moshier
	*/

	static const double P[] = {
		4.97778295871696322025E-1,
		3.73336776063286838734E0,
		7.69994162726912503298E0,
		4.66651806774358464979E0
	};
	static const double Q[] = {
		/* 1.00000000000000000000E0, */
		9.33340916416696166113E0,
		2.79999886606328401649E1,
		3.35994905342304405431E1,
		1.39995542032307539578E1
	};
	/* 2^(-i/16), IEEE precision */
	static const double A[] = {
		1.00000000000000000000E0,
		9.57603280698573700036E-1,
		9.17004043204671215328E-1,
		8.78126080186649726755E-1,
		8.40896415253714502036E-1,
		8.05245165974627141736E-1,
		7.71105412703970372057E-1,
		7.38413072969749673113E-1,
		7.07106781186547572737E-1,
		6.77127773468446325644E-1,
		6.48419777325504820276E-1,
		6.20928906036742001007E-1,
		5.94603557501360513449E-1,
		5.69394317378345782288E-1,
		5.45253866332628844837E-1,
		5.22136891213706877402E-1,
		5.00000000000000000000E-1
	};
	static const double B[] = {
		0.00000000000000000000E0,
		1.64155361212281360176E-17,
		4.09950501029074826006E-17,
		3.97491740484881042808E-17,
		-4.83364665672645672553E-17,
		1.26912513974441574796E-17,
		1.99100761573282305549E-17,
		-1.52339103990623557348E-17,
		0.00000000000000000000E0
	};
	static const double R[] = {
		1.49664108433729301083E-5,
		1.54010762792771901396E-4,
		1.33335476964097721140E-3,
		9.61812908476554225149E-3,
		5.55041086645832347466E-2,
		2.40226506959099779976E-1,
		6.93147180559945308821E-1
	};

	#define MAXNUM		1.7976931348623154E308
	#define douba(k)	A[k]
	#define doubb(k)	B[k]
	#define MEXP		16383.0
	#define MNEXP		-17183.0
	#define LOG2EA		0.44269504088896340736 // log2(e) - 1

	BrBOOL IsLittleEndian(void)
	{
		short int br_word = 0x0001;
		char *br_byte = (char *) &br_word;
		return (br_byte[0] ? BrTRUE : BrFALSE);
	}

	// frexp() extracts the exponent from x.  It returns an integer
	// power of two to expnt and the significand between 0.5 and 1 to y.
	// Thus  x = y * 2**expn.
	double BrFrexp( double x, int *pw2 )
	{
		union
		{
			double y;
			unsigned short sh[4];
		} u;
		int i;
		int k;
		short *q;

		u.y = x;

		if (IsLittleEndian())
		{
			q = (short *)&u.sh[3];

			// find the exponent (power of 2)
			i  = ( *q >> 4) & 0x7ff;
			if( i != 0 )
				goto ieeedon;
		}
		else
		{
			q = (short *)&u.sh[0];
			i  =  *q >> 4;
			i &= 0x7ff;
			if( i != 0 )
				goto ieeedon;
		}

		// Number is denormal or zero
		if( u.y == 0.0 )
		{
			*pw2 = 0;
			return( 0.0 );
		}

		// Handle denormal number.
		do
		{
			u.y *= 2.0;
			i -= 1;
			k  = ( *q >> 4) & 0x7ff;
		}
		while( k == 0 );
		i = i + k;

ieeedon:
		i -= 0x3fe;
		*pw2 = i;
		*q &= 0x800f;
		*q |= 0x3fe0;
		return( u.y );
	}

	// ldexp() multiplies x by 2**n.
	double BrLdexp( double x, int pw2 )
	{
		union
		{
			double y;
			unsigned short sh[4];
		} u;
		short *q;
		int e;

		u.y = x;

		if (IsLittleEndian())
			q = (short *)&u.sh[3];
		else
			q = (short *)&u.sh[0];

		while( (e = (*q & 0x7ff0) >> 4) == 0 )
		{
			if( u.y == 0.0 )
			{
				return( 0.0 );
			}
			// Input is denormal.
			if( pw2 > 0 )
			{
				u.y *= 2.0;
				pw2 -= 1;
			}
			if( pw2 < 0 )
			{
				if( pw2 < -53 )
					return(0.0);
				u.y /= 2.0;
				pw2 += 1;
			}
			if( pw2 == 0 )
				return(u.y);
		}

		e += pw2;

		// Handle overflow
		if( e >= MEXP )
			return( 2.0*MAXNUM );

		// Handle denormalized results
		if( e < 1 )
		{
			if( e < -53 )
				return(0.0);
			*q &= 0x800f;
			*q |= 0x10;
			/* For denormals, significant bits may be lost even
			when dividing by 2.  Construct 2^-(1-e) so the result
			is obtained with only one multiplication.  */
			u.y *= BrLdexp(1.0, e-1);
			return(u.y);
		}
		else
		{
			*q &= 0x800f;
			*q |= (e & 0x7ff) << 4;
			return(u.y);
		}
	}

	// Evaluates polynomial of degree N:
	//
	//            1      2          N
	// y  =  C  + C x + C x  +...+ C x
	//        0    1     2          N
	//
	// Coefficients are stored in reverse order:
	//
	// coef[0] = C  , ..., coef[N] = C  .
	//            N                   0
	//
	// The function p1evl() assumes that coef[N] = 1.0 and is
	// omitted from the array.  Its calling arguments are
	// otherwise the same as polevl().
	double BrPolevl( double x, const double coef[], int N )
	{
		double ans;
		int i;
		double *p;

		p = (double*)coef;
		ans = *p++;
		i = N;

		do {
			ans = ans * x  +  *p++;
		} while( --i );

		return( ans );
	}

	// p1evl()
	// Evaluate polynomial when coefficient of x  is 1.0.
	// Otherwise same as polevl.
	double BrP1evl( double x, const double coef[], int N )
	{
		double ans;
		double *p;
		int i;

		p = (double*)coef;
		ans = x + *p++;
		i = N-1;

		do {
			ans = ans * x  + *p++;
		} while( --i );

		return( ans );
	}

	// Find a multiple of 1/16 that is within 1/16 of x.
	double BrReduc( double x )
	{
		double t;
		t = BrLdexp( x, 4 );
		t = BrFloor( t );
		t = BrLdexp( t, -4 );
		return(t);
	}

	BrDOUBLE BrFABS( BrDOUBLE x )
	{
#ifdef USE_STD_LIB
		return fabs(x);
#endif //USE_STD_LIB
		union
		{
			double d;
			short i[4];
		} u;

		u.d = x;

		if (IsLittleEndian())
			u.i[3] &= 0x7fff;
		else
			u.i[0] &= 0x7fff;

		return( u.d );
	}

	// Computes x raised to the yth power.  Analytically,
	// x**y  =  exp( y log(x) ).
	// Following Cody and Waite, this program uses a lookup table
	// of 2**-i/16 and pseudo extended precision arithmetic to
	// obtain an extra three bits of accuracy in both the logarithm
	// and the exponential.
	BrDOUBLE BrPow2( BrDOUBLE x, BrDOUBLE y )
	{
#ifdef USE_STD_LIB
			return pow(x, y);
#endif //USE_STD_LIB

		double w, z, ya, yb;
		//double W, Wa, Wb, u;
		double F, Fa, Fb, G, Ga, Gb, H, Ha, Hb;
		double aw, ay, wy;
		int e, i, nflg, iyflg, yoddint;

		if( y == 0.0 )
			return( 1.0 );

		if( y == 1.0 )
			return( x );

		if( x == 1.0 )
			return( 1.0 );

		if( y >= MAXNUM )
		{
			if( x > 1.0 )
				return( MAXNUM );
			if( x > 0.0 && x < 1.0 )
				return( 0.0);
			if( x < -1.0 )
				return( MAXNUM );
			if( x > -1.0 && x < 0.0 )
				return( 0.0 );
		}

		if( y <= -MAXNUM )
		{
			if( x > 1.0 )
				return( 0.0 );
			if( x > 0.0 && x < 1.0 )
				return( MAXNUM );
			if( x < -1.0 )
				return( 0.0 );
			if( x > -1.0 && x < 0.0 )
				return( MAXNUM );
		}

		if( x >= MAXNUM )
		{
			if( y > 0.0 )
				return( MAXNUM );
			return(0.0);
		}

		// Set iyflg to 1 if y is an integer.
		iyflg = 0;
		w = BrFloor(y);
		if( w == y )
			iyflg = 1;

		// Test for odd integer y.
		yoddint = 0;
		if( iyflg )
		{
			ya = BrFABS(y);
			ya = BrFloor(0.5 * ya);
			yb = 0.5 * BrFABS(w);
			if( ya != yb )
				yoddint = 1;
		}

		if( x <= -MAXNUM )
		{
			if( y > 0.0 )
			{
				if( yoddint )
					return( -MAXNUM );
				return( MAXNUM );
			}
			if( y < 0.0 )
				return( 0.0 );
		}

		nflg = 0; // flag = 1 if x<0 raised to integer power
		if( x <= 0.0 )
		{
			if( x == 0.0 )
			{
				if( y < 0.0 )
					return( MAXNUM );
				if( y > 0.0 )
					return( 0.0 );
				return( 1.0 );
			}
			else
			{
				if( iyflg == 0 ) //non integer power of negative number
					return(0.0L);
				nflg = 1;
			}
		}

		// Integer power of an integer.
		if( iyflg )
		{
			i = (int)w;
			w = BrFloor(x);
			if( (w == x) && (BrFABS(y) < 32768.0) )
			{
				w = BrPow( x, (int) y );
				return( w );
			}
		}

		if( nflg )
			x = BrFABS(x);

		// For results close to 1, use a series expansion.
		w = x - 1.0;
		aw = BrFABS(w);
		ay = BrFABS(y);
		wy = w * y;
		ya = BrFABS(wy);
		if((aw <= 1.0e-3 && ay <= 1.0) || (ya <= 1.0e-3 && ay >= 1.0))
		{
			z = (((((w*(y-5.)/720. + 1./120.)*w*(y-4.) + 1./24.)*w*(y-3.)
				+ 1./6.)*w*(y-2.) + 0.5)*w*(y-1.) )*wy + wy + 1.;
			goto done;
		}
		
		// separate significand from exponent
		x = BrFrexp( x, &e );

		// Find significand of x in antilog table A[].
		i = 1;
		if( x <= douba(9) )
			i = 9;
		if( x <= douba(i+4) )
			i += 4;
		if( x <= douba(i+2) )
			i += 2;
		if( x >= douba(1) )
			i = -1;
		i += 1;

		// Find (x - A[i])/A[i]
		// in order to compute log(x/A[i]):
		// log(x) = log( a x/a ) = log(a) + log(x/a)
		// log(x/a) = log(1+v),  v = x/a - 1 = (x-a)/a
		x -= douba(i);
		x -= doubb(i/2);
		x /= douba(i);

		// rational approximation for log(1+v):
		// log(1+v)  =  v  -  v**2/2  +  v**3 P(v) / Q(v)
		z = x*x;
		w = x * ( z * BrPolevl( x, P, 3 ) / BrP1evl( x, Q, 4 ) );
		w = w - BrLdexp( z, -1 ); // w - 0.5 * z

		// Convert to base 2 logarithm:
		// multiply by log2(e)
		w = w + LOG2EA * w;
		// Note x was not yet added in
		// to above rational approximation,
		// so do it now, while multiplying
		// by log2(e).
		z = w + LOG2EA * x;
		z = z + x;

		// Compute exponent term of the base 2 logarithm.
		w = -i;
		w = BrLdexp( w, -4 ); // divide by 16
		w += e;
		// Now base 2 log of x is w + z.

		// Multiply base 2 log by y, in extended precision.

		// separate y into large part ya
		// and small part yb less than 1/16
		ya = BrReduc(y);
		yb = y - ya;

		F = z * y  +  w * yb;
		Fa = BrReduc(F);
		Fb = F - Fa;

		G = Fa + w * ya;
		Ga = BrReduc(G);
		Gb = G - Ga;

		H = Fb + Gb;
		Ha = BrReduc(H);
		w = BrLdexp( Ga+Ha, 4 );

		// Test the power of 2 for overflow
		if( w > MEXP )
		{
			if( nflg && yoddint )
				return( -MAXNUM );
			return( MAXNUM );
		}

		if( w < (MNEXP - 1) )
			return( 0.0 );

		e = (int)w;
		Hb = H - Ha;

		if( Hb > 0.0 )
		{
			e += 1;
			Hb -= 0.0625;
		}

		// Now the product y * log2(x)  =  Hb + e/16.0.
		// Compute base 2 exponential of Hb,
		// where -0.0625 <= Hb <= 0.
		z = Hb * BrPolevl( Hb, R, 6 ); // z  =  2**Hb - 1

		// Express e/16 as an integer plus a negative number of 16ths.
		// Find lookup table entry for the fractional power of 2.
		if( e < 0 )
			i = 0;
		else
			i = 1;
		i = e/16 + i;
		e = 16*i - e;
		w = douba( e );
		z = w + w * z;		// 2**-e * ( 1 + (2**Hb-1) )
		z = BrLdexp( z, i );	// multiply by integer power of 2

done:
		// Negate if odd integer power of negative number
		if( nflg && yoddint )
			z = -z;

		return( z );
	}


	BrDOUBLE BrSqrt(BrDOUBLE dbInput)
	{
#ifdef USE_STD_LIB
		return sqrt(dbInput);
#else
		// sqrt�� ������ ���� 0���� ���� ��쿡 ���� ������ �� �ڵ带 �����ؾ� ��
		BRTHREAD_ASSERT(dbInput >= 0);

		BrDOUBLE dbRtnValue = 2.0, dbBeforeValue = 0; 

		if (dbInput == 0)
		{
			return 0;
		}

		while (true)
		{ 
			dbRtnValue = 0.5 * (dbRtnValue + dbInput / dbRtnValue); 
			if (dbBeforeValue == dbRtnValue) 
			{
				return dbRtnValue; 
			}
			dbBeforeValue = dbRtnValue; 
		} 
#endif
	} 

	BrDOUBLE BrSinh( BrDOUBLE x )
	{
#ifdef USE_STD_LIB
 		return sinh(x);
 #else
		return (BrPow2(M_E, x) - BrPow2(M_E, -x)) * 0.5;
#endif
	}

	BrDOUBLE BrCosh( BrDOUBLE x )
	{
#ifdef USE_STD_LIB
 		return cosh(x);
#else
		return (BrPow2(M_E, x) + BrPow2(M_E, -x)) * 0.5;
#endif
	}

};



BrINT32 __IsNan(BrDOUBLE d)
{
#if defined(vax) || defined(pdp)
#else
	BrFLOAT f = (BrFLOAT)d;

	if ((*((BrLONG *) &f) & 0x7f800000) == 0x7f800000 &&
		(*((BrLONG *) &f) & 0x007fffff) != 0) return 1;
#endif
	return 0;
}
BrDOUBLE asin_acos(BrDOUBLE x, BrINT32 cosfl)
{
	BrINT32 negative = x < 0;
	BrINT32     i;
	BrDOUBLE  g;
	static const BrDOUBLE p[] = {
		-0.27368494524164255994e+2,
		0.57208227877891731407e+2,
		-0.39688862997540877339e+2,
		0.10152522233806463645e+2,
		-0.69674573447350646411e+0
	};
	static const BrDOUBLE q[] = {
		-0.16421096714498560795e+3,
		0.41714430248260412556e+3,
		-0.38186303361750149284e+3,
		0.15095270841030604719e+3,
		-0.23823859153670238830e+2,
		1.0
	};

	if (__IsNan(x)) {
		//errno = EDOM;
		return 0;
	}

	if (negative) {
		x = -x;
	}
	if (x > 0.5) {
		i = 1;
		if (x > 1) {
			//errno = EDOM;
			return 0;
		}
		g = 0.5 - 0.5 * x;
		x = - BrSqrt(g);
		x += x;
	}
	else {
		/* ??? avoid underflow ??? */
		i = 0;
		g = x * x;
	}
	x += x * g * POLYNOM4(g, p) / POLYNOM5(g, q);
	if (cosfl) {
		if (! negative)
			x = -x;
	}
	if ((cosfl == 0) == (i == 1)) {
		x = (x + M_PI_4) + M_PI_4;
	}
	else if (cosfl && negative && i == 1) {
		x = (x + M_PI_2) + M_PI_2;
	}
	if (! cosfl && negative)
		x = -x;
	return x;
}

BrDOUBLE BrAtan(BrDOUBLE x)
{
#ifdef USE_STD_LIB
	return atan(x);
#else
	BrDOUBLE xi, q, q2, y;

	if (x == 0)
		return 0;

	xi = (x < 0. ? -x : x);
	q = (xi - 1.0) / (xi + 1.0);
	q2 = q * q;
	y = ((((((( - .0040540580 * q2
		     + .0218612286) * q2
		     - .0559098861) * q2
		     + .0964200441) * q2
		     - .1390853351) * q2
		     + .1994653599) * q2
		     - .3332985605) * q2
		     + .9999993329) * q + 0.785398163397;
	return(x < 0. ? -y: y);
#endif
}



BrDOUBLE BrFloor(BrDOUBLE x)
{
#ifdef USE_STD_LIB //system ���� floor �� �����ϴ� ��� ���. ������ �� �Ʒ� �ڵ� ��밡��.
	return floor(x);
#else
#ifdef OLD
	BrDOUBLE		y;
	BrINT32		ix;
	y = 0;
	while (x >= 0x7fffffff) {
		y += 0x7fffffff;
		x -= 0x7fffffff;
	}
	while (x <= -0x7fffffff) {
		y -= 0x7fffffff;
		x += 0x7fffffff;
	}
	//if (x > 0.0) ix = (BrINT32) x;
	//else ix = (BrINT32)(x*100000 - 99999)/100000;

	//breakfree:[20111229] 0002482: [QA][Excel] Ư�� ������ �Լ� ��� ����� ����Ȯ... BrFloor �Լ����� 0���� ���� ��� overflow ������ ��� ó��... ������� ��ü ������ ���� �Լ����� ������ ����. ǥ�� �Լ� ��� ����
	if ( x > 0.0 ) ix = ( BrINT32 ) x;
	else ix = ( BrINT32 )( x * 10 - 9 ) / 10;

	return ( y + ( BrDOUBLE ) ix );
#else	// by donny [2012.01.04] �� ����� -1.09 �̸� -1.0���� ��
	BrDOUBLE val;
	return BrModf(x, &val) < 0 ? val - 1.0 : val ;
#endif
#endif
}

void BrSetMinMax(BrINT32 a, BrINT32 b, BrINT32 *min, BrINT32 *max)
{
	if (a < b) {
		*min = a;
		*max = b;
	}
	else {
		*min = b;
		*max = a;
	}
}

BrDOUBLE BrModf(BrDOUBLE x0, BrDOUBLE *iptr)
{
	BrINT32 i;
	BrLONG l =0;
	BrDOUBLE x = x0;
	BrDOUBLE f=1.0;

	for (i=0;i<100;i++) {
		l = (BrLONG)x;
		if (l < (x+1) && l > (x-1)) break;
		x *= 0.1;
		f *= 10.0;
	}

	if (i == 100) {
		(*iptr) = 0;
		return 0;
	}

	if (i != 0) {
		BrDOUBLE i2;
		BrDOUBLE ret;

		ret = BrModf(x0-l*f, &i2);
		(*iptr) = l*f + i2;
		return ret;
	} 

	(*iptr) = l;
	return x - (*iptr);
}

BrDOUBLE BrCeil(BrDOUBLE x)
{
	BrDOUBLE val;
	return BrModf(x, &val) > 0 ? val + 1.0 : val ;
}

BrDOUBLE BrExp(BrDOUBLE x)
{
#ifdef USE_STD_LIB
	return exp(x); //breakfree:[20111220] ���õ� �����Լ��� ǥ�� �����Լ� ������� �޶� Sheet ����Լ�(CRITBINOM)���� ���� ���� ���� (USE_STD_LIB ����Ҷ��� �ذ�Ǹ� ���õ� ���� �Լ��� ����ϴ� ��� ���� ������ �ʿ���
#else

	BrDOUBLE result = 1.0, term = 1.0, I = 0.0, prev;
	
	do {
		prev = result;
		I = I + 1.0;
		term = term * x/I;
		result = result + term;
	}while(prev != result);

	return (result);
#endif
}

/*
*	@author 	Andrew
*	@date  		2017.03.06
*	@params  	const BrCHAR* $pStr : �Է� ��Ʈ��
*	@return 	BrINT32 : ��ȯ�� ��Ʈ��
*	@brief  	BrAtoi�� ������ �����ϴ� ������ �Լ��� ��ȣ�� ���� ������ �����Ͽ� strtol�� ��ȯ�ؼ� ����
*/
BrINT32 PoStringToInt32(const BrCHAR *pStr)
{
	if(pStr == BrNULL || *pStr == 0 )
		return 0;
	BrCHAR ch, *lptr = (BrCHAR*)pStr;
	BrBOOL bDigit = BrFALSE;
	
	do
	{
		ch = *lptr;	
		if (IsDigit(ch)) {
			if ( *(lptr - 1) == '-')
				*lptr--;
			bDigit = BrTRUE;
			break;
		}
	}while (*lptr++);

	if( !bDigit )
		return 0;

	char * pEnd=NULL;
	long int ret = strtol (lptr,&pEnd,10);
	return (BrINT32)ret;
}
BrINT32 BrAtoi(const BrCHAR *pStr)
{
	if(pStr == BrNULL)
		return 0;

	//secure coding
	char * pEnd=NULL;
	BrINT32 ret1 = (BrINT32)strtol (pStr,&pEnd,10);
#if 1//def _DEBUG	//_DEBUG�� ���� Ȯ���Ͽ� �߸� ����ϴ� ��ġ Ȯ��
	BrCHAR ch, *lptr = (BrCHAR*)pStr;
	BrINT32 result = 0;	
	BrBOOL bNinus = 0;
	BrBOOL bDigit = BrFALSE;
	BrINT32 nLen = BrStrLen(pStr);
	
	if(nLen == 0) return 0;
	
	do
	{
		ch = *lptr;	
		if (ch == '-')
			bNinus = 1;
		if (IsDigit(ch)) {
			bDigit = BrTRUE;//hnsong:2012-02-20
			break;
		}
	}while (*lptr++);

	if( !bDigit )
		return 0;

	for(ch = *lptr; lptr && IsDigit(ch); lptr++, ch = *lptr)
	{
		result *= 10; 

		if( ch >= '0' && ch <= '9')
			result += ch - '0'; 
	}

	BrINT32 ret2 = (bNinus?-result:result);
//	if ( ret1 != ret2 )
//		BRTHREAD_DEBUG_INTERRUPT;
#endif
	return ret2;
}


BrINT32 BrWtoi( const BrWCHAR *string )
{ 
	if(string==NULL) return 0;

	BrWCHAR ch;
	BrWCHAR *p1 = (BrWCHAR*) string;
	BrINT32 result = 0;	
	BrBOOL bNinus = 0;

	do
	{
		ch = *p1;	
		if (ch == '-')
			bNinus = 1;
		if (IsDigit(ch))
			break;
	}while (*p1++);

	for(ch = *p1; p1 && IsDigit( ch ); p1++ , ch = *p1 )
	{
		result *= 10; 

		if( ch >= 0x30 && ch <= 0x39 )
			result += ch - 0x30; 
	}

	return (bNinus?-result:result);
}

BrLONG BrAtol(const BrCHAR *pStr)
{
	if(pStr==NULL) return 0;

	//secure coding
	char * pEnd=NULL;
	BrLONG ret1 = (BrLONG)strtol (pStr,&pEnd,10);
#if 1//def _DEBUG	//_DEBUG�� ���� Ȯ���Ͽ� �߸� ����ϴ� ��ġ Ȯ��
	BrCHAR ch;
	BrCHAR *lptr = (BrCHAR*)pStr;
	BrLONG result = 0;
	BrBOOL bNinus = 0;
	do
	{
		ch = *lptr;	
		if (ch == '-')
			bNinus = 1;
		if (IsDigit(ch))
			break;
	}while (*lptr++);

	for(ch = *lptr; lptr && IsDigit(ch); lptr++, ch = *lptr)
	{
		result *= 10; 

		if( ch >= '0' && ch <= '9')
			result += ch - '0'; 
	}

	BrLONG ret2 = (bNinus?-result:result);
//	if ( ret1 != ret2 )
//		BRTHREAD_DEBUG_INTERRUPT;
#endif
	return ret2;
}

BrINT64 BrAtoll(const BrCHAR *pStr)
{
	if(pStr==NULL) return 0;

	//secure coding
	char * pEnd=NULL;
#ifdef WIN32
	BrINT64 ret1 = (BrINT64)_strtoi64 (pStr,&pEnd,10);
#else
	BrINT64 ret1 = (BrINT64)strtoll (pStr,&pEnd,10);
#endif
	
#if 1//def _DEBUG	//_DEBUG�� ���� Ȯ���Ͽ� �߸� ����ϴ� ��ġ Ȯ��
	BrCHAR ch;
	BrCHAR *lptr = (BrCHAR*)pStr;
	BrINT64 result = 0;
	BrBOOL bNinus = 0;

	do
	{
		ch = *lptr;	
		if (ch == '-')
			bNinus = 1;
		if (IsDigit(ch))
			break;
	}while (*lptr++);

	for(ch = *lptr; lptr && IsDigit(ch); lptr++, ch = *lptr)
	{
		result *= 10; 

		if( ch >= '0' && ch <= '9')
			result += ch - '0'; 
	}

	BrINT64 ret2 = (bNinus?-result:result);
//	if ( ret1 != ret2 )
//		BRTHREAD_DEBUG_INTERRUPT;
#endif
	return ret2;
}

BrLONG BrWtol( const BrWCHAR *string )
{
	if(string==NULL) return 0;
	BrWCHAR ch;
	BrWCHAR	*p1 = (BrWCHAR*) string;
	BrLONG result = 0;	
	BrBOOL bNinus = 0;

	do
	{
		ch = *p1;	
		if (ch == '-')
			bNinus = 1;
		if (IsDigit(ch))
			break;
	}while (*p1++);
	
	for(ch = *p1; p1 && IsDigit( ch ); p1++ , ch = *p1 )
	{
		result *= 10; 

		if( ch >= 0x30 && ch <= 0x39 )
			result += ch - 0x30; 
	}

	return (bNinus?-result:result);
}

BrINT32 BrAtoX(BrCHAR *pStr)
{ 
	if(pStr==NULL) return 0;
	BrCHAR ch;
	BrCHAR *lptr = pStr;
	BrINT32 result = 0;	
	BrBOOL bNinus = 0;

	do
	{
		ch = *lptr;	
		if (ch == '-')
			bNinus = 1;
		if (IsXDigit(ch))
			break;
	}while (*lptr++);
		
	for(ch = *lptr; lptr && IsXDigit(ch); lptr++, ch = *lptr)
	{
		result *= 16; 

		if( ch >= '0' && ch <= '9')
			result += ch - '0'; 
		else if( ch >= 'A' && ch <= 'F')
			result += ch - 'A' + 10; 
		else if( ch >= 'a' && ch <= 'f')
			result += ch - 'a' + 10; 
	}

	return (bNinus?-result:result);
}

BrINT32 BrWtoX(BrWCHAR *pStr)
{ 
	if(pStr==NULL) return 0;

	BrWCHAR ch;
	BrWCHAR	*lptr = pStr;
	BrINT32 result = 0;	
	BrBOOL bNinus = 0;
	do
	{
		ch = *lptr;	
		if (ch == '-')
			bNinus = 1;
		if (IsXDigit(ch))
			break;
	}while (*lptr++);
	
	for(ch = *lptr; lptr && IsXDigit(ch); lptr++, ch = *lptr)
	{
		result *= 16; 

		if( ch >= '0' && ch <= '9')
			result += ch - '0'; 
		else if( ch >= 'A' && ch <= 'F')
			result += ch - 'A' + 10; 
		else if( ch >= 'a' && ch <= 'f')
			result += ch - 'a' + 10; 
	}

	return (bNinus?-result:result);
}

void BrXtoa(   BrULONG val, char *buf, unsigned radix, int is_neg )
{
        char *p;                /* pointer to traverse string */
        char *firstdig;         /* pointer to first digit */
        char temp;              /* temp char */
        unsigned digval;        /* value of digit */

        p = buf;

        if (is_neg) {
            /* negative, so output '-' and negate */
            *p++ = '-';
            val = (BrULONG)(-(BrLONG)val);
        }

        firstdig = p;           /* save pointer to first digit */

        do {
            digval = (unsigned) (val % radix);
            val /= radix;       /* get next digit */

            /* convert to ascii and store */
            if (digval > 9)
                *p++ = (char) (digval - 10 + 'a');  /* a letter */
            else
                *p++ = (char) (digval + '0');       /* a digit */
        } while (val > 0);

        /* We now have the digit of the number in the buffer, but in reverse
           order.  Thus we reverse them now. */

        *p-- = '\0';            /* terminate string; p points to last digit */

        do {
            temp = *p;
            *p = *firstdig;
            *firstdig = temp;   /* swap *p and *firstdig */
            --p;
            ++firstdig;         /* advance to next two digits */
        } while (firstdig < p); /* repeat until halfway */
}

void BrXtow(   BrULONG val, BrWCHAR *buf, unsigned radix, int is_neg )
{
        BrWCHAR *p;                /* pointer to traverse string */
        BrWCHAR *firstdig;         /* pointer to first digit */
        BrWCHAR temp;              /* temp char */
        unsigned digval;        /* value of digit */

        p = buf;

        if (is_neg) {
            /* negative, so output '-' and negate */
            *p++ = '-';
            val = (BrULONG)(-(BrLONG)val);
        }

        firstdig = p;           /* save pointer to first digit */

        do {
            digval = (unsigned) (val % radix);
            val /= radix;       /* get next digit */

            /* convert to ascii and store */
            if (digval > 9)
                *p++ = (BrWCHAR) (digval - 10 + 'a');  /* a letter */
            else
                *p++ = (BrWCHAR) (digval + '0');       /* a digit */
        } while (val > 0);

        /* We now have the digit of the number in the buffer, but in reverse
           order.  Thus we reverse them now. */

        *p-- = '\0';            /* terminate string; p points to last digit */

        do {
            temp = *p;
            *p = *firstdig;
            *firstdig = temp;   /* swap *p and *firstdig */
            --p;
            ++firstdig;         /* advance to next two digits */
        } while (firstdig < p); /* repeat until halfway */
}

BrCHAR * BrItoa( int val, BrCHAR *buf,int radix )
{
        if (radix == 10 && val < 0)
            BrXtoa((BrULONG)val, buf, radix, 1);
        else
            BrXtoa((BrULONG)(unsigned int)val, buf, radix, 0);
        return buf;
}

BrWCHAR * BrItow( int val, BrWCHAR *buf,int radix )
{
        if (radix == 10 && val < 0)
            BrXtow((BrULONG)val, buf, radix, 1);
        else
            BrXtow((BrULONG)(unsigned int)val, buf, radix, 0);
        return buf;
}

//
// sheet ���� ���� ������ ȣȯ���� ����, 
// ǥ�� �Լ� ��� ��ü �Լ��� ��� ����ϴ� ���·� ����
// 
// https://confluence.infraware.net:8443/pages/viewpage.action?pageId=34464166 
//
BrDOUBLE BrAtof(const BrCHAR* pStr)
{
	BrDOUBLE ret2 = BrStrtod(pStr, NULL);

#if 0 // �߸� ����ϴ� ��ġ Ȯ�ο�
	char* _EndPtr = NULL;
	BrDOUBLE ret1 = strtod(pStr, &_EndPtr);
	if (ret1 != ret2)
		BRTHREAD_DEBUG_INTERRUPT;
#endif

	return ret2;
}

BrUINT32 BrToLatinLower(BrUINT16 ch)
{
	// Latin ������ ��ҹ��� �� �߰�. 2013.03.11. #14041
	switch(ch)
	{
	case 0x102:
	case 0x104:
	case 0x106:
	case 0x108:
	case 0x10a:
	case 0x10c:
	case 0x10e:
	case 0x110:			// Latin Small Letter D With Stroke
	case 0x112:
	case 0x114:
	case 0x116:
	case 0x118:
	case 0x11a:
	case 0x11c:
	case 0x11e:
	case 0x120:
	case 0x124:
	case 0x126:
	case 0x128:
	case 0x12a:
	case 0x12c:
	case 0x12e:

	case 0x168:
	case 0x1a0:
	case 0x1af:


	case 0x1ea0:
	case 0x1ea2:
	case 0x1ea4:
	case 0x1ea6:
	case 0x1ea8:
	case 0x1eaa:
	case 0x1eac:
	case 0x1eae:
	case 0x1eb0:
	case 0x1eb2:
	case 0x1eb4:
	case 0x1eb6:
	case 0x1eb8:
	case 0x1eba:
	case 0x1ebc:
	case 0x1ebe:
	case 0x1ec0:
	case 0x1ec2:
	case 0x1ec4:
	case 0x1ec6:
	case 0x1ec8:
	case 0x1eca:
	case 0x1ecc:
	case 0x1ece:

	case 0x1ed0:		// Latin Capital Letter O with Circumflex And Acute
	case 0x1ed2:
	case 0x1ed4:
	case 0x1ed6:
	case 0x1ed8:
	case 0x1eda:
	case 0x1edc:
	case 0x1ede:
	case 0x1ee0:
	case 0x1ee2:
	case 0x1ee4:
	case 0x1ee6:
	case 0x1ee8:
	case 0x1eea:
	case 0x1eec:
	case 0x1eee:
	case 0x1ef0:
	case 0x1ef2:
	case 0x1ef4:
	case 0x1ef6:
	case 0x1ef8:	ch = ch+1;	break;	// Latin Capital Letter With Stroke

	case 0xc0:		ch = 0xe0;	break;
	case 0xc1:		ch = 0xe1;	break;
	case 0xc2:		ch = 0xe2;	break;
	case 0xc3:		ch = 0xe3;	break;
	case 0xc8:		ch = 0xe8;	break;
	case 0xc9:		ch = 0xe9;	break;
	case 0xca:		ch = 0xea;	break;
	case 0xcc:		ch = 0xec;	break;
	case 0xcd:		ch = 0xed;	break;

	case 0xd2:		ch = 0xf2;	break;
	case 0xd3:		ch = 0xf3;	break;
	case 0xd4:		ch = 0xf4;	break;
	case 0xd5:		ch = 0xf5;	break;
	case 0xd9:		ch = 0xf9;	break;
	case 0xda:		ch = 0xfa;	break;
	case 0xdd:		ch = 0xfd;	break;
	}

	return ch;
}

BrUINT16 BrToLower(BrUINT16 ch)
{
	if(ch >= 'A' && ch <= 'Z')
		ch = (ch-'A') +'a';
	else
		ch = BrToLatinLower(ch);
	return ch;
}

BrUINT16 BrToUpper(BrUINT16 ch)
{
	if(ch >= 'a' && ch <= 'z')
		ch = (ch-'a') +'A';
	return ch;
}

BrBOOL BrIsUpper(BrCHAR ch)
{
	if((ch)>='A' && (ch) <='Z')
		return true;
	return false;
}

BrBOOL BrIsLower(BrCHAR ch)
{
	if((ch)>='a' && (ch) <='z')
		return true;
	return false;
}

BrUINT16 BrToLower(BrUINT16 ch, BrBOOL a_bUseLocaleStr)
{
	if(ch >= 'A' && ch <= 'Z')
		ch = (ch-'A') +'a';
	// A ~ ��: 1040 ~ 1071 - 2011.04.13 offi R/D2 rabetgu
	else if(a_bUseLocaleStr && ch >= RUS_UPPER_START && ch <= RUS_UPPER_END)
		ch = (ch-RUS_UPPER_START) + RUS_LOWER_START;
	else
		ch = BrToLatinLower(ch);

	return ch;
}

BrUINT16 BrToUpper(BrUINT16 ch, BrBOOL a_bUseLocaleStr)
{
	if(ch >= 'a' && ch <= 'z')
		ch = (ch-'a') +'A';
	// ��~ ��: 1072 ~ 1103 - 2011.04.13 offi R/D2 rabetgu
	else if(a_bUseLocaleStr && ch >= RUS_LOWER_START && ch <= RUS_LOWER_END)
		ch = (ch-RUS_LOWER_START) + RUS_UPPER_START;

	return ch;
}

BrBOOL BrIsUpper(BrCHAR ch, BrBOOL a_bUseLocaleStr)
{
	if((ch)>='A' && (ch) <='Z')
		return true;
	// ��~ ��: 1072 ~ 1103 - 2011.04.13 offi R/D2 rabetgu
	else if(a_bUseLocaleStr && (ch)>= RUS_UPPER_START && (ch) <= RUS_UPPER_END)
		return true;

	return false;
}

BrBOOL BrIsLower(BrCHAR ch, BrBOOL a_bUseLocaleStr)
{
	if((ch)>='a' && (ch) <='z')
		return true;
	// ��~ ��: 1072 ~ 1103 - 2011.04.13 offi R/D2 rabetgu
	else if(a_bUseLocaleStr && (ch)>= RUS_LOWER_START && (ch) <= RUS_LOWER_END)
		return true;

	return false;
}

BrCHAR* BrStrdup(const BrCHAR* pStr)
{
	BrCHAR* pRet = BrNULL;
	if(pStr)
	{
		BrINT nLen = BrStrLen(pStr);
		if(nLen)
		{
			pRet = (BrCHAR*)BrMalloc(nLen+1);
			if(pRet)
			{
				memcpy(pRet, pStr, nLen);
				pRet[nLen] = '\0';
			}
		}
	}
	return pRet;
}

//BrCHAR *BrStrCpy(BrCHAR *strDest, const BrCHAR *strSource, int nDestBufferLen)
//{
//	strncpy_s(strDest, nDestBufferLen+1, strSource, nDestBufferLen);
//	BRTHREAD_ASSERT(strDest[nDestBufferLen - 1] != 0xcc);	// [2016.06.08][donny] ���⼭ assert�� �ɸ��� buffer overrun�� �� ������, ���� check �� ��!!!!!!!!!
//	strDest[nDestBufferLen - 1] = '\0';		// strSource length�� count ���� ū ��� ������ null terminate ����
//	return strDest;
//}
//
//BrCHAR *BrStrCat(BrCHAR *strDest, const BrCHAR *strSource, int nDestBufferLen)
//{
//	//�ϱ� �ڵ忡�� ASSERT�� �߻��ϴ� ��� ������ �ִ� �ڵ�� �����ϱ� �ٶ�
//	BrINT nDstStrLen = BrStrLen(strDest);
//	BRTHREAD_ASSERT(nDstStrLen<nDestBufferLen);
//	if(nDstStrLen>=nDestBufferLen)
//		return strDest;
//	nDstStrLen = nDestBufferLen-nDstStrLen;
//#ifdef WIN32
//	BRTHREAD_ASSERT(nDstStrLen>BrStrLen(strSource));
//#endif //WIN32
//	strncat_s(strDest, nDstStrLen+1, strSource, nDstStrLen);
//	BRTHREAD_ASSERT(strDest[nDestBufferLen - 1] != 0xcc);	// [2016.06.08][donny] ���⼭ assert�� �ɸ��� buffer overrun�� �� ������, ���� check �� ��!!!!!!!!!
//	strDest[nDestBufferLen - 1] = '\0';		// strSource length�� count ���� ū ��� ������ null terminate ����
//	return strDest;
//}
//
//int BrSprintf(BrCHAR *buffer, int nMaxBufferLen, const BrCHAR *format, ...)
//{
//	va_list ap;
//
//	va_start(ap, format);
//
//	int nLen = vsnprintf_s(buffer, nMaxBufferLen, nMaxBufferLen-1, format, ap);
//
//	va_end(ap);
//
//	return nLen;
//}

//getenv�� ��ü�Ͽ� secure coding
//static ������ ���� ó���� �ʿ���
#undef getenv
char* POgetenv(const char* pValue)
{
	static char* pOutput=NULL;
	if ( pOutput )
		free(pOutput);
#ifdef WIN32
	size_t len = 0;
	_dupenv_s(&pOutput, &len, pValue);
#else
   pOutput = getenv(pValue);
#endif
   return pOutput;
}

//strerror�� ��ü�Ͽ� _s�Լ��� ȣ��
//static������ ���� ũ�⸦ ����� �־� ��Ȱ���ϰ� fee���� 
#undef strerror
extern	char *	POstrerror(int errnum)
{
	size_t errmsglen = 1024*10;
	static char errmsg[1024*10]; 
	memset(errmsg, 0, errmsglen);
#ifdef WIN32
    strerror_s(errmsg, errmsglen, errno);
#else
	strerror_r(errnum, errmsg, errmsglen);
#endif
	return errmsg;
}

BrBOOL BrStrHasPrefix(const BrCHAR* const self, const BrCHAR* const patt)
{
	__BrExitOn(!self, BrFALSE);
	__BrExitOn(!patt, BrFALSE);
	__BrExitOn(self == patt, BrTRUE);

	BrINT self_len = BrStrLen(self);
	BrINT patt_len = BrStrLen(patt);
	__BrExitOn(self_len < patt_len, BrFALSE);

	size_t min_len = BrMIN(self_len, patt_len);

	return !memcmp(self, patt, min_len);
}

BrBOOL BrStrHasSuffix(const BrCHAR* const self, const BrCHAR* const patt)
{
	__BrExitOn(!self, BrFALSE);
	__BrExitOn(!patt, BrFALSE);

	BrINT self_len = BrStrLen(self);
	BrINT patt_len = BrStrLen(patt);
	__BrExitOn(self_len < patt_len, BrFALSE);

	size_t min_len = BrMIN(self_len, patt_len);

	const BrCHAR* const self_off = self + self_len - min_len;
	const BrCHAR* const patt_off = patt + patt_len - min_len;

	return !memcmp(self_off, patt_off, min_len);
}

const BrCHAR* BrStrSkipIf(const BrCHAR* str, bool (*pred)(const BrCHAR ch))
{
	while (*str && pred(*str)) str++;
	return str;
}

const BrCHAR* BrStrLTrim(const BrCHAR* str)
{
	bool (*pred)(const BrCHAR) = [](const BrCHAR ch) {
		return ch == 0x20 || (0x09 <= ch && ch <= 0x0D);
	};

	return BrStrSkipIf(str, pred);
}

void BrMemset16(BrUINT16* pDst, BrUINT16 nValue, BrINT nCount)
{
	if ( isSimdEngine() )
	{
		br_memset16_simd(pDst, nValue, nCount);
		return;
	}
	else
	{
#if defined(__arm__) && !(defined(USE_FOR_IOS) || defined(__clang__))
		br_memset16_arm(pDst, nValue, nCount);
		return;
#endif //__arm__
	}
	BrINT nSeg = BR_MEMSET_SEG;
	BrINT nQuotient = nCount/nSeg;
	BrINT nRemainder = nCount%nSeg;

	if(nQuotient > 1)	
	{
		BrINT nSegIndex = 0, nSegSize = nSeg*sizeof(BrINT16);
		BrUINT16* pSegPtr = pDst;
		do 
		{
			*pDst++ = nValue; 
		} while(--nSeg);
		--nQuotient;
		do 
		{
			memcpy((BrCHAR*)pDst, (BrCHAR*)pSegPtr, nSegSize);
			pDst+=BR_MEMSET_SEG;
		} while(--nQuotient);
	}
	else
		nRemainder = nCount;

	while(nRemainder--)
		*pDst++ = nValue;
}

void BrMemset24(LPBr3BYTE pDst, Br3BYTE nValue, BrINT nCount)
{
	BrINT nSeg = BR_MEMSET_SEG;
	BrINT nQuotient = nCount/nSeg;
	BrINT nRemainder = nCount%nSeg;

	if(nQuotient > 1)	
	{
		BrINT nSegIndex = 0, nSegSize = nSeg*sizeof(Br3BYTE);
		LPBr3BYTE pSegPtr = pDst;
		do 
		{
			*pDst++ = nValue; 
		} while(--nSeg);
		--nQuotient;
		do 
		{
			memcpy(pDst, pSegPtr, nSegSize);
			pDst+=BR_MEMSET_SEG;
		} while(--nQuotient);
	}
	else
		nRemainder = nCount;

	while(nRemainder--)
		*pDst++ = nValue;
}

void BrMemset32(BrUINT32* pDst, BrUINT32 nValue, BrINT nCount)
{
	if ( isSimdEngine() )
	{
		br_memset32_simd(pDst, nValue, nCount);
		return;
	}
	else
	{
#if defined(__arm__) && !(defined(USE_FOR_IOS) || defined(__clang__))
		br_memset32_arm(pDst, nValue, nCount);
		return;
#endif //__arm__
	}
	BrINT nSeg = BR_MEMSET_SEG;
	BrINT nQuotient = nCount/nSeg;
	BrINT nRemainder = nCount%nSeg;

	if(nQuotient > 1)	
	{
		BrINT nSegIndex = 0, nSegSize = nSeg*sizeof(BrINT);
		BrUINT* pSegPtr = pDst;
		do 
		{
			*pDst++ = nValue; 
		} while(--nSeg);
		--nQuotient;
		do 
		{
			memcpy(pDst, pSegPtr, nSegSize);
			pDst+=BR_MEMSET_SEG;
		} while(--nQuotient);
	}
	else
		nRemainder = nCount;

	while(nRemainder--)
		*pDst++ = nValue;	
}

extern "C" void POSetTotalMemorySizes(unsigned long long nSize)
{
	if ( g_pBInterfaceHandle )
		g_pBInterfaceHandle->SetTotalMemorySizes(nSize);
}

#if defined(_WIN32)
#include <Windows.h>

#elif defined(__unix__) || defined(__unix) || defined(unix) || (defined(__APPLE__) && defined(__MACH__))
#include <unistd.h>
#include <sys/types.h>
#include <sys/param.h>
#if defined(BSD)
#include <sys/sysctl.h>
#endif
#if defined(__APPLE__)
#include "MemoryStatus.h"
#endif
#endif

/*
*	@author 	Andrew
*	@date  		2016.11.02
#	@return 	unsigned long long : ���� �޸� ũ��
*	@brief  	�ý����� ���� �޸𸮸� ��� �´�.
*	@source		http://nadeausoftware.com/articles/2012/09/c_c_tip_how_get_physical_memory_size_system
*/
unsigned long long PoGetAvailableMemorySizes()
{
	//ui���� ������ ũ�⸦ ������ ��� �� ���� ����Ѵ�.
	unsigned long long nSize = g_pBInterfaceHandle->GetTotalMemorySizes();
	if ( nSize > 0 )
		return nSize;

#if defined(_WIN32) && (defined(__CYGWIN__) || defined(__CYGWIN32__))
	/* Cygwin under Windows. ------------------------------------ */
	/* New 64-bit MEMORYSTATUSEX isn't available.  Use old 32.bit */
	MEMORYSTATUS status = {0,};
	status.dwLength = sizeof(status);
	GlobalMemoryStatus( &status );
	return (unsigned long long)status.dwAvailVirtual;

#elif defined(_WIN32)
	/* Windows. ------------------------------------------------- */
	/* Use new 64-bit MEMORYSTATUSEX, not old 32-bit MEMORYSTATUS */
	MEMORYSTATUSEX status = {0,};
	status.dwLength = sizeof(status);
	GlobalMemoryStatusEx( &status );
	return (unsigned long long)status.ullAvailVirtual;

#elif defined(__unix__) || defined(__unix) || defined(unix) || (defined(__APPLE__) && defined(__MACH__))
	/* UNIX variants. ------------------------------------------- */
	/* Prefer sysctl() over sysconf() except sysctl() HW_REALMEM and HW_PHYSMEM */

	//�ý��� ȣ���� ���� �־ ó�� �ȵ�.
	#if defined (__ANDROID__)
//jniȣ�� ���
		//multi-core���� ȣ��� jni�Լ����� crash�� �߻��Ͽ� ����, �������� ���� �����带 �� �� jniȣ�⿡ ���� ���� �ʿ�
		if (BrIsMasterThread())
			return (unsigned long long)Po_Pl_GetAvailableMemorySizes();
		return gpMemPool->m_available_memory_size;
    #elif defined(__APPLE__)
    
        return (unsigned long long)get_free_memory();
    
	#elif defined(CTL_HW) && (defined(HW_USERMEM) || defined(HW_USERMEM64))
		int mib[2];
		mib[0] = CTL_HW;
		#if defined(HW_USERMEM)
			mib[1] = HW_MEMSIZE;            /* OSX. --------------------- */
		#elif defined(HW_USERMEM64)
			mib[1] = HW_USERMEM64;          /* NetBSD, OpenBSD. --------- */
		#endif
		int64_t size = 0;               /* 64-bit */
		size_t len = sizeof( size );
		if ( sysctl( mib, 2, &size, &len, NULL, 0 ) == 0 )
			return (unsigned long long)size;

	//Andrew C.Lee _SC_AVPHYS_PAGES�� ��� ��Ȯ�� ���� �޸𸮰� �ƴϾ linuxȯ���� ��ü �޸𸮸� �����ϵ��� ����
	//�ٸ� �Լ��� ����ϴ� ��� overhead�� ����� �־ ������ ������ �����
	#elif defined(_SC_PHYS_PAGES) && defined(_SC_PAGESIZE)
		/* FreeBSD, Linux, OpenBSD, and Solaris. -------------------- */
		return (unsigned long long)sysconf( _SC_PHYS_PAGES ) *
			(unsigned long long)sysconf( _SC_PAGESIZE );

	#elif defined(_SC_PHYS_PAGES) && defined(_SC_PAGE_SIZE)
		/* Legacy. -------------------------------------------------- */
		return (unsigned long long)sysconf( _SC_PHYS_PAGES ) *
			(unsigned long long)sysconf( _SC_PAGE_SIZE );
	
	//#elif defined(_SC_AIX_REALMEM)
	//	/* AIX. ----------------------------------------------------- */
	//	return (unsigned long long)sysconf( _SC_AIX_REALMEM ) * (size_t)1024L;

	#elif defined(_SC_AVPHYS_PAGES) && defined(_SC_PAGESIZE)
		/* FreeBSD, Linux, OpenBSD, and Solaris. -------------------- */
		return (unsigned long long)sysconf( _SC_AVPHYS_PAGES ) *
			(unsigned long long)sysconf( _SC_PAGESIZE );

	#elif defined(_SC_AVPHYS_PAGES) && defined(_SC_PAGE_SIZE)
		/* Legacy. -------------------------------------------------- */
		return (unsigned long long)sysconf( _SC_AVPHYS_PAGES ) *
			(unsigned long long)sysconf( _SC_PAGE_SIZE );

//	#elif defined(CTL_HW) && (defined(HW_PHYSMEM) || defined(HW_REALMEM))
//		/* DragonFly BSD, FreeBSD, NetBSD, OpenBSD, and OSX. -------- */
//		int mib[2];
//		mib[0] = CTL_HW;
//		#if defined(HW_REALMEM)
//			mib[1] = HW_REALMEM;		/* FreeBSD. ----------------- */
//		#elif defined(HW_PYSMEM)
//			mib[1] = HW_PHYSMEM;		/* Others. ------------------ */
//		#endif
//		unsigned int size = 0;		/* 32-bit */
//		size_t len = sizeof( size );
//		if ( sysctl( mib, 2, &size, &len, NULL, 0 ) == 0 )
//			return (unsigned long long)size;
//		return 0L;			/* Failed? */
	#endif /* sysctl and sysconf variants */

#endif
	return 0L;			/* Unknown OS. */
}

int _POCBCheckBackupFilePath(const char* pFilePath)
{
#ifdef _WIN32
	BRCONTEXT;
	return MakeOSCall<int>(Brcontext, POCBCheckBackupFilePath, pFilePath);
#endif
	return 0;
}

void BrSleep( BrULONG milliseconds ) 
{
	BSleep(milliseconds);
}

void AdjustPathSeparator(BrCHAR *pFilePath)
{
	if( !pFilePath ) return;

	BrINT32 i, nCount = BrStrLen(pFilePath);
	for(i=0; i<nCount; i++)
	{
		if( pFilePath[i]=='\\' ) 
			pFilePath[i]='/';
	}
}

void CopyAdjustPathSeparator(BrCHAR *path_new, int path_new_length,
							 const char *path_old)
{
	if (!path_new || !path_old)
		return;

	memset(path_new, 0, path_new_length);
	strncpy_s(path_new, path_new_length, path_old, strlen(path_old));
	AdjustPathSeparator(path_new);
}

BrBOOL BrGetFileNameFromPath(BrCHAR* pFullPath, BrCHAR* pFileName, int pFileNameSize)
{
	if(pFullPath && pFileName)
	{
		AdjustPathSeparator(pFullPath);
		BrCHAR* pFind = strrchr(pFullPath,'/');
		if(pFind && pFind[1] != '\0')
		{
			BrINT nLen = BrStrLen(pFind)-1;
			pFind ++;
			memset(pFileName, 0, pFileNameSize);
			strncpy_s(pFileName, pFileNameSize, pFind, strlen(pFind));
			return BrTRUE;
		}
	}

	return BrFALSE;
}

BrBOOL BrReplaceFileNameFromPath(BrCHAR* pFullPath, int pFullPathSize, BrCHAR* pFileName)
{
	if(pFullPath && pFileName)
	{
		AdjustPathSeparator(pFullPath);
		BrCHAR* pFind = strrchr(pFullPath,'/');
		if(pFind && pFind[1] != '\0')
		{
			BrINT nLen_find = BrStrLen(pFind)-1;
			BrINT nLen_path = BrStrLen(pFullPath);
			BrINT nLen_directory = nLen_path - nLen_find;
			pFullPath[nLen_directory] = '\0';
			strncat_s(pFullPath, pFullPathSize, pFileName, strlen(pFileName));
			return BrTRUE;
		}
	}

	return BrFALSE;
}

extern const BrCHAR* trimNamespace(const BrCHAR* pName)
{
	BrCHAR* pNewPtr = (BrCHAR*)pName + BrStrLen(pName);
	while(pName < --pNewPtr )
	{
		if( *pNewPtr==':' )
			return pNewPtr+1;
	}

	return pName;
}

BrBOOL CanUseScreenBufferForTmpMemory(Painter* pPainter)
{
	if( !pPainter )
		return BrFALSE;

	BRCONTEXT;

#ifdef SINGLE_SCREEN_BUFFER
	if (Brcontext.m_GeneralValue.nScreenBufferType == SCREEN_BUF_ONE)
		return BrFALSE;
#endif

	return BrTRUE;
}

PrBitmap* BoraScreenBitmapPtr()
{
	Painter* pPainter = getPainter();

	if( !CanUseScreenBufferForTmpMemory(pPainter) )
		return BrNULL;

	return &pPainter->pageImg.m_ScreenBitmap;
}

//freetype ���� file i/o porting layer
//windowsȯ�濡�� fopen�� ��Ƽ����Ʈ�� open�ϴµ� �Է��� utf8�� �ޱ� ������ unicode�� ��ȯ�Ͽ� wfopen�� ����ϵ��� ����
FILE* POfopen(const char* pFilePath, const char *in_mode)
{
	// BTrace("%s(%d) %s pFilePath[%s] in_mode[%s]", __FILE__, __LINE__, __FUNCTION__, pFilePath, in_mode);
	FILE *fp = NULL;
#ifdef _WIN32

	WCHAR* wPath = BrNULL;
	std::unique_ptr<WCHAR, std::function<void(WCHAR*)> > auto_buffer_path(
		(WCHAR*)FindSysAllocPtr(sizeof(BrUSHORT)*(strlen(pFilePath)+1))
		, [](WCHAR* p) { 
		FindSysFreePtr(p);
	});
	wPath = auto_buffer_path.get();
	int nLen = BrMultiByteToWideChar(CP_UTF8, pFilePath, strlen(pFilePath), wPath, strlen(pFilePath)+1);
	if ( nLen > 0 )
		wPath[nLen] = '\0';

	WCHAR* wMode = BrNULL;
	std::unique_ptr<WCHAR, std::function<void(WCHAR*)> > auto_buffer_mode(
		(WCHAR*)FindSysAllocPtr(sizeof(BrUSHORT)*(strlen(in_mode)+1))
		, [](WCHAR* p) { 
		FindSysFreePtr(p);
	});
	wMode = auto_buffer_mode.get();
	nLen = BrMultiByteToWideChar(CP_UTF8, in_mode, strlen(in_mode), wMode, strlen(in_mode)+1);
	if ( nLen > 0 )
		wMode[nLen] = '\0';
	_wfopen_s(&fp, wPath, wMode);
#else
	fp = (FILE*)fopen(pFilePath, in_mode);
#endif
	if ( !fp )
	{
		int nError = (int)errno;
		char msg[1024] = { 0, };
		_snprintf_s(msg, sizeof(msg), sizeof(msg) - 1, "file open fail! errno[%d]", nError);
		//ENFILE	Too many files open in system	23
		//EMFILE	Too many open files	24
		if (nError == 23 || nError == 24)
			BRTERMINATE(kPoErrFileOpen, msg, PO_PUBLIC_CLASS);
		else
			SET_ERROR_LOG(kPoErrFileOpen, msg, false);
	}
	else
	{
		BString fileString = CUtil::UTF8ToBString(pFilePath);
		g_pBInterfaceHandle->getFileManager()->fileRegister(fileString, fp, PO_FILE_OPEN, CUtil::UTF8ToBString(in_mode), true);
	}
	return fp;
}
int POfclose( FILE * pFile )
{
	if (g_pBInterfaceHandle && g_pBInterfaceHandle->getFileManager())
		g_pBInterfaceHandle->getFileManager()->changeStatus(pFile, PO_FILE_CLOSE);
	return fclose(pFile);
}
int POfread(void *ptr, int item, int size, FILE* pFile)
{
	return fread(ptr, item, size, pFile);
}
int POfseek(FILE* pFile, long pos, int type)
{
	return fseek(pFile, pos, type);
}
int POftell(FILE* pFile)
{
	return ftell(pFile);
}

#include "memoryFile.h"
void AddExceptFileList(const char* pFilePath)
{
	if ( pFilePath == BrNULL || !strcmp(pFilePath, "") )
		return;
	BSysArray<BrCHAR*>	*pExceptFileList = BrNULL;
#ifdef NOT_USE_GLOBAL_VARIABLE
	BInterfaceHandle * pHandle = g_pBInterfaceHandle;
	if(!pHandle)
		return;
	if ( !pHandle->m_ExceptFileList )
		pHandle->m_ExceptFileList = BrNEW BSysArray<BrCHAR*>;
	pExceptFileList = pHandle->m_ExceptFileList;
#endif //NOT_USE_GLOBAL_VARIABLE				

	if ( !pExceptFileList )
		return;
	BrBOOL bAdd = BrTRUE;		
	for (int n=0;n<pExceptFileList->size();n++)
	{
		if ( !strcmp(pFilePath, (char*)*pExceptFileList->getAt(n)) )
		{
			bAdd = BrFALSE;
			break;
		}
	}
	if ( bAdd )
	{
		BrCHAR* pFileName = (BrCHAR*)BMalloc(strlen(pFilePath)+1);
		memset(pFileName, 0, strlen(pFilePath)+1);
		strncpy_s(pFileName, strlen(pFilePath)+1, pFilePath, strlen(pFilePath));
		pExceptFileList->add(pFileName);
	}
}

BrBOOL IsExceptFile(const char* pFilePath)
{
	BrBOOL bRet = BrFALSE;
	BSysArray<BrCHAR*>	*pExceptFileList = BrNULL;
#ifdef NOT_USE_GLOBAL_VARIABLE
	BInterfaceHandle * pHandle = g_pBInterfaceHandle;
	if(!pHandle)
		return bRet;
	if ( !pHandle->m_ExceptFileList )
		pHandle->m_ExceptFileList = BrNEW BSysArray<BrCHAR*>;
	pExceptFileList = pHandle->m_ExceptFileList;	
#endif //NOT_USE_GLOBAL_VARIABLE				

	if ( !pExceptFileList )
		return bRet;
	char* pFileName;
	for (int n=0;n<pExceptFileList->size();n++)
	{
		pFileName = (char*)*pExceptFileList->getAt(n);
		if ( !strcmp(pFilePath, pFileName) )
		{
			bRet = BrTRUE;
			break;
		}
	}
	if (!bRet)
		bRet = gpFontManager->IsExceptFontFile(pFilePath);

	if (  !bRet )
	{
		//clipboard���� ����ϴ� ��δ� ����
		const char* pClipPath = BrGetClipboardRootPath();
		if ( pClipPath && strlen(pClipPath) > 0 )
			bRet = !BFile::CompareFilePath(CUtil::UTF8ToBString((char*)pFilePath), CUtil::UTF8ToBString((char*)pClipPath), BrTRUE);
	}	
	if ( !bRet )
	{
		//pdf cmap data file�� ��쵵 ���� ó��
		char* pCMPPath = (char*)g_pBInterfaceHandle->getPDFFontFilePath();
		if ( pCMPPath && strlen(pCMPPath) > 0 )
			bRet = !BFile::CompareFilePath(CUtil::UTF8ToBString((char*)pFilePath), CUtil::UTF8ToBString((char*)pCMPPath), BrTRUE);
	}
	return bRet;
}

void SetOpenMemoryFileBuffer(const char* pFilePath, char* pBuffer, int nBufferSize)
{
	Painter* pPainter = getPainter();
	if ( !pPainter->m_MemoryFileArray )
		pPainter->m_MemoryFileArray = BrNEW BArray<MemoryFile*>;

	MemoryFile* pFile = BrNEW MemoryFile((char*)pFilePath);
	if ( pFile )
	{
		pFile->SetBufferAndSize(pBuffer, nBufferSize, nBufferSize);
		pPainter->m_MemoryFileArray->Add(pFile);

		g_pBInterfaceHandle->getFileManager()->setDocumentByMemory(true, pBuffer, nBufferSize);
	}
}

void GetMemorySaveResult(const char* pFilePath, void** pOutBufferPtr, int* nOutBufferSize)	
{
	if ( IS_USE_ONLY_MEMORY )
	{
		int nBufferSize;
		void* pBufferPtr;
		if ( GetBufferFileMemStream(pFilePath, &nBufferSize, &pBufferPtr) )
		{
			*nOutBufferSize = nBufferSize;
			*pOutBufferPtr = pBufferPtr;
		}
	}
}

bool BrConvertMemoryToFile(const char* pFilePath)
{
	bool bRet = false;
	if ( IS_USE_ONLY_MEMORY )
	{
		int nBufferSize = 0;
		void* pBufferPtr;
		if ( GetBufferFileMemStream(pFilePath, &nBufferSize, &pBufferPtr) )
		{
			void* pf = BFopen(pFilePath, "wb");
			if ( pf )
			{
				BFwrite(pBufferPtr, 1, nBufferSize, pf);
				BFclose(pf);
				bRet = true;
			}
			else
				SET_ERROR_LOG_FILE(kPoErrFileWrite, g_pBInterfaceHandle->CheckSystemErrorNo(), pFilePath, "wb", true);			
		}
	}	
	return bRet;
}

const void* POGetMemoryFile(const char* pFilePath, int& nBufferSize)
{
	int nSize = 0;
	void* pBufferPtr = BrNULL;
	if ( IS_USE_ONLY_MEMORY )
	{
		if ( GetBufferFileMemStream(pFilePath, &nSize, &pBufferPtr) )
			nBufferSize = nSize;
	}
	return pBufferPtr;
}

MemoryFile* GetMemoryFile(const char* pFilePath, int* nIndex = BrNULL);
MemoryFile* GetMemoryFile(const char* pFilePath, int* nIndex)
{
	Painter* pPainter = getPainter();
	if ( !pPainter || (pPainter && !pPainter->m_MemoryFileArray) )
		return BrNULL;
	for (int n=0;n<pPainter->m_MemoryFileArray->count();n++)
	{
		MemoryFile* pFile = (MemoryFile*)*pPainter->m_MemoryFileArray->GetAt(n);
		if ( pFile->IsFileName(pFilePath) )
		{
			if ( nIndex )
				*nIndex = n;
			return pFile;
		}
	}	
	return BrNULL;
}

BrBOOL GetBufferFileMemStream(const char* pFilePath, int* nBufferSize, void** nBufferPtr)
{
	MemoryFile* pFile = GetMemoryFile(pFilePath);
	if ( pFile && !pFile->IsExceptFile() )
	{
		*nBufferSize = pFile->length();
		*nBufferPtr = (void*)pFile->getBuffer();
		return BrTRUE;	
	}
	return BrFALSE;	
}

void* OpenFileMemStream(const char* pFilePath, const char *in_mode)	
{
	Painter* pPainter = getPainter();
	if (!pPainter)
		return BrNULL;
	if ( !pPainter->m_MemoryFileArray )
		pPainter->m_MemoryFileArray = BrNEW BArray<MemoryFile*>;

	BrBOOL bExceptFile = (pPainter->m_bSkipMemoryFile | IsExceptFile(pFilePath));
	MemoryFile* pFile = BrNULL;
	if ( !bExceptFile )//���� ó���Ͽ� ���Ϸ� �����ϴ� ��� ���� ������ �ƴ� ���ο� ���Ϸ� ������ ó��
		pFile = GetMemoryFile(pFilePath);
	BrBOOL bFind = (pFile != BrNULL);	
	if ( !bFind )//&& strcmp(in_mode, BMV_READ_ONLY))//������ MemoryFile�� �����ؾ� ��
		pFile = BrNEW MemoryFile((char*)pFilePath);
//	BTrace("OpenFileMemStream pFilePath[%s] bExceptFile[%d] pFile[0x%x]", pFilePath, bExceptFile, pFile);	
	if ( pFile )
	{
		MF_OPEN_MODE mode = M_CLOSED;
		if ( !strcmp(in_mode, BMV_READ_ONLY) || !strcmp(in_mode, BMV_EXCLUSIVE_READ) )
			mode = M_READ;
		else if ( !strcmp(in_mode, BMV_WRITE_ONLY) || !strcmp(in_mode, BMV_READ_WRITE) )
			mode = M_WRITE;
		else if ( !strcmp(in_mode, BMV_APPEND) || !strcmp(in_mode, "ab") )
			mode = M_APPEND;
		else if ( !strcmp(in_mode, BMV_READ_WRITING) )
			mode = M_READ_WRITE;
		pFile->open(mode);
		if ( bExceptFile )
		{
			void* pF = BFopen(pFilePath, in_mode);
			if ( pF == BrNULL )
			{
				SET_ERROR_LOG_FILE(kPoErrFileWrite, g_pBInterfaceHandle->CheckSystemErrorNo(), pFilePath, in_mode, true);
				if(!bFind)
					BR_SAFE_DELETE(pFile);
				return BrNULL;//pF;
			}
			pFile->SetExceptFile(bExceptFile? true : false, pF);
		}

		if ( !bFind )
		{
			pPainter->m_MemoryFileArray->Add(pFile);
		}
		BrTrace("%s(%d) %s %s[%s]", __FILE__, __LINE__, __FUNCTION__, pFilePath, in_mode);
	}
	return (void*)pFile;
}
int		CloseFileMemStream(void *hf)
{
	int nRet = 0;
	Painter* pPainter = getPainter();
	if ( hf )
	{
		MemoryFile* pFile = (MemoryFile*)hf;		
		if ( pFile->IsExceptFile() )
		{
			if ( pFile->getFileHandle() )
				nRet = BFclose(pFile->getFileHandle());
			return nRet;
		}
		pFile->close();
		//for(int idx = pPainter->m_MemoryFileArray->GetSize() -1; idx >= 0;idx--)
		//{
		//	if((MemoryFile*)pPainter->m_MemoryFileArray->at(idx) == pFile)
		//	{
		//		pPainter->m_MemoryFileArray->RemoveAt(idx);
		//		BrDELETE pFile;
		//		break;
		//	}
		//}
		nRet = 0;
	}
	return nRet;
}
int		ReadFileMemStream(void *ptr, int size, int nmemb, void *hf)
{
	int nRet = 0;
	if ( hf )
	{
		MemoryFile* pFile = (MemoryFile*)hf;
		if ( pFile->IsExceptFile() )
		{
			if ( pFile->getFileHandle() )
				nRet = BFread(ptr, size, nmemb, pFile->getFileHandle());
			return nRet;
		}
		nRet = pFile->read(ptr, size, nmemb);
	}
	return nRet;
}
int		WriteFileMemStream(const void *ptr, int size, int nmemb, void *hf)
{
	int nRet = 0;
	if ( hf )
	{
		MemoryFile* pFile = (MemoryFile*)hf;
		if ( pFile->IsExceptFile() )
		{
			if ( pFile->getFileHandle() )
				nRet = BFwrite(ptr, size, nmemb, pFile->getFileHandle());
			return nRet;
		}
		nRet = pFile->write(ptr, size, nmemb);
	}
	return nRet;
}
int		FlushFileMemStream(void *hf)
{
	int nRet = 0;
	if ( hf )
	{
		MemoryFile* pFile = (MemoryFile*)hf;
		if ( pFile->IsExceptFile() )
		{
			if ( pFile->getFileHandle() )
				nRet = BFflush(pFile->getFileHandle());
			return nRet;
		}
		nRet = 1;
	}	
	return nRet;
}

int		SeekFileMemStream(void *hf, long pos, int type)
{
	int nRet = 0;
	if ( hf )
	{
		MemoryFile* pFile = (MemoryFile*)hf;
		if ( pFile->IsExceptFile() )
		{
			if ( pFile->getFileHandle() )
				nRet = BFseek64(pFile->getFileHandle(), pos, type);
			return nRet;
		}
		nRet = pFile->seek(pos, type);
	}
	return nRet;
}
long long		TellFileMemStream(void *hf)
{
	long long nRet = 0;
	if ( hf )
	{
		MemoryFile* pFile = (MemoryFile*)hf;
		if ( pFile->IsExceptFile() )
		{
			if ( pFile->getFileHandle() )
				nRet = BFtell64(pFile->getFileHandle());
			return nRet;
		}
		nRet = pFile->tell();
	}
	return nRet;
}
int RemoveFileMemStream(const char *pFilename, bool bFileLock  )
{
	if(pFilename == BrNULL)
		return 1;

	int nIndex;
	MemoryFile* pFile = GetMemoryFile(pFilename, &nIndex);
	if ( pFile )
	{
		if ( pFile->IsExceptFile() )
			BRemove(pFilename, bFileLock );
		//������ �������� ��� �������� �ʵ��� ó��
		BrBOOL bSameFile = !BFile::CompareFilePath(CUtil::UTF8ToBString(getDocFileName()), CUtil::UTF8ToBString((char*)pFilename));	
		if ( !bSameFile )
		{
			Painter* pPainter = getPainter();	
			pFile->close();
			BrDELETE pFile;
			pPainter->m_MemoryFileArray->RemoveAt(nIndex);
		}
		return 0;
	}
	return 1;	
}
int RenameFileMemStream( char* pSrcFileName, char* pDstFileName, bool bFileLock  )
{
	Painter* pPainter = getPainter();	
	int nDstIndex=-1, nSrcIndex=-1;
	MemoryFile* pSrcFile = GetMemoryFile(pSrcFileName, &nSrcIndex);
	MemoryFile* pDstFile = GetMemoryFile(pDstFileName, &nDstIndex);	
	//������ ������ ���� ��� ����
	if ( !pDstFile )
	{
		pDstFile = BrNEW MemoryFile((char*)pDstFileName);
		if ( pDstFile )
		{
			nDstIndex = pPainter->m_MemoryFileArray->GetSize();
			pPainter->m_MemoryFileArray->Add(pDstFile);
		}
	}
	if ( pSrcFile && pDstFile )
	{
		if ( pSrcFile->IsExceptFile() )
			BRename( pSrcFileName , pDstFileName, bFileLock );		
		pSrcFile->rename(pDstFileName);
		pPainter->m_MemoryFileArray->SetAt(nSrcIndex, pSrcFile);		

		//rename�� �����ϸ� ��� ������ ������ �����Ѵ�.
		pPainter->m_MemoryFileArray->RemoveAt(nDstIndex);
		pDstFile->close();
		BR_SAFE_DELETE(pDstFile);
		return 0;
	}
	return 1;		
}
int FileExistFileMemStream( char* pFileName )
{
	//m_bSkipMemoryFile�� true�� ��쿡�� ������ ���� Ȯ���ϵ��� ����
	Painter* pPainter = getPainter();
	if ( pPainter && pPainter->m_bSkipMemoryFile )
		return BFileExist( pFileName );
	
	// Ȯ���ڰ� ���� ��� ������ Ȯ���ϴ� ���� �켱 true�� ����ó��
	char* szDot = strrchr(pFileName, '.');
	char* szSlash = strrchr(pFileName, '/');
	if ( szDot == BrNULL || (szDot != BrNULL && szSlash != BrNULL && strlen(szDot) > strlen(szSlash)) )
	{
		//temppath�� ��쿡 ��� Ȯ��
		char* pTempPath = (char*)BrGetTempPath();
		char* pTmp = strstr(pTempPath, pFileName);
		if ( pTmp == pTempPath && (strlen(pTempPath) - strlen(pFileName) <= 1) ) 
			return 1;//BFileExist( pFileName );//�޸� ���۽ÿ��� Ȯ������ �ʵ��� ����
		
		//favorite temppath�� ��쿡 ��� Ȯ��
		pTempPath = (char*)BrGetFavoriteTempPath();
		if (pTempPath != BrNULL)
		{
			pTmp = strstr(pTempPath, pFileName);
			if (pTmp == pTempPath && (strlen(pTempPath) - strlen(pFileName) <= 1))
				return 1;//BFileExist( pFileName );//�޸� ���۽ÿ��� Ȯ������ �ʵ��� ����
		}
	}

	MemoryFile* pFile = GetMemoryFile(pFileName);
	if ( pFile && pFile->IsExceptFile() )
		return BFileExist( pFileName );
	return (pFile != BrNULL);	
}
void	GetFileInfoFileMemStream(char* szName, int *nSize, int *tModified)
{
	MemoryFile* pFile = GetMemoryFile(szName);
	if ( pFile )
	{
		if ( pFile->IsExceptFile() )
		{
			BGetFileInfo(szName, nSize, tModified);
			return;
		}
		*nSize = pFile->length();
		*tModified = 0;
	}
}
int	GetFileInfoExFileMemStream(char* szName, unsigned int* pAtt, int *pSize, int *pModified)
{
	MemoryFile* pFile = GetMemoryFile(szName);
	if ( pFile )
	{
		if ( pFile->IsExceptFile() )
		{
			return BGetFileInfoEx(szName, pAtt, pSize, pModified);
		}
		*pSize = pFile->length();
		*pAtt = 0;
		*pModified = 0;
		return 1;		
	}
	return 0;
}	

void* _BFopen(const char* pFilePath, const char *in_mode)	
{
	if ( IS_USE_ONLY_MEMORY )
		return OpenFileMemStream(pFilePath, in_mode);
	else
		return BFopen(pFilePath, in_mode);
}
int		_BFclose(void *hf)
{
	if ( IS_USE_ONLY_MEMORY )
		return CloseFileMemStream(hf);
	else
		return BFclose(hf);
}
int		_BFread(void *ptr, int size, int nmemb, void *hf, BrBYTE nByteCryptoInfo, BrCHAR* pByteCryptoPassword)
{
	if ( IS_USE_ONLY_MEMORY )
		return ReadFileMemStream(ptr, size, nmemb, hf);
	else
		return BFread(ptr, size, nmemb, hf);
}
int		_BFwrite(const void *ptr, int size, int nmemb, void *hf, BrBYTE nByteCryptoInfo, BrCHAR* pByteCryptoPassword)
{
	if ( IS_USE_ONLY_MEMORY )
		return WriteFileMemStream(ptr, size, nmemb, hf);
	else
		return BFwrite(ptr, size, nmemb, hf);
}
int		_BFflush(void *hf)
{
	if ( IS_USE_ONLY_MEMORY )
		return FlushFileMemStream(hf);
	else
		return BFflush(hf);
}

bool BrReplaceFile(char* pExistingFileName, char* pNewFileName)
{
#if defined(_WIN32)
	//PC������ �޸� ������ �ؼ� rename���� ������
	if (IS_USE_ONLY_MEMORY)
		return !RenameFileMemStream(pExistingFileName, pNewFileName, true);
	else
		return BReplaceFile(pExistingFileName, pNewFileName);
#endif
	return false;
}

int		_BFseek(void *hf, long pos, int type)
{
	if ( IS_USE_ONLY_MEMORY )
		return SeekFileMemStream(hf, pos, type);
	else
		return BFseek(hf, pos, type);
}
int		_BFseek64(void *hf, long long pos, int type)
{
	if ( IS_USE_ONLY_MEMORY )
		return SeekFileMemStream(hf, pos, type);
	else
		return BFseek64(hf, pos, type);
}
int		_BFtell(void *hf)
{
	if ( IS_USE_ONLY_MEMORY )
		return (int)TellFileMemStream(hf);
	else
		return BFtell(hf);
}
long long		_BFtell64(void *hf)
{
	if ( IS_USE_ONLY_MEMORY )
		return TellFileMemStream(hf);
	else
		return BFtell64(hf);
}
int _BRemove(const char *pFilename, bool bFileLock  )
{
	if ( IS_USE_ONLY_MEMORY )
		return RemoveFileMemStream(pFilename, bFileLock  );
	else
		return BRemove(pFilename, bFileLock  );
}
int _BRename( char* pFileName , char* pReName, bool bFileLock  )
{
	if ( IS_USE_ONLY_MEMORY )
		return RenameFileMemStream( pFileName , pReName, bFileLock );
	else
		return BRename( pFileName , pReName, bFileLock );
}
int _BFileExist( char* pFileName )
{
	if ( IS_USE_ONLY_MEMORY )
		return FileExistFileMemStream( pFileName );
	else
		return BFileExist( pFileName );
}
void	_BGetFileInfo(char* szName, int *nSize, int *tModified)
{
	if ( IS_USE_ONLY_MEMORY )
		GetFileInfoFileMemStream(szName, nSize, tModified);
	else
		BGetFileInfo(szName, nSize, tModified);
}
int	_BGetFileInfoEx(char* szName, unsigned int* pAtt, int *pSize, int *pModified)
{
	if ( IS_USE_ONLY_MEMORY )
		return GetFileInfoExFileMemStream(szName, pAtt, pSize, pModified);
	else
		return BGetFileInfoEx(szName, pAtt, pSize, pModified);
}
	
#undef 	BFopen
#undef 	BFclose
#undef 	BFread
#undef 	BFwrite
#undef 	BFflush
#undef 	BFseek
#undef 	BFtell
#undef 	BRemove
#undef 	BRename
#undef 	BFileExist
#undef 	BGetFileInfo
#undef 	BGetFileInfoEx

#define 	BFopen  		_BFopen
#define 	BFclose			_BFclose
#define 	BFread			_BFread
#define 	BFwrite			_BFwrite
#define 	BFflush			_BFflush
#define 	BFseek			_BFseek
#define 	BFseek64		_BFseek64
#define 	BFtell			_BFtell
#define 	BFtell64		_BFtell64
#define 	BRemove		_BRemove
#define 	BRename		_BRename
#define 	BFileExist		_BFileExist
#define 	BGetFileInfo		_BGetFileInfo
#define 	BGetFileInfoEx	_BGetFileInfoEx

BrLPVOID BrFileOpen(const BrCHAR* pFileName, const BrCHAR* mode, BrBOOL bDRMOpen, BrBOOL& bIsDRM)
{
	if (!pFileName || !strcmp(pFileName, ""))
		return BrNULL;
// BTrace("%s(%d) %s pFileName[%s] mode[%s]", __FILE__, __LINE__, __FUNCTION__, pFileName, mode);		

	BrLPVOID	pFile = BrNULL;
	if (bDRMOpen)
	{
		// [AOM-10021] Save���� 1ȸ�� Crash �̽� ������� : ��Ƽ�ھ� �����忡���� BIsDRMDocumentSupport ȣ������ �ʵ��� ��
		BrBOOL bIsDRMDocumentSupport = BrFALSE;
		if (BrIsMasterThread())
		{
			bIsDRMDocumentSupport = BIsDRMDocumentSupport(pFileName) == 0 ? false : true;
		}
		if (bIsDRMDocumentSupport && getPainter())
		{
			bIsDRM = BrTRUE;
			pFile = BFopen_DRM(pFileName, mode);
		}
		else
			pFile = BFopen(pFileName, mode);
	}
	else
		pFile = BFopen(pFileName, mode);
	if (pFile == BrNULL)
	{
		int nSysError = g_pBInterfaceHandle->CheckSystemErrorNo();

		if (nSysError == 112)
		{
			BString strPath = pFileName;

			if (BFile::isTempPath(strPath))
			{
				g_BoraThreadAtom.m_nErrorCode = kPoErrSysDriveSizeOver;
				SET_ERROR_LOG_FILE(kPoErrSysDriveSizeOver, nSysError, pFileName, __FUNCTION__, false);
			}
			else
			{
				g_BoraThreadAtom.m_nErrorCode = kPoErrFileStorage;
				SET_ERROR_LOG_FILE(kPoErrFileStorage, nSysError, pFileName, __FUNCTION__, false);
			}
		}
		else
			SET_ERROR_LOG_FILE(kPoErrFileWrite, nSysError, pFileName, mode, true);

		BTrace("%s FAIL!!! filename=%s", __FUNCTION__, pFileName);
		//BFopen�� ������ ��쿡 ���� windows, debug����� ���� Ȯ�����
#if defined(_WIN32) && defined(_DEBUG)
//		BRTHREAD_DEBUG_INTERRUPT
#endif
	}
	return pFile;
}

//return : 1(success), 0(fail)
BrINT32 BrFileClose(BrLPBORAFILEINFO pFile)
{
	BRTHREAD_ASSERT(pFile);
	if(!pFile) return 0;

	BrINT32 ret;
	if (pFile->bIsDRM)
		ret = BFclose_DRM((void*)pFile->nFileID);
	else
		ret = BFclose((void*)pFile->nFileID);
	if (IS_USE_ONLY_MEMORY)
		pFile->nFileID = BrNULL;
	//BrTrace("[BrFileClose][fp : 0x%08x][id : 0x%08x]", pFile, pFile->nFileID);	
	//������ ��� �ý��� ������ ����
	if (ret != 0)
		g_pBInterfaceHandle->CheckSystemErrorNo();
	return ret == 0 ? 1 : 0;
}

BrINT32 BrFileRead(BrLPBORAFILEINFO pFile, BrBYTE* pData, BrULONG nSize)
{
	BRCONTEXT
	BRTHREAD_ASSERT(pFile);
	if(!pFile) return 0;

	BrINT32 nRead = 0;
	if( pFile->bIsDRM )
		nRead = BFread_DRM(pData, sizeof(BrBYTE), nSize, (void*)pFile->nFileID);
	else
		nRead = BFread(pData, sizeof(BrBYTE), nSize, (void*)pFile->nFileID, pFile->nByteCryptoInfo, pFile->pByteCryptoPassword);

	if ( nSize > 0 && nRead <= 0 )
		g_pBInterfaceHandle->CheckSystemErrorNo();
	return nRead;
}

BrINT32 BrFileWrite(BrLPBORAFILEINFO pFile, BrBYTE* pData, BrULONG nSize)
{
	BRTHREAD_ASSERT(pFile);
	if(!pFile ) return 0;

	BrINT32 nWrite = 0;
	if( pFile->bIsDRM || pFile->bManualFlush)
		nWrite = BFwrite_DRM(pData, sizeof(BrBYTE), nSize, (void*)pFile->nFileID);
	else
		nWrite = BFwrite(pData, sizeof(BrBYTE), nSize, (void*)pFile->nFileID, pFile->nByteCryptoInfo, pFile->pByteCryptoPassword);

	if ( nSize > 0 && nWrite <= 0 )
		g_pBInterfaceHandle->CheckSystemErrorNo();
	return nWrite;
}

BrINT32 BrFileSeek64(BrLPBORAFILEINFO pFile, BrINT64 nPos, BrINT32 nOrigin)
{
	BRTHREAD_ASSERT(pFile);
	if(!pFile) return -1;

	if( pFile->bIsDRM )
	{
		if( BFseek64_DRM((void*)pFile->nFileID, nPos, nOrigin) >= 0 )
			return 0;
		else
		{
			g_pBInterfaceHandle->CheckSystemErrorNo();
			return -1;
		}
	}
	else
	{
		if( BFseek64((void*)pFile->nFileID, nPos, nOrigin) >= 0 )
			return 0;
		else
		{
			g_pBInterfaceHandle->CheckSystemErrorNo();
			return -1;
		}
	}
}

BrINT64 BrFileTell64(BrLPBORAFILEINFO pFile)
{
	BRTHREAD_ASSERT(pFile);
	if(!pFile) return 0;

	BrINT64 nPos = -1;
	if( pFile->bIsDRM )
		nPos = BFtell64_DRM((void*)pFile->nFileID);
	else
		nPos = BFtell64((void*)pFile->nFileID);

	if ( nPos < 0 )
		g_pBInterfaceHandle->CheckSystemErrorNo();
	return nPos;
}

#ifdef USE_HWP_CONTROL
//a_strOpenFilePath			���� ���� 
//a_strSavedFilePath		���� �Ϸ�� qbk���� 
//a_strTargetFilePath		������ FilePath
//DRM Check �� DRM Write�� Rename���� qbk->DRM Temp FILE�� �ٲپ��ش�.
BrBOOL 	BrSaveFilePackForDRM(const BrCHAR* a_strOpenFilePath, const BrCHAR* a_strSavedFilePath, const BrCHAR* a_strTargetFilePath)
{
	if(!a_strOpenFilePath || !a_strSavedFilePath || !a_strTargetFilePath)
		return BrFALSE;

	if(!BrStrLen(a_strOpenFilePath) || !BrStrLen(a_strSavedFilePath))
		return BrFALSE;

	//File Exist Check
	BString strOpenFilePath = CUtil::UTF8ToBString(a_strOpenFilePath);
	BString strSavedFilePath = CUtil::UTF8ToBString(a_strSavedFilePath);
	if(!BFile::Exist(strOpenFilePath) || !BFile::Exist(strSavedFilePath))
		return BrFALSE;

	//Check DRM for OrgFile 
	if(!BIsDRMDocumentSupport(a_strOpenFilePath))
		return BrFALSE;

	//TargetFile Open
	BrVOID* pTargetFile = BrNULL;
	//DRM �����ΰ�� Pack���� ����.Ex) Open == Target
	if(CUtil::StrCmp((BrCHAR*)a_strOpenFilePath, (BrCHAR*)a_strTargetFilePath) == 0 || BIsDRMDocumentSupport(a_strTargetFilePath))
		pTargetFile = BFopen_DRM(a_strTargetFilePath, "ab");	//Open�� File�� �������� ��� ������ ���� Ab�� ����.
	//DRM ������ �ƴ� ��� Pack��. Ex) SaveAS
	else 
	{
		//Target File DRM Open
		pTargetFile = BFopen_DRM(a_strTargetFilePath,BMV_READ_WRITE);
		if(!pTargetFile)
			return BrFALSE;

		//OpenFile DRMOpen
		BrVOID* fOpenFile = BFopen_DRM(a_strOpenFilePath, BMV_READ_ONLY);
		if(!fOpenFile)
		{
			BFclose_DRM(pTargetFile);
			return BrFALSE;
		}
		//Pack TargerFile 
		if(!BPackContent_DRM(fOpenFile, pTargetFile))
		{
			BFclose_DRM(pTargetFile);
			BFclose_DRM(fOpenFile);
			return BrFALSE;
		}
		BFclose_DRM(fOpenFile);
	}

	if(!pTargetFile)
		return BrFALSE;

	//Open - .qbk
	BFile fQbkFile;	
	if(!fQbkFile.Open(strSavedFilePath, BMV_READ_ONLY) || fQbkFile.Size() == 0)
	{
		BFclose_DRM( pTargetFile );
		return BrFALSE;
	}

	//Copy qbk->TargetFile
	const BrINT32 MAXBUFFSIZE = 4096;

	BrUINT32 nFileSize = fQbkFile.Size();
	fQbkFile.SeekToBegin();
	BFseek_DRM(pTargetFile, 0, BMV_SEEK_SET);

	BrBYTE* pBuffer = (BrBYTE*)BrMalloc(MAXBUFFSIZE);
	memset(pBuffer,0,MAXBUFFSIZE);
	BrUINT32 nReadSize =0;


	while ((nReadSize = fQbkFile.Read((void*)pBuffer,MAXBUFFSIZE)) > 0)
	{
		//Win Api Write �� ���� �ϴٴ� �����Ͽ� �˾Ƽ� File Position �ű����..
		BFwrite_DRM((void*)pBuffer,sizeof(BrBYTE), nReadSize, pTargetFile);
	}

	//TargetFile�� End Of File ����
	BFSetEOF_DRM(pTargetFile);
	BFclose_DRM(pTargetFile);

	BR_SAFE_FREE(pBuffer);


	//Copy �Ϸ��� qbk���� ����
	fQbkFile.Close();
	fQbkFile.Remove();

	return BrTRUE;
}
#endif	//USE_HWP_CONTROL

void	BrGetFileInfo(char* szName, BrLONG *nSize, BrLONG *tModified)
{
	if (!szName || !strcmp(szName, "")) return;

	AdjustPathSeparator(szName);
	BGetFileInfo(szName, nSize, tModified);
}
#ifdef OFFICE_EDITOR
BrBOOL BrGetFileInfoEx(BrCHAR* szName, BrUINT32* pAtt, BrLONG *pSize, BrLONG *pModified)
{
	if (szName && strcmp(szName, ""))
	{
		AdjustPathSeparator(szName);
		if(BGetFileInfoEx(szName, pAtt, pSize, pModified) > 0)
			return BrTRUE;
	}
	return BrFALSE;	
}

BrBOOL BrSetFileTime(BrCHAR* szName, BrULONG nLastAccess, BrULONG nLastWrite)
{
	if (szName && strcmp(szName, ""))
	{
		AdjustPathSeparator(szName);
		if(BSetFileTime(szName, nLastAccess, nLastWrite) > 0)
			return BrTRUE;
	}
	return BrFALSE;	
}

void BrSendTrackReviewModeInfo(int nReviewMode)
{
	BSendTrackReviewModeInfo(nReviewMode);
}

#endif //OFFICE_EDITOR
void BrGetSystemTime(int *nYear, int *nMonth, int *nDay, int *nWday, int *nHour, int *nMinute, int *nSecond)
{
	BGetSystemTime(nYear, nMonth, nDay, nWday, nHour, nMinute, nSecond);
}


int _BrRemove(const char *pFilename, bool bFileLock  )
{
	int nRet = _BRemove(pFilename, bFileLock );
	if ( nRet != 0 )
		g_pBInterfaceHandle->CheckSystemErrorNo();
	return nRet;
}
int	_BrFileExist(char* pFileName)
{
	int nRet = _BFileExist(pFileName);
	if ( nRet != 1 )
		g_pBInterfaceHandle->CheckSystemErrorNo();
	return nRet;
}
int	_BrRename( char* pFileName , char *pRename, bool bFileLock )
{
	int nRet = _BRename( pFileName , pRename, bFileLock );
	if ( nRet != 0 )
		g_pBInterfaceHandle->CheckSystemErrorNo();
	return nRet;
}


BrINT32 BrMakeDirectory(BrCHAR* pDir)
{
	if( !pDir ) return 0;
	BrINT32 nRet = 0;	
	if ( IS_USE_ONLY_MEMORY && !getPainter()->m_bSkipMemoryFile )
		return 1;
	AdjustPathSeparator(pDir);	
	POMulticoreMutex;
	nRet = BMakeDirectory(pDir);
	if ( nRet != 1 )
	{
		g_pBInterfaceHandle->CheckSystemErrorNo();
		//BFopen�� ������ ��쿡 ���� windows, debug����� ���� Ȯ�����
#if defined(_WIN32) && defined(_DEBUG)
//		BRTHREAD_DEBUG_INTERRUPT
#endif
	}
	//if (BrIsMasterThread())
	{
		if( BrGetTempPath() ) {
			if (!strcmp(pDir, (char*)BrGetTempPath()))
				gbMakeTmpDirectory = nRet? true : false;
		}
	}
	//else
	//{
	//	if (!gbMakeTmpDirectory)
	//	{
	//		BrCHAR szTempPath[BRMAX_FULLPATH_LENGTH] = {0,};
	//		BrGetTempPath_ForMCore(szTempPath, sizeof(szTempPath));
	//		if (!strcmp(pDir, szTempPath))
	//			gbMakeTmpDirectory = nRet? true : false;
	//	}
	//}
	return nRet;
}

BrINT32 BrDeleteDirectory(BrCHAR* pDir)
{
	if( !pDir ) return 0;
	BrINT32 nRet = 0;
	AdjustPathSeparator(pDir);
	POMulticoreMutex;
	nRet = BDeleteDirectory(pDir);
	if (!strcmp(pDir, (char*)BrGetTempPath()))
		gbMakeTmpDirectory = !nRet;

	return nRet;
}

void* BrGetDefaultFontFilePath()
{
#if defined(USE_FREETYPE2_ENGINE)
	BrCHAR* pFont = BFont::GetDefaultFontFilePath();
	if ( strcmp(pFont, "") )
		return pFont;
#endif
	return BrNULL;
}

void* BrGetDefaultPDFFontFilePath()
{
//3.0�� ���� PDF font path�� �ʿ��� ��� �Ʒ� �ڵ帣 �츲
/*
#if defined(USE_FREETYPE2_ENGINE)
	BrCHAR* pFont = (BrCHAR*)BGetDefaultPDFFontFilePath();
	if( pFont )
		return pFont;
	else
		return BrGetDefaultFontFilePath();
#endif
*/
	return BrGetDefaultFontFilePath();
}

BrCHAR* BrGetEmFontData(BrBYTE nType, BrINT nEmIndex, BrINT & nSize, BrBYTE nAtt, BrBYTE & nOutAtt)
{
#if defined(USE_FREETYPE2_ENGINE)
	return BFont::GetEmFontData(nType, nEmIndex, nSize, nAtt, nOutAtt);
#endif //defined(USE_FREETYPE2_ENGINE)
}

//Andrew C.Lee XPD-17268 ���� �⺻ ��Ʈ ����
char * BrGetDefaultEnglishFontName()
{
	BrEditModeType nDocType = (BrEditModeType)IsEditorMode(getPainter());
	return BGetDefaultFontName(nDocType, true);
}
#if 1
// word/slide/sheet�� ���� �⺻ ��Ʈ�� ���� 
char * BrGetDefaultFontName()
{
	BrEditModeType nDocType = (BrEditModeType)IsEditorMode(getPainter());
	char *pDefaultFontName = BGetDefaultFontName(nDocType, false);
	if ( !pDefaultFontName || !strcmp(pDefaultFontName, "") )
	{		
		switch(nDocType)
		{
		case EDITOR_SHEET:			
			g_pBInterfaceHandle->setDefaultFontFilePath("Arial");
			break;
		case EDITOR_WORD:
		case EDITOR_PPT:
		default:
#ifdef	SMP		// for Samsung
			g_pBInterfaceHandle->setDefaultFontFilePath("Sgulim");
#elif defined ( ANDROID_FULLJAVA_OMP ) || defined( POLARISOFFICE )
			g_pBInterfaceHandle->setDefaultFontFilePath("NanumGothic");
#else
			g_pBInterfaceHandle->setDefaultFontFilePath("Times New Roman");
#endif			
			break;
		}
	}
	else
		g_pBInterfaceHandle->setDefaultFontFilePath(pDefaultFontName);
	return (char*)g_pBInterfaceHandle->getDefaultFontFilePath();
}

#else
//[sok1029][2014.02.03]
void * BrGetDefaultFontName(BrCHAR * pDefaultFontName)
{
	BGetDefaultFontName(pDefaultFontName);
	return pDefaultFontName;
}
#endif

void * BrGetDefaultFontSize( float* fDefaultFontSize)
{
	BGetDefaultFontSize(fDefaultFontSize);
	return fDefaultFontSize; 
}

void * BrGetDefaultLineSp(float* fDefaultLineSp)
{
	BGetDefaultLineSp(fDefaultLineSp);
	return fDefaultLineSp; 
}

void* BrGetEMFamilyFontFace()
{
	return BFont::GetFontFamilyFontFace();
}

void* BrGetFullSetFontFace()
{
	return BFont::GetFullSetFontFace();
}

void* BrGetSystemFontFace()
{
	return BFont::GetSystemFontFace();
}

BrUINT BrGetSystemFontFaceCnt()
{
	return BFont::GetSystemFontFaceCnt();
}

void* BrGetFTLibrary()
{
	return BFont::GetFTLibrary();
}

void* BrGetInternalFontFace()
{
	return BFont::GetInternalFontFace();
}

BrUINT BrGetInternalFontFaceCnt()
{
	return BFont::GetInternalFontFaceCnt();
}

BrINT BrLoadSystemFont(BrCHAR* fontName)
{
	return BFont::LoadSystemFont(fontName);
}

BrCHAR* HasGlyphIndex(unsigned int uCode, BrBOOL bHangul, BrINT* pFaceIndex, BrBOOL bReFind)
{
	return BFont::HasGlyphIndex(uCode, bHangul,pFaceIndex,bReFind);
}

bool	BrIsShowDiffEditingSymbol()
{
	return BIsShowDiffEditingSymbol();	
}

unsigned char* BrGetFontDataAddress()
{
#if defined(USE_FREETYPE2_ENGINE)
	return BFont::GetFirstFontDataAddr();
#endif
	return BrNULL;
}

BrLONG BrGetFontDataSize()
{
#if defined(USE_FREETYPE2_ENGINE)
	return BFont::GetFirstFontDataSize();
#endif
	return 0;
}

const char* BrGetPDFFontFilePath(char* filename)
{
	BrCHAR* pPath = (BrCHAR*)BGetPDFFontFilePath(filename);
	if( pPath )
	{
		g_pBInterfaceHandle->setPDFFontFilePath(pPath);
		AddExceptFileList(g_pBInterfaceHandle->getPDFFontFilePath());
		return g_pBInterfaceHandle->getPDFFontFilePath();
	}
	return pPath;
}

//Andrew C.Lee
//���� �������� �����ؼ� ���� ������ �����ϴ� ��θ� ���ֱ� ���� �۾�
void POSetBookmarkFilePath(const char* pSetPath)
{
	BrCHAR* pPath = (BrCHAR*)pSetPath;
	if ( pPath == BrNULL )
		pPath = (BrCHAR*)BGetBookmarkPath();
	if ( pPath != BrNULL )
	{
		g_pBInterfaceHandle->setBookmarkPath(pPath);
	}
}

//Andrew C.Lee
//���� �������� �����ؼ� ���� ������ �����ϴ� ��θ� ���ֱ� ���� �۾�
void POSetFavoriteTempPath(const BrCHAR* pSetPath) 
{
	BrCHAR* pPath = (BrCHAR*)pSetPath;
	if ( pPath == BrNULL )
		pPath = (BrCHAR*)BGetFavoriteTempPath();	

	if ( pPath != BrNULL )
	{
		g_pBInterfaceHandle->setFavoriteTempPath(pPath);
	}	
}

void POSetTempPath(const BrCHAR* pSetPath) 
{
	BrCHAR* pPath = (BrCHAR*)pSetPath;

	if ( pPath == BrNULL )
		pPath = (BrCHAR*)BGetTempPath();	

	if ( pPath != BrNULL )
	{
		g_pBInterfaceHandle->setTempPath(pPath);
	}	
}

void POSetQBKPathName(const char* pSetPath)
{
	if(pSetPath != BrNULL)
	{
		g_pBInterfaceHandle->setQBKPathName(pSetPath);
	}	
}

void POSetDocumentValidationMode(bool modeValue)
{
	g_pBInterfaceHandle->setDocumentValidationMode(modeValue);
}

#ifdef OFFICE_EDITOR
BrINT32 BrGetDefaultResString(BrINT nStrID, BrUSHORT *pOutput, BrINT nBuffLen)	//ZPD-3340
{
	if(!pOutput || nBuffLen==0) return 0;
	if(nStrID < 0 || nStrID >= BR_RESSTR_MAX) return 0;
	
	const char *pDefaultStr = g_brResStr[nStrID];
	//��Ʈ���� ���̰� ��ȿ�ؾ߸� ����
	if( pDefaultStr != BrNULL && strlen(pDefaultStr) > 0 )
	{		
		return BrMultiByteToWideChar( CP_UTF8, (BrLPCSTR)pDefaultStr, strlen(pDefaultStr), (BrLPWSTR)pOutput, nBuffLen);
	}
	return 0;
}

BrINT32 BrGetResString(BrINT nStrID, BrUSHORT *pOutput, BrINT nBuffLen, BR_LOCALE_TYPE nLocale)
{
	if(!pOutput || nBuffLen==0) return 0;
	memset(pOutput, 0, nBuffLen);

	BrINT32 nLen = BGetResString(nStrID, pOutput, nBuffLen, nLocale);
	if(nLen == 0) nLen = BrGetDefaultResString(nStrID, pOutput, nBuffLen);
    return nLen;
}

BrBOOL BrIsDeleteChar(BYTE bLinkType, BYTE bSubType)
{
	return BIsDeleteChar(bLinkType, bSubType);
}

BrBOOL BrIsDeleteHWPTypeseChar(BrWORD *pString, BrHWPTypeSetSymbolIndex nIndex, BrBOOL bEulPostPosition)
{
#ifdef SUPPORT_SHOW_HWP_TYPESET
	return BIsDeleteHWPTypeseChar(pString, nIndex, bEulPostPosition);
#endif
	return BrFALSE;
}

// ��Ʈ ����
// nStringCount : ��Ʈ string ���� (ex: 2)
// pStringArray : ��Ʈ string (ex: m_pStringArray[0]=="Sheet1", m_pStringArray[1]=="Sheet2") (unicode)
// return : ���õ� ��Ʈ�� index�� return (ex: 0, 1) , ����ϴ� ��쿡�� -1 �� return
BrINT32 BrSelectSheetNameForMailMerge(BrINT nStringCount, unsigned short **pStringArray)
{
#if defined(SUPPORT_MAIL_MERGE) || defined(SUPPORT_MAIL_MERGE_FOR_DOC)
	return BSelectSheetNameForMailMerge(nStringCount, pStringArray);
#else
	return BrFALSE;
#endif //SUPPORT_MAIL_MERGE_FOR_DOC
}

// �ּҷ� ���ڵ� ����
// nRecordCount : ���ڵ� ���� (ex: 3)
// pStringArray : pStringArray[0] : ���ڵ� �̸��� TAB ���� �и��Ǿ� string���� ���� (ex: "�̸�\t��ȭ ��ȣ\tȸ��") (unicode)
//			      pStringArray[1], pString[2], ...... : ���ڵ� ������ TAB ���� �и��Ǿ� string���� ���� (ex: "�赿��\t010-9900-6700\t���������", "ȫ�浿\t010-1234-5678\t�Ｚ����", ......) (unicode)
// pSelectArray : ���õ� ���ڵ� ǥ�� (ex: ���  �����ϴ� ��� pSelectArray[0]=1, pSelectArray[1]=1, pSelectArray[2]=1, ȫ�浿�� �����ϴ� ��� pSelectArray[0]=0, pSelectArray[1]=1, pSelectArray[2]=0)
// return : bool�� return (Ȯ�� : true, ��� : false)
BrBOOL BrSelectRecordForMailMerge(BrINT nRecordCount, unsigned short **pStringArray, char *pSelectArray)
{
#if defined(SUPPORT_MAIL_MERGE) || defined(SUPPORT_MAIL_MERGE_FOR_DOC)
	return BSelectRecordForMailMerge(nRecordCount, pStringArray, pSelectArray);
#else
	return BrFALSE;
#endif //SUPPORT_MAIL_MERGE_FOR_DOC
}

// �ʵ� �̸� ����
// nRecordCnt : ���ڵ� ���� (ex : 3  (�̸�, ��ȭ ��ȣ, ȸ��))
// pRecordStringArray : ���ڵ� string (ex : pRecordStringArray[0]="�̸�", pRecordStringArray[0]="��ȭ ��ȣ", pRecordStringArray[0]="ȸ��")
// pFieldString : field string (ex : pFieldString="DISPLAY_NAME")
// return : ���õ� ������ ���� �ʵ� index�� return (ex : 0("�̸�"�� �����ϴ� ���), 1("��ȭ ��ȣ"�� �����ϴ� ���), ....., -1(��Ҹ� �ϴ� ���))
//		    ��Ҹ� �ϴ� ��쿡�� �ش� �ʵ带 ��ü���� ���� �ʰ� ��ĭ���� ó��
BrINT32 BrConnectFieldNameForMailMerge(BrINT nRecordCnt, unsigned short **pRecordStringArray, unsigned short *pFieldString)
{
#ifdef SUPPORT_MAIL_MERGE
	return BConnectFieldNameForMailMerge(nRecordCnt, pRecordStringArray, pFieldString);
#else
	return BrFALSE;
#endif //SUPPORT_MAIL_MERGE
}

// ���� �ʵ� ����
// nRecordCount : ���ڵ� ���� (ex: 3)
// pStringArray : pStringArray[0] : Record Name (ex: "�̸�") (unicode)
//			      pStringArray[1], pString[2], ...... : Record Name (ex: "��ȭ��ȣ", "�ּ�", ......) (unicode)
// nFieldIndex  : ���õ� ���ڵ� index (ex: 0, 1, 2, ...)
// return : bool�� return (Ȯ�� : true, ��� : false)
BrBOOL BrSelectMergeFieldForMailMerge(BrINT nRecordCount, unsigned short **pStringArray, int *nFieldIndex)
{
#if defined(SUPPORT_MAIL_MERGE) || defined(SUPPORT_MAIL_MERGE_FOR_DOC)
	return BSelectMergeFieldForMailMerge(nRecordCount, pStringArray, nFieldIndex);
#else
	return BrFALSE;
#endif //SUPPORT_MAIL_MERGE_FOR_DOC
}
#endif

BrBOOL BrGetCalcDateTime(BrCHAR* pMemoDate, BrUSHORT *pOutput)
{
	if(!pMemoDate) return BrFALSE;
	memset(pOutput, 0, BrSizeOf(BrUSHORT) * BORA_DEFINEDNAME_LENGTH/*255*/);

	BrINT32 nLen = BGetCalcDateTime(pMemoDate, pOutput);
	if(nLen == 0) return BrFALSE;
	return BrTRUE;
}

char* BrGetCMapDataAddress()
{
#if defined(USE_CMAP_MEM_FONT) || defined(USE_CMAP_NAND_FONT)
	return (char*)BGetCMapDataAddress();
#else
	return NULL;
#endif
}

BrLONG BrGetCMapDataSize()
{
#if defined(USE_CMAP_MEM_FONT) || defined(USE_CMAP_NAND_FONT)
	return BGetCMapDataSize();
#else
	return 0;
#endif
}

const char* BrGetPDFExportWaterMarkPath(BrINT page , BrINT width , BrINT height )
{
	BrCHAR* pPath = (BrCHAR*)BGetPDFExportWaterMarkPath(page , width , height);

	if( pPath )
	{
		AddExceptFileList(pPath);
		return pPath;
	}
	else
		return BrNULL;
}


int BrReadNandData(char* pBuf, int nOffset, int nSize)
{
#ifdef USE_CMAP_NAND_FONT
	return BReadNandData(pBuf, nOffset, nSize);
#else
	return 0;  
#endif
}

void BrGdkThreadsEnter()
{
// gtk+ �� ����ϸ鼭 �����忡�� ���̺귯���� �����ϴ� ��� ���
#ifdef USE_GTK_THREAD
	BGetThreadsEnter();
#endif
}

void BrGdkThreadsLeave()
{
// gtk+ �� ����ϸ鼭 �����忡�� ���̺귯���� �����ϴ� ��� ���
#ifdef USE_GTK_THREAD
	BGetThreadsLeave();
#endif
}

#ifndef ENGINE_LIB_REMOVE
BrBOOL BrStrEncrypt(BrUCHAR* pPKey, BrUCHAR* pStr, BrUCHAR* pResult, BrINT nLen, BrUCHAR* pUKey)
{
#ifdef BINARY_DECRYPTOR
	BrUCHAR *pUniqueKey = pUKey? pUKey : (BrUCHAR*)BR_STR_UNIKEY;
	BrUCHAR pUniKey[16] = {0,};
	for (BrINT i=0; i<16; i++)
	{
		if (pUniqueKey[i])
			pUniKey[i] = pUniqueKey[i];
		else
			break;
	}
	return BrStrEncryptRC4(pPKey, pUniKey, pStr, pResult, nLen);
#else
	return BrFALSE;
#endif
}

BrBOOL BrStrDecrypt(BrUCHAR* pPKey, BrUCHAR* pStr, BrUCHAR* pResult, BrINT nLen, BrUCHAR* pUKey)
{
#ifdef BINARY_DECRYPTOR
	BrUCHAR *pUniqueKey = pUKey? pUKey : (BrUCHAR*)BR_STR_UNIKEY;
	BrUCHAR pUniKey[16] = {0,};
	for (BrINT i=0; i<16; i++)
	{
		if (pUniqueKey[i])
			pUniKey[i] = pUniqueKey[i];
		else
			break;
	}
	return BrStrDecryptRC4(pPKey, pUniKey, pStr, pResult, nLen);
#else
	return BrFALSE;
#endif
}
#endif

BrSBitmapPtr BrGetSBitmapPtr(LPBrBITMAPINFOHEADER pBitmap)
{
	return BrNULL;
}

BrBOOL BrCreateSBitmapPtr(LPBrBITMAPINFOHEADER pBitmap)
{
	return 0;
}

void BrDeleteSBitmapPtr(LPBrBITMAPINFOHEADER pBitmap)
{
}

#include "ImageLib.h"
BrUINT32 BrROWSIZE(LPBrBITMAPINFOHEADER pBitmap, BrWORD type)
{
	BrSBitmapPtr pSBitmap = BrGetSBitmapPtr(pBitmap);
	if (pSBitmap)
	{
		return pSBitmap->biWidthBytes;
	}
	else
	{
		switch(type)
		{
		case 8:
			return ROWSIZE8(pBitmap->biWidth, pBitmap->biBitCount);
			break;
		case 16:
			return ROWSIZE16(pBitmap->biWidth, pBitmap->biBitCount);
			break;
		case 32:
			return ROWSIZE32(pBitmap->biWidth, pBitmap->biBitCount);
			break;
		default:
			break;
		}
	}

	return 0;
}

BrUINT32 BrIMAGESIZE(LPBrBITMAPINFOHEADER pBitmap, BrWORD type)
{
	BrSBitmapPtr pSBitmap = BrGetSBitmapPtr(pBitmap);
	if (pSBitmap)
	{
		return (BrROWSIZE(pBitmap, type) * pSBitmap->biHeight);
	}
	else
	{
		return (BrROWSIZE(pBitmap, type) * pBitmap->biHeight);
	}
}

BrUINT32 BrDIBSIZE(LPBrBITMAPINFOHEADER pBitmap, BrWORD type)
{
	BrSBitmapPtr pSBitmap = BrGetSBitmapPtr(pBitmap);
	if (pSBitmap)
	{
		return (BrIMAGESIZE(pBitmap, type) + BITSOFFSET(pBitmap));
	}
	else
	{
		return (BrIMAGESIZE(pBitmap, type) + BITSOFFSET(pBitmap));
	}
}

BrINT32 BrGetFileExtOnDRM(BrCHAR* szFilePath, BrCHAR* szFileExt)
{
	BrCHAR pStrFullPath[BRMAX_FULLPATH_LENGTH]={0,};
	BrCHAR pStrPath[BRMAX_FULLPATH_LENGTH]={0,};
	BrCHAR pStrFile[BRMAX_FILENAME_LENGTH]={0,};
	BrCHAR *pFileName = BrNULL;
	BrINT32 ret = 0;

	AdjustPathSeparator(szFilePath);
	strncpy_s(pStrFullPath, sizeof(pStrFullPath), szFilePath, strlen(szFilePath));

	pFileName = strrchr(pStrFullPath, '/');
	if( pFileName == BrNULL ) return 0;

	pStrFullPath[ (int)(pFileName - pStrFullPath)] = '\0';
	strncpy_s(pStrPath, sizeof(pStrPath), pStrFullPath, strlen(pStrFullPath));
	strncpy_s(pStrFile, sizeof(pStrFile), pFileName+1, strlen(pFileName+1));

	ret = BGetFileExtOnDRM(pStrPath, pStrFile, szFileExt);

	return ret;
}

//Andrew C.Lee strstr�� ���� ��츦 ������ ������
char * BrStrrstr(const char *str, const char *strSearch)
{
	char *ptr, *last=NULL;
	ptr = (char*)str;
	while((ptr = strstr(ptr, strSearch))) last = ptr++; 
	return last;
}

/*
*	@author 	Andrew
*	@date  	2017.12.29
*	@brief  	BGetClipboardDirectory�� ���� ȣ������ �ʰ� MakeOSCall�� ȣ���ϵ��� ����
*/
const char* _BGetClipboardDirectory()
{
	BRCONTEXT;
	return MakeOSCall<const char*>(Brcontext, BGetClipboardDirectory);
}

/*
*	@author 	Andrew
*	@date  	2017.12.29
*	@params $pSetPath : ��θ�
*	@brief  	clipboard ��θ� �����ϴ� �Լ�, NULL�� ��� ���� �Լ��� ȣ���Ͽ� Ȯ�� ó��
*/
void POSetClipboardPath(const BrCHAR* pSetPath) 
{
	const BrCHAR* pPath = (const BrCHAR*)pSetPath;

	if ( pPath == BrNULL )
		pPath = (const BrCHAR*)_BGetClipboardDirectory();	

	if ( pPath == BrNULL )
		return;
	
	g_pBInterfaceHandle->m_nClipboardCounter = 0;

	g_pBInterfaceHandle->setClipboardPath(pPath);
}

/*
*	@author 	Freddy
*	@date  	2020.01.28
*	@params $pSetPath : ��θ�
*	@brief  	..\AppData\Roaming\Microsoft\Templates ��θ� �����ϴ� �Լ�, NULL�� ��� ���� �Լ��� ȣ���Ͽ� Ȯ�� ó��
*/
 void POSetMSTemplatePath(const char* pSetPath)
 {
	 const BrCHAR* pPath = (const BrCHAR*)pSetPath;

	 if (pPath == BrNULL)
		 pPath = (const BrCHAR*)_BGetClipboardDirectory();

	 if (pPath == BrNULL)
		 return;

	g_pBInterfaceHandle->setMSTemplatePath(pPath);
 }

/*
*	@author 	Andrew
*	@date  	2017.12.29
*	@brief  	clipboard�� ���� ������ �����ϱ� ������ root�н��� ��θ� ���� ����
*/
const char* BrGetClipboardRootPath()
{	
	return (const char*)g_pBInterfaceHandle->getClipboardPath();
}

/*
*	@author 	Andrew
*	@date  	2017.12.29
*	@brief  	������ ���� ������ ����
*/
const char* BrGetClipboardPath()
{		
	g_pBInterfaceHandle->setClipboardSubPath(g_pBInterfaceHandle->getClipboardPath());
	return g_pBInterfaceHandle->getClipboardSubPath();
}

unsigned int BrWcsLen(const BrWCHAR	*string)
{
	if (!string || !string[0])
		return 0;

	BrWCHAR* p = (BrWCHAR*)string;
	while( *p++ );

	return (unsigned int)(p - string -1);
}

#include "../../sources/Sheet/frmw/TLwrapper/ETLwrapper/etlBuffer.h"

// BrUINT CodePage : code page
// BrLPCSTR lpMultiByteStr : input multibyte string
// int cbMultiByte : input string length
// BrLPWSTR lpWideStr : output widechar string
// int cchWideChar : output widechar length
BrINT32 BrMultiByteToWideChar( BrUINT CodePage, BrLPCSTR lpMultiByteStr, int cbMultiByte, OUT BrLPWSTR lpWideStr, int cchWideChar )
{
	//Andrew C.Lee linux���� �ڵ� ��ȯ�� ������ �߻��Ͽ� ���� �Լ� ȣ������ �ʵ��� ����
	if( CodePage == CP_UTF8 ) 
	{
		int nLen = BoraUTF8ToWideChar(  lpMultiByteStr, cbMultiByte, lpWideStr, cchWideChar );
#ifdef __sparc__
		UINT8* srcData = (UINT8*)lpWideStr;
		for (int n = 0; n < BrWcsLen(lpWideStr)*2; n += 2)
		{
			UINT8 tmp = srcData[n + 1];

			srcData[n + 1] = srcData[n];
			srcData[n] = tmp;
		}
		lpWideStr[nLen] = '\0';
#endif
		return nLen;
	}

	int nRet = 0;
	if (!cchWideChar && !lpWideStr)
	{
		int nLen = cbMultiByte;

		etlBuffer64<BrUSHORT> etl(nLen + 1, etl_alloc::sysalloc);
		BrUSHORT* pBuffer = etl.GetBuffer();
		if (pBuffer == nullptr)
			return 0;

		nRet = BMultiByteToWideChar( CodePage, lpMultiByteStr, cbMultiByte, pBuffer, nLen );
	}	
	else
	{
		nRet = BMultiByteToWideChar( CodePage, lpMultiByteStr, cbMultiByte, lpWideStr, cchWideChar );
		if ( nRet > 0 )
		{
			BRTHREAD_ASSERT(lpWideStr[nRet] == '\0');
			//buffer overrun ������ ����ũ�Ⱑ ���� ũ�⺸�� ���� ��츸 null terminateó��
			//ȣ���� �ʿ��� null terminate�� �����ؾ� ��
			if ( nRet < cchWideChar )
				lpWideStr[nRet] = '\0';		
		}
		else
		{
#ifdef WIN32
			DWORD nError = GetLastError();
#endif
			BRTHREAD_ASSERT(nRet);
		}
	}

	return nRet;
}


// BrUINT CodePage : code page
// BrLPWSTR lpWideStr : input widechar string
// int cchWideChar : input widechar length
// BrLPCSTR lpMultiByteStr : output multibyte string
// int cbMultiByte : output string length
BrINT32 BrWideCharToMultiByte( BrUINT CodePage, BrLPCWSTR lpWideCharStr, int cchWideChar, OUT BrLPSTR lpMultiByteStr, int cbMultiByte , bool bUseUCS4 )
{
	//bigendian
#if 0//def __sparc__
	UINT8* srcData = (UINT8*)lpWideCharStr;
	for (int n = 0; n < BrWcsLen(lpWideCharStr)*2; n += 2)
	{
		UINT8 tmp = srcData[n + 1];

		srcData[n + 1] = srcData[n];
		srcData[n] = tmp;
	}
#endif	
	//Andrew C.Lee linux���� �ڵ� ��ȯ�� ������ �߻��Ͽ� ���� �Լ� ȣ������ �ʵ��� ����
	if ( CodePage == CP_UTF8 )
	{
		return BoraWideCharToUTF8(  (BrLPWSTR)lpWideCharStr, cchWideChar, (LPBYTE)lpMultiByteStr, cbMultiByte , bUseUCS4 );
	}

	int nRet = 0;
	if (!cbMultiByte && !lpMultiByteStr)
	{
		int nLen = cchWideChar*2 + 1;
		if ( CodePage == CP_UTF8 )
			nLen = cchWideChar*3 + 32;


		etlBuffer64<BrCHAR> etl(nLen + 1, etl_alloc::sysalloc);
		if (etl.GetBuffer() == nullptr)
			return 0;		

		nRet = BWideCharToMultiByte( CodePage, lpWideCharStr, cchWideChar, etl.GetBuffer(), nLen );
	}
	else
	{
		nRet = BWideCharToMultiByte( CodePage, lpWideCharStr, cchWideChar, lpMultiByteStr, cbMultiByte );
		if ( nRet > 0 )
		{
			BRTHREAD_ASSERT(lpMultiByteStr[nRet] == '\0');
			//buffer overrun ������ ����ũ�Ⱑ ���� ũ�⺸�� ���� ��츸 null terminateó��
			//ȣ���� �ʿ��� null terminate�� �����ؾ� ��
			if ( nRet < cbMultiByte )
				lpMultiByteStr[nRet] = '\0';
		}
		else
		{
#ifdef WIN32
			DWORD nError = GetLastError();
#endif
			BRTHREAD_ASSERT(nRet);
		}
	}

	return nRet;
}

unsigned long long BrGetTickCount()
{
	using namespace std::chrono;
	unsigned long long tick = duration_cast<milliseconds>(steady_clock::now().time_since_epoch()).count();
//	BTrace("BrGetTickCount() = %lld", tick);
	return tick;
}

unsigned long long BrGetElapsedTime(unsigned long long nTime)
{
	unsigned long long tick = BrGetTickCount();
//	BTrace("BrGetElapsedTime() = %lld", tick - nTime);
	return tick - nTime;
}

void* BrGetScreenBuffer()
{
	return 0;

	//by sunklee. 2007.2.21
	//�Ʒ� �Լ��� UI �� ��ũ�� ���� �����͸� ������ ����.
	//�̸� �����ϸ� bmvinterface.h ���� �Բ� ����ǹǷ� �����ÿ��� �Ű� �����.
	//TV Out�� �������� ���۸� ���� ���� UI ���� ����ڿ� ������ ��Ȯ�� ���ظ� ���Ѿ� ��.
	////return (void*)BGetScreenBuffer(getLCDWidth(), getLCDHeight(), gnBits);
}

BrDOUBLE BrStrtod(const BrCHAR *pStr, BrCHAR **endptr)
{
	BrDOUBLE number;
	BrINT exponent;
	BrINT negative;
	BrCHAR *p = (BrCHAR *) pStr;
	BrDOUBLE p10;
	BrINT n;
	BrINT num_digits;
	BrINT num_decimals;

	if (endptr)
		*endptr = p; //�ʱ�ȭ �ϰ� ����.

	if (pStr == NULL || !strcmp(pStr, ""))	return 0.0;
	// Skip leading whitespace
	while (IsAsciiSpace(*p)) p++;

	// Handle optional sign
	negative = 0;
	switch (*p) 
	{             
		case '-': negative = 1; // Fall through to increment position
		case '+': p++;
	}

	number = 0.;
	exponent = 0;
	num_digits = 0;
	num_decimals = 0;

	// Process string of digits
	while (IsDigit(*p))
	{
		number = number * 10. + (*p - '0');
		p++;
		num_digits++;
	}

	// Process decimal part
	if (*p == '.') 
	{
		p++;

		while (IsDigit(*p))
		{
			number = number * 10. + (*p - '0');
			p++;
			num_digits++;
			num_decimals++;
		}

		exponent -= num_decimals;
	}

	if (num_digits == 0)
	{
		//errno = BrERANGE;
		return 0.0;
	}

	// Correct for sign
	if (negative) number = -number;

	// Process an exponent string
	if (*p == 'e' || *p == 'E') 
	{
		// Handle optional sign
		negative = 0;
		switch(*++p) 
		{   
			case '-': negative = 1;   // Fall through to increment pos
			case '+': p++;
		}

		// Process string of digits
		n = 0;
		while (IsDigit(*p)) 
		{   
			n = n * 10 + (*p - '0');
			p++;
		}

		if (negative) 
			exponent -= n;
		else
			exponent += n;
	}

	if (exponent < BrDBL_MIN_EXP  || exponent > BrDBL_MAX_EXP)
	{
		//errno = BrERANGE;
		return 0/*HUGE_VAL*/;
	}

	// Scale the result
	p10 = 10.;
	n = exponent;
	if (n < 0) n = -n;
	while (n) 
	{
		if (n & 1) 
		{
			if (exponent < 0)
				number /= p10;
			else
				number *= p10;
		}
		n >>= 1;
		p10 *= p10;
	}
	
	if (endptr)
	{
		if (number == 0/*HUGE_VAL*/)
			*endptr = BrNULL;
		else
			*endptr = p;
	}

	return number;
}

BrDOUBLE BrWcstod(const BrWCHAR *pStr, BrWCHAR **endptr)
{
	BrDOUBLE number;
	BrINT exponent;
	BrINT negative;
	BrWCHAR *p = (BrWCHAR *) pStr;
	BrDOUBLE p10;
	BrINT n;
	BrINT num_digits;
	BrINT num_decimals;

	if (endptr)
		*endptr = p; //�ʱ�ȭ �ϰ� ����.

	if (pStr == NULL || *pStr == 0 )	
		return 0.0;
	// Skip leading whitespace
	while (IsAsciiSpace(*p)) p++;

	// Handle optional sign
	negative = 0;
	switch (*p) 
	{             
		case '-': negative = 1; // Fall through to increment position
		case '+': p++;
	}

	number = 0.;
	exponent = 0;
	num_digits = 0;
	num_decimals = 0;

	// Process string of digits
	while (IsDigit(*p))
	{
		number = number * 10. + (*p - '0');
		p++;
		num_digits++;
	}

	// Process decimal part
	if (*p == '.') 
	{
		p++;

		while (IsDigit(*p))
		{
			number = number * 10. + (*p - '0');
			p++;
			num_digits++;
			num_decimals++;
		}

		exponent -= num_decimals;
	}

	if (num_digits == 0)
	{
		//errno = BrERANGE;
		return 0.0;
	}

	// Correct for sign
	if (negative) number = -number;


	BrWCHAR *pNext = p +1;

	// Process an exponent string
	if ((*p == 'e' || *p == 'E') && *pNext != 'm') 
	{
		// Handle optional sign
		negative = 0;
		switch(*++p) 
		{   
			case '-': negative = 1;   // Fall through to increment pos
			case '+': p++;
		}

		// Process string of digits
		n = 0;
		while (IsDigit(*p)) 
		{   
			n = n * 10 + (*p - '0');
			p++;
		}

		if (negative) 
			exponent -= n;
		else
			exponent += n;
	}

	if (exponent < BrDBL_MIN_EXP  || exponent > BrDBL_MAX_EXP)
	{
		//errno = BrERANGE;
		return 0/*HUGE_VAL*/;
	}

	// Scale the result
	p10 = 10.;
	n = exponent;
	if (n < 0) n = -n;
	while (n) 
	{
		if (n & 1) 
		{
			if (exponent < 0)
				number /= p10;
			else
				number *= p10;
		}
		n >>= 1;
		p10 *= p10;
	}
	
	if (endptr)
	{
		if (number == 0/*HUGE_VAL*/)
			*endptr = BrNULL;
		else
			*endptr = p;
	}

	return number;
}

#ifdef __cplusplus
extern "C" {
#endif


#if 0
int BrRand()
{
#if !defined(NOT_USE_GLOBAL_VARIABLE)
	static BrLONG g_holdrand = 1L;
#endif
	return(((g_holdrand = g_holdrand * 214013L + 2531011L) >> 16) & 0x7fff);
}

char* BrStrtok(char *line, char *delims)
{
#if !defined(NOT_USE_GLOBAL_VARIABLE)
	static char     *g_saveline = '\0';
#endif
	char            *p;
	int             n;
	if (line != '\0')
	{
		g_saveline = line;
	}

	if (g_saveline == '\0' || *g_saveline == '\0')
	{
		return('\0');
	}

	n = strcspn(g_saveline, delims);                   //
	p = g_saveline;                                            //
	g_saveline += n;                                          //

	if (*g_saveline != '\0')
	{	
		*g_saveline++ = '\0';
	}

	return (p);
}

// reference => http://www.koders.com/c/fid772A1DFFFF802B239C481E127BE09BA87279F95E.aspx?s=md5
BrLONG BrStrtol(const char *nptr, char **endptr, int base)
{
#define TYPE_TWOS_COMPLEMENT(t) ((t) ~ (t) 0 == (t) -1)
#define TYPE_ONES_COMPLEMENT(t) ((t) ~ (t) 0 == 0)
#define TYPE_SIGNED_MAGNITUDE(t) ((t) ~ (t) 0 < (t) -1)

#define TYPE_SIGNED(t) (! ((t) 0 < (t) -1))
#define CHAR_BIT 8
/* The maximum and minimum values for the integer type T.  These
   macros have undefined behavior if T is signed and has padding bits.
   If this is a problem for you, please let us know how to fix it for
   your host.  */
#define TYPE_MINIMUM(t) \
   ((t) (! TYPE_SIGNED (t) \
	 ? (t) 0 \
	 : TYPE_SIGNED_MAGNITUDE (t) \
	 ? ~ (t) 0 \
	 : ~ (t) 0 << (sizeof (t) * CHAR_BIT - 1)))
#define TYPE_MAXIMUM(t) \
   ((t) (! TYPE_SIGNED (t) \
	 ? (t) -1 \
	 : ~ (~ (t) 0 << (sizeof (t) * CHAR_BIT - 1))))

#define STRTOL_ULONG_MAX	TYPE_MAXIMUM (BrULONG)
#define STRTOL_LONG_MIN	TYPE_MAXIMUM (BrLONG)
#define STRTOL_LONG_MAX	TYPE_MINIMUM (BrLONG)
#define LONG	BrLONG
	int negative;
	register BrULONG cutoff;
	register unsigned int cutlim;
	register BrULONG i;
	register const char *s;
	register unsigned char c;
	const char *save, *end;
	int overflow;



	if (base < 0 || base == 1 || base > 36)
	{
//	__set_errno (EINVAL);
		return 0;
	}

	save = s = nptr;

	/* Skip white space.	*/
	while (IsAsciiSpace(*s))
		++s;
	if (*s == '\0')
		goto noconv;

	/* Check for a sign.	*/
	if (*s == '-')
	{
		negative = 1;
		++s;
	}
	else if (*s == '+')
	{
		negative = 0;
		++s;
	}
	else
		negative = 0;

	/* Recognize number prefix and if BASE is zero, figure it out ourselves.	*/
	if (*s == '0')
	{
		if ((base == 0 || base == 16) && BrToUpper(s[1]) == 'X')
		{
			s += 2;
			base = 16;
		}
		else if (base == 0)
			base = 8;
	}
	else if (base == 0)
		base = 10;

	/* Save the pointer so we can check later if anything happened.  */
	save = s;

	end = NULL;

	cutoff = STRTOL_ULONG_MAX / (BrULONG) base;
	cutlim = STRTOL_ULONG_MAX % (BrULONG) base;

	overflow = 0;
	i = 0;
	for (c = *s; c != '\0'; c = *++s)
	{
		if (s == end)
			break;
		if (c >= '0' && c <= '9')
			c -= '0';
		else if (IS_ALPHABET(c))
			c = BrToUpper(c) - 'A' + 10;
		else
			break;
		if ((int) c >= base)
			break;
		/* Check for overflow.  */
		if (i > cutoff || (i == cutoff && c > cutlim))
			overflow = 1;
		else
		{
			i *= (BrULONG) base;
			i += c;
		}
	}

	/* Check if anything actually happened.  */
	if (s == save)
		goto noconv;

	/* Store in ENDPTR the address of one character
	past the last character we converted.	*/
	if (endptr != NULL)
		*endptr = (char *) s;

	/* Check for a value that is within the range of
	`unsigned LONG int', but outside the range of `LONG int'.	*/
	if (overflow == 0
		&& i > (negative
		? -((BrULONG) (STRTOL_LONG_MIN + 1)) + 1
		: (BrULONG) STRTOL_LONG_MAX))
		overflow = 1;

	if (overflow)
	{
//		__set_errno (ERANGE);
		return negative ? STRTOL_LONG_MIN : STRTOL_LONG_MAX;
	}

	/* Return the result of the appropriate sign.  */
	return negative ? -i : i;

noconv:
	/* We must handle a special case here: the base is 0 or 16 and the
	first two characters are '0' and 'x', but the rest are no
	hexadecimal digits.  This is no error case.  We return 0 and
	ENDPTR points to the `x`.	*/
	if (endptr != NULL)
	{
		if (save - nptr >= 2 && BrToUpper(save[-1]) == 'X' && save[-2] == '0')
			*endptr = (char *) &save[-1];
		else
			/*	There was no number to convert.  */
			*endptr = (char *) nptr;
	}

	return 0L;
}

BrULONG BrStrtoul(const char *nptr, char **endptr, int base)
{
#define TYPE_TWOS_COMPLEMENT(t) ((t) ~ (t) 0 == (t) -1)
#define TYPE_ONES_COMPLEMENT(t) ((t) ~ (t) 0 == 0)
#define TYPE_SIGNED_MAGNITUDE(t) ((t) ~ (t) 0 < (t) -1)

#define TYPE_SIGNED(t) (! ((t) 0 < (t) -1))
#define CHAR_BIT 8
/* The maximum and minimum values for the integer type T.  These
   macros have undefined behavior if T is signed and has padding bits.
   If this is a problem for you, please let us know how to fix it for
   your host.  */
#define TYPE_MINIMUM(t) \
   ((t) (! TYPE_SIGNED (t) \
	 ? (t) 0 \
	 : TYPE_SIGNED_MAGNITUDE (t) \
	 ? ~ (t) 0 \
	 : ~ (t) 0 << (sizeof (t) * CHAR_BIT - 1)))
#define TYPE_MAXIMUM(t) \
   ((t) (! TYPE_SIGNED (t) \
	 ? (t) -1 \
	 : ~ (~ (t) 0 << (sizeof (t) * CHAR_BIT - 1))))

#define STRTOL_ULONG_MAX	TYPE_MAXIMUM (BrULONG)
#define STRTOL_LONG_MIN	TYPE_MAXIMUM (BrLONG)
#define STRTOL_LONG_MAX	TYPE_MINIMUM (BrLONG)
#define LONG	BrLONG
	int negative;
	register BrULONG cutoff;
	register unsigned int cutlim;
	register BrULONG i;
	register const char *s;
	register unsigned char c;
	const char *save, *end;
	int overflow;



	if (base < 0 || base == 1 || base > 36)
	{
//	__set_errno (EINVAL);
		return 0;
	}

	save = s = nptr;

	/* Skip white space.	*/
	while (IsAsciiSpace(*s))
		++s;
	if (*s == '\0')
		goto noconv;

	/* Check for a sign.	*/
	if (*s == '-')
	{
		negative = 1;
		++s;
	}
	else if (*s == '+')
	{
		negative = 0;
		++s;
	}
	else
		negative = 0;

	/* Recognize number prefix and if BASE is zero, figure it out ourselves.	*/
	if (*s == '0')
	{
		if ((base == 0 || base == 16) && BrToUpper(s[1]) == 'X')
		{
			s += 2;
			base = 16;
		}
		else if (base == 0)
			base = 8;
	}
	else if (base == 0)
		base = 10;

	/* Save the pointer so we can check later if anything happened.  */
	save = s;

	end = NULL;

	cutoff = STRTOL_ULONG_MAX / (BrULONG) base;
	cutlim = STRTOL_ULONG_MAX % (BrULONG) base;

	overflow = 0;
	i = 0;
	for (c = *s; c != '\0'; c = *++s)
	{
		if (s == end)
			break;
		if (c >= '0' && c <= '9')
			c -= '0';
		else if (IS_ALPHABET(c))
			c = BrToUpper(c) - 'A' + 10;
		else
			break;
		if ((int) c >= base)
			break;
		/* Check for overflow.  */
		if (i > cutoff || (i == cutoff && c > cutlim))
			overflow = 1;
		else
		{
			i *= (BrULONG) base;
			i += c;
		}
	}

	/* Check if anything actually happened.  */
	if (s == save)
		goto noconv;

	/* Store in ENDPTR the address of one character
	past the last character we converted.	*/
	if (endptr != NULL)
		*endptr = (char *) s;

	if (overflow)
	{
		return STRTOL_ULONG_MAX;
	}

	/* Return the result of the appropriate sign.  */
	return negative ? -i : i;

noconv:
	/* We must handle a special case here: the base is 0 or 16 and the
	first two characters are '0' and 'x', but the rest are no
	hexadecimal digits.  This is no error case.  We return 0 and
	ENDPTR points to the `x`.	*/
	if (endptr != NULL)
	{
		if (save - nptr >= 2 && BrToUpper(save[-1]) == 'X' && save[-2] == '0')
			*endptr = (char *) &save[-1];
		else
			/*	There was no number to convert.  */
			*endptr = (char *) nptr;
	}

	return 0L;
}
#endif

void BrTerminate(char* pFile, int nLine, PoError err, const char* msg, PO_ErrorClassType classtype)
{	
	BRCONTEXT;
	Brcontext.m_GeneralValue.SetViewerTerminate(BrTRUE);
	BRTHREAD_ASSERT(0);
	
	//Andrew. terminate�߻��� �ݽ��� ������ �α�
	g_pBInterfaceHandle->SetLoadCallstack(true);
	SetErrorInfoList(err, pFile, nLine, "", msg, true, 0, classtype);
	g_pBInterfaceHandle->SetLoadCallstack(false);

	if( BrIsMasterThread())
	{
		SetThreadAtomError(err);		
	}
	else 
	{
		//multicore �����忡�� ������ �ۿ��� ó���ϵ��� �������� �����ϰ� ����
		SetThreadAtomError(kPoErrTerminateOnSlaveThread);
		return;
	} 
		
#ifdef BRMEMORY_DEBUG_TRACE	
	if(g_pHeapTrace)
		g_pHeapTrace->clear();
#endif //BRMEMORY_DEBUG_TRACE

	// ���� �޸� ���������� txt���Ϸ� ������
	
	DebugMemInfo();	

	Painter* pPainter = getPainter();
	if(pPainter)
	{
		if(pPainter->m_bPrintToImg		// print �ÿ��� termination ����
			&& !pPainter->m_bSaveToPdf	// ��Ʈ ���� �������� ������ pdf �������� �ÿ��� m_bPrintToImg �÷��� �Ѽ� ����ϱ� ������ !m_bSaveToPdf üũ �߰�
			)
			return;
		if(pPainter->m_bSaveHtml)	// savememo �ÿ��� termination ����
			return;
	}

	#ifdef USE_MEMCHECK
	{
		extern B_MEM_POOL*		gpMemPool;

		if( gpMemPool )
		{
			extern void meminfo(int nBlock, int* pfree_block_space, int* pfree_block_max );
			extern void meminfo_ex(int nBlock, int* pused_block_space, int* pused_block_max );
			int pfree_block_space, pfree_block_max;
			int pused_block_space, pused_block_max;
			meminfo(0, &pfree_block_space, &pfree_block_max );
			meminfo_ex(0, &pused_block_space, &pused_block_max );
		
			meminfo(1, &pfree_block_space, &pfree_block_max );
			meminfo_ex(1, &pused_block_space, &pused_block_max );

			meminfo(2, &pfree_block_space, &pfree_block_max );
			meminfo_ex(2, &pused_block_space, &pused_block_max );

			meminfo(3, &pfree_block_space, &pfree_block_max );
			meminfo_ex(3, &pused_block_space, &pused_block_max );

			meminfo(4, &pfree_block_space, &pfree_block_max );
			meminfo_ex(4, &pused_block_space, &pused_block_max );
		
			meminfo(5, &pfree_block_space, &pfree_block_max );
			meminfo_ex(5, &pused_block_space, &pused_block_max );

			meminfo(6, &pfree_block_space, &pfree_block_max );
			meminfo_ex(6, &pused_block_space, &pused_block_max );

			meminfo(7, &pfree_block_space, &pfree_block_max );
			meminfo_ex(7, &pused_block_space, &pused_block_max );

			meminfo(-1, &pfree_block_space, &pfree_block_max );
			meminfo_ex(-1, &pused_block_space, &pused_block_max );
		}
	}
	#endif
	
	g_BoraThreadAtom.m_nLoadStatus = LOAD_STATUS_END;
	g_BoraThreadAtom.m_nRetOpen = err;	// Out of Memory

#ifdef BORA_THREAD_SUPPORT
	Brcontext.m_GeneralValue.SetViewerTerminate(BrTRUE);
#else
	Brcontext.m_GeneralValue.UseBookmark = BrFALSE;
#endif

	// BoraMainThread������ throw�� B_Init ������ �߻�
	if(!IsThreadMgrInit(Brcontext) || !gpFontManager )
	{
		Brcontext.m_GeneralValue.SetViewerTerminate(BrFALSE);
		BrLongJmpOnlyInit(gJumpBuf, -1);
	}
	else
	{
		if (B_IsThreadRunning(BORA_LONGPROCESS_THREAD_ID) && BRGUI_SAVE_EVENT == GetLongProcessThreadEventType())
		{
			if (err == kPoErrMemory)
			{
				//���� ������ ���� �� terminate�ÿ��� ������ ���з� ó��
				Brcontext.m_GeneralValue.SetViewerTerminate(BrFALSE);
				B_TerminateThread(BORA_LONGPROCESS_THREAD_ID, kThreadSaveCancelErr);
				return;
			}
		}
		//������ ���� ���°� �ƴ� ��� longjmp�Ͽ� BrSetGuiEvent�Լ��� �����Ѵ�.
		if (!B_IsThreadRunning(BORA_BASE_THREAD_ID) &&
			!B_IsThreadRunning(BORA_BG_CACHE_THREAD_ID) &&
			!B_IsThreadRunning(BORA_BGLOAD_THREAD_ID) &&
			!B_IsThreadRunning(BORA_LONGPROCESS_THREAD_ID))
		{
			brthread_longjmp(g_pBInterfaceHandle->m_SyncFuncJumpBuf, -1);
		}
		else if(BoraOnMainThread(Brcontext) )
		{
			THREAD_TRACE(("%s(%d) : gJumpBuf longjmp on mainthread!\n", __FILE__, __LINE__));
			brthread_longjmp(get_ThreadJmpBuf(Brcontext), -1);
		}
		else
			BrLongJmp(gJumpBuf, -1);
	}
}

#ifdef SHEET_HEADER_FOOTER_EDIT
void clearFontDataArray(BrHFFontData** a_pFontDataArray, BrUINT32 nFontDataCount)
{
	if(a_pFontDataArray == BrNULL || nFontDataCount == 0)
		return;

	for(BrINT32 i = 0; i < nFontDataCount; i++)
		BR_SAFE_FREE(a_pFontDataArray[i]);
}

void BrSheetHeaderFooterFreeEx(BrSheetHeaderFooter& a_refHeaderFooter)
{
	BR_SAFE_FREE(a_refHeaderFooter.stLeft.stPictureInfo.stImageData.pixels);
	BR_SAFE_FREE(a_refHeaderFooter.stCenter.stPictureInfo.stImageData.pixels);
	BR_SAFE_FREE(a_refHeaderFooter.stRight.stPictureInfo.stImageData.pixels);

	BR_SAFE_FREE(a_refHeaderFooter.stLeft.pFontDataArray);
	BR_SAFE_FREE(a_refHeaderFooter.stCenter.pFontDataArray);
	BR_SAFE_FREE(a_refHeaderFooter.stRight.pFontDataArray);
}
#endif	// SHEET_HEADER_FOOTER_EDIT

// �̺�Ʈ ����ü���� �ɹ��� free�ؾ� �ϴ� ��쿡 ���
void BrEventFreeEx(BrLPVOID pBaseEvent)
{
	if(pBaseEvent == BrNULL)
		return;

	switch (((LPBrBaseEventType)pBaseEvent)->nType)
	{
	case BRPRINT_EVENT :
		{
			LPBrPrintEventType pEvent = (LPBrPrintEventType)pBaseEvent;
			if ( pEvent->szPageBoundary )
			{
				// BrMalloc�� ����� ���(malloc�� �ڵ忡�� �ݵ�� Ȯ��)
				BrFree( pEvent->szPageBoundary );
				pEvent->szPageBoundary = BrNULL;
			}
			if ( pEvent->szOutputPath )
			{
				// BrMalloc�� ����� ���(malloc�� �ڵ忡�� �ݵ�� Ȯ��)
				BrFree( pEvent->szOutputPath );
				pEvent->szOutputPath = BrNULL;
			}
			if ( pEvent->szOutputFilename )
			{
				// BrMalloc�� ����� ���(malloc�� �ڵ忡�� �ݵ�� Ȯ��)
				BrFree( pEvent->szOutputFilename );
				pEvent->szOutputFilename = BrNULL;
			}
		}
		break;
	case BRIMAGETOPDF_EVENT :
		{
			LPBrImageToPdfEventType pEvent = (LPBrImageToPdfEventType)pBaseEvent;
			BR_SAFE_FREE(pEvent->pImagePaths);
			if(pEvent->pImageBufs != BrNULL)
			{
				//BrINT nPages = BrMIN(BORA_MAX_IMAGETOPDF_FILES, pEvent->nImageCount);
				BrINT nPages = pEvent->nImageCount;
				for(int i = 0; i < nPages; i++)
					BR_SAFE_FREE(pEvent->pImageBufs[i].imageBuf);
				BR_SAFE_FREE(pEvent->pImageBufs);
			}
		}
		break;
	case BRSETPAGE_EVENT:
		{
			LPBrSetPageEventType pEvent = (LPBrSetPageEventType)pBaseEvent;
			if ( pEvent->pMultiSheetTabIndex != BrNULL )
				BR_SAFE_FREE(pEvent->pMultiSheetTabIndex);
		}
		break;
	case BRCHARTINSERTMODIFY_EVENT:
		{
			BrChartModifyEvent* pEvent = (BrChartModifyEvent*)pBaseEvent;
			pEvent->chartDataClear();
		}
		break;
	case BRSHEETHIDESHOWROWCOLLIST_EVENT :
		{
			LPBrSheetHideShowRowColListEventType pEvent = (LPBrSheetHideShowRowColListEventType)pBaseEvent;
			BR_SAFE_FREE(pEvent->pRowColList);
		}
		break;
	case BRSHEET_AUTOFILTERCOMMAND_EVENT :
		{
			LPBrSheetAutoFilterEventType pEvent = (LPBrSheetAutoFilterEventType)pBaseEvent;
			if ( pEvent->sCommandString )
			{
				BrString* pDstBrString = (BrString*)pEvent->sCommandString;

				delete [] pDstBrString;
				pEvent->sCommandString = BrNULL;
			}
		}
		break;
	case BRSHEETCOLOR_EVENT:
		{
			LPBrSheetColorEventType pEvent = (LPBrSheetColorEventType)pBaseEvent;
			if ( pEvent->nMultiSheetTabCount > 0 )
				BR_SAFE_FREE(pEvent->pMultiSheetTabIndex);
		}
		break;
	case BRSHEETSORTEXTEND_EVENT:
		{
			LPBrSheetSortExtendEventType pEvent = (LPBrSheetSortExtendEventType)pBaseEvent;
#ifdef SHEET_SORT_STANDARD_ADDITION
			if ( pEvent->pSortDetailInfoArray != BrNULL )
				BR_SAFE_FREE(pEvent->pSortDetailInfoArray);
#else
			if ( pEvent->pKeys != BrNULL )
				BR_SAFE_FREE(pEvent->pKeys);
#endif // SHEET_SORT_STANDARD_ADDITION
		}
		break;
	case BRSHEETPROTECTEDRANGE_EVENT:
		{
			BrSheetEditProtectedRangeEventType* pEvent = (BrSheetEditProtectedRangeEventType*)pBaseEvent;
			if ( pEvent->pPrList != BrNULL )
				BR_SAFE_FREE(pEvent->pPrList);
		}
		break;
	case BRSHEETSETTEXTBOXTEXT_EVENT:
		{
			LPBrSheetSetTextboxTextEventType pEvent = (LPBrSheetSetTextboxTextEventType)pBaseEvent;
			if ( pEvent->szText != BrNULL )
				BR_SAFE_FREE(pEvent->szText);
		}
		break;
	case BRSHEETDELETEDEFINEDNAME_EVENT:
		{
			LPBrSheetDeleteDefinedNameEventType pEvent = (LPBrSheetDeleteDefinedNameEventType)pBaseEvent;
			if ( pEvent->selectedNameNum > 0 )
			{
				for ( int nIndex = 0 ; nIndex < pEvent->selectedNameNum ; nIndex++ )
				{
					BR_SAFE_FREE( pEvent->strDefinedName[nIndex] );
					BR_SAFE_FREE( pEvent->strUseRange[nIndex] );
				}
				BR_SAFE_FREE( pEvent->strDefinedName );
				BR_SAFE_FREE( pEvent->strUseRange );
			}
		}
		break;
	case BRSHEETAPPLYDEFINEDNAME_EVENT:
		{
			LPBrSheetApplyDefinedNameEventType pEvent = (LPBrSheetApplyDefinedNameEventType)pBaseEvent;
			if ( pEvent->selectedNameNum > 0 )
			{
				for ( int nIndex = 0 ; nIndex < pEvent->selectedNameNum ; nIndex++ )
					BR_SAFE_FREE( pEvent->strDefinedName[nIndex] );
				BR_SAFE_FREE( pEvent->strDefinedName );
			}
		}
		break;
	case BRSHEETEDITCF_EVENT:
		{
			LPBrSheetEditCFEventInfo pEvent = (LPBrSheetEditCFEventInfo)pBaseEvent;
			if ( pEvent->pCFList != BrNULL )
				BR_SAFE_FREE(pEvent->pCFList);
		}
		break;
	case BRSHEETEDIT_EVENT:
		{
			LPBrSheetEditEventType pEvent = (LPBrSheetEditEventType)pBaseEvent;
			if ( pEvent->pMultiSheetTabIndex != BrNULL )
				BR_SAFE_FREE(pEvent->pMultiSheetTabIndex);
		}
		break;
	case BRSHEETHIDESHOW_EVENT:
		{
			LPBrSheetHideShowEvent pEvent = (LPBrSheetHideShowEvent)pBaseEvent;
			if ( pEvent->pMultiSheetTabIndex != BrNULL )
				BR_SAFE_FREE(pEvent->pMultiSheetTabIndex);
		}
		break;
	case BRSHEETBACKGROUND_EVENT:
		{
			LPBrSheetBackgroundEventType pEvent = (LPBrSheetBackgroundEventType)pBaseEvent;
			BR_SAFE_FREE(pEvent->stImageData.pixels);
		}
		break;
#ifdef SHEET_HEADER_FOOTER_EDIT
	case BRSHEETHEADERFOOTER_EVENT:
		{
			LPBrSheetHeaderFooterEventType pEvent = (LPBrSheetHeaderFooterEventType)pBaseEvent;
			BrSheetHeaderFooterFreeEx(pEvent->stHeaderFooterData.stOddHeader);
			BrSheetHeaderFooterFreeEx(pEvent->stHeaderFooterData.stOddFooter);
			BrSheetHeaderFooterFreeEx(pEvent->stHeaderFooterData.stEvenHeader);
			BrSheetHeaderFooterFreeEx(pEvent->stHeaderFooterData.stEvenFooter);
			BrSheetHeaderFooterFreeEx(pEvent->stHeaderFooterData.stFirstHeader);
			BrSheetHeaderFooterFreeEx(pEvent->stHeaderFooterData.stFirstFooter);
		}
		break;
#endif	// SHEET_HEADER_FOOTER_EDIT
	case BRBWPINSERTSTRING_EVENT:
		{
			BrSetInsertStringEventType* pEvent = (BrSetInsertStringEventType*)pBaseEvent;
			BR_SAFE_FREE(pEvent->inputString);
		}
		break;
	case BREDITCOPY_EVENT:
	case BREDITPASTE_EVENT:
	case BREDITCUT_EVENT:
	case BREDITCLONE_EVENT:
	case BREDITCOPY_FORMAT_EVENT:
	case BRSHEETCOPY_IMAGE_EVENT:
		{
			//Andrew C.Lee �̺�Ʈ ������ deep copy�ϵ��� �ؼ� event free�� �����ؾ� ��
			//�����忡�� ����� ��� �ű⼭�� �۾��� �ʿ�
			LPBrEditEventType pEvent = (LPBrEditEventType)pBaseEvent;
			BR_SAFE_FREE(pEvent->pData);
			BR_SAFE_FREE(pEvent->pText);
			BR_SAFE_FREE(pEvent->pClipBoardFileName);		
			
			for (int i = 0; i < pEvent->nImagePathCount; i++)
			{
				BR_SAFE_DELETE(pEvent->pImagePaths[i]);
				BR_SAFE_DELETE(pEvent->pContentIDs[i]);
			}
			BR_SAFE_DEL_ARRAY(pEvent->pImagePaths);
			BR_SAFE_DEL_ARRAY(pEvent->pContentIDs);
		}
		break;
#ifdef PPT_EDITOR
	case BRPPTSLIDEINSERT_EVENT:
	case BRPPTSLIDEDELETE_EVENT:
	case BRPPTSLIDEMOVEPREV_EVENT:
	case BRPPTSLIDEMOVENEXT_EVENT:
	case BRPPTSLIDEMOVEEX_EVENT:
	case BRPPTSLIDEDUPLICATE_EVENT:
	case BRPPTSLIDELAYOUT_EVENT:
	case BRPPTSLIDECOPY_EVENT:
	case BRPPTSLIDECUT_EVENT:
	case BRPPTSLIDEPASTE_EVENT:
		{
			BrPPTSlideInsDelEventType* pEvent = (BrPPTSlideInsDelEventType*)pBaseEvent;
			if(pEvent->stPageListInfo.nMasterPageInfoCnt > 0)
			{
				for(int i = 0; i < pEvent->stPageListInfo.nMasterPageInfoCnt; i++)
				{
					if(pEvent->stPageListInfo.pMasterPageInfo)
					{					
						BrPPTSlideMasterPageListInfo* pMasterInfo = pEvent->stPageListInfo.pMasterPageInfo + i;									
						BR_SAFE_FREE(pMasterInfo->pLayoutPageList);
					}
				}
				BR_SAFE_FREE(pEvent->stPageListInfo.pMasterPageInfo);
			}

			if(pEvent->stPageListInfo.pPageList)
				BR_SAFE_FREE(pEvent->stPageListInfo.pPageList);
		}
		break;
#endif//#ifdef PPT_EDITOR

		//USE_SHEET_PIVOT_TABLE_2017
	case BRSHEETPIVOTTABLECREATE_EVENT:
		{
			BrSheetPivotTableCreateEventType* pEvent = (BrSheetPivotTableCreateEventType*)pBaseEvent;
			if(pEvent->pSrcRange){	BR_SAFE_FREE(pEvent->pSrcRange);	}
			if(pEvent->pDstRange){	BR_SAFE_FREE(pEvent->pDstRange);	}
		}
		break;
		//USE_SHEET_PIVOT_TABLE_2017

#ifdef XLSX_TEXT_IMPORT_WIZARD
	case BRSHEETTEXTIMPORTWIZARD_EVENT :
		{
			LPBrSheetTextImportWizardEventType pEvent = (LPBrSheetTextImportWizardEventType)pBaseEvent;
			BR_SAFE_FREE(pEvent->pArrWidths);
		}
		break;
#endif //XLSX_TEXT_IMPORT_WIZARD
	case BRCHARTBWPSETVALUE_EVENT:
		{
			LPBrChartBWPSetValueEventType pEvent = (LPBrChartBWPSetValueEventType)pBaseEvent;
			BR_SAFE_FREE(pEvent->pDataArray);
		}
		break;
#ifdef USE_COLLABORATION
	case BRCOLLABORATIONCOWORKERSINFO_EVENT :
		{
			LPBrCollaborationCoworkersInfoEventType pEvent = (LPBrCollaborationCoworkersInfoEventType)pBaseEvent;
			BR_SAFE_FREE(pEvent->pCoworkerInfo);
		}
		break;
	case BRCOLLABORATIONSYNCCOMMANDLIST_EVENT :
		{
			LPBrCollaborationSyncCommandListEventType pEvent = (LPBrCollaborationSyncCommandListEventType)pBaseEvent;
			for ( int nIndex = 0 ; nIndex < pEvent->nCommandListCount ; nIndex++ )
				BR_SAFE_FREE(pEvent->pCommandList[nIndex].pJsonCommand);
			BR_SAFE_FREE(pEvent->pCommandList);
		}
		break;
	break;
	case BRCOLLABORATIONUPDATECONTENT_EVENT :
		{
			LPBrCollaborationUpdateContentEventType pEvent = (LPBrCollaborationUpdateContentEventType)pBaseEvent;
			for ( int nIndex = 0 ; nIndex < pEvent->nContentListCount ; nIndex++ )
				BR_SAFE_FREE(pEvent->pContentList[nIndex].pContentFilePath);
			BR_SAFE_FREE(pEvent->pContentList);
		}
		break;
	case BRCOLLABORATIONSELECTFRAMES_EVENT:
		{
			BrCollaborationSelectFramesEvent *pEvent = (BrCollaborationSelectFramesEvent*)pBaseEvent;
			if(pEvent)
				BR_SAFE_FREE(pEvent->pSpid);
		}
	default:
		{
			if ( doCollaborationCheckExecutionEvent( ((LPBrBaseEventType)pBaseEvent)->nType ) )
			{
				LPBrCollaborationEventType pEvent = (LPBrCollaborationEventType)pBaseEvent;
				BR_SAFE_FREE(pEvent->pJsonCommand);
			}
		}
		break;
#endif // USE_COLLABORATION
	}

	BrEventFree(pBaseEvent);
}

#if defined(NOT_USE_GLOBAL_VARIABLE)
BrBOOL IsFinalModeHandle(void * pInterfaceHandle){
	return ((BInterfaceHandle*)pInterfaceHandle)->m_bFinalMode;
}
#endif

BrBOOL BrGetTagetModelName(BrCHAR * pModel, BrINT nSize)
{
	BrINT nLen = nSize;
#ifdef TARGET_NAME_LIST
	extern int GetDeviceInfoEx(int nid, void* pBuff, int * nSize);	
	GetDeviceInfoEx(0, pModel, &nLen);
	return BrTRUE;
#endif //TARGET_NAME_LIST
	return BrFALSE;
}

#ifdef __cplusplus
}
#endif

#ifdef NOT_USE
BrDOUBLE GetImageScaleRatio(BrINT32 nImgWidth, BrINT32 nImgHeight)
{
	BrINT32 nIntRatio=1;
	BrFLOAT dIntRatio = BrMAX((BrFLOAT)nImgWidth / (BrFLOAT)getDeviceScreenWidth(), (BrFLOAT)nImgHeight / (BrFLOAT)getDeviceScreenHeight());
	if (dIntRatio >= 8.0)	
		nIntRatio = 8;
	else if (dIntRatio >= 4.0)
		nIntRatio = 4;
	else if (dIntRatio >= 2.0)
		nIntRatio = 2;
	else
		nIntRatio=1;

	return nIntRatio;
}
#endif

BrINT32 BoraUTF8ToWideChar(  BrLPCSTR  utf8 , BrINT32 utf_len, BrLPWSTR uni, BrINT32 unisize)
{
	#define MAXIMUM_UCS2            0x0000FFFF
	#define MAXIMUM_UTF16             0x0010FFFF

	#define UTF8_IS_TRAIL( ch ) ( (ch & 0xc0)==0x80 )

	static const unsigned char UTF8_HEAD_ADDED[7] = { 0,
	  0, 0xC0 , 0xE0 , 0xF0 , 0xF8 , 0xFC 
	};

	static const INT8 bytesFromUTF8[256] = {
	  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
	  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 6, 6, 0, 0
	};

	//
	unsigned char *p = (unsigned char *) utf8;

	int len = utf_len;
	if( utf_len == -1 )
		len = BrStrLen( utf8 );
	
	const unsigned char *p_out = (unsigned char *) (utf8 + len);
	

	
 	if( unisize <= 0 || uni == BrNULL ) //���� ����� 0 üũ �ϴ� ���ε�. ���� ����.
	{		//����� ���. 

		int count = 0;
		while( p < p_out )
		{
			if( bytesFromUTF8[*p] == 0 )
			{
				//illegal utf
				return count;
			}
			else
			{
				if( p+bytesFromUTF8[*p] > p_out )
					return count;  //illegal utf
			}			
			if( bytesFromUTF8[*p] > 3 )
				count+=2;
			else
				count++;

			p+=bytesFromUTF8[*p];			
		}

		if( utf_len == -1 )
			count++; // NULL Terminator INCLUDE

		return count;
	}

	unsigned short *target = uni;
	const unsigned short *target_out = ( uni + unisize );
	BrUINT32 ch = 0;
	int i, inBytes;

	while( p < p_out && target < target_out )
	{
		if( *p < 0x80 )        /* Simple case */
		{
			*(target++) = (unsigned short) *p++;
		}
		else
		{
			/* store the first char */
			inBytes = bytesFromUTF8[*p]; /* lookup current sequence length */
			
			if( inBytes == 0 )
			{
				//illegal utf
				*(target++) = (unsigned short)'\0';
				return (BrINT32)(target - uni);// ������ �������� ��������.
			}
			else
			{
				if( p+inBytes > p_out )
				{
					//illegal utf
					*(target++) = (unsigned short)'\0';
					return (BrINT32)(target - uni);// ������ �������� ��������.
				}

				if( inBytes > 3 && target+2 > target_out )
				{
					//illegal utf
					*(target++) = (unsigned short)'\0';
					return (BrINT32)(target - uni);// ������ �������� ��������.
				}
			}

			//utf_check
			for( i=1; i<inBytes; i++ )
			{
				if( !UTF8_IS_TRAIL(  *(p+i)  ) )
				{
					//illegal utf
					*(target++) = (unsigned short)'\0';
					return (BrINT32)(target - uni);// ������ �������� ��������.
				}
			}
				
			//���� ��� ��ƾ.

			ch = *p - UTF8_HEAD_ADDED[inBytes];
			for( i=1; i<inBytes; i++ )
			{
				ch = (ch << 6 );
				ch += ( (*(p+i)) & 0x3F );
			}

			if( ch <=  MAXIMUM_UCS2 )
			{
				*(target++) = (unsigned short)ch;
			}
			else if( ch > MAXIMUM_UTF16 )
			{
				//illegal utf
				*(target++) = (unsigned short)'\0';
				return (BrINT32)(target - uni);// ������ �������� ��������.
			}
			else
			{
				// pair surrogate
				ch -= 0x10000;

				*(target++) = (unsigned short) ( (ch >> 10) + 0xD800);
				*(target++) = (unsigned short) ( (ch & 0x3FF) + 0xDC00 );
			}

			p+=inBytes;
		}
	}

	if( utf_len == -1 )
		*(target++) = (unsigned short)'\0';// ���͹̳����� ����
	
	return (BrINT32)(target - uni);
}

void BrChnageUnicodeByteOrder(BrUSHORT* pSrc,BrINT nSrcLen, BrUSHORT* pDst)
{
	if(pDst && pSrc && nSrcLen)
	{
		BrINT i;
		for(i = 0; i < nSrcLen; i++)		
			pDst[i] = (BrUSHORT)(((pSrc[i] << 8) & 0xff00) | ((pSrc[i] >> 8) & 0x00ff));

		pDst[i] = 0;
	}	
}

BrLONG changeBGRtoRGBColor(BrLONG abgr)
{
	if ((abgr & 0xffffffff) == 0xffffffff)
		return 0x00000000;

	BrLONG blue_mask = 0x00ff0000;
	BrLONG green_mask = 0x0000ff00;
	BrLONG red_mask = 0x000000ff;

	BrINT argb = (blue_mask&abgr)>>16 | green_mask&abgr | (red_mask&abgr)<<16 | (0xff000000&abgr);

	return argb ;
}

BrLONG changeRGBtoBGRColor(BrLONG argb)
{
	if ( argb == 0x00000000)
		return NONE_COLOR_BITS;

	BrLONG red_mask 	= 0x00ff0000;
	BrLONG green_mask 	= 0x0000ff00;
	BrLONG blue_mask 	= 0x000000ff;

	BrINT bgr = (red_mask&argb)>>16 | green_mask&argb | (blue_mask&argb)<<16 | (0x00000000&argb);

	return bgr;
}

unsigned int toUnicodeSlimEDITOR(const char* chars, int len, unsigned short* output)
{
	int nRet = 0;
	nRet = BrMultiByteToWideChar( CP_UTF8, (BrLPCSTR)chars, BrStrLen(chars), (BrLPWSTR)output, len );
	if (nRet==0  || *output == '\0' )
		nRet = BrMultiByteToWideChar( CP_ACP, (BrLPCSTR)chars, BrStrLen(chars), (BrLPWSTR)output, len );

	return nRet;
}

unsigned int toUnicodeSlim(const char* chars, int len, unsigned short* output)
{
	int nRet = 0;
	nRet = BrMultiByteToWideChar( CP_ACP, (BrLPCSTR)chars, BrStrLen(chars), (BrLPWSTR)output, len );
	if (nRet==0)
		nRet = BrMultiByteToWideChar( CP_UTF8, (BrLPCSTR)chars, BrStrLen(chars), (BrLPWSTR)output, len );

	return nRet;
}

// wide to utf, �̶� ���� UTF8�� ���̸� ���� 
BrINT32 BoraWideCharToUTF8(  BrLPWSTR uni, int uni_len, OUT LPBYTE utf8, int nMaxSize, bool bUseUCS4 /*= TRUE*/ )
{
	unsigned short *src = (unsigned short *)uni;

	int len = uni_len;
	if( len==-1)
		len  = BrWcsLen( uni );

	const unsigned short *src_out = src + len;


	if( nMaxSize <= 0 || utf8 == BrNULL )
	{
		int count = 0; //������ ��� ��ƾ.
		while( src < src_out )
		{
			if( *src < 0x80 )
			{
				count++;
			}
			else if( *src < 0x800 )
			{
				count+=2;
			}
			else
			{
				if( bUseUCS4 )
				{
					if( UTF_IS_SURROGATE_LEAD( *src ) )
					{
						if( src+1 >= src_out )
						{
							count++;// ?�� ��ȯ �Ұ���.
						}
						else if( UTF_IS_SURROGATE_TRAIL( *(src+1) ) )
						{   
							// ����ó��.
							count+=4;
							src++;// ��ĭ �̵�.
						}
						else
						{
							count++;// first �� ?�� ��ȯ �Ұ���.
						}
					}
					else if( UTF_IS_SURROGATE_TRAIL( *src ) )
					{
						//second�� ���� ���� �����.
						count++;// ?�� ��ȯ �Ұ���.
					}
					else
						count+=3;
				}
				else
					count+=3;
			}

			src++;
		}

		if( uni_len == -1 )
			count++;

		return count;

	}		

	unsigned char *target = (unsigned char *) utf8;
	const unsigned char *target_out = target+nMaxSize;
	unsigned int ch;

	while( src < src_out && target < target_out )
	{
		if( *src < 0x80 )
		{
			*target++ = (unsigned char) *src;
		}
		else if( *src < 0x800 )
		{
			if( target+1 >= target_out )
			{
				*target++ = '\0';
				break;
			}
			ch = *src >> 6;
			*target++ =  (unsigned char) ( ch+0xC0 ); 
			ch = ( *src & 0x3F );
			*target++ =  (unsigned char) ( ch+0x80 ); 
		}
		else
		{
			if( bUseUCS4 )
			{
				if( UTF_IS_SURROGATE_LEAD( *src ) )
				{
					if( src+1 >= src_out )
					{
						*target++ = '?' ;// ?�� ��ȯ �Ұ���.
					}
					else if( UTF_IS_SURROGATE_TRAIL( *(src+1) ) )
					{
						if( target+3 >= target_out )
						{
							*target++ = '\0';
							break;
						}

						// ����ó��.
						unsigned int ch2 = *src;
						ch2 = ( ch2 & 0x3FF );
						ch2 = ( ch2 << 10 ) + ( *(src+1) & 0x3FF );
						ch2 += 0x10000;

						ch = ch2 >> 18;
						*target++ =  (unsigned char) ( ch+0xF0 ); 
						ch = ( ch2 >> 12 ) & 0x3F ;
						*target++ =  (unsigned char) ( ch+0x80 ); 
						ch = ( ch2 >> 6 ) & 0x3F ;
						*target++ =  (unsigned char) ( ch+0x80 ); 
						ch = ( ch2 & 0x3F );
						*target++ =  (unsigned char) ( ch+0x80 ); 


						src++;// ��ĭ �̵�.
					}
					else
					{
						*target++ = '?';// first �� ?�� ��ȯ �Ұ���.
					}
				}
				else if( UTF_IS_SURROGATE_TRAIL( *src ) )
				{
					//second�� ���� ���� �����.
					*target++ = '?';// ?�� ��ȯ �Ұ���.
				}
				else
				{
					if( target+2 >= target_out )
					{
						*target++ = '\0';
						break;
					}
					ch = *src >> 12;
					*target++ =  (unsigned char) ( ch+0xE0 ); 
					ch = ( *src >> 6 ) & 0x3F ;
					*target++ =  (unsigned char) ( ch+0x80 ); 
					ch = ( *src & 0x3F );
					*target++ =  (unsigned char) ( ch+0x80 ); 
				}
			}
			else
			{
				if( target+2 >= target_out )
				{
					*target++ = '\0';
					break;
				}

				ch = *src >> 12;
				*target++ =  (unsigned char) ( ch+0xE0 ); 
				ch = ( *src >> 6 ) & 0x3F;
				*target++ =  (unsigned char) ( ch+0x80 ); 
				ch = ( *src & 0x3F );
				*target++ =  (unsigned char) ( ch+0x80 ); 
			}
				
		}

		src++;
	}

	if( uni_len == -1 )
		*target++ = '\0';

	return (BrINT32)(target-utf8);

}


BrINT32 BoraMultiByteToWideChar_UTF8(  BrLPCSTR  lpMultiByteStr , BrINT32 cbMultiByte , BrLPWSTR lpWideStr , BrINT32 cchWideChar )
{

	return BoraUTF8ToWideChar( lpMultiByteStr ,  cbMultiByte ,  lpWideStr , cchWideChar );

	//���� lpMultiByteStr�� \0 �� ������  cbMultiByte�� -1�� �� �� �ִ�. �̶� ��Ƽ���� \0���� �����ϹǷ� �����ϴ� ���� \0���� �����ϴ� �����̴�.
		//�� �̶� lpWideStr�� ���� �ִ´ٸ� �̰����� \0�� ���Ե� ���̴�.
	//     cchWideChar = 0 �϶� lpWideStr�� ���õǸ� ���ϰ��� ���̵�� ����� ���� ���̵��� �����̴�. cbMultiByte==-1�̸� 0�� ����

	// �޸� ������ �۰ų� �ϸ� 0�� �����ؾ� �Ѵ�.

	//��Ƽ ����Ʈ�� �������� �������Ʈ�� ������ ���� ������ ���� ����Ʈ�� \0���� �����ϸ� �� \0���� �ؼ��� ����Ʈ�� �Ѱ��� ���̵� ����Ʈ�� �ؼ��Ͽ� ���� ������ ���Խ�Ų��. 

	int wi =  0;
	BrBYTE* p = (BrBYTE*) lpMultiByteStr;

	BrBYTE b = 0;
	BrBYTE b2 =0;
	BrWCHAR wideChar = 0;

//	BrWCHAR  w = 0;

	if( cbMultiByte < -1 || cbMultiByte == 0 )
		return 0;


	{
		if( cchWideChar == 0 )
		{
			//�ʿ��� ������ ���� , lpWideStr�� ���� ���� �ʴ´�.
			
			if( cbMultiByte == -1 )
			{
				// \0 �� ���ö� ���� ���. �Ǵ� Tail byte�� 0�϶� ���� ó�� �Ѵ�.
				while( 1 ) 
				{
					b = *p;

					if( b < 0x80 )
					{
						p++;
					}
					else if( b < 0xe0 )
					{
						p++;
						if( *p == 0 )
						{
							p++;
						}
						else
						{
							p++;
						}
					}
					else if( b < 0xf0 )
					{
						p++;
						if( *p == 0 )
						{
							p++;
							p++;
						}
						else
						{
							p++;
							if( *p == 0 )
							{
								p++;
							}
							else
							{
								p++;
							}
						}
					}
					else if( b < 0xf8 )
					{

						p++;
						if( *p == 0 )
						{
							p++;
							p++;
							p++;
						}
						else
						{
							p++;
							if( *p == 0 )
							{
								p++;
								p++;
							}
							else
							{
								p++;
								if( *p == 0 )
								{
									p++;
								}
								else
								{
									p++;
									wi++;
								}
							}
						}

					}
					else
					{
						//�����ڵ� ������ �Ѿ� ���� ���� ��� �Խ��ϴ�.
						//�����ڵ� ������ �Ѿ� ���� �ѱ��ڷ� ���� �մϴ�.
						p++;
						//return 0;
					}

					wi++;

					if( b == 0 )
						return wi;
				}

				//����� ���� Ÿ�� �ʴ´�.
				return 0;

			}
			else
			{
				// ��Ƽ�� ������ �־ �� �������� ����Ѵ�.
				// �ٵ� ���̵� ������ 0�̹Ƿ� ��Ƽ ���� ����ؼ� �� ���̵��� ������ �����ϸ� �ȴ�. 
				// �̶� �߰��� �ִ� \0�� �Ѱ��� ���̵�� �Ի��� �ȴ�. tail byte�� 0�� �ѵ��� ��� 0���� ��ȯ�ȴ�.
			
				BrBYTE* pOut = (BrBYTE*) lpMultiByteStr + cbMultiByte; //����� ���� ���� �ۿ��� �߿� ?��°.

				
				//��Ƽ ����Ʈ �������� ����� ��.
				//��Ƽ ����Ʈ �������� ����� ��.
				while( p  <  pOut ) //������ ����Ʈ ���� ���.
				{

					b = *p;

					if( b < 0x80 )
					{
						p++;
					}
					else if( b < 0xe0 )
					{

						p++;

						if( p == pOut )
						{
							;
						}
						else
						{
							p++;
						}
					}
					else if( b < 0xf0 )
					{
						p++;
						if( p == pOut )
						{
							;
						}
						else
						{
							p++;
							if( p == pOut )
							{
								;
							}
							else
							{
								p++;
							}
						}
					}
					else if( b < 0xf8 )
					{
						p++;
						if( p == pOut )
						{
							;
						}
						else
						{
							p++;
							if( p == pOut )
							{
								;
							}
							else
							{
								p++;
								if( p == pOut )
								{
									;
								}
								else
								{
									p++;
									wi++;
								}
							}
						}

					}
					else
					{
						//�����ڵ� ������ �Ѿ� ���� ���� ��� �Խ��ϴ�.
						//�����ڵ� ������ �Ѿ� ���� �ѱ��ڷ� ���� �մϴ�.
						p++;
						//return 0;
					}

					wi++;
				}

				return wi;
			}

		}
		else  
		{
			//�̺κ��� ���� �V���ϴ� �κ�

			BrWCHAR* pw = (BrWCHAR*) lpWideStr;

			BYTE  utf[4];
			
			if( cbMultiByte == -1 )
			{
				// \0 �� ���ö� ���� ����Ͽ� �V��.

				// �ٵ� ���̵� ������ �����Ƿ� ���̵� ������ �ʰ��� �� 0 �� ������ ������.
				
				// �̶� �߰��� �ִ� \0�� �Ѱ��� ���̵�� �Ի��� �ȴ�. tail byte�� 0�� �ѵ��� ��� 0���� ��ȯ�ȴ�.

				if( cchWideChar < 0 || lpWideStr==NULL ) return 0;		
			
				BrLPWSTR pWideOut = (BrLPWSTR) lpWideStr + cchWideChar; //���̵��� ���� ���� �� �߿��� ?��°.

				// \0�� ���ö� ���� ���.
				while( 1 ) 
				{
					if( pw == pWideOut )
						return 0;

					b = *p;

					if( b < 0x80 )
					{
						*pw = b;
						p++;
					}
					else if( b < 0xe0 )
					{

						utf[0] =( *p & 0x1f );
						p++;

						if( *p == 0 )
						{
							p++;
							*pw = 0;
						}
						else
						{
							utf[1] =( *p & 0x3f );
							p++;
							*pw =  utf[0]*0x40;
							*pw += utf[1];
						}
					}
					else if( b < 0xf0 )
					{
						utf[0] =( *p & 0x0f );
						p++;
						if( *p == 0 )
						{
							p++;
							p++;
							*pw = 0;
						}
						else
						{
							utf[1] =( *p & 0x3f ); 
							p++;
							if( *p == 0 )
							{
								p++;
								*pw = 0;
							}
							else
							{
								utf[2] =( *p & 0x3f );  
								p++;

								*pw =  utf[0] * 0x1000;
								*pw += utf[1] * 0x40;
								*pw += utf[2];
							}
						}
					}
					else if( b < 0xf8 )
					{

						utf[0] =( *p & 0x07 );
						p++;
						if( *p == 0 )
						{
							p++;
							p++;
							p++;
							*pw = 0;
						}
						else
						{
							utf[1] =( *p & 0x3f ); 
							p++;
							if( *p == 0 )
							{
								p++;
								p++;
								*pw = 0;
							}
							else
							{
								utf[2] =( *p & 0x3f ); 
								p++;
								if( *p == 0 )
								{
									p++;
									*pw = 0;
								}
								else
								{
									utf[3] =( *p & 0x3f ); 
									p++;

									//���� ���� ���Ѵ�.
									BrDWORD dword;
									dword = utf[0] * 0x40000;
									dword += utf[1]* 0x1000;
									dword += utf[2]* 0x40;
									dword += utf[3];

									BrDWORD pair = dword - 0x10000;
									
									BrWORD pl= (BrWORD)(pair & 0x3ff); //���� 10bit
									BrWORD ph= (BrWORD)(pair / 0x400); //���� 10bit

									BrWORD uh = ph | 0xd800;
									BrWORD ul = pl | 0xdc00; 

									// ���� �󿡼��� ������ uh ul 
									// ����Ʈ �������� �Ѵٸ�  uh-lowbyte , uh-highbyte , ul-lowbyte , ul-highbyte ������ ���Ͽ� ���� ��
									
									*pw = uh;
									pw++;
									if( pw == pWideOut )
									{
										return 0;
									}
									else
									{
										*pw = ul;
									}
								}
							}
						}

					}
					else
					{
						//�����ڵ� ������ �Ѿ� ���� ���� ��� �Խ��ϴ�.
						//�˼� ���� ���ڷ� �����մϴ�.
						*pw = '?';
						p++;

						//return 0;
					}

					pw++;

					if( b == 0 )
						return (BrINT32)( pw - lpWideStr );
				}

				return 0; //����� ��ź��.

			}
			else
			{
				// ��Ƽ�� ������ �־ �� �������� ����Ѵ�.
				// �ٵ� ���̵� ������ �����Ƿ� ���̵� ������ �ʰ��� �� 0 �� ������ ������.
				// �̶� �߰��� �ִ� \0�� �Ѱ��� ���̵�� �Ի��� �ȴ�. tail byte�� 0�� �ѵ��� ��� 0���� ��ȯ�ȴ�.

				if( cchWideChar < 0 || lpWideStr==NULL ) return 0;		
			
				BrBYTE* pOut = (BrBYTE*) lpMultiByteStr + cbMultiByte; //����� ���� ���� �ۿ��� �߿� ?��°.
				BrLPWSTR pWideOut = (BrLPWSTR) lpWideStr + cchWideChar; //���̵��� ���� ���� �� �߿��� ?��°.

				//��Ƽ ����Ʈ �������� ����� ��.
				while( p  <  pOut ) //������ ����Ʈ ���� ���.
				{
					if( pw == pWideOut )
						return 0;

					b = *p;

					if( b < 0x80 )
					{
						*pw = b;
						p++;
					}
					else if( b < 0xe0 )
					{

						utf[0] =( *p & 0x1f );
						p++;

						if( p == pOut )
						{
							*pw = 0;
						}
						else
						{
							utf[1] =( *p & 0x3f );
							p++;
							*pw =  utf[0]*0x40;
							*pw += utf[1];
						}
					}
					else if( b < 0xf0 )
					{
						utf[0] =( *p & 0x0f );
						p++;
						if( p == pOut )
						{
							*pw = 0;
						}
						else
						{
							utf[1] =( *p & 0x3f ); 
							p++;
							if( p == pOut )
							{
								*pw = 0;
							}
							else
							{
								utf[2] =( *p & 0x3f );  
								p++;

								*pw =  utf[0] * 0x1000;
								*pw += utf[1] * 0x40;
								*pw += utf[2];
							}
						}
					}
					else if( b < 0xf8 )
					{

						utf[0] =( *p & 0x07 );
						p++;
						if( p == pOut )
						{
							*pw = 0;
						}
						else
						{
							utf[1] =( *p & 0x3f ); 
							p++;
							if( p == pOut )
							{
								*pw = 0;
							}
							else
							{

								utf[2] =( *p & 0x3f ); 
								p++;
								if( p == pOut )
								{
									*pw = 0;
								}
								else
								{
									utf[3] =( *p & 0x3f ); 
									p++;

									//���� ���� ���Ѵ�.
									BrDWORD dword;
									dword = utf[0] * 0x40000;
									dword += utf[1]* 0x1000;
									dword += utf[2]* 0x40;
									dword += utf[3];

									BrDWORD pair = dword - 0x10000;
									
									BrWORD pl= (BrWORD)(pair & 0x3ff); //���� 10bit
									BrWORD ph= (BrWORD)(pair / 0x400); //���� 10bit

									BrWORD uh = ph | 0xd800;
									BrWORD ul = pl | 0xdc00; 

									// ���� �󿡼��� ������ uh ul 
									// ����Ʈ �������� �Ѵٸ�  uh-lowbyte , uh-highbyte , ul-lowbyte , ul-highbyte ������ ���Ͽ� ���� ��
									
									*pw = uh;
									pw++;
									if( pw == pWideOut )
									{
										return 0;
									}
									else
									{
										*pw = ul;
									}
								}
							}
						}

					}
					else
					{
						//�����ڵ� ������ �Ѿ� ���� ���� ��� �Խ��ϴ�.
						//���� �ϳ��� ����.
						*pw = '?';
						p++;
						//return 0;
					}

					pw++;
				}

				return (BrINT32)( pw - lpWideStr );

			}
		}
		
		return 0; //����� ��ź��.
	}

	return wi;
}


BrBOOL BrIsUTF_8NoneBOM(BrLPBYTE pByte, int nLen)
{
	// RFC3629 ��Ģ�� ���� UTF-8 No Bom üũ
	if(nLen < 2)
		return BrFALSE;

	for(int i=0; i<nLen; i++)
	{
		int nCase = 0;
		BYTE b = pByte[i];
		if(b < 0x80)	// 0xxxxxxx ASCII
			continue;
		else if(0xC2 <= b && b <= 0xDF)	// 110xxxxx 10xxxxxx
		{
			nCase = 1;
			++i;
		}
		else if(0xE0 <= b && b <= 0xEF)	// 1110xxxx 10xxxxxx 10xxxxxx
		{
			++i;
			if(i < nLen)
			{
				switch(b)
				{
				case 0xE0:
					if(0xA0 <= pByte[i] && pByte[i] <= 0xBF)
					{
						++i;
						nCase = 1;
					}
					break;
				case 0xED:
					if(0x80 <= pByte[i] && pByte[i] <= 0x9F)
					{
						++i;
						nCase = 1;
					}
					break;
				case 0xEE:
				case 0xEF:
					nCase = 2;
					break;
				default:	 
					if(0xE1 <= b && b <= 0xEF)
						nCase = 2;
				}
			}
			else
				return BrFALSE;
		}
		else if(0xE0 <= b && b < 0xEF)	// 11110xxx 10xxxxxx 10xxxxxx 10xxxxxx
		{
			++i;
			if(i < nLen)
			{
				switch(b)
				{
				case 0xF0:
					if(0x90 <= pByte[i] && pByte[i] <= 0xBF)
					{
						++i;
						nCase = 2;
					}
					break;
				case 0xF4:
					if(0x80 <= pByte[i] && pByte[i] <= 0x8F)
					{
						++i;
						nCase = 2;
					}
					break;
				case 0xF1:
				case 0xF2:
				case 0xF3:
					nCase = 3;
					break;
				}
			}
			else
				return BrFALSE;
		}
		else
			return BrFALSE;

		// switch�� break ���� ���� �ǵ��� ����
		switch (nCase)
		{
		case 3:		// 4Byte�� �տ��� �ι�° 10xxxxxx üũ
			if(i < nLen)
			{
				b = pByte[i];
				if(b >= 0x80 && b < 0xC0)
					++i;
				else
					return BrFALSE;
			}
		case 2:		// 4Byte�� �տ��� ����° 10xxxxxx üũ
			if(i < nLen)
			{
				b = pByte[i];
				if(b >= 0x80 && b < 0xC0)
					++i;
				else
					return BrFALSE;
			}
		case 1:		// 4Byte�� �տ��� �׹�° 10xxxxxx üũ
			if(i < nLen)
			{
				b = pByte[i];
				if(!(b >= 0x80 && b < 0xC0))
					return BrFALSE;
			}
			else
				return BrFALSE;
		}
	}
	return BrTRUE;
}


BrBOOL Bora_IsBigEndianUnicodeData(BrLPBYTE pByte, BrINT32 nLen)
{
	return (pByte[0] & 0xFF) == 0xFE && (pByte[1] & 0xFF) == 0xFF;
}
BrBOOL Bora_IsLittleEndianUnicodeData(BrLPBYTE pByte, BrINT32 nLen)
{
	return (pByte[0] & 0xFF) == 0xFF && (pByte[1] & 0xFF) == 0xFE;
}

BrBOOL Bora_IsUTF8Data(BrLPBYTE pByte, BrINT32 nLen)
{ 
	LPBYTE pTest = pByte;
	BrBYTE b = *pTest;
	BrINT32 icase = 1, nCur = nLen;

	while( b )
	{
		switch( icase )
		{
		case 1:
			if( b>>7 == 0 )
			{
				;// 0xxx xxxx
				return BrFALSE;//hnsong:2012-02-06 [M-4990] �ѱ�("����") �Է� ����
			}
			else if( b>>6 == 2 )
			{
				// 10XX XXXX
				return BrFALSE;
			}
			else if( b>>5 == 6 )
			{
				//110X xxxx
				icase =22;
			}
			else if( b>>4 == 14 )
			{
				// 1110 xxxx
				icase =32;
			}
			else if( b>>3 == 30  )
			{
				// 1111 0xxx
				icase =42;
			}
			else
				return BrFALSE;
			break;
//		case 1:
//			break;
		case 22:
			if( b>>6 == 2 )
			{
				// 10XX XXXX
				icase = 1;
			}
			else
				return BrFALSE;
			break;
		case 32:
			if( b>>6 == 2 )
			{
				// 10XX XXXX
				icase = 33;
			}
			else
				return BrFALSE;
			break;
		case 33:
			if( b>>6 == 2 )
			{
				// 10XX XXXX
				icase = 1;
			}
			else
				return BrFALSE;
			break;
		case 42:
			if( b>>6 == 2 )
			{
				// 10XX XXXX
				icase = 43;
			}
			else
				return BrFALSE;
			break;
		case 43:
			if( b>>6 == 2 )
			{
				// 10XX XXXX
				icase = 44;
			}
			else
				return BrFALSE;
			break;
		case 44:
			if( b>>6 == 2 )
			{
				// 10XX XXXX
				icase = 1;
			}
			else
				return BrFALSE;
			break;
		default:
			return BrFALSE;
			break;
		}

		pTest++;
		b = *pTest;
		nCur--;

		if (nCur > 0 && !b)
			return BrFALSE;
		else if (nCur == 0)
			break;
	}

	return BrTRUE;
}

BrBOOL Bora_IsUTF16Data(BrLPBYTE pByte, BrINT32 nLen)
{
#if 0
    int nCnt = 0;
    while( nCnt < nLen ) 
    {
        BrBYTE pFirst = pByte[nCnt++];
        BrBYTE pLast = pByte[nCnt++];
        if (pFirst < 0x80 && pLast )
            return FALSE;            
    }

	return TRUE;
#else
    return FALSE;
#endif	
}

void* BrGetPublicZipHandle(BrCHAR* pFileName, BrCHAR* pPassword, void* lpfnProgress)
{
	LPVOID & pZipHandle = g_bIsEmZip? g_pEmZipHandle : g_pZipHandle;
	if(pFileName)
	{
		BrReleasePublicZipHandle();
		pZipHandle = (void*)BrZipCreate(pFileName, pPassword);
	}
	return pZipHandle;
}

void BrReleasePublicZipHandle()
{
	LPVOID & pZipHandle = g_bIsEmZip? g_pEmZipHandle : g_pZipHandle;
	if(pZipHandle)
	{
		int nRet = BrZipClose(pZipHandle);
		//[XPD-24433] [kjins1201] Zip Close �����ϴ� ��� Log �߰�.
		if( nRet )
			SET_ERROR_LOG_FILE(kPoErrZIPInternal, 0, "Zip", __FUNCTION__, false);
		pZipHandle = BrNULL;
	}
}

#ifdef _THREAD_DEBUG
#ifdef SAVE_BMP_TO_MEMINFO
#include "ImageFilter.h"

static int nBitmapCount = 0;
LPBrBITMAPINFOHEADER MakeDeviceDIB2(int width, int height, int nBits)
{
#ifdef USE_32BIT_IMAGE
	if (nBits == 0 || nBits == 16)
		nBits = 32;
#else
	if (nBits >= 24 || nBits == 0)
		nBits = 16;
#endif
	BrBITMAPINFOHEADER bi;
	memset((BrLPVOID)&bi, 0, sizeof(BrBITMAPINFOHEADER));

	bi.biSize = sizeof(BrBITMAPINFOHEADER);
	bi.biBitCount = nBits;
	bi.biPlanes = 1;
	bi.biWidth = width;
	bi.biHeight = height;
	bi.biCompression = bi.biBitCount == 16? BI_BITFIELDS : BI_RGB;
	//bi.biSizeImage = IMAGESIZE8(&bi);
	bi.biSizeImage = BrIMAGESIZE8(&bi);

	//BrDWORD dwSize = DIBSIZE8(&bi);
	BrDWORD dwSize = BrDIBSIZE8(&bi);
//	TRACE(_T("DIB Size = %i\n"), dwSize);
	LPBrBITMAPINFOHEADER lpbi = (LPBrBITMAPINFOHEADER)BMallocEx(dwSize);
	if (!lpbi)
		return NULL;
	*lpbi = bi;
	if (bi.biBitCount == 16)
	{
		BrDWORD *pMask = (BrDWORD *)&lpbi[1];
		*pMask++ = BrRGB16(0xff, 0, 0);	//0x001F;
		*pMask++ = BrRGB16(0, 0xff, 0);	//0x07E0;
		*pMask = BrRGB16(0, 0, 0xff);	//0xF800;
	}
//	memset(GETDATAPOS(lpbi), 0xff, IMAGESIZE(lpbi));
	return lpbi;
}

void SaveBitmap2(char *pName, void* lpbi)
{
	if (!strcmp(pName, "") || !lpbi)
		return;
	
#if 0 //def 
//	BrDWORD dwSize = BrGetSBitmapDataSize((BrSBitmapPtr)lpbi);
	BITMAPINFOHEADER bi;
	memset((BrLPVOID)&bi, 0, sizeof(BITMAPINFOHEADER));

	bi.biSize = sizeof(BITMAPINFOHEADER);
	bi.biBitCount = ((BrSBitmapPtr)lpbi)->biBitCount;
	bi.biPlanes = ((BrSBitmapPtr)lpbi)->biPlanes;
	bi.biWidth = ((BrSBitmapPtr)lpbi)->biWidth;
	bi.biHeight = ((BrSBitmapPtr)lpbi)->biHeight;
	bi.biCompression = bi.biBitCount == 16? BI_BITFIELDS : BI_RGB;
	bi.biSizeImage = IMAGESIZE8(&bi);

	BrDWORD dwSize = DIBSIZE8(&bi);
	
	LPBITMAPINFOHEADER lpbs = (LPBITMAPINFOHEADER)BMallocEx(dwSize);
	if (lpbs)
	{
		*lpbs = bi;	
		int inRow = ROWSIZE8(lpbs->biWidth, lpbs->biBitCount);
		int outRow = ROWSIZE32(lpbs->biWidth, lpbs->biBitCount);

		BrLPBYTE lps = (BrLPBYTE)GETDATAPOS(lpbs) + (lpbs->biHeight - 1) * outRow;
		BrLPBYTE lpd = (BrLPBYTE)((BrSBitmapPtr)lpbi)->biBits;		
		for (int i = 0; i < lpbs->biHeight; i++, lpd += inRow, lps -= outRow)
			memcpy((char*)lps, (char*)lpd, inRow);

		void *fp = BFopen(pName, BMV_READ_WRITE);
		if (fp)
		{			
			BITMAPFILEHEADER fh; 
			fh.bfOffBits=sizeof(BITMAPFILEHEADER)+BITSOFFSET(lpbs);
			fh.bfReserved1=0;
			fh.bfReserved2=0;
			fh.bfSize=dwSize+sizeof(BITMAPFILEHEADER);
			fh.bfType=0x4d42;

			BFwrite((void*)&fh, 1, sizeof(fh), fp);
			BFwrite((void*)lpbs, 1, dwSize, fp);
			BFclose(fp);		
		}
		BFreeEx((void*)lpbs);
	}
#else	
	BrDWORD dwSize = DIBSIZE32((LPBrBITMAPINFOHEADER)lpbi);
	LPBrBITMAPINFOHEADER lpbs = (LPBrBITMAPINFOHEADER)BMallocEx(dwSize);
	if (lpbs)
	{
		memcpy((char*)lpbs, (char*)lpbi, BITSOFFSET((LPBrBITMAPINFOHEADER)lpbi));

		//int inRow = ROWSIZE8(((LPBrBITMAPINFOHEADER)lpbi)->biWidth, ((LPBrBITMAPINFOHEADER)lpbi)->biBitCount);
		//int outRow = ROWSIZE32(lpbs->biWidth, lpbs->biBitCount);
		int inRow = BrROWSIZE8((LPBrBITMAPINFOHEADER)lpbi);
		int outRow = BrROWSIZE32(lpbs);

		BrLPBYTE lps = (BrLPBYTE)GETDATAPOS(lpbs) + (lpbs->biHeight - 1) * outRow;
		BrLPBYTE lpd = (BrLPBYTE)GETDATAPOS(((LPBrBITMAPINFOHEADER)lpbi));
		for (int i = 0; i < ((LPBrBITMAPINFOHEADER)lpbi)->biHeight; i++, lpd += inRow, lps -= outRow)
			memcpy((char*)lps, (char*)lpd, inRow);

		void *fp = BFopen(pName, BMV_READ_WRITE);
		if (fp)
		{
#ifndef WIN32
			unsigned short	bfType=0x4d42;
			BFwrite((void*)&bfType, 1, sizeof(bfType), fp);
			BrULONG		bfSize=dwSize+14;
			BFwrite((void*)&bfSize, 1, sizeof(bfSize), fp);
			unsigned short	bfReserved1 =0;
			BFwrite((void*)&bfReserved1, 1, sizeof(bfReserved1), fp);
			unsigned short	bfReserved2 =0;
			BFwrite((void*)&bfReserved2, 1, sizeof(bfReserved2), fp);
			BrULONG		bfOffBits=14+BITSOFFSET(lpbs);
			BFwrite((void*)&bfOffBits, 1, sizeof(bfOffBits), fp);
#else
			BrBITMAPFILEHEADER fh; 
			fh.bfOffBits=sizeof(BrBITMAPFILEHEADER)+BITSOFFSET(lpbs);
			fh.bfReserved1=0;
			fh.bfReserved2=0;
			fh.bfSize=dwSize+sizeof(BrBITMAPFILEHEADER);
			fh.bfType=0x4d42;
			BFwrite((void*)&fh, 1, sizeof(fh), fp);
#endif			
			BFwrite((void*)lpbs, 1, dwSize, fp);
			BFclose(fp);		
		}
		BFreeEx((BrLPVOID)lpbs);
	}
#endif
}
#endif
#endif


#ifdef B_VS_DEBUG
extern "C" void BChronometryTrace(const char* s ,...);
#define BCHRONOMETRYTRACE	BChronometryTrace
#else
#define BCHRONOMETRYTRACE	BTrace
#endif
void BrEventChronometry(BrINT nEvent, BrINT8 nMode)
{
#if defined( USE_EVENT_MANAGER) && defined(B_DEBUG)
	BRCONTEXT;
#define BR_CHECK_EVENT(a) case a:	sprintf_s(pEvent, sizeof(pEvent), "[V%d.%02d]%s", MAJOR_VERSION_NUM, RELEASE_VERSION_NUM, #a);break;

	if(nEvent == BRGUI_BRTIMER) return;

	char pEvent[64] = {0,};
	switch(nEvent)
	{
//		BR_CHECK_EVENT(BRGUI_INIT_EVENT)
//		BR_CHECK_EVENT(BRGUI_FINALIZE_EVENT)
		BR_CHECK_EVENT(BRGUI_OPEN_EVENT)
		BR_CHECK_EVENT(BRGUI_OPENEX_EVENT)
//		BR_CHECK_EVENT(BRGUI_BRCLOSEDOC_EVENT)
		BR_CHECK_EVENT(BRGUI_BRFIRSTPAGE_EVENT)
		BR_CHECK_EVENT(BRGUI_BRPREVPAGE_EVENT)
		BR_CHECK_EVENT(BRGUI_BRPREVPAGEEX_EVENT)
		BR_CHECK_EVENT(BRGUI_BRNEXTPAGE_EVENT)
		BR_CHECK_EVENT(BRGUI_BRNEXTPAGEEX_EVENT)
		BR_CHECK_EVENT(BRGUI_BRLASTPAGE_EVENT)
		BR_CHECK_EVENT(BRGUI_BRSETPAGE_EVENT)
		BR_CHECK_EVENT(BRGUI_BRZOOMIN_EVENT)
		BR_CHECK_EVENT(BRGUI_BRZOOMOUT_EVENT)
		BR_CHECK_EVENT(BRGUI_BRSETZOOM_EVENT)
		BR_CHECK_EVENT(BRGUI_BRSETREGIONZOOM_EVENT)
		BR_CHECK_EVENT(BRGUI_BRFITTOWIDTH_EVENT)
		BR_CHECK_EVENT(BRGUI_BRFITTOHEIGHT_EVENT)
		BR_CHECK_EVENT(BRGUI_BRFITTOORIGIN_EVENT)
		BR_CHECK_EVENT(BRGUI_BRFITTOWHOLEPAGE_EVENT)
		BR_CHECK_EVENT(BRGUI_BRFITTOREFLOW_EVENT)
		BR_CHECK_EVENT(BRGUI_BRSCROLLUP_EVENT)
		BR_CHECK_EVENT(BRGUI_BRSCROLLDOWN_EVENT)
		BR_CHECK_EVENT(BRGUI_BRSCROLLLEFT_EVENT)
		BR_CHECK_EVENT(BRGUI_BRSCROLLRIGHT_EVENT)
		BR_CHECK_EVENT(BRGUI_BRSCROLLHOME_EVENT)
		BR_CHECK_EVENT(BRGUI_BRSCROLLEND_EVENT)
		BR_CHECK_EVENT(BRGUI_BRSCROLL_EVENT)
		BR_CHECK_EVENT(BRGUI_BRSCROLLBYPAGEMAP_EVENT)
		BR_CHECK_EVENT(BRGUI_BRCHANGETEXTONLY_EVENT)
		BR_CHECK_EVENT(BRGUI_BRROTATE_EVENT)
		BR_CHECK_EVENT(BRGUI_BRROTATECW_EVENT)
		BR_CHECK_EVENT(BRGUI_BRROTATECCW_EVENT)
		BR_CHECK_EVENT(BRGUI_BRPIVOTSCREEN_EVENT)
		BR_CHECK_EVENT(BRGUI_BRUSEBOOKMARK_EVENT)
		BR_CHECK_EVENT(BRGUI_BRSETBOOKMARK_EVENT)
		BR_CHECK_EVENT(BRGUI_BRAPPLYBOOKMARK_EVENT)
		BR_CHECK_EVENT(BRGUI_BRREMOVEBOOKMARK_EVENT)
		BR_CHECK_EVENT(BRGUI_BRPRINT_EVENT)
		BR_CHECK_EVENT(BRGUI_BRSCREENSCAPTURE_EVENT)
		BR_CHECK_EVENT(BRGUI_BRSETTHUMBNAIL_EVENT)
		BR_CHECK_EVENT(BRGUI_USEMAGNIFIER_EVENT)
		BR_CHECK_EVENT(BRGUI_CHANGESCREEN_EVENT)
		BR_CHECK_EVENT(BRGUI_BRSEARCH_EVENT)
//		BR_CHECK_EVENT(BRGUI_BRTIMER)
//		BR_CHECK_EVENT(BRGUI_BRTHREAD_SUSPEND)
//		BR_CHECK_EVENT(BRGUI_BRTHREAD_RESUME)
//		BR_CHECK_EVENT(BRGUI_BRCANCEL_EVENT)
//		BR_CHECK_EVENT(BRGUI_BRSEARCH_END_MODEEVENT)
		BR_CHECK_EVENT(BRGUI_REDRAW_BITMAP_EVENT)
		BR_CHECK_EVENT(BRGUI_PAGETHUMBNAIL_EVENT)

		BR_CHECK_EVENT(BRGUI_CHANGE_PAGE_DISPLAY)
		BR_CHECK_EVENT(BRGUI_CHANGE_CASE_EVENT)
		BR_CHECK_EVENT(BRGUI_SUMMARY_DATA_EVENT)

		BR_CHECK_EVENT(BRGUI_SEND_INTERNAL_STRING)


		BR_CHECK_EVENT(BRGUI_MEDIA_LINK)

#ifdef SUPPORT_BOOKCLIP
		BR_CHECK_EVENT(BRGUI_BRBOOKCLIP_EVENT)
#endif // SUPPORT_BOOKCLIP

		BR_CHECK_EVENT(BRGUI_FLICK_EVENT)


		BR_CHECK_EVENT(BRGUI_DRAW_UNDERLINE)

#ifdef OFFICE_EDITOR /////////////////////////////////////////////////////////////////////////////
		BR_CHECK_EVENT(BRGUI_EDIT_MODE_EVENT)
		BR_CHECK_EVENT(BRGUI_VIEW_MODE_EVENT)
		BR_CHECK_EVENT(BRGUI_WEBLAYOUT_MODE_EVENT)
		BR_CHECK_EVENT(BRGUI_OUTLINE_MODE_EVENT)
		BR_CHECK_EVENT(BRGUI_PRINTLAYOUT_MODE_EVENT)
		BR_CHECK_EVENT(BRGUI_TEXT_MODE_EVENT)
		BR_CHECK_EVENT(BRGUI_NEW_EVENT)
		BR_CHECK_EVENT(BRGUI_SAVE_EVENT)
		BR_CHECK_EVENT(BRGUI_UNDO_EVENT)
		BR_CHECK_EVENT(BRGUI_REDO_EVENT)
		BR_CHECK_EVENT(BRGUI_LEFT_ALIGN_EVENT)
		BR_CHECK_EVENT(BRGUI_CENTER_ALIGN_EVENT)
		BR_CHECK_EVENT(BRGUI_RIGHT_ALIGN_EVENT)
		BR_CHECK_EVENT(BRGUI_JUSTIFY_ALIGN_EVENT)
		BR_CHECK_EVENT(BRGUI_TOP_ALIGN_EVENT)
		BR_CHECK_EVENT(BRGUI_MIDDLE_ALIGN_EVENT)
		BR_CHECK_EVENT(BRGUI_BOTTOM_ALIGN_EVENT)
		BR_CHECK_EVENT(BRGUI_INPUTCHAR_EVENT)
		BR_CHECK_EVENT(BRGUI_IME_INSERT_EVENT)
		BR_CHECK_EVENT(BRGUI_IME_REPLACE_EVENT)
		BR_CHECK_EVENT(BRGUI_DELETECHAR_EVENT)
		BR_CHECK_EVENT(BRGUI_CARET_UP_EVENT)
		BR_CHECK_EVENT(BRGUI_CARET_DOWN_EVENT)
		BR_CHECK_EVENT(BRGUI_CARET_LEFT_EVENT)
		BR_CHECK_EVENT(BRGUI_CARET_RIGHT_EVENT)
		BR_CHECK_EVENT(BRGUI_CARET_HOME_EVENT)
		BR_CHECK_EVENT(BRGUI_CARET_END_EVENT)
		BR_CHECK_EVENT(BRGUI_CARET_PAGEUP_EVENT)
		BR_CHECK_EVENT(BRGUI_CARET_PAGEDOWN_EVENT)
		BR_CHECK_EVENT(BRGUI_HID_ACTION_EVENT)
		BR_CHECK_EVENT(BRGUI_EDIT_COPY_EVENT)
		BR_CHECK_EVENT(BRGUI_EDIT_CUT_EVENT)
		BR_CHECK_EVENT(BRGUI_EDIT_PASTE_EVENT)
		BR_CHECK_EVENT(BRGUI_EDIT_PASTEVALUE_EVENT)
		BR_CHECK_EVENT(BRGUI_SELECT_ALL_EVENT)
		BR_CHECK_EVENT(BRGUI_SETFONT_EVENT)
		BR_CHECK_EVENT(BRGUI_SETFONT_PREVIEW_EVENT)
		BR_CHECK_EVENT(BRGUI_TABLEPROPERTY_PREVIEW_EVENT)
		BR_CHECK_EVENT(BRGUI_SCREENMODE_CONTINUE_EVENT)
		BR_CHECK_EVENT(BRGUI_SCREENMODE_BASIC_EVENT)
		BR_CHECK_EVENT(BRGUI_OBJECT_ATT_EVENT)
		BR_CHECK_EVENT(BRGUI_LINE_INSERT_EVENT)
		BR_CHECK_EVENT(BRGUI_SHAPE_INSERT_EVENT)
		BR_CHECK_EVENT(BRGUI_OBJECT_POSITION_EVENT)
		BR_CHECK_EVENT(BRGUI_OBJECT_GRADIENT_EVENT)
		BR_CHECK_EVENT(BRGUI_BORDER_EVENT)
		BR_CHECK_EVENT(BRGUI_SETCOLORS_EVENT)
		BR_CHECK_EVENT(BRGUI_OBJECTTEXTEDIT_EVENT)
		BR_CHECK_EVENT(BRGUI_OBJECT_DELETE_EVENT)
		BR_CHECK_EVENT(BRGUI_OBJECT_RESIZE_EVENT)
    	BR_CHECK_EVENT(BRGUI_SCREENMODE_THUMBNAIL_EVENT)
		BR_CHECK_EVENT(BRGUI_CELL_PROPERTY_EVENT)
		BR_CHECK_EVENT(BRGUI_ESC_KEY_EVENT)
#ifdef PPT_EDITOR
		BR_CHECK_EVENT(BRGUI_SLIDE_NEW_PHOTO_ALBUM_EVENT)  // Photo Album
#endif // PPT_EDITOR
#ifdef ORG_OLE_FILE
		BR_CHECK_EVENT(BRGUI_SET_OLE_EVENT)   // anesin: T#23588 input/update OLE
#endif // ORG_OLE_FILE
#ifdef BWP_EDITOR
		BR_CHECK_EVENT(BRGUI_BWP_INPUTIMG_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_INSTABLE_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_SET_CARET_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_ONE_SELECT_CELL_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_MULTI_SELECT_CELL_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_CARET_MARK_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_SELECT_MARK_CANCEL_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_CHANGE_CELLSIZE_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_BULLET_INPUT_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_NUMBERING_INPUT_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_EDITPAGE_REDRAW_BITMAP_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_SHOWIMAGE_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_HIDEIMAGE_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_CELL_INSERT_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_CELL_DELETE_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_CELL_MERGE_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_CELL_SEPARATE_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_INDENT_INCREASE_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_INDENT_DECREASE_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_CHANGE_LIST_LEVELE_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_BOOKMARKEDITOR_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_HYPERLINKEDITOR_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_POPUPOFFSET_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_CELL_BORDER_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_DETAIL_MARK_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_INSERT_STRING_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_LINESPACE_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_COLUMN_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_GET_PAGE_THUMBNAIL_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_CELL_EQUAL_WIDTH_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_CELL_EQUAL_HEIGHT_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_CELL_EQUAL_WIDTHHEIGHT_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_SETSTYLETABLE_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_NEW_BULLET_INPUT_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_NEW_NUMBERING_INPUT_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_NEW_MULTINUMBERING_INPUT_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_COLUMNBREAK_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_SECTIONBREAK_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_MULTINUMBERING_INPUT_EVENT)
		BR_CHECK_EVENT(BRGUI_BWP_LINENUMBER_EVENT)
		BR_CHECK_EVENT(BRGUI_MOBILEVIEW_LAYOUT_MODE_EVENT)
		BR_CHECK_EVENT(BRGUI_TABLETVIEW_LAYOUT_MODE_EVENT)
#endif // BWP_EDITOR
#ifdef __2008_SHEET_EDITOR__
		BR_CHECK_EVENT(BRGUI_SHEET_COLOR_EVENT)
		BR_CHECK_EVENT(BRGUI_SHEET_ALIGNMENT_EVENT)
		BR_CHECK_EVENT(BRGUI_SHEET_FORMAT_EVENT)
		BR_CHECK_EVENT(BRGUI_SHEET_CELLFORMAT_PROTECTION_EVENT)
		BR_CHECK_EVENT(BRGUI_SHEET_FORMATEX_EVENT)
		BR_CHECK_EVENT(BRGUI_SHEET_FUNCTION_EVENT)
		BR_CHECK_EVENT(BRGUI_SHEET_CALCULATE_NOW_EVENT)
		BR_CHECK_EVENT(BRGUI_SHEET_EDIT_EVENT)
		BR_CHECK_EVENT(BRGUI_SHEET_FIXFRAME_EVENT)
		BR_CHECK_EVENT(BRGUI_SHEET_FIXFRAME_INTGR_EVENT)
		BR_CHECK_EVENT(BRGUI_SHEET_PAGEBREAK_EVENT)
		BR_CHECK_EVENT(BRGUI_SHEET_PAGEBREAK_INTGR_EVENT)
		BR_CHECK_EVENT(BRGUI_SHEET_COLOR_SET_EVENT)
		BR_CHECK_EVENT(BRGUI_SHEET_FIND_CONDITIONAL_FORMAT)
#ifdef SHEET_SELECTED_ROW_COL_HIGHLIGHT
		BR_CHECK_EVENT(BRGUI_SHEET_SELECTED_ROW_COL_HIGHLIGHT_EVENT)
#endif	// SHEET_SELECTED_ROW_COL_HIGHLIGHT
#ifdef SUPPORT_CHART_SHEET
		BR_CHECK_EVENT(BRGUI_SHEET_CHARTSHEET_EVENT)
#endif	// SUPPORT_CHART_SHEET
		BR_CHECK_EVENT(BRGUI_SHEET_PROTECTION_EVENT)
		BR_CHECK_EVENT(BRGUI_SHEET_WORKBOOKPROTECTION)
		BR_CHECK_EVENT(BRGUI_SHEET_INSERT_CELL_EVENT)
		BR_CHECK_EVENT(BRGUI_SHEET_INSERT_ROW_EVENT)
		BR_CHECK_EVENT(BRGUI_SHEET_INSERT_COL_EVENT)
		BR_CHECK_EVENT(BRGUI_SHEET_SHOW_ROW_EVENT)
		BR_CHECK_EVENT(BRGUI_SHEET_SHOW_COL_EVENT)
		BR_CHECK_EVENT(BRGUI_SHEET_ROW_HEIGHT_EVENT)
		BR_CHECK_EVENT(BRGUI_SHEET_COLUMN_WIDTH_EVENT)
		BR_CHECK_EVENT(BRGUI_SHEET_DELETE_CONTENT_EVENT)
		BR_CHECK_EVENT(BRGUI_SHEET_DELETE_FORMAT_EVENT)
		BR_CHECK_EVENT(BRGUI_SHEET_DELETE_ALL_EVENT)
		BR_CHECK_EVENT(BRGUI_SHEET_SORT_EVENT)
		BR_CHECK_EVENT(BRGUI_SHEET_SORT_EXTEND_EVENT)
		BR_CHECK_EVENT(BRGUI_SHEET_FOCUS_EVENT)
#ifdef USE_SHEET_EDIT_CONTROL_COUTDEV
		BR_CHECK_EVENT(BRGUI_SHEET_CELL_FOCUS_EVENT)
		BR_CHECK_EVENT(BRGUI_SHEET_APPEND_UPPER_CELL_TEXT_EVENT)
#endif	// USE_SHEET_EDIT_CONTROL_COUTDEV
		BR_CHECK_EVENT(BRGUI_SHEET_INPUTFIELD_EVENT)
		BR_CHECK_EVENT(BRGUI_SHEET_MERGE_EVENT)
		BR_CHECK_EVENT(BRGUI_SHEET_SHOW_HEADER_EVENT)
		BR_CHECK_EVENT(BRGUI_SHEET_SHOW_GRID_EVENT)
		BR_CHECK_EVENT(BRGUI_SHEET_GRIDLINE_COLOR)
#ifdef USE_SHEET_EDIT_CONTROL_COUTDEV
		BR_CHECK_EVENT(BRGUI_SHEET_CARET_MOVE_EVENT)
		BR_CHECK_EVENT(BRGUI_SHEET_INPUT_FUNCSTR_EVENT)
#ifdef BRGUI_SHEET_OBJECT_FOCUS_EVENT
		BR_CHECK_EVENT(BRGUI_SHEET_OBJECT_FOCUS_EVENT)
#endif	// BRGUI_SHEET_OBJECT_FOCUS_EVENT
#endif // USE_SHEET_EDIT_CONTROL_COUTDEV
		BR_CHECK_EVENT(BRGUI_SHEET_FINDREPLACE_FORMAT_PREVIEW_EVENT)
#endif // __2008_SHEET_EDITOR_
#ifdef PPT_EDITOR
		BR_CHECK_EVENT(BRGUI_PPT_SLIDEINSERT_EVENT)
		BR_CHECK_EVENT(BRGUI_PPT_SLIDEDELETE_EVENT)
		BR_CHECK_EVENT(BRGUI_PPT_TEXTBOXINSERT_EVENT)
		BR_CHECK_EVENT(BRGUI_PPT_SLIDEMOVENEXT_EVENT)
		BR_CHECK_EVENT(BRGUI_PPT_SLIDEMOVEPREV_EVENT)
		BR_CHECK_EVENT(BRGUI_PPT_SLIDEMOVEEX_EVENT)
		BR_CHECK_EVENT(BRGUI_PPT_SLIDEDUPLICATE_EVENT)
		BR_CHECK_EVENT(BRGUI_PPT_SLIDENOTEINPUT_EVENT)
		BR_CHECK_EVENT(BRGUI_PPT_SLIDEOBJ_START_EVENT)
		BR_CHECK_EVENT(BRGUI_PPT_SLIDENOTE_EVENT)
		BR_CHECK_EVENT(BRGUI_PPT_SLIDESHOWSTART_EVENT)
		BR_CHECK_EVENT(BRGUI_PPT_SLIDESHOWEND_EVENT)
		BR_CHECK_EVENT(BRGUI_PPT_SLIDEINSERTEX_EVENT)
    	BR_CHECK_EVENT(BRGUI_PPT_SLIDEOBJ_STARTEX_EVENT)
		BR_CHECK_EVENT(BRGUI_PPT_SLIDESHOWPLAY_EVENT)
		BR_CHECK_EVENT(BRGUI_PPT_SLIDEHIDE_EVENT)
		BR_CHECK_EVENT(BRGUI_PPT_SLIDELAYOUT_EVENT)
		BR_CHECK_EVENT(BRGUI_PPT_SLIDESHOWEFFECT_EVENT)
		BR_CHECK_EVENT(BRGUI_PPT_SLIDEANIMATION_ADD_EVENT)
		BR_CHECK_EVENT(BRGUI_PPT_SLIDEANIMATION_DELETE_EVENT)
		BR_CHECK_EVENT(BRGUI_PPT_SLIDEANIMATION_MOVE_EVENT)
		BR_CHECK_EVENT(BRGUI_PPT_SLIDECOPY_EVENT)
		BR_CHECK_EVENT(BRGUI_PPT_SLIDECUT_EVENT)
		BR_CHECK_EVENT(BRGUI_PPT_SLIDEPASTE_EVENT)
		BR_CHECK_EVENT(BRGUI_PPT_SLIDESCREENIMAGE_EVENT)
#endif // PPT_EDITOR
#endif // OFFICE_EDITOR //////////////////////////////////////////////////////////////////////////

		BR_CHECK_EVENT(BRGUI_SET_PEN_MODE_EVENT)
		BR_CHECK_EVENT(BRGUI_CLEAR_ALL_EVENT)
		BR_CHECK_EVENT(BRGUI_SHOW_HIDE_ALL_EVENT)
		BR_CHECK_EVENT(BRGUI_SET_PEN_COLOR_EVENT)
		BR_CHECK_EVENT(BRGUI_SET_PEN_SIZE_EVENT)
		BR_CHECK_EVENT(BRGUI_SET_PEN_TRANSPARENCY_EVENT)
		BR_CHECK_EVENT(BRGUI_IS_HIGHLIGHT_AREA_EVENT)
		BR_CHECK_EVENT(BRGUI_CHANGE_HIGHLIGHT_COLOR_EVENT)
		BR_CHECK_EVENT(BRGUI_SET_UNHIGHLIGHT_EVENT)
		BR_CHECK_EVENT(BRGUI_SET_PEN_POSITIONS_EVENT)
	default:
		return;
	}

	if (nMode == 1) 
	{
//		if (!Brcontext.m_ViewerConfig.nRunningTime)
		{
			Brcontext.m_ViewerConfig.nRunningTime = BrGetTickCount(); 
			if (nEvent == BRGUI_OPEN_EVENT || nEvent == BRGUI_OPENEX_EVENT)
			{

				int nYear = 0, nMonth = 0, nDay = 0, nWday = 0, nHour = 0, nMinute = 0, nSecond = 0;
				BrGetSystemTime(&nYear, &nMonth, &nDay, &nWday, &nHour, &nMinute, &nSecond);				
				BCHRONOMETRYTRACE("[%s]Start Chronometry [%d][%4d.%d.%d %2d:%2d:%2d]", pEvent, 0, nYear, nMonth+1, nDay, nHour, nMinute, nSecond); 
			}
		}
	} 
	else if (nMode == 2) 
	{ 
		BCHRONOMETRYTRACE("[%s]Rendering [%d msec]", pEvent, (unsigned int)BrGetElapsedTime(Brcontext.m_ViewerConfig.nRunningTime)); 
	} 
	else if (nMode == 3) 
	{ 
		BCHRONOMETRYTRACE("[%s]Filtering [%d msec]", pEvent, (unsigned int)BrGetElapsedTime(Brcontext.m_ViewerConfig.nRunningTime));
	} 
	else 
	{
		if(Brcontext.m_ViewerConfig.nRunningTime != 0)
		{
			BCHRONOMETRYTRACE("[%s]Total Elapsed Time [%d msec]", pEvent, (unsigned int)BrGetElapsedTime(Brcontext.m_ViewerConfig.nRunningTime));
			Brcontext.m_ViewerConfig.nRunningTime = 0; 
		}		
	} 
#endif
}

#if defined(B_DEBUG) 
void BLineTrace(char* file, int line, const char* s, ...)
{
	char *str = (char*)BMalloc(1024*10);
	if (str)
	{
		memset(str, 0, 1024 * 10);
		va_list ap;

		va_start(ap, s);
		if (s)
			vsprintf_s(str, 1024*10, s, ap);
		va_end(ap);
	}

	BTrace("%s(%d) %s", file, line, str);
	BFree(str);	
}

void BrShapeTypeTrace(char* szfile, int nline, int nType, BrBOOL bFlipV, BrBOOL bFlipH, BrINT32 nRotateAngle)
{
#if 0
#define BR_SHAPE_TYPE_DEBUG(a) 			case a: BrTrace("%s(%d) Shape Type [ %s ] FlipV[%d] FlipH[%d], Angle[%d]", szfile, nline, #a, bFlipV, bFlipH, nRotateAngle); break;
#define BR_SHAPE_TYPE_DEBUG_DEFAULT(b) 	default: BrTrace("%s(%d) Shape Type [ %d ] FlipV[%d] FlipH[%d], Angle[%d]", szfile, nline, b, bFlipV, bFlipH, nRotateAngle); break;

	switch(nType)
	{
		BR_SHAPE_TYPE_DEBUG(SHAPE_Min)// =0, SHAPE_NotPrimitive
		BR_SHAPE_TYPE_DEBUG(SHAPE_None)// =-1,		
		BR_SHAPE_TYPE_DEBUG(SHAPE_Rectangle)// =1,
		BR_SHAPE_TYPE_DEBUG(SHAPE_RoundRectangle)// =2,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Ellipse)// =3,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Diamond)// =4,
		BR_SHAPE_TYPE_DEBUG(SHAPE_IsocelesTriangle)// =5,
		BR_SHAPE_TYPE_DEBUG(SHAPE_RightTriangle)// =6,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Parallelogram)// =7,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Trapezoid)// =8,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Hexagon)// =9,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Octagon)// =10,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Plus)// =11,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Star)// =12,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Arrow)// =13,
		BR_SHAPE_TYPE_DEBUG(SHAPE_ThickArrow)// =14,
		BR_SHAPE_TYPE_DEBUG(SHAPE_HomePlate)// =15,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Cube)// =16,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Balloon)// =17,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Seal)// =18,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Arc)// =19,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Line)// =20,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Plaque)// =21,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Can)// =22,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Donut)// =23,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextSimple)// =24,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextOctagon)// =25,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextHexagon)// =26,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextCurve)// =27,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextWave)// =28,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextRing)// =29,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextOnCurve)// =30,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextOnRing)// =31,
		BR_SHAPE_TYPE_DEBUG(SHAPE_StraightConnector1)// =32,
		BR_SHAPE_TYPE_DEBUG(SHAPE_BentConnector2)// =33,
		BR_SHAPE_TYPE_DEBUG(SHAPE_BentConnector3)// =34,
		BR_SHAPE_TYPE_DEBUG(SHAPE_BentConnector4)// =35,
		BR_SHAPE_TYPE_DEBUG(SHAPE_BentConnector5)// =36,
		BR_SHAPE_TYPE_DEBUG(SHAPE_CurvedConnector2)// =37,
		BR_SHAPE_TYPE_DEBUG(SHAPE_CurvedConnector3)// =38,
		BR_SHAPE_TYPE_DEBUG(SHAPE_CurvedConnector4)// =39,
		BR_SHAPE_TYPE_DEBUG(SHAPE_CurvedConnector5)// =40,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Callout1)// =41,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Callout2)// =42,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Callout3)// =43,
		BR_SHAPE_TYPE_DEBUG(SHAPE_AccentCallout1)// =44,
		BR_SHAPE_TYPE_DEBUG(SHAPE_AccentCallout2)// =45,
		BR_SHAPE_TYPE_DEBUG(SHAPE_AccentCallout3)// =46,
		BR_SHAPE_TYPE_DEBUG(SHAPE_BorderCallout1)// =47,
		BR_SHAPE_TYPE_DEBUG(SHAPE_BorderCallout2)// =48,
		BR_SHAPE_TYPE_DEBUG(SHAPE_BorderCallout3)// =49,
		BR_SHAPE_TYPE_DEBUG(SHAPE_AccentBorderCallout1)// =50,
		BR_SHAPE_TYPE_DEBUG(SHAPE_AccentBorderCallout2)// =51,
		BR_SHAPE_TYPE_DEBUG(SHAPE_AccentBorderCallout3)// =52,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Ribbon)// =53,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Ribbon2)// =54,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Chevron)// =55,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Pentagon)// =56,
		BR_SHAPE_TYPE_DEBUG(SHAPE_NoSmoking)// =57,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Seal8)// =58,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Seal16)// =59,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Seal32)// =60,
		BR_SHAPE_TYPE_DEBUG(SHAPE_WedgeRectCallout)// =61,
		BR_SHAPE_TYPE_DEBUG(SHAPE_WedgeRRectCallout)// =62,
		BR_SHAPE_TYPE_DEBUG(SHAPE_WedgeEllipseCallout)// =63,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Wave)// =64,
		BR_SHAPE_TYPE_DEBUG(SHAPE_FoldedCorner)// =65,
		BR_SHAPE_TYPE_DEBUG(SHAPE_LeftArrow)// =66,
		BR_SHAPE_TYPE_DEBUG(SHAPE_DownArrow)// =67,
		BR_SHAPE_TYPE_DEBUG(SHAPE_UpArrow)// =68,
		BR_SHAPE_TYPE_DEBUG(SHAPE_LeftRightArrow)// =69,
		BR_SHAPE_TYPE_DEBUG(SHAPE_UpDownArrow)// =70,
		BR_SHAPE_TYPE_DEBUG(SHAPE_IrregularSeal1)// =71,
		BR_SHAPE_TYPE_DEBUG(SHAPE_IrregularSeal2)// =72,
		BR_SHAPE_TYPE_DEBUG(SHAPE_LightningBolt)// =73,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Heart)// =74,
		BR_SHAPE_TYPE_DEBUG(SHAPE_PictureFrame)// =75,
		BR_SHAPE_TYPE_DEBUG(SHAPE_QuadArrow)// =76,
		BR_SHAPE_TYPE_DEBUG(SHAPE_LeftArrowCallout)// =77,
		BR_SHAPE_TYPE_DEBUG(SHAPE_RightArrowCallout)// =78,
		BR_SHAPE_TYPE_DEBUG(SHAPE_UpArrowCallout)// =79,
		BR_SHAPE_TYPE_DEBUG(SHAPE_DownArrowCallout)// =80,
		BR_SHAPE_TYPE_DEBUG(SHAPE_LeftRightArrowCallout)// =81,
		BR_SHAPE_TYPE_DEBUG(SHAPE_UpDownArrowCallout)// =82,
		BR_SHAPE_TYPE_DEBUG(SHAPE_QuadArrowCallout)// =83,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Bevel)// =84,
		BR_SHAPE_TYPE_DEBUG(SHAPE_LeftBracket)// =85,
		BR_SHAPE_TYPE_DEBUG(SHAPE_RightBracket)// =86,
		BR_SHAPE_TYPE_DEBUG(SHAPE_LeftBrace)// =87,
		BR_SHAPE_TYPE_DEBUG(SHAPE_RightBrace)// =88,
		BR_SHAPE_TYPE_DEBUG(SHAPE_LeftUpArrow)// =89,
		BR_SHAPE_TYPE_DEBUG(SHAPE_BentUpArrow)// =90,
		BR_SHAPE_TYPE_DEBUG(SHAPE_BentArrow)// =91,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Seal24)// =92,
		BR_SHAPE_TYPE_DEBUG(SHAPE_StripedRightArrow)// =93,
		BR_SHAPE_TYPE_DEBUG(SHAPE_NotchedRightArrow)// =94,
		BR_SHAPE_TYPE_DEBUG(SHAPE_BlockArc)// =95,
		BR_SHAPE_TYPE_DEBUG(SHAPE_SmileyFace)// =96,
		BR_SHAPE_TYPE_DEBUG(SHAPE_VerticalScroll)// =97,
		BR_SHAPE_TYPE_DEBUG(SHAPE_HorizontalScroll)// =98,
		BR_SHAPE_TYPE_DEBUG(SHAPE_CircularArrow)// =99,
		BR_SHAPE_TYPE_DEBUG(SHAPE_NotchedCircularArrow)// =100,
		BR_SHAPE_TYPE_DEBUG(SHAPE_UturnArrow)// =101,
		BR_SHAPE_TYPE_DEBUG(SHAPE_CurvedRightArrow)// =102,
		BR_SHAPE_TYPE_DEBUG(SHAPE_CurvedLeftArrow)// =103,
		BR_SHAPE_TYPE_DEBUG(SHAPE_CurvedUpArrow)// =104,
		BR_SHAPE_TYPE_DEBUG(SHAPE_CurvedDownArrow)// =105,
		BR_SHAPE_TYPE_DEBUG(SHAPE_CloudCallout)// =106,
		BR_SHAPE_TYPE_DEBUG(SHAPE_EllipseRibbon)// =107,
		BR_SHAPE_TYPE_DEBUG(SHAPE_EllipseRibbon2)// =108,
		BR_SHAPE_TYPE_DEBUG(SHAPE_FlowChartProcess)// =109,
		BR_SHAPE_TYPE_DEBUG(SHAPE_FlowChartDecision)// =110,
		BR_SHAPE_TYPE_DEBUG(SHAPE_FlowChartInputOutput)// =111,
		BR_SHAPE_TYPE_DEBUG(SHAPE_FlowChartPredefinedProcess)// =112,
		BR_SHAPE_TYPE_DEBUG(SHAPE_FlowChartInternalStorage)// =113,
		BR_SHAPE_TYPE_DEBUG(SHAPE_FlowChartDocument)// =114,
		BR_SHAPE_TYPE_DEBUG(SHAPE_FlowChartMultidocument)// =115,
		BR_SHAPE_TYPE_DEBUG(SHAPE_FlowChartTerminator)// =116,
		BR_SHAPE_TYPE_DEBUG(SHAPE_FlowChartPreparation)// =117,
		BR_SHAPE_TYPE_DEBUG(SHAPE_FlowChartManualInput)// =118,
		BR_SHAPE_TYPE_DEBUG(SHAPE_FlowChartManualOperation)// =119,
		BR_SHAPE_TYPE_DEBUG(SHAPE_FlowChartConnector)// =120,
		BR_SHAPE_TYPE_DEBUG(SHAPE_FlowChartPunchedCard)// =121,
		BR_SHAPE_TYPE_DEBUG(SHAPE_FlowChartPunchedTape)// =122,
		BR_SHAPE_TYPE_DEBUG(SHAPE_FlowChartSummingJunction)// =123,
		BR_SHAPE_TYPE_DEBUG(SHAPE_FlowChartOr)// =124,
		BR_SHAPE_TYPE_DEBUG(SHAPE_FlowChartCollate)// =125,
		BR_SHAPE_TYPE_DEBUG(SHAPE_FlowChartSort)// =126,
		BR_SHAPE_TYPE_DEBUG(SHAPE_FlowChartExtract)// =127,
		BR_SHAPE_TYPE_DEBUG(SHAPE_FlowChartMerge)// =128,
		BR_SHAPE_TYPE_DEBUG(SHAPE_FlowChartOfflineStorage)// =129,
		BR_SHAPE_TYPE_DEBUG(SHAPE_FlowChartOnlineStorage)// =130,
		BR_SHAPE_TYPE_DEBUG(SHAPE_FlowChartMagneticTape)// =131,
		BR_SHAPE_TYPE_DEBUG(SHAPE_FlowChartMagneticDisk)// =132,
		BR_SHAPE_TYPE_DEBUG(SHAPE_FlowChartMagneticDrum)// =133,
		BR_SHAPE_TYPE_DEBUG(SHAPE_FlowChartDisplay)// =134,
		BR_SHAPE_TYPE_DEBUG(SHAPE_FlowChartDelay)// =135,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextPlainText)// =136,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextStop)// =137,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextTriangle)// =138,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextTriangleInverted)// =139,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextChevron)// =140,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextChevronInverted)// =141,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextRingInside)// =142,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextRingOutside)// =143,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextArchUpCurve)// =144,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextArchDownCurve)// =145,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextCircleCurve)// =146,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextButtonCurve)// =147,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextArchUpPour)// =148,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextArchDownPour)// =149,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextCirclePour)// =150,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextButtonPour)// =151,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextCurveUp)// =152,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextCurveDown)// =153,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextCascadeUp)// =154,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextCascadeDown)// =155,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextWave1)// =156,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextWave2)// =157,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextWave3)// =158,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextWave4)// =159,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextInflate)// =160,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextDeflate)// =161,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextInflateBottom)// =162,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextDeflateBottom)// =163,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextInflateTop)// =164,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextDeflateTop)// =165,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextDeflateInflate)// =166,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextDeflateInflateDeflate)// =167,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextFadeRight)// =168,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextFadeLeft)// =169,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextFadeUp)// =170,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextFadeDown)// =171,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextSlantUp)// =172,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextSlantDown)// =173,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextCanUp)// =174,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextCanDown)// =175,
		BR_SHAPE_TYPE_DEBUG(SHAPE_FlowChartAlternateProcess)// =176,
		BR_SHAPE_TYPE_DEBUG(SHAPE_FlowChartOffpageConnector)// =177,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Callout90)// =178,
		BR_SHAPE_TYPE_DEBUG(SHAPE_AccentCallout90)// =179,
		BR_SHAPE_TYPE_DEBUG(SHAPE_BorderCallout90)// =180,
		BR_SHAPE_TYPE_DEBUG(SHAPE_AccentBorderCallout90)// =181,
		BR_SHAPE_TYPE_DEBUG(SHAPE_LeftRightUpArrow)// =182,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Sun)// =183,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Moon)// =184,
		BR_SHAPE_TYPE_DEBUG(SHAPE_BracketPair)// =185,
		BR_SHAPE_TYPE_DEBUG(SHAPE_BracePair)// =186,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Seal4)// =187,
		BR_SHAPE_TYPE_DEBUG(SHAPE_DoubleWave)// =188,
		BR_SHAPE_TYPE_DEBUG(SHAPE_ActionButtonBlank)// =189,
		BR_SHAPE_TYPE_DEBUG(SHAPE_ActionButtonHome)// =190,
		BR_SHAPE_TYPE_DEBUG(SHAPE_ActionButtonHelp)// =191,
		BR_SHAPE_TYPE_DEBUG(SHAPE_ActionButtonInformation)// =192,
		BR_SHAPE_TYPE_DEBUG(SHAPE_ActionButtonForwardNext)// =193,
		BR_SHAPE_TYPE_DEBUG(SHAPE_ActionButtonBackPrevious)// =194,
		BR_SHAPE_TYPE_DEBUG(SHAPE_ActionButtonEnd)// =195,
		BR_SHAPE_TYPE_DEBUG(SHAPE_ActionButtonBeginning)// =196,
		BR_SHAPE_TYPE_DEBUG(SHAPE_ActionButtonReturn)// =197,
		BR_SHAPE_TYPE_DEBUG(SHAPE_ActionButtonDocument)// =198,
		BR_SHAPE_TYPE_DEBUG(SHAPE_ActionButtonSound)// =199,
		BR_SHAPE_TYPE_DEBUG(SHAPE_ActionButtonMovie)// =200,
		BR_SHAPE_TYPE_DEBUG(SHAPE_HostControl)// =201,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextBox)// =202,
		//?   BR_SHAPE_TYPE_DEBUG(SHAPE_doubleArrow)// =203,
		//   BR_SHAPE_TYPE_DEBUG(SHAPE_curve)// =204,
		//   BR_SHAPE_TYPE_DEBUG(SHAPE_freeForm)// =205,
		BR_SHAPE_TYPE_DEBUG(SHAPE_scribble)// =206,
		//   BR_SHAPE_TYPE_DEBUG(SHAPE_picture)// =207,		// picture fram�� �ߺ�!
		BR_SHAPE_TYPE_DEBUG(SHAPE_table)// =208,
		BR_SHAPE_TYPE_DEBUG(SHAPE_group)// =209,
		BR_SHAPE_TYPE_DEBUG(SHAPE_bullet)// =210,
		BR_SHAPE_TYPE_DEBUG(SHAPE_TextPictureFrame)// =211,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Conn)// =212,

		// office2007 new shape
		BR_SHAPE_TYPE_DEBUG(SHAPE_snip1Rect)// =300,
		BR_SHAPE_TYPE_DEBUG(SHAPE_snip2SameRect)// =301,
		BR_SHAPE_TYPE_DEBUG(SHAPE_snip2DiagRect)// =302,
		BR_SHAPE_TYPE_DEBUG(SHAPE_snipRoundRect)// =303,
		BR_SHAPE_TYPE_DEBUG(SHAPE_round1Rect)// =304,
		BR_SHAPE_TYPE_DEBUG(SHAPE_round2SameRect)// =305,
		BR_SHAPE_TYPE_DEBUG(SHAPE_round2DiagRect)// =306,
		BR_SHAPE_TYPE_DEBUG(SHAPE_mathPlus)// =307,
		BR_SHAPE_TYPE_DEBUG(SHAPE_mathMinus)// =308,
		BR_SHAPE_TYPE_DEBUG(SHAPE_mathMultiply)// =309,
		BR_SHAPE_TYPE_DEBUG(SHAPE_mathDivide)// =310,
		BR_SHAPE_TYPE_DEBUG(SHAPE_mathEqual)// =311,
		BR_SHAPE_TYPE_DEBUG(SHAPE_mathNotEqual)// =312,
		BR_SHAPE_TYPE_DEBUG(SHAPE_heptagon)// =313,
		BR_SHAPE_TYPE_DEBUG(SHAPE_decagon)// =314,
		BR_SHAPE_TYPE_DEBUG(SHAPE_dodecagon)// =315, 
		BR_SHAPE_TYPE_DEBUG(SHAPE_pie)// =316,
		BR_SHAPE_TYPE_DEBUG(SHAPE_chord)// =317,
		BR_SHAPE_TYPE_DEBUG(SHAPE_teardrop)// =318,
		BR_SHAPE_TYPE_DEBUG(SHAPE_frame)// =319,
		BR_SHAPE_TYPE_DEBUG(SHAPE_halfFrame)// =320,
		BR_SHAPE_TYPE_DEBUG(SHAPE_corner)// =321,
		BR_SHAPE_TYPE_DEBUG(SHAPE_diagStripe)// =322,
		BR_SHAPE_TYPE_DEBUG(SHAPE_cloud)// =323,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Star6)// =324,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Star7)// =325,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Star10)// =326,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Star12)// =327,
		BR_SHAPE_TYPE_DEBUG(SHAPE_swooshArrow)// =334,
		BR_SHAPE_TYPE_DEBUG(SHAPE_leftCircularArrow)// =335,
		BR_SHAPE_TYPE_DEBUG(SHAPE_pieWedge)// =336,
		BR_SHAPE_TYPE_DEBUG(SHAPE_nonIsoscelesTrapezoid)// =337,
		// office2007 new shape


		// office2007_SmartArt new shape
		//BR_SHAPE_TYPE_DEBUG(SHAPE_RightArrow)// =329,
		BR_SHAPE_TYPE_DEBUG(SHAPE_LeftRightRibbon)// =330,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Funnel)// =331,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Gear9)// =332,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Gear6)// =333,

		BR_SHAPE_TYPE_DEBUG(SHAPE_BoraPoly)// =400,
		BR_SHAPE_TYPE_DEBUG(SHAPE_BackGround)// =401,

#ifdef  GUL_IMPORT
		// �ƹ�������
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_200)// =500,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_201)// =501,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_202)// =502,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_203)// =503,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_204)// =504,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_205)// =505,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_206)// =506,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_207)// =507,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_208)// =508,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_209)// =509,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_210)// =510,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_211)// =511,	 
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_212)// =512,	 
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_213)// =513,	 
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_214)// =514,	 
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_215)// =515,	 
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_216)// =516,	 
		// Block arrow style Template
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_301)// =521,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_302)// =522,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_303)// =523,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_304)// =524,

		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_305)// =525,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_306)// =526,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_307)// =527,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_308)// =528,

		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_309)// =529,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_310)// =530,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_311)// =531,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_312)// =532,

		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_313)// =533,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_314)// =534,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_315)// =535,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_316)// =536,

		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_317)// =537,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_318)// =538,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_319)// =539,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_320)// =540,
 
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_321)// =541,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_322)// =542,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_323)// =543,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_324)// =544,

		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_325)// =545,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_326)// =546,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_327)// =547,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_328)// =548,	 

		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_329)// =549,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_330)// =550,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_331)// =551,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_332)// =552,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_333)// =553,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_334)// =554,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_335)// =555,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_336)// =556,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_337)// =557,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_338)// =558,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_339)// =559,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_340)// =560,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_341)// =561,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_342)// =562,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_343)// =563,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_344)// =564,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_345)// =565,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_346)// =566,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_347)// =567,
		//�����
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_401)// =601,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_402)// =602,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_403)// =603,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_404)// =604,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_405)// =605,
		BR_SHAPE_TYPE_DEBUG(SHAPE_hun_templ_406)// =606,
#endif
		BR_SHAPE_TYPE_DEBUG(SHAPE_Max)//,
		BR_SHAPE_TYPE_DEBUG(SHAPE_Nil)// =0x0FFF
		BR_SHAPE_TYPE_DEBUG_DEFAULT(nType)
	}
#endif
}



#endif //(B_DEBUG) 


BrINT ShapeTypeToBrShapeType(BrINT shape_type)
{
	BrShapeType br_shape_type = (BrShapeType)shape_type;

	//100���� : ��
	switch (shape_type) {
		case SHAPE_StraightConnector1:      br_shape_type = SHAPE_TYPE_LINE;                             break;
		//case SHAPE_StraightConnector1:      shape_type = SHAPE_TYPE_ARROW;                            break;
		//case SHAPE_StraightConnector1:      shape_type = SHAPE_TYPE_DOUBLE_ARROW;                     break;
		case SHAPE_BentConnector3:          br_shape_type = SHAPE_TYPE_ELBOW_CONNECTOR;                  break;
		//case SHAPE_BentConnector3:          shape_type = SHAPE_TYPE_ELBOW_ARROW_CONNECTOR;            break;
		//case SHAPE_BentConnector3:          shape_type = SHAPE_TYPE_ELBOW_DOUBLE_ARROW_CONNECTOR;     break;
		case SHAPE_CurvedConnector3:        br_shape_type = SHAPE_TYPE_CURVED_CONNECTOR;                 break;
		//case SHAPE_CurvedConnector3:        shape_type = SHAPE_TYPE_CURVED_ARROW_CONNECTOR;           break;
		//case SHAPE_CurvedConnector3:        shape_type = SHAPE_TYPE_CURVED_DOUBLE_ARROW_CONNECTOR;    break;
		case SHAPE_scribble:                br_shape_type = SHAPE_TYPE_CURVE;                            break;
		//case SHAPE_scribble:                shape_type = SHAPE_TYPE_FREEFORM;                         break;
		//case SHAPE_scribble:                shape_type = SHAPE_TYPE_SCRIBLE;                          break;

		//200���� : �簢�� ����
		case SHAPE_TextBox:
		case SHAPE_Rectangle:         br_shape_type = SHAPE_TYPE_RECTANGLE;                                 break;
		case SHAPE_RoundRectangle:    br_shape_type = SHAPE_TYPE_ROUNDED_RECTANGLE;                         break;
		case SHAPE_snip1Rect:         br_shape_type = SHAPE_TYPE_SNIP_SINGLE_CORNER_RECTANGLE;              break;
		case SHAPE_snip2SameRect:     br_shape_type = SHAPE_TYPE_SNIP_SAME_SIDE_CORNER_RECTANGLE;           break;
		case SHAPE_snip2DiagRect:     br_shape_type = SHAPE_TYPE_SNIP_DIAGONAL_CORNER_RECTANGLE;            break;
		case SHAPE_snipRoundRect:     br_shape_type = SHAPE_TYPE_SNIP_AND_ROUND_SINGLE_CORNER_RECTANGLE;    break;
		case SHAPE_round1Rect:        br_shape_type = SHAPE_TYPE_ROUND_SINGLE_CORNER_RECTANGLE;             break;
		case SHAPE_round2SameRect:    br_shape_type = SHAPE_TYPE_ROUND_SAME_SIDE_CORNER_RECTANGLE;          break;
		case SHAPE_round2DiagRect:    br_shape_type = SHAPE_TYPE_ROUND_DIAGONAL_CORNER_RECTANGLE;           break;

		//300���� : �⺻ ����
		case SHAPE_Ellipse:             br_shape_type = SHAPE_TYPE_OVAL;                  break;
		case SHAPE_IsocelesTriangle:    br_shape_type = SHAPE_TYPE_ISOSCELES_TRIANGLE;    break;
		case SHAPE_RightTriangle:       br_shape_type = SHAPE_TYPE_RIGHT_TRIANGLE;        break;
		case SHAPE_Parallelogram:       br_shape_type = SHAPE_TYPE_PARALLELOGRAM;         break;
		case SHAPE_Trapezoid:           br_shape_type = SHAPE_TYPE_TRAPEZOID;             break;
		case SHAPE_Diamond:             br_shape_type = SHAPE_TYPE_DIAMOND;               break;
		case SHAPE_Pentagon:            br_shape_type = SHAPE_TYPE_REGULAR_PENTAGON;      break;
		case SHAPE_Hexagon:             br_shape_type = SHAPE_TYPE_HEXAGON;               break;
		case SHAPE_heptagon:            br_shape_type = SHAPE_TYPE_HEPTAGON;              break;
		case SHAPE_Octagon:             br_shape_type = SHAPE_TYPE_OCTAGON;               break;
		case SHAPE_decagon:             br_shape_type = SHAPE_TYPE_DECAGON;               break;
		case SHAPE_dodecagon:           br_shape_type = SHAPE_TYPE_DODECAGON;             break;
		case SHAPE_pie:                 br_shape_type = SHAPE_TYPE_PIE;                   break;
		case SHAPE_chord:               br_shape_type = SHAPE_TYPE_CHORD;                 break;
		case SHAPE_teardrop:            br_shape_type = SHAPE_TYPE_TEARDROP;              break;
		case SHAPE_frame:               br_shape_type = SHAPE_TYPE_FRAME;                 break;
		case SHAPE_halfFrame:           br_shape_type = SHAPE_TYPE_HALF_FRAME;            break;
		case SHAPE_corner:              br_shape_type = SHAPE_TYPE_L_SHAPE;               break;
		case SHAPE_diagStripe:          br_shape_type = SHAPE_TYPE_DIAGONAL_STRIPE;       break;
		case SHAPE_Plus:                br_shape_type = SHAPE_TYPE_PLUS;                  break;
		case SHAPE_Plaque:              br_shape_type = SHAPE_TYPE_PLAQUE;                break;
		case SHAPE_Can:                 br_shape_type = SHAPE_TYPE_CAN;                   break;
		case SHAPE_Cube:                br_shape_type = SHAPE_TYPE_CUBE;                  break;
		case SHAPE_Bevel:               br_shape_type = SHAPE_TYPE_BEVEL;                 break;
		case SHAPE_Donut:               br_shape_type = SHAPE_TYPE_DONUT;                 break;
		case SHAPE_NoSmoking:           br_shape_type = SHAPE_TYPE_NO_SYMBOL;             break;
		case SHAPE_BlockArc:            br_shape_type = SHAPE_TYPE_BLOCK_ARC;             break;
		case SHAPE_FoldedCorner:        br_shape_type = SHAPE_TYPE_FOLDED_CORNER;         break;
		case SHAPE_SmileyFace:          br_shape_type = SHAPE_TYPE_SMILEY_FACE;           break;
		case SHAPE_Heart:               br_shape_type = SHAPE_TYPE_HEART;                 break;
		case SHAPE_LightningBolt:       br_shape_type = SHAPE_TYPE_LIGHTING_BOLT;         break;
		case SHAPE_Sun:                 br_shape_type = SHAPE_TYPE_SUN;                   break;
		case SHAPE_Moon:                br_shape_type = SHAPE_TYPE_MOON;                  break;
		case SHAPE_cloud:               br_shape_type = SHAPE_TYPE_CLOUD;                 break;
		case SHAPE_Arc:                 br_shape_type = SHAPE_TYPE_ARC;                   break;
		case SHAPE_BracketPair:         br_shape_type = SHAPE_TYPE_DOUBLE_BRACKET;        break;
		case SHAPE_BracePair:           br_shape_type = SHAPE_TYPE_DOUBLE_BRACE;          break;
		case SHAPE_LeftBracket:         br_shape_type = SHAPE_TYPE_LEFT_BRACKET;          break;
		case SHAPE_RightBracket:        br_shape_type = SHAPE_TYPE_RIGHT_BRACKET;         break;
		case SHAPE_LeftBrace:           br_shape_type = SHAPE_TYPE_LEFT_BRACE;            break;
		case SHAPE_RightBrace:          br_shape_type = SHAPE_TYPE_RIGHT_BRACE;           break;

		//400���� : ���� ȭ��ǥ
		case SHAPE_Arrow:                    br_shape_type = SHAPE_TYPE_RIGHT_ARROW;                 break;
		case SHAPE_LeftArrow:                br_shape_type = SHAPE_TYPE_LEFT_ARROW;                  break;
		case SHAPE_UpArrow:                  br_shape_type = SHAPE_TYPE_UP_ARROW;                    break;
		case SHAPE_DownArrow:                br_shape_type = SHAPE_TYPE_DOWN_ARROW;                  break;
		case SHAPE_LeftRightArrow:           br_shape_type = SHAPE_TYPE_LEFT_RIGHT_ARROW;            break;
		case SHAPE_UpDownArrow:              br_shape_type = SHAPE_TYPE_UP_DOWN_ARROW;               break;
		case SHAPE_QuadArrow:                br_shape_type = SHAPE_TYPE_QUAD_ARROW;                  break;
		case SHAPE_LeftRightUpArrow:         br_shape_type = SHAPE_TYPE_LEFT_RIGHT_UP_ARROW;         break;
		case SHAPE_BentArrow:                br_shape_type = SHAPE_TYPE_BENT_ARROW;                  break;
		case SHAPE_UturnArrow:               br_shape_type = SHAPE_TYPE_U_TURN_ARROW;                break;
		case SHAPE_LeftUpArrow:              br_shape_type = SHAPE_TYPE_LEFT_UP_ARROW;               break;
		case SHAPE_BentUpArrow:              br_shape_type = SHAPE_TYPE_BENT_UP_ARROW;               break;
		case SHAPE_CurvedRightArrow:         br_shape_type = SHAPE_TYPE_CURVED_RIGHT_ARROW;          break;
		case SHAPE_CurvedLeftArrow:          br_shape_type = SHAPE_TYPE_CURVED_LEFT_ARROW;           break;
		case SHAPE_CurvedUpArrow:            br_shape_type = SHAPE_TYPE_CURVED_UP_ARROW;             break;
		case SHAPE_CurvedDownArrow:          br_shape_type = SHAPE_TYPE_CURVED_DOWN_ARROW;           break;
		case SHAPE_StripedRightArrow:        br_shape_type = SHAPE_TYPE_STRIPED_RIGHT_ARROW;         break;
		case SHAPE_NotchedRightArrow:        br_shape_type = SHAPE_TYPE_NOTCHED_RIGHT_ARROW;         break;
		case SHAPE_HomePlate:                br_shape_type = SHAPE_TYPE_PENTAGON;                    break;
		case SHAPE_Chevron:                  br_shape_type = SHAPE_TYPE_CHEVRON_UP;                  break;
		case SHAPE_RightArrowCallout:        br_shape_type = SHAPE_TYPE_RIGHT_ARROW_CALLOUT;         break;
		case SHAPE_DownArrowCallout:         br_shape_type = SHAPE_TYPE_DOWN_ARROW_CALLOUT;          break;
		case SHAPE_LeftArrowCallout:         br_shape_type = SHAPE_TYPE_LEFT_ARROW_CALLOUT;          break;
		case SHAPE_UpArrowCallout:           br_shape_type = SHAPE_TYPE_UP_ARROW_CALLOUT;            break;
		case SHAPE_LeftRightArrowCallout:    br_shape_type = SHAPE_TYPE_LEFT_RIGHT_ARROW_CALLOUT;    break;
		case SHAPE_UpDownArrowCallout:       br_shape_type = SHAPE_TYPE_UP_DOWN_ARROW_CALLOUT;       break;
		case SHAPE_QuadArrowCallout:         br_shape_type = SHAPE_TYPE_QUAD_ARROW_CALLOUT;          break;
		case SHAPE_CircularArrow:            br_shape_type = SHAPE_TYPE_CIRCULAR_ARROW;              break;

		//500���� : ����
		case SHAPE_mathPlus:        br_shape_type = SHAPE_TYPE_MATH_PLUS;         break;
		case SHAPE_mathMinus:       br_shape_type = SHAPE_TYPE_MATH_MINUS;        break;
		case SHAPE_mathMultiply:    br_shape_type = SHAPE_TYPE_MATH_MULTIPLY;     break;
		case SHAPE_mathDivide:      br_shape_type = SHAPE_TYPE_MATH_DIVISION;     break;
		case SHAPE_mathEqual:       br_shape_type = SHAPE_TYPE_MATH_EQUAL;        break;
		case SHAPE_mathNotEqual:    br_shape_type = SHAPE_TYPE_MATH_NOT_EQUAL;    break;

		//600���� : ������
		case SHAPE_FlowChartProcess:              br_shape_type = SHAPE_TYPE_FLOW_CHART_PROCESS;                      break;        
		case SHAPE_FlowChartAlternateProcess:     br_shape_type = SHAPE_TYPE_FLOW_CHART_ALTERNATE_PROCESS;            break;
		case SHAPE_FlowChartDecision:             br_shape_type = SHAPE_TYPE_FLOW_CHART_DECISION;                     break;
		case SHAPE_FlowChartInputOutput:          br_shape_type = SHAPE_TYPE_FLOW_CHART_DATA;                         break;
		case SHAPE_FlowChartPredefinedProcess:    br_shape_type = SHAPE_TYPE_FLOW_CHART_PREDEFINED_PROCESS;           break;
		case SHAPE_FlowChartInternalStorage:      br_shape_type = SHAPE_TYPE_FLOW_CHART_INTERNAL_STORAGE;             break;
		case SHAPE_FlowChartDocument:             br_shape_type = SHAPE_TYPE_FLOW_CHART_DOCUMENT;                     break;
		case SHAPE_FlowChartMultidocument:        br_shape_type = SHAPE_TYPE_FLOW_CHART_MULTIDOCUMENT;                break;
		case SHAPE_FlowChartTerminator:           br_shape_type = SHAPE_TYPE_FLOW_CHART_TERMINATOR;                   break;    
		case SHAPE_FlowChartPreparation:          br_shape_type = SHAPE_TYPE_FLOW_CHART_PREPARATION;                  break;
		case SHAPE_FlowChartManualInput:          br_shape_type = SHAPE_TYPE_FLOW_CHART_MANUAL_INPUT;                 break;
		case SHAPE_FlowChartManualOperation:      br_shape_type = SHAPE_TYPE_FLOW_CHART_MANUAL_OPERATION;             break;
		case SHAPE_FlowChartConnector:            br_shape_type = SHAPE_TYPE_FLOW_CHART_CONNECTOR;                    break;
		case SHAPE_FlowChartOffpageConnector:     br_shape_type = SHAPE_TYPE_FLOW_CHART_OFF_PAGE_CONNECTOR;           break;
		case SHAPE_FlowChartPunchedCard:          br_shape_type = SHAPE_TYPE_FLOW_CHART_CARD;                         break;
		case SHAPE_FlowChartPunchedTape:          br_shape_type = SHAPE_TYPE_FLOW_CHART_PUNCHED_TAPE;                 break;
		case SHAPE_FlowChartSummingJunction:      br_shape_type = SHAPE_TYPE_FLOW_CHART_SUMMING_JUNCTION;             break;
		case SHAPE_FlowChartOr:                   br_shape_type = SHAPE_TYPE_FLOW_CHART_OR;                           break;
		case SHAPE_FlowChartCollate:              br_shape_type = SHAPE_TYPE_FLOW_CHART_COLLATE;                      break;
		case SHAPE_FlowChartSort:                 br_shape_type = SHAPE_TYPE_FLOW_CHART_SORT;                         break;
		case SHAPE_FlowChartExtract:              br_shape_type = SHAPE_TYPE_FLOW_CHART_EXTRACT;                      break;
		case SHAPE_FlowChartMerge:                br_shape_type = SHAPE_TYPE_FLOW_CHART_MERGE;                        break;
		case SHAPE_FlowChartOnlineStorage:        br_shape_type = SHAPE_TYPE_FLOW_CHART_STORED_DATA;                  break;
		case SHAPE_FlowChartDelay:                br_shape_type = SHAPE_TYPE_FLOW_CHART_DELAY;                        break;
		case SHAPE_FlowChartMagneticTape:         br_shape_type = SHAPE_TYPE_FLOW_CHART_SEQUENTIAL_ACCESS_STORAGE;    break;
		case SHAPE_FlowChartMagneticDisk:         br_shape_type = SHAPE_TYPE_FLOW_CHART_MAGNETIC_DISK;                break;
		case SHAPE_FlowChartMagneticDrum:         br_shape_type = SHAPE_TYPE_FLOW_CHART_DIRECT_ACCESS_STORAGE;        break;
		case SHAPE_FlowChartDisplay:              br_shape_type = SHAPE_TYPE_FLOW_CHART_DISPLAY;                      break;

		//700���� : �� �� ������
		case SHAPE_IrregularSeal1:      br_shape_type = SHAPE_TYPE_EXPLOSION_1;           break;
		case SHAPE_IrregularSeal2:      br_shape_type = SHAPE_TYPE_EXPLOSION_2;           break;
		case SHAPE_Seal4:               br_shape_type = SHAPE_TYPE_4_POINT_STAR;          break;
		case SHAPE_Star:                br_shape_type = SHAPE_TYPE_5_POINT_STAR;          break;
		case SHAPE_Star6:               br_shape_type = SHAPE_TYPE_6_POINT_STAR;          break;
		case SHAPE_Star7:               br_shape_type = SHAPE_TYPE_7_POINT_STAR;          break;
		case SHAPE_Seal8:               br_shape_type = SHAPE_TYPE_8_POINT_STAR;          break;
		case SHAPE_Star10:              br_shape_type = SHAPE_TYPE_10_POINT_STAR;         break;
		case SHAPE_Star12:              br_shape_type = SHAPE_TYPE_12_POINT_STAR;         break;
		case SHAPE_Seal16:              br_shape_type = SHAPE_TYPE_16_POINT_STAR;         break;
		case SHAPE_Seal24:              br_shape_type = SHAPE_TYPE_24_POINT_STAR;         break;
		case SHAPE_Seal32:              br_shape_type = SHAPE_TYPE_32_POINT_STAR;         break;
		case SHAPE_Ribbon2:             br_shape_type = SHAPE_TYPE_UP_RIBBON;             break;
		case SHAPE_Ribbon:              br_shape_type = SHAPE_TYPE_DOWN_RIBBON;           break;
		case SHAPE_EllipseRibbon2:      br_shape_type = SHAPE_TYPE_CURVED_UP_RIBBON;      break;
		case SHAPE_EllipseRibbon:       br_shape_type = SHAPE_TYPE_CURVED_DOWN_RIBBON;    break;
		case SHAPE_VerticalScroll:      br_shape_type = SHAPE_TYPE_VERTICAL_SCROLL;       break;
		case SHAPE_HorizontalScroll:    br_shape_type = SHAPE_TYPE_HORIZONTAL_SCROLL;     break;
		case SHAPE_Wave:                br_shape_type = SHAPE_TYPE_WAVES;                 break;
		case SHAPE_DoubleWave:          br_shape_type = SHAPE_TYPE_DOUBLE_WAVE;           break;

		//800���� : ������
		case SHAPE_WedgeRectCallout:        br_shape_type = SHAPE_TYPE_RECTANGULAR_CALLOUT;                     break;
		case SHAPE_WedgeRRectCallout:       br_shape_type = SHAPE_TYPE_ROUNDED_RECTANGULAR_CALLOUT;             break;
		case SHAPE_WedgeEllipseCallout:     br_shape_type = SHAPE_TYPE_OVAL_CALLOUT;                            break;
		case SHAPE_CloudCallout:            br_shape_type = SHAPE_TYPE_CLOUD_CALLOUT;                           break;
		case SHAPE_BorderCallout1:          br_shape_type = SHAPE_TYPE_LINE_CALLOUT_1;                          break;
		case SHAPE_BorderCallout2:          br_shape_type = SHAPE_TYPE_LINE_CALLOUT_2;                          break;
		case SHAPE_BorderCallout3:          br_shape_type = SHAPE_TYPE_LINE_CALLOUT_3;                          break;
		case SHAPE_AccentCallout1:          br_shape_type = SHAPE_TYPE_LINE_CALLOUT_1_ACCENT_BAR;               break;
		case SHAPE_AccentCallout2:          br_shape_type = SHAPE_TYPE_LINE_CALLOUT_2_ACCENT_BAR;               break;
		case SHAPE_AccentCallout3:          br_shape_type = SHAPE_TYPE_LINE_CALLOUT_3_ACCENT_BAR;               break;
		case SHAPE_Callout1:                br_shape_type = SHAPE_TYPE_LINE_CALLOUT_1_NO_BORDER;                break;
		case SHAPE_Callout2:                br_shape_type = SHAPE_TYPE_LINE_CALLOUT_2_NO_BORDER;                break;
		case SHAPE_Callout3:                br_shape_type = SHAPE_TYPE_LINE_CALLOUT_3_NO_BORDER;                break;
		case SHAPE_AccentBorderCallout1:    br_shape_type = SHAPE_TYPE_LINE_CALLOUT_1_BORDER_AND_ACCENT_BAR;    break;
		case SHAPE_AccentBorderCallout2:    br_shape_type = SHAPE_TYPE_LINE_CALLOUT_2_BORDER_AND_ACCENT_BAR;    break;
		case SHAPE_AccentBorderCallout3:    br_shape_type = SHAPE_TYPE_LINE_CALLOUT_3_BORDER_AND_ACCENT_BAR;    break;

		//900���� : ���� ����
		case SHAPE_ActionButtonBackPrevious:    br_shape_type = SHAPE_TYPE_ACTION_BUTTON_BACK_OR_PREVIOUS;    break;
		case SHAPE_ActionButtonForwardNext:     br_shape_type = SHAPE_TYPE_ACTION_BUTTON_FORWARD_OR_NEXT;     break;
		case SHAPE_ActionButtonBeginning:       br_shape_type = SHAPE_TYPE_ACTION_BUTTON_BEGINNING;           break;
		case SHAPE_ActionButtonEnd:             br_shape_type = SHAPE_TYPE_ACTION_BUTTON_END;                 break;
		case SHAPE_ActionButtonHome:            br_shape_type = SHAPE_TYPE_ACTION_BUTTON_HOME;                break;
		case SHAPE_ActionButtonInformation:     br_shape_type = SHAPE_TYPE_ACTION_BUTTON_INFORMATION;         break;
		case SHAPE_ActionButtonReturn:          br_shape_type = SHAPE_TYPE_ACTION_BUTTON_RETURN;              break;
		case SHAPE_ActionButtonMovie:           br_shape_type = SHAPE_TYPE_ACTION_BUTTON_MOVIE;               break;
		case SHAPE_ActionButtonDocument:        br_shape_type = SHAPE_TYPE_ACTION_BUTTON_DOCUMENT;            break;
		case SHAPE_ActionButtonSound:           br_shape_type = SHAPE_TYPE_ACTION_BUTTON_SOUND;               break;
		case SHAPE_ActionButtonHelp:            br_shape_type = SHAPE_TYPE_ACTION_BUTTON_HELP;                break;
		case SHAPE_ActionButtonBlank:           br_shape_type = SHAPE_TYPE_ACTION_BUTTON_CUSTOM;              break;
    }

	return static_cast<BrINT>(br_shape_type);
}

//ZPD-3340, shape name
BrINT ShapeTypeToResStringID(BrINT shape_type, BrINT nArraowNum)
{
	BrResStringID eBrResStringID = BR_RESSTR_NONE;

	switch (shape_type) {
	case SHAPE_StraightConnector1:
		eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_LINE;
		if(nArraowNum == 1) eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_ARROW;
		else if(nArraowNum == 2) eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_DOUBLE_ARROW;
		break;
	case SHAPE_BentConnector3:
		eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_ELBOW_CONNECTOR; 
		if(nArraowNum == 1) eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_ELBOW_ARROW_CONNECTOR;
		else if(nArraowNum == 2) eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_ELBOW_DOUBLE_ARROW_CONNECTOR;
		break;
	case SHAPE_CurvedConnector3:
		eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_CURVED_CONNECTOR;
		if(nArraowNum == 1) eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_CURVED_ARROW_CONNECTOR;
		else if(nArraowNum == 2) eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_CURVED_DOUBLE_ARROW_CONNECTOR;
		break;
	case SHAPE_scribble:                eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_CURVE;                            break;
		//case SHAPE_scribble:          eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_FREEFORM;                         break;
		//case SHAPE_scribble:          eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_SCRIBLE;                          break;

		//200���� : �簢�� ����
	case SHAPE_Rectangle:         eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_RECTANGLE;                                 break;
	case SHAPE_RoundRectangle:    eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_ROUNDED_RECTANGLE;                         break;
	case SHAPE_snip1Rect:         eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_SNIP_SINGLE_CORNER_RECTANGLE;              break;
	case SHAPE_snip2SameRect:     eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_SNIP_SAME_SIDE_CORNER_RECTANGLE;           break;
	case SHAPE_snip2DiagRect:     eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_SNIP_DIAGONAL_CORNER_RECTANGLE;            break;
	case SHAPE_snipRoundRect:     eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_SNIP_AND_ROUND_SINGLE_CORNER_RECTANGLE;    break;
	case SHAPE_round1Rect:        eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_ROUND_SINGLE_CORNER_RECTANGLE;             break;
	case SHAPE_round2SameRect:    eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_ROUND_SAME_SIDE_CORNER_RECTANGLE;          break;
	case SHAPE_round2DiagRect:    eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_ROUND_DIAGONAL_CORNER_RECTANGLE;           break;

		//300���� : �⺻ ����
	case SHAPE_Ellipse:             eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_OVAL;                  break;
	case SHAPE_IsocelesTriangle:    eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_ISOSCELES_TRIANGLE;    break;
	case SHAPE_RightTriangle:       eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_RIGHT_TRIANGLE;        break;
	case SHAPE_Parallelogram:       eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_PARALLELOGRAM;         break;
	case SHAPE_Trapezoid:           eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_TRAPEZOID;             break;
	case SHAPE_Diamond:             eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_DIAMOND;               break;
	case SHAPE_Pentagon:            eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_REGULAR_PENTAGON;      break;
	case SHAPE_Hexagon:             eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_HEXAGON;               break;
	case SHAPE_heptagon:            eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_HEPTAGON;              break;
	case SHAPE_Octagon:             eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_OCTAGON;               break;
	case SHAPE_decagon:             eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_DECAGON;               break;
	case SHAPE_dodecagon:           eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_DODECAGON;             break;
	case SHAPE_pie:                 eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_PIE;                   break;
	case SHAPE_chord:               eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_CHORD;                 break;
	case SHAPE_teardrop:            eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_TEARDROP;              break;
	case SHAPE_frame:               eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_FRAME;                 break;
	case SHAPE_halfFrame:           eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_HALF_FRAME;            break;
	case SHAPE_corner:              eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_L_SHAPE;               break;
	case SHAPE_diagStripe:          eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_DIAGONAL_STRIPE;       break;
	case SHAPE_Plus:                eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_PLUS;                  break;
	case SHAPE_Plaque:              eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_PLAQUE;                break;
	case SHAPE_Can:                 eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_CAN;                   break;
	case SHAPE_Cube:                eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_CUBE;                  break;
	case SHAPE_Bevel:               eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_BEVEL;                 break;
	case SHAPE_Donut:               eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_DONUT;                 break;
	case SHAPE_NoSmoking:           eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_NO_SYMBOL;             break;
	case SHAPE_BlockArc:            eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_BLOCK_ARC;             break;
	case SHAPE_FoldedCorner:        eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_FOLDED_CORNER;         break;
	case SHAPE_SmileyFace:          eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_SMILEY_FACE;           break;
	case SHAPE_Heart:               eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_HEART;                 break;
	case SHAPE_LightningBolt:       eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_LIGHTING_BOLT;         break;
	case SHAPE_Sun:                 eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_SUN;                   break;
	case SHAPE_Moon:                eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_MOON;                  break;
	case SHAPE_cloud:               eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_CLOUD;                 break;
	case SHAPE_Arc:                 eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_ARC;                   break;
	case SHAPE_BracketPair:         eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_DOUBLE_BRACKET;        break;
	case SHAPE_BracePair:           eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_DOUBLE_BRACE;          break;
	case SHAPE_LeftBracket:         eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_LEFT_BRACKET;          break;
	case SHAPE_RightBracket:        eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_RIGHT_BRACKET;         break;
	case SHAPE_LeftBrace:           eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_LEFT_BRACE;            break;
	case SHAPE_RightBrace:          eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_RIGHT_BRACE;           break;

		//400���� : ���� ȭ��ǥ
	case SHAPE_Arrow:                    eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_RIGHT_ARROW;                 break;
	case SHAPE_LeftArrow:                eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_LEFT_ARROW;                  break;
	case SHAPE_UpArrow:                  eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_UP_ARROW;                    break;
	case SHAPE_DownArrow:                eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_DOWN_ARROW;                  break;
	case SHAPE_LeftRightArrow:           eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_LEFT_RIGHT_ARROW;            break;
	case SHAPE_UpDownArrow:              eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_UP_DOWN_ARROW;               break;
	case SHAPE_QuadArrow:                eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_QUAD_ARROW;                  break;
	case SHAPE_LeftRightUpArrow:         eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_LEFT_RIGHT_UP_ARROW;         break;
	case SHAPE_BentArrow:                eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_BENT_ARROW;                  break;
	case SHAPE_UturnArrow:               eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_U_TURN_ARROW;                break;
	case SHAPE_LeftUpArrow:              eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_LEFT_UP_ARROW;               break;
	case SHAPE_BentUpArrow:              eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_BENT_UP_ARROW;               break;
	case SHAPE_CurvedRightArrow:         eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_CURVED_RIGHT_ARROW;          break;
	case SHAPE_CurvedLeftArrow:          eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_CURVED_LEFT_ARROW;           break;
	case SHAPE_CurvedUpArrow:            eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_CURVED_UP_ARROW;             break;
	case SHAPE_CurvedDownArrow:          eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_CURVED_DOWN_ARROW;           break;
	case SHAPE_StripedRightArrow:        eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_STRIPED_RIGHT_ARROW;         break;
	case SHAPE_NotchedRightArrow:        eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_NOTCHED_RIGHT_ARROW;         break;
	case SHAPE_HomePlate:                eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_PENTAGON;                    break;
	case SHAPE_Chevron:                  eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_CHEVRON_UP;                  break;
	case SHAPE_RightArrowCallout:        eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_RIGHT_ARROW_CALLOUT;         break;
	case SHAPE_DownArrowCallout:         eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_DOWN_ARROW_CALLOUT;          break;
	case SHAPE_LeftArrowCallout:         eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_LEFT_ARROW_CALLOUT;          break;
	case SHAPE_UpArrowCallout:           eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_UP_ARROW_CALLOUT;            break;
	case SHAPE_LeftRightArrowCallout:    eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_LEFT_RIGHT_ARROW_CALLOUT;    break;
	case SHAPE_UpDownArrowCallout:       eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_UP_DOWN_ARROW_CALLOUT;       break;
	case SHAPE_QuadArrowCallout:         eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_QUAD_ARROW_CALLOUT;          break;
	case SHAPE_CircularArrow:            eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_CIRCULAR_ARROW;              break;

		//500���� : ����
	case SHAPE_mathPlus:        eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_MATH_PLUS;         break;
	case SHAPE_mathMinus:       eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_MATH_MINUS;        break;
	case SHAPE_mathMultiply:    eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_MATH_MULTIPLY;     break;
	case SHAPE_mathDivide:      eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_MATH_DIVISION;     break;
	case SHAPE_mathEqual:       eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_MATH_EQUAL;        break;
	case SHAPE_mathNotEqual:    eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_MATH_NOT_EQUAL;    break;

		//600���� : ������
	case SHAPE_FlowChartProcess:              eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_FLOW_CHART_PROCESS;                      break;        
	case SHAPE_FlowChartAlternateProcess:     eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_FLOW_CHART_ALTERNATE_PROCESS;            break;
	case SHAPE_FlowChartDecision:             eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_FLOW_CHART_DECISION;                     break;
	case SHAPE_FlowChartInputOutput:          eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_FLOW_CHART_DATA;                         break;
	case SHAPE_FlowChartPredefinedProcess:    eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_FLOW_CHART_PREDEFINED_PROCESS;           break;
	case SHAPE_FlowChartInternalStorage:      eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_FLOW_CHART_INTERNAL_STORAGE;             break;
	case SHAPE_FlowChartDocument:             eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_FLOW_CHART_DOCUMENT;                     break;
	case SHAPE_FlowChartMultidocument:        eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_FLOW_CHART_MULTIDOCUMENT;                break;
	case SHAPE_FlowChartTerminator:           eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_FLOW_CHART_TERMINATOR;                   break;    
	case SHAPE_FlowChartPreparation:          eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_FLOW_CHART_PREPARATION;                  break;
	case SHAPE_FlowChartManualInput:          eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_FLOW_CHART_MANUAL_INPUT;                 break;
	case SHAPE_FlowChartManualOperation:      eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_FLOW_CHART_MANUAL_OPERATION;             break;
	case SHAPE_FlowChartConnector:            eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_FLOW_CHART_CONNECTOR;                    break;
	case SHAPE_FlowChartOffpageConnector:     eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_FLOW_CHART_OFF_PAGE_CONNECTOR;           break;
	case SHAPE_FlowChartPunchedCard:          eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_FLOW_CHART_CARD;                         break;
	case SHAPE_FlowChartPunchedTape:          eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_FLOW_CHART_PUNCHED_TAPE;                 break;
	case SHAPE_FlowChartSummingJunction:      eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_FLOW_CHART_SUMMING_JUNCTION;             break;
	case SHAPE_FlowChartOr:                   eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_FLOW_CHART_OR;                           break;
	case SHAPE_FlowChartCollate:              eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_FLOW_CHART_COLLATE;                      break;
	case SHAPE_FlowChartSort:                 eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_FLOW_CHART_SORT;                         break;
	case SHAPE_FlowChartExtract:              eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_FLOW_CHART_EXTRACT;                      break;
	case SHAPE_FlowChartMerge:                eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_FLOW_CHART_MERGE;                        break;
	case SHAPE_FlowChartOnlineStorage:        eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_FLOW_CHART_STORED_DATA;                  break;
	case SHAPE_FlowChartDelay:                eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_FLOW_CHART_DELAY;                        break;
	case SHAPE_FlowChartMagneticTape:         eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_FLOW_CHART_SEQUENTIAL_ACCESS_STORAGE;    break;
	case SHAPE_FlowChartMagneticDisk:         eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_FLOW_CHART_MAGNETIC_DISK;                break;
	case SHAPE_FlowChartMagneticDrum:         eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_FLOW_CHART_DIRECT_ACCESS_STORAGE;        break;
	case SHAPE_FlowChartDisplay:              eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_FLOW_CHART_DISPLAY;                      break;

		//700���� : �� �� ������
	case SHAPE_IrregularSeal1:      eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_EXPLOSION_1;           break;
	case SHAPE_IrregularSeal2:      eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_EXPLOSION_2;           break;
	case SHAPE_Seal4:               eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_4_POINT_STAR;          break;
	case SHAPE_Star:                eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_5_POINT_STAR;          break;
	case SHAPE_Star6:               eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_6_POINT_STAR;          break;
	case SHAPE_Star7:               eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_7_POINT_STAR;          break;
	case SHAPE_Seal8:               eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_8_POINT_STAR;          break;
	case SHAPE_Star10:              eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_10_POINT_STAR;         break;
	case SHAPE_Star12:              eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_12_POINT_STAR;         break;
	case SHAPE_Seal16:              eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_16_POINT_STAR;         break;
	case SHAPE_Seal24:              eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_24_POINT_STAR;         break;
	case SHAPE_Seal32:              eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_32_POINT_STAR;         break;
	case SHAPE_Ribbon2:             eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_UP_RIBBON;             break;
	case SHAPE_Ribbon:              eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_DOWN_RIBBON;           break;
	case SHAPE_EllipseRibbon2:      eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_CURVED_UP_RIBBON;      break;
	case SHAPE_EllipseRibbon:       eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_CURVED_DOWN_RIBBON;    break;
	case SHAPE_VerticalScroll:      eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_VERTICAL_SCROLL;       break;
	case SHAPE_HorizontalScroll:    eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_HORIZONTAL_SCROLL;     break;
	case SHAPE_Wave:                eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_WAVES;                 break;
	case SHAPE_DoubleWave:          eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_DOUBLE_WAVE;           break;

		//800���� : ������
	case SHAPE_WedgeRectCallout:        eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_RECTANGULAR_CALLOUT;                     break;
	case SHAPE_WedgeRRectCallout:       eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_ROUNDED_RECTANGULAR_CALLOUT;             break;
	case SHAPE_WedgeEllipseCallout:     eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_OVAL_CALLOUT;                            break;
	case SHAPE_CloudCallout:            eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_CLOUD_CALLOUT;                           break;
	case SHAPE_BorderCallout1:          eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_LINE_CALLOUT_1;                          break;
	case SHAPE_BorderCallout2:          eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_LINE_CALLOUT_2;                          break;
	case SHAPE_BorderCallout3:          eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_LINE_CALLOUT_3;                          break;
	case SHAPE_AccentCallout1:          eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_LINE_CALLOUT_1_ACCENT_BAR;               break;
	case SHAPE_AccentCallout2:          eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_LINE_CALLOUT_2_ACCENT_BAR;               break;
	case SHAPE_AccentCallout3:          eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_LINE_CALLOUT_3_ACCENT_BAR;               break;
	case SHAPE_Callout1:                eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_LINE_CALLOUT_1_NO_BORDER;                break;
	case SHAPE_Callout2:                eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_LINE_CALLOUT_2_NO_BORDER;                break;
	case SHAPE_Callout3:                eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_LINE_CALLOUT_3_NO_BORDER;                break;
	case SHAPE_AccentBorderCallout1:    eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_LINE_CALLOUT_1_BORDER_AND_ACCENT_BAR;    break;
	case SHAPE_AccentBorderCallout2:    eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_LINE_CALLOUT_2_BORDER_AND_ACCENT_BAR;    break;
	case SHAPE_AccentBorderCallout3:    eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_LINE_CALLOUT_3_BORDER_AND_ACCENT_BAR;    break;

		//900���� : ���� ����
	case SHAPE_ActionButtonBackPrevious:    eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_ACTION_BUTTON_BACK_OR_PREVIOUS;    break;
	case SHAPE_ActionButtonForwardNext:     eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_ACTION_BUTTON_FORWARD_OR_NEXT;     break;
	case SHAPE_ActionButtonBeginning:       eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_ACTION_BUTTON_BEGINNING;           break;
	case SHAPE_ActionButtonEnd:             eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_ACTION_BUTTON_END;                 break;
	case SHAPE_ActionButtonHome:            eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_ACTION_BUTTON_HOME;                break;
	case SHAPE_ActionButtonInformation:     eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_ACTION_BUTTON_INFORMATION;         break;
	case SHAPE_ActionButtonReturn:          eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_ACTION_BUTTON_RETURN;              break;
	case SHAPE_ActionButtonMovie:           eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_ACTION_BUTTON_MOVIE;               break;
	case SHAPE_ActionButtonDocument:        eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_ACTION_BUTTON_DOCUMENT;            break;
	case SHAPE_ActionButtonSound:           eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_ACTION_BUTTON_SOUND;               break;
	case SHAPE_ActionButtonHelp:            eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_ACTION_BUTTON_HELP;                break;
	case SHAPE_ActionButtonBlank:           eBrResStringID = BR_RESSTR_OBJECT_NAME_SHAPE_TYPE_ACTION_BUTTON_CUSTOM;              break;
	}

	return eBrResStringID;
}

void POSetCustomizeColorFilePath(const char* pSetPath)
{
#ifdef SUPPORT_THEME_CUSTOMIZE_COLOR
	BrCHAR* pPath = (BrCHAR*)pSetPath;
	if ( pPath == BrNULL )
		pPath = (BrCHAR*)BGetCustomizeColorPath();	

	if ( pPath != BrNULL )
	{
		g_pBInterfaceHandle->setCustomizeColorPath(pPath);
		AddExceptFileList(g_pBInterfaceHandle->getCustomizeColorPath());
	}
#endif//SUPPORT_THEME_CUSTOMIZE_COLOR
}

void* BrGetCustomizeColorPath()
{
#ifdef SUPPORT_THEME_CUSTOMIZE_COLOR
	return (void*)g_pBInterfaceHandle->getCustomizeColorPath();
#else
	return BrNULL;
#endif // SUPPORT_THEME_CUSTOMIZE_COLOR
}

void POSetSmartArtTemplateFilePath(const char* pSetPath)
{
#ifdef SMARTART_INSERT_EXTERNAL_FILE
	BrCHAR* pPath = (BrCHAR*)pSetPath;
	if ( pPath == BrNULL )
		pPath = (BrCHAR*)BGetSmartArtTemplatePath();	

	if ( pPath != BrNULL )
	{
		g_pBInterfaceHandle->setSmartArtTemplatePath(pPath);
		AddExceptFileList(g_pBInterfaceHandle->getSmartArtTemplatePath());
	}
#endif//SUPPORT_THEME_CUSTOMIZE_COLOR
}

void* BrGetSmartArtTemplatePath()
{
#ifdef SMARTART_INSERT_EXTERNAL_FILE
	return (void*)g_pBInterfaceHandle->getSmartArtTemplatePath();
#else
	return BrNULL;
#endif // SMARTART_INSERT_EXTERNAL_FILE
}

#ifdef B_DEBUG
// �޸� �����Ͱ� Memory Pool �������� Free�Ǿ����� ���θ� �˻��ϴ� �Լ�
BrBOOL BrIsFreeMemoryOfMemPool(BrLPVOID pTarget)
{
	// return BrFALSE : Memory Pool ������ Free�� �޸𸮰� �ƴ�
	// return BrTRUE : Memory Pool ������ ���� Free�� �޸𸮿� �ش��� => �ش� ������ ���� �� �����ϴٴ� �ǹ�(Dangling Pointer)
	
	BrBOOL bRet = CheckOnlyFreeListOfNormalMemBlock(pTarget);
	return bRet;
}
#endif //B_DEBUG

// word/slide/sheet�� ���� �⺻ ��Ʈ�� ���� 
char * BrGetDefaultResFontName(BrResFontName nStrID)
{
	char *pDefaultFontName = BGetDefaultResFontName(nStrID);
	if ( !pDefaultFontName || !strcmp(pDefaultFontName, "") )
	{
		return BrNULL;
	}
	else
	{
		switch(nStrID)
		{
		case eMemoFont:
			g_pBInterfaceHandle->setMemoFontFilePath(pDefaultFontName);
			return (char*)g_pBInterfaceHandle->getMemoFontFilePath();
		case eMathFont:
			g_pBInterfaceHandle->setMathFontFilePath(pDefaultFontName);
			return (char*)g_pBInterfaceHandle->getMathFontFilePath();
		}
	}
	
	return BrNULL;
}

//Andrew C. Lee
//license check 
BrBOOL PoCheckLicense()
{
	BrBOOL bRet = BrFALSE;
	BRCONTEXT;
	Brcontext.m_ViewerConfig.nOpenCTbe = 0;
	memset(Brcontext.m_ViewerConfig.aOpenCTae, 0, BRMAX_TIMESTR_LENGTH);
	BrUCHAR* pOpenCT = Brcontext.m_ViewerConfig.aOpenCTae;
#if defined(TARGET_NAME_LIST)
	if(checkTargetList())
	{
		RegOpenCT(pOpenCT);
		bRet = BrTRUE;
	}
#elif defined(USE_LICENSE_KEY)
	int nLen = BGetLicenseLength();
	nLen = BORA_LICENSE_INFO_LENGTH;
	if ( nLen > 0 )
	{				
		BrCHAR *aEncryptedHexStr = (BrCHAR*)BrCalloc(nLen+1, sizeof(BrCHAR));
		BGetLicense(aEncryptedHexStr, nLen + 1);
		if ( BrCheckLicense(aEncryptedHexStr) == LICENSE_VALID || BrCheckLicense(aEncryptedHexStr) == LICENSE_UPDATE)
		{
			RegOpenCT(pOpenCT);
			bRet = BrTRUE;
		}				
		BrFree(aEncryptedHexStr);
	}
#endif
//BTrace("%s(%d) %s bRet = %d pOpenCT[0x%x]", __FILE__, __LINE__, __FUNCTION__, bRet, pOpenCT);
	return bRet;
}

BR_LOCALE_TYPE PoGetLocale()
{
	BR_LOCALE_TYPE nLocale = BR_LOCALE_US_ENGLISH;
	if ( g_pBInterfaceHandle )
		nLocale = g_pBInterfaceHandle->getUserLocale();
	return nLocale;
}
BR_LOCALE_TYPE PoGetSysLocale() 
{
	BR_LOCALE_TYPE nLocale = BR_LOCALE_US_ENGLISH;
	if (g_pBInterfaceHandle)
		nLocale = g_pBInterfaceHandle->getSystemLocale();
	return nLocale;
}
