#include <basePCH.hpp>
#include "cmnFuncApi.h"
#include "cmnFunc.h"
#include "painter.h"
#include "shtFuncApi.h"
#include "brmcoreproc.h"
#include "read.h"
#include "bmvstream.h"
#include "ImageFilter.h"
#include "ImageLoader.h"
#include "PDFFilterApi.h"
#include "bwpWordFilterApi.h"
#include "bwpPtFilterApi.h"
#include "OdpFilterApi.h"
#include "shtFilterApi.h"
#include "bmvstruct.h"
#include "bmvstruct_sheet.h"
#include "bmvinterface.h"
#include "bmvinterface_tool.h"
#include "ScaleBitmap.h"
#include "prmemory_manager.h"
#include "zlib.h"
#if 1//def  PPT_EDITOR
#include "bwpFuncApi.h"
#include "bwpPPTFuncApi.h"
#endif
#include "brImageLoadingBase.h"
#include "Error/ErrorMacro.h"  // IF_SUCCESS_THAN_SET_ERR_ONLY

#define CHECK_TYPE_SAVE		1
#define CHECK_TYPE_THREAD	2

//#define CACHE_DEBUG

#ifndef NOT_USE_GLOBAL_VARIABLE
#include "../bwp/Conv2Filter.h"
extern CConv2XFilter *s_pConv2Filter;
#endif

#include "BrThemeBase.h"
#include "ThreadDefines_i.h"
#include "binterfacehandle.h"
#include "butil.h"


BrBOOL readMasterPage_Painter(Painter* pPainter)
{
	if ( IsEditorMode(pPainter)==EDITOR_WORD || IsEditorMode(pPainter)==EDITOR_PPT) 
		return BrFALSE;
	
	return BrTRUE;
}

void getSizeInfo_Painter(Painter* pPainter, int &nType, int &nWidth, int &nHeight, int &nResX, int &nResY)
{
	if (pPainter && pPainter->mode.m_nFilterMode == FILTER_IMAGE)
	{
		IMG_INFO lpInfo = {eImage_NONE,};
		BrBOOL bRet = BrFALSE;

		bRet = PrBitmap::getImageInfoFile(getDocFileName(), &lpInfo);
		if (bRet)
		{
			nType = lpInfo.type;
			nWidth = lpInfo.width;
			nHeight = lpInfo.height;
			nResX = lpInfo.nResX;
			nResY = lpInfo.nResY;
		}
	}
}

#ifdef IMPORT_PDF
BrBOOL readPage_Painter_PDF(Painter* pPainter, BrUINT32 &nPage, BrUINT* nParaNum, BRUI_PROC_CB pCallBack)
{
	BRTHREAD_ASSERT(nPage>0);

	g_BoraThreadAtom.m_nRetOpen = kPoProcessSucess;
	g_BoraThreadAtom.m_nErrorCode = kPoProcessSucess;

///////////////////////////////////////////////////////////////////////////////////////////////
// FILTER_DOCUMENT
///////////////////////////////////////////////////////////////////////////////////////////////
	
	{
		BrBOOL	bReadCacheOK=BrFALSE;

		if( pPainter->doc.m_pDoc )
			pPainter->doc.m_pDoc->PageReSize(0);

		BMVFilterInterfaceType FilterInterface;
		memset(&FilterInterface, 0, sizeof(BMVFilterInterfaceType));
		FilterInterface.nErrcode = kPoProcessSucess;
		FilterInterface.p_UICallBack = pCallBack;
		FilterInterface.pDoc = pPainter->doc.m_pDoc;
		FilterInterface.pPassword = pPainter->doc.m_szPassword;

		PO_THREAD_TRY_BLOCK {
			setDocType(BORA_DOCTYPE_PDF);	// [2016.7.27][dhlee1223] ���� Open ó�� ���߿� Close �̺�Ʈ ������(�����) Thread cancel�� ��� �߻��ϴ� �޸𸮸�(skia ����) ���� ����

			if (!poGetPagePtr_Pdf(getDocFileName(), nPage, nParaNum, &FilterInterface))
				goto READ_ERR_END;

			BRTHREAD_ASSERT(IsEditorMode(pPainter) || FilterInterface.pDoc );
			if(FilterInterface.pDoc==NULL )
				goto READ_ERR_END;

			pPainter->doc.m_pDoc = FilterInterface.pDoc;

			{
				// bookmark���� ���� ������ ���� ��ü ������ ������ ū ��� ������ �������� �е��� �Ѵ�.
				// �� ���Ϳ��� Ȯ�� �ʿ�
		                if (pPainter->doc.m_pDoc->m_DocProperty.m_nPageCount < (BrINT16)nPage)
					pPainter->doc.m_nCurPage = nPage = pPainter->doc.m_pDoc->m_DocProperty.m_nPageCount;
			}

			setTotalPages(pPainter->doc.m_pDoc->m_DocProperty.m_nPageCount);			
			setDocType(pPainter->doc.m_pDoc->m_DocProperty.m_nDocType);				

			//HandsPointer_SetSlideShowPage_PDF(1, pPainter->doc.m_pDoc->m_DocProperty.m_nPageCount);

		} PO_THREAD_CATCH_BLOCK { 
		} PO_THREAD_END
	}

	g_BoraThreadAtom.m_nRetOpen = g_BoraThreadAtom.m_nErrorCode;
	return BrTRUE;

READ_ERR_END:


	setDocType(BORA_DOCTYPE_BORA);
	if (g_BoraThreadAtom.m_nErrorCode == kPoProcessSucess)
	{
		ERR_TRACE(kPoErrInternal);
		g_BoraThreadAtom.m_nRetOpen = g_BoraThreadAtom.m_nErrorCode = kPoErrInternal;
	}
	else
		g_BoraThreadAtom.m_nRetOpen = g_BoraThreadAtom.m_nErrorCode;

	// ���� �������� ������ �� �ε��� �� ���¶�� terminate��Ŵ
	if ( getTotalPages() != 0 )
		BRTERMINATE(g_BoraThreadAtom.m_nErrorCode, "", PO_PUBLIC_CLASS);

	return BrFALSE;	
}
#endif //IMPORT_PDF

BMVPage* readPage_Painter(Painter* pPainter, BrUINT32 &nPage, BrUINT* nParaNum, BRUI_PROC_CB pCallBack, BrBOOL bRemoveFont, BrBOOL bReadOnlyOpen, BrBOOL bTempleteOpen, BrBOOL bFromReload)
{
	BRTHREAD_ASSERT(nPage>0);

	g_BoraThreadAtom.m_nRetOpen = kPoProcessSucess;
	g_BoraThreadAtom.m_nErrorCode = kPoProcessSucess;


	if(pPainter->doc.m_pPage)
		pPainter->doc.m_pPage->SetReflow(BrFALSE);
	{
		BrBOOL	bReadCacheOK=BrFALSE;

		{
			if( pPainter->doc.m_pPage )
				BrDELETE pPainter->doc.m_pPage;
			pPainter->doc.m_pPage = BrNULL;
		}

		if( pPainter->doc.m_pDoc )
			pPainter->doc.m_pDoc->PageReSize(0);
		BMVFilterInterfaceType FilterInterface;
		memset(&FilterInterface, 0, sizeof(BMVFilterInterfaceType));
		FilterInterface.nErrcode = kPoProcessSucess;
		FilterInterface.p_UICallBack = pCallBack;
		FilterInterface.pDoc = pPainter->doc.m_pDoc;

		PO_THREAD_TRY_BLOCK {
			if( !bReadCacheOK )
			{
				switch(pPainter->mode.m_nFilterMode)
				{
				case FILTER_WORD:
					{
					BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
	
						if (!poGetPagePtr_Bwp(pPainter, getDocFileName(), nPage, &FilterInterface))
							goto READ_ERR_END; 
BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);

						if( FilterInterface.pDoc && FilterInterface.pDoc->m_DocProperty.m_nPageCount < (INT16)nPage )
						{
							pPainter->doc.m_nCurPage = FilterInterface.pDoc->m_DocProperty.m_nPageCount;
						}
					}
					break;
#ifdef IMPORT_TXT
				case FILTER_TEXT:
					{
						if (!poGetPagePtr_Txt(getDocFileName(), nPage, &FilterInterface))
							goto READ_ERR_END;
					}
					break;
#endif  // IMPORT_TXT
#ifndef NEW_PPT_IMPORTER
#ifdef IMPORT_PPT
				case FILTER_PPT:
					{
#if 0
						FilterInterface.bRequestMasterPage = (pPainter->doc.m_nSizeMasterPages == 0);
#endif
						FilterInterface.bRequestMasterPage = TRUE;

						if (g_pBInterfaceHandle->getDocumentValidattionMode())
						{
							BString strSourcePath = CUtil::UTF8ToBString(getDocFileName());
							BrINT32 nDocumentContentType = CUtil::getFileSignatureFormat(strSourcePath);

							if (nDocumentContentType != BORA_DOCTYPE_PPT)
							{
								SET_ERROR((PoError)kPoErrFileContentsMismatched, "");
								return BrNULL;
							}
						}

						if (!poGetPagePtr_Ppt(pPainter, getDocFileName(), nPage, nPage, &FilterInterface))
						{	
							//[2012.04.12][�����][TID:5680] .ppt�� Ȯ��� ���� ����� pptx ���� ó��
							//[2011.08.10][�����][TID:1440]
#ifdef IMPORT_PPTX
							if(kPoProcessSucess == g_BoraThreadAtom.m_nErrorCode)
								goto PPTX_READ;
							else
#endif //IMPORT_PPTX
								goto READ_ERR_END;
						}
					}
					break;
#endif //IMPORT_PPT
#endif
#ifdef IMPORT_XLS
				case FILTER_SHEET:
					{
						
						if (getDocExt() == BORA_EXT_CSV && !pPainter->m_bPrintToImg && !bFromReload)	// [XPD-9409][2016.09.29] csv ������ ����Ʈ�� ���� ȣ��Ǵ� ��� �Ʒ� GetPagePtr_Xls() �� ������ �д´�.
						{
#ifdef IMPORT_CSV
							BrThemeDataMgr* pBrThemeDataMgr = gpPaint->pTheme->ThemeDataMgr();
							gpPaint->pTheme->readUserTheme(pBrThemeDataMgr->GetBrThemeDataCnt());
							if (!poGetPagePtr_CSV_TSV(getDocFileName(), &FilterInterface, false))
								goto READ_ERR_END;
#endif
						}
						else if ( getDocExt() == BORA_EXT_TXT && !pPainter->m_bPrintToImg && !bFromReload)
						{
#ifdef IMPORT_TXT_BY_SHEET
							if (!HandsPointer_GetPagePtr_TXT_BY_SHEET(getDocFileName(), &FilterInterface))
								goto READ_ERR_END;
#endif 
						}
#ifdef IMPORT_XML_SPREADSHEET
						else if(getDocExt() == BORA_EXT_XMLSPREADSHEET )
						{
							if( !pocheckXmlSpreadSheet(getDocFileName(), &FilterInterface) )
								goto READ_ERR_END;
							if (!poGetPagePtr_XML_SPREADSHEET(getDocFileName(), &FilterInterface))
								goto READ_ERR_END;
						}
#endif //IMPORT_XML_SPREADSHEET
#ifdef IMPORT_TSV
						else if(getDocExt() == BORA_EXT_TSV)
						{
							BrThemeDataMgr* pBrThemeDataMgr = gpPaint->pTheme->ThemeDataMgr();
							gpPaint->pTheme->readUserTheme(pBrThemeDataMgr->GetBrThemeDataCnt());
							if (!poGetPagePtr_CSV_TSV(getDocFileName(), &FilterInterface, true))
								goto READ_ERR_END;
						}
#endif //IMPORT_TSV
						else {
							if (!poGetPagePtr_Xls(getDocFileName(), nPage, &FilterInterface, false))
							{
								//[kjins1201] ���� ���� �˻�ÿ��� xls�� �õ����� �ʰ� ���� ó��
								if(FilterInterface.nErrcode == kPoErrCorruptFile && !g_pBInterfaceHandle->getDocumentValidattionMode() )
								{
									// [4/12/2014 hyunwook]									
									setFilterMode(FILTER_SHEET_X);
									setDocExt(BORA_EXT_XLSX);
									//[WPD-2603] [kjins1201] xlsx�� ���� �õ� �� Error �� �ʱ�ȭ ó�� �߰�.
									FilterInterface.nErrcode = g_BoraThreadAtom.m_nErrorCode = kPoProcessSucess;
									goto XLSX_READ; 
								}
#ifdef IMPORT_XML_SPREADSHEET
								//Ȯ���ڰ� �޶� ������ �о��µ� xml�� �Ǵܵ� ���
								else if((g_BoraThreadAtom.m_nLoadType & BORA_LOAD_FORCED ) == BORA_LOAD_FORCED && FilterInterface.nErrcode == kPoErrEventUnsupportedTypeXml)
								{
									g_BoraThreadAtom.m_nErrorCode = kPoProcessSucess;
									FilterInterface.nErrcode = kPoProcessSucess;
									if( !pocheckXmlSpreadSheet(getDocFileName(), &FilterInterface) )
										goto READ_ERR_END;
									if (!poGetPagePtr_XML_SPREADSHEET(getDocFileName(), &FilterInterface))
										goto READ_ERR_END;
									setDocExt(BORA_EXT_XMLSPREADSHEET);
								}
#endif //IMPORT_XML_SPREADSHEET
								else
									goto READ_ERR_END;	//[2011.08.10][�̻�][TID:1529]
							}
						}
					}
					break;
#endif //IMPORT_XLS
#if defined(IMPORT_PDF)
				case FILTER_PDF:
					{
						FilterInterface.pPassword = pPainter->doc.m_szPassword;
#ifdef USE_EVENT_MANAGER
						FilterInterface.GetImgCB = ProcessGetSnapShotImageCB;
#endif
#if defined(IMPORT_PDF)
						if (!poGetPagePtr_Pdf(getDocFileName(), nPage, nParaNum, &FilterInterface))
#endif // IMPORT_PDF
							goto READ_ERR_END;
					}
					break;
#endif //

#ifdef		IMPORT_XLSX
				case	FILTER_SHEET_X : 
					{
XLSX_READ: //[2011.08.10][�̻�][TID:1529]
						//�� �κк��� XlsX ������ �ٲ�� ��. // csp168 ���� üũ ����
						if (!poGetPagePtr_XlsX(getDocFileName(), nPage, &FilterInterface))
						{
							pocheckXmlOrHtml(getDocFileName(), &FilterInterface);
							goto READ_ERR_END;
						}
					}
					break;
#endif	// IMPORT_XLSX

#ifndef NEW_PPTX_IMPORTER
#ifdef		IMPORT_PPTX
				case	FILTER_PPT_X : 
					{
						//[2012.04.12][�����][TID:5680] .ppt�� Ȯ��� ���� ����� pptx ���� ó��
						//[2011.08.10][�����][TID:1440]
PPTX_READ:
#ifdef IMPORT_ODP
						if(getDocExt() == BORA_EXT_ODP)
							goto ODP_READ;
#endif
						FilterInterface.bRequestMasterPage = TRUE;
						FilterInterface.bRemoveFont = bRemoveFont;
						FilterInterface.bReadOnlyOpen = bReadOnlyOpen;
						FilterInterface.bTempleteOpen = bTempleteOpen;

						if (g_pBInterfaceHandle->getDocumentValidattionMode())
						{
							BString strSourcePath = CUtil::UTF8ToBString(getDocFileName());
							BrINT32 nDocumentContentType = CUtil::getFileSignatureFormat(strSourcePath);

							if (nDocumentContentType != BORA_DOCTYPE_PPTX)
							{
								SET_ERROR((PoError)kPoErrFileContentsMismatched, "");
								return BrNULL;
							}
						}

						if (!poGetPagePtr_PptX(pPainter, getDocFileName(), nPage, nPage, &FilterInterface))
							goto READ_ERR_END;
					}
					break;
#endif	// IMPORT_PPTX
#endif

#ifdef 		BWP_IMG_VIEWER
				case FILTER_IMAGE:
					{
						if (!poImageViewePtr_Bwp(pPainter, &FilterInterface))
							goto READ_ERR_END;
					}
					break;
#endif

#ifdef IMPORT_ODS
				case FILTER_ODS:
					{
						if (!HandsPointer_GetPagePtr_ods(getDocFileName(), nPage, &FilterInterface))
							goto READ_ERR_END;
					}
					break;
#endif	// IMPORT_ODS

#ifdef IMPORT_ODP
				case FILTER_ODP:
					{
ODP_READ:
						if (!HandsPointer_GetPagePtr_Odp(pPainter, getDocFileName(), nPage, nPage, &FilterInterface))
							goto READ_ERR_END;
					}
					break;
#endif	// IMPORT_ODP

				default:
					SET_ERROR((PoError)kPoErrUnsupportedType, "");
					break;
				}
#ifdef IMPORT_PDF
				BRTHREAD_ASSERT(IsEditorMode(pPainter) || (FilterInterface.pDoc && (pPainter->mode.m_nFilterMode == FILTER_PDF || FilterInterface.pPage)));
				if(FilterInterface.pDoc==NULL || (pPainter->mode.m_nFilterMode != FILTER_PDF && FilterInterface.pPage==NULL))
#else //IMPORT_PDF
				BRTHREAD_ASSERT(IsEditorMode(pPainter) || (FilterInterface.pDoc && FilterInterface.pPage));
				if(FilterInterface.pDoc==NULL || FilterInterface.pPage==NULL)
#endif //IMPORT_PDF
					goto READ_ERR_END;

				pPainter->doc.m_pDoc = FilterInterface.pDoc;
				if( FilterInterface.bRequestMasterPage )
					addMasterPage_Painter(pPainter, FilterInterface.pMasterPage);
				pPainter->doc.m_pPage = FilterInterface.pPage;
			}

			{
				// bookmark���� ���� ������ ���� ��ü ������ ������ ū ��� ������ �������� �е��� �Ѵ�.
				// �� ���Ϳ��� Ȯ�� �ʿ�
		                if (pPainter->doc.m_pDoc->m_DocProperty.m_nPageCount < (BrINT16)nPage)
					pPainter->doc.m_nCurPage = nPage = pPainter->doc.m_pDoc->m_DocProperty.m_nPageCount;
			}

//			pPainter->doc.m_pDoc->m_DocProperty.m_nPageCount = BrMIN(pPainter->doc.m_pDoc->m_DocProperty.m_nPageCount, PAGE_LOAD_LIMITS);
			setTotalPages(pPainter->doc.m_pDoc->m_DocProperty.m_nPageCount);			
			setDocType(pPainter->doc.m_pDoc->m_DocProperty.m_nDocType);	
			addDefaultFont_Painter(pPainter);

			if( IsViewerHtmlType(pPainter) )
			{ //html ������ ��� Sheet ���·� �׸��� ���� Sheet ������Ʈ�� �߰��� �ش�.
				if( !pPainter->doc.m_pPage->GetSheet() )
				{
					BMVSheet* pSheet = BrNEW BMVSheet();
					pPainter->doc.m_pPage->m_PageProperty.m_nHeight = pPainter->doc.m_pPage->m_PageProperty.m_nHeight/255;
					pPainter->doc.m_pPage->m_PageProperty.m_nWidth = pPainter->doc.m_pPage->m_PageProperty.m_nWidth/255;
					pPainter->doc.m_pPage->DataReSize(pPainter->doc.m_pPage->GetDataSize()+1);
					pPainter->doc.m_pPage->m_DataArray.at(pPainter->doc.m_pPage->GetDataSize()-1)=pSheet;
					pPainter->doc.m_pPage->SetSheetIndex();
				}
			}

			if (IsSheetType(pPainter))
			{
				pPainter->offset.m_nRowCount = pPainter->doc.m_pPage->m_PageProperty.m_nHeight;
				pPainter->offset.m_nColCount = pPainter->doc.m_pPage->m_PageProperty.m_nWidth;
			}

			pocheckBoundarySheet_Painter(pPainter);
			//initScroll_Painter(pPainter);
			
		} PO_THREAD_CATCH_BLOCK { 		

			BR_SAFE_DELETE(pPainter->doc.m_pPage);
			FilterInterface.pPage = BrNULL;
		} PO_THREAD_END
	}

	g_BoraThreadAtom.m_nRetOpen = g_BoraThreadAtom.m_nErrorCode;
	return pPainter->doc.m_pPage;

READ_ERR_END:

	if (kPoProcessSucess == g_BoraThreadAtom.m_nErrorCode) {
		IF_SUCCESS_THAN_SET_ERR_ONLY(kPoErrInternal,
		                             ErrMsg("pPainter->mode.m_nFilterMode=%d", pPainter->mode.m_nFilterMode));
		g_BoraThreadAtom.m_nErrorCode = kPoErrInternal;
	}
	g_BoraThreadAtom.m_nRetOpen = g_BoraThreadAtom.m_nErrorCode;

	// ���� �������� ������ �� �ε��� �� ���¶�� terminate��Ŵ
	if ( getTotalPages() != 0 )
		BRTERMINATE(g_BoraThreadAtom.m_nErrorCode, "", PO_PUBLIC_CLASS);

	return BrNULL;
}


#if 0
BMVPage* readCachePage_Painter(Painter* pPainter, BrUINT32 nPage)
{
#ifdef PAGE_CACHING_OLD
	if(pPainter->mode.m_nFilterMode == FILTER_NONE || pPainter->mode.m_nFilterMode == FILTER_IMAGE)
		return NULL;

	BMVFilterInterfaceType FilterInterface;
	memset(&FilterInterface, 0, sizeof(BMVFilterInterfaceType));

	switch(pPainter->mode.m_nFilterMode)
	{
	case FILTER_WORD:
	// case FILTER_TEXT:
		if(!poGetPagePtr_Bwp(pPainter, getDocFileName(), nPage, &FilterInterface))
			return BrNULL;
		break;

#ifdef IMPORT_TXT
	case FILTER_TEXT:
		if(!poGetPagePtr_Txt(getDocFileName(), nPage, &FilterInterface))
			return BrNULL;
		break;
#endif  // IMPORT_TXT

	case FILTER_PPT:
		FilterInterface.bRequestMasterPage = TRUE;	
		if(!poGetPagePtr_Ppt(pPainter, getDocFileName(), nPage, &FilterInterface))
			return BrNULL;
		break;

	case FILTER_SHEET:
		if(!poGetPagePtr_Xls(getDocFileName(), nPage, &FilterInterface))
			return BrNULL;
		break;
	case FILTER_PDF:
		FilterInterface.pPassword = pPainter->doc.m_szPassword;
		if (!poGetPagePtr_Pdf(getDocFileName(), nPage, &FilterInterface))
			return BrNULL;
		break;
	default:
		break;
	}

	if(FilterInterface.pDoc==NULL || FilterInterface.pPage==NULL) 
		return BrNULL;

	//���� ������ ĳ��
	OnePageUnit* pPageUnit = (OnePageUnit*)BrMalloc(sizeof(OnePageUnit));
	pPainter->doc.m_pOnePageUnitArray[nPage-1] = pPageUnit;
	pPageUnit->m_pDoc = FilterInterface.pDoc;
	pPageUnit->m_pPage = FilterInterface.pPage;
	pPageUnit->m_pMasterPage = FilterInterface.pMasterPage;
	return FilterInterface.pPage;
#else
	return BrNULL;
#endif
}
#endif

BrBOOL readCachePage_Painter(Painter* pPainter, BrUINT32 nPage, BrBOOL bOnlyPageImageCache)
{
	BrBOOL bRet = BrFALSE;

	THREAD_TRACE(("PageCaching... %d page\n", nPage));

BrUINT32 nSlideNum = nPage;
#ifdef PPT_EDITOR
    BrUINT8 nEditorMode = IsEditorMode(pPainter);
    if (EDITOR_PPT == nEditorMode)
    {
        if (bOnlyPageImageCache)
        {
            if( CheckMemoryLimit() )
		        return bRet;
                
            BrUINT32 nStart, nEnd;
            nStart = (pPainter->doc.m_nCurPage < 6) ? 1 : pPainter->doc.m_nCurPage - 5; 
            nEnd = nStart + 10;

            if (nStart <= nPage && nPage <= nEnd)
                return pomakeImageCacheOfBwpPage(pPainter, nPage);
            else
                return BrTRUE;
        }
        else
            nSlideNum = poGetReadSlideNumber_PPTEditor(nPage);
    }
#endif //PPT_EDITOR
		
	{
	BRCONTEXT;
    if(pPainter->mode.m_nFilterMode == FILTER_NONE || 
		(!Brcontext.m_GeneralValue.bDualDisplay && (pPainter->mode.m_nFilterMode == FILTER_IMAGE && (getTotalPages() == 1) )))
		return bRet;
	}

	if( (pPainter->mode.m_nFilterMode & 0x0FFF)==FILTER_SHEET )
	{
		if( CheckExcelMemoryLimit(BrTRUE) )
		{
//			g_BoraThreadAtom.m_nRetOpen = kPoErrMemory;
//			g_BoraThreadAtom.m_nErrorCode = kPoErrMemory;
//			ERR_TRACE(kPoErrMemory);
			return bRet;
		}

#ifdef __2008_SHEET_EDITOR__ //sh-shin. __2008_SHEET_EDITOR_CHECK_AGAIN__
		if (IsEditorMode(pPainter))
			return bRet;
#endif //__2008_SHEET_EDITOR__
	}

	if (g_BoraThreadAtom.m_bPageThumbnailMode == BR_THUMBNAIL_EXTERNAL_DIRECT_MODE && 
		nPage > getTotalPages() )
		return bRet;

	if (g_BoraThreadAtom.m_bPageThumbnailMode != BR_THUMBNAIL_EXTERNAL_DIRECT_MODE )
		if( (pPainter->mode.m_nFilterMode & 0x0FFF)==FILTER_WORD )
			if( !poIsFinishedLoading() )
				return bRet;

	//���� �������� ������Ʈ�� ���� �޸𸮸� ���� �����ϰ� ������ 
	//ĳ�� �� �͹̳���Ʈ �ǰų� ����� ���� ���ϴ� ��찡 ����. Ư�� PDF. 2007.09.14 by sunklee
	if( CheckMemoryLimit() )
		return bRet;

	BMVFilterInterfaceType FilterInterface;
	memset(&FilterInterface, 0, sizeof(BMVFilterInterfaceType));	
	FilterInterface.pDoc = pPainter->doc.m_pDoc;
	FilterInterface.nErrcode = kPoProcessSucess;

	g_BoraThreadAtom.m_nLoadStatus = LOAD_STATUS_PROGRESS;
	g_BoraThreadAtom.m_nRetOpen = kPoProcessSucess;
	g_BoraThreadAtom.m_nErrorCode = kPoProcessSucess;

	pPainter->m_CachingPageCount = nPage;
	PO_THREAD_TRY_BLOCK {
		switch(pPainter->mode.m_nFilterMode)
		{
		case FILTER_WORD:
			if(!poGetPagePtr_Bwp(pPainter, getDocFileName(), nPage, &FilterInterface))
				goto CACHE_END;
			break;

	#ifdef IMPORT_TXT
		case FILTER_TEXT:
			if(!poGetPagePtr_Txt(getDocFileName(), nPage, &FilterInterface))
				goto CACHE_END;
			break;
	#endif  // IMPORT_TXT

	#ifdef IMPORT_PPT
		case FILTER_PPT:
			FilterInterface.bRequestMasterPage = TRUE;
			if(!poGetPagePtr_Ppt(pPainter, getDocFileName(), nSlideNum, nPage, &FilterInterface))
				goto CACHE_END;
			break;
	#endif

	#ifdef	IMPORT_DOCX
		case FILTER_WORD_X:	//������� ���� (FILTER_WORD�� ���)
			{
				//�� �κк��� DocX ������ �ٲ�� ��.
				//if (!poGetPagePtr_PptX(getDocFileName(), nPage, &FilterInterface))
					goto CACHE_END;
			}
			break;
	#endif	// IMPORT_DOCX

	#ifdef	IMPORT_XLSX
		case FILTER_SHEET_X : 
			{
				//�� �κк��� XlsX ������ �ٲ�� ��.
				if (!poGetPagePtr_XlsX(getDocFileName(), nPage, &FilterInterface))
					goto CACHE_END;
			}
			break;
	#endif	// IMPORT_XLSX

	#ifdef	IMPORT_PPTX
		case FILTER_PPT_X : 
			{
	#ifdef IMPORT_ODP
				if(getDocExt() == BORA_EXT_ODP) 
				{
					if (!HandsPointer_GetPagePtr_Odp(pPainter, getDocFileName(), nPage, nPage, &FilterInterface))
						goto CACHE_END;
				}
				else
	#endif
				{
					FilterInterface.bRequestMasterPage = TRUE;
					if (!poGetPagePtr_PptX(pPainter, getDocFileName(), nSlideNum, nPage, &FilterInterface))
						goto CACHE_END;
				}
			}
			break;
	#endif	// IMPORT_PPTX

	#ifdef IMPORT_XLS
		case FILTER_SHEET:
			if(!poGetPagePtr_Xls(getDocFileName(), nPage, &FilterInterface, false))
				goto CACHE_END;
			break;
	#endif
		default:
//			g_BoraThreadAtom.m_nRetOpen = kPoErrUnsupportedType;
//			g_BoraThreadAtom.m_nErrorCode = kPoErrUnsupportedType;
//			ERR_TRACE(kPoErrUnsupportedType);
			break;
		}

//		FilterInterface.pDoc->m_DocProperty.m_nPageCount = BrMIN(FilterInterface.pDoc->m_DocProperty.m_nPageCount, PAGE_LOAD_LIMITS);
#ifdef PPT_EDITOR
		if((EDITOR_PPT != nEditorMode) && (FilterInterface.pDoc==NULL || FilterInterface.pPage==NULL))
#else
        if(FilterInterface.pDoc==NULL || FilterInterface.pPage==NULL)
#endif
		{
			g_BoraThreadAtom.m_nLoadStatus = LOAD_STATUS_END;
//			g_BoraThreadAtom.m_nRetOpen = kPoErrUnsupportedType;
//			g_BoraThreadAtom.m_nErrorCode = kPoErrUnsupportedType;
//			ERR_TRACE(kPoErrUnsupportedType);
			return bRet;
		}

		if( IsViewerHtmlType(pPainter) )
		{ //html ������ ��� Sheet ���·� �׸��� ���� Sheet ������Ʈ�� �߰��� �ش�.
			if( !FilterInterface.pPage->GetSheet() )
			{
				BMVSheet* pSheet = BrNEW BMVSheet();
				FilterInterface.pPage->m_PageProperty.m_nHeight = FilterInterface.pPage->m_PageProperty.m_nHeight/255;
				FilterInterface.pPage->m_PageProperty.m_nWidth = FilterInterface.pPage->m_PageProperty.m_nWidth/255;
				FilterInterface.pPage->DataReSize(FilterInterface.pPage->GetDataSize()+1);
				FilterInterface.pPage->m_DataArray.at(FilterInterface.pPage->GetDataSize()-1)=pSheet;
				FilterInterface.pPage->SetSheetIndex();
			}
		}

#ifdef PPT_EDITOR
        if (EDITOR_PPT == nEditorMode)
        {
            pPainter->m_CachingPageCount = 0;
            
            BrUINT32 nStart, nEnd;
            nStart = (pPainter->doc.m_nCurPage < 6) ? 1 : pPainter->doc.m_nCurPage - 5; 
            nEnd = nStart + 10;

            if (nStart <= nPage && nPage <= nEnd)
                bRet =  pomakeImageCacheOfBwpPage(pPainter, nPage);
            else
                bRet = BrTRUE;
        }
        else
#endif
        {

		    if( FilterInterface.bRequestMasterPage )
			    addMasterPage_Painter(pPainter, FilterInterface.pMasterPage);

		    pPainter->m_CachingPageCount = 0;

        }

		if (FilterInterface.pPage)
            BrDELETE FilterInterface.pPage;

		g_BoraThreadAtom.m_nLoadStatus = LOAD_STATUS_END;
		g_BoraThreadAtom.m_nRetOpen = kPoProcessSucess;
		g_BoraThreadAtom.m_nErrorCode = kPoProcessSucess;
		return bRet;

CACHE_END:
		g_BoraThreadAtom.m_nLoadStatus = LOAD_STATUS_END;
		g_BoraThreadAtom.m_nRetOpen = kPoProcessSucess;
		g_BoraThreadAtom.m_nErrorCode = kPoProcessSucess;

		// ���� �������� ������ �� �ε��� �� ���¶�� terminate��Ŵ
		BRTERMINATE(kPoErrInternal, "", PO_PUBLIC_CLASS);

		return bRet;
	} PO_THREAD_CATCH_BLOCK { 

		g_BoraThreadAtom.m_nLoadStatus = LOAD_STATUS_END;
		g_BoraThreadAtom.m_nRetOpen = kPoProcessSucess;
		g_BoraThreadAtom.m_nErrorCode = kPoProcessSucess;

		pPainter->m_CachingPageCount = 0;
		BrDELETE FilterInterface.pPage;
	} PO_THREAD_END

	return bRet;
}


BrBOOL GetScaledThumbnail(Painter* pPainter, PrBitmap& bm)
{
	BRCONTEXT;
	//scale thumbnail
#if defined(DYNAMIC_MEMORY_BLOCK) && defined(HAVE_LARGEST_THUMBNAIL)
	BrDWORD screensize;

#ifdef SINGLE_SCREEN_BUFFER
	if (Brcontext.m_GeneralValue.nScreenBufferType == SCREEN_BUF_ONE)
		screensize = pPainter->pageImg.m_PageBitmap.getDibSize();
	else
#endif //SINGLE_SCREEN_BUFFER
		screensize = pPainter->pageImg.m_ScreenBitmap.getDibSize();

	BRTHREAD_ASSERT(screensize);// Coverity CID(17583)
	BrUINT64 avail_size = GetCurrentAvailableMemory();
	BrDOUBLE fFactor = (BrDOUBLE)avail_size * 0.35f / screensize;
	BrDOUBLE cScale_Fact = BrMIN(1.0f, fFactor);
#else //DYNAMIC_MEMORY_BLOCK
	const BrDOUBLE cScale_Fact = (BrDOUBLE)Brcontext.m_GeneralValue.nThumbnailPercent/100;
#endif //DYNAMIC_MEMORY_BLOCK

	PrBitmap* pScalBitmap = BrNULL;

	BrINT nThumbScale = getPageZoomScale_Painter(pPainter, SETZOOM_WHOLEPAGE); // scale_itk
	BrINT32 nOrgWidth = (BrINT32)getDocZoomWidth(pPainter, nThumbScale);
	BrINT32 nOrgHeight = (BrINT32)getDocZoomHeight(pPainter, nThumbScale);

	BrINT nWidth, nHeight, nThumbW = 0, nThumbH = 0;
	bm.getSize(&nThumbW, &nThumbH);

	{
		
#if defined(DYNAMIC_MEMORY_BLOCK)

#if defined(HAVE_LARGEST_THUMBNAIL)
		cScale_Fact = 1.0f;
		enum { MAXIMUM = 3000 };
#else
		enum { MAXIMUM = 320 };
#endif

#else
		enum { MAXIMUM = 110 };
#endif

		nWidth = BrMINMAX(10, nThumbW, (BrINT32)((BrDOUBLE)nOrgWidth * cScale_Fact) );
		nHeight = BrMINMAX(10, nThumbH, (BrINT32)((BrDOUBLE)nOrgHeight * cScale_Fact) );

		if(nWidth > MAXIMUM || nHeight > MAXIMUM)
		{
			if(nWidth >= nHeight)
			{
				nHeight	= BrMulDiv(nHeight, MAXIMUM, nWidth);
				nWidth	= MAXIMUM;
			}
			else
			{
				nWidth	= BrMulDiv(nWidth, MAXIMUM, nHeight);
				nHeight	= MAXIMUM;
			}
		}
	}

	BrBOOL bBlur = BrFALSE;
	do 
	{
		if(&bm != pScalBitmap)
			BR_SAFE_DELETE(pScalBitmap);

		if(nWidth == nThumbW && nHeight == nThumbH)
			pScalBitmap = &bm;
		else
			pScalBitmap = bm.scaleEx(nWidth, nHeight);			
#if defined(DYNAMIC_MEMORY_BLOCK)
		if (pScalBitmap && Brcontext.m_GeneralValue.bBluringPagemap && g_BoraThreadAtom.BackupVariable.m_bMakeThumbnailImage)
			bBlur = pScalBitmap->blur(BrMAX(60, (BrINT32)(((BrFLOAT)nWidth/(BrFLOAT)nOrgWidth) * 70)));
		else
			bBlur = (pScalBitmap ? BrTRUE : BrFALSE);
#else
		bBlur = (pScalBitmap ? BrTRUE : BrFALSE);
#endif
		nWidth >>= 1;
		nHeight >>= 1;
	} while(!bBlur && nWidth && nHeight);

	if(&bm != pScalBitmap && pScalBitmap)	
	{
		if(bBlur)
			bm.setDib(pScalBitmap, BrFALSE);
		BrDELETE pScalBitmap;
	}
	
	return bBlur;
}