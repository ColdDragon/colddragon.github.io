﻿#include <OfficePreComp.hpp>

#if defined(USE_FREETYPE2_ENGINE)

#include "bmvinterface.h"
#include "bmvinterface_tool.h"
#include "BoraFont.h"
#include "font2Freetype.h"

#include FT_LCD_FILTER_H
#include FT_SYNTHESIS_H
#include FT_TRUETYPE_IDS_H
#include FT_TRUETYPE_TAGS_H
#include FT_TRUETYPE_DRIVER_H
#include FT_GASP_H
#include FT_FONT_FORMATS_H
#include <freetype/internal/tttypes.h>
#include <freetype/internal/ftdebug.h>
#include "../src/truetype/ttobjs.h"

#include <libeot.h>

#include "BFile.h"
#include "butil.h"
#include "FontTableList.h"
#include "brlanguage.h"
#include "BrLocaleLanguageDef.h"
#include "binterfacehandle.h"
#include "BoraFont_Config.h"
#include "ZeroCharWidthList.h"
#include "brmcoreimp.h"
#include "brmcoreproc.h"
#include "prpublicmem.h"

//#define SUPPORT_ADD_FONT
#define FONT_TEST_CODE_ENABLE	0
#define FONT_HEIGHT_TEST_CODE_ENABLE	0

#if defined(__APPLE__) && defined(MAC_POLARISOFFICE)	// 일단 MAC에서만 사용
#define MAC_FONT_SUPPORT
#elif FONT_TEST_CODE_ENABLE	//Test용
#define MAC_FONT_SUPPORT
#endif

const int BoraFont::m_nFontNameLength = (MAX_FONT_LENGTH+1);
static pthread_mutex_t pFontMutex;
static BoraFontShared* g_pBoraFontShared = BrNULL;

BrBYTE* BoraFont::m_pFontTableData = BrNULL;
BrCHAR* BoraFont::m_mFontName = BrNULL;
BrWORD* BoraFont::m_wFontName = BrNULL;
BSysExArray<BrCHAR*>* BoraFont::m_ExceptFileList = BrNULL;

BrINT16	arrBaseFontTable[FTABLE_SIZE] = { 0, };
BrINT16	arrBaseBoldFontTable[FTABLE_SIZE] = { 0, };

static inline int unhex(BrCHAR a)
{
	if (a >= 'A' && a <= 'F') return a - 'A' + 0xA;
	if (a >= 'a' && a <= 'f') return a - 'a' + 0xA;
	if (a >= '0' && a <= '9') return a - '0';
	return 0;
}


BoraFont::BoraFont()
	: s_pBoraFontShared(g_pBoraFontShared ? g_pBoraFontShared : (g_pBoraFontShared = new BoraFontShared()))
{
	if ( s_pBoraFontShared->count==0 )
	{
		pthread_mutex_init(&pFontMutex, NULL);
	}
	s_pBoraFontShared->ref();
	m_pPublicMem = new PrPublicMem();
	m_pMEMIDHash = new Font_MEMIDHash(m_pPublicMem);
	m_pMEMIDWidthHash = new Font_MEMIDWidthHash(m_pPublicMem);
	m_pBoraMultiLang = new BoraMultiLang(m_pPublicMem);

	m_pLocaleIndexHash = BrNULL;
	m_face_count = 0;
	m_Face = (PO_Face*)PoSysCalloc(TTF_FONT_COUNT, sizeof(PO_Face));
	
	for (int i = 0; i < TTF_FONT_COUNT; i++)
	{
		m_pFontFiles[i].nType = FONTTYPE_FILE;
		m_pFontFiles[i].nSize = 0;
		m_pFontFiles[i].pFontData = BrNULL;
	}

	m_charFontInfoList = (CharFontInfo**)PoSysCalloc(TTF_FONT_COUNT, sizeof(CharFontInfo*));
	m_ncharFontInfoListCount = 0;
	m_ncharFontInfoListLevel = 1;

	m_nDefOriginalFontFlag = -1;	
	m_nFontFlag = eBaseFont;
	m_bRealFont = BrFALSE;
	
	m_first_font_address = BrNULL;
	m_first_font_size = 0;

	m_nOldIndex = -1;
	m_bExistFont = BrFALSE;

	m_pFontName = (BrUSHORT*)PoSysCalloc(m_nFontNameLength, sizeof(BrUSHORT));
	m_pPrevFontName = (BrUSHORT*)PoSysCalloc(m_nFontNameLength, sizeof(BrUSHORT));

	m_nFontNameIndexTemp = m_nCurFontNameIndex = -1;

	m_nEFIndex = -1;
	m_nSymbolIndex = -1;
	m_nWindingIndex = -1;
	m_nWinding2Index = -1;
	m_nWinding3Index = -1;
	m_nWebdingsIndex = -1;
	m_nMathIndex = -1;
	m_nHWPMathIndex = -1;
	m_nHangulIndex = -1;
	m_pDefultFontFilePath = (BrCHAR*)PoSysCalloc(BORA_FULLPATH_LENGTH, sizeof(BrCHAR));
	m_nBaseIndex = 0;
		
	m_nFontFaceGap = 0;

	m_nBaseMapFontIndex = -1;

	m_LocaleFontFace = BrNULL;
	m_nLocaleFontIndex = 0;

	m_nAppendFontCnt = m_nPDFDrawFontIndex = 0;
	m_nLoadedPurchaseFontCnt = 0;
	for(int i = 0; i < ePurchaseFontMax; i++)
		m_bLoadedPurchaseFont[i] = BrFALSE;

	for(int i = 0; i < m_aNotExistFontName.size(); i++)
	{
		PoSysFree(m_aNotExistFontName.at(i));
	}
	m_aNotExistFontName.removeAll();

	for(int i = 0; i < m_aTypeFaceList.size(); i++)
	{
		LPBrTypefaceStruct pFamily = m_aTypeFaceList.at(i);
		for(int j=0 ; j < eFontStyleIndexMax; j++)
		{
			if(pFamily->nFontIndices[j])
			{
				LPBrFontStyleIdxNode node = pFamily->nFontIndices[j];
				LPBrFontStyleIdxNode nextNode = BrNULL;
				while(node)
				{
					nextNode = node->pNext;
					PoSysFree(node);
					node = nextNode;
				}
			}
		}
		PoSysFree(pFamily);
	}
	m_aTypeFaceList.removeAll();

	releaseFontFileList();
	m_nRuntimeLoadFontCount = 0;

	for(int i = 0; i < m_RuntimeLoadFont.size(); i++)
	{
		if(m_RuntimeLoadFont.at(i)->bHasHJCTTable)
			PoSysFree(m_RuntimeLoadFont.at(i)->pHJCTData);
		PoSysFree(m_RuntimeLoadFont.at(i));
	}
	m_RuntimeLoadFont.removeAll();
	m_bSetPrimaryFont = BrFALSE;

	m_pFontNameList = new BFontNameList(m_pPublicMem);

	int hjctTableSize = m_aFontHjctTable.size();
	for(int i = 0; i < hjctTableSize; i++)
	{
		BR_SAFE_DELETE(m_aFontHjctTable.at(i)->pHjct);
		PoSysFree(m_aFontHjctTable.at(i));
	}
	m_aFontHjctTable.removeAll();

	for (int i = 0; i < m_aLocaleDefaultFontName.size(); i++)
	{
		for(int j = 0; j < m_aLocaleDefaultFontName.at(i)->fontNameCnt; j++)
		{
			if (m_aLocaleDefaultFontName.at(i)->defaultFontName[j])
				PoSysFree(m_aLocaleDefaultFontName.at(i)->defaultFontName[j]);
		}

		PoSysFree(m_aLocaleDefaultFontName.at(i));
	}
	m_aLocaleDefaultFontName.removeAll();

	m_pFTLibrary = BrNULL;

	m_InternalFontNameList = new BFontNameList(m_pPublicMem);

	for(int i = 0; i < m_aLoadedPanoseFont.size(); i++)
	{
		PoSysFree(m_aLoadedPanoseFont.at(i));
	}
	m_aLoadedPanoseFont.removeAll(); 

	for(int i = 0; i < m_aFontNamePanoseInfo.size(); i++)
	{
		PoSysFree(m_aFontNamePanoseInfo.at(i));
	}
	m_aFontNamePanoseInfo.removeAll();
	m_bFindAltFont = false;
	m_pSystemMathFontName = BrNULL;

	m_aFontFace = BrNULL;

	m_EFIndex = eEF_NoneFont;
	m_bTimesFullset = BrFALSE;

	m_pBidiMemBlock = BrNULL;
	m_nBidiMemBlockLen = 0;

	for (int i = 0; i < eEF_MaxFontType; i++)
	{
		m_EFFace[i] = BrNULL;
	}

	m_poFullSetFont.pBold = BrNULL;
	m_poFullSetFont.pItalic = BrNULL;
	m_poFullSetFont.pBoldItalic = BrNULL;
	m_poFullSetFont.pFullSet = BrNULL;


#ifdef USE_EMFAMILY_HEADER_FONT
	for (int i = 0; i < eEF_MaxFontType; i++)
	{
		m_EFFace[i] = (PO_Face)PoSysCalloc(1, sizeof(PO_FaceRec_));
		m_bUseEFFace[i] = BrFALSE;
	}

	m_poFullSetFont.pBold = (PO_Face)PoSysCalloc(1, sizeof(PO_FaceRec_));
	m_poFullSetFont.pItalic = (PO_Face)PoSysCalloc(1, sizeof(PO_FaceRec_));
	m_poFullSetFont.pBoldItalic = (PO_Face)PoSysCalloc(1, sizeof(PO_FaceRec_));
	m_poFullSetFont.pFullSet = (PO_Face)PoSysCalloc(1, sizeof(PO_FaceRec_));
#endif

	BoraFont::m_pFontTableData = BrNULL;
	BoraFont::m_mFontName = BrNULL;
	BoraFont::m_wFontName = BrNULL;
}

BoraFont::~BoraFont()
{
	clear();
	releaseExceptFontFileList();
	if (s_pBoraFontShared->deref())
	{
		if (s_pBoraFontShared == g_pBoraFontShared)
			s_pBoraFontShared = 0;
		delete g_pBoraFontShared;
		g_pBoraFontShared = nullptr;
		pthread_mutex_destroy(&pFontMutex);
	}	
	delete m_pPublicMem;
	m_pPublicMem = NULL;
}

void BoraFont::clear()
{
#if 1//def USE_COMMON_INTERFACE
	//[18.04.12][sglee1206] FT_Done_Face 시에도 Mutex Lock 처리함
	POMulticoreMutexForKey(&pFontMutex);
	ReleaseLocaleIndexHash();

#ifdef USE_EMFAMILY_HEADER_FONT
	for (BrINT i = 0; i < eEF_MaxFontType; i++)
	{
		if (m_EFFace[i])
		{
			if (m_EFFace[i]->family_name_UTF8)
				PoSysFree(m_EFFace[i]->family_name_UTF8);
			if (m_EFFace[i]->family_name_Unicode)
				PoSysFree(m_EFFace[i]->family_name_Unicode);
			if (m_EFFace[i]->ft_face)
				FT_Done_Face(m_EFFace[i]->ft_face);
			PoSysFree(m_EFFace[i]);
		}
	}

	if (m_poFullSetFont.pBold)
	{
		if (m_poFullSetFont.pBold->family_name_UTF8)
			PoSysFree(m_poFullSetFont.pBold->family_name_UTF8);
		if (m_poFullSetFont.pBold->family_name_Unicode)
			PoSysFree(m_poFullSetFont.pBold->family_name_Unicode);
		if (m_poFullSetFont.pBold->ft_face)
			FT_Done_Face(m_poFullSetFont.pBold->ft_face);
		PoSysFree(m_poFullSetFont.pBold);
	}
	if (m_poFullSetFont.pItalic)
	{
		if (m_poFullSetFont.pItalic->family_name_UTF8)
			PoSysFree(m_poFullSetFont.pItalic->family_name_UTF8);
		if (m_poFullSetFont.pItalic->family_name_Unicode)
			PoSysFree(m_poFullSetFont.pItalic->family_name_Unicode);
		if (m_poFullSetFont.pItalic->ft_face)
			FT_Done_Face(m_poFullSetFont.pItalic->ft_face);
		PoSysFree(m_poFullSetFont.pItalic);
	}
	if (m_poFullSetFont.pBoldItalic)
	{
		if (m_poFullSetFont.pBoldItalic->family_name_UTF8)
			PoSysFree(m_poFullSetFont.pBoldItalic->family_name_UTF8);
		if (m_poFullSetFont.pBoldItalic->family_name_Unicode)
			PoSysFree(m_poFullSetFont.pBoldItalic->family_name_Unicode);
		if (m_poFullSetFont.pBoldItalic->ft_face)
			FT_Done_Face(m_poFullSetFont.pBoldItalic->ft_face);
		PoSysFree(m_poFullSetFont.pBoldItalic);
	}
	if (m_poFullSetFont.pFullSet)
	{
		if (m_poFullSetFont.pFullSet->family_name_UTF8)
			PoSysFree(m_poFullSetFont.pFullSet->family_name_UTF8);
		if (m_poFullSetFont.pFullSet->family_name_Unicode)
			PoSysFree(m_poFullSetFont.pFullSet->family_name_Unicode);
		if (m_poFullSetFont.pFullSet->ft_face)
			FT_Done_Face(m_poFullSetFont.pFullSet->ft_face);
		PoSysFree(m_poFullSetFont.pFullSet);
	}
#endif

	for(unsigned int i=0; i<m_face_count; i++ )
	{
		if (m_Face[i])
		{
			if (m_Face[i]->family_name_UTF8)
				PoSysFree(m_Face[i]->family_name_UTF8);

			if (m_Face[i]->family_name_Unicode)
				PoSysFree(m_Face[i]->family_name_Unicode);

			if (m_Face[i]->ft_face)
				FT_Done_Face(m_Face[i]->ft_face);

			PoSysFree(m_Face[i]);
			m_Face[i] = BrNULL;
		}
	}
	PoSysFree(m_Face);

	BR_SAFE_DELETE(m_pMEMIDHash);
	BR_SAFE_DELETE(m_pMEMIDWidthHash);
	BR_SAFE_DELETE(m_pBoraMultiLang);

	m_aFontDataPool.removeAll();

	for (int i = 0; i < TTF_FONT_COUNT; i++)
	{
		m_pFontFiles[i].nType = FONTTYPE_FILE;
		m_pFontFiles[i].nSize = 0;
		if (m_pFontFiles[i].pFontData != BrNULL)
		{
			PoSysFree(m_pFontFiles[i].pFontData);
			m_pFontFiles[i].pFontData = BrNULL;
		}
	}
	
	m_first_font_address = BrNULL;
	m_first_font_size = 0;

	clearCacheFontFace(true);
	if (m_pFontName)
	{
		PoSysFree(m_pFontName);
		m_pFontName = BrNULL;
	}

	if (m_pPrevFontName)
	{
		PoSysFree(m_pPrevFontName);
		m_pPrevFontName = BrNULL;
	}

	for (int n=0;n<m_szCurFontList.size();n++)
	{
		PoSysFree(m_szCurFontList[n]);
	}
	m_szCurFontList.clear();

	for(int i = 0; i < m_aNotExistFontName.size(); i++)
	{
		PoSysFree(m_aNotExistFontName.at(i));
	}
	m_aNotExistFontName.removeAll();
	for(int i = 0; i < m_aTypeFaceList.size(); i++)
	{
		LPBrTypefaceStruct pFamily = m_aTypeFaceList.at(i);
		for (int j = 0; j < eFontStyleIndexMax; j++)
		{
			if(pFamily->nFontIndices[j])
			{
				LPBrFontStyleIdxNode node = pFamily->nFontIndices[j];
				LPBrFontStyleIdxNode nextNode = BrNULL;
				while(node)
				{
					nextNode = node->pNext;
					PoSysFree(node);
					node = nextNode;
				}
			}
		}
		PoSysFree(pFamily);
	}
	m_aTypeFaceList.removeAll();

	releaseFontFileList();

	BR_SAFE_DELETE(m_pFontNameList);

	for(int i = 0; i <m_nRuntimeLoadFontCount;i++)
	{
		if(m_RuntimeLoadFont.at(i)->bHasHJCTTable)
			PoSysFree(m_RuntimeLoadFont.at(i)->pHJCTData);
		PoSysFree(m_RuntimeLoadFont.at(i));
	}
	m_RuntimeLoadFont.removeAll();

	if(m_aFontHjctTable)
	{
		int hjctTableSize = m_aFontHjctTable.size();
		for(int i = 0; i < hjctTableSize; i++)
		{
			BR_SAFE_DELETE(m_aFontHjctTable.at(i)->pHjct);
			PoSysFree(m_aFontHjctTable.at(i));
		}
		m_aFontHjctTable.removeAll();
	}

	for (int i = 0; i < m_aLocaleDefaultFontName.size(); i++)
	{
		for (int j = 0; j < m_aLocaleDefaultFontName.at(i)->fontNameCnt; j++)
		{
			if (m_aLocaleDefaultFontName.at(i)->defaultFontName[j])
				PoSysFree(m_aLocaleDefaultFontName.at(i)->defaultFontName[j]);
		}
		PoSysFree(m_aLocaleDefaultFontName.at(i));
	}
	m_aLocaleDefaultFontName.removeAll();

	ReleaseEmbeddedFontData();
	BR_SAFE_DELETE(m_InternalFontNameList);

	if (m_pFTLibrary)
	{
		FT_Done_FreeType(m_pFTLibrary);
		m_pFTLibrary = NULL;
	}

	ReleaseFontNameList();

	if (m_pSystemMathFontName)
	{
		PoSysFree(m_pSystemMathFontName);
		m_pSystemMathFontName = BrNULL;
	}

	if ( m_pDefultFontFilePath )
	{
		PoSysFree(m_pDefultFontFilePath);
		m_pDefultFontFilePath = BrNULL;
	}

	if (m_pBidiMemBlock)
	{
		PoSysFree(m_pBidiMemBlock);
	}
	m_nBidiMemBlockLen = 0;


	if (BoraFont::m_pFontTableData)
	{
		PoSysFree(BoraFont::m_pFontTableData);
		BoraFont::m_pFontTableData = BrNULL;
	}
	if (BoraFont::m_mFontName)
	{
		PoSysFree(BoraFont::m_mFontName);
		BoraFont::m_mFontName = BrNULL;
	}
	if(BoraFont::m_wFontName)
	{
		PoSysFree(BoraFont::m_wFontName);
		BoraFont::m_wFontName = BrNULL;
	}
#endif//ifdef USE_COMMON_INTERFACE
}

FT_Library BoraFont::GetFTLibrary()
{
	if (m_pFTLibrary == BrNULL)
		if (FT_Init_FreeType(&m_pFTLibrary))
			return BrNULL;

	return m_pFTLibrary;
}

BrINT BoraFont::GetFontFamilyCount(const char* pFilePath)
{
	BrINT32 nTTFCount = 0;
	ttcHeader ttc;
	BFile file;
	BString strSrcFile;

	strSrcFile = CUtil::UTF8ToBString(pFilePath);
	if(strSrcFile.isEmpty())
		return nTTFCount;
	
	if (file.Open(strSrcFile, BMV_READ_ONLY))
	{
		BrBYTE pTTCData[4 + 1] = { 0, };
		file.Read(pTTCData, 4);
		if (!FontStrCmp((const char*)pTTCData, "ttcf", 4))
		{
			ttc.tag = chars_2_BEULong(pTTCData);

			file.Read(pTTCData, 2);
			ttc.majorVersion = chars_2_BEUShort(pTTCData);
			file.Read(pTTCData, 2);
			ttc.minorVersion = chars_2_BEUShort(pTTCData);
			file.Read(pTTCData, 4);
			ttc.numFonts = chars_2_BEULong(pTTCData);
			nTTFCount = ttc.numFonts;
		}
		else
			nTTFCount = 1;	// not ttc
		file.Close();
	}

	return nTTFCount;
}

BrINT BoraFont::GetFontNames(const char* pFilePath, BSysExArray<LPFontList>* pFontNames, BSysExArray<BrFontStyle>* pFontStyles)
{
	BrINT nLoadedFontCount = 0;
	FT_Error error = FT_Err_Ok;
	int nTTFIndex = 0;

	if (GetFTLibrary() == BrNULL)
	{
		return nLoadedFontCount;
	}

	if (!pFontNames)
		return nLoadedFontCount;

	FT_Int major, minor, patch;
	FT_Library_Version(m_pFTLibrary, &major, &minor, &patch);

	BrINT32 nTTFCount = GetFontFamilyCount(pFilePath);
	BrUSHORT* wTemp = BrNULL;

	do
	{
		FT_Face FontFace = BrNULL;
		error = FT_New_Face(m_pFTLibrary, (char*)pFilePath, nTTFIndex, &FontFace);

		// error가 success여도 실패한 경우에 대해 error처리하도록 수정함(auEmoji.ttf 폰트 로딩시 발생)
		if (error == FT_Err_Ok && FontFace->family_name != BrNULL)
		{
#ifdef USE_FOR_IOS
			//[19.12.05][sglee1206] LG스마트체2.0 과 같은 경우가 존재하므로 조건변경
			if (FontFace->family_name[0] == '.')
			{
				if (FontStrCmp(FontFace->family_name, ".LastResort"))
				{
					FT_Done_Face(FontFace);
					FontFace = BrNULL;

					nTTFIndex++;
					continue;
				}
				else
					BrTrace("LastResort!");
			}
#endif
			wTemp = BrNULL;
			get_family_name_utf8(FontFace, &wTemp);
			
			BrINT nFontLen = BrWcsLen(wTemp);
			FontList* fontData = (FontList*)BrCalloc(1, sizeof(FontList));
			if (fontData)
			{
				BrWideCharToMultiByte(CP_UTF8, wTemp, nFontLen, fontData->pEngName, sizeof(fontData->pEngName));

				fontData->nFontEncodingType = GetFontEncodingFlag(FontFace);
				FT_UInt tmCount = FT_Get_Sfnt_Name_Count(FontFace);
				BrUSHORT fontNameTemp[MAX_FONT_LENGTH] = { 0, };
				for (int j = 0; j < tmCount; j++)
				{
					memset(fontNameTemp, 0, sizeof(BrUSHORT) * MAX_FONT_LENGTH);
					FT_SfntName tmName;
					FT_Get_Sfnt_Name(FontFace, j, &tmName);
					//[dwchun : 2013.10.23] : 조건을 체크하는 순서 절대로 바꾸지 말 것. 속도를 위해 맞춘 순서임
					if (tmName.language_id == TT_MS_LANGID_KOREAN_EXTENDED_WANSUNG_KOREA && tmName.name_id == 1 && tmName.platform_id == TT_PLATFORM_MICROSOFT && tmName.encoding_id == TT_MS_ID_UNICODE_CS)
					{
						convertFontFaceName(tmName.string_len, tmName.string, fontNameTemp, sizeof(BrUSHORT) * MAX_FONT_LENGTH);
						if (BrWcsLen(fontNameTemp) > 0)
						{
							BrWideCharToMultiByte(CP_UTF8, fontNameTemp, BrWcsLen(fontNameTemp), (BrLPSTR)fontData->pLocName, BORA_FONTNAME_LENGTH - 1);
						}
						break;
					}
				}

				strncpy_s(fontData->pFontPath, sizeof(fontData->pFontPath), pFilePath, strlen(pFilePath));

				pFontNames->add(fontData);

				if (pFontStyles)
				{
					eFontStyleIndex nStyle = getFontListIndexStyleValue(FontFace->style_name);
					BrFontStyle nType = FONTSTYLE_NORMAL;

					if (nStyle == eStyleBold)
						nType = FONTSTYLE_BOLD;
					else if (nStyle == eStyleItalic)
						nType = FONTSTYLE_ITALIC;
					else if (nStyle == eStyleBoldItalic)
						nType = FONTSTYLE_BOLDITALIC;

					pFontStyles->add(nType);
				}

				nLoadedFontCount++;
			}

			if (wTemp)
			{
				PoSysFree(wTemp);
				wTemp = BrNULL;
			}
		}

		if(FontFace)
			FT_Done_Face(FontFace);
		nTTFIndex++;

	}while (error == FT_Err_Ok && nTTFCount > nTTFIndex);

	return nLoadedFontCount;
}

bool BoraFont::Init()
{
#if 1//def USE_COMMON_INTERFACE
	//[18.04.12][sglee1206] Mutex Lock 시점 변경. FT_Init 시에도 다른 작업하면 안됨
	POMulticoreMutexForKey(&pFontMutex);
	if (GetFTLibrary() == BrNULL)
	{
		return false;
	}

	FT_Int major, minor, patch;
	FT_Library_Version(m_pFTLibrary, &major, &minor, &patch);
#ifdef FT_CONFIG_OPTION_SUBPIXEL_RENDERING
	if (FT_Library_SetLcdFilter(m_pFTLibrary, FT_LCD_FILTER_LIGHT) == 0) 
	{
		/*
		static const FT_LcdFiveTapFilter  default_weights =
		{ 0x08, 0x4d, 0x56, 0x4d, 0x08 };
		static const FT_LcdFiveTapFilter  light_weights =
		{ 0x00, 0x55, 0x56, 0x55, 0x00 };
		static unsigned char gGaussianLikeHeavyWeights[] = 
		{ 0x00, 0x55, 0x56, 0x55, 0x00 };
		FT_Library_SetLcdFilterWeights(m_pFTLibrary, gGaussianLikeHeavyWeights);
		*/

		FT_Int      darken_params[8] = 
		{    375, 300,   // x1, y1
			750, 200,   // x2, y2
			1125, 100,   // x3, y3
			1500,   0 }; // x4, y4
		FT_Bool     no_stem_darkening = FALSE;

		FT_Property_Set( m_pFTLibrary, "autofitter","darkening-parameters", darken_params );
		//FT_Property_Set( m_pFTLibrary, "sfnt","darkening-parameters", darken_params );
		//FT_Property_Set( m_pFTLibrary, "autofitter","wrap", darken_params );
		//FT_Property_Set( m_pFTLibrary, "autofitter","no-stem-darkening", &no_stem_darkening );
		 FT_UInt     interpreter_version = TT_INTERPRETER_VERSION_40;
		
		 FT_Property_Set( m_pFTLibrary, "truetype",
		                           "interpreter-version",
		                           &interpreter_version );
	}
#endif

	loadHeaderFont();

	bool bFontInitialized = false;
	bool bLoadSystemFont = false;
#ifdef SUPPORT_ADD_FONT_TABLE
	bFontInitialized = BHasFontInitializedTable();
	if(bFontInitialized)
		bLoadSystemFont = convertGetDataToFontTable();
#endif
	if ( !bLoadSystemFont )
		bLoadSystemFont = getSystemFontName();

	//[16.01.14][sglee1206] 기본적으로 가지고 있어야 하는 폰트 Load
	BrINT nLoadedDefaultSystemFont = loadDefaultSystemFont();

	BrINT nLoadedPurchaseFontCnt = loadPurchaseFont();

	BRTHREAD_ASSERT(m_face_count);
	if (!m_face_count)
	{
		return false;
	}

#ifdef USE_EMFAMILY_HEADER_FONT
	if(m_EFFace)
		loadCharmap(m_EFFace, eEF_MaxFontType);

	if (m_poFullSetFont.pBold)
		loadCharmap(&m_poFullSetFont.pBold, 1);
	if (m_poFullSetFont.pItalic)
		loadCharmap(&m_poFullSetFont.pItalic, 1);
	if (m_poFullSetFont.pBoldItalic)
		loadCharmap(&m_poFullSetFont.pBoldItalic, 1);
	if (m_poFullSetFont.pFullSet)
		loadCharmap(&m_poFullSetFont.pFullSet, 1);
#endif
	loadCharmap(m_Face, m_face_count);

	if(m_nDefOriginalFontFlag == -1)
		initialFontTable();

	BRTHREAD_ASSERT(m_nBaseIndex != m_face_count);
	if ( m_nBaseIndex == m_face_count )
		m_nBaseIndex--;

	//[15.08.05][sglee1206] Apple Color Emoji가 _1x, @2x 두가지 종류가 추가(iOS 8.2부터)되어 Emoji가 Base가 되어 문제 발생
	//MQP-3883,MQP-3896
	bool bEmoji = true;
	FT_UInt fontCnt = GetFontFaceCnt();
	while(bEmoji && fontCnt > m_nBaseIndex)
	{
		if(IsColorEmojiFont(getFTFaceByIndex(m_nBaseIndex)) )
			m_nBaseIndex++;
		else
		{
			BrWORD* family_name = GetFamilyNameByIndex(m_nBaseIndex);
			if (family_name[0] == 0x41 && !FontWcsCmp(family_name, (const unsigned short*)u"Apple Color Emoji", 17))
				m_nBaseIndex++;
			else
				bEmoji = false;
		}
	}

	if(!bFontInitialized)
	{
		bFontInitialized = convertFontTableToSendData();
		BrTrace("Font Data Send Result :%d",bFontInitialized);
	}
	return true;
#endif//#ifdef USE_COMMON_INTERFACE
	return true;
}

bool BoraFont::SetLocaleDefaultFontList(LPBrLocaleDefaultFontName fontNameList, const int nListCount)
{
BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
	LPBrLocaleDefaultFont defaultFontNameList = BrNULL;

	if (fontNameList == BrNULL || nListCount <= 0)
		return false;

	for (int testIdx = 0; testIdx < nListCount; testIdx++)
	{
		defaultFontNameList = BrNULL;
		defaultFontNameList = (LPBrLocaleDefaultFont)PoSysCalloc(1, sizeof(BrLocaleDefaultFont));

		if (defaultFontNameList == BrNULL)
		{
			// Error Return
			BRTHREAD_ASSERT(0);
			return false;
		}

		memset(defaultFontNameList->scriptTag, 0, BORA_SCRIPT_TAG_LENGTH);
		strncpy_s(defaultFontNameList->scriptTag, BORA_SCRIPT_TAG_LENGTH, fontNameList[testIdx].scriptTag, strlen(fontNameList[testIdx].scriptTag));
		defaultFontNameList->fontNameCnt = fontNameList[testIdx].fontNameCnt;

		//name List Copy
		int nameLen = 0;
		for (int i = 0; i < 5; i++)
		{
			if (fontNameList[testIdx].defaultFontName[i] != BrNULL)
			{
				nameLen = BrStrLen(fontNameList[testIdx].defaultFontName[i]);
				BrINT32 nLen = BrMultiByteToWideChar(CP_UTF8, fontNameList[testIdx].defaultFontName[i], nameLen, BrNULL, 0);
				defaultFontNameList->defaultFontName[i] = (unsigned short*)PoSysCalloc(nLen +1, sizeof(unsigned short));
				BrMultiByteToWideChar(CP_UTF8, fontNameList[testIdx].defaultFontName[i], nameLen, defaultFontNameList->defaultFontName[i], nLen);
			}
		}
		
		m_aLocaleDefaultFontName.add(defaultFontNameList);
	}

	return true;
}

bool BoraFont::SetDefaultLoadFontFileList(char** fontfileList, int nCount)
{
	BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
#if defined( SUPPORT_ADD_FONT ) && !defined( SUPPORT_ADD_FONT_TABLE )
	BrINT fontFileListLen = m_aLoadFontFilePath.size();
	BrBOOL bFindFont = BrFALSE;
	BrINT findfileIdx = -1;
	BrINT prevFontCnt = GetFontFaceCnt();

	for (int i = 0; i < nCount; i++)
	{
		bFindFont = BrFALSE;
		findfileIdx = -1;
		if (fontfileList[i] != BrNULL)
		{
			for (int fileIdx = 0; fileIdx < fontFileListLen; fileIdx++)
			{
				LPBrLoadFontFileList pSystmeFontFile = getLoadFontFileList(fileIdx);

				if (pSystmeFontFile &&
					pSystmeFontFile->bLoaded == BrFALSE
					&& !FontStrCmp(pSystmeFontFile->pFontPath, fontfileList[i]))
				{
					bFindFont = BrTRUE;
					findfileIdx = fileIdx;
					break;
				}
			}
		}

		if (bFindFont && findfileIdx > -1)
		{
			LPBrLoadFontFileList pSystmeFontFile = getLoadFontFileList(findfileIdx);
			if (pSystmeFontFile)
			{
				int listSize = pSystmeFontFile->fontStIndices->size();
				for (int fileIdx = 0; fileIdx < listSize; fileIdx++)
				{
					loadSystemFontFile(pSystmeFontFile->fontStIndices->at(fileIdx));
				}
			}
		}
	}

	return (prevFontCnt < GetFontFaceCnt());
#endif	//defined( SUPPORT_ADD_FONT ) && !defined( SUPPORT_ADD_FONT_TABLE )
	return false;
}


/*
*	@author 		Andrew
*	@date  		2016.06.07
*	@params  	const char* $pFilePath : 파일영(.ttf)
*	@params  	FT_Face[] $ft_FontFace : FT_Face배열
*	@params  	FT_UInt& $ft_FontFace_count : FT_Face[]의 인덱스
*	@params  	int $sysFontIdx :
*	@params  	int $nIndex :
*	@params  	BrBOOL $bDirectLoading : true인 경우 $fontFace를 유지(m_Face[])
*	@brief  		FT_New_Face를 사용하여 폰트를 로딩
*   @change		2018.07.19
*				$nTtfIndex 제거
*				FT_Face& $fontFace -> FT_Face ft_FontFace[]
*				return value 제거
*/

BrINT BoraFont::addFontFile(const char* pFilePath, int sysFontIdx, int nIndex, BrBOOL bDirectLoading)
{
	BrINT nAddFont = 0;
	int nTTFIndex = 0;
	FT_Error error = FT_Err_Ok;
	
	BrINT32 nTTFCount = 0;
	{
		ttcHeader ttc;
		BFile file;
		BString strSrcFile = CUtil::UTF8ToBString(pFilePath);
		if (file.Open(strSrcFile, BMV_READ_ONLY))
		{
			BrBYTE pTTCData[4 + 1] = { 0, };
			file.Read(pTTCData, 4);
			if (!FontStrCmp((const char*)pTTCData, "ttcf", 4))
			{
				ttc.tag = chars_2_BEULong(pTTCData);

				file.Read(pTTCData, 2);
				ttc.majorVersion = chars_2_BEUShort(pTTCData);
				file.Read(pTTCData, 2);
				ttc.minorVersion = chars_2_BEUShort(pTTCData);
				file.Read(pTTCData, 4);
				ttc.numFonts = chars_2_BEULong(pTTCData);
				nTTFCount = ttc.numFonts;
			}
			else
				nTTFCount = 1;	// not ttc
			file.Close();
		}
	}

	do
	{
		FT_Face FontFace = BrNULL;
		error = FT_New_Face(m_pFTLibrary, (char*)pFilePath, nTTFIndex, &FontFace);

		// error가 success여도 실패한 경우에 대해 error처리하도록 수정함(auEmoji.ttf 폰트 로딩시 발생)
		if ( error == FT_Err_Ok && FontFace->family_name != BrNULL)
		{
#ifdef USE_FOR_IOS
			//[19.12.05][sglee1206] LG스마트체2.0 과 같은 경우가 존재하므로 조건변경
			if (FontFace->family_name[0] == '.')
			{
				if (FontStrCmp(FontFace->family_name, ".LastResort"))
				{
					FT_Done_Face(FontFace);
					FontFace = BrNULL;

					nTTFIndex++;
					continue;
				}
				else
					BrTrace("LastResort!");
			}
#endif
			AddExceptFontFile((const char*)pFilePath);
			if ( bDirectLoading )
			{
				int nFontIndex = addFontFaceByIndex(FontFace);
				PO_Face pFace = GetFontFaceByIndex(nFontIndex);

				int nSysFontIndex = getSysFontIndex(pFace, sysFontIdx);
#ifndef SUPPORT_ADD_FONT
				setSystemFontPath((BrCHAR*)pFilePath,FontFace, nTTFIndex, bDirectLoading);
				pFace->nFontListIndex = m_nRuntimeLoadFontCount-1;
#else
				pFace->nFontListIndex = nSysFontIndex;
#endif // !SUPPORT_ADD_FONT
				regFontDataPool((void*)pFilePath, 0, pFace);

				addFontCharmap(pFace);

				if ( nAddFont == 0 && nIndex == 0 )
				{
					memset(m_pDefultFontFilePath, 0, BORA_FULLPATH_LENGTH);
					strncpy_s(m_pDefultFontFilePath, BORA_FULLPATH_LENGTH, (char*)pFilePath, strlen((char*)pFilePath));
				}
			}
			else
			{
				setSystemFontPath((char*)pFilePath, FontFace, nTTFIndex, bDirectLoading);
			}
			nAddFont++;
		}
		else if(FontFace != BrNULL)
		{
			FT_Done_Face(FontFace);
		}

		if ( !bDirectLoading )
		{
			if(m_bSetPrimaryFont == BrTRUE && nIndex <= 0)
				m_bSetPrimaryFont = BrFALSE;
		}
		nTTFIndex++;
	}while(error == FT_Err_Ok && nTTFCount > nTTFIndex);
#ifdef USE_PRIMARY_FONT
	if(m_bSetPrimaryFont == BrFALSE)
	{
		m_bSetPrimaryFont = BrTRUE;
	}
#endif
	return nAddFont;
}

BrINT BoraFont::getMemoryFontFaceCount(BrBYTE* pTTCData)
{
	if (pTTCData == BrNULL)
		return 0;

	ttcHeader ttc;
	int nTTFCount = 0;
	if (!FontStrCmp((const char*)pTTCData, "ttcf", 4))
	{
		ttc.tag = chars_2_BEULong(pTTCData);
		pTTCData += 4;

		ttc.majorVersion = chars_2_BEUShort(pTTCData);
		pTTCData += 2;

		ttc.minorVersion = chars_2_BEUShort(pTTCData);
		pTTCData += 2;

		ttc.numFonts = chars_2_BEULong(pTTCData);
		pTTCData += 4;
		nTTFCount = ttc.numFonts;
	}
	else
		nTTFCount = 1;	// not ttc

	return nTTFCount;
}


/*
*	@author 		Andrew
*	@date  		2016.06.09
*	@params  	void* $pBuffer : 폰트 버퍼
*	@params  	int $nBufferSize : 버퍼의 크기
*	@params  	int $nTtfIndex : ttc인 경우 ttf인덱스
*	@params  	FT_Face& $fontFace : FT_Face값
*	@params  	BrBOOL $bDirectLoading : true인 경우 $fontFace를 유지(m_Face[])
*	@return  		jboolean : success(true), fail(false)
*	@brief  		FT_New_Memory_Face를 사용하여 폰트를 로딩
*/
BrBOOL BoraFont::addFontMemory(void* pBuffer, int nBufferSize, int nTtfIndex, FT_Face& fontFace, BrBOOL bDirectLoading)
{
	if ( pBuffer == BrNULL || nBufferSize == 0 )
		return BrFALSE;
	
	FT_Error error = FT_Err_Ok;
	
	error = FT_New_Memory_Face(m_pFTLibrary, (const FT_Byte*)pBuffer, nBufferSize, nTtfIndex, &fontFace);

	return (error == FT_Err_Ok);
}

void BoraFont::SetBaseFontFacePixelSizes(FT_Int nWidth, FT_Int nHeight)
{
	// getFontFace에서 SUPPORT_ADD_FONT시 Index번째 font가 없을때 0번째를 사용하므로 set 할때도 0번째를 사용하도록 한다
	FT_Face fontFace = getFTFaceByIndex(m_nBaseIndex);
#ifdef SUPPORT_ADD_FONT
	if (fontFace == BrNULL)
		fontFace = getFTFaceByIndex(0);
#endif//SUPPORT_ADD_FONT

	if (fontFace)
	{
		FT_Set_Pixel_Sizes(fontFace, nWidth, nHeight);
	}
}

/*
*	@author 		Andrew
*	@date  		2016.06.13
*	@params  	int $nIndex : m_Face의 index
*	@return  		FT_Face& : m_Face[$nIndex]
*	@brief  		m_Face[$nIndex]에 해당하는 FT_Face
*/
PO_Face BoraFont::GetFontFaceByIndex(int nIndex) 
{
	if(nIndex < 0 || nIndex >= m_face_count)
		return BrNULL;

	return m_Face[nIndex];
}

FT_Face BoraFont::getFTFaceByIndex(int nIndex) 
{
	PO_Face fontFace = GetFontFaceByIndex(nIndex);
	if(fontFace)
		return fontFace->ft_face;
	else
		return BrNULL;
}

int BoraFont::addFontFaceByIndex(FT_Face face)
{
	if(m_Face[m_face_count] == BrNULL)
		m_Face[m_face_count] = (PO_Face)PoSysCalloc(1, sizeof(PO_FaceRec_));

	m_Face[m_face_count]->nFontListIndex = -1;
	m_Face[m_face_count]->nPrimaryCharmapIdx = 0;
	m_Face[m_face_count]->family_name_UTF8 = get_family_name_utf8(face, &m_Face[m_face_count]->family_name_Unicode);

#if defined( USE_ALTERNATE_FONT )
	if (BrWcsLen(m_Face[m_face_count]->family_name_Unicode) > 0)
	{
		for (int i = 0; sPurchaseFontHName[i] && i < ePurchaseFontMax; i++)
		{
			if (!FontWcsCmp(m_Face[m_face_count]->family_name_Unicode, sPurchaseFontHName[i]))
			{
				m_nLoadedPurchaseFontCnt++;
				m_bLoadedPurchaseFont[i] = BrTRUE;
				continue;
			}
		}
	}
#endif

	m_Face[m_face_count]->moduleName = BrNULL;
	m_Face[m_face_count++]->ft_face = face;

	return m_face_count - 1;
}

BrWORD* BoraFont::GetFamilyNameByIndex(int nIndex)
{
	PO_Face fontFace = GetFontFaceByIndex(nIndex);
	if (fontFace)
		return fontFace->family_name_Unicode;
	else
		return BrNULL;
}

FT_String* BoraFont::getPostScriptNameByFontFace(PO_Face face) 
{
	FT_String* psName = (FT_String*)FT_Get_Postscript_Name(face->ft_face);
	if (!psName)
	{
		if(face->family_name_UTF8)
			return face->family_name_UTF8;
		else
			return face->ft_face->family_name;
	}

	return psName;
}

/*
*	@author 		Andrew
*	@date  		2016.06.07
*	@params  	int $nSize : buffer size
*	@params  	unsigned char* $tmName : string buffer
*	@return  		BrCHAR* : output string(unicode : utf16)
*	@brief  		입력 스트링의 endian을 변경하여 unicode로 변환한다.
*/
BrCHAR* BoraFont::convertFontFaceName(int nSize, unsigned char *tmName)
{
	int nLength = BrMIN(MAX_FONT_LENGTH-2, nSize);
	BrCHAR* fontName = (BrCHAR*)PoSysMalloc(nLength+2);
	memset(fontName,0,nLength+2);	
	for( int k = 0; k < nLength; k = k + 2 )
	{
		fontName[k] = tmName[k+1];
		fontName[k+1] = tmName[k];
	}
	return fontName;
}

/*
*	@author 		Andrew
*	@date  		2016.06.07
*	@params  	int $nSize : buffer size
*	@params  	unsigned char* $tmName : string buffer
*	@params  	unsigned short* $pFontName : output string
*	@return  		
*	@brief  		입력 스트링의 endian을 변경하여 unicode로 변환한다.
*/
void BoraFont::convertFontFaceName(int nSize, unsigned char *tmName, unsigned short* pFontName, int nOutBufferSize)
{
	int nLength = BrMIN(nOutBufferSize, nSize);
	for( int k = 0, j=0; k < nLength; k = k + 2,j++ )
	{
		pFontName[j] = tmName[k]<<8 | tmName[k+1];
	}
}

BrINT BoraFont::setSystemFontNameCache(FT_Face fontFace, BrINT nListIndex) 
{
	BrINT nRet = nListIndex;
#if defined( SUPPORT_ADD_FONT )
	FT_UInt tmCount = FT_Get_Sfnt_Name_Count( fontFace );
	//////////////////////// Testing ///////////////////////////	
	int nInsertResult = -3;		// -1 : success, -2 : Same RuntimeLoadFont Index, -3 default

	FT_String mac_style_name[MAX_FONT_LENGTH] = { 0, };
#ifdef MAC_FONT_SUPPORT	// OS X 말고 iOS에서도 사용해야 할지 검토 필요
	FT_UShort languageMacID = TT_MAC_LANGID_KOREAN;
	FT_UShort encodingMacID = TT_MAC_ID_KOREAN;
	FT_UShort platformMacID = TT_PLATFORM_MACINTOSH;

	int nLocale = PoGetLocale();
	int localeCodePage = CP_ACP;
	const FT_UShort* retLocaleID = getLocaleIDList(nLocale);

	//[15.12.16][sglee1206] 현재는 아래 넷에 대해서만 처리. 추가 요청에 따라 늘리고 궁극적으로는 조건이 필요없어야 함
	if (retLocaleID != BrNULL)
	{
		languageMacID = retLocaleID[5];
		encodingMacID = retLocaleID[6];
		platformMacID = retLocaleID[8];
	}

	for (int j = 0; j < tmCount; j++)
	{
		FT_SfntName tmName;
		FT_Get_Sfnt_Name(fontFace, j, &tmName);
		if (tmName.language_id == languageMacID && tmName.name_id == TT_NAME_ID_FONT_SUBFAMILY && tmName.platform_id == platformMacID
			&& tmName.encoding_id == encodingMacID)
		{
			int  nLength = BrMIN(MAX_FONT_LENGTH, tmName.string_len);
			for (int k = 0; k < nLength; k++)
			{
				mac_style_name[k] = tmName.string[k];
			}
			break;
		}
	}
#endif

	for( int j = 0; j < tmCount; j++ )
	{
		BrWORD* fontName = BrNULL;
		fontName = convertSfntFontName(fontFace, j, mac_style_name);

		if ( fontName )
			nInsertResult = m_pFontNameList->Insert(fontName,nRet);		
		else
			nInsertResult = -3;

		if(nInsertResult >= 0)
			nRet = nInsertResult;
		
		if(nRet != nListIndex)
		{
			m_pFontNameList->ReplaceAllByValue(nListIndex,nRet);
			nListIndex = nRet;
		}

		nInsertResult = -3;
	}
#endif
	return nRet;
}

BrINT BoraFont::addFontFilePath(BrCHAR* pFontPath)
{
	if (pFontPath == BrNULL)
		return -1;
	BrINT nFontFileCnt = m_aLoadFontFilePath.size();
	LPBrLoadFontFileList pFontFile;
	for (int i = nFontFileCnt - 1; i >= 0; i--)
	{
		pFontFile = getLoadFontFileList(i);
		if (pFontFile && !strcmp(pFontPath, pFontFile->pFontPath))
		{
			pFontFile->nFontFaceCount++;
			return i;
		}
	}
	// not exist
	pFontFile = (LPBrLoadFontFileList)PoSysMalloc(BrSizeOf(BrLoadFontFileList));
	pFontFile->nFontFaceCount = 1;
	pFontFile->bLoaded = BrFALSE;
	memset(pFontFile->pFontPath, 0, sizeof(pFontFile->pFontPath));
	strncpy_s(pFontFile->pFontPath, sizeof(pFontFile->pFontPath), pFontPath, strlen(pFontPath));
#if !defined( SUPPORT_ADD_FONT_TABLE )
	pFontFile->fontStIndices = new BSysExArray<BrINT>;
#endif
	m_aLoadFontFilePath.add(pFontFile);
	return nFontFileCnt;
}

const FT_UShort* BoraFont::getLocaleIDList(int nLocale)
{
#define LOCALE_ID_LIST_ITEM_COUNT	9
	//languageMSID, encodingMSID, encodingMSID2, nameMSID, platformMSID, languageMacID, encodingMacID, nameMacID, platformMacID
	static const FT_UShort arrLocaleIDList[][LOCALE_ID_LIST_ITEM_COUNT] =
	{
		{
			TT_MS_LANGID_KOREAN_EXTENDED_WANSUNG_KOREA, TT_MS_ID_UNICODE_CS, TT_MS_ID_WANSUNG, TT_NAME_ID_FONT_FAMILY, TT_PLATFORM_MICROSOFT,
			TT_MAC_LANGID_KOREAN,TT_MAC_ID_KOREAN, TT_NAME_ID_FONT_FAMILY, TT_PLATFORM_MACINTOSH
		}, //1 BR_LOCALE_KOREAN
		{
			TT_MS_LANGID_CHINESE_PRC, TT_MS_ID_UNICODE_CS, TT_MS_ID_GB2312, TT_NAME_ID_FONT_FAMILY, TT_PLATFORM_MICROSOFT,
			TT_MAC_LANGID_CHINESE_SIMPLIFIED, TT_MAC_ID_SIMPLIFIED_CHINESE, TT_NAME_ID_FONT_FAMILY, TT_PLATFORM_MACINTOSH
		}, //28 BR_LOCALE_S_CHINESE
		{
			TT_MS_LANGID_CHINESE_TAIWAN, TT_MS_ID_UNICODE_CS, TT_MS_ID_BIG_5, TT_NAME_ID_FONT_FAMILY, TT_PLATFORM_MICROSOFT,
			TT_MAC_LANGID_CHINESE_TRADITIONAL, TT_MAC_ID_TRADITIONAL_CHINESE, TT_NAME_ID_FONT_FAMILY, TT_PLATFORM_MACINTOSH
		}, //29 BR_LOCALE_T_CHINESE_TW
		{
			TT_MS_LANGID_JAPANESE_JAPAN, TT_MS_ID_UNICODE_CS, TT_MS_ID_SJIS, TT_NAME_ID_FONT_FAMILY, TT_PLATFORM_MICROSOFT,
			TT_MAC_LANGID_JAPANESE, TT_MAC_ID_JAPANESE, TT_NAME_ID_FONT_FAMILY, TT_PLATFORM_MACINTOSH
		}, //44 BR_LOCALE_JAPANESE
	};

	const FT_UShort* retLocaleID = BrNULL;
	switch (nLocale)
	{
	case BR_LOCALE_KOREAN:
		retLocaleID = arrLocaleIDList[0];
		break;
	case BR_LOCALE_S_CHINESE:
		retLocaleID = arrLocaleIDList[1];
		break;
	case BR_LOCALE_T_CHINESE_TW:
		retLocaleID = arrLocaleIDList[2];
		break;
	case BR_LOCALE_JAPANESE:
		retLocaleID = arrLocaleIDList[3];
		break;
	default:
		retLocaleID = BrNULL;
		break;
	}

	return retLocaleID;
}

void BoraFont::setTypefaceStructName(FT_Face fontFace, BrWORD* fontName_unicode, BrCHAR* family_name_utf8, LPBrTypefaceStruct pFamily)
{
#ifdef USE_COMMON_INTERFACE
	if (pFamily)
	{
		BrUSHORT wTemp[MAX_FONT_LENGTH] = { 0, };
		memset(pFamily->pFamily_name, 0, sizeof(pFamily->pFamily_name));
		CUtil::WcsCpy(pFamily->pFamily_name, fontName_unicode);
		sameFamilyFontListIndexClear(pFamily);

		
		pFamily->nCountSameFamily = 1;

		////////////////////////////////////////////////////////////
		FT_UInt tmCount = FT_Get_Sfnt_Name_Count(fontFace);

		memset(pFamily->sFontData.pEngName, 0, 256 * BrSizeOf(unsigned short));
		memset(pFamily->sFontData.pLocName, 0, 256 * BrSizeOf(unsigned short));

		FT_UShort languageMSID = TT_MS_LANGID_KOREAN_EXTENDED_WANSUNG_KOREA;
		FT_UShort encodingMSID = TT_MS_ID_UNICODE_CS;
		FT_UShort encodingMSID2 = TT_MS_ID_WANSUNG;
		FT_UShort nameMSID = TT_NAME_ID_FONT_FAMILY;
		FT_UShort platformMSID = TT_PLATFORM_MICROSOFT;

		FT_UShort languageMacID = TT_MAC_LANGID_KOREAN;
		FT_UShort encodingMacID = TT_MAC_ID_KOREAN;
		FT_UShort nameMacID = TT_NAME_ID_FONT_FAMILY;
		FT_UShort platformMacID = TT_PLATFORM_MACINTOSH;

		int nLocale = PoGetLocale();
		int localeCodePage = CP_ACP;
		const FT_UShort* retLocaleID = getLocaleIDList(nLocale);

		//[15.12.16][sglee1206] 현재는 아래 넷에 대해서만 처리. 추가 요청에 따라 늘리고 궁극적으로는 조건이 필요없어야 함
		if (retLocaleID != BrNULL)
		{
			languageMSID = retLocaleID[0];
			encodingMSID = retLocaleID[1];
			encodingMSID2 = retLocaleID[2];
			nameMSID = retLocaleID[3];
			platformMSID = retLocaleID[4];

			languageMacID = retLocaleID[5];
			encodingMacID = retLocaleID[6];
			nameMacID = retLocaleID[7];
			platformMacID = retLocaleID[8];
		}

		//[15.12.16][sglee1206] Code Page 얻는 부분 분리함
		localeCodePage = getLocaleCodePage(nLocale);

		BrBOOL bFindFontName = BrFALSE;
#ifdef MAC_FONT_SUPPORT	// OS X 말고 iOS에서도 사용해야 할지 검토 필요
		unsigned short	pMACLocName[MAX_FONT_LENGTH] = {0,};
		FT_String mac_style_name[MAX_FONT_LENGTH] = { 0, };
		for (int j = 0; j < tmCount; j++)
		{
			FT_SfntName tmName;
			FT_Get_Sfnt_Name(fontFace, j, &tmName);
			if (tmName.language_id == languageMacID && tmName.name_id == TT_NAME_ID_FONT_SUBFAMILY && tmName.platform_id == platformMacID
				&& tmName.encoding_id == encodingMacID)
			{
				int  nLength = BrMIN(MAX_FONT_LENGTH, tmName.string_len);
				for (int k = 0; k < nLength; k++)
				{
					mac_style_name[k] = tmName.string[k];
				}
				break;
			}
		}

#endif
		for (int j = 0; j < tmCount; j++)
		{
			FT_SfntName tmName;
			FT_Get_Sfnt_Name(fontFace, j, &tmName);


			///////////////////////////////////////////// Microsoft Font Name /////////////////////////////////////////////
			//[dwchun : 2013.10.23] : 조건을 체크하는 순서 절대로 바꾸지 말 것. 속도를 위해 맞춘 순서임
			if (tmName.language_id == languageMSID && tmName.name_id == nameMSID && tmName.platform_id == platformMSID)
			{
				if (tmName.encoding_id == encodingMSID || tmName.encoding_id == 10)
				{
					convertFontFaceName(tmName.string_len, tmName.string, pFamily->sFontData.pLocName, BrSizeOf(pFamily->sFontData.pLocName));
					bFindFontName = true;
					break;
				}
				else if (tmName.encoding_id == encodingMSID2)
				{
					int  nLength = BrMIN(MAX_FONT_LENGTH, tmName.string_len);

					//multibyte(CP-949 등)
					BrUCHAR* mFontName = (BrUCHAR*)getCharBuffer();

					int localeCodePage = CP_ACP;
					int nLocale = BR_LOCALE_US_ENGLISH;

					{
						if (tmName.encoding_id == TT_MS_ID_SJIS)
							nLocale = BR_LOCALE_JAPANESE;
						else if (tmName.encoding_id == TT_MS_ID_GB2312)
							nLocale = BR_LOCALE_S_CHINESE;
						else if (tmName.encoding_id == TT_MS_ID_BIG_5)
							nLocale = BR_LOCALE_T_CHINESE_TW;
						else if (tmName.encoding_id == TT_MS_ID_WANSUNG)
							nLocale = BR_LOCALE_KOREAN;
					}

					BrINT nLen = 0;
					//[17.06.29][sglee1206] 특정 폰트명이 tmName.encoding_id == TT_MS_ID_WANSUNG인 경우에 Unicode로 되어 있음[XPD-17697]
					//태 나무, 펜흘림 폰트명 처리시 기존방식대로 하면 글자 깨짐
					if (nLocale == BR_LOCALE_KOREAN && tmName.string_len > 5 &&
						(((tmName.string[0] << 8 | tmName.string[1]) == 0xD0DC && (tmName.string[2] << 8 | tmName.string[3]) == 0x0020 && (tmName.string[4] << 8 | tmName.string[5]) == 0xB098)
							|| ((tmName.string[0] << 8 | tmName.string[1]) == 0xD39C && (tmName.string[2] << 8 | tmName.string[3]) == 0xD758 && (tmName.string[4] << 8 | tmName.string[5]) == 0xB9BC))
						)
					{
						for (int k = 0; k < nLength; k++)
						{
							mFontName[nLen++] = tmName.string[k];
						}
						convertFontFaceName(nLen, mFontName, pFamily->sFontData.pLocName, nLength);
					}
					else
					{
						for (int k = 0; k < nLength; k++)
						{
							if (tmName.string[k] != 0)
							{
								mFontName[nLen++] = tmName.string[k];
							}
						}

						localeCodePage = getLocaleCodePage(nLocale);

						//[15.11.13][sglee1206] 글꼴_일부 글꼴 화면 표시 오류 수정 [ZPD-17896][ZPD-17948]
						//CP_ACP는 해당 locale의 ANSI Code Page로 OS Locale이 영어권에서는 CP949로 처리되지 않음
						// CP949 -> Unicode
						nLen = BrMultiByteToWideChar(localeCodePage, (BrLPCSTR)mFontName, nLen, pFamily->sFontData.pLocName, BrSizeOf(pFamily->sFontData.pLocName) / BrSizeOf(unsigned short));
					}

					bFindFontName = BrTRUE;
					break;
				}
			}
#ifdef MAC_FONT_SUPPORT	// OS X 말고 iOS에서도 사용해야 할지 검토 필요
			if (tmName.language_id == languageMacID && tmName.name_id == nameMacID && tmName.platform_id == platformMacID
				&& tmName.encoding_id == encodingMacID)
			{
				int  nLength = BrMIN(MAX_FONT_LENGTH, tmName.string_len);

				//multibyte(CP-949 등)
				BrCHAR* mFontName = new BrCHAR[nLength + 1];
				memset(mFontName, 0, sizeof(BrCHAR) * nLength + 1);
				BrINT nLen = 0;
				for (int k = 0; k < nLength; k++)
				{
					if (tmName.string[k] != 0)
					{
						mFontName[nLen++] = tmName.string[k];
					}
				}

				int localeCodePage = CP_ACP;
				int nLocale = BR_LOCALE_US_ENGLISH;
				//[16.07.23][sglee1206] mac인 경우 Language ID에 따라 codepage 변경
				{
					if (tmName.language_id == TT_MAC_LANGID_JAPANESE)
						nLocale = BR_LOCALE_JAPANESE;
					else if (tmName.language_id == TT_MAC_LANGID_CHINESE_SIMPLIFIED)
						nLocale = BR_LOCALE_S_CHINESE;
					else if (tmName.language_id == TT_MAC_LANGID_CHINESE_TRADITIONAL)
						nLocale = BR_LOCALE_T_CHINESE_TW;
					else if (tmName.language_id == TT_MAC_LANGID_KOREAN)
						nLocale = BR_LOCALE_KOREAN;
				}

				localeCodePage = getLocaleCodePage(nLocale);

				// CP949 -> Unicode
				nLen = BrMultiByteToWideChar(localeCodePage, mFontName, nLen, pMACLocName, BrSizeOf(pMACLocName) / BrSizeOf(unsigned short));
				delete[] mFontName;

				if (!BoraFontComm::IsSkipFontName(fontFace->family_name))
				{
					if (BrStrLen(mac_style_name) == 0 || !FontStrCmp(mac_style_name, fontFace->style_name))
					{
						CUtil::WcsCpy(pFamily->sFontData.pLocName, pMACLocName);
						memset(pMACLocName, 0, sizeof(pMACLocName));
						bFindFontName = BrTRUE;
						break;
					}
					else
						memset(pMACLocName, 0, sizeof(pMACLocName));
				}
				else
					memset(pMACLocName, 0, sizeof(pMACLocName));
			}
#endif
		}
		memset(pFamily->sFontData.pEngName, 0, BrSizeOf(pFamily->sFontData.pEngName));

		BrINT nFontLen = 0;

		memset(wTemp, 0, sizeof(BrUSHORT)* MAX_FONT_LENGTH);
		if (fontName_unicode != BrNULL)
		{
			CUtil::WcsCpy(wTemp, fontName_unicode);
			nFontLen = BrWcsLen(wTemp);
		}
		else if(family_name_utf8 != BrNULL)
			nFontLen = BrMultiByteToWideChar(CP_UTF8, family_name_utf8, BrStrLen(family_name_utf8), wTemp, MAX_FONT_LENGTH);

		if (!isRegEmFamilyFont(wTemp, nFontLen, m_nFontFlag))
		{
			CUtil::WcsCpy(pFamily->sFontData.pEngName, wTemp);
			pFamily->sFontData.nFontEncodingType = GetFontEncodingFlag(fontFace);
		}
		
#ifdef USE_EMFAMILY_HEADER_FONT
		BrBOOL bToUpper = BrFALSE;
		BrBOOL bRealEMFont = BrFALSE;
		BrINT nBaseMapFontIndex = -1;
		FT_Int nFontFlag = BoraFontComm::GetFontFlag(wTemp, nFontLen, 0, m_bLoadedPurchaseFont, bRealEMFont, nBaseMapFontIndex, bToUpper);
		eBEFFONT_TABLE_TYPE emfIndex = findEmbFontIndex(nFontFlag);
		if (bRealEMFont && emfIndex > eEF_NoneFont && emfIndex < eEF_MaxFontType)
			m_bUseEFFace[emfIndex] = BrFALSE;
#endif
	}
#endif
}

void BoraFont::setSystemFontPath(BrCHAR* pFontPath, FT_Face fontFace, BrINT nFontFileFaceIndex, BrBOOL bDirectLoading)
{
#ifdef USE_COMMON_INTERFACE	
	const char* ps_family_name = BrNULL;
	BrCHAR* family_name_utf8 = BrNULL;
	BrWORD* fontName_unicode = BrNULL;

	BrINT nFontFileIdx = addFontFilePath(pFontPath);
	family_name_utf8 = get_family_name_utf8(fontFace, &fontName_unicode);
	ps_family_name = FT_Get_Postscript_Name(fontFace);

	LPBrFontStruct pRuntimeLoadFont = (LPBrFontStruct)PoSysMalloc(BrSizeOf(BrFontStruct));
	memset(pRuntimeLoadFont, 0, BrSizeOf(BrFontStruct));

	if (fontName_unicode)
		CUtil::WcsCpy(pRuntimeLoadFont->pFamily_name, fontName_unicode);
	
	if (ps_family_name)
		BrMultiByteToWideChar(CP_ACP, ps_family_name, strlen(ps_family_name), pRuntimeLoadFont->pFamily_ps_name, sizeof(pRuntimeLoadFont->pFamily_ps_name));

	if (fontFace->style_name)
	{
#if defined( WIN32 ) || defined( _WIN64 )
		//[17.10.17][sglee1206] Windows인 경우 _TRUNCATE를 사용하여 Crash 수정[XPD-18926]
		strncpy_s(pRuntimeLoadFont->pStyle_name, sizeof(pRuntimeLoadFont->pStyle_name), fontFace->style_name, _TRUNCATE);
#else
		strncpy_s(pRuntimeLoadFont->pStyle_name, sizeof(pRuntimeLoadFont->pStyle_name), fontFace->style_name, strlen(fontFace->style_name));
#endif
	}

	pRuntimeLoadFont->style_Flag = fontFace->style_flags;
	pRuntimeLoadFont->nTypefaceListIndex = -1;
	pRuntimeLoadFont->nFontFileIdx = nFontFileIdx;
	pRuntimeLoadFont->nFontFileFaceIndex = nFontFileFaceIndex;


	pRuntimeLoadFont->pHJCTData = BrNULL;

	//[15.04.10][sglee1206] 세팅 실패 시 처리 추가 필요
	//[19.11.08][sglee1206] 파일 입출력을 사용하므로 속도에 영향이 있어서 조건 추가함
	//함초롬바탕, 함초롬돋움 폰트 외에는 HJCT 테이블 존재하지 않음. 만약 있다면 그때 변경 필요
	if(fontFace->family_name != BrNULL &&
		(fontFace->family_name[0] == 'H' || fontFace->family_name[0] == 'h') &&
		(fontFace->family_name[1] == 'C' || fontFace->family_name[1] == 'c') &&
		(fontFace->family_name[2] == 'R' || fontFace->family_name[2] == 'r'))
		pRuntimeLoadFont->bHasHJCTTable = setHJCTTableData(pFontPath,&pRuntimeLoadFont->pHJCTData);
	else
	{
		pRuntimeLoadFont->bHasHJCTTable = false;
	}
		

	//pRuntimeLoadFont와 1대1 매칭
	LPBrFontStyleIdxNode pNode = (LPBrFontStyleIdxNode)PoSysMalloc(BrSizeOf(BrFontStyleIdxNode));
	eFontStyleIndex changeIdx = getFontListIndexStyleValue(fontFace->style_name);

	pNode->pPrev = pNode->pNext = BrNULL;
	pNode->eStyle = changeIdx;
	pNode->nPrio = 5;
	pNode->nGlyphCount = fontFace->num_glyphs;
	pNode->nFontIndex = m_nRuntimeLoadFontCount;

	// prio setting 필요
	
	
#if defined( USE_PC_VERSION_FONT ) && defined( USE_PANOSE_INFO )
	TT_OS2* os2_table = (TT_OS2*)FT_Get_Sfnt_Table(fontFace, ft_sfnt_os2);
	if( os2_table)
	{
		//pRuntimeLoadFont->nPanose = os2_table->panose;
		for(int i=0; i< 10; i++)
		{
			pRuntimeLoadFont->nPanose[i] = os2_table->panose[i];
		}
	}
#endif //USE_PANOSE_INFO

	//////////////// same Family Set ////////////////
	BrINT nTypeFaceListSize = m_aTypeFaceList.size();
	BrBOOL bAddingSysFontFamily = BrFALSE;
	
	//Family name으로 찾기(일반적으로는 해당 Case에서 찾음
	int sfIdx = 0;
	for(sfIdx = nTypeFaceListSize - 1;  sfIdx >= 0; sfIdx--)
	{
		LPBrTypefaceStruct pFamily = m_aTypeFaceList.at(sfIdx);
		if(fontName_unicode && pFamily->pFamily_name &&
			!FontWcsCmp(pFamily->pFamily_name, fontName_unicode) )
		{
			if(changeIdx >= 0 && pFamily->nFontIndices[changeIdx] == BrNULL)
			{
				pFamily->nFontIndices[changeIdx] = pNode;
				pFamily->nStyleCnt[changeIdx] = 1;
				pFamily->nCountSameFamily++;
				bAddingSysFontFamily = BrTRUE;
				pRuntimeLoadFont->nTypefaceListIndex = sfIdx;
			}

			if(changeIdx < 0)
				changeIdx = eStyleExtra1;

			//[15.05.26][sglee1206] Polaris New Dotum 등 Font 한글 Famlily Name이 변경되어 다중으로 처리된 경우로 인해 수정 
			if( !bAddingSysFontFamily &&
				pFamily->nFontIndices[eStyleExtra1] == BrNULL && (fontFace->style_name == BrNULL || changeIdx == eStyleExtra1)
				)
			{
				pFamily->nFontIndices[eStyleExtra1] = pNode;
				pFamily->nStyleCnt[eStyleExtra1] = 1;
				pFamily->nCountSameFamily++;
				bAddingSysFontFamily = BrTRUE;
				pRuntimeLoadFont->nTypefaceListIndex = sfIdx;
			}
			
			if(!bAddingSysFontFamily)
			{
				LPBrFontStyleIdxNode pList = pFamily->nFontIndices[changeIdx];
				
				if(pList->nPrio > pNode->nPrio || (pList->nPrio == pNode->nPrio && pList->nGlyphCount < pNode->nGlyphCount))
				{
					pList->pPrev = pNode;
					pNode->pNext = pList;
					pFamily->nFontIndices[changeIdx] = pNode;
				}
				else
				{
					while(pList->pNext != BrNULL && 
						(pList->pNext->nPrio < pNode->nPrio || (pList->pNext->nPrio == pNode->nPrio && pList->pNext->nGlyphCount > pNode->nGlyphCount)))
						pList = pList->pNext;

					if(pList->pNext != BrNULL)
						pList->pNext->pPrev = pNode;
					pNode->pNext = pList->pNext;

					pList->pNext = pNode;
					pNode->pPrev = pList;
				}

				pFamily->nStyleCnt[changeIdx] += 1;
				pFamily->nCountSameFamily++;
				bAddingSysFontFamily = BrTRUE;
				pRuntimeLoadFont->nTypefaceListIndex = sfIdx;
			}

			break;
		}
	}
	if(!bAddingSysFontFamily)
	{
		LPBrTypefaceStruct pFamily = BrNULL;
		pFamily = (LPBrTypefaceStruct)PoSysMalloc(BrSizeOf(BrTypefaceStruct));
		pFamily->sFontData.nFontEncodingType = 0;

		setTypefaceStructName(fontFace, fontName_unicode, family_name_utf8, pFamily);
		
		if (changeIdx < 0)
			changeIdx = eStyleExtra1;

		pFamily->nFontIndices[changeIdx] = pNode;
		pFamily->nStyleCnt[changeIdx] = 1;
		////////////////////////////////////////////////////////////
		sfIdx = m_aTypeFaceList.size();
		//Add Name Cache
		BrINT Index = setSystemFontNameCache(fontFace,sfIdx);

		if(sfIdx == Index)
			m_aTypeFaceList.add(pFamily);
		else
		{
			//
			PoSysFree(pFamily);
			pFamily = m_aTypeFaceList.at(Index);

			BrINT pFamilyStyleName = getFontListIndexStyleValue(fontFace->style_name);

			if(pNode->eStyle == 0 && pFamilyStyleName != 0)
			{
				memset(pFamily->pFamily_name,0,sizeof(pFamily->pFamily_name));
				CUtil::WcsCpy(pFamily->pFamily_name, fontName_unicode);
			}

			LPBrFontStyleIdxNode pList = pFamily->nFontIndices[changeIdx];
			if(pList == BrNULL)
			{
				pFamily->nFontIndices[changeIdx] = pNode;
				pFamily->nStyleCnt[changeIdx] = 1;
			}
			else
			{
				if(pList->nPrio > pNode->nPrio || (pList->nPrio == pNode->nPrio && pList->nGlyphCount < pNode->nGlyphCount))
				{
					pList->pPrev = pNode;
					pNode->pNext = pList;
					pFamily->nFontIndices[changeIdx] = pNode;
				}
				else
				{
					while(pList->pNext != BrNULL && 
						(pList->pNext->nPrio < pNode->nPrio || (pList->pNext->nPrio == pNode->nPrio && pList->pNext->nGlyphCount > pNode->nGlyphCount)))
						pList = pList->pNext;

					if(pList->pNext != BrNULL)
						pList->pNext->pPrev = pNode;
					pNode->pNext = pList->pNext;

					pList->pNext = pNode;
					pNode->pPrev = pList;
				}

				pFamily->nStyleCnt[changeIdx] += 1;
			}
			pFamily->nCountSameFamily++;
			bAddingSysFontFamily = BrTRUE;
		}
		pRuntimeLoadFont->nTypefaceListIndex = Index;
	}

#if !defined( SUPPORT_ADD_FONT_TABLE )
	if(pRuntimeLoadFont->nFontFileIdx >= 0)
		m_aLoadFontFilePath.at(pRuntimeLoadFont->nFontFileIdx)->fontStIndices->add(pRuntimeLoadFont->nTypefaceListIndex);
#endif

	m_RuntimeLoadFont.add(pRuntimeLoadFont);
	m_nRuntimeLoadFontCount++;

	if (fontName_unicode)
		PoSysFree(fontName_unicode);

	if (family_name_utf8)
		PoSysFree(family_name_utf8);

	if ( !bDirectLoading )
		FT_Done_Face(fontFace);
#ifdef USE_PRIMARY_FONT
	//[16.04.25][sglee1206] WebView 요구사항 [CHI-955]
	if(m_bSetPrimaryFont == BrFALSE)
	{
		if(loadSystemFontFile(m_RuntimeLoadFont.at(m_nRuntimeLoadFontCount-1)->pFamily_name) >= 0)
			m_bSetPrimaryFont = BrTRUE;
	}
#endif
#endif//ifdef USE_COMMON_INTERFACE
}

bool BoraFont::convertFontTableToSendData()
{
	bool bRet = false;
#if defined( SUPPORT_ADD_FONT ) && defined( SUPPORT_ADD_FONT_TABLE )
	BrINT nRuntimeLoadFontSize = BrSizeOf(BrFontStruct) * m_RuntimeLoadFont.size() + BrSizeOf(BrINT);
	BrINT nTypeFaceListSize = BrSizeOf(BrTypefaceStruct) * m_aTypeFaceList.size() + BrSizeOf(BrINT);
	BrINT nLoadFontFilePathSize = BrSizeOf(BrLoadFontFileList) * m_aLoadFontFilePath.size() + BrSizeOf(BrINT);

	BrINT nFontNameListSize = 0;
#ifdef USE_PC_VERSION_FONT
	nFontNameListSize = ((BrSizeOf(BrWORD) * MAX_FONT_LENGTH)  + BrSizeOf(BrINT)) * m_pFontNameList->GetSize()  + BrSizeOf(BrINT);
#endif
	BrINT fontDataSize = nRuntimeLoadFontSize + nTypeFaceListSize + nLoadFontFilePathSize + nFontNameListSize;
	BYTE* fontTable = (BYTE*)BrMalloc(fontDataSize);

	if(!fontTable)
		return bRet;

	BYTE *offset = fontTable;
	memset(offset,0,fontDataSize);

	/////////////////////m_RuntimeLoadFont///////////////////////
	BrINT nRuntimeLoadFontCount = m_RuntimeLoadFont.size();
	memcpy(offset,&nRuntimeLoadFontCount,BrSizeOf(BrINT));
	offset += BrSizeOf(BrINT);

	for(int i = 0; i < nRuntimeLoadFontCount; i++)
	{
		LPBrFontStruct pRuntimeLoadFont = m_RuntimeLoadFont.at(i);
		memcpy(offset,pRuntimeLoadFont,BrSizeOf(BrFontStruct));
		offset += BrSizeOf(BrFontStruct);
	}
	////////////////////////////////////////////////////////////

	/////////////////////m_aTypeFaceList///////////////////////
	BrINT nSysFontFamilyListCount = m_aTypeFaceList.size();
	memcpy(offset,&nSysFontFamilyListCount,BrSizeOf(BrINT));
	offset += BrSizeOf(BrINT);

	BrINT totalNodeCnt = 0;
	for(int i = 0; i < nSysFontFamilyListCount; i++)
	{
		LPBrTypefaceStruct pSysFontFamilyList = m_aTypeFaceList.at(i);
		memcpy(offset,pSysFontFamilyList,BrSizeOf(BrTypefaceStruct));
		offset += BrSizeOf(BrTypefaceStruct);
		totalNodeCnt += pSysFontFamilyList->nCountSameFamily;
	}
	////////////////////////////////////////////////////////////

	/////////////////////m_aLoadFontFilePath///////////////////////
	BrINT nSystemFontFilePathCount = m_aLoadFontFilePath.size();
	memcpy(offset,&nSystemFontFilePathCount,BrSizeOf(BrINT));
	offset += BrSizeOf(BrINT);

	for(int i = 0; i < nSystemFontFilePathCount; i++)
	{
		LPBrLoadFontFileList pSystemFontFilePath = getLoadFontFileList(i);
		if (pSystemFontFilePath)
		{
			memcpy(offset, pSystemFontFilePath, BrSizeOf(BrLoadFontFileList));
			((LPBrLoadFontFileList)offset)->bLoaded = BrFALSE;
			offset += BrSizeOf(BrLoadFontFileList);
		}
	}
	////////////////////////////////////////////////////////////
#ifdef USE_PC_VERSION_FONT
	/////////////////////m_pFontNameList///////////////////////
	BrINT nfontNameListCount = m_pFontNameList->GetSize();
	memcpy(offset,&nfontNameListCount,BrSizeOf(BrINT));
	offset += BrSizeOf(BrINT);

	BrWORD* fontName = BrNULL;
	BrINT fontIndex = 0;
	for(int i = 0; i < nfontNameListCount; i++)
	{
		fontName = m_pFontNameList->GetName(i);
		fontIndex = m_pFontNameList->GetFontListIndex(i);

		memcpy(offset,fontName,BrWcsLen(fontName)*BrSizeOf(BrWORD));
		offset += (BrSizeOf(BrWORD) * MAX_FONT_LENGTH);
		memcpy(offset,&fontIndex,BrSizeOf(BrINT));
		offset += BrSizeOf(BrINT);
	}
	////////////////////////////////////////////////////////////
#endif
	/////////////////////m_aTypeFaceList NODE///////////////////////
	
	//NodeData+(Style,StyleCnt)+nSysFontFamilyListCount+Size
	BrINT pStyleNodeTotalSize = 3*totalNodeCnt+(eFontStyleIndexMax*nSysFontFamilyListCount*2)+nSysFontFamilyListCount;
	BrINT nNodeTotalSize = (4*BrSizeOf(BYTE))+pStyleNodeTotalSize*BrSizeOf(BrINT);
	BYTE* pStyleNode = (BYTE*)BrMalloc(nNodeTotalSize);

	if(!pStyleNode)
	{
		BR_SAFE_FREE(fontTable);
		return bRet;
	}

	BYTE *nodeOffset = pStyleNode;
	memset(nodeOffset,0,nNodeTotalSize);
	
	nodeOffset[0] = 'N';nodeOffset[1] = 'O';nodeOffset[2] = 'D';nodeOffset[3] = 'E';
	nodeOffset += (4*BrSizeOf(BYTE));

	for(int i = 0; i < nSysFontFamilyListCount; i++)
	{
		LPBrTypefaceStruct pSysFontFamilyList = m_aTypeFaceList.at(i);
		memcpy(nodeOffset,&i,BrSizeOf(BrINT));
		nodeOffset += BrSizeOf(BrINT);
		for(int nStyleIdx = 0; nStyleIdx < eFontStyleIndexMax; nStyleIdx++)
		{
			//Style
			memcpy(nodeOffset,&nStyleIdx,BrSizeOf(BrINT));
			nodeOffset += BrSizeOf(BrINT);
			//Cnt
			memcpy(nodeOffset,&pSysFontFamilyList->nStyleCnt[nStyleIdx],BrSizeOf(BrINT));
			nodeOffset += BrSizeOf(BrINT);
			LPBrFontStyleIdxNode pFamily = pSysFontFamilyList->nFontIndices[nStyleIdx];
			for(int nFontIndex =0; nFontIndex < pSysFontFamilyList->nStyleCnt[nStyleIdx];nFontIndex++)
			{
				memcpy(nodeOffset,&pFamily->nPrio,BrSizeOf(BrINT));
				nodeOffset += BrSizeOf(BrINT);
				memcpy(nodeOffset,&pFamily->nGlyphCount,BrSizeOf(BrINT));
				nodeOffset += BrSizeOf(BrINT);
				memcpy(nodeOffset,&pFamily->nFontIndex,BrSizeOf(BrINT));
				nodeOffset += BrSizeOf(BrINT);
				pFamily = pFamily->pNext;
			}
		}
	}
	////////////////////////////////////////////////////////////

	BYTE* finalFontTable = (BYTE*)BrMalloc(fontDataSize+nNodeTotalSize);

	if(!finalFontTable)
	{
		BR_SAFE_FREE(fontTable);
		BR_SAFE_FREE(pStyleNode);
		return bRet;
	}
	offset = finalFontTable;
	memcpy(offset,fontTable,fontDataSize);
	offset += fontDataSize;
	memcpy(offset,pStyleNode,nNodeTotalSize);
	
	bRet = BSendFontInitializedTable(fontDataSize+nNodeTotalSize,(void*)finalFontTable);

	BR_SAFE_FREE(fontTable);
	BR_SAFE_FREE(pStyleNode);
	BR_SAFE_FREE(finalFontTable);
#endif//#if defined( SUPPORT_ADD_FONT ) && defined( SUPPORT_ADD_FONT_TABLE )
	return bRet;
}

bool BoraFont::convertGetDataToFontTable()
{
#if defined( SUPPORT_ADD_FONT ) && defined( SUPPORT_ADD_FONT_TABLE )
	int fontDataSize = 0;
	int nRuntimeLoadFont = m_nRuntimeLoadFontCount;
	BYTE* fontTable = (BYTE*)BGetFontInitializedTable(&fontDataSize);

	if(fontTable != BrNULL && fontDataSize > 0 )
	{
		BYTE *offset = fontTable;
		/////////////////////m_RuntimeLoadFont///////////////////////
		BrINT nRuntimeLoadFontCount = *((BrINT*)offset);
		offset += BrSizeOf(BrINT);

		for(int i = 0; i < nRuntimeLoadFontCount; i++)
		{
			LPBrFontStruct pRuntimeLoadFont = (LPBrFontStruct)PoSysMalloc(BrSizeOf(BrFontStruct));
			memcpy(pRuntimeLoadFont,offset,BrSizeOf(BrFontStruct));
			offset += BrSizeOf(BrFontStruct);
			m_RuntimeLoadFont.add(pRuntimeLoadFont);
			m_nRuntimeLoadFontCount++;
		}
		////////////////////////////////////////////////////////////


		/////////////////////m_aTypeFaceList///////////////////////
		BrINT nSysFontFamilyListCount = *((BrINT*)offset);
		offset += BrSizeOf(BrINT);

		for(int i = 0; i < nSysFontFamilyListCount; i++)
		{
			LPBrTypefaceStruct pSysFontFamilyList = (LPBrTypefaceStruct)PoSysMalloc(BrSizeOf(BrTypefaceStruct));
			memcpy(pSysFontFamilyList,offset,BrSizeOf(BrTypefaceStruct));
			offset += BrSizeOf(BrTypefaceStruct);
			m_aTypeFaceList.add(pSysFontFamilyList);
		}
		////////////////////////////////////////////////////////////
		/////////////////////m_aLoadFontFilePath///////////////////////
		BrINT nSystemFontFilePathCount = *((BrINT*)offset);
		offset += BrSizeOf(BrINT);

		for(int i = 0; i < nSystemFontFilePathCount; i++)
		{
			LPBrLoadFontFileList pSystemFontFilePath = (LPBrLoadFontFileList)PoSysMalloc(BrSizeOf(BrLoadFontFileList));
			memcpy(pSystemFontFilePath,offset,BrSizeOf(BrLoadFontFileList));
			pSystemFontFilePath->bLoaded = BrFALSE;
			m_aLoadFontFilePath.add(pSystemFontFilePath);
			offset += BrSizeOf(BrLoadFontFileList);
		}
		////////////////////////////////////////////////////////////
#ifdef USE_PC_VERSION_FONT
		/////////////////////fontNameList///////////////////////
		BrINT nfontNameListCount = *((BrINT*)offset);
		offset += BrSizeOf(BrINT);


		BrINT nInsertResult = -1;
		BrWORD* fontName = BrNULL;
		BrINT fontIndex = 0;
		int nLength = 0;
		for(int i = 0; i < nfontNameListCount; i++)
		{
			nLength = BrMIN(BrWcsLen((BrWORD*)offset), MAX_FONT_LENGTH-1);
			fontName = (BrLPWORD)PoSysCalloc(nLength+1, BrSizeOf(BrWORD));
			CUtil::WcsNcpy(fontName, (BrWORD*)offset, nLength);
			offset += (BrSizeOf(BrWORD) * MAX_FONT_LENGTH);

			fontIndex = *((BrINT*)offset);
			offset += BrSizeOf(BrINT);
			nInsertResult = m_pFontNameList->Insert(fontName,fontIndex);
		}
		////////////////////////////////////////////////////////////
#endif
		/////////////////////m_aTypeFaceList NODE///////////////////////
		if(offset[0] == 'N' && offset[1] == 'O'&& offset[2] == 'D'&& offset[3] == 'E')
		{
			offset += (4*BrSizeOf(BYTE));
			for(int i = 0; i < nSysFontFamilyListCount; i++)
			{
				BrINT nFontFamilyListIdx = *((BrINT*)offset);
				offset += BrSizeOf(BrINT);
				if(nFontFamilyListIdx != i)
					BrTrace("");

				LPBrTypefaceStruct pSysFontFamilyList = m_aTypeFaceList.at(i);
				for(int nStyleIdx = 0; nStyleIdx < eFontStyleIndexMax; nStyleIdx++)
				{
					//Style
					BrINT nStyleCheck = *((BrINT*)offset);
					offset += BrSizeOf(BrINT);

					if(nStyleCheck != nStyleIdx)
						BrTrace("");
					//Cnt
					BrINT nNodeCnt = *((BrINT*)offset);
					offset += BrSizeOf(BrINT);

					if(nNodeCnt != pSysFontFamilyList->nStyleCnt[nStyleIdx])
						BrTrace("");

					pSysFontFamilyList->nFontIndices[nStyleIdx] = BrNULL;

					LPBrFontStyleIdxNode pFamily = pSysFontFamilyList->nFontIndices[nStyleIdx];
					for(int nFontIndex =0; nFontIndex < nNodeCnt;nFontIndex++)
					{
						LPBrFontStyleIdxNode pNode = (LPBrFontStyleIdxNode)PoSysMalloc(BrSizeOf(BrFontStyleIdxNode));
						pNode->pPrev = pNode->pNext = BrNULL;

						pNode->nPrio = *((BrINT*)offset);
						offset += BrSizeOf(BrINT);
						pNode->nGlyphCount = *((BrINT*)offset);
						offset += BrSizeOf(BrINT);
						pNode->nFontIndex = *((BrINT*)offset);
						offset += BrSizeOf(BrINT);
						pNode->eStyle = (eFontStyleIndex)nStyleIdx;

						if(pFamily == BrNULL || nFontIndex == 0)
							pSysFontFamilyList->nFontIndices[nStyleIdx] = pNode;
						else
						{
							pFamily->pNext = pNode;
							pNode->pPrev = pFamily;
						}
						pFamily = pNode;
					}
				}

			}

		}
		////////////////////////////////////////////////////////////

		/////////////// HJCTTable setting ////////////////////////////
		for(int i = 0; i < nRuntimeLoadFontCount; i++)
		{
			LPBrFontStruct pRuntimeLoadFont = m_RuntimeLoadFont.at(i);
			LPBrLoadFontFileList pSystmeFontFile = getLoadFontFileList(pRuntimeLoadFont->nFontFileIdx);
			if(pRuntimeLoadFont->bHasHJCTTable && pSystmeFontFile)
			{
				BrCHAR* pFontPath = pSystmeFontFile->pFontPath;
				pRuntimeLoadFont->bHasHJCTTable = setHJCTTableData(pFontPath,&pRuntimeLoadFont->pHJCTData);
			}
			else
				pRuntimeLoadFont->pHJCTData = BrNULL;
		}

#ifdef USE_PRIMARY_FONT
		//[16.04.25][sglee1206] WebView 요구사항 [CHI-955]
		if(m_bSetPrimaryFont == BrFALSE)
		{
			if(loadSystemFontFile(m_RuntimeLoadFont.at(nRuntimeLoadFont)->pFamily_name) >= 0)
				m_bSetPrimaryFont = BrTRUE;
		}
#endif
		return true;
	}
#endif//#if defined( SUPPORT_ADD_FONT ) && defined( SUPPORT_ADD_FONT_TABLE )	
	return false;
}

BrINT BoraFont::loadSystemFontFile(BrINT nRuntimeFontIdx, BrWORD* pFontName)
{	
	BrINT nFindFontIndex = -1;
#if defined( SUPPORT_ADD_FONT )
	if(nRuntimeFontIdx < 0 || nRuntimeFontIdx >= m_aTypeFaceList.size()) {
		return loadSystemFontFile(pFontName);
	}	

	if (pFontName == BrNULL)
		pFontName = m_pFontName;

	LPBrTypefaceStruct pFamily = m_aTypeFaceList.at(nRuntimeFontIdx);

	BrINT prevFontCount = GetFontFaceCnt();
	BrINT nFontCount = pFamily->nCountSameFamily;
	BrINT n = -1;
	BrINT nIdx = 0;
	BrBYTE firstMatchStyle = eFontStyleIndexMax;
	//Same Family Font Load
	while(nFontCount > 0)
	{
		n = pFamily->nStyleCnt[nIdx];
		if(n > 0 )
		{
			LPBrFontStyleIdxNode pNode = pFamily->nFontIndices[nIdx];
			while(pNode != BrNULL)
			{
				if (firstMatchStyle == eFontStyleIndexMax)
					firstMatchStyle = nIdx;
				nFontCount--;
				LPBrLoadFontFileList pSystmeFontFile = getLoadFontFileList(getLoadFontStFileIndex(pNode->nFontIndex));
				if (pSystmeFontFile && pSystmeFontFile->bLoaded == BrFALSE)
				{
					addFontFace(pSystmeFontFile->pFontPath, pNode->nFontIndex);
					pSystmeFontFile->bLoaded = BrTRUE;
				}
				pNode = pNode->pNext;
			}
		}
		nIdx++;
	}

	//Check Current Font
	for(BrINT idx = prevFontCount; idx < GetFontFaceCnt(); idx++)
	{
		if (IsFamilyFontName(m_aTypeFaceList.at(nRuntimeFontIdx)->pFamily_name, GetFontFaceByIndex(idx), firstMatchStyle))
		{			
			nFindFontIndex = idx;
			break;
		}
	}
#else
	return loadSystemFontFile(pFontName);
#endif // defined( SUPPORT_ADD_FONT ) && defined( USE_PC_VERSION_FONT )
	return nFindFontIndex;
}

BrINT  BoraFont::loadDefaultSystemFont()
{
	BrINT nLoadFontCount = 0;
#ifdef SUPPORT_ADD_FONT 
#if !defined( USE_EMBEDDED_SYMBOL_FONT )
	//[16.01.14][sglee1206] 기호의 경우 폰트명과 상관없이 처리되는 경우가 존재하여 기본적으로 읽어야 함.(ex: HWP)
	if(loadSystemFontFile((unsigned short*)u"Symbol") >= 0)
		m_nBaseIndex++;
	if(loadSystemFontFile((unsigned short*)u"Wingdings") >= 0)
		m_nBaseIndex++;
	if(loadSystemFontFile((unsigned short*)u"Wingdings 2") >= 0)
		m_nBaseIndex++;
	if(loadSystemFontFile((unsigned short*)u"Wingdings 3") >= 0)
		m_nBaseIndex++;
	if(loadSystemFontFile((unsigned short*)u"Webdings") >= 0)
		m_nBaseIndex++;
#endif

#ifdef USE_PC_VERSION_FONT
	const char* mathFontName = BGetMathFontName();
	if(mathFontName != NULL)
	{
		BrWCHAR pFontName[MAX_FONT_LENGTH] = { 0, };
		int nSize = BrStrLen(mathFontName);
		nSize = BrMultiByteToWideChar(CP_UTF8, mathFontName, nSize, (BrLPWSTR)pFontName, MAX_FONT_LENGTH);

		m_pSystemMathFontName = (BrWORD*)PoSysCalloc(BrWcsLen(pFontName)+1, sizeof(BrWORD));
		CUtil::WcsCpy(m_pSystemMathFontName, pFontName);
		BrINT nPrevFaceCnt = GetFontFaceCnt();
		if(loadSystemFontFile(m_pSystemMathFontName) >= 0)
		{
			m_nBaseIndex += (GetFontFaceCnt() - nPrevFaceCnt);
		}
		else
		{
			PoSysFree(m_pSystemMathFontName);
			m_pSystemMathFontName = BrNULL;
		}
	}
#endif


	BrINT nDefaultFontCount = 0;
	char** _defaultFontList = BDefaultFontList(&nDefaultFontCount);

	if(nDefaultFontCount > 0 && _defaultFontList != NULL)
	{
		BrWCHAR pFontName[MAX_FONT_LENGTH] = { 0, };
		
		for(int i= 0; i < nDefaultFontCount && _defaultFontList[i] != NULL; i++)
		{
			memset(pFontName, 0, MAX_FONT_LENGTH * BrSizeOf(BrWCHAR));
			int nSize = BrStrLen(_defaultFontList[i]);
			nSize = BrMultiByteToWideChar(CP_UTF8, _defaultFontList[i], nSize, (BrLPWSTR)pFontName, MAX_FONT_LENGTH);

			if(loadSystemFontFile(pFontName) >= 0)
				nLoadFontCount++;
		}
	}

	//[16.02.25][sglee1206] MS 기본 폰트중 Glyph이 많은 편인 Arial Unicode MS를 기본적으로 읽도록 추가함
	if(loadSystemFontFile((unsigned short*)u"Arial Unicode MS") >= 0)
		nLoadFontCount++;

	//[16.08.31][sglee1206] PD Team 요구사항. 중문 Default Font를 Simsun으로 처리 요청[XPD-8806][XPD-8818]
	if(loadSystemFontFile((unsigned short*)u"SimSun") >= 0)
		nLoadFontCount++;

	//[17.04.20][sglee1206] 4Bytes Character 0x215E5 미출력 이슈 처리를 위해 load되는 폰트 추가함[CSP-4724]
	if(loadSystemFontFile((unsigned short*)u"SimSun-ExtB") >= 0)
		nLoadFontCount++;

	//[16.05.12][sglee1206] 중문 대체 폰트. Arial Unicode MS가 없는 경우 간체 출력시 필요[AOM-6899]
	if(loadSystemFontFile((unsigned short*)u"Microsoft YaHei") >= 0)
		nLoadFontCount++;

	//[17.10.16][sglee1206] Registry FontLInk 정보를 보면 SimSun에 없는 경우 Batang으로 대체됨. 따라서 SimSun에 없는 한자는 Batang으로 출력[XPD-18884]
	//Jisu에서 Sheet에 한글 작성 시 한글 관련 폰트가 아무것도 Load되지 않은 상태로 입력되는 경우 공백으로 나오는 이슈 수정[XPD-17533], [XPD-17535], [XPD-17536]
	if(loadSystemFontFile((unsigned short*)u"Batang") >= 0)
		nLoadFontCount++;

	if (loadSystemFontFile((unsigned short*)u"Malgun Gothic") >= 0)
		nLoadFontCount++;

	//[16.05.12][sglee1206] 힌디어(Devanagari etc.) 대체 폰트. Arial Unicode MS가 없는 경우 출력시 필요[AOM-6900]
	//그러나 실제 입력시에는 대체가 아닌 폰트명이 변경되어야 함
	if(loadSystemFontFile((unsigned short*)u"Mangal") >= 0)
		nLoadFontCount++;
	if(loadSystemFontFile((unsigned short*)u"Nirmala UI") >= 0)
		nLoadFontCount++;

	//[18.01.18][sglee1206] 한양견명조와 같이 명조계열인 경우 0x2018등이 Times New Roman으로 대체되므로 Load함
	//BoraFontComm::IsHFTExcept(ch) 함수 참고
	if(loadSystemFontFile((unsigned short*)u"Times New Roman") >= 0)
		nLoadFontCount++;

#ifdef KVIEWER_MODIFIED
	if(loadSystemFontFile("\xED\x95\x9C\xEC\xBB\xB4\xEB\xB0\x94\xED\x83\x95") >= 0)
		nLoadFontCount++;

	if(loadSystemFontFile("\xED\x95\x9C\xEC\xBB\xB4\xEB\x8F\x8B\xEC\x9B\x80") >= 0)
		nLoadFontCount++;

	if(loadSystemFontFile("\xED\x95\xA8\xEC\xB4\x88\xEB\xA1\xAC\xEB\xB0\x94\xED\x83\x95") >= 0)
		nLoadFontCount++;

	if(loadSystemFontFile("\xED\x95\xA8\xEC\xB4\x88\xEB\xA1\xAC\xEB\x8F\x8B\xEC\x9B\x80") >= 0)
		nLoadFontCount++;
#endif //KVIEWER_MODIFIED

	if(loadSystemFontFile((unsigned short*)u"Helvetica") >= 0)
		nLoadFontCount++;
	if(loadSystemFontFile((unsigned short*)u"PingFang SC") >= 0)
		nLoadFontCount++;
	if(loadSystemFontFile((unsigned short*)u"Heiti SC") >= 0)
		nLoadFontCount++;
	if(loadSystemFontFile((unsigned short*)u"PingFang TC") >= 0)
		nLoadFontCount++;
	if(loadSystemFontFile((unsigned short*)u"Heiti TC") >= 0)
		nLoadFontCount++;
	if(loadSystemFontFile((unsigned short*)u"Devanagari MT") >= 0)
		nLoadFontCount++;

	if (loadSystemFontFile((unsigned short*)u"Segoe UI Emoji") >= 0)
		nLoadFontCount++;

	if(loadSystemFontFile((unsigned short*)u"Apple Color Emoji") >= 0)
		nLoadFontCount++;

	if(loadSystemFontFile((unsigned short*)u"Noto Color Emoji") >= 0)
		nLoadFontCount++;

	//[16.09.26][sglee1206] 기존에 삭제된 Emoji Font 처리 [CAM-771]
	//기존 삭제된 리비전은 rev.4211로 7.0기준으로는 73636
	if (loadSystemFontFile((unsigned short*)u"Segoe UI Symbol") >= 0)
		nLoadFontCount++;

#endif//#ifdef SUPPORT_ADD_FONT
	return nLoadFontCount;
}

BrINT BoraFont::loadSystemFontFile(BrWORD* pFontName)
{	
	BrINT nFindFontIndex = -1;
#ifdef SUPPORT_ADD_FONT
	if(pFontName == BrNULL)
		pFontName = m_pFontName;

	BrINT nRuntimeFontIndex = -1;
	BrINT nRet = getFontNameListIndex(pFontName);
	if (nRet > -1) {
		nRuntimeFontIndex = m_pFontNameList->GetFontListIndex(nRet);
	}
	if (nRuntimeFontIndex >= 0 && nRuntimeFontIndex < m_aTypeFaceList.size())
		return loadSystemFontFile(nRuntimeFontIndex, pFontName);

	BrWORD* pSystemFontHName = BrNULL;
	BrINT nTypeFaceListSize = m_aTypeFaceList.size();
	for(int i = nTypeFaceListSize -1;  i >= 0; i--)
	{
		LPBrTypefaceStruct pFamily = m_aTypeFaceList.at(i);

		pSystemFontHName = BrNULL;
		pSystemFontHName = pFamily->sFontData.pLocName;

		if(BrWcsLen(pSystemFontHName) > 0 && !FontWcsCmp(pFontName,pSystemFontHName))
		{
			BrINT prevFontCount = GetFontFaceCnt();
			BrINT nFontCount = pFamily->nCountSameFamily;
			BrINT n = -1;
			BrINT nIdx = 0;
			//Same Family Font Load
			while(nFontCount > 0)
			{
				n = pFamily->nStyleCnt[nIdx];
				if(n >= 0 )
				{
					LPBrFontStyleIdxNode pNode = pFamily->nFontIndices[nIdx];
					while(pNode != BrNULL)
					{
						nFontCount--;
						LPBrLoadFontFileList pSystmeFontFile = getLoadFontFileList(getLoadFontStFileIndex(pNode->nFontIndex));

						if (pSystmeFontFile && pSystmeFontFile->bLoaded == BrFALSE)
						{
							addFontFace(pSystmeFontFile->pFontPath, pNode->nFontIndex);
							pSystmeFontFile->bLoaded = BrTRUE;

							//TTC와 같이 하나의 폰트파일에 여러 fontface 존재시
							if (pSystmeFontFile->nFontFaceCount > 1)
							{
								for (BrINT idx = prevFontCount; idx < GetFontFaceCnt(); idx++)
								{
									int prev = BrMAX(n - 32, 0);
									int next = BrMIN(n + 32, m_nRuntimeLoadFontCount);
									for (int checkIdx = prev; checkIdx < next; checkIdx++)
									{
										if (getLoadFontStFileIndex(pNode->nFontIndex) == getLoadFontStFileIndex(checkIdx))
										{
											if (!FontWcsCmp(GetFamilyNameByIndex(idx), m_RuntimeLoadFont.at(checkIdx)->pFamily_name))
											{
												GetFontFaceByIndex(idx)->nFontListIndex = checkIdx;
												break;
											}
										}
									}
								}
							}
						}
						pNode = pNode->pNext;
					}
				}
				nIdx++;
			}

			//Check Current Font
			for(BrINT idx = prevFontCount; idx < GetFontFaceCnt(); idx++)
			{
				if (IsFamilyFontName(pFontName, GetFontFaceByIndex(idx), 0, pSystemFontHName))
				{			
					nFindFontIndex = idx;
					break;
				}
			}
		}
		else
		{
			BrINT prevFontCount = GetFontFaceCnt();
			BrINT nFontCount = pFamily->nCountSameFamily;
			BrINT n = -1;
			BrINT nIdx = 0;
			BrBOOL bFindFont = BrFALSE;
			while(nFontCount > 0 && bFindFont == BrFALSE)
			{
				n = pFamily->nStyleCnt[nIdx];
				if(n > 0 )
				{
					LPBrFontStyleIdxNode pNode = pFamily->nFontIndices[nIdx];
					while(pNode != BrNULL)
					{
						nFontCount--;
						LPBrLoadFontFileList pSystmeFontFile = getLoadFontFileList(getLoadFontStFileIndex(pNode->nFontIndex));
						if (pSystmeFontFile &&
							pSystmeFontFile->bLoaded == BrFALSE
							&& IsFamilyFontName(pFontName, BrNULL, 0, BrNULL, m_RuntimeLoadFont.at(pNode->nFontIndex)))
						{
							bFindFont = BrTRUE;
							break;
						}
						pNode = pNode->pNext;
					}
				}
				nIdx++;
			}

			if(bFindFont)
			{
				nFontCount = pFamily->nCountSameFamily;
				n = -1;
				nIdx = 0;
				BrBYTE firstMatchStyle = eFontStyleIndexMax;
				//Same Family Font Load
				while(nFontCount > 0)
				{
					n = pFamily->nStyleCnt[nIdx];
					if(n > 0 )
					{
						LPBrFontStyleIdxNode pNode = pFamily->nFontIndices[nIdx];
						while(pNode != BrNULL)
						{
							if (firstMatchStyle == eFontStyleIndexMax)
								firstMatchStyle = nIdx;
							nFontCount--;
							LPBrLoadFontFileList pSystmeFontFile = getLoadFontFileList(getLoadFontStFileIndex(pNode->nFontIndex));
							if (pSystmeFontFile && pSystmeFontFile->bLoaded == BrFALSE)
							{
								addFontFace(pSystmeFontFile->pFontPath, pNode->nFontIndex);
								pSystmeFontFile->bLoaded = BrTRUE;
							}
							pNode = pNode->pNext;
						}
					}
					nIdx++;
				}

				//Check Current Font
				for(BrINT idx = prevFontCount; idx < GetFontFaceCnt(); idx++)
				{
					if (IsFamilyFontName(pFontName, GetFontFaceByIndex(idx), firstMatchStyle))
					{			
						nFindFontIndex = idx;
						break;
					}
				}
			}
		}

		if(nFindFontIndex >= 0)
		{
			BrTrace("Find %s Font... finding Font : %s ", pFontName, GetFamilyNameByIndex(nFindFontIndex));
			break;
		}
	}
#endif//#ifdef SUPPORT_ADD_FONT	
	return nFindFontIndex;
}

/*
*	@author 		Andrew
*	@date  		2016.06.07
*	@params  	const char* $pFontName : font name
*	@return  		int : m_pFontNameList에서의 인덱스
*	@brief  		m_pFontNameList상에서 font name을 찾아서 인덱스를 리턴한다.
*/
int BoraFont::getFontNameUtf8ListIndex(const BrCHAR* pFontName)
{
	BrINT nRet = -1;
	BrWORD wFontName[MAX_FONT_LENGTH] = { 0, };
	if (pFontName != BrNULL)
	{
		BrINT nLen = BrMultiByteToWideChar(CP_UTF8, pFontName, BrStrLen(pFontName), wFontName, MAX_FONT_LENGTH);
		nLen = BrWcsLen(wFontName);

		if (nLen > 0)
		{
			nRet = m_pFontNameList->BinarySearch(wFontName);
		}
	}
	return nRet;
}

/*
*	@author 		Andrew
*	@date  		2016.06.07
*	@params  	const BrWORD* $pFontName : font name
*	@return  		int : m_pFontNameList에서의 인덱스
*	@brief  		m_pFontNameList상에서 font name을 찾아서 인덱스를 리턴한다.
*/
int BoraFont::getFontNameListIndex(const BrWORD* pFontName)
{
	BrINT nRet = -1;
	if(pFontName != BrNULL)
	{
		BrINT nLen = BrWcsLen(pFontName);
		if ( nLen > 0 )
		{
			nRet = m_pFontNameList->BinarySearch(pFontName);
		}
	}
	return nRet;
}

int BoraFont::getSysFontIndex(PO_Face face, int sysFontIdx)
{
	int nSysFontIndex = sysFontIdx;
#if defined( SUPPORT_ADD_FONT )
	BrWORD* sysFontName = BrNULL;	// sysFontIdx
	BrWORD* NameListIndexName = BrNULL;	// nFLIndex

	FT_String* curFamilyName = getPostScriptNameByFontFace(face);
	BrWORD curFamilyName_unicode[MAX_FONT_LENGTH] = { 0, };
	if (curFamilyName != BrNULL)
	{
		BrINT nLen = BrMultiByteToWideChar(CP_UTF8, curFamilyName, BrStrLen(curFamilyName), curFamilyName_unicode, MAX_FONT_LENGTH);
		nLen = BrWcsLen(curFamilyName_unicode);
	}

	BrINT nRet = getFontNameListIndex(curFamilyName_unicode);
	if (nRet < 0)
		nRet = getFontNameUtf8ListIndex((const char*)face->family_name_UTF8);
	if (nRet < 0)
		nRet = getFontNameUtf8ListIndex((const char*)face->ft_face->family_name);

	if(nRet >= 0)
	{
		//[16.10.25][sglee1206] 이미 제대로 된 Font Index를 넘겨줬는데 여기서 다시바꾸면서 문제가 발생함[XPD-11604]
		//[16.10.26][sglee1206] 어제 작업한 내용에서 미처리된 내용. TTC 파일의 경우 sysFontIdx가 동일하므로 문제가 발생[XPD-12085]
		//기존 방식으로 얻은 Index와 sysFontIdx에 해당하는 Font Name을 비교하여 맞는 것을 찾아 처리하도록 함
		//nSysFontIndex = m_pFontNameList->GetFontListIndex(nRet);
		BrINT nFLIndex = m_pFontNameList->GetFontListIndex(nRet);
		
		if (sysFontIdx >= 0)
		{
			LPBrFontStruct pRuntimeLoadFont = m_RuntimeLoadFont.at(sysFontIdx);
			sysFontName = BrWcsLen(pRuntimeLoadFont->pFamily_ps_name) > 0 ? pRuntimeLoadFont->pFamily_ps_name : pRuntimeLoadFont->pFamily_name;
		}
		BrBOOL bFind = BrFALSE;

		LPBrFontStyleIdxNode pNode = BrNULL;
		BrINT nStyleIdx = 0;
		while(nStyleIdx < eFontStyleIndexMax && bFind == BrFALSE)
		{
			pNode = m_aTypeFaceList.at(nFLIndex)->nFontIndices[nStyleIdx];
			while(pNode != BrNULL && bFind == BrFALSE)
			{
				if(nSysFontIndex < 0)
					nSysFontIndex = pNode->nFontIndex;

				LPBrFontStruct pRuntimeLoadFont = m_RuntimeLoadFont.at(pNode->nFontIndex);
				NameListIndexName = BrWcsLen(pRuntimeLoadFont->pFamily_ps_name) > 0 ? pRuntimeLoadFont->pFamily_ps_name : pRuntimeLoadFont->pFamily_name;

				if(sysFontName != BrNULL && !FontWcsCmp(sysFontName, curFamilyName_unicode))
				{
					bFind = BrTRUE;
					nSysFontIndex = sysFontIdx;
					//이경우에는 Cache도 변경해야할 것으로 판단됨...
				}
				else if(NameListIndexName != BrNULL && !FontWcsCmp(NameListIndexName, curFamilyName_unicode))
				{
					bFind = BrTRUE;
					nSysFontIndex = pNode->nFontIndex;
				}
				pNode = pNode->pNext;
			}
			nStyleIdx++;
		}
	}
#endif //defined( SUPPORT_ADD_FONT )
	return nSysFontIndex;
}

BrBOOL BoraFont::GetFontPoolData(LPBoraFontFileList pFontFileList)
{
	BrINT nCount = m_aFontDataPool.size();
	if (pFontFileList && nCount > 0)
	{
		pFontFileList->nCount = nCount;
		pFontFileList->pFontFile = m_aFontDataPool.data();
		return BrTRUE;
	}
	return BrFALSE;
}

void BoraFont::regFontDataPool(void* pFontData, BrINT nDataLen, PO_Face pFace, BrBYTE nStyle)
{
	BrUINT nIndex = m_aFontDataPool.size();
	m_aFontDataPool.resize(nIndex + 1);
	BoraFontFileInfo* pInfo = m_aFontDataPool.getAt(nIndex);
	pFace->nFontPoolIndex = nIndex;
	pInfo->pFontPtr = pFontData;

	//BTrace("pFace->nFontPoolIndex : %d, pFace->family_name : %s", pFace->nFontPoolIndex, pFace->family_name);

	if (nDataLen == 0)
	{
		pInfo->nType = FONTTYPE_FILE;
		pInfo->nLen = BrStrLen((char*)pFontData);
	}
	else
	{
		pInfo->nType = FONTTYPE_MEMORY;
		pInfo->nLen = nDataLen;
	}

	if (nStyle == eFontBold)
		pInfo->nType |= FONTSTYLE_BOLD;
	else if (nStyle == eFontItalic)
		pInfo->nType |= FONTSTYLE_ITALIC;
	else if (nStyle == eFontBoldItalic)
		pInfo->nType |= FONTSTYLE_BOLDITALIC;
}

bool BoraFont::getSystemFontName()
{
	int nFontCNTCheck = 0;
	BrBOOL bDirectLoading = BrTRUE;
#ifdef SUPPORT_ADD_FONT	
	bDirectLoading = BrFALSE;
#endif//#ifdef SUPPORT_ADD_FONT
	int nFontIndex = 0;
	int nTotalCount = 0;
	BrFontType* nType = (BrFontType*)PoSysCalloc(TTF_FONT_COUNT, sizeof(BrFontType));
	unsigned char** pFont = (unsigned char**)PoSysCalloc(TTF_FONT_COUNT, sizeof(unsigned char*));
	unsigned int* nSize = (unsigned int*)PoSysCalloc(TTF_FONT_COUNT, sizeof(unsigned int));
	BGetSystemFont(&nTotalCount, nType, pFont, nSize);	

	for (int i = 0; i < nTotalCount; i++)
	{
		m_pFontFiles[i].nType = nType[i];
		m_pFontFiles[i].nSize = nSize[i];

		if (m_pFontFiles[i].nType == FONTTYPE_FILE)
		{
			m_pFontFiles[i].pFontData = (unsigned char*)PoSysCalloc(BORA_FULLPATH_LENGTH, sizeof(unsigned char));
			if (m_pFontFiles[i].pFontData)
				strncpy_s((char*)m_pFontFiles[i].pFontData, sizeof(unsigned char) * BORA_FULLPATH_LENGTH, (char*)pFont[i], strlen((char*)pFont[i]));
		}
		else
		{
			m_pFontFiles[i].pFontData = (unsigned char*)PoSysCalloc(m_pFontFiles[i].nSize, sizeof(unsigned char));
			if (m_pFontFiles[i].pFontData)
				memcpy_s(m_pFontFiles[i].pFontData, m_pFontFiles[i].nSize, pFont[i], nSize[i]);
		}
	}

	for (int n=0;n<nTotalCount;n++)
	{
		FT_Face fontFace = BrNULL;
		if ( nType[n] == FONTTYPE_FILE )
		{
			nFontCNTCheck += addFontFile((BrLPCSTR)m_pFontFiles[n].pFontData, -1, n, bDirectLoading);
		}
		else
		{
			int nTTFCount = getMemoryFontFaceCount((BrBYTE*)m_pFontFiles[n].pFontData);
			
			for (int idx = 0; idx < nTTFCount; idx++)
			{
				if (addFontMemory((void*)m_pFontFiles[n].pFontData, m_pFontFiles[n].nSize, idx, fontFace, bDirectLoading))
				{
					int nFontIndex = addFontFaceByIndex(fontFace);
					PO_Face pFace = GetFontFaceByIndex(nFontIndex);
					if (bDirectLoading)
					{
						regFontDataPool(m_pFontFiles[n].pFontData, m_pFontFiles[n].nSize, pFace);
					}
					nFontCNTCheck++;
				}
			}
		}

#ifndef SUPPORT_ADD_FONT
		//해당 내용이 필요한지 검토 필요
		if (GetFontFaceCnt() == 1)
		{
			m_first_font_address = m_pFontFiles[n].pFontData;
			m_first_font_size = nSize[n];
		}			
#endif//#ifdef SUPPORT_ADD_FONT
	}
	PoSysFree(nType);
	PoSysFree(pFont);
	PoSysFree(nSize);

	return (nFontCNTCheck > 0);
}


void BoraFont::addFontFace(BrCHAR* pFontFilePath,BrINT sysFontIdx)
{
#ifdef SUPPORT_ADD_FONT
	if(pFontFilePath)
		addFontFile(pFontFilePath, sysFontIdx, 0, BrTRUE);
#endif	
}

void BoraFont::addFontCharmap(PO_Face fontFace)
{
#ifdef SUPPORT_ADD_FONT
	BrINT n;
	FT_Face face = fontFace->ft_face;
	FT_CharMap  charmap;
	BrBOOL bFindMSPlatform = BrFALSE;

	for (n = 0; n < face->num_charmaps; n++ )
	{		
		charmap = face->charmaps[n];
		if (charmap->platform_id == TT_PLATFORM_MICROSOFT)
		{
			if (bFindMSPlatform)
			{
				// 아래 조건의 경우 TT_MS_ID_UCS_4를 사용하는게 맞을듯... ex)Hiragino Gothic Pro W3 [CSP-8080]
				if (charmap->encoding_id == TT_MS_ID_UNICODE_CS &&
					face->charmaps[fontFace->nPrimaryCharmapIdx]->platform_id == TT_PLATFORM_MICROSOFT && face->charmaps[fontFace->nPrimaryCharmapIdx]->encoding_id == TT_MS_ID_UCS_4)
					BrTrace("%s font charmap is UCS 4...",face->family_name);
				else
					fontFace->nPrimaryCharmapIdx = n;
			}
			else
				fontFace->nPrimaryCharmapIdx = n;
			bFindMSPlatform = BrTRUE;
		}
		else if( charmap->platform_id == TT_PLATFORM_APPLE_UNICODE && face->family_name[0] == 0x41 && !FontStrCmp(face->family_name, "Apple Color Emoji") )
		{
			fontFace->nPrimaryCharmapIdx = n;
			bFindMSPlatform = BrTRUE;
		}
		//[16.07.19][sglee1206][CAM-1461] MAC font중 Zapf dingbats의 경우 platform_id가 TT_PLATFORM_MACINTOSH이므로 해당 부분 추가
		//[21.04.05][sglee1206][CSP-7976] 조건 추가
		else if(charmap->platform_id == TT_PLATFORM_MACINTOSH && charmap->encoding_id == TT_MAC_ID_ROMAN && charmap->encoding == FT_ENCODING_APPLE_ROMAN)
		{
			FT_ULong nCmapID = FT_Get_CMap_Language_ID(face->charmap);
			//http://www.unicode.org/Public/MAPPINGS/VENDORS/APPLE/Readme.txt 9- a)참고
			if (nCmapID == 0 &&
				(!FontStrCmp(face->family_name, "Symbol") || !FontStrCmp(face->family_name, "Zapf Dingbats") || !FontStrCmp(face->family_name, ".Keyboard")))
			{
				fontFace->nPrimaryCharmapIdx = n;
				bFindMSPlatform = BrTRUE;
			}
		}
	}
#endif //SUPPORT_ADD_FONT	
}

bool BoraFont::setHJCTTableData(BrCHAR* fontPath, BrBYTE** pHjctData)
{
#ifdef USE_COMMON_INTERFACE
	bool bFind = false;
	if(fontPath == BrNULL)
		return false;

	//////// file Data Read ////////
	BString strSrcFile = CUtil::UTF8ToBString((char*)fontPath);
	std::unique_ptr<BFile> file(BrNEW BFile);
	if ( !file->Open(strSrcFile, BMV_READ_ONLY) )
		return false;

	BrLONG len = 0;
	file->Seek(0L, SEEK_END);
	len = file->Tell();
	file->Seek(0L, SEEK_SET);

	//[16,11.30][sglee1206] len에 대한 예외처리 추가[AOM-18320]
	if (len <= 0)
	{
		return	false;
	}

	//tag Table Check
	int nTableDataSize = 0;
	BrBYTE* pFontTableData = getFontTableBuffer(nTableDataSize);
	if (pFontTableData == BrNULL)
	{
		return	false;
	}
	if ( file->Read(pFontTableData, nTableDataSize) <= 0 )
		return false;
	file->Seek(0L, SEEK_SET);
	////// 현재는 TTF라 가정하고 작성 ////////
	if(pFontTableData[0] == 't' && pFontTableData[1] == 't' && pFontTableData[2] == 'c' && pFontTableData[3] == 'f')
	{
		return	false;
	}

	BrINT pos = 12;
	BrINT tagLen =4;
	BrINT numTags = 0;
	BrBYTE tag[5] = {0,};
	BrBYTE* pTagData;

	{
		numTags = pFontTableData[4];
		numTags = (numTags << 8) +pFontTableData[5];
	}
	for(int i = 0; i< numTags; i++)
	{
		pTagData = pFontTableData+(pos*(i+1))+tagLen*i;
		memcpy((void*)tag,pTagData,4);
		if(tag[0] == 'H' && tag[1] == 'J' && tag[2] == 'C' && tag[3] == 'T')
		{
			bFind = true;
			break;
		}
	}

	if(bFind)
	{
		BrBYTE* pFontData;
		pFontData = (BrBYTE*)BrCalloc(len, BrSizeOf(BrBYTE));
		if (pFontData == BrNULL)
		{
			return	BrFALSE;
		}
		file->Read(pFontData,len);

		BrINT offset,Length;
		{
			offset = 0;
			offset = pTagData[8];
			offset = (offset << 8) + pTagData[9];
			offset = (offset << 8) + pTagData[10];
			offset = (offset << 8) + pTagData[11];
		}
		{
			Length = 0;
			Length = pTagData[12];
			Length = (Length << 8) + pTagData[13];
			Length = (Length << 8) + pTagData[14];
			Length = (Length << 8) + pTagData[15];
		}

		*pHjctData = (BrBYTE*)PoSysMalloc(Length*BrSizeOf(BrBYTE));

		if (*pHjctData == BrNULL)
		{
			BrFree(pFontData);
			return	false;
		}

		memcpy(*pHjctData, pFontData+offset,Length);
		BrFree(pFontData);
	}

	return bFind;
#endif//ifdef USE_COMMON_INTERFACE
	return false;
}

void* BoraFont::GetHJCTTableData(unsigned int uCode, BrBOOL bBold, BrBOOL bItalic, BrINT& nFontIndex)
{
	BrINT nLocalFontIndex = -1;
	BrBYTE fontStyle = 0;

	if (bItalic)
		fontStyle |= FT_STYLE_FLAG_ITALIC;

	if (bBold)
		fontStyle |= FT_STYLE_FLAG_BOLD;

	BrBOOL bFontExistCheck = BrTRUE;
	PO_Face	fontFace = GetFontFace((FT_ULong)uCode, fontStyle, 10, 10, bFontExistCheck, &nLocalFontIndex);
	if(fontFace->nFontListIndex >= 0 && 
		m_RuntimeLoadFont.at(fontFace->nFontListIndex)->bHasHJCTTable)
	{
		setLocaleFontFace(fontFace);
		nFontIndex = m_nLocaleFontIndex = nLocalFontIndex;
		return m_RuntimeLoadFont.at(fontFace->nFontListIndex)->pHJCTData;
	}
	return BrNULL;
}

BrINT BoraFont::HasFontHJCTTable(BrINT nIndex)
{
	if(m_aFontHjctTable.isEmpty())
		return -1;

	//[15.12.02][sglee1206] HJCT Table은 한컴 전용 옛한글 Table로 해당 Table을 가진 폰트는 많아도 10개 이하로 존재한다.
	//따라서 반복문으로 처리하여도 속도상 문제는 없음
	for(int i = 0; i < m_aFontHjctTable.size(); i++)
	{
		if(m_aFontHjctTable.at(i)->nFontIndex == nIndex)
			return i;
	}
	return -1;
}

BrINT BoraFont::AddFontHJCTTable(void* pHjctTable, BrINT nIndex)
{
	BrINT nTableIndex = HasFontHJCTTable(nIndex);
	if(nTableIndex >= 0)
		return nTableIndex;

	LPBrFontHJCTTable table = (LPBrFontHJCTTable)PoSysMalloc(BrSizeOf(BrFontHJCTTable));
	if(table)
	{
		table->pHjct = (BrHJCTTable*)	pHjctTable;
		table->nFontIndex = nIndex;
		m_aFontHjctTable.add(table);
		return m_aFontHjctTable.size() - 1;
	}
	return -1;
}

void* BoraFont::GetFontHJCTTable(BrINT nFontIndex)
{
	if(m_aFontHjctTable.isEmpty())
		return BrNULL;

	//[15.12.02][sglee1206] HJCT Table은 한컴 전용 옛한글 Table로 해당 Table을 가진 폰트는 많아도 10개 이하로 존재한다.
	//따라서 반복문으로 처리하여도 속도상 문제는 없음
	for(int i = 0; i < m_aFontHjctTable.size(); i++)
	{
		if(m_aFontHjctTable.at(i)->nFontIndex == nFontIndex)
			return (void*)m_aFontHjctTable.at(i)->pHjct;
	}
	return BrNULL;
}

BrINT BoraFont::GetEmbFamilyFontCount()
{
#ifdef USE_EMFAMILY_HEADER_FONT
	return eEF_MaxFontType;
#else
	return 0;
#endif
}

void* BoraFont::GetEmbFamilyFontFace()
{
#ifdef USE_EMFAMILY_HEADER_FONT
	return (void*)m_EFFace;
#else
	return BrNULL;
#endif
}

void* BoraFont::GetEmbFullSetFontFace()
{
#ifdef USE_EMFAMILY_HEADER_FONT
	return (void*)&m_poFullSetFont;
#else
	return BrNULL;
#endif
}

BrBOOL BoraFont::GetEmbFamilyFontNames(BrCHAR** lpNames)
{
	BrBOOL bRet = BrFALSE;
#ifdef USE_EMFAMILY_HEADER_FONT

	if (!lpNames || eEF_MaxFontType < 1)
		return bRet;

	for (BrINT i = 0; i < eEF_MaxFontType; i++)
	{
		if (!getEmbFamilyFontName(lpNames[i], BORA_FONTNAME_LENGTH, i))
			break;
	}
	bRet = BrTRUE;
#endif

	return bRet;
}

BrBOOL BoraFont::getEmbFamilyFontName(BrCHAR* lpName, int lpNameSize, BrINT nIndex)
{
	BrBOOL bRet = BrFALSE;
#ifdef USE_EMFAMILY_HEADER_FONT
	BrINT nLocale = PoGetLocale();

	if (!lpName || eEF_MaxFontType < 1 || nIndex < 0 || nIndex >= eEF_MaxFontType)
		return bRet;

	switch (nIndex)
	{
	case eEF_TimesFont:
		strncpy_s(lpName, lpNameSize, "\x54\x69\x6D\x65\x73\x20\x4E\x65\x77\x20\x52\x6F\x6D\x61\x6E", strlen("\x54\x69\x6D\x65\x73\x20\x4E\x65\x77\x20\x52\x6F\x6D\x61\x6E"));
		break;
	case eEF_ArialFont:
		strncpy_s(lpName, lpNameSize, "\x41\x72\x69\x61\x6C", strlen("\x41\x72\x69\x61\x6C"));
		break;
	case eEF_TahomaFont:
		strncpy_s(lpName, lpNameSize, "\x54\x61\x68\x6F\x6D\x61", strlen("\x54\x61\x68\x6F\x6D\x61"));
		break;
	case eEF_CourFont:
		strncpy_s(lpName, lpNameSize, "\x43\x6F\x75\x72\x69\x65\x72\x20\x4E\x65\x77", strlen("\x43\x6F\x75\x72\x69\x65\x72\x20\x4E\x65\x77"));
		break;
	case eEF_VerdanaFont:
		strncpy_s(lpName, lpNameSize, "\x56\x65\x72\x64\x61\x6E\x61", strlen("\x56\x65\x72\x64\x61\x6E\x61"));
		break;
#ifdef USE_TTF_GDB_HEADER_FONT
	case eEF_GulimFont:
		if (nLocale == BR_LOCALE_KOREAN)
			strncpy_s(lpName, lpNameSize, "\xEA\xB5\xB4\xEB\xA6\xBC", strlen("\xEA\xB5\xB4\xEB\xA6\xBC")); //굴림
		else
			strncpy_s(lpName, lpNameSize, "\x47\x75\x6C\x69\x6D", strlen("\x47\x75\x6C\x69\x6D")); //굴림
		break;
	case eEF_DotumFont:
		if (nLocale == BR_LOCALE_KOREAN)
			strncpy_s(lpName, lpNameSize, "\xEB\x8F\x8B\xEC\x9B\x80", strlen("\xEB\x8F\x8B\xEC\x9B\x80")); //돋움
		else
			strncpy_s(lpName, lpNameSize, "\x44\x6F\x74\x75\x6D", strlen("\x44\x6F\x74\x75\x6D")); //돋움				
		break;
	case eEF_BatangFont:
		if (nLocale == BR_LOCALE_KOREAN)
			strncpy_s(lpName, lpNameSize, "\xEB\xB0\x94\xED\x83\x95", strlen("\xEB\xB0\x94\xED\x83\x95")); //바탕
		else
			strncpy_s(lpName, lpNameSize, "\x42\x61\x74\x61\x6E\x67", strlen("\x42\x61\x74\x61\x6E\x67")); //바탕
		break;
#endif
	}

	bRet = BrTRUE;
#endif

	return bRet;
}

BrBOOL BoraFont::getEmbFontFace(PO_Face* fontFace, FT_ULong ch, BrINT* pFaceIndex, FT_Int nWidth, FT_Int nHeight, BrBYTE fontStyle)
{
	*fontFace = BrNULL;
	if (pFaceIndex) *pFaceIndex = -1;
#ifdef USE_EMFAMILY_HEADER_FONT
	if (0x263a != ch && isEmFamilyFontCode(ch, fontStyle))
	{
		BrBOOL bBold = HAS_FONT_FLAG(fontStyle, FT_STYLE_FLAG_BOLD);
		BrBOOL bItalic = HAS_FONT_FLAG(fontStyle, FT_STYLE_FLAG_ITALIC);

		if (m_EFIndex == eEF_TimesFont)
		{
			PO_Face pFace = BrNULL;

			if (m_bTimesFullset)
			{
				pFace = m_poFullSetFont.pFullSet;
			}
			else
			{
				if (bBold && bItalic && m_poFullSetFont.pBoldItalic)
					pFace = m_poFullSetFont.pBoldItalic;
				else if (bBold && m_poFullSetFont.pBold)
					pFace = m_poFullSetFont.pBold;
				else if (bItalic && m_poFullSetFont.pItalic)
					pFace = m_poFullSetFont.pItalic;
			}

			if (pFace)
			{
				FT_Set_Transform(pFace->ft_face, BrNULL, BrNULL);
				FT_Set_Pixel_Sizes(pFace->ft_face, nWidth, nHeight);
				*fontFace = pFace;
			}
		}

		if (*fontFace == BrNULL && m_EFIndex != eEF_NoneFont)
		{
			FT_Set_Pixel_Sizes(m_EFFace[m_EFIndex]->ft_face, nWidth, nHeight);
			*fontFace = m_EFFace[m_EFIndex];
		}
	}

	if (*fontFace != BrNULL)
	{
		if (pFaceIndex)
			*pFaceIndex = m_EFIndex;
		return BrTRUE;
	}

#endif
	return BrFALSE;
}

eBEFFONT_TABLE_TYPE BoraFont::findEmbFontIndex(FT_Int nFontFlag)
{
	eBEFFONT_TABLE_TYPE efIndex = eEF_NoneFont;
#ifdef USE_EMFAMILY_HEADER_FONT
	switch (nFontFlag)
	{
	case eTimesNewRomanFont:
		if (m_EFFace[eEF_TimesFont])
			efIndex = eEF_TimesFont;
		break;
	case eArialFont:
		if (m_EFFace[eEF_ArialFont])
			efIndex = eEF_ArialFont;
		break;
	case eTahomaFont:
		if (m_EFFace[eEF_TahomaFont])
			efIndex = eEF_TahomaFont;
		break;
	case eCourierNewFont:
		if (m_EFFace[eEF_CourFont])
			efIndex = eEF_CourFont;
		break;
	case eVerdanaFont:
		if (m_EFFace[eEF_VerdanaFont])
			efIndex = eEF_VerdanaFont;
		break;
#ifdef USE_TTF_GDB_HEADER_FONT
	case eGulimFont:
		if (m_EFFace[eEF_GulimFont])
			efIndex = eEF_GulimFont;
		break;
	case eDotumFont:
		if (m_EFFace[eEF_DotumFont])
			efIndex = eEF_DotumFont;
		break;
	case eBatangFont:
		if (m_EFFace[eEF_BatangFont])
			efIndex = eEF_BatangFont;
		break;
#endif
	}
#endif

	return efIndex;
}

BrBOOL BoraFont::isRegEmFamilyFont(BrUSHORT* strFontName, BrUINT16 nLen, BrUINT16 nFlag)
{
#ifdef USE_COMMON_INTERFACE
	BrBOOL bReg = BrFALSE;

#ifdef USE_EMFAMILY_HEADER_FONT
	FT_Int nOldFontFlag = nFlag;
	BrBOOL bToUpper = BrFALSE;

	FT_Int nFontFlag = getFontFlag(strFontName, nLen, 0, bToUpper, BrFALSE);
	BrINT nLength = BrWcsLen(strFontName);
	switch (nFontFlag)
	{
	case eTimesNewRomanFont:
		if (nLength)
		{
			if (!FontWcsCmp(strFontName, (const unsigned short*)u"Times New Roman"))
				bReg = BrTRUE;
		}
		break;
	case eArialFont:
		if (nLength)
		{
			if (!FontWcsCmp(strFontName, (const unsigned short*)u"Arial"))
				bReg = BrTRUE;
		}
		break;
	case eTahomaFont:
		if (nLength)
		{
			if (!FontWcsCmp(strFontName, (const unsigned short*)u"Tahoma"))
				bReg = BrTRUE;
		}
		break;
	case eCourierNewFont:
		if (nLength)
		{
			if (!FontWcsCmp(strFontName, (const unsigned short*)u"Courier New"))
				bReg = BrTRUE;
		}
		break;
	case eVerdanaFont:
		if (nLength)
		{
			if (!FontWcsCmp(strFontName, (const unsigned short*)u"Verdana"))
				bReg = BrTRUE;
		}
		break;
	case eGulimFont:
		if (nLength)
		{
			if (!FontWcsCmp(strFontName, (const unsigned short*)u"\xAD74\xB9BC"))
				bReg = BrTRUE;
		}
		break;
	case eDotumFont:
		if (nLength)
		{
			if (!FontWcsCmp(strFontName, (const unsigned short*)u"\xB3CB\xC6C0"))
				bReg = BrTRUE;
		}
		break;
	case eBatangFont:
		if (nLength)
		{
			if (!FontWcsCmp(strFontName, (const unsigned short*)u"\xBC14\xD0D5"))
				bReg = BrTRUE;
		}
		break;
	}

	m_nFontFlag = nOldFontFlag;
#endif

	return bReg;
#endif//ifdef USE_COMMON_INTERFACE
	return BrFALSE;
}

void BoraFont::loadEmFamilyFont()
{
#if defined( USE_EMFAMILY_HEADER_FONT )
	BrINT i = 0;
	FT_Face tmFace = BrNULL;
	
	for (i = 0; i < eEF_MaxFontType; i++)
	{
		tmFace = BrNULL;
		if (!FT_New_Memory_Face(m_pFTLibrary, (const FT_Byte*)arrEFPool[i].pData, arrEFPool[i].nSize, 0, &tmFace))
		{
			m_EFFace[i]->nFontListIndex = -1;
			m_EFFace[i]->nPrimaryCharmapIdx = 0;
			m_EFFace[i]->family_name_UTF8 = BrNULL;
			m_EFFace[i]->moduleName = BrNULL;
			m_EFFace[i]->ft_face = tmFace;
			m_bUseEFFace[i] = BrTRUE;
			regFontDataPool(arrEFPool[i].pData, arrEFPool[i].nSize, m_EFFace[i]);
		}
	}

	tmFace = BrNULL;
	if (arrFullSetFontPool.sBold.pData && !FT_New_Memory_Face(m_pFTLibrary, (const FT_Byte*)arrFullSetFontPool.sBold.pData, arrFullSetFontPool.sBold.nSize, 0, &tmFace))
	{
		m_poFullSetFont.pBold->nFontListIndex = -1;
		m_poFullSetFont.pBold->nPrimaryCharmapIdx = 0;
		m_poFullSetFont.pBold->family_name_UTF8 = BrNULL;
		m_poFullSetFont.pBold->moduleName = BrNULL;
		m_poFullSetFont.pBold->ft_face = tmFace;
		regFontDataPool(arrFullSetFontPool.sBold.pData, arrFullSetFontPool.sBold.nSize, m_poFullSetFont.pBold, eFontBold);
	}
	tmFace = BrNULL;
	if (arrFullSetFontPool.sItalic.pData && !FT_New_Memory_Face(m_pFTLibrary, (const FT_Byte*)arrFullSetFontPool.sItalic.pData, arrFullSetFontPool.sItalic.nSize, 0, &tmFace))
	{
		m_poFullSetFont.pItalic->nFontListIndex = -1;
		m_poFullSetFont.pItalic->nPrimaryCharmapIdx = 0;
		m_poFullSetFont.pItalic->family_name_UTF8 = BrNULL;
		m_poFullSetFont.pItalic->moduleName = BrNULL;
		m_poFullSetFont.pItalic->ft_face = tmFace;
		regFontDataPool(arrFullSetFontPool.sItalic.pData, arrFullSetFontPool.sItalic.nSize, m_poFullSetFont.pItalic, eFontItalic);
	}

	tmFace = BrNULL;
	if (arrFullSetFontPool.sBoldItalic.pData && !FT_New_Memory_Face(m_pFTLibrary, (const FT_Byte*)arrFullSetFontPool.sBoldItalic.pData, arrFullSetFontPool.sBoldItalic.nSize, 0, &tmFace))
	{
		m_poFullSetFont.pBoldItalic->nFontListIndex = -1;
		m_poFullSetFont.pBoldItalic->nPrimaryCharmapIdx = 0;
		m_poFullSetFont.pBoldItalic->family_name_UTF8 = BrNULL;
		m_poFullSetFont.pBoldItalic->moduleName = BrNULL;
		m_poFullSetFont.pBoldItalic->ft_face = tmFace;
		regFontDataPool(arrFullSetFontPool.sBoldItalic.pData, arrFullSetFontPool.sBoldItalic.nSize, m_poFullSetFont.pBoldItalic, eFontBoldItalic);
	}
	tmFace = BrNULL;
	if (arrFullSetFontPool.sFullSet.pData && !FT_New_Memory_Face(m_pFTLibrary, (const FT_Byte*)arrFullSetFontPool.sFullSet.pData, arrFullSetFontPool.sFullSet.nSize, 0, &tmFace))
	{
		m_poFullSetFont.pFullSet->nFontListIndex = -1;
		m_poFullSetFont.pFullSet->nPrimaryCharmapIdx = 0;
		m_poFullSetFont.pFullSet->family_name_UTF8 = BrNULL;
		m_poFullSetFont.pFullSet->moduleName = BrNULL;
		m_poFullSetFont.pFullSet->ft_face = tmFace;
		regFontDataPool(arrFullSetFontPool.sFullSet.pData, arrFullSetFontPool.sFullSet.nSize, m_poFullSetFont.pFullSet);
	}
#endif //USE_EMFAMILY_HEADER_FONT
}


void BoraFont::loadHeaderFont()
{
	BrINT nSTIXGeneralCount = 0;

	loadEmFamilyFont();

#ifdef USE_TTF_HANGUL_HEADER_FONT
	loadMemFontFace((FT_Byte*)EFFDATA(EB_SinGothic), EFFSIZE(EB_SinGothic), &m_nHangulIndex);	
#endif //USE_TTF_HANGUL_HEADER_FONT

#if defined( USE_TTF_HEADER_FONT)
	loadMemFontFace((FT_Byte*)pFontBuf, ttfFontSize, &m_nEFIndex);
#endif

#ifdef USE_EMBEDDED_SYMBOL_FONT
	loadMemFontFace((FT_Byte*)EFFDATA(Winding), EFFSIZE(Winding), &m_nWindingIndex);	
	loadMemFontFace((FT_Byte*)EFFDATA(Winding2), EFFSIZE(Winding2), &m_nWinding2Index);	
	loadMemFontFace((FT_Byte*)EFFDATA(Winding3), EFFSIZE(Winding3), &m_nWinding3Index);	
	loadMemFontFace((FT_Byte*)EFFDATA(Webdings), EFFSIZE(Webdings), &m_nWebdingsIndex);	
	loadMemFontFace((FT_Byte*)EFFDATA(Symbol), EFFSIZE(Symbol), &m_nSymbolIndex);	
#endif //USE_EMBEDDED_SYMBOL_FONT

#ifdef USE_TTF_MATH_HEADER_FONT
	loadMemFontFace((FT_Byte*)EFFDATA(STIXGeneral), EFFSIZE(STIXGeneral), &m_nMathIndex,&nSTIXGeneralCount);	
#endif //USE_TTF_MATH_HEADER_FONT

#ifdef USE_TTF_HWP_MATH_HEADER_FONT
	loadMemFontFace((FT_Byte*)EFFDATA(HyhwpEQ), EFFSIZE(HyhwpEQ), &m_nHWPMathIndex);	
#endif //USE_TTF_HWP_MATH_HEADER_FONT

	if( m_nEFIndex != -1 )
		m_nBaseIndex++;
	if( m_nWindingIndex != -1 )
		m_nBaseIndex++;
	if( m_nWinding2Index != -1 )
		m_nBaseIndex++;
	if( m_nWinding3Index != -1 )
		m_nBaseIndex++;
	if( m_nWebdingsIndex != -1 )
		m_nBaseIndex++;
	if( m_nSymbolIndex != -1 )
		m_nBaseIndex++;
	if( m_nMathIndex != -1 )
		m_nBaseIndex += nSTIXGeneralCount;	//[15.01.16][sglee1206]	TTC Load 했으므로 해당 Font내 TTF만큼 Count 증가가 필요하여 수정
	if( m_nHWPMathIndex != -1 )
		m_nBaseIndex++;
	if(m_nHangulIndex != -1)
		m_nBaseIndex++;
}

FT_Short BoraFont::GetFontEncodingFlag(FT_Face pFace, BrBOOL bForseHangulSet)
{
	FT_Short nEncodingFlag = 0;
	//CJK
	if( FT_Get_Char_Index(pFace, 0xac00) || bForseHangulSet )
		nEncodingFlag = 1;
	else if( FT_Get_Char_Index(pFace, 0x5343) )
		nEncodingFlag = 1;
	else if( FT_Get_Char_Index(pFace, 0x3042) )	//Hiragana
		nEncodingFlag = 1;
	else if( FT_Get_Char_Index(pFace, 0x30A2) )	//Katakana
		nEncodingFlag = 1;
	//SYMBOL
	else if( !FT_Get_Char_Index(pFace, 0x20) || !FT_Get_Char_Index(pFace, 'a') )
		nEncodingFlag = 2;
	//Other
	else
		nEncodingFlag = 0;

	//[15.08.11][sglee1206] 문체부 바탕과 같은 폰트와 같이 Encoding이 Wansung인 경우 Flag 체크를 한번 더 하도록 추가
	// 조건은 변경될 수 있음
	if(pFace->num_charmaps == 1 && pFace->charmaps[0]->encoding == FT_ENCODING_WANSUNG)
	{
		FT_ULong  charcode = 0xac00;
		FT_UShort wansungCh = 0xac00;	//[16.06.16][sglee1206] Coverity medium 처리 수정
		char pOutout[3] = {0,};
		if ( BrWideCharToMultiByte( CP_ACP, (BrLPCWSTR)&wansungCh, 1, (BrLPSTR)pOutout, sizeof(pOutout)) )
			charcode = (pOutout[0] << 8)&0xff00 | (pOutout[1]&0xff);
		FT_Set_Charmap(pFace,pFace->charmaps[0]);
		if( FT_Get_Char_Index(pFace, charcode) || bForseHangulSet )
			nEncodingFlag = 1;
	}

	return nEncodingFlag;
}

BrBOOL BoraFont::bSymbolCharCheck(PO_Face const pFace, FT_ULong& ch, BrBOOL bEmbedFlag)
{
	BrBOOL bSymbolChar = BrFALSE;

	if (isOpenTypeFontCheck(pFace, BrTRUE))
	{
		FT_Face fontFace = pFace->ft_face;
		// TrueType
		TT_OS2* os2_table = (TT_OS2*)FT_Get_Sfnt_Table(fontFace, ft_sfnt_os2);
		if ((os2_table && HAS_SYMBOL_CHARSET(os2_table->ulCodePageRange1)) || (fontFace->charmap->encoding == FT_ENCODING_MS_SYMBOL))
		{
			//[15.09.04][sglee1206] revision 56687([ZPD-9802][Sheet] Symbol로 공란 입력시 빈공간 없이 기호 표시되는 현상 수정) 사이드 수정
			if ((ch >= 0x20 && ch <= 0xff) && !(os2_table && ch >= (os2_table->usFirstCharIndex) && ch <= (os2_table->usLastCharIndex)))
			{
				ch = 0xF000 | ch;
				bSymbolChar = BrTRUE;
			}
			//[16.07.19][sglee1206][KPV-353] ch가 0xf0XX로 전달되는 경우가 존재. 해당 경우인 기호 폰트의 경우 Flag 세팅이 안되는 경우가 존재하여 해당부분 수정
			// 추후 nSPFlag를 PC 버전에서는 사용하지 않는 방향으로 수정 필요
			else if ((fontFace->charmap->encoding == FT_ENCODING_MS_SYMBOL) && os2_table && (ch >= 0xf020 && ch <= 0xf0ff) && (ch >= (os2_table->usFirstCharIndex) && ch <= (os2_table->usLastCharIndex)))
			{
				bSymbolChar = BrTRUE;
			}
			//[15.12.22][sglee1206] Symbol 처리 추가
			else if ((fontFace->charmap->encoding == FT_ENCODING_MS_SYMBOL) && BoraFontComm::IsMSAlterSymbolChar(ch))
			{
				ch = BoraFontComm::GetMSAlterSymbolChar(ch);
				bSymbolChar = BrTRUE;
			}
#if defined(USE_EMBEDDED_SYMBOL_FONT)
			if (!bSymbolChar && bEmbedFlag) {
				BrINT embSymIndex;
				BrINT8 nFlag;
				nFlag = GetSpecialFontFlag(ch);
				embSymIndex = GetSpecialFontFlag2Index(nFlag);

				if (embSymIndex > -1 && (ch >= 0xf020 && ch <= 0xf0ff) && os2_table && (ch >= (os2_table->usFirstCharIndex) && ch <= (os2_table->usLastCharIndex)))
				{
					bSymbolChar = BrTRUE;
				}
			}
#endif //USE_EMBEDDED_SYMBOL_FONT
		}
	}

	return bSymbolChar;
}

BrBOOL BoraFont::hasFontGlyph(PO_Face const fontFace, FT_ULong ch)
{
	BrBOOL bRet = BrFALSE;
	FT_Error error = FT_Err_Ok;
	FT_Face ft_face = setFontFaceCharmap(fontFace, error);
	if(ft_face == BrNULL || error)
		return bRet;

	FT_CharMap charmap = ft_face->charmap;
	
	//[16.10.27][sglee1206]MAC Symbol Font의 경우 MS symbol font와는 다르게 Symbol Encoding이 존재하지 않음 [CAM-5550]
	// 아래 경로를 참고하면 MAC Roman인 경우에 처리에관한 내용이 존재하는 데 Symbol Font의 경우 해당 charmap을 사용한다고 되어있음
	if(charmap->platform_id == TT_PLATFORM_MACINTOSH && charmap->encoding_id == TT_MAC_ID_ROMAN && charmap->encoding == FT_ENCODING_APPLE_ROMAN)
	{
		FT_ULong nCmapID = FT_Get_CMap_Language_ID(ft_face->charmap);
		//http://www.unicode.org/Public/MAPPINGS/VENDORS/APPLE/Readme.txt 9- a)참고
		if(nCmapID == 0 && 
			(!FontStrCmp(ft_face->family_name,"Symbol") || !FontStrCmp(ft_face->family_name,"Zapf Dingbats") || !FontStrCmp(ft_face->family_name,".Keyboard")) &&
			FT_Get_Char_Index(ft_face, ch))
			bRet = BrTRUE;
	}

	if (!bRet)
	{
		FT_ULong  char_code = ch;
		if (charmap->encoding == FT_ENCODING_WANSUNG && ch > 0x80)
		{
			FT_UShort wansungCh = 0;	//[16.06.16][sglee1206] Coverity medium 처리 수정
			wansungCh = (ch & 0xFFFF);
			char pOutout[3] = { 0, };
			if (BrWideCharToMultiByte(CP_ACP, (BrLPCWSTR)&wansungCh, 1, (BrLPSTR)pOutout, sizeof(pOutout)))
				char_code = (pOutout[0] << 8) & 0xff00 | (pOutout[1] & 0xff);
		}

		if (FT_Get_Char_Index(ft_face, char_code))
			bRet = BrTRUE;
		else if (bSymbolCharCheck(fontFace, ch))
			bRet = BrTRUE;
	}

	return bRet;
}

void BoraFont::loadCharmap(PO_Face * pFace, FT_Int nFaceCnt)
{
	if (pFace == BrNULL)
		return;

	BrINT n = 0;
	BrUINT8 k =0;
	for (n=0;n<nFaceCnt;n++)
	{
		if (pFace[n])
		{
			FT_Face face = pFace[n]->ft_face;
			FT_CharMap  charmap;
			BrBOOL bFindMSPlatform = BrFALSE;
			for (k = 0; k < face->num_charmaps; k++)
			{
				charmap = face->charmaps[k];
				if (charmap->platform_id == TT_PLATFORM_MICROSOFT
#ifdef USE_FOR_IOS
					|| charmap->platform_id == TT_PLATFORM_APPLE_UNICODE
#endif
					)
				{
					if (bFindMSPlatform)
					{
						// 아래 조건의 경우 TT_MS_ID_UCS_4를 사용하는게 맞을듯... ex)Hiragino Gothic Pro W3 [CSP-8080]
						if (charmap->encoding_id == TT_MS_ID_UNICODE_CS &&
							face->charmaps[pFace[n]->nPrimaryCharmapIdx]->platform_id == TT_PLATFORM_MICROSOFT && face->charmaps[pFace[n]->nPrimaryCharmapIdx]->encoding_id == TT_MS_ID_UCS_4)
							BrTrace("%s font charmap is UCS 4...", face->family_name);
						else
							pFace[n]->nPrimaryCharmapIdx = k;
					}
					else
						pFace[n]->nPrimaryCharmapIdx = k;

					bFindMSPlatform = BrTRUE;
				}
				else if (charmap->platform_id == TT_PLATFORM_APPLE_UNICODE && face->family_name[0] == 0x41 && !FontStrCmp(face->family_name, "Apple Color Emoji"))
				{
					pFace[n]->nPrimaryCharmapIdx = k;
					bFindMSPlatform = BrTRUE;
				}
			}
		}
	}
}

void BoraFont::addCharmap(PO_Face pFace)
{
	if (pFace == BrNULL)
		return;

	BrINT k;

	FT_Face face = pFace->ft_face;
	FT_CharMap  charmap;
	for (k = 0; k < face->num_charmaps; k++ )
	{
		charmap = face->charmaps[k];
		if (charmap->platform_id == TT_PLATFORM_MICROSOFT
#ifdef USE_FOR_IOS
			|| charmap->platform_id == TT_PLATFORM_APPLE_UNICODE
#endif
			)
			pFace->nPrimaryCharmapIdx = k;
	}
}

BrBOOL BoraFont::loadMemFontFace(FT_Byte* pData, FT_Long size, FT_Int* pIndex, BrINT* pTTCCount)
{	
	FT_Error error = FT_Err_Ok;
	BrINT32 nTTFIndex = 0;

	if(pTTCCount != BrNULL)
		*pTTCCount = 0;

	while(error == FT_Err_Ok)
	{
		FT_Face FontFace = BrNULL;
		error = FT_New_Memory_Face( m_pFTLibrary, pData, size, nTTFIndex, &FontFace);

		if ( error == FT_Err_Ok )
		{
			int nFontIndex = addFontFaceByIndex(FontFace);
			PO_Face pFace = GetFontFaceByIndex(nFontIndex);
			regFontDataPool(pData, size, pFace);
			if(pIndex && nTTFIndex == 0)
				*pIndex = nFontIndex;

			pFace->nFontListIndex = -1;			

			//[16.01.05][sglee1206] 최초에 font Address 처리.
			//EG Print로 인해 PDF Export에 영향을 주어서 변경함
			if(m_first_font_address == BrNULL)
			{
				m_first_font_address = pData;
				m_first_font_size = size;			
			}
			if(pTTCCount != BrNULL)
				*pTTCCount += 1;
		}
		/*else if(pIndex)
		{
			*pIndex = -1;
			return BrFALSE;
		}*/

		nTTFIndex++;
	}

	return (nTTFIndex > 1);
}

void BoraFont::ReleaseFontNameList()
{
	//return;
	if (m_aFontFace)
	{
		for (BrUINT n = 0; n < m_aFontFace->size(); n++)
		{
			LPFontList pList = (LPFontList)m_aFontFace->at(n);
			PoSysFree(pList);
		}
		m_aFontFace->removeAll();
		delete m_aFontFace;
		m_aFontFace = BrNULL;
	}

	if (m_aLoadedPanoseFont)
	{
		for (int i = 0; i < m_aLoadedPanoseFont.size(); i++)
		{
			PoSysFree(m_aLoadedPanoseFont.at(i));
		}
		m_aLoadedPanoseFont.removeAll();
	}

	if (m_aFontNamePanoseInfo)
	{
		for (int i = 0; i < m_aFontNamePanoseInfo.size(); i++)
		{
			PoSysFree(m_aFontNamePanoseInfo.at(i));
		}
		m_aFontNamePanoseInfo.removeAll();
	}
}

BSysExArray<LPFontList>* BoraFont::GetFontNameList()
{
	if (!m_aFontFace)
	{
		m_aFontFace = new BSysExArray<LPFontList>;
	}

	if (m_aFontFace->size() == 0)
		GetFontList(m_aFontFace);

	return m_aFontFace;
}

void BoraFont::GetFontList(BSysExArray<LPFontList>* pFontList)
{
	if(pFontList && pFontList->size() == 0)
	{
		BrINT i = 0, nFCnt = 0, nFontLen = 0;
		BrUSHORT wTemp[MAX_FONT_LENGTH] = {0};

#ifdef USE_COMMON_INTERFACE
#ifdef USE_EMFAMILY_HEADER_FONT
		if(m_EFFace)
		{
			BrCHAR	szTemp[MAX_FONT_LENGTH] = { 0, };
			for (i = 0; i < eEF_MaxFontType; i++)
			{
				FontList* fontData = (FontList*)PoSysCalloc(1, sizeof(FontList));
				if (fontData)
				{
					strncpy_s(fontData->pEngName, sizeof(fontData->pEngName), m_EFFace[i]->ft_face->family_name, BrStrLen(m_EFFace[i]->ft_face->family_name));
					if (!FontStrCmp(m_EFFace[i]->ft_face->family_name, "HYGulim") ||
						!FontStrCmp(m_EFFace[i]->ft_face->family_name, "HYDotum") ||
						!FontStrCmp(m_EFFace[i]->ft_face->family_name, "HYBatang"))
					{
						fontData->nFontEncodingType = GetFontEncodingFlag(m_EFFace[i]->ft_face, BrTRUE);
						memset(szTemp, 0, sizeof(szTemp));
						getEmbFamilyFontName(szTemp, sizeof(szTemp), i);
						strncpy_s(fontData->pLocName, sizeof(fontData->pLocName), szTemp, BrStrLen(szTemp));
					}
					else
						fontData->nFontEncodingType = GetFontEncodingFlag(m_EFFace[i]->ft_face);

					pFontList->add(fontData);
				}
			}

		}
#endif
#endif//ifdef USE_COMMON_INTERFACE

#ifdef SUPPORT_ADD_FONT
		BrINT nTypeFaceListSize = m_aTypeFaceList.size();
		for(i = 0;  i < nTypeFaceListSize; i++)
		{
			LPBrTypefaceStruct pFamily = m_aTypeFaceList.at(i);
			BrINT nRuntimeLoadFontIndex = -1;
			for(int familyIdx = 0; familyIdx < eFontStyleIndexMax; familyIdx++)
			{
				if(pFamily->nStyleCnt[familyIdx] > 0)
				{
					LPBrFontStyleIdxNode pNode = pFamily->nFontIndices[familyIdx];
					while(pNode != BrNULL && nRuntimeLoadFontIndex < 0)
					{
						nRuntimeLoadFontIndex = pNode->nFontIndex;
						pNode = pNode->pNext;
					}

					if(nRuntimeLoadFontIndex > -1)
						break;
				}
			}
			//if(m_nEFIndex != i && m_nSymbolIndex != i && m_nWindingIndex !=i && m_nWinding2Index !=i && m_nWinding3Index !=i && m_nWebdingsIndex !=i && m_nMathIndex !=i && m_nHWPMathIndex !=i && m_nHangulIndex != i)
			if(nRuntimeLoadFontIndex > -1)
			{	
				//[16.10.25][sglee1206] i의 값은 m_aSysFontFamilyList의 Index인데 이것을 m_RuntimeLoadFont로 이용하면 잘못처리되므로 해당 부분 수정
				//관련 이슈[CSP-4328][CAM-5448][CAM-5072][CAM-4745][CAM-3945]
				LPBrLoadFontFileList pFontFile = getLoadFontFileList(getLoadFontStFileIndex(nRuntimeLoadFontIndex));

				if(BrWcsLen(pFamily->sFontData.pEngName) > 0 /* && pFontFile->bLoaded == BrFALSE*/)
				{
					FontList *fontData = (FontList *)PoSysCalloc(1, sizeof(FontList));
					if ( fontData )
					{
						BrINT32 nLen = BrWcsLen(pFamily->sFontData.pEngName);
						BrWideCharToMultiByte(CP_UTF8, pFamily->sFontData.pEngName, nLen, (BrLPSTR)fontData->pEngName, BORA_FONTNAME_LENGTH - 1);

						nLen = BrWcsLen(pFamily->sFontData.pLocName);
						if (nLen > 0)
							BrWideCharToMultiByte(CP_UTF8, pFamily->sFontData.pLocName, nLen, (BrLPSTR)fontData->pLocName, BORA_FONTNAME_LENGTH - 1);
						
						if (pFontFile != BrNULL && strlen(pFontFile->pFontPath) > 0)
							strncpy_s(fontData->pFontPath, sizeof(fontData->pFontPath), pFontFile->pFontPath, strlen(pFontFile->pFontPath));
						
						fontData->nFontEncodingType = pFamily->sFontData.nFontEncodingType;
						
						pFontList->add(fontData);
					}
				}
			}
		}
#else
		BrINT fontFaceCnt = GetFontFaceCnt();
		for (i = 0; i < fontFaceCnt; i++)
		{
			if (m_nEFIndex != i && m_nSymbolIndex != i && m_nWindingIndex != i && m_nWinding2Index != i && m_nWinding3Index != i && m_nWebdingsIndex != i && m_nMathIndex != i && m_nHWPMathIndex != i && m_nHangulIndex != i)
			{
				memset(wTemp, 0, sizeof(BrUSHORT) * MAX_FONT_LENGTH);
				CUtil::WcsCpy(wTemp, GetFamilyNameByIndex(i));
				nFontLen = BrWcsLen(wTemp);
				if (!isRegEmFamilyFont(wTemp, nFontLen, m_nFontFlag))
				{
					FontList* fontData = (FontList*)PoSysCalloc(1, sizeof(FontList));
					if (fontData)
					{
						BrWideCharToMultiByte(CP_UTF8, wTemp, nFontLen, fontData->pEngName, sizeof(fontData->pEngName));

						fontData->nFontEncodingType = GetFontEncodingFlag(getFTFaceByIndex(i));
						FT_Face ft_face = getFTFaceByIndex(i);
						FT_UInt tmCount = FT_Get_Sfnt_Name_Count(ft_face);
						for (int j = 0; j < tmCount; j++)
						{
							memset(wTemp, 0, sizeof(BrUSHORT)* MAX_FONT_LENGTH);
							FT_SfntName tmName;
							FT_Get_Sfnt_Name(ft_face, j, &tmName);
							//[dwchun : 2013.10.23] : 조건을 체크하는 순서 절대로 바꾸지 말 것. 속도를 위해 맞춘 순서임
							if (tmName.language_id == TT_MS_LANGID_KOREAN_EXTENDED_WANSUNG_KOREA && tmName.name_id == 1 && tmName.platform_id == TT_PLATFORM_MICROSOFT && tmName.encoding_id == TT_MS_ID_UNICODE_CS)
							{
								convertFontFaceName(tmName.string_len, tmName.string, wTemp, sizeof(BrUSHORT)* MAX_FONT_LENGTH);
								if (BrWcsLen(wTemp) > 0)
								{
									BrWideCharToMultiByte(CP_UTF8, wTemp, BrWcsLen(wTemp), (BrLPSTR)fontData->pLocName, BORA_FONTNAME_LENGTH - 1);
								}
								break;
							}
						}

						LPBrLoadFontFileList pFontFile = getLoadFontFileList(getLoadFontStFileIndex(GetFontFaceByIndex(i)->nFontListIndex));
						if (pFontFile && strlen(pFontFile->pFontPath) > 0)
							strncpy_s(fontData->pFontPath, sizeof(fontData->pFontPath), pFontFile->pFontPath, strlen(pFontFile->pFontPath));
						
						pFontList->add(fontData);
					}
				}
			}
		}
#endif // SUPPORT_ADD_FONT
	}
}

void*	BoraFont::GetLocaleFontFace(FT_ULong ch, BrBOOL bBold, BrBOOL bItalic, FT_Int nFontWidth, FT_Int nFontHeight, BrBOOL bFontExistCheck, BrINT* pFaceIndex)
{
	BrINT nFontIndex = -1;
	if(m_LocaleFontFace != BrNULL)
	{
		nFontIndex = m_nLocaleFontIndex;
	}

	BrBYTE fontStyle = 0;

	if (bItalic)
		fontStyle |= FT_STYLE_FLAG_ITALIC;

	if (bBold)
		fontStyle |= FT_STYLE_FLAG_BOLD;

	PO_Face	fontFace = GetFontFace(ch, fontStyle, nFontWidth, nFontHeight, bFontExistCheck, &nFontIndex, BrNULL, BrFALSE, BrTRUE);
	FT_Face ftFace = BrNULL;
	if(fontFace)
	{
		setLocaleFontFace(fontFace);
		if(pFaceIndex != BrNULL)
			*pFaceIndex = nFontIndex;
		m_nLocaleFontIndex = nFontIndex;
		ftFace = fontFace->ft_face;
	}

	return (void*)ftFace;
}

BrINT	BoraFont::LoadSystemFontForPDF(BrCHAR* fontName)
{
#ifdef SUPPORT_ADD_FONT
	if (fontName == BrNULL || BrStrLen(fontName) < 1)
		return -1;

	BrWORD _fontName[MAX_FONT_LENGTH] = { 0, };

	BrWORD* pSystemFontHName = BrNULL;
	BrINT	nSystemFontIdx, nTypefaceListIndex;
	BrINT fontFaceCnt = GetFontFaceCnt();

	BrMultiByteToWideChar(CP_UTF8, fontName, BrStrLen(fontName), _fontName, MAX_FONT_LENGTH);

	for (BrINT n=0;n< fontFaceCnt;n++)
	{
		pSystemFontHName = BrNULL;
		nSystemFontIdx = GetFontFaceByIndex(n)->nFontListIndex;
		if(nSystemFontIdx != -1) 
		{
			nTypefaceListIndex = m_RuntimeLoadFont.at(nSystemFontIdx)->nTypefaceListIndex;
			if(nTypefaceListIndex >= 0)
			{
				pSystemFontHName = m_aTypeFaceList.at(nTypefaceListIndex)->sFontData.pLocName;
			}
		}
		if (IsFamilyFontName(_fontName, GetFontFaceByIndex(n), 0, pSystemFontHName))
		{			
			return n;
		}
	}

	return loadSystemFontFile(_fontName);
#endif
	return -1;
}

BrBOOL BoraFont::HasGlyphCheckSimple(const BrCHAR* fontName, BrULONG ch)
{
	if(fontName == BrNULL || ch <= 0)
		return BrFALSE;

	for(int i =0; m_Face[i];i++)
	{
		if(m_Face[i] && strcmp(fontName, m_Face[i]->family_name_UTF8) == 0)
		{
			int err = 0;
			int index = FT_Get_Char_Index(m_Face[i]->ft_face, ch);

			if (index == 0)
				return BrFALSE;
			else
				return BrTRUE;
		}
	}

	return BrFALSE;
}

BrBOOL BoraFont::HasGlyphForFont(BrUSHORT* strFontName, BrUINT16 nLen, FT_ULong ch, BrBOOL* bHasFont)
{
	BrBOOL bFind = BrFALSE;
	BrBOOL bToUpper = BrFALSE;

	BrBOOL bFontExistCheck = BrTRUE;
	// Store Current Font Name
	BrUSHORT pFontName[MAX_FONT_LENGTH+1] = {0,};
	CUtil::WcsCpy(pFontName, m_pFontName);
	
	// Change Font Name
	SetFontName(strFontName, BrFALSE, BrFALSE, bToUpper, bFontExistCheck);

	if(bHasFont)
	{
		*bHasFont = BrTRUE;
		*bHasFont = !(CheckNotExistFontName(strFontName));
	}

	//Default Value
	BrINT nFontIndex = -1;
	
	// Not find Default Font
	BrBOOL bForceFind = BrTRUE;

	PO_Face	fontFace; 
	BrBYTE fontStyle = 0;

	fontFace = GetFontFace(ch, fontStyle, 10, 10, bFontExistCheck, &nFontIndex, &bFind, bForceFind);

	// Restore Current Font Name
	SetFontName(pFontName, BrFALSE, BrFALSE, bToUpper, bFontExistCheck);

	return bFind;
}

BrCHAR* BoraFont::HasGlyphIndex(unsigned int uCode, BrBOOL bHangul, BrINT* pFaceIndex, BrBOOL bReFind)
{
	FT_Face pdfFace = GetFontFaceForPdf((FT_ULong)uCode, bHangul,pFaceIndex,bReFind);
	if( pdfFace )
		return (BrCHAR*)pdfFace->stream->pathname.pointer;

	return BrNULL;
}

BrCHAR* BoraFont::HasGlyphName(unsigned int uCode)
{
	BrINT nFaceIndex = -1;
	BrBOOL bFind = BrTRUE;
	BrBYTE fontStyle = 0;
	BrBOOL bFontExistCheck = BrTRUE;
	PO_Face pdfFace = GetFontFace((FT_ULong)uCode, fontStyle, 10, 10, bFontExistCheck, &nFaceIndex, &bFind);
	if( pdfFace && pdfFace->ft_face && bFind)
		return (BrCHAR*)getPostScriptNameByFontFace(pdfFace);

	return BrNULL;
}

FT_Face BoraFont::GetFontFaceForPdf(FT_ULong uCode, BrBOOL bHangul, BrINT* pFaceIndex, BrBOOL bReFind)
{
	PO_Face fontFace = BrNULL;
	FT_Face ft_face = BrNULL;

	BrINT32 nOldSize = -1;
	BrINT nBigSizeIndex = m_nBaseIndex;
	BrBOOL bFind = BrFALSE;
	FT_Error error = FT_Err_Ok;
	BrINT nFontFaceCnt = GetFontFaceCnt();

	for(int n=m_nBaseIndex; n< nFontFaceCnt; n++ )
	{
		fontFace = GetFontFaceByIndex(n);
		ft_face = setFontFaceCharmap(fontFace, error);

		if (ft_face == BrNULL)
			continue;

		if( bHangul )
		{
			if( FT_Get_Char_Index(ft_face, uCode) && FT_Get_Char_Index(ft_face, 0xAC00) )
			{
				if( nOldSize == -1 || ft_face->num_glyphs > nOldSize )
				{
					if(!bReFind || (pFaceIndex != BrNULL &&*pFaceIndex != n) )
					{
						nBigSizeIndex = n;
						nOldSize = ft_face->num_glyphs;
						bFind = BrTRUE;
					}
				}
			}
		}
		else
		{
			if( uCode == 0x20 )
			{
				if( nOldSize == -1 || ft_face->num_glyphs > nOldSize )
				{
					//if(!bReFind || (pFaceIndex != BrNULL &&*pFaceIndex != n) )
					{
						nBigSizeIndex = n;
						nOldSize = ft_face->num_glyphs;
						//bFind = BrTRUE;
					}
				}
			}
			else
			{
				if( FT_Get_Char_Index(ft_face, uCode) )
				{
					if( nOldSize == -1 || ft_face->num_glyphs > nOldSize )
					{
						if(!bReFind || (pFaceIndex != BrNULL &&*pFaceIndex != n) )
						{
							nBigSizeIndex = n;
							nOldSize = ft_face->num_glyphs;
							bFind = BrTRUE;
						}
					}
				}
			}
		}
	}

	ft_face = getFTFaceByIndex(nBigSizeIndex);
	if(pFaceIndex != BrNULL)
	{
		if(bFind)
			*pFaceIndex = nBigSizeIndex;
		else
			*pFaceIndex = -1;
	}
	return ft_face;
}

FT_Int BoraFont::originalTableCal(PO_Face fontFace, FT_ULong ch, BrBOOL bBold)
{
	BrINT nCharWidth = 0;
	FT_Glyph_Format prev_format = FT_GLYPH_FORMAT_NONE;
	if (Bora_2_FT_Load_Char(fontFace->ft_face, ch, FT_LOAD_DEFAULT | FT_LOAD_COLOR, prev_format, -1))
	{
		return 0;
	}

	if (fontFace->ft_face->glyph->advance.x == 0)
		return 0;

	nCharWidth = (fontFace->ft_face->glyph->advance.x + 32) / 64;

	if (fontFace->ft_face->glyph->advance.x > 0 && nCharWidth == 0)
		nCharWidth = 1;

	nCharWidth = BoraFontComm::GetCoordinateX(nCharWidth, BrTRUE, eNormalCoordinate, ZOOM_10000, 96);

	return nCharWidth;
}

void BoraFont::initialFontTable()
{
	BrUSHORT FontName[MAX_FONT_LENGTH] = { 0, };
	int nBaseFontIndex = 0;
	BrBOOL bToUpper;
	BrBOOL bFontExistCheck = BrTRUE;

	/*기존 poFont::InitialFontTable() 함수 내용*/
	PO_Face	fontFace = BrNULL;
	
	//기호 폰트의 경우 영문이 없는 경우가 대다수라 시스템에서 읽은 첫번째 폰트로 최소한 Width를 처리 하도록 함
	if (m_nWindingIndex == 0 || m_nWinding2Index == 0 || m_nWinding3Index == 0 || m_nWebdingsIndex == 0 || m_nSymbolIndex == 0 ||
		m_nMathIndex == 0 || m_nHWPMathIndex == 0)
		nBaseFontIndex = m_nBaseIndex;

	fontFace = GetFontFaceByIndex(nBaseFontIndex);
	if (fontFace == BrNULL)
	{
		fontFace = GetFontFaceByIndex(0);
		nBaseFontIndex = 0;
	}

	FT_Face ft_face = fontFace->ft_face;

	CUtil::WcsCpy(FontName, fontFace->family_name_Unicode);
	m_nDefOriginalFontFlag = m_nFontFlag = SetFontName(FontName, BrFALSE, BrFALSE, bToUpper, bFontExistCheck);

	FT_Int nFontHeight = BoraFontComm::GetCoordinateY(200, BrFALSE, eNormalCoordinate, ZOOM_10000, 96);
	if (nFontHeight <= 0)
		nFontHeight = 1;

	FT_Set_Pixel_Sizes(fontFace->ft_face, nFontHeight, nFontHeight);

	if (fontFace->nPrimaryCharmapIdx < 0 || fontFace->nPrimaryCharmapIdx >= ft_face->num_charmaps)
		fontFace->nPrimaryCharmapIdx = 0;

	FT_CharMap charmap = ft_face->charmaps[fontFace->nPrimaryCharmapIdx];
	if (ft_face->charmap != charmap)
		FT_Set_Charmap(ft_face, charmap);
	
	BrINT i, j;
	for (i = 0x20, j = 0; i <= 0x7F; i = i + 0x01, j++)
	{
		arrBaseFontTable[j] = originalTableCal(fontFace, i, BrFALSE);
		arrBaseBoldFontTable[j] = originalTableCal(fontFace, i, BrTRUE);
	}

	arrBaseFontTable[j] = 200;
	arrBaseBoldFontTable[j++] = 200;

	arrBaseFontTable[j] = 200;
	arrBaseBoldFontTable[j] = 200;
}

BrWORD* BoraFont::AppendFontForPrint( BrCHAR* pFontData, BrINT nLen, BrINT* nDrawFontIndex)
{
	BrWORD* pRetName = BrNULL;

	if (GetFontFaceCnt() >= TTF_FONT_COUNT)
		return pRetName;

	int nTTFCount = getMemoryFontFaceCount((BrBYTE*)pFontData);

	for (int idx = 0; idx < nTTFCount; idx++)
	{
		FT_Face fontFace = BrNULL;
		if (addFontMemory(pFontData, nLen, idx, fontFace, TRUE))
		{
			int nFontIndex = addFontFaceByIndex(fontFace);
			PO_Face pFace = GetFontFaceByIndex(nFontIndex);
			if(idx == 0)
				pRetName = GetFamilyNameByIndex(nFontIndex);
			regFontDataPool(pFontData, nLen, pFace);
			addCharmap(pFace);
			m_nAppendFontCnt++;
			*nDrawFontIndex = nFontIndex;
		}
	}

	return pRetName;
}

void BoraFont::RemoveFontForPrint()
{
	int nFaceCount = GetFontFaceCnt();
	for (int n=nFaceCount-1;n>=0 && m_nAppendFontCnt>0;n--,m_nAppendFontCnt--)
	{
		FT_Done_Face(m_Face[n]->ft_face);
		PoSysFree(m_Face[n]);
		m_Face[n] = BrNULL;
		m_face_count--;
	}

	m_nOldIndex = -1;
}

BrINT BoraFont::AppendFontIndexForPrint(BrINT pDrawFontIndex)
{
	m_nPDFDrawFontIndex = pDrawFontIndex;
	return m_nPDFDrawFontIndex;
}

BrBOOL BoraFont::isExistFontface(BrUSHORT* strFontName, BrUINT16 nLen, BrBYTE fontStyle)
{
	if(strFontName && GetFontFaceCnt() > 1)
	{
		for (BrINT n=0;n<(BrINT)GetFontFaceCnt();n++)
		{			
			if (BrWcsLen(strFontName) <= 0 || IsFamilyFontName(strFontName, GetFontFaceByIndex(n), fontStyle))
				return BrTRUE;
		}
	}

	return BrFALSE;
}

BrCHAR* BoraFont::GetEmFontData(BrBYTE nType, BrINT nEmIndex, BrINT & nSize, BrBYTE nAtt, BrBYTE & nOutAtt)
{
	BrCHAR* pFontData = BrNULL;
	nSize = 0;

	nOutAtt = eFontNormal;

	switch(nType)
	{
	case eFT_BaseFontFile:
		pFontData = m_pDefultFontFilePath;
		break;
	case eFT_BaseEmFont:
		pFontData = (BrCHAR*)m_first_font_address;
		nSize = m_first_font_size;
		break;
	case eFT_FamilyFont:
	{
		nSize = 0;
#ifdef USE_EMFAMILY_HEADER_FONT
		pFontData = BrNULL;
		if (nEmIndex == eEF_TimesFont)
		{
			nOutAtt = nAtt;
			if (nAtt == eFontBold)
			{
				pFontData = (BrCHAR*)arrFullSetFontPool.sBold.pData;
				nSize = arrFullSetFontPool.sBold.nSize;
			}
			else if (nAtt == eFontItalic)
			{
				pFontData = (BrCHAR*)arrFullSetFontPool.sItalic.pData;
				nSize = arrFullSetFontPool.sItalic.nSize;
			}
			else if (nAtt == eFontBoldItalic)
			{
				pFontData = (BrCHAR*)arrFullSetFontPool.sBoldItalic.pData;
				nSize = arrFullSetFontPool.sBoldItalic.nSize;
			}
		}

		if (nSize == 0 && nEmIndex > eEF_NoneFont && nEmIndex < eEF_MaxFontType)
		{
			pFontData = (BrCHAR*)arrEFPool[nEmIndex].pData;
			nSize = arrEFPool[nEmIndex].nSize;
		}
#endif
	}
	break;
#ifdef USE_EMBEDDED_SYMBOL_FONT
	case eFT_SymbolFont:
		pFontData = (BrCHAR*)EFFDATA(Symbol);
		nSize = EFFSIZE(Symbol);
		break;
	case eFT_WingdingsFont:
		pFontData = (BrCHAR*)EFFDATA(Winding);
		nSize = EFFSIZE(Winding);
		break;
	case eFT_Wingdings2Font:
		pFontData = (BrCHAR*)EFFDATA(Winding2);
		nSize = EFFSIZE(Winding2);
		break;
	case eFT_Wingdings3Font:
		pFontData = (BrCHAR*)EFFDATA(Winding3);
		nSize = EFFSIZE(Winding3);
		break;
	case eFT_WebdingsFont:
		pFontData = (BrCHAR*)EFFDATA(Webdings);
		nSize = EFFSIZE(Webdings);
		break;
#endif
	case eFT_STIXMathFont:
#ifdef USE_TTF_MATH_HEADER_FONT
		pFontData = (BrCHAR*)EFFDATA(STIXGeneral);
		nSize = EFFSIZE(STIXGeneral);
#endif // USE_TTF_MATH_HEADER_FONT
		break;
	case eFT_HyhwpEQFont:
#ifdef USE_TTF_HWP_MATH_HEADER_FONT
		pFontData = (BrCHAR*)EFFDATA(HyhwpEQ);
		nSize = EFFSIZE(HyhwpEQ);
#endif // USE_TTF_HWP_MATH_HEADER_FONT
		break;
	case eFT_NanumGothicFont:
#ifdef USE_TTF_HEADER_FONT
		pFontData = (BrCHAR*)pFontBuf;
		nSize = ttfFontSize;
#endif //USE_TTF_HEADER_FONT
		break;
	default:
		break;
	}

	return pFontData;
}

BrFLOAT BoraFont::getFontInternalLeading(PO_Face const pFace, BrINT nFontHeight)
{
	BrFLOAT leading = 0.0f;
	FT_Face fontFace = pFace->ft_face;

	//Defalut Internal Leading Value
	leading = 1.0 * fontFace->ascender- fontFace->descender - fontFace->units_per_EM;
	//Internal Leading ratio
	leading /= fontFace->units_per_EM;
	//Current Font Size Internal Leading
	leading *=  nFontHeight;

	return leading;
}

BrFLOAT BoraFont::getFontExternalLeading(PO_Face const pFace, BrINT nFontHeight)
{
	BrFLOAT leading = 0.0f;

	if(isOpenTypeFontCheck(pFace, BrTRUE))
	{
		FT_Face fontFace = pFace->ft_face;
		// TrueType
		TT_Face const ttFontFace = (TT_Face)(fontFace);
		//Defalut External Leading Value
		leading = 1.0 * ttFontFace->horizontal.Line_Gap;
		//External Leading ratio
		leading /= fontFace->units_per_EM;
		//Current Font Size External Leading
		leading *=  nFontHeight;
	}

	return leading;
}

// return Type : -1 Not check, 0 Diff Font, 1 Same Font
BrINT BoraFont::checkFamilyFontForIndex(BrWORD* fontName, PO_Face pFace, BrBYTE fontStyle)
{
	BrINT nRet = -1;
	if(pFace->nFontListIndex > -1 &&
		m_RuntimeLoadFont.size() > pFace->nFontListIndex
		&& m_RuntimeLoadFont.at(pFace->nFontListIndex)->nTypefaceListIndex > -1)
	{
		BrINT nTypefaceListIndex = m_RuntimeLoadFont.at(pFace->nFontListIndex)->nTypefaceListIndex;
		BrINT nFontFamilyCnt = m_aTypeFaceList.at(nTypefaceListIndex)->nCountSameFamily;

		//Fisrt Case... 1 Family, 1 Font
		if(nFontFamilyCnt == 1)
			return 1;

		//Second Case... 1 Family Same Flag Font
		LPBrFontStyleIdxNode pNode = m_aTypeFaceList.at(nTypefaceListIndex)->nFontIndices[fontStyle];
		
		while(pNode != BrNULL)
		{
			if(pNode->nFontIndex == pFace->nFontListIndex)
				return 1;
			pNode = pNode->pNext;
		}

		//[15.06.01][sglee1206] 동일 Family에 Flag가 다른 Font가 존재 시 해당 Font가 아니면 다음에 찾아야 함
		if(m_aTypeFaceList.at(nTypefaceListIndex)->nStyleCnt[fontStyle] > 0
			&& pNode == BrNULL)
			return 0;


		BrINT caseNum = -1;
		//Third Case... 1 Family Alternate Font
		// Bold Italic -> Bold or Italic, Bold -> Regular, Italic -> Regular
		if(HAS_FONT_FLAG(fontStyle,FT_STYLE_FLAG_BOLD))
		{
			if(HAS_FONT_FLAG(fontStyle,FT_STYLE_FLAG_ITALIC))	// Bold Italic
			{
				pNode = m_aTypeFaceList.at(nTypefaceListIndex)->nFontIndices[eStyleItalic];
				while(pNode != BrNULL)
				{
					if(pNode->nFontIndex == pFace->nFontListIndex)
						return 1;
					pNode = pNode->pNext;
				}
				pNode = m_aTypeFaceList.at(nTypefaceListIndex)->nFontIndices[eStyleBold];
				while(pNode != BrNULL)
				{
					if(pNode->nFontIndex == pFace->nFontListIndex)
						return 1;
					pNode = pNode->pNext;
				}
				caseNum = 0;
			}
			else			// Bold
			{
				pNode = m_aTypeFaceList.at(nTypefaceListIndex)->nFontIndices[eStyleItalic];
				while(pNode != BrNULL && caseNum < 0)
				{
					if(pNode->nFontIndex == pFace->nFontListIndex)
						caseNum = 1;	// Bold Italic
					pNode = pNode->pNext;
				}
				pNode = m_aTypeFaceList.at(nTypefaceListIndex)->nFontIndices[eStyleBoldItalic];
				while(pNode != BrNULL && caseNum < 0)
				{
					if(pNode->nFontIndex == pFace->nFontListIndex)
						caseNum = 1;	// Bold Italic
					pNode = pNode->pNext;
				}

				if(caseNum < 0)
					return 1;
			}
		}
		else if(HAS_FONT_FLAG(fontStyle,FT_STYLE_FLAG_ITALIC))	// Italic
		{
			pNode = m_aTypeFaceList.at(nTypefaceListIndex)->nFontIndices[eStyleBold];
			while(pNode != BrNULL && caseNum < 0)
			{
				if(pNode->nFontIndex == pFace->nFontListIndex)
					caseNum = 1;	// Bold Italic
				pNode = pNode->pNext;
			}
			pNode = m_aTypeFaceList.at(nTypefaceListIndex)->nFontIndices[eStyleBoldItalic];
			while(pNode != BrNULL && caseNum < 0)
			{
				if(pNode->nFontIndex == pFace->nFontListIndex)
					caseNum = 1;	// Bold Italic
				pNode = pNode->pNext;
			}

			if(caseNum < 0)
				return 1;
		}
		else				// Regular
		{
			pNode = m_aTypeFaceList.at(nTypefaceListIndex)->nFontIndices[eStyleExtra1];
			while(pNode != BrNULL)
			{
				if(pNode->nFontIndex == pFace->nFontListIndex)
					return 1;
				pNode = pNode->pNext;
			}
			caseNum = 2;
		}

		//Last Case... 1 Family, another Font
		switch(caseNum)
		{
		case 0:
			{
				pNode = m_aTypeFaceList.at(nTypefaceListIndex)->nFontIndices[eStyleRegular];
				while(pNode != BrNULL)
				{
					if(pNode->nFontIndex == pFace->nFontListIndex)
						return 1;
					pNode = pNode->pNext;
				}
				pNode = m_aTypeFaceList.at(nTypefaceListIndex)->nFontIndices[eStyleExtra1];
				while(pNode != BrNULL)
				{
					if(pNode->nFontIndex == pFace->nFontListIndex)
						return 1;
					pNode = pNode->pNext;
				}
			}
			break;
		case 1:
			{
				pNode = m_aTypeFaceList.at(nTypefaceListIndex)->nFontIndices[eStyleBoldItalic];
				while(pNode != BrNULL)
				{
					if(pNode->nFontIndex == pFace->nFontListIndex)
						return 1;
					pNode = pNode->pNext;
				}
			}
			break;
		case 2:
			{
				pNode = m_aTypeFaceList.at(nTypefaceListIndex)->nFontIndices[eStyleItalic];
				while(pNode != BrNULL)
				{
					if(pNode->nFontIndex == pFace->nFontListIndex)
						return 1;
					pNode = pNode->pNext;
				}
			}
			break;
		default:
			break;
		}
	}
	return nRet;
}

BrBOOL BoraFont::IsFamilyFontName(BrWORD* fontName, PO_Face pFace, BrBYTE fontStyle, BrWORD* familyHName, LPBrFontStruct CheckFont)
{
#ifdef USE_COMMON_INTERFACE
	BrBOOL result = BrFALSE; 
	BrWORD wTemp[MAX_FONT_LENGTH] = { 0, };
	//기존에 convertValidFontName 함수 내용
	//사용하는 곳이 이곳외엔 없으므로 함수로 호출하는 것 자체가 call Stack 낭비
	const BrWORD* szHYWingding = (const BrWORD*)u"HYWingding";
	BrWORD*outName  = fontName;
#ifdef USE_EMBEDDED_SYMBOL_FONT
	if(BrToLower(fontName[0]) == 'w')
	{
		if (FontWcsCmp(&fontName[1], (const BrWORD*)u"ingdings")== 0)
		{
			outName = (BrWORD*)szHYWingding;
		}
	}
#endif //USE_EMBEDDED_SYMBOL_FONT

	if(pFace != BrNULL)
	{
		FT_Face ft_face = pFace->ft_face;
		const char* ps_family_name = getPostScriptNameByFontFace(pFace);
		if(ps_family_name)
			BrMultiByteToWideChar(CP_ACP, ps_family_name, strlen(ps_family_name), wTemp, MAX_FONT_LENGTH);

		BrWORD* wFontName = pFace->family_name_Unicode;

		if(	(wFontName && (BoraFontComm::IsValidCJKFontName(outName, wFontName, ft_face->style_name, m_nFontFlag)
			|| ( outName[0] == wFontName[0] && !FontWcsCmp(outName, wFontName) )) )
			|| ( ps_family_name && outName[0] == ps_family_name[0] && !FontWcsCmp(outName, wTemp) )
			)
		{
			BrINT nRet = checkFamilyFontForIndex(outName, pFace, fontStyle);
			if(nRet == 0)
				return BrFALSE;
			else if(nRet == 1)
				return BrTRUE;

			//기존 코드
			// 상기 조건 모두 Skip 시에는 방법이 없어서 기존코드를 사용
			if(fontStyle == 0)
			{
				if(ft_face->style_flags)
					return BrFALSE;

				if(m_nFontFlag == eArialFont)
				{
					if(FontStrCmp(ft_face->style_name,"Regular"))
						return BrFALSE;
				}
			}
			result = BrTRUE; 
		}
	}
	if(familyHName != BrNULL && !result)
	{
		if(BrWcsLen(familyHName) > 0 && !FontWcsCmp(fontName,familyHName))
			result = BrTRUE;
	}
	if(CheckFont != BrNULL && !result)
	{
		if(	BoraFontComm::IsValidCJKFontName(outName, CheckFont->pFamily_name, CheckFont->pStyle_name, m_nFontFlag)
			|| ( BrWcsLen(CheckFont->pFamily_name) > 0 && outName[0] == CheckFont->pFamily_name[0] && !FontWcsCmp(outName, CheckFont->pFamily_name) ) 
			|| (BrWcsLen(CheckFont->pFamily_ps_name) > 0 && outName[0] == CheckFont->pFamily_ps_name[0] && !FontWcsCmp(outName, CheckFont->pFamily_ps_name) )
			)
			result = BrTRUE;
	}

	return result; 
#endif//ifdef USE_COMMON_INTERFACE
	return BrFALSE;
}

BrBOOL BoraFont::IsColorEmojiFont(FT_Face fontFace)
{
	FT_String* family_name = BrNULL;
	unsigned long nCBDTLen = 0;
	if(fontFace == BrNULL)
		return BrFALSE;

	family_name = fontFace->family_name;
	if(family_name == BrNULL)
		return BrFALSE;


	if(family_name[0] == 0x4E && !FontStrCmp(family_name, "Noto Color Emoji"))
		return BrTRUE;
	else if(family_name[0] == 0x4C && !FontStrCmp(family_name, "LG Emoji"))
		return BrTRUE;

	FT_Load_Sfnt_Table(fontFace, TTAG_CBDT, 0, BrNULL, &nCBDTLen);
	if(nCBDTLen > 0)
		return BrTRUE;

	return BrFALSE;
}

PO_Face BoraFont::getCacheFontFace(FT_ULong ch, int fontnameindex, BrINT* pFaceIndex, BrBYTE fontStyle)
{
	CharFontInfo *info;
	for (int n=0;n<m_ncharFontInfoListCount;n++)
	{
		info = m_charFontInfoList[n];
		if ( info->ch == ch && info->fontnameindex == fontnameindex && info->style == fontStyle)
		{
			if ( pFaceIndex )
				*pFaceIndex = info->fontIndex;

			m_bExistFont = info->bExist;
			m_nFontFlag = info->nFontFlag;
			return info->face;
		}
	}
	return BrNULL;
}
void BoraFont::setCacheFontFace(FT_ULong ch, int fontnameindex, PO_Face fontFace, int fontIndex, BrBYTE fontStyle)
{
	BrBOOL bExist = BrFALSE;
	CharFontInfo *info;
	for (int n=0;n<m_ncharFontInfoListCount;n++)
	{
		info = m_charFontInfoList[n];
		if ( info->ch == ch && info->fontnameindex == fontnameindex && info->style == fontStyle)
		{
			bExist = BrTRUE;
			break;
		}
	}
	if ( bExist == BrFALSE )
	{
		info = (CharFontInfo*)PoSysCalloc(1, sizeof(CharFontInfo));
		info->ch = ch;
		info->face = fontFace;
		info->fontIndex = fontIndex;		
		info->fontnameindex = fontnameindex;
		info->style = fontStyle;

		info->bExist = m_bExistFont;
		info->nFontFlag = m_nFontFlag;

		// all clear 후 할당 시 처리
		if (m_ncharFontInfoListLevel <= 0)
		{
			m_ncharFontInfoListLevel = 1;
			m_charFontInfoList = (CharFontInfo**)PoSysCalloc(TTF_FONT_COUNT, sizeof(CharFontInfo*));

		}
		else if ( TTF_FONT_COUNT*m_ncharFontInfoListLevel <= m_ncharFontInfoListCount )
		{
			m_ncharFontInfoListLevel++;
			m_charFontInfoList = (CharFontInfo**)PoSysRealloc(m_charFontInfoList, TTF_FONT_COUNT*sizeof(CharFontInfo*)*m_ncharFontInfoListLevel);
		}
		m_charFontInfoList[m_ncharFontInfoListCount++] = info;
	}
}
void BoraFont::clearCacheFontFace(bool bAll)
{
	for (int n = 0; n < m_ncharFontInfoListCount; n++)
		PoSysFree(m_charFontInfoList[n]);
	if (bAll)
	{
		PoSysFree(m_charFontInfoList);
		m_ncharFontInfoListLevel = 0;
	}
	m_ncharFontInfoListCount = 0;
}

void BoraFont::ReleaseCachedFontData()
{
	//테스트 중...
	return;
	// Locale 변경 시 정리 되어야 할 함수 모음
	clearCacheFontFace();
}

PO_Face BoraFont::findInternalFontFace(FT_ULong ch, BrINT* pFaceIndex, BrBYTE fontStyle, FT_Int nFontWidth, FT_Int nFontHeight)
{
	BrINT nRet = m_InternalFontNameList->BinarySearch(m_pFontName);

	if (nRet > -1)
	{
		BrINT nIdx = m_InternalFontNameList->GetFontListIndex(nRet);	//return m_InternalFontFamilyList index
		nIdx = findInternalFontIndex(nIdx, fontStyle);

		if (nIdx > -1)
		{
			FT_Error bSetCharmap = FT_Err_Ok;
			PO_Face embedFace = getInternalFontFace(nIdx);
			FT_Face face = setFontFaceCharmap(embedFace, bSetCharmap);
			if (face != BrNULL)
			{
				int charmapIdx = embedFace->nPrimaryCharmapIdx;

				if (face->charmap->encoding != FT_ENCODING_NONE && FT_Get_Char_Index(face, ch))
				{
					embedFace->nPrimaryCharmapIdx = charmapIdx;
					return getFontFaceResult(embedFace, ch, fontStyle, nFontWidth, nFontHeight, (int)(0x80000000 | (nIdx << 12) | charmapIdx), pFaceIndex);
				}

				for (charmapIdx = 0; charmapIdx < face->num_charmaps; charmapIdx++)
				{
					FT_Set_Charmap(face, face->charmaps[charmapIdx]);

					//[17.11.21][sglee1206] 내장폰트의 경우 사용하는 charmaps을 임의로 기억하지 않고 그때그때 처리.
					//또한 해당 charmap Index를 Masking처리하여 전달하여 실제 로드시에도 사용할 수 있도록 함
					//[18.02.19][sglee1206] Maksing 추가.
					//0x80000000 | Font Index(0xFF000) | charmap(0xFFF)
					//추후 각각 조건 정리 예정
					if (face->charmap->encoding != FT_ENCODING_NONE && FT_Get_Char_Index(face, ch))
					{
						embedFace->nPrimaryCharmapIdx = charmapIdx;
						return getFontFaceResult(embedFace, ch, fontStyle, nFontWidth, nFontHeight, (int)(0x80000000 | (nIdx << 12) | charmapIdx), pFaceIndex);
					}
				}
			}
		}
	}

	return BrNULL;
}

BrBOOL BoraFont::isEmFamilyFontCode(FT_ULong ch, BrBYTE fontStyle)
{
#ifdef USE_EMFAMILY_HEADER_FONT
	m_bTimesFullset = BrFALSE;

	if (m_EFIndex != eEF_NoneFont)
	{
		if (!m_bUseEFFace[m_EFIndex])
			return BrFALSE;

		if (m_EFIndex > eEF_NoneFont && m_EFIndex <= eEF_VerdanaFont && fontStyle == 0)
		{
			if (ch == 0x00C7
				|| ch == 0x00D3 || ch == 0x00D6 || ch == 0x00DC
				|| ch == 0x00F3 || ch == 0x00F6 || ch == 0x00E7 || ch == 0x00FC
				|| (ch >= 0x010C && ch <= 0x010F)
				|| ch == 0x011A || ch == 0x011B
				|| ch == 0x011E || ch == 0x011F
				|| (ch >= 0x0100 && ch <= 0x0107)
				|| (ch >= 0x0110 && ch <= 0x0113)
				|| (ch >= 0x0116 && ch <= 0x0119)
				|| (ch >= 0x0128 && ch <= 0x012B)
				|| (ch >= 0x012E && ch <= 0x012F)
				|| ch == 0x0130 || ch == 0x0131
				|| (ch >= 0x0141 && ch <= 0x0148)
				|| ch == 0x014C || ch == 0x014D
				|| (ch >= 0x0150 && ch <= 0x0153)
				|| (ch >= 0x0158 && ch <= 0x015B)
				|| (ch >= 0x015E && ch <= 0x0161)
				|| ch == 0x0164 || ch == 0x0165
				|| (ch >= 0x0168 && ch <= 0x016B)
				|| ch == 0x016E || ch == 0x016F
				|| (ch >= 0x0178 && ch <= 0x017E)
				|| (ch >= 0x0170 && ch <= 0x0173)
				|| ch == 0x01A0 || ch == 0x01A1 || ch == 0x01AF || ch == 0x01B0
				|| (ch >= 0x1EA0 && ch <= 0x1EF9)
				|| ch == 0x2022 || ch == 0x201E || ch == 0x2014
				)
				return BrTRUE;
		}

		if (ch >= EMFAMILY_BASECODE_MIN && ch <= EMFAMILY_BASECODE_MAX)
			return BrTRUE;

		if (m_EFIndex == eEF_TimesFont && FT_Get_Char_Index(m_poFullSetFont.pFullSet->ft_face, ch))
		{
			m_bTimesFullset = BrTRUE;
			return BrTRUE;
		}

		if (m_EFIndex == eEF_ArialFont || m_EFIndex == eEF_CourFont)
		{
			if ((ch >= EMFAMILY_BASECODE_MIN && ch <= EMFAMILY_ARABIC_END)
				|| IS_UCS2_Alphabetic_Presentation_Forms(ch) || IS_UCS2_Arabic_Presentation_Forms_A(ch) || IS_UCS2_Arabic_Presentation_Forms_B(ch) 
				|| (ch >= 0x2190 && ch <= 0x2195))
				return BrTRUE;
		}
		else if (m_EFIndex == eEF_TahomaFont)
		{
			if ((ch >= EMFAMILY_BASECODE_MIN && ch <= EMFAMILY_ARABIC_END)
				/*|| ( ch >= EMFAMILY_THAI_START && ch <= EMFAMILY_THAI_END ) */	//Tahoma 관련 태국어 처리가 아직 완료 되지 않았기 때문에 6.0 부터 지원하는 걸로 하자!
				|| IS_UCS2_Alphabetic_Presentation_Forms(ch) || IS_UCS2_Arabic_Presentation_Forms_A(ch) || IS_UCS2_Arabic_Presentation_Forms_B(ch))
				return BrTRUE;
		}
		else if (m_EFIndex == eEF_VerdanaFont)
		{
			if ((ch >= EMFAMILY_BASECODE_MIN && ch <= EMFAMILY_CYRILLIC_END) 
				|| IS_UCS2_Latin_Extended_Additional(ch))
				return BrTRUE;
		}
	}
#endif
	return BrFALSE;
}

BrBOOL BoraFont::checkGlyphBitmap(PO_Face pFace, FT_ULong ch, FT_Int nFontWidth, FT_Int nFontHeight)
{
	if (!pFace || !pFace->ft_face)
		return BrFALSE;

	FT_Face fontFace = pFace->ft_face;
	FT_Error error = FT_Err_Ok;

	setFontFaceSize(fontFace, ch, nFontWidth, nFontHeight);

	FT_Face pCheck_ft_face = setFontFaceCharmap(pFace, error);
	if (pCheck_ft_face)
	{
		FT_ULong  char_code = ch;
		BrBOOL bSymbolFont = BrFALSE;
		char_code = ConvertSymbolChar(pFace, char_code, bSymbolFont);

		//기존에 m_PrevFormat 였으나 해당 Flag는 Embolden 시 사용하는 것으로 불필요하여 별도로 빼서 체크함
		FT_Glyph_Format			prevFormat;
		if (!bSymbolFont)
			error = (Bora_2_FT_Load_Char(pCheck_ft_face, char_code, FT_LOAD_DEFAULT, prevFormat, m_pBoraMultiLang->GetFontGlyphIndex(), BrFALSE) == -1) ? -1 : 0;
		else
			error = (Bora_2_FT_Load_Char(pCheck_ft_face, char_code, FT_LOAD_DEFAULT, prevFormat, m_pBoraMultiLang->GetFontGlyphIndex(), BrFALSE) != 0) ? -1 : 0;
	}

	if(!BoraFontComm::IsBlankChar(ch)
		&& (fontFace->glyph->metrics.width == 0 || fontFace->glyph->metrics.height == 0))
		return BrFALSE;
	else
		return BrTRUE;
}


PO_Face BoraFont::GetFontFace(FT_ULong ch, BrBYTE fontStyle, FT_Int nFontWidth, FT_Int nFontHeight, BrBOOL bFontExistCheck, BrINT* pFaceIndex, BrBOOL *bFind, BrBOOL bForceFind, BrBOOL bLocaleFind)
{
	FT_Face fontFace = BrNULL;
	PO_Face pFace = BrNULL;
	FT_Error error = FT_Err_Ok;
	
	BrINT nFaceIndex = m_nBaseIndex;
	BrINT nOldFaceIndex = -1;
	BrBOOL bChina = checkChinese(ch);
	FT_UInt nFontFaceCnt = GetFontFaceCnt();

	//[16.07.01][sglee1206] 잘못된 폰트를 찾는 경우가 존재하여 六이 출력안되는 이슈[XPD-4670]
	//실제 폰트를 찾을 때 Font를 찾았는 지 체크하는 Flag. 
	//이 Flag가 없는 경우에 한자를 찾으면 마지막 조건에서 다른 폰트로 대체되는 문제가 있어서 처리함( if( !bFontFind && checkChineseChar(ch) ) <- 이 조건)
	BrBOOL bFontFind = BrFALSE;
	BrBOOL bCheckGlyphBitmap = BrFALSE;
	BrINT n = 0;

	//1. 이미 한번 설정한 폰트인 경우에 활용한다.
	if ( pFaceIndex && !bFind && !bForceFind && m_nCurFontNameIndex >= 0)
	{
		pFace = getCacheFontFace(ch, m_nCurFontNameIndex, pFaceIndex, fontStyle);
		if ( pFace )
		{
			m_nOldIndex = *pFaceIndex;

			changeFontName(m_pPrevFontName, m_pFontName);

			return getFontFaceResult(pFace, ch, fontStyle, nFontWidth, nFontHeight);
		}
	}
	
	if(pFaceIndex) 
	{
		nOldFaceIndex = *pFaceIndex;
		*pFaceIndex = nFaceIndex;
	}

	//[16.07.01][sglee1206] 최하단의 조건을 처리하기위한 Flag이므로 bFind와 pair를 맞춰서 처리하여야 함
	bFontFind = BrTRUE;
	if(bFind) *bFind = BrTRUE;
	
#ifdef USE_PRIMARY_FONT
	nFaceIndex = m_nBaseIndex;
	pFace = GetFontFaceByIndex(nFaceIndex);
	fontFace = setFontFaceCharmap(pFace, error);

	if (fontFace && FT_Get_Char_Index(fontFace, ch))
		return getFontFaceResult(pFace, ch, fontStyle, nFontWidth, nFontHeight, nFaceIndex, pFaceIndex);
#endif

#ifndef USE_PC_VERSION_FONT
	if(getEmbFontFace(&pFace, ch, pFaceIndex, nFontWidth, nFontHeight, fontStyle) )
	{
		PO_Face internalFace = findInternalFontFace(ch, pFaceIndex, fontStyle, nFontWidth, nFontHeight);
		
		if (internalFace)
			return internalFace;

		//[19.02.01][sglee1206] 내장폰트 사용시 Flag나 Index값 변경 [POD-2336]
		//*pFaceIndex의 경우 위에 조건처리하는 함수에서 세팅하는데 다른값으로 변경되어 아래와 같이 작성
		if(pFaceIndex)
			nFaceIndex = *pFaceIndex;
		//m_bExistFont는 실제 폰트를 찾은 경우 사용되는데 EmbeddedFont와는 상관이 없는 Flag이므로 해당 경우 False처리 필요
		m_bExistFont = BrFALSE;

		return getFontFaceResult(pFace, ch, fontStyle, nFontWidth, nFontHeight, nFaceIndex, pFaceIndex);
	}
#endif

	if(m_pBoraMultiLang->GetFontGlyphIndex() >= 0 && m_pLocaleIndexHash)
	{
		Font_LocaleIndexVal* localeFontValue = m_pLocaleIndexHash->Lookup_Font_LocaleIDXHash(makeLocaleIndexHashKey(fontStyle));
		if(localeFontValue != BrNULL)
		{
			m_nLocaleFontIndex = localeFontValue->nLocaleFontIndex;
			m_LocaleFontFace = localeFontValue->LocaleFontFace;
		}
		else
		{
			BrTrace("locale Glyph Index : 0x%x. find font face : %s",m_pBoraMultiLang->GetFontGlyphIndex(),m_LocaleFontFace->ft_face->family_name);
			//[17.12.28][sglee1206] 해당 Case가 발생하면 안되나 현시점에서 문제가 되어 이런 경우 0로 치환함
			m_pBoraMultiLang->SetFontGlyphIndex(-1);
		}

		pFace = m_LocaleFontFace;
		return getFontFaceResult(m_LocaleFontFace, ch, fontStyle, nFontWidth, nFontHeight, m_nLocaleFontIndex, pFaceIndex);
	}

	//직전 폰트 체크
	if(m_CheckFontStyle == fontStyle && !FontWcsCmp(m_pPrevFontName, m_pFontName))
	{
		if( m_nOldIndex >= 0 && m_bExistFont )
		{
			nFaceIndex = m_nOldIndex;
			pFace = GetFontFaceByIndex(nFaceIndex);
			if (hasFontGlyph(pFace, ch))
			{
				if (pFaceIndex) *pFaceIndex = nFaceIndex;
				return getFontFaceResult(pFace, ch, fontStyle, nFontWidth, nFontHeight, m_nOldIndex, pFaceIndex);
			}
		}
	}
	else
	{
		if(!FontWcsCmp(m_pFontName, (const unsigned short*)u""))
		{
			changeFontName(m_pFontName, m_pPrevFontName);
			bCheckGlyphBitmap = BrTRUE;
		}
	}		

	changeFontName(m_pPrevFontName, BrNULL);
	m_bExistFont = BrFALSE;

	if(getInternalFontFaceCount() > 0)
	{
		PO_Face internalFace = findInternalFontFace(ch, pFaceIndex, fontStyle, nFontWidth, nFontHeight);

		if (internalFace)
			return internalFace;
	}


	pFace = GetFontFaceByIndex(nFaceIndex = m_nBaseIndex);

#ifdef SUPPORT_ADD_FONT
	if (pFace == BrNULL || fontFace == BrNULL)
		pFace = GetFontFaceByIndex(0);
#endif//SUPPORT_ADD_FONT
	fontFace = pFace->ft_face;

	BrBOOL bSkip = BrFALSE;
	BrBOOL bHancomWingdingSymbols = ((getDocType() == BORA_DOCTYPE_HWP || getDocType() == BORA_DOCTYPE_ODT) && (ch >= 0xF020 && ch <= 0xF0FF));
	
	if( !FontWcsCmp(m_pPrevFontName, (const unsigned short*)u"") )
	{
#ifdef USE_TTF_MATH_HEADER_FONT
		if(!m_pSystemMathFontName && !FontWcsCmp(m_pFontName, DEFAULT_MATH_FONT_NAME,BrWcsLen(DEFAULT_MATH_FONT_NAME)) )
		{
			for(int mathIdx = m_nMathIndex; mathIdx < nFontFaceCnt && 
				!FontWcsCmp(GetFontFaceByIndex(mathIdx)->family_name_Unicode, DEFAULT_MATH_FONT_NAME, BrWcsLen(DEFAULT_MATH_FONT_NAME)); mathIdx++)
			{
				pFace = GetFontFaceByIndex(mathIdx);
				fontFace = pFace->ft_face;
				if(fontFace->style_flags == fontStyle && FT_Get_Char_Index(fontFace, ch))
				{
					m_nOldIndex = nFaceIndex = mathIdx;
					changeFontName(m_pPrevFontName, m_pFontName);
					m_bExistFont = BrTRUE;
					return getFontFaceResult(pFace, ch, fontStyle, nFontWidth, nFontHeight, nFaceIndex, pFaceIndex);
				}
				else if(IS_UCS4_Mathematical_Alphanumeric_Symbols(ch) && FT_Get_Char_Index(fontFace, ch))
				{
					m_nOldIndex = nFaceIndex = mathIdx;
					changeFontName(m_pPrevFontName, m_pFontName);
					m_bExistFont = BrTRUE;
					return getFontFaceResult(pFace, ch, fontStyle, nFontWidth, nFontHeight, nFaceIndex, pFaceIndex);
				}
			}
			bSkip = BrTRUE;
		}
#endif //USE_TTF_MATH_HEADER_FONT
#ifdef USE_TTF_HWP_MATH_HEADER_FONT
		if( !FontWcsCmp(m_pFontName, (const unsigned short*)HWP_MATH_FONT_NAME) )
		{
			PO_Face tmpFace = getFontFaceEx(m_nHWPMathIndex, fontStyle, nFontWidth, nFontHeight, pFaceIndex, bFind, ch);
			if(tmpFace != BrNULL)
			{
				m_nOldIndex = nFaceIndex = m_nHWPMathIndex;
				changeFontName(m_pPrevFontName, m_pFontName);
				m_bExistFont = BrTRUE;
				return tmpFace;
			}
		}
#endif //USE_TTF_HWP_MATH_HEADER_FONT


		BrBOOL bFindFontFace = BrFALSE;
		BrBOOL bExistSet = BrFALSE;
		BrINT8 nSPFlag = eSPFONT_NONE_FACE;
#if defined(USE_EMBEDDED_SYMBOL_FONT)
		nSPFlag = GetSpecialFontFlag(ch);
#endif
		if (!bSkip)
		{
#if defined( SUPPORT_ADD_FONT )
			bExistSet = BrTRUE;
#if defined(USE_EMBEDDED_SYMBOL_FONT)
			if (nSPFlag > eSPFONT_NONE_FACE&& nSPFlag < eSPFONT_MAX_FACE) {
				n = GetSpecialFontFlag2Index(nSPFlag);

				if (n > -1)
					bFindFontFace = BrTRUE;
			}
			else
#endif //USE_EMBEDDED_SYMBOL_FONT
			{
				BrINT nRet = getFontNameListIndex(m_pFontName);
				//[16.02.12][sglee1206] MS Office처럼 대체되는 폰트 찾아 처리
				if (nRet <= -1) {
					BrWORD MSAlterFontName[MAX_FONT_LENGTH] = { 0, };
					BoraFontComm::GetAlterFontName(m_pFontName, MSAlterFontName, MAX_FONT_LENGTH);
					if (FontWcsCmp(m_pFontName, MSAlterFontName))
					{
						nRet = getFontNameListIndex(MSAlterFontName);
					}
				}

#if defined( USE_PC_VERSION_FONT ) && defined( USE_PANOSE_INFO )

				if (!isLoadedPanoseFont(m_pFontName))
					m_bFindAltFont = BrFALSE;

				if (nRet <= -1 && !m_bFindAltFont)
					FindAltFontUsePanose(m_pFontName);

				if (nRet <= -1)
				{
					BrWORD* altPanoseFontName = BrNULL;
					altPanoseFontName = existPanoseAlterFont(fontStyle);

					if (altPanoseFontName != BrNULL)
					{
						nRet = getFontNameListIndex(altPanoseFontName);
						nFontFaceCnt = GetFontFaceCnt();
						PoSysFree(altPanoseFontName);
					}

				}
#endif

				BrINT nRuntimeFontIndex;
				BrINT* pFaceIndexHash = BrNULL;
				LPBrFontStyleIdxNode pNode = BrNULL;
				if (nRet > -1) {
					nRuntimeFontIndex = m_pFontNameList->GetFontListIndex(nRet);
					{
						if (!bFindFontFace)
						{
							pNode = getFontListNode(nRuntimeFontIndex, fontStyle);
						}

						BrINT nRunTimeFont = -1;
						BrBOOL bRet = BrFALSE;
						while (pNode != BrNULL && bRet == BrFALSE)
						{
							nRunTimeFont = pNode->nFontIndex;
							//[16.05.13][sglee1206] symbol Font Load 시 base Font index가 증가하여 문제 발생. [XPD-1766]
							// 시작 index 수정
							for (BrINT i = 0; i < nFontFaceCnt; i++)
							{
								if (nRunTimeFont == GetFontFaceByIndex(i)->nFontListIndex)
								{
									bFindFontFace = BrTRUE;
									pFace = GetFontFaceByIndex(i);
									n = i;
									break;
								}
							}

							bRet = hasFontGlyph(GetFontFaceByIndex(n), ch);

							if (bCheckGlyphBitmap)
							{
								if (!checkGlyphBitmap(GetFontFaceByIndex(n), ch, nFontWidth, nFontHeight))
									bRet = BrFALSE;
							}

							bSkip = !bRet;
							pNode = pNode->pNext;
						}
					}
				}
			}
#else	// defined( SUPPORT_ADD_FONT ) && defined( USE_PC_VERSION_FONT )
			BrBOOL bCurrentFontFind = bFontExistCheck;
#if defined(USE_EMBEDDED_SYMBOL_FONT)
			bCurrentFontFind |= (nSPFlag > eSPFONT_NONE_FACE&& nSPFlag < eSPFONT_MAX_FACE);
#endif
			if (bCurrentFontFind || bHancomWingdingSymbols)
			{
				BrWORD* pHancomWingdingAlterName[3] = { (BrWORD*)u"HYWingding", (BrWORD*)u"Wingdings", BrNULL };
				BrWORD* pSystemFontHName = BrNULL;
				BrINT	nSystemFontIdx, nTypefaceListIndex;
				BrINT	alterIndex = n;
				for (; n < nFontFaceCnt; n++)
				{
					nSystemFontIdx = GetFontFaceByIndex(n)->nFontListIndex;
					pSystemFontHName = BrNULL;
					if (nSystemFontIdx != -1)
					{
						nTypefaceListIndex = m_RuntimeLoadFont.at(nSystemFontIdx)->nTypefaceListIndex;
						if (nTypefaceListIndex >= 0)
						{
							pSystemFontHName = m_aTypeFaceList.at(nTypefaceListIndex)->sFontData.pLocName;
						}
					}

					BrBOOL bFindFamilyName =
						IsFamilyFontName(m_pFontName, GetFontFaceByIndex(n), fontStyle, pSystemFontHName)
#ifdef USE_EMBEDDED_SYMBOL_FONT
						|| (nSPFlag == eSPFONT_SYMBOL_FACE && n == m_nSymbolIndex)
						|| (nSPFlag == eSPFONT_WINGDING_FACE && n == m_nWindingIndex)
						|| (nSPFlag == eSPFONT_WINGDING2_FACE && n == m_nWinding2Index)
						|| (nSPFlag == eSPFONT_WINGDING3_FACE && n == m_nWinding3Index)
						|| (nSPFlag == eSPFONT_WEBDINGS_FACE && n == m_nWebdingsIndex)
#endif //USE_EMBEDDED_SYMBOL_FONT
						;

					if (!bFindFamilyName && bHancomWingdingSymbols)
					{
						for (int wingdingsIdx = 0; pHancomWingdingAlterName[wingdingsIdx] != BrNULL; wingdingsIdx++)
						{
							if (IsFamilyFontName(pHancomWingdingAlterName[wingdingsIdx], GetFontFaceByIndex(n), fontStyle, pSystemFontHName))
							{
								bFindFamilyName = BrTRUE;
								break;
							}
						}
					}

					if (bFindFamilyName)
					{
						pFace = GetFontFaceByIndex(n);
						
						BrBOOL bRet = hasFontGlyph(pFace, ch);
						
						if (!bRet)
							continue;

						if (bCheckGlyphBitmap)
						{
							if(!checkGlyphBitmap(GetFontFaceByIndex(n), ch, nFontWidth, nFontHeight))
								continue;
						}
						
						bFindFontFace = BrTRUE;
						//bExistSet = !bHancomWingdingSymbols || (bHancomWingdingSymbols && !IsFamilyFontName(pHancomWingdingAlterName[0], pFace, fontStyle, pHancomWingdingAlterName[1]));
						bExistSet = !bHancomWingdingSymbols || !IsFamilyFontName(pHancomWingdingAlterName[0], pFace, fontStyle, pHancomWingdingAlterName[1]);
						break;
					}
				}
			}
#endif	// defined( SUPPORT_ADD_FONT ) && defined( USE_PC_VERSION_FONT )
		}

		if (!bSkip && bFindFontFace) {
			m_nOldIndex = nFaceIndex = n;
			changeFontName(m_pPrevFontName, m_pFontName);
			if(bExistSet)
				m_bExistFont = BrTRUE;

			return getFontFaceResult(GetFontFaceByIndex(n), ch, fontStyle, nFontWidth, nFontHeight, nFaceIndex, pFaceIndex);
		}
	}

	changeFontName(m_pPrevFontName, m_pFontName);
	m_bExistFont = BrFALSE;

	if(getInternalFontFaceCount() > 0)
	{
		PO_Face internalFace = findInternalFontFace(ch, pFaceIndex, fontStyle, nFontWidth, nFontHeight);

		if (internalFace)
			return internalFace;
	}

	//이부분도 검토 필요
	BrINT nBSIndex;
	if(m_nEFIndex != -1)
		nBSIndex = m_nEFIndex;
	else
		nBSIndex = m_nBaseIndex;

	BrINT32 nLocale = PoGetLocale();
	if(
		(nLocale == BR_LOCALE_JAPANESE || nLocale == BR_LOCALE_S_CHINESE || nLocale == BR_LOCALE_T_CHINESE_HK || nLocale == BR_LOCALE_T_CHINESE_TW)
		&& (IS_HANJA(ch) || IS_JAPANESE(ch) || IS_UCS2_CJK_Symbols_and_Punctuation(ch))
		)
	{
		if(m_nEFIndex != -1 || m_nEFIndex == 0)
			nBSIndex = 1;
		else
			nBSIndex = m_nEFIndex;
	}

	if( nBSIndex < 0 )
		nBSIndex = 0;

	//[16.07.01][sglee1206] 최하단의 조건을 처리하기위한 Flag이므로 bFind와 pair를 맞춰서 처리하여야 함
	bFontFind = BrFALSE;
	if(bFind) *bFind = BrFALSE;

	//[16.03.14][sglee1206] 한자의 경우 한중일 한자가 조금씩 다르므로 해당 나라에 맞는 폰트로 출력되어야 함
	//따라서 시스템 폰트 전달시(BGetSystemFont) 최상단에 해당 국가 대표폰트가 오도록 UI처리 필요[CSP-3146][CSP-3188]
	//PC버전의 경우는 다른 방향으로 처리하여야하므로 관련피쳐로 처리
#if !defined( USE_PC_VERSION_FONT ) && !defined( USE_ALTERNATE_FONT )
	BrBOOL bMincho = CUtil::WcsStr(m_pFontName, (const unsigned short*)u"Mincho") != NULL;
	//if(nLocale == BR_LOCALE_JAPANESE || nLocale == BR_LOCALE_S_CHINESE || nLocale == BR_LOCALE_T_CHINESE_HK || nLocale == BR_LOCALE_T_CHINESE_TW)
	if(IS_HANJA(ch) || IS_UCS2_CJK_Symbols_and_Punctuation(ch))
	{
		BrBOOL bFindSFont = BrFALSE;
		// 구현부


		// PC 버전이 아닌경우에 Locale에 따라 한자 처리
		BR_LOCALE_TYPE nLocale = PoGetLocale();
		const char* nTag = NULL;
		if (BR_LOCALE_KOREAN == nLocale)
		{
			nTag = "Hang";
		}
		else if (BR_LOCALE_S_CHINESE == nLocale)
		{
			nTag = "Hans";
		}
		else if (BR_LOCALE_T_CHINESE_HK == nLocale)
		{
			nTag = "Hant";
		}
		else if (BR_LOCALE_T_CHINESE_TW == nLocale)
		{
			nTag = "Hant";
		}


		if (nTag != NULL && m_aLocaleDefaultFontName.size() > 0)
		{
			BrINT localeIndex = -1;

			for (n = 0; n < m_aLocaleDefaultFontName.size(); n++)
			{
				if (!FontStrCmp(nTag, m_aLocaleDefaultFontName.at(n)->scriptTag))
				{
					int defaultFontIdx = 0;
					localeIndex = n;
					while (!bFindSFont && defaultFontIdx < m_aLocaleDefaultFontName.at(localeIndex)->fontNameCnt)
					{
						BrWORD* pFontName = m_aLocaleDefaultFontName.at(localeIndex)->defaultFontName[defaultFontIdx];
						BrWORD* pName = BrNULL;
						if (pFontName)
						{
							for (int nIdx = m_nBaseIndex; nIdx < nFontFaceCnt; nIdx++)
							{
								pName = GetFamilyNameByIndex(nIdx);
								if (pName != BrNULL && CUtil::WcsStr(pName, pFontName) != NULL)
								{
									if (BoraFontComm::IsSkipPurchaseFontChar(ch, GetFamilyNameByIndex(nIdx)))
									{
										continue;
									}

									if (FT_Get_Char_Index(getFTFaceByIndex(nIdx), ch))
									{
										if (!bFindSFont)
										{
											bFindSFont = BrTRUE;
											nFaceIndex = nIdx;
											pFace = GetFontFaceByIndex(nIdx);
										}
									}
									break;
								}
							}
						}
						defaultFontIdx++;
					}

				}
			}

			bFontFind = bFindSFont;
			if (bFind) *bFind = bFindSFont;
			if (bFindSFont)
				return getFontFaceResult(pFace, ch, fontStyle, nFontWidth, nFontHeight, nFaceIndex, pFaceIndex);
		}
		

		// 상기 추가된 내용으로 처리되지 않는경우 기존과 동일하게 처리
		for(int nIdx = m_nBaseIndex; nIdx<nFontFaceCnt; nIdx++ )
		{
			if (BoraFontComm::IsSkipPurchaseFontChar(ch, GetFamilyNameByIndex(nIdx)))
			{
				continue;
			}

			if( FT_Get_Char_Index( getFTFaceByIndex(nIdx), ch) )
			{
#ifdef USE_FOR_IOS
				//if(nLocale == BR_LOCALE_JAPANESE)
				{
					if(bMincho)
					{
						if(GetFamilyNameByIndex(nIdx) != BrNULL && CUtil::WcsStr(GetFamilyNameByIndex(nIdx), (const unsigned short*)u"Mincho") != NULL)
						{
							bFindSFont = BrTRUE;
							nFaceIndex = nIdx;
							pFace = GetFontFaceByIndex(nIdx);
							break;
						}
					}
				}
#endif
				if (bCheckGlyphBitmap)
				{
					if (!checkGlyphBitmap(GetFontFaceByIndex(n), ch, nFontWidth, nFontHeight))
						continue;
				}

				if(!bFindSFont)
				{
					bFindSFont = BrTRUE;
					nFaceIndex = nIdx;
					pFace = GetFontFaceByIndex(nIdx);
#ifdef USE_FOR_IOS
					if (!bMincho)
#endif
						break;
				}
			}
		}

		//[16.07.01][sglee1206] 최하단의 조건을 처리하기위한 Flag이므로 bFind와 pair를 맞춰서 처리하여야 함
		bFontFind = bFindSFont;
		if(bFind) *bFind = bFindSFont;
		if( bFindSFont )
			return getFontFaceResult(pFace, ch, fontStyle, nFontWidth, nFontHeight, nFaceIndex, pFaceIndex);
	}
	else if (IS_JAPANESE(ch))
	{
		BrBOOL bFindSFont = BrFALSE;
		// 구현부
		for (int nIdx = m_nBaseIndex; nIdx < nFontFaceCnt; nIdx++)
		{
			if (FT_Get_Char_Index(getFTFaceByIndex(nIdx), ch))
			{
#ifdef USE_FOR_IOS
				//if(nLocale == BR_LOCALE_JAPANESE)
				{
					if (bMincho)
					{
						if (GetFamilyNameByIndex(nIdx) != BrNULL && CUtil::WcsStr(GetFamilyNameByIndex(nIdx), (const unsigned short*)u"Mincho") != NULL)
						{
							bFindSFont = BrTRUE;
							nFaceIndex = nIdx;
							pFace = GetFontFaceByIndex(nIdx);
							break;
						}
					}
				}
#endif
				if (bCheckGlyphBitmap)
				{
					if (!checkGlyphBitmap(GetFontFaceByIndex(n), ch, nFontWidth, nFontHeight))
						continue;
				}

				if (!bFindSFont)
				{
					bFindSFont = BrTRUE;
					nFaceIndex = nIdx;
					pFace = GetFontFaceByIndex(nIdx);
#ifdef USE_FOR_IOS
					if (!bMincho)
#endif
						break;
				}
			}
		}

		//[16.07.01][sglee1206] 최하단의 조건을 처리하기위한 Flag이므로 bFind와 pair를 맞춰서 처리하여야 함
		bFontFind = bFindSFont;
		if (bFind) *bFind = bFindSFont;
		if (bFindSFont)
			return getFontFaceResult(pFace, ch, fontStyle, nFontWidth, nFontHeight, nFaceIndex, pFaceIndex);
	}
#endif

	if (!bForceFind)
	{
#if defined( USE_PC_VERSION_FONT ) || defined( USE_ALTERNATE_FONT )
		BrBOOL bAlternateHancomFont = BrTRUE;

		// [18.09.11][sglee1206] 동일 폰트가 없는 경우 일부폰트 대체 Case.
		//기존에는 HWP, ODT이나 한글인 경우에만 적용하였으나 동일폰트로 영문 작성시 대체 폰트가 달라서 문제가 됨
		//해당 Case에도 존재하지 않는다면 기본값으로 출력됨
		PO_Face tmpFace = BrNULL;

		//[19.03.07][minseob][OFF-18703] 폰트에 해당 언어의 글자 글립이 없을 경우 윈도우 기본 폰트로 매칭
		//[19.12.10][sglee1206] 조건문으로 인해 일부 조합처리시 오류 발생
		//if(!bLocaleFind)
		tmpFace = getFontFaceForLocalLang(ch, fontStyle, nFontWidth, nFontHeight, pFaceIndex, bFind);

		// [19.01.04][sglee1206] GetLocaleFontFace 에서 호출 시에는 처리하지 말아야함
		if (!bLocaleFind && tmpFace == BrNULL && !m_bFindAltFont)
			tmpFace = getFontFaceForHWP(ch, bHancomWingdingSymbols, fontStyle, nFontWidth, nFontHeight, pFaceIndex, bFind, bForceFind, &bAlternateHancomFont);

		if (tmpFace == BrNULL &&
			(getDocType() == BORA_DOCTYPE_HWP || getDocType() == BORA_DOCTYPE_ODT || IS_MODERN_KOREAN(ch)))
			tmpFace = getFontFaceForKorean(ch, bHancomWingdingSymbols, fontStyle, nFontWidth, nFontHeight, pFaceIndex, bFind, bForceFind, bAlternateHancomFont);

		if (tmpFace != BrNULL) {
			return tmpFace;
		}
#endif //defined( USE_PC_VERSION_FONT ) || defined( USE_ALTERNATE_FONT )


#if defined( USE_PC_VERSION_FONT ) && !defined( USE_ALTERNATE_FONT )
		if (!BIsODTEditorApp() && m_nBaseIndex < nFontFaceCnt)
			nBSIndex = m_nBaseIndex;

#endif		

		if(m_aLocaleDefaultFontName.size() > 0)
		{
			BrINT nRet = -1;
			const char* nTestTag = NULL;
			if (IS_MODERN_KOREAN(ch))	// ch로 영역 확인 후 
			{
				nTestTag = "Hang";
			}
			else if (IS_UCS2_Thai(ch))
			{
				nTestTag = "Thai";
			}
			else if (IS_UCS2_Khmer(ch))
			{
				nTestTag = "Khmr";
			}
			else if (IS_UCS2_Arabic(ch))
			{
				nTestTag = "Arab";
			}

			if(nTestTag != NULL)
			{
				BrINT localeIndex = -1;

				for (n = 0; n < m_aLocaleDefaultFontName.size(); n++)
				{
					if (!FontStrCmp(nTestTag, m_aLocaleDefaultFontName.at(n)->scriptTag))
					{
						localeIndex = n;
						break;
					}
				}

				int defaultFontIdx = 0;
				if (localeIndex >= 0)
				{
					BrWORD* pFontName = m_aLocaleDefaultFontName.at(localeIndex)->defaultFontName[defaultFontIdx];
					nRet = getFontNameListIndex(pFontName);
					defaultFontIdx++;

					while (nRet < 0 && defaultFontIdx < m_aLocaleDefaultFontName.at(localeIndex)->fontNameCnt)
					{
						pFontName = m_aLocaleDefaultFontName.at(localeIndex)->defaultFontName[defaultFontIdx];
						nRet = getFontNameListIndex(pFontName);
						defaultFontIdx++;
					}
				}
				BrINT nRuntimeFontIndex = -1;
				LPBrFontStyleIdxNode pNode = BrNULL;
				if (nRet > -1)
				{
					defaultFontIdx--;				
					nRuntimeFontIndex = m_pFontNameList->GetFontListIndex(nRet);
					pNode = getFontListNode(nRuntimeFontIndex, fontStyle);

					BrINT nRunTimeFont = -1;
					BrBOOL bRet = BrFALSE;
					BrBOOL bTryLoad = BrFALSE;
					nRunTimeFont = pNode->nFontIndex;
					BrINT testIndex = 0;
					//Find
					for (testIndex = 0; testIndex < nFontFaceCnt; testIndex++)
					{
						if (nRunTimeFont == GetFontFaceByIndex(testIndex)->nFontListIndex)
						{
							break;
						}
					}

					//Load
					if (testIndex < 0 || testIndex >= nFontFaceCnt)
					{
						BrINT nIndex = loadSystemFontFile(nRuntimeFontIndex, m_aLocaleDefaultFontName.at(localeIndex)->defaultFontName[defaultFontIdx]);
						nFontFaceCnt = GetFontFaceCnt();
						for (n = nIndex; n < nFontFaceCnt; n++)
						{
							error = FT_Err_Ok;
							PO_Face po_face = GetFontFaceByIndex(n);
							FT_Face ft_face = setFontFaceCharmap(po_face, error);

							if (NULL == ft_face)
								continue;

							if (FT_Get_Char_Index(ft_face, ch))
							{
								nBSIndex = n;
								break;
							}
						}
					}
				}
			}
		}

		for(n=nBSIndex; n<nFontFaceCnt; n++ )
		{
			//[15.09.08][hadion] private user area 의 코드 일 경우 다른 폰트로 대체하지 않음
			//[17.12.28][sglee1206] 예외상황을 처리하는 함수구현 필요
			//[19.01.04][sglee1206] 예외상황을 처리하는 함수구현
			//[21.05.26][sglee1206] 특정 조건(HWP에서 바탕폰트로 한양 PUA 입력)일때 폴라리스 바탕으로 대체함.
			if(BoraFontComm::IsReservedChar(ch) || ((getDocType()  != BORA_DOCTYPE_HWP) && (ch >= 0xE000 && ch <= 0xF8FF /*private user area*/)))
				break;

			error = FT_Err_Ok;
			PO_Face po_face = GetFontFaceByIndex(n);
			FT_Face ft_face = setFontFaceCharmap(po_face, error);

			if(NULL == ft_face)
				continue;


			if (m_EFIndex != eEF_NoneFont && !m_bUseEFFace[m_EFIndex] && SearchTable(ch, fontStyle))
			{
				if (FontStrCmp(m_EFFace[m_EFIndex]->ft_face->family_name, ft_face->family_name))
					continue;
			}

			if (BoraFontComm::IsSkipPurchaseFontChar(ch, po_face->family_name_Unicode))
			{
				continue;
			}

			if (!HAS_FONT_FLAG(fontStyle, FT_STYLE_FLAG_ITALIC) && (ft_face->style_flags  & FT_STYLE_FLAG_ITALIC) == FT_STYLE_FLAG_ITALIC)
			{
				continue;
			}

			if (!HAS_FONT_FLAG(fontStyle, FT_STYLE_FLAG_BOLD) && (ft_face->style_flags & FT_STYLE_FLAG_BOLD) == FT_STYLE_FLAG_BOLD)
			{
				continue;
			}

			BrINT nFindChineseIdx = -1;
			if( FT_Get_Char_Index(ft_face, ch) )
			{
				if (getDocType() == BORA_DOCTYPE_HWP) 
				{
					//[21.05.26][sglee1206] 특정 조건(HWP에서 바탕폰트로 한양 PUA 입력)일때 폴라리스 바탕으로 대체함.
					if (IS_UCS2_Private_Use_Area(ch))
					{
						if (CUtil::WcsStr(m_pFontName, (const unsigned short*)u"\xBC14\xD0D5"))
						{
							if (!FontWcsCmp(po_face->family_name_Unicode, sPurchaseFontName[ePolaris_Batang][0]) ||
								(sPurchaseFontName[ePolaris_Batang][1] != BrNULL &&
									!FontWcsCmp(po_face->family_name_Unicode, sPurchaseFontName[ePolaris_Batang][1]))
								)
								BrTrace("PUA old Korean...");
							else
								continue;
						}
					}
					else if (IS_UCS2_Mathematical_Operators(ch))
					{
						if (!FontStrCmp(ft_face->family_name, "NanumGothic"))
							continue;
					}
					//[CLT-2384] 한컴 PUA 영역을 Color Emoji로 대체하여 문제 발생.
					else if (ch >= 0xF0000 && ch <= 0xFFFFF /*Supplementary_Private_Use_Area_A*/)
					{
						if (IsColorEmojiFont(ft_face))
							continue;
					}
				}

				if (ch >= 0xA000 && ch <= 0xA6FF)
				{
					//폴라리스 중고딕에는 Yi Syllables 영역에 기호가 있으므로 skip
					if (!FontWcsCmp(po_face->family_name_Unicode, sPurchaseFontName[ePolarisGothicM][0]) ||
						(sPurchaseFontName[ePolarisGothicM][1] != BrNULL &&
							!FontWcsCmp(po_face->family_name_Unicode, sPurchaseFontName[ePolarisGothicM][1]))
						)
						continue;
				}

				//[16.01.14][sglee1206] square root sign을 Check Mark처럼 사용하면서 해당 Font가 없는 경우 나눔고딕 등을 사용하면 안됨 CSP-2826
				if( ch == 0x221A &&
					(getDocType() == BORA_DOCTYPE_PPT || getDocType() == BORA_DOCTYPE_PPTX)
					)
				{
					if (!FontWcsCmp(po_face->family_name_Unicode, sPurchaseFontName[ePolaris_Batang][0]) ||
						(sPurchaseFontName[ePolaris_Batang][1] != BrNULL &&
							!FontWcsCmp(po_face->family_name_Unicode, sPurchaseFontName[ePolaris_Batang][1]))
						)
						BrTrace("use square root sign in %d format", getDocType());
					else
						continue;
				}

				if( checkChineseChar(ch) && !bChina && (ft_face->charmap->encoding_id == TT_MS_ID_GB2312) )
				{
					nFindChineseIdx = n;
					continue;
				}

#ifndef USE_PC_VERSION_FONT	//[18.04.27][sglee1206] 일단은 WINDOWS_8 디파인 처리하나 추후에 PC버전에서도 문제 시에는 피쳐 제거. WINDOWS_8->USE_PC_VERSION_FONT
				//비단 나눔고딕 뿐만 아니라 여러폰트에서 문제가 되는데 JIS X 0201(한국은 KS X 1003)에서 시작된 문제
				if(ch == '\\' && !FontStrCmp(ft_face->family_name, "Nanum",5))
					continue;
#endif
				if (bCheckGlyphBitmap)
				{
					if (!checkGlyphBitmap(po_face, ch, nFontWidth, nFontHeight))
						continue;
				}

				//[16.07.01][sglee1206] 최하단의 조건을 처리하기위한 Flag이므로 bFind와 pair를 맞춰서 처리하여야 함
				bFontFind = BrTRUE;
				if(bFind) *bFind = BrTRUE;

				pFace = po_face;
				fontFace = ft_face;
				nFaceIndex = n;
				if(!FontWcsCmp(pFace->family_name_Unicode, DEFAULT_MATH_FONT_NAME,BrWcsLen(DEFAULT_MATH_FONT_NAME)) && !(IS_UCS2_Mathematical_Operators(ch) || IS_UCS4_Mathematical_Alphanumeric_Symbols(ch)))
					continue;

#ifdef USE_TTF_HWP_MATH_HEADER_FONT
				else if( !FontWcsCmp(pFace->family_name_Unicode, HWP_MATH_FONT_NAME) )
					continue;
#endif //USE_TTF_HWP_MATH_HEADER_FONT

				if((PoGetLocale() != BR_LOCALE_KOREAN || !FontWcsCmp(m_pFontName, (const unsigned short*)u"Microsoft YaHei" /*"\xE5\xBE\xAE\xE8\xBD\xAF\xE9\x9B\x85\xE9\xBB\x91"*/ /*Microsoft YaHei*/)) 
					&& checkChineseChar(ch) && IS_HANJA(ch) && !FontStrCmp(fontFace->family_name, "NanumGothic",11))
					continue;

				break;
			}

			if( n == nFontFaceCnt - 1 && nFindChineseIdx != -1)
			{
				pFace = GetFontFaceByIndex(nFindChineseIdx);
				fontFace = pFace->ft_face;
				nFaceIndex = nFindChineseIdx;
			}
		}

		//[16.07.01][sglee1206] 아래 bFind 조건이 잘못된 것이므로 해당 조건을 처리하기위한 Flag(bFontFind)를 만들어서 처리함
		//if( !bFind && checkChineseChar(ch) )
		//[17.04.18][sglee1206] BR_LOCALE_S_CHINESE 일때 잘못 참조하는 문제가 존재하여 bFontFind 제거
		if( checkChineseChar(ch) )
		{
			//[15.08.12][sglee1206] 한자를 찾고 폰트 Index를 변경하게되면 다음 글자도 모두 변경되므로 rollback 가능하게 처리 ZPD-11752
			//findSimplifiedCFont 함수에서 변경되지 않아도 되면 해당코드와 findSimplifiedCFont내에 m_nOldIndex 값 변경하는 구문 제거
			BrINT oldIndexTemp = m_nOldIndex;
			//[15.10.07][sglee1206] 한자를 대체 시 m_bExistFont를 무조건 True로 하면서 문제가 발생. 상기 수정 내용 Side. 
			FT_Bool bExistFontTemp = m_bExistFont;
			BrBOOL bFindSFont = findSimplifiedCFont(ch, nFontWidth, nFontHeight, nBSIndex, &pFace, pFaceIndex, bCheckGlyphBitmap);
			m_nOldIndex = oldIndexTemp;
			m_bExistFont = bExistFontTemp;

			bFontFind = bFindSFont;
			if(bFind) *bFind = bFindSFont;
			if( bFindSFont )
				return getFontFaceResult(pFace, ch, fontStyle, nFontWidth, nFontHeight, nFaceIndex, pFaceIndex);
		}
	}
	//if(bFind == BrFALSE)
	//	nFaceIndex = m_nOldIndex;

	return getFontFaceResult(pFace, ch, fontStyle, nFontWidth, nFontHeight, nFaceIndex, pFaceIndex, bForceFind);
}

PO_Face BoraFont::getFontFaceEx(BrINT fontIndex, BrBYTE fontStyle, FT_Int nFontWidth, FT_Int nFontHeight, BrINT* pFaceIndex, BrBOOL *bFind, FT_ULong ch, BrBOOL bForceLoad)
{
	PO_Face fontFace = GetFontFaceByIndex(fontIndex);
	if(fontFace != BrNULL && (bForceLoad || FT_Get_Char_Index(fontFace->ft_face, ch)) )
	{
		if(bFind) *bFind = BrTRUE;
		
		return getFontFaceResult(fontFace, ch, fontStyle, nFontWidth, nFontHeight, fontIndex, pFaceIndex);
	}
	return BrNULL;
}

PO_Face BoraFont::getFontFaceResult(PO_Face fontFace, FT_ULong ch, BrBYTE fontStyle, FT_Int nFontWidth, FT_Int nFontHeight, BrINT fontIndex, BrINT* pFaceIndex, BrBOOL bForceFind)
{	
	m_CheckFontStyle = fontStyle;
	if(pFaceIndex && !bForceFind) 
	{
		*pFaceIndex = fontIndex;
		setCacheFontFace(ch, m_nCurFontNameIndex, fontFace, fontIndex, fontStyle);
	}
	FT_Face ft_face = fontFace->ft_face;

	setFontFaceSize(ft_face,ch, nFontWidth, nFontHeight);
	
	//[dwchun : 2012.04.03] : 현재 설정된 폰트와 실제 그릴 폰트의 Descent를 빼줌
	if(IsColorEmojiFont(ft_face))
		m_nFontFaceGap = 0;
	else if(ft_face->family_name && ft_face->family_name[0] == 0x41 && !FontStrCmp(ft_face->family_name, "Apple Color Emoji"))
		m_nFontFaceGap = 0;
	else
		//기존 코드
		//[16.08.05][sglee1206] DEX-377이슈를 위해 변경하였으나 Rendering오류로 rev.9389 수정사항 rollback
#if FONT_HEIGHT_TEST_CODE_ENABLE
		m_nFontFaceGap = -(getFontInternalLeading(fontFace, nFontHeight));// + getFontExternalLeading(fontFace, nFontHeight));	
#else
		m_nFontFaceGap = GetCharDescent() - ((32 - ft_face->size->metrics.descender) >> 6);
#endif
	
	return fontFace;
}

BrFontStyleIdxNode* BoraFont::getFontListNode(BrINT nRuntimeFontIndex, BrBYTE fontStyle)
{
	LPBrTypefaceStruct pSameFamilyList = m_aTypeFaceList.at(nRuntimeFontIndex);
	BrINT nCountSameFamily = pSameFamilyList->nCountSameFamily;
	BrINT fIdx = 0;
	LPBrFontStyleIdxNode pNode = BrNULL;
	if(nCountSameFamily == 1)
	{
		for (fIdx = 0; fIdx<eFontStyleIndexMax ; fIdx++)
		{
			if(pSameFamilyList->nStyleCnt[fIdx] > 0)
			{
				pNode = pSameFamilyList->nFontIndices[fIdx];
				break; 
			}
		}
	}
	else if(nCountSameFamily > 1)
	{
		fIdx = fontStyle;

		if(pSameFamilyList->nStyleCnt[fIdx] > 0)
			pNode = pSameFamilyList->nFontIndices[fIdx];
		//[16.03.01][sglee1206] nRunTimeFont 값 잘못처리되는 버그 수정
		else if(fIdx == eStyleBoldItalic)
		{
			if(pSameFamilyList->nStyleCnt[eStyleBold] > 0)
				pNode = pSameFamilyList->nFontIndices[eStyleBold];
			else if(pSameFamilyList->nStyleCnt[eStyleItalic] > 0)
				pNode = pSameFamilyList->nFontIndices[eStyleItalic];
			else if(pSameFamilyList->nStyleCnt[eStyleRegular] > 0)
				pNode = pSameFamilyList->nFontIndices[eStyleRegular];
		}
		else if(fIdx == eStyleBold)
		{
			if(pSameFamilyList->nStyleCnt[eStyleRegular] > 0)
				pNode = pSameFamilyList->nFontIndices[eStyleRegular];
			else if(pSameFamilyList->nStyleCnt[eStyleBoldItalic] > 0)
				pNode = pSameFamilyList->nFontIndices[eStyleBoldItalic];
			else if(pSameFamilyList->nStyleCnt[eStyleExtra1] > 0)
				pNode = pSameFamilyList->nFontIndices[eStyleExtra1];
		}
		else if(fIdx == eStyleItalic)
		{
			if(pSameFamilyList->nStyleCnt[eStyleRegular] > 0)
				pNode = pSameFamilyList->nFontIndices[eStyleRegular];
			else if(pSameFamilyList->nStyleCnt[eStyleBoldItalic] > 0)
				pNode = pSameFamilyList->nFontIndices[eStyleBoldItalic];
			else if(pSameFamilyList->nStyleCnt[eStyleExtra1] > 0)
				pNode = pSameFamilyList->nFontIndices[eStyleExtra1];
		}
		else
		{
			if(pSameFamilyList->nStyleCnt[eStyleRegular] > 0)
				pNode = pSameFamilyList->nFontIndices[eStyleRegular];
			else if(pSameFamilyList->nStyleCnt[eStyleExtra1] > 0)
				pNode = pSameFamilyList->nFontIndices[eStyleExtra1];
			else if(pSameFamilyList->nStyleCnt[eStyleBold] > 0)
				pNode = pSameFamilyList->nFontIndices[eStyleBold];
			else if(pSameFamilyList->nStyleCnt[eStyleItalic] > 0)
				pNode = pSameFamilyList->nFontIndices[eStyleItalic];
			else if(pSameFamilyList->nStyleCnt[eStyleBoldItalic] > 0)
				pNode = pSameFamilyList->nFontIndices[eStyleBoldItalic];
		}
	}
	
	return pNode;
}

/*
	m_RuntimeLoadFont.at(nIndex)->nFontFileIdx
*/
BrINT BoraFont::getLoadFontStFileIndex(BrINT nIndex)
{
	BrINT nRet = -1;

	if (nIndex < 0 || m_RuntimeLoadFont.size() <= 0)
		return nRet;

	if (nIndex < m_RuntimeLoadFont.size())
	{
		nRet = m_RuntimeLoadFont.at(nIndex)->nFontFileIdx;
	}

	return nRet;
}

LPBrLoadFontFileList BoraFont::getLoadFontFileList(BrINT nIndex)
{
	LPBrLoadFontFileList pFontFile = BrNULL;

	if (nIndex < 0 || m_aLoadFontFilePath.size() <= 0)
		return BrNULL;

	if (nIndex < m_aLoadFontFilePath.size())
	{
		pFontFile = m_aLoadFontFilePath.at(nIndex);
	}

	return pFontFile;
}

void BoraFont::releaseFontFileList()
{
	int nSize = m_aLoadFontFilePath.size();
	LPBrLoadFontFileList pFontFile = BrNULL;

	for (int i = 0; i < nSize; i++)
	{
		pFontFile = m_aLoadFontFilePath.at(i);
		if (pFontFile)
		{
#if !defined( SUPPORT_ADD_FONT_TABLE )
			BR_SAFE_DELETE(pFontFile->fontStIndices);
#endif
			PoSysFree(pFontFile);
		}
	}
	m_aLoadFontFilePath.removeAll();
}

/*
*	@author 	minseob
*	@date  		2019.03.07
*	@params		FT_ULong ch : char_code
*	@params		BrINT* pFaceIndex : FontFace Index
*	@params		BrBOOL *bFind : bFind
*	@brief  	설정된 폰트에 해당 언어의 글자 글립이 없을 경우 윈도우 기본 폰트로 매칭
*/
PO_Face BoraFont::getFontFaceForLocalLang(FT_ULong ch, BrBYTE fontStyle, FT_Int nFontWidth, FT_Int nFontHeight, BrINT* pFaceIndex, BrBOOL *bFind)
{
#ifdef USE_COMMON_INTERFACE
	PO_Face tmpFace = NULL;

	BrINT nIdx = -1;
	const unsigned short* pAlterName[3] = {NULL, };
	const unsigned short* pFindAlterName = NULL;
	char* nTestTag = "";

	//International fonts
	//https://docs.microsoft.com/ko-kr/windows/uwp/design/globalizing/loc-international-fonts
	//https://en.wikipedia.org/wiki/List_of_typefaces_included_with_Microsoft_Windows
	if( IS_UCS2_Thai(ch))
	{
		nTestTag = "Thai";
		/*
		pAlterName[0] = (const unsigned short* )u"Browallia New";
		pAlterName[1] = (const unsigned short* )u"Leelawadee";
		pAlterName[2] = (const unsigned short* )u"Arial Unicode MS";
		*/
		pAlterName[0] = (const unsigned short*)u"Leelawadee UI";
		pAlterName[1] = (const unsigned short*)u"Browallia New";
		pAlterName[2] = (const unsigned short*)u"Arial Unicode MS";
	}
	else if ( IS_UCS2_Khmer(ch) )
	{
		nTestTag = "Khmr";
		pAlterName[0] = (const unsigned short*)u"DaunPenh";
		pAlterName[1] = (const unsigned short*)u"Leelawadee UI";
	}
	else if ( IS_UCS2_Arabic(ch) )
	{
		nTestTag = "Arab";
		pAlterName[0] = (const unsigned short*)u"Arabic Typesetting";
		pAlterName[1] = (const unsigned short*)u"Segoe UI";
	}
	else
		return NULL;

	for (int i = 0; i < m_aLocaleDefaultFontName.size(); i++)
	{
		if (!FontStrCmp(nTestTag, m_aLocaleDefaultFontName.at(i)->scriptTag))
		{
			for (int k = 0; k < m_aLocaleDefaultFontName.at(i)->fontNameCnt; k++)
				pAlterName[k] = m_aLocaleDefaultFontName.at(i)->defaultFontName[k];
			break;
		}
	}

	BrINT nRet = -1;
	BrINT nNameIdx = 0;
	while(nRet < 0 && nNameIdx < 3)
	{
		if (pAlterName[nNameIdx])
		{
			nRet = getFontNameListIndex(pAlterName[nNameIdx]);
		}
		nNameIdx++;
	}

	if(nNameIdx > 0 && nNameIdx < 3)
		pFindAlterName = pAlterName[nNameIdx -1];
	
	BrINT nRuntimeFontIndex;
	BrINT* pFaceIndexHash = BrNULL;
	LPBrFontStyleIdxNode pNode = BrNULL;
	
	if(nRet > -1) 
	{
		nRuntimeFontIndex = m_pFontNameList->GetFontListIndex(nRet);
		pNode = getFontListNode(nRuntimeFontIndex, fontStyle);

		BrINT nRunTimeFont = -1;
		BrBOOL bRet = BrFALSE;
		BrBOOL bTryLoad = BrFALSE;
		while(pNode != BrNULL && bRet == BrFALSE)
		{
			BrINT nFontFaceCnt = GetFontFaceCnt();
			nRunTimeFont = pNode->nFontIndex;
			for (BrINT i = 0; i<nFontFaceCnt ; i++)
			{
				if(nRunTimeFont == GetFontFaceByIndex(i)->nFontListIndex)
				{
					nIdx = i;
					break; 
				}
			}

			if(!bTryLoad && nIdx < 0)
			{
				if(loadSystemFontFile(nRuntimeFontIndex,(BrWORD*)pFindAlterName) >= 0)
				{
					bTryLoad = BrTRUE;
					continue;
				}
			}

			bRet = hasFontGlyph(GetFontFaceByIndex(nIdx), ch);
			pNode = pNode->pNext;
		}

		if(bRet) {
			tmpFace = getFontFaceEx(nIdx, fontStyle, nFontWidth, nFontHeight, pFaceIndex, bFind, ch);
		}
	}	
#if !defined( USE_PC_VERSION_FONT ) && defined( USE_ALTERNATE_FONT )
	else
	{
		for(int n = 0; n < m_face_count; n++)
		{
			BrWORD* fontName = GetFamilyNameByIndex(n);
			if(!FontWcsCmp(fontName, pAlterName[0]) ||
				(pAlterName[1] != BrNULL && !FontWcsCmp(fontName, pAlterName[1])) ||
				(pAlterName[2] != BrNULL && !FontWcsCmp(fontName, pAlterName[2]))
				)
			{
				tmpFace = getFontFaceEx(n, fontStyle, nFontWidth, nFontHeight, pFaceIndex, bFind, ch);
				if(tmpFace != BrNULL) {
					break;
				}
			}
		}
	}
#endif

	return tmpFace;
#endif//ifdef USE_COMMON_INTERFACE
	return 0;
}

PO_Face	BoraFont::getFontFaceForHWP(FT_ULong ch, BrBOOL bHancomWingdingSymbols, BrBYTE fontStyle, FT_Int nFontWidth, FT_Int nFontHeight, BrINT* pFaceIndex, BrBOOL *bFind, BrBOOL bForceFind, BrBOOL *bAlternateHancomFont)
{
#ifdef USE_COMMON_INTERFACE
	PO_Face tmpFace = NULL;
	BrINT nIdx = -1;
	const unsigned short* pAlterName[3] = {NULL, };
	const unsigned short* pFindAlterName = NULL;

	BrBOOL bNonSkip = BrFALSE;

	//[15.10.22][sglee1206] 한컴의 경우 글머리기호가 Wingdings로 넘어오지 않고 Code값만 전달함
	//해당 경우에는 Wingdings을 사용하여 처리되고 있음. ZPD-19069
	//ODT의 경우도 해당 영역이 없는 경우 Wingdings로 처리하도록 협의함 IAC-1739
	//관련 confluence : http://confluence.infraware.net:8090/pages/viewpage.action?pageId=14104919 2번항목
	if(bHancomWingdingSymbols)
	{
		pAlterName[0] = (const unsigned short*)u"HYWingding";
		pAlterName[1] = (const unsigned short*)u"Wingdings";
	}
	else if(CUtil::WcsStr(m_pFontName, (const unsigned short*)u"\xBA85\xC870"/*"\xEB\xAA\x85\xEC\xA1\xB0"*/ /*명조*/))
	{
#ifndef KVIEWER_MODIFIED
		if(BoraFontComm::IsHFTExcept(ch) == BrTRUE)
		{
			//[18.01.18][sglee1206] 기존에 배포된 ODT 버전에서 문제가 있던 부분을 수정한 것이나 기존에 배포된 버전으로 작성된 문서 레이아웃이 변경됨
			//따라서 정상동작이 아닌 버전으로 처리해 달라고 하여 해당 부분을 적용
			//관련 이슈: [HEJ-1691]
			if(!BIsODTEditorApp())
			{
				pAlterName[0] = (const unsigned short*)u"Times New Roman";
			}
			else
			{
				pAlterName[0] = (const unsigned short*)u"NanumGothic";
			}
		}
		else 
#endif //KVIEWER_MODIFIED
			if(CUtil::WcsStr(m_pFontName, (const unsigned short*)u"\xD734\xBA3C\xBA85\xC870"/*"\xED\x9C\xB4\xEB\xA8\xBC\xEB\xAA\x85\xEC\xA1\xB0"*/ /* 휴먼명조 */))
			{
#ifdef SUPPORT_ADD_FONT
				*bAlternateHancomFont = !m_bLoadedPurchaseFont[ePolarisHumanMyeongjo];
#endif
				bNonSkip = BrTRUE;
				pAlterName[0] = sPurchaseFontName[ePolarisHumanMyeongjo][0];
				pAlterName[1] = sPurchaseFontName[ePolarisHumanMyeongjo][1];
			}
#ifdef KVIEWER_MODIFIED
			else if(!FontStrCmp(m_pFontName, (const unsigned short*)u"\xD55C\xC591\xC2E0\xBA85\xC870") || !FontStrCmp(m_pFontName, (const unsigned short*)u"\xBA85\xC870"))	//한양신명조
			{
				*bAlternateHancomFont = BrFALSE;
				if(ch == 0x33DE || ch == 0x33DF)
				{
					pAlterName[0] = (const unsigned short*)u"HCR Batang";
					pAlterName[1] = (const unsigned short*)u"\xD568\xCD08\xB86C\xBC14\xD0D5";
				}
				else
				{
					pAlterName[0] = (const unsigned short*)u"Haansoft Batang";
					pAlterName[1] = (const unsigned short*)u"\xD55C\xCEF4\xBC14\xD0D5";
				}
			}
#endif //KVIEWER_MODIFIED					
			else if(CUtil::WcsStr(m_pFontName, (const unsigned short*)u"\xC2E0\xBA85\xC870"/*"신명조"*/))
			{
				//[16.03.08][sglee1206] 대체 시 예외 조건을 한번만 처리하기위해 boolean 사용
				//[16.08.20][sglee1206] [XPD-1219]신명조 계열 옛한글은 폴라리스 바탕을 사용하기 위해 조건 추가
				bool bUseFontByChar = (ch != 0xFF5E && ch != 0x221A && ch != 0x25CB && ch != 0x25E6 && ch != 0xAD && !IS_HANGUL_JAMO(ch));
				bool bUseFontByName = m_pFontName[0] != 0x23 /* #신명조 #태신명조 */ && FontWcsCmp(m_pFontName, (const unsigned short*)u"\xD55C\xC591"/*"\xED\x95\x9C\xEC\x96\x91"*/ /*한양*/,2);
				//[15.08.12][sglee1206] 0x221A(√)의 경우 HY신명조와 한양신명조,#신명조, #태신명조의 모양이 다르므로 조건처리 CSP-2085
				//[16.02.25][sglee1206] ○의 경우 신명조 계열 HFT에서는 휴먼명조등 일반적인 명조에서보다 Size가 작음 [ZPD-25256]
				//[16.03.08][sglee1206] 0xAD(soft hyphen:SHY) 의 경우 HY신명조의 Glyph이 문제가 있으므로 다른 폰트로 대체[ZPD-26704][ZPD-25433]
				if(bUseFontByChar)
				{
					pAlterName[0] = (const unsigned short*)u"HYSinMyeongJo-Medium";
					pAlterName[1] = (const unsigned short*)u"HYSinMyeongJo M";
				}
				else if(!bUseFontByChar && bUseFontByName)	// (ch == 0x221A || ch == 0x25CB || ch == 0xAD) && m_pFontName[0] != 0x23 /* #신명조 #태신명조 */ && FontStrCmp(m_pFontName, "\xED\x95\x9C\xEC\x96\x91" /*한양*/,6)
				{
					pAlterName[0] = (const unsigned short*)u"HYSinMyeongJo-Medium";
					pAlterName[1] = (const unsigned short*)u"HYSinMyeongJo M";
				}
			}
			else if(CUtil::WcsStr(m_pFontName, (const unsigned short*)u"\xACAC\xBA85\xC870"/*"\xEA\xB2\xAC\xEB\xAA\x85\xEC\xA1\xB0"*/ /*견명조*/))
			{
				pAlterName[0] = (const unsigned short*)u"HYmjrE";
				pAlterName[1] = (const unsigned short*)u"HYMyeongJo-Extra";
				pAlterName[2] = (const unsigned short*)u"HYMyeongJo E";
			}
			else 
			{
				pAlterName[0] = (const unsigned short*)u"HYSinMyeongJo-Medium";
				pAlterName[1] = (const unsigned short*)u"HYSinMyeongJo M";
			}
	}
	else if(CUtil::WcsStr(m_pFontName, (const unsigned short*)u"\xD5E4\xB4DC\xB77C\xC778"/*"\xED\x97\xA4\xEB\x93\x9C\xEB\x9D\xBC\xEC\x9D\xB8"*/ /*헤드라인*/))
	{
		pAlterName[0] = (const unsigned short*)u"HYHeadLine-Medium";
		pAlterName[1] = (const unsigned short*)u"HYHeadLine M";
	}
	else if(CUtil::WcsStr(m_pFontName, (const unsigned short*)u"\xBC14\xD0D5"/*"\xEB\xB0\x94\xED\x83\x95"*/ /*바탕*/))
	{
		if(CUtil::WcsStr(m_pFontName, (const unsigned short*)u"\xD568\xCD08\xB86C\xBC14\xD0D5"/*"\xED\x95\xA8\xEC\xB4\x88\xEB\xA1\xAC\xEB\xB0\x94\xED\x83\x95"*/ /* 함초롬바탕 */))
		{
			if(HAS_FONT_FLAG(fontStyle, FT_STYLE_FLAG_BOLD))
			{
#ifdef SUPPORT_ADD_FONT
				*bAlternateHancomFont = !m_bLoadedPurchaseFont[ePolarisNewBatang_B];
#endif
				pAlterName[0] = sPurchaseFontName[ePolarisNewBatang_B][0];
				pAlterName[1] = sPurchaseFontName[ePolarisNewBatang_B][1];
			}
			else
			{
#ifdef SUPPORT_ADD_FONT
				*bAlternateHancomFont = !m_bLoadedPurchaseFont[ePolarisNewBatang];
#endif
				pAlterName[0] = sPurchaseFontName[ePolarisNewBatang][0];
				pAlterName[1] = sPurchaseFontName[ePolarisNewBatang][1];
			}
		}
		else if(CUtil::WcsStr(m_pFontName, (const unsigned short*)u"\xD3F4\xB77C\xB9AC\xC2A4\xC0C8\xBC14\xD0D5"/*"\xED\x8F\xB4\xEB\x9D\xBC\xEB\xA6\xAC\xEC\x8A\xA4\xEC\x83\x88\xEB\xB0\x94\xED\x83\x95"*/ /*"폴라리스새바탕"*/))
		{
			if(HAS_FONT_FLAG(fontStyle,FT_STYLE_FLAG_BOLD))
			{
#ifdef SUPPORT_ADD_FONT
				*bAlternateHancomFont = !m_bLoadedPurchaseFont[ePolarisNewBatang_B];
#endif
				pAlterName[0] = sPurchaseFontName[ePolarisNewBatang_B][0];
				pAlterName[1] = sPurchaseFontName[ePolarisNewBatang_B][1];
			}
			else
			{
#ifdef SUPPORT_ADD_FONT
				*bAlternateHancomFont = !m_bLoadedPurchaseFont[ePolarisNewBatang];
#endif
				pAlterName[0] = sPurchaseFontName[ePolarisNewBatang][0];
				pAlterName[1] = sPurchaseFontName[ePolarisNewBatang][1];
			}
		}
		//else if(!FontStrCmp(GetFamilyNameByIndex(nIdx), "\xD3F4\xB77C\xB9AC\xC2A4\xBC14\xD0D5" //"폴라리스바탕"))
		else
		{
			pAlterName[0] =  sPurchaseFontName[ePolaris_Batang][0];
			pAlterName[1] = sPurchaseFontName[ePolaris_Batang][1];
		}
	}
	else if(CUtil::WcsStr(m_pFontName, (const unsigned short*)u"\xB3CB\xC6C0")  || CUtil::WcsStr(m_pFontName, (const unsigned short*)u"Dotum") || CUtil::WcsStr(m_pFontName, (const unsigned short*)u"dotum"))
	{
		if(CUtil::WcsStr(m_pFontName, (const unsigned short*)u"\xD568\xCD08\xB86C\xB3CB\xC6C0"/*"\xED\x95\xA8\xEC\xB4\x88\xEB\xA1\xAC\xEB\x8F\x8B\xEC\x9B\x80"*/ /* 함초롬돋움 */))
		{
			if(HAS_FONT_FLAG(fontStyle,FT_STYLE_FLAG_BOLD))
			{
#ifdef SUPPORT_ADD_FONT
				*bAlternateHancomFont = !m_bLoadedPurchaseFont[ePolarisNewDotum_B];
#endif
				pAlterName[0] = sPurchaseFontName[ePolarisNewDotum_B][0];
				pAlterName[1] = sPurchaseFontName[ePolarisNewDotum_B][1];
			}
			else
			{
#ifdef SUPPORT_ADD_FONT
				*bAlternateHancomFont = !m_bLoadedPurchaseFont[ePolarisNewDotum];
#endif
				pAlterName[0] = sPurchaseFontName[ePolarisNewDotum][0];
				pAlterName[1] = sPurchaseFontName[ePolarisNewDotum][1];
			}
		}
		else if(CUtil::WcsStr(m_pFontName, (const unsigned short*)u"\xD3F4\xB77C\xB9AC\xC2A4\xC0C8\xB3CB\xC6C0"/*"\xED\x8F\xB4\xEB\x9D\xBC\xEB\xA6\xAC\xEC\x8A\xA4\xEC\x83\x88\xEB\x8F\x8B\xEC\x9B\x80"*/ /* 폴라리스새돋움 */))
		{
			if(HAS_FONT_FLAG(fontStyle,FT_STYLE_FLAG_BOLD))
			{
#ifdef SUPPORT_ADD_FONT
				*bAlternateHancomFont = !m_bLoadedPurchaseFont[ePolarisNewDotum_B];
#endif
				pAlterName[0] = sPurchaseFontName[ePolarisNewDotum_B][0];
				pAlterName[1] = sPurchaseFontName[ePolarisNewDotum_B][1];
			}
			else
			{
#ifdef SUPPORT_ADD_FONT
				*bAlternateHancomFont = !m_bLoadedPurchaseFont[ePolarisNewDotum];
#endif
				pAlterName[0] = sPurchaseFontName[ePolarisNewDotum][0];
				pAlterName[1] = sPurchaseFontName[ePolarisNewDotum][1];
			}
		}
		else
		{
			pAlterName[0] = (const unsigned short*)u"HYDotum";
		}
	}
	//[17.01.24][sglee1206] 온나라 Html파일에서 한글 굴림이 아닌 Gulim으로 처리되어 매칭되지 않아 추가함 [IAC-2508]
	else if(CUtil::WcsStr(m_pFontName, (const unsigned short*)u"\xAD74\xB9BC") || CUtil::WcsStr(m_pFontName, (const unsigned short*)u"Gulim") || CUtil::WcsStr(m_pFontName, (const unsigned short*)u"gulim"))
	{
		pAlterName[0] = (const unsigned short*)u"HYGulim";
	}
	else if(CUtil::WcsStr(m_pFontName, (const unsigned short*)u"\xAD81\xC11C"/*"\xEA\xB6\x81\xEC\x84\x9C"*/ /*궁서*/))
	{
		pAlterName[0] = (const unsigned short*)u"HYGungSo";
		pAlterName[1] = (const unsigned short*)u"HYgsrB";
		pAlterName[2] = (const unsigned short*)u"HYGungsuh";
	}
	else if(CUtil::WcsStr(m_pFontName, (const unsigned short*)u"\xACE0\xB515") || CUtil::WcsStr(m_pFontName, (const unsigned short*)u"Gothic") || CUtil::WcsStr(m_pFontName, (const unsigned short*)u"gothic"))
	{
		if(CUtil::WcsStr(m_pFontName, (const unsigned short*)u"\xD734\xBA3C\xACE0\xB515"/*"\xED\x9C\xB4\xEB\xA8\xBC\xEA\xB3\xA0\xEB\x94\x95"*/ /* 휴먼고딕 */))
		{
#ifdef SUPPORT_ADD_FONT
			*bAlternateHancomFont = !m_bLoadedPurchaseFont[ePolarisHumanGothic];
#endif
			bNonSkip = BrTRUE;
			pAlterName[0] = sPurchaseFontName[ePolarisHumanGothic][0];
			pAlterName[1] = sPurchaseFontName[ePolarisHumanGothic][1];
		}
#ifdef KVIEWER_MODIFIED
		else if(!FontStrCmp(m_pFontName, (const unsigned short*)u"\xACE0\xB515"/*고딕*/))
		{
			*bAlternateHancomFont = BrFALSE;
			if(ch == 0x33DE || ch == 0x33DF)
			{
				pAlterName[0] = (const unsigned short*)u"HCR Dotum";
				pAlterName[1] = (const unsigned short*)u"\xD568\xCD08\xB86C\xB3CB\xC6C0";
			}
			else
			{
				pAlterName[0] = (const unsigned short*)u"Haansoft Dotum";
				pAlterName[1] = (const unsigned short*)u"\xD55C\xCEF4\xB3CB\xC6C0";
			}
		}
#endif //KVIEWER_MODIFIED
		else if(CUtil::WcsStr(m_pFontName, (const unsigned short*)u"\xD55C\xC591\xC911\xACE0\xB515"/*"한양중고딕"*/))
		{
#ifdef SUPPORT_ADD_FONT
			*bAlternateHancomFont = !m_bLoadedPurchaseFont[ePolarisGothicM];
#endif
			if(	ch == 0xFF5E
#ifdef SUPPORT_ADD_FONT
				&& !m_bLoadedPurchaseFont[ePolarisGothicM]
#endif	
			)
			{
#ifdef SUPPORT_ADD_FONT
				*bAlternateHancomFont = !m_bLoadedPurchaseFont[ePolaris_Batang];
#endif
				pAlterName[0] = sPurchaseFontName[ePolaris_Batang][0];
				pAlterName[1] = sPurchaseFontName[ePolaris_Batang][1];
			}
			else
			{
				pAlterName[0] = sPurchaseFontName[ePolarisGothicM][0];
				pAlterName[1] = sPurchaseFontName[ePolarisGothicM][1];
			}
		}
		else
		{
			pAlterName[0] = (const unsigned short*)u"Malgun Gothic";
			if (IS_UCS2_General_Punctuation(ch))
			{
				pAlterName[0] = sPurchaseFontName[ePolaris_Batang][0];
				pAlterName[1] = sPurchaseFontName[ePolaris_Batang][1];
			}
			else
			{
				pAlterName[1] = sPurchaseFontName[ePolarisHumanGothic][0];
				pAlterName[2] = sPurchaseFontName[ePolarisHumanGothic][1];
			}
		}
	}
	else
	{
		if(getDocType() == BORA_DOCTYPE_HWP)
		{
			if(m_nFontFlag == eMalkeunGodikFont || m_nFontFlag == eHCIHollyhockFont)
			{
				pAlterName[0] = (const unsigned short*)u"Malgun Gothic";
			}
			else if(m_nFontFlag == eHCIPoppyFont || m_nFontFlag == eHCITulipFont)
			{
				pAlterName[0] = (const unsigned short*)u"Times New Roman";
			}
			else if(m_nFontFlag == eHanComSomangMFont || m_nFontFlag == eHanComSomangBFont)
			{
				pAlterName[0] = (const unsigned short*)u"NanumMyeongjo";
			}
			else
			{
				pAlterName[0] = sPurchaseFontName[ePolaris_Batang][0];
				pAlterName[1] = sPurchaseFontName[ePolaris_Batang][1];
			}
		}
		else if(!bForceFind)
		{
			pAlterName[0] = (const unsigned short*)u"Malgun Gothic";
			pAlterName[1] = sPurchaseFontName[ePolarisHumanGothic][0];
			pAlterName[2] = sPurchaseFontName[ePolarisHumanGothic][1];
		}
	}

	BrINT nRet = -1;
	BrINT nNameIdx = 0;
	while(nRet < 0 && nNameIdx < 3)
	{
		nRet = getFontNameListIndex(pAlterName[nNameIdx]);
		nNameIdx++;
	}

	if(nNameIdx > 0 && nNameIdx < 3)
		pFindAlterName = pAlterName[nNameIdx -1];

	BrINT nRuntimeFontIndex;
	BrINT* pFaceIndexHash = BrNULL;
	LPBrFontStyleIdxNode pNode = BrNULL;
	//BrBOOL bHancomWingdingSymbols, BrINT* pFaceIndex, BrBOOL *bFind, BrBOOL bForceFind, BrBOOL *bAlternateHancomFont)
	if(nRet > -1) 
	{
		nRuntimeFontIndex = m_pFontNameList->GetFontListIndex(nRet);
		pNode = getFontListNode(nRuntimeFontIndex, fontStyle);

		BrINT nRunTimeFont = -1;
		BrBOOL bRet = BrFALSE;
		BrBOOL bTryLoad = BrFALSE;
		while(pNode != BrNULL && bRet == BrFALSE)
		{
			BrINT nFontFaceCnt = GetFontFaceCnt();
			nRunTimeFont = pNode->nFontIndex;
			for (BrINT i = 0; i<nFontFaceCnt ; i++)
			{
				if(nRunTimeFont == GetFontFaceByIndex(i)->nFontListIndex)
				{
					nIdx = i;
					break; 
				}
			}

			if(!bTryLoad && nIdx < 0)
			{
				if(loadSystemFontFile(nRuntimeFontIndex, (BrWORD*)pFindAlterName) >= 0)
				{
					bTryLoad = BrTRUE;
					continue;
				}
			}

			bRet = hasFontGlyph(GetFontFaceByIndex(nIdx), ch);
			pNode = pNode->pNext;
		}

		if(bRet) {
			tmpFace = getFontFaceEx(nIdx, fontStyle, nFontWidth, nFontHeight, pFaceIndex, bFind, ch);
		}
		
		if (tmpFace == BrNULL && nIdx >= 0 && !isPrintableUnicode(ch))
		{
			tmpFace = getFontFaceEx(nIdx, fontStyle, nFontWidth, nFontHeight, pFaceIndex, bFind, ch, BrTRUE);
		}
	}
#if !defined( USE_PC_VERSION_FONT ) && defined( USE_ALTERNATE_FONT )
	else
	{
		for(int n = 0; n < m_face_count; n++)
		{
			BrWORD* fontName = GetFamilyNameByIndex(n);
			if(!FontWcsCmp(fontName, pAlterName[0]) ||
				(pAlterName[1] != BrNULL && !FontWcsCmp(fontName, pAlterName[1])) ||
				(pAlterName[2] != BrNULL && !FontWcsCmp(fontName, pAlterName[2]))
				)
			{
				if (BoraFontComm::IsSkipPurchaseFontChar(ch, fontName))
				{
					if(!bNonSkip)
						continue;
					else
						tmpFace = getFontFaceEx(n, fontStyle, nFontWidth, nFontHeight, pFaceIndex, bFind, ch);
				}
				else
					tmpFace = getFontFaceEx(n, fontStyle, nFontWidth, nFontHeight, pFaceIndex, bFind, ch);
				if(tmpFace != BrNULL) {
					break;
				}
			}
		}
	}
#endif
	return tmpFace;
#endif//ifdef USE_COMMON_INTERFACE
	return 0;
}

PO_Face	BoraFont::getFontFaceForKorean(FT_ULong ch, BrBOOL bHancomWingdingSymbols, BrBYTE fontStyle, FT_Int nFontWidth, FT_Int nFontHeight, BrINT* pFaceIndex, BrBOOL* bFind, BrBOOL bForceFind, BrBOOL bAlternateHancomFont)
{
#ifdef USE_COMMON_INTERFACE
	if (getDocType() == BORA_DOCTYPE_HWP || getDocType() == BORA_DOCTYPE_ODT || IS_MODERN_KOREAN(ch))
	{	
		BrINT nDefaultFontIndex = -1;	//폴라리스 바탕 Index
		PO_Face tmpFace = NULL;
		BrINT n = 0;
		BrINT nFontFaceCnt = GetFontFaceCnt();
		BrINT nBSIndex;
		if (m_nEFIndex != -1)
			nBSIndex = m_nEFIndex;
		else
			nBSIndex = m_nBaseIndex;

		if (nBSIndex < 0)
			nBSIndex = 0;

		BrBOOL bDotum = CUtil::WcsStr(m_pFontName, (const unsigned short*)u"\xB3CB\xC6C0"/*"\xEB\x8F\x8B\xEC\x9B\x80" *//*돋움*/) != BrNULL;
		BrBOOL bGothic = CUtil::WcsStr(m_pFontName, (const unsigned short*)u"\xACE0\xB515"/*"\xEA\xB3\xA0\xEB\x94\x95"*/ /*고딕*/) != NULL;
		BrBOOL bMing = CUtil::WcsStr(m_pFontName, (const unsigned short*)u"\xBA85\xC870"/*"\xEB\xAA\x85\xEC\xA1\xB0"*/ /*명조*/) != NULL;
		BrBOOL bShinMing = CUtil::WcsStr(m_pFontName, (const unsigned short*)u"\xC2E0\xBA85\xC870"/*"\xEC\x8B\xA0\xEB\xAA\x85\xEC\xA1\xB0"*/ /*신명조*/) != NULL;

		for (n = nBSIndex; n < nFontFaceCnt; n++)
		{
			//[17.04.07][sglee1206][IAC-2654] 0x274d와 같이 일반적인 폰트에 없는 글자의 경우 대체폰트를 사용
			// 그런데 온나라 odt에서 나눔바른고딕으로 대체되는데 해당 모양이 잘못처리된 글자이므로 이슈 발생
			// HWP처럼 아래 루틴을 탈 수 있도록 수정함
			//[18.01.18][sglee1206] ODT 편집기에 한해 이전코드로 동작하도록 수정[HEJ-1691][HEJ-1697][HEJ-1698][HEJ-1699]
			if (/*getDocType() == BORA_DOCTYPE_HWP && */!BIsODTEditorApp() && bAlternateHancomFont && !bHancomWingdingSymbols)
			{
				//[15.07.17][sglee1206] HWP에서 고딕계열은 폴라리스휴먼고딕으로 대체하도록 변경. ZPD-14538
				if (bGothic)
				{
					if (!FontWcsCmp(GetFamilyNameByIndex(n), sPurchaseFontName[ePolarisHumanGothic][0]) ||
						(sPurchaseFontName[ePolarisHumanGothic][1] != BrNULL &&
							!FontWcsCmp(GetFamilyNameByIndex(n), sPurchaseFontName[ePolarisHumanGothic][1]))
						)
					{
						tmpFace = getFontFaceEx(n, fontStyle, nFontWidth, nFontHeight, pFaceIndex, bFind, ch);
						if (tmpFace != BrNULL) {
							return tmpFace;
						}
					}
				}
				//[16.02.25][sglee1206] HWP에서 명조계열은 폴라리스휴먼명조으로 대체하도록 변경(신명조 계열 제외)
				else if (bMing)
				{
					if (bShinMing)
					{
						//[16.02.25][sglee1206] ○의 경우 신명조 계열 HFT에서는 휴먼명조등 일반적인 명조에서보다 Size가 작음 [ZPD-25256]
						//그나마 유사한 크기를 가진 NanumGothic으로 대체.
						//나눔고딕은 Engine에서 기본적으로 가지고 있는 폰트(HeaderFont)이므로 항상존재함(Windows Version 기준)
						//[16.12.13][sglee1206] 0x25E6의 경우 신명조 계열 HFT에서는 일반적인 명조보다 Size가 크므로 유사한 나눔고딕으로 대체[KPV-518]
						if (ch == 0x25CB || ch == 0x25E6)
						{
							if (!FontWcsCmp(GetFamilyNameByIndex(n), (const unsigned short*)u"NanumGothic"))
							{
								tmpFace = getFontFaceEx(n, fontStyle, nFontWidth, nFontHeight, pFaceIndex, bFind, ch);
								if (tmpFace != BrNULL) {
									return tmpFace;
								}
							}
						}
						/*else if(ch == 0x221A)
						{
						if(!FontWcsCmp(GetFamilyNameByIndex(n), "Times New Roman"))
						{
						tmpFace = getFontFaceEx(n, fontStyle, nFontWidth, nFontHeight, pFaceIndex, bFind, ch);
						if(tmpFace != BrNULL) {
						return tmpFace;
						}
						}
						}*/
						else if (ch >= 0x25F8 && ch <= 0x25FF)
						{
							break;
						}
						else if (ch >= 0xA000 && ch <= 0xA6FF)
						{
							if (!FontWcsCmp(m_pFontName, (const unsigned short*)u"\xD55C\xC591"/*"\xED\x95\x9C\xEC\x96\x91"*/ /*한양*/, 2))	//한양신명조
							{
								//한양신명조와 같은 HFT 폰트는 폴라리스 바탕으로 대체함.
								//eH50Compatibility1_Start ~ eH50Compatibility1_End (ch >= 0xA000 && ch <= 0xA6FF) 영역에 대해서는 아래와 같이 치환함
								//Hwp50CodeMap::DecodeHwpCompatibilityToUnicode(CCharSet& a_CharSet) 함수 동작 참고
								if (!FontWcsCmp(GetFamilyNameByIndex(n), sPurchaseFontName[ePolaris_Batang][0]) ||
									(sPurchaseFontName[ePolaris_Batang][1] != BrNULL &&
										!FontWcsCmp(GetFamilyNameByIndex(n), sPurchaseFontName[ePolaris_Batang][1]))
									)
								{
									ch = ch | 0x0F0000;
									ch = ch - 0xA000;

									tmpFace = getFontFaceEx(n, fontStyle, nFontWidth, nFontHeight, pFaceIndex, bFind, ch);
									if (tmpFace != BrNULL) {
										return tmpFace;
									}
								}
							}
						}
						else if (!FontWcsCmp(GetFamilyNameByIndex(n), sPurchaseFontName[ePolaris_Batang][0]) ||
							(sPurchaseFontName[ePolaris_Batang][1] != BrNULL &&
								!FontWcsCmp(GetFamilyNameByIndex(n), sPurchaseFontName[ePolaris_Batang][1]))
							)
						{
							tmpFace = getFontFaceEx(n, fontStyle, nFontWidth, nFontHeight, pFaceIndex, bFind, ch);
							if (tmpFace != BrNULL) {
								return tmpFace;
							}
						}
					}
					else
					{
						if (m_bLoadedPurchaseFont[ePolarisHumanMyeongjo])
						{
							if (!FontWcsCmp(GetFamilyNameByIndex(n), sPurchaseFontName[ePolarisHumanMyeongjo][0]) ||
								(sPurchaseFontName[ePolarisHumanMyeongjo][1] != BrNULL &&
									!FontWcsCmp(GetFamilyNameByIndex(n), sPurchaseFontName[ePolarisHumanMyeongjo][1]))
								)
							{
								tmpFace = getFontFaceEx(n, fontStyle, nFontWidth, nFontHeight, pFaceIndex, bFind, ch);
								if (tmpFace != BrNULL) {
									return tmpFace;
								}
							}
						}//eHYSinMyeongJo_M
						else if (m_bLoadedPurchaseFont[ePolaris_Batang])
						{
							if (!FontWcsCmp(GetFamilyNameByIndex(n), sPurchaseFontName[ePolaris_Batang][0]) ||
								(sPurchaseFontName[ePolaris_Batang][1] != BrNULL &&
									!FontWcsCmp(GetFamilyNameByIndex(n), sPurchaseFontName[ePolaris_Batang][1]))
								)
							{
								tmpFace = getFontFaceEx(n, fontStyle, nFontWidth, nFontHeight, pFaceIndex, bFind, ch);
								if (tmpFace != BrNULL) {
									return tmpFace;
								}
							}
						}
					}
				}
				else if (!bForceFind)
				{
					if (getDocType() == BORA_DOCTYPE_HWP || getDocType() == BORA_DOCTYPE_ODT)
					{
						//if(!FontWcsCmp(GetFamilyNameByIndex(n), "폴라리스바탕"))
						if (!FontWcsCmp(GetFamilyNameByIndex(n), sPurchaseFontName[ePolaris_Batang][0]) ||
							(sPurchaseFontName[ePolaris_Batang][1] != BrNULL &&
								!FontWcsCmp(GetFamilyNameByIndex(n), sPurchaseFontName[ePolaris_Batang][1]))
							)
						{
							tmpFace = getFontFaceEx(n, fontStyle, nFontWidth, nFontHeight, BrNULL, bFind, ch);
							if (tmpFace != BrNULL) {
								//[17.05.31][sglee1206] 대체폰트가 존재하여도 폴라리스 바탕으로 출력되는 이슈 수정[IAC-2838]
								//폴라리스 바탕과 대체폰트가 존재시 대체폰트로 처리되어야 하는 경우에도 순서에 따라 폴라리스 바탕으로 처리되어 문제발생
								//index만 기억 후 나중에도 없는 경우 처리하도록 수정
								nDefaultFontIndex = n;
							}
						}
					}
					else
					{
						if (!FontWcsCmp(GetFamilyNameByIndex(n), (const unsigned short *)u"Malgun Gothic"))
						{
							tmpFace = getFontFaceEx(n, fontStyle, nFontWidth, nFontHeight, BrNULL, bFind, ch);
							if (tmpFace != BrNULL) {
								//[17.05.31][sglee1206] 대체폰트가 존재하여도 폴라리스 바탕으로 출력되는 이슈 수정[IAC-2838]
								//폴라리스 바탕과 대체폰트가 존재시 대체폰트로 처리되어야 하는 경우에도 순서에 따라 폴라리스 바탕으로 처리되어 문제발생
								//index만 기억 후 나중에도 없는 경우 처리하도록 수정
								nDefaultFontIndex = n;
							}
						}
					}
				}
			}
		}
		if (IS_HANGUL_JAMO(ch))
		{
			for (n = nBSIndex; n < nFontFaceCnt; n++)
			{
				if (bGothic || bDotum)
				{
					if (HAS_FONT_FLAG(fontStyle, FT_STYLE_FLAG_BOLD))
					{
						if ((!FontWcsCmp(GetFamilyNameByIndex(n), sPurchaseFontName[ePolarisNewDotum_B][0]) ||
							(sPurchaseFontName[ePolarisNewDotum_B][1] != BrNULL &&
								!FontWcsCmp(GetFamilyNameByIndex(n), sPurchaseFontName[ePolarisNewDotum_B][1]))
							)
							&& !FontStrCmp(getFTFaceByIndex(n)->style_name, "Bold")
							)
						{
							tmpFace = getFontFaceEx(n, fontStyle, nFontWidth, nFontHeight, pFaceIndex, bFind, ch);
							if (tmpFace != BrNULL) {
								return tmpFace;
							}
						}
					}
					else
					{

						if (!FontWcsCmp(GetFamilyNameByIndex(n), sPurchaseFontName[ePolarisNewDotum][0]) ||
							(sPurchaseFontName[ePolarisNewDotum][1] != BrNULL &&
								!FontWcsCmp(GetFamilyNameByIndex(n), sPurchaseFontName[ePolarisNewDotum][1]))
							)
						{
							tmpFace = getFontFaceEx(n, fontStyle, nFontWidth, nFontHeight, pFaceIndex, bFind, ch);
							if (tmpFace != BrNULL) {
								return tmpFace;
							}
						}
					}
				}
				else
				{
					if (HAS_FONT_FLAG(fontStyle, FT_STYLE_FLAG_BOLD))
					{

						if ((!FontWcsCmp(GetFamilyNameByIndex(n), sPurchaseFontName[ePolarisNewBatang_B][0]) ||
							(sPurchaseFontName[ePolarisNewBatang_B][1] != BrNULL &&
								!FontWcsCmp(GetFamilyNameByIndex(n), sPurchaseFontName[ePolarisNewBatang_B][1]))
							)
							&& !FontStrCmp(getFTFaceByIndex(n)->style_name, "Bold"))
						{
							tmpFace = getFontFaceEx(n, fontStyle, nFontWidth, nFontHeight, pFaceIndex, bFind, ch);
							if (tmpFace != BrNULL) {
								return tmpFace;
							}
						}
					}
					else
					{

						if (!FontWcsCmp(GetFamilyNameByIndex(n), sPurchaseFontName[ePolarisNewBatang][0]) ||
							(sPurchaseFontName[ePolarisNewBatang][1] != BrNULL &&
								!FontWcsCmp(GetFamilyNameByIndex(n), sPurchaseFontName[ePolarisNewBatang][1]))
							)
						{
							tmpFace = getFontFaceEx(n, fontStyle, nFontWidth, nFontHeight, pFaceIndex, bFind, ch);
							if (tmpFace != BrNULL) {
								return tmpFace;
							}
						}
					}
				}
			}
		}
		//[17.05.31][sglee1206] 대체폰트가 존재하여도 폴라리스 바탕으로 출력되는 이슈 수정[IAC-2838]
		//폴라리스 바탕과 대체폰트가 존재시 대체폰트로 처리되어야 하는 경우에도 순서에 따라 폴라리스 바탕으로 처리되어 문제발생
		//index만 기억 후 나중에도 없는 경우 처리하도록 수정
		//if(!strcmp(GetFamilyNameByIndex(n), "폴라리스바탕"))
		if (nDefaultFontIndex >= 0)
		{
			n = nDefaultFontIndex;
			tmpFace = getFontFaceEx(n, fontStyle, nFontWidth, nFontHeight, pFaceIndex, bFind, ch);
			if (tmpFace != BrNULL) {
				return tmpFace;
			}
		}
	}
#endif
	return BrNULL;
}

BrBOOL BoraFont::checkChinese(FT_ULong ch)
{
	if( (PoGetLocale() == BR_LOCALE_S_CHINESE) && checkChineseChar(ch))
		return BrTRUE;

	return BrFALSE;
}

BrBOOL BoraFont::checkChineseChar(FT_ULong ch)
{
	if (IS_HANJA(ch))
		return BrTRUE;

	return BrFALSE;
}

BrBOOL BoraFont::findSimplifiedCFont(FT_ULong ch, FT_Int nFontWidth, FT_Int nFontHeight, BrINT nStart, PO_Face* fontFace, BrINT* pFaceIndex, BrBOOL bCheckGlyphBitmap)
{
	BrINT nFontFaceCnt = GetFontFaceCnt();
	PO_Face face = BrNULL;
	FT_Face ft_face = BrNULL;
	FT_Error error = FT_Err_Ok;

	for (BrINT n = nStart; n < nFontFaceCnt; n++)
	{
		face = GetFontFaceByIndex(n);

		if (bCheckGlyphBitmap)
		{
			if (!checkGlyphBitmap(face, ch, nFontWidth, nFontHeight))
				continue;
		}

		ft_face = setFontFaceCharmap(face, error);

		if (ft_face)
		{
			//[16.08.31][sglee1206] PD Team 요구사항. 중문 Default Font를 Simsun으로 처리 요청[XPD-8806][XPD-8818]
			if (PoGetLocale() == BR_LOCALE_S_CHINESE)
			{
				if (!FontStrCmp(ft_face->family_name, "SimSun"))
				{
					if (FT_Get_Char_Index(ft_face, ch))
					{
						*fontFace = face;
						if (pFaceIndex) *pFaceIndex = n;
						m_nOldIndex = n;
						m_bExistFont = BrTRUE;
						return BrTRUE;
					}
				}
			}
			else
			{
				if (FT_Get_Char_Index(ft_face, ch))
				{
					*fontFace = face;
					if (pFaceIndex) *pFaceIndex = n;
					m_nOldIndex = n;
					m_bExistFont = BrTRUE;
					return BrTRUE;
				}
			}
		}
	}

	return BrFALSE;
}

FT_ULong BoraFont::ConvertSymbolChar(PO_Face pFace, FT_ULong ch, BrBOOL& bSymbolFont)
{
	FT_ULong char_code = ch;

	if (!pFace)
		return char_code;

	bool bSymbolRange = (ch >= 0x20 && ch <= 0xff);
	FT_Face fontFace = pFace->ft_face;
	FT_CharMap charmap = fontFace->charmap;
	BrINT8 nSPFlag = GetSpecialFontFlag(ch);
	
	TT_OS2* os2_table = (TT_OS2*)FT_Get_Sfnt_Table(fontFace, ft_sfnt_os2);
	//bSymbolRange = (ch >= (os2_table->usFirstCharIndex & 0xFF) && ch <= (os2_table->usLastCharIndex & 0xFF));

	if (IS_SPFONT_FLAG(nSPFlag) && ((charmap->encoding == FT_ENCODING_MS_SYMBOL) || (charmap->encoding == FT_ENCODING_UNICODE)) && bSymbolRange)
	{
		char_code = (0xf000 | ch);

		bool bMarlett = m_pFontName ? !FontWcsCmp(m_pFontName, (const unsigned short*)u"Marlett") : false;
		if(bMarlett)
		{
			switch(char_code)
			{
			case 0xf033:
			case 0xf034:
			case 0xf035:
				char_code += 0x49;
				break;
			case 0xf068:
			case 0xf069:
				char_code = 0xf09f;
				break;
			case 0xf06E:
				char_code = 0xf06c;
				break;
			}
		}
		bSymbolFont = BrTRUE;
	}
	else if ( (charmap->encoding == FT_ENCODING_WANSUNG) && (ch > 0x80) )
	{
		FT_UShort wansungCh = 0;	//[16.06.16][sglee1206] Coverity medium 처리 수정
		wansungCh = (ch&0xFFFF);
		char pOutout[3] = {0,};
		if ( BrWideCharToMultiByte( CP_ACP, (BrLPCWSTR)&wansungCh, 1, (BrLPSTR)pOutout, sizeof(pOutout)) )
			char_code = (pOutout[0] << 8)&0xff00 | (pOutout[1]&0xff);
	}
	else if(os2_table && (HAS_SYMBOL_CHARSET(os2_table->ulCodePageRange1) || (fontFace->charmap->encoding == FT_ENCODING_MS_SYMBOL)) && isOpenTypeFontCheck(pFace, BrTRUE))
	{
		//[15.09.04][sglee1206] revision 56687([ZPD-9802][Sheet] Symbol로 공란 입력시 빈공간 없이 기호 표시되는 현상 수정) 사이드 수정
		if(bSymbolRange && !(ch >= (os2_table->usFirstCharIndex) && ch <= (os2_table->usLastCharIndex)) )
		{
			char_code = (0xf000 | ch);	
			bSymbolFont = BrTRUE;
		}
		//[16.07.19][sglee1206][KPV-353] ch가 0xf0XX로 전달되는 경우가 존재. 해당 경우인 기호 폰트의 경우 Flag 세팅이 안되는 경우가 존재하여 해당부분 수정
		// 추후 nSPFlag를 PC 버전에서는 사용하지 않는 방향으로 수정 필요
		else if((charmap->encoding == FT_ENCODING_MS_SYMBOL) && (ch >= 0xf020 && ch <= 0xf0ff) && (ch >= (os2_table->usFirstCharIndex) && ch <= (os2_table->usLastCharIndex)))
		{
			bSymbolFont = BrTRUE;
		}
		else if((charmap->encoding == FT_ENCODING_MS_SYMBOL) && BoraFontComm::IsMSAlterSymbolChar(ch))
		{
			char_code = BoraFontComm::GetMSAlterSymbolChar(ch);
			bSymbolFont = BrTRUE;
		}
#if defined(USE_EMBEDDED_SYMBOL_FONT)
		if(!bSymbolFont && nSPFlag > eSPFONT_NONE_FACE && nSPFlag < eSPFONT_MAX_FACE) {
			BrINT embSymIndex = -1;
			embSymIndex = GetSpecialFontFlag2Index(nSPFlag);

			if( embSymIndex > -1 && (ch >= 0xf020 && ch <= 0xf0ff) && (ch >= (os2_table->usFirstCharIndex) && ch <= (os2_table->usLastCharIndex)))
			{
				bSymbolFont = BrTRUE;
			}
		} 
#endif //USE_EMBEDDED_SYMBOL_FONT
	}

	return char_code;
}

BrINT8 BoraFont::GetSpecialFontFlag(FT_ULong ch)
{
	return BoraFontComm::GetSpecialFontFlag(m_pFontName,ch);
}

FT_Int BoraFont::GetSpecialFontFlag2Index(BrINT8 nSPFlag)
{
	FT_Int embSymIndex = -1;

	if(nSPFlag == eSPFONT_SYMBOL_FACE) {
		embSymIndex = m_nSymbolIndex;
	} else if(nSPFlag == eSPFONT_WINGDING_FACE) {
		embSymIndex = m_nWindingIndex;
	} else if(nSPFlag == eSPFONT_WINGDING2_FACE) {
		embSymIndex = m_nWinding2Index;
	} else if(nSPFlag == eSPFONT_WINGDING3_FACE) {
		embSymIndex = m_nWinding3Index;
	} else if(nSPFlag == eSPFONT_WEBDINGS_FACE) {
		embSymIndex = m_nWebdingsIndex;
	}

	return embSymIndex;
}

BrBOOL BoraFont::CheckLocaleFont(FT_Long ch, BrUSHORT const* strFont, BrUINT16 nLen, BrBOOL bBold, BrBOOL bItalic)
{
	BrBOOL bRet = BrFALSE;
	BrBOOL bFindFont = BrFALSE;
	BrUINT16 orgLen = nLen;
	BrBYTE fontStyle = 0;


	if(strFont == BrNULL)
		return bRet;

	if (bItalic)
		fontStyle |= FT_STYLE_FLAG_ITALIC;

	if (bBold)
		fontStyle |= FT_STYLE_FLAG_BOLD;


	//Convert Name. Unicode to UTF-8
	if ( nLen > 0 )
	{
		BrUSHORT strFontName[MAX_FONT_LENGTH] = {0,};		//Unicode
		BrINT n = -1;

		//Copy Font Name
		memcpy(strFontName, strFont, nLen*2);

		PO_Face	fontFace = NULL;
		BrINT nRuntimeFontIndex = -1;
#if defined( SUPPORT_ADD_FONT )

		BrINT nRet = getFontNameListIndex(strFont);
		if(nRet > -1) {
			nRuntimeFontIndex = m_pFontNameList->GetFontListIndex(nRet);			
		}
#else // defined( SUPPORT_ADD_FONT )
		BrINT nTypefaceListIndex;
		BrWORD* pSystemFontHName = BrNULL;
		BrINT nSystemFontIdx;

		n = 0;
#ifdef SUPPORT_ADD_FONT
		//[15.08.11][sglee1206] PC 버전에서는 기본적으로 systemFont에서 찾도록 처리 SRG-25
		n = m_nBaseIndex;
#endif

		//Memory로 Load된 것만 검색
		for (;n<(BrINT)GetFontFaceCnt();n++)
		{
			nSystemFontIdx = GetFontFaceByIndex(n)->nFontListIndex;
			pSystemFontHName = BrNULL;
			if(nSystemFontIdx != -1) 
			{
				nTypefaceListIndex = m_RuntimeLoadFont.at(nSystemFontIdx)->nTypefaceListIndex;
				if(nTypefaceListIndex >= 0)
				{
					pSystemFontHName = m_aTypeFaceList.at(nTypefaceListIndex)->sFontData.pLocName;
				}
			}
			if (IsFamilyFontName(strFontName, GetFontFaceByIndex(n), fontStyle, pSystemFontHName))
			{			
				bFindFont = BrTRUE;
				fontFace = GetFontFaceByIndex(n);
				break;
			}
		}

		bRet = hasFontGlyph(fontFace, ch);

#endif // defined( SUPPORT_ADD_FONT ) && defined( USE_PC_VERSION_FONT )

#ifdef SUPPORT_ADD_FONT
		if(!bFindFont)
		{
			if (CheckNotExistFontName(strFontName))
				return bRet;
			
			BrINT nIndex = loadSystemFontFile(nRuntimeFontIndex);

			//[15.09.21][sglee1206] MS Office처럼 대체되는 폰트 존재 확인
			if(nIndex < 0 && existAlterFont(strFontName))
			{
				BrWORD MSAlterFontName[MAX_FONT_LENGTH] = {0,};
				BoraFontComm::GetAlterFontName(strFontName,MSAlterFontName, MAX_FONT_LENGTH);
				nIndex = loadSystemFontFile(MSAlterFontName);
			}
			if(nIndex < 0)
			{
#ifndef USE_PANOSE_INFO	
				BrWORD* ignoreFontName;
				ignoreFontName = (BrWORD*)PoSysMalloc((BrWcsLen(strFontName)+1)*BrSizeOf(BrWORD));
				memset(ignoreFontName, 0, (BrWcsLen(strFontName) + 1) * BrSizeOf(BrWORD));
				CUtil::WcsCpy(ignoreFontName, strFontName);
				m_aNotExistFontName.add(ignoreFontName);
				return bRet;
#endif
			}
			else
			{
				//이게 의미가 있나
				fontFace = GetFontFaceByIndex(nIndex);
				n = nIndex;
			}
		}

		//Check Font 
		LPBrTypefaceStruct pSameFamilyList = m_aTypeFaceList.at(nRuntimeFontIndex);
		BrINT nCountSameFamily = pSameFamilyList->nCountSameFamily;
		BrINT fIdx = 0;
		LPBrFontStyleIdxNode pNode = BrNULL;

		if(nCountSameFamily == 1)
		{
			for (; fIdx<eFontStyleIndexMax ; fIdx++)
			{
				if(pSameFamilyList->nStyleCnt[fIdx] > 0)
				{
					pNode = pSameFamilyList->nFontIndices[fIdx];
					break; 
				}
			}
		}
		else if(nCountSameFamily > 1)
		{
			fIdx = fontStyle;
			if(pSameFamilyList->nStyleCnt[fIdx] > 0)
				pNode = pSameFamilyList->nFontIndices[fIdx];
			//[16.03.01][sglee1206] nRunTimeFont 값 잘못처리되는 버그 수정
			else if(fIdx == eStyleBoldItalic)
			{
				if(pSameFamilyList->nStyleCnt[eStyleBold] > 0)
					pNode = pSameFamilyList->nFontIndices[eStyleBold];
				else if(pSameFamilyList->nStyleCnt[eStyleItalic] > 0)
					pNode = pSameFamilyList->nFontIndices[eStyleItalic];
				else if(pSameFamilyList->nStyleCnt[eStyleRegular] > 0)
					pNode = pSameFamilyList->nFontIndices[eStyleRegular];
			}
			else if(fIdx == eStyleBold)
			{
				if(pSameFamilyList->nStyleCnt[eStyleRegular] > 0)
					pNode = pSameFamilyList->nFontIndices[eStyleRegular];
				else if(pSameFamilyList->nStyleCnt[eStyleBoldItalic] > 0)
					pNode = pSameFamilyList->nFontIndices[eStyleBoldItalic];
				else if(pSameFamilyList->nStyleCnt[eStyleExtra1] > 0)
					pNode = pSameFamilyList->nFontIndices[eStyleExtra1];
			}
			else if(fIdx == eStyleItalic)
			{
				if(pSameFamilyList->nStyleCnt[eStyleRegular] > 0)
					pNode = pSameFamilyList->nFontIndices[eStyleRegular];
				else if(pSameFamilyList->nStyleCnt[eStyleBoldItalic] > 0)
					pNode = pSameFamilyList->nFontIndices[eStyleBoldItalic];
				else if(pSameFamilyList->nStyleCnt[eStyleExtra1] > 0)
					pNode = pSameFamilyList->nFontIndices[eStyleExtra1];
			}
			else
			{
				if(pSameFamilyList->nStyleCnt[eStyleRegular] > 0)
					pNode = pSameFamilyList->nFontIndices[eStyleRegular];
				else if(pSameFamilyList->nStyleCnt[eStyleExtra1] > 0)
					pNode = pSameFamilyList->nFontIndices[eStyleExtra1];
				else if(pSameFamilyList->nStyleCnt[eStyleBold] > 0)
					pNode = pSameFamilyList->nFontIndices[eStyleBold];
				else if(pSameFamilyList->nStyleCnt[eStyleItalic] > 0)
					pNode = pSameFamilyList->nFontIndices[eStyleItalic];
				else if(pSameFamilyList->nStyleCnt[eStyleBoldItalic] > 0)
					pNode = pSameFamilyList->nFontIndices[eStyleBoldItalic];
			}
		}
		else
			return bRet;

		BrINT nRunTimeFont = -1;
		while(pNode != BrNULL && bRet == BrFALSE)
		{
			nRunTimeFont = pNode->nFontIndex;
			//[16.05.13][sglee1206] symbol Font Load 시 base Font index가 증가하여 문제 발생. [XPD-1766]
			// 시작 index 수정
			for (BrINT i = 0; i<GetFontFaceCnt() ; i++)
			{
				if(nRunTimeFont == GetFontFaceByIndex(i)->nFontListIndex)
				{
					fontFace = GetFontFaceByIndex(i);
					n = i;
					break; 
				}
			}

			bRet = hasFontGlyph(fontFace, ch);
			pNode = pNode->pNext;
		}
#endif//SUPPORT_ADD_FONT
	}

	return bRet;
}

BrBOOL BoraFont::IsExistFont( BrUSHORT const* strFont, BrUINT16 nLen)
{
	BrBOOL bFindFont = BrFALSE;
	BrUINT16 orgLen = nLen;

	
	if(strFont == BrNULL)
		return bFindFont;

	//Convert Name. Unicode to UTF-8
	if ( nLen > 0 )
	{
		BrUSHORT strFontName[MAX_FONT_LENGTH] = {0,};		//Unicode
		//Copy Font Name
		memcpy(strFontName, strFont, nLen*2);

#if defined( SUPPORT_ADD_FONT )
		BrINT nRuntimeFontIndex = -1;
		BrINT nRet = getFontNameListIndex(strFontName);
		if(nRet > -1) {
			bFindFont = BrTRUE;	
		}
#else // defined( SUPPORT_ADD_FONT )

		BrWORD* pSystemFontHName = BrNULL;
		BrINT n, nSystemFontIdx, nTypefaceListIndex;
		
		n = 0;
#ifdef SUPPORT_ADD_FONT
		//[15.08.11][sglee1206] PC 버전에서는 기본적으로 systemFont에서 찾도록 처리 SRG-25
		n = m_nBaseIndex;
#endif

		//Memory로 Load된 것만 검색
		for (;n<(BrINT)GetFontFaceCnt();n++)
		{
			pSystemFontHName = BrNULL;
			nSystemFontIdx = GetFontFaceByIndex(n)->nFontListIndex;
			if(nSystemFontIdx != -1) 
			{
				nTypefaceListIndex = m_RuntimeLoadFont.at(nSystemFontIdx)->nTypefaceListIndex;
				if(nTypefaceListIndex >= 0)
				{
					pSystemFontHName = m_aTypeFaceList.at(nTypefaceListIndex)->sFontData.pLocName;
				}
			}
			if (IsFamilyFontName(strFontName, GetFontFaceByIndex(n), 0, pSystemFontHName))
			{			
				bFindFont = BrTRUE;
				break;
			}
		}
#endif // defined( SUPPORT_ADD_FONT ) && defined( USE_PC_VERSION_FONT )
	}

	return bFindFont;
}

int BoraFont::setCurFontName(BrUSHORT* szCurFont)
{
	int listSize = m_szCurFontList.size()-1;
	m_nFontNameIndexTemp = -1;

	for (int n=listSize; n>=0; n--)
	{
		if ( !CUtil::WcsCmp(szCurFont, m_szCurFontList[n]) )
		{
			return n;
		}
	}
	int orgLen = BrWcsLen(szCurFont);
	BrUSHORT* szTmpCurFont = (BrUSHORT*)PoSysCalloc(orgLen+1, sizeof(BrUSHORT));
	CUtil::WcsCpy(szTmpCurFont, szCurFont);
	
	//속도에 문제가 있을 수 있으나 함수 호출 회수 대비 push_back은 거의 없으므로 그래도 둠
	//만약 문제가 생기면 reserve사용하여 다시 구현 필요
	m_szCurFontList.push_back(szTmpCurFont);
	return m_szCurFontList.size() - 1;
}

FT_Int BoraFont::SetFontName(BrLPWORD strFontName, BrBOOL bBold, BrBOOL bItalic, BrBOOL& bToUpper, BrBOOL& bFontExistCheck)
{
	BrBYTE fontStyle = 0;

	if (bItalic)
		fontStyle |= FT_STYLE_FLAG_ITALIC;

	if (bBold)
		fontStyle |= FT_STYLE_FLAG_BOLD;

	if (strFontName == BrNULL)
	{
		m_nFontFlag = eBaseFont;
		//m_nBaseRatio = 0;
		return m_nFontFlag;
	}
	
	BrINT nLen = BrWcsLen(strFontName);
	if(nLen == 0)
	{
		m_nFontFlag = eBaseFont;
		//m_nBaseRatio = 0;
		return m_nFontFlag;
	}
	
	//[17.11.28][sglee1206] nLen 및 strFont가 비정상적으로 넘어오는 경우에 대한 예외처리[XPD-20242] 
	nLen = BrMIN(nLen,(MAX_FONT_LENGTH-1));
	bFontExistCheck = BrTRUE;
	if (!CUtil::WcsCmp(strFontName, m_pFontName))
	{
		if (m_CheckFontStyle != fontStyle)
			m_nOldIndex = -1;
		if (CheckNotExistFontName(m_pFontName))
		{
			bFontExistCheck = BrFALSE;
		}
		return m_nFontFlag;
	}	

	memset(m_pFontName, 0, MAX_FONT_LENGTH * sizeof(BrUSHORT) );
	CUtil::WcsNcpy(m_pFontName, strFontName, nLen);
	m_nCurFontNameIndex = setCurFontName(m_pFontName);
	m_nFontFlag = eBaseFont;
	m_nOldIndex = -1;
	//m_nBaseRatio = 0;
	BrBOOL bFindFont = BrFALSE;
	if(nLen)
	{
		m_nFontFlag = getFontFlag(m_pFontName, nLen, fontStyle, bToUpper);

		PO_Face	fontFace = NULL;
		BrINT n=0;

#ifdef SUPPORT_ADD_FONT
		BrINT nRuntimeFontIndex = -1;
#endif

#if defined( SUPPORT_ADD_FONT )
		//[15.08.11][sglee1206] PC 버전에서는 기본적으로 systemFont에서 찾도록 처리 SRG-25
		n = m_nBaseIndex;
		BrINT nRet = getFontNameListIndex(m_pFontName);
		if(nRet > -1) {
			nRuntimeFontIndex = m_pFontNameList->GetFontListIndex(nRet);
		} 
#else // defined( SUPPORT_ADD_FONT ) && defined( USE_PC_VERSION_FONT )
		BrWORD* pSystemFontHName = BrNULL;
		BrINT	nSystemFontIdx, nTypefaceListIndex;

		if (!CheckNotExistFontName(m_pFontName))
		{
			for (; n < (BrINT)GetFontFaceCnt(); n++)
			{
				nSystemFontIdx = GetFontFaceByIndex(n)->nFontListIndex;
				pSystemFontHName = BrNULL;
				if (nSystemFontIdx != -1)
				{
					nTypefaceListIndex = m_RuntimeLoadFont.at(nSystemFontIdx)->nTypefaceListIndex;
					if (nTypefaceListIndex >= 0)
					{
						pSystemFontHName = m_aTypeFaceList.at(nTypefaceListIndex)->sFontData.pLocName;
					}
				}
				if (IsFamilyFontName(m_pFontName, GetFontFaceByIndex(n), fontStyle, pSystemFontHName))
				{
					fontFace = GetFontFaceByIndex(n);
					bFindFont = BrTRUE;
					break;
				}
			}
		}
#endif // defined( SUPPORT_ADD_FONT )

#ifdef SUPPORT_ADD_FONT
		if(!bFindFont)
		{
			if (CheckNotExistFontName(m_pFontName))
			{
				bFontExistCheck = BrFALSE;
				return m_nFontFlag;
			}

			BrINT nIndex = loadSystemFontFile(nRuntimeFontIndex);
			
			//[15.09.21][sglee1206] MS Office처럼 대체되는 폰트 존재 확인
			if(nIndex < 0 && existAlterFont(m_pFontName))
			{
				BrWORD MSAlterFontName[MAX_FONT_LENGTH] = {0,};
				BoraFontComm::GetAlterFontName(m_pFontName,MSAlterFontName, MAX_FONT_LENGTH);
				nIndex = loadSystemFontFile(MSAlterFontName);
			}

#ifndef USE_PANOSE_INFO
			if(nIndex < 0)
			{
				bFontExistCheck = BrFALSE;
				BrWORD* ignoreFontName;
				ignoreFontName = (BrWORD*)PoSysMalloc((BrWcsLen(m_pFontName) + 1) * BrSizeOf(BrWORD));
				memset(ignoreFontName, 0, (BrWcsLen(m_pFontName) + 1) * BrSizeOf(BrWORD));
				CUtil::WcsCpy(ignoreFontName, m_pFontName);
				m_aNotExistFontName.add(ignoreFontName);
			}
#endif
			else
			{
				m_nFontFlag = getFontFlag(m_pFontName, nLen, fontStyle, bToUpper);
				fontFace = GetFontFaceByIndex(nIndex);
			}
		}
#else
		if(!bFindFont)
		{
			if (CheckNotExistFontName(m_pFontName))
			{
				bFontExistCheck = BrFALSE;
				return m_nFontFlag;
			}

			bFontExistCheck = BrFALSE;
			BrWORD* ignoreFontName;
			ignoreFontName = (BrWORD*)PoSysMalloc((BrWcsLen(m_pFontName) + 1) * BrSizeOf(BrWORD));
			memset(ignoreFontName, 0, (BrWcsLen(m_pFontName) + 1) * BrSizeOf(BrWORD));
			CUtil::WcsCpy(ignoreFontName, m_pFontName);
			m_aNotExistFontName.add(ignoreFontName);
		}
#endif//SUPPORT_ADD_FONT
	}
	else
		m_EFIndex = eEF_NoneFont;

	return m_nFontFlag;
}

BrBOOL BoraFont::SearchTable( FT_ULong ch, BrBYTE fontStyle )
{			
#ifdef USE_COMMON_INTERFACE
	BrBOOL bRet = BrFALSE;
	
	/* 
	Basic Latin 영역에 한해 Font Width Table 사용.
	Export가 아닌 Sheet와 
	
	*/ 
	if( m_nFontFlag >= 0 && ch >= 0x20 && ch <= 0x7F && 
		( (IS_SHEET_TEXT_DRAW && !isExportMode()) || !m_bRealFont )
	)
		bRet = BrTRUE;	
	else
		bRet = BrFALSE;

	if(bRet)
	{
		// 내장폰트인 경우 Font Table 이용안함
		BrINT nRet = m_InternalFontNameList->BinarySearch(m_pFontName);
		if(nRet> -1)
		{
			BrINT nIdx = m_InternalFontNameList->GetFontListIndex(nRet);
			nIdx = findInternalFontIndex(nIdx, fontStyle);

			if(nIdx > -1)
			{
				PO_Face face = getInternalFontFace(nIdx);
				for(int charmapIdx = 0; charmapIdx < face->ft_face->num_charmaps; charmapIdx++)
				{
					FT_Set_Charmap(face->ft_face,face->ft_face->charmaps[charmapIdx]);

					if( FT_Get_Char_Index(face->ft_face, ch) )
						return BrFALSE;
				}
			}
		}

		if (getFontNameListIndex(m_pFontName) > -1)
			return BrFALSE;
	}

	return bRet;

#endif//ifdef USE_COMMON_INTERFACE
	return BrFALSE;
}


void BoraFont::setFontFaceSize(FT_Face pFace, FT_ULong ch, FT_Int nFontWidth, FT_Int nFontHeight)
{
	if(pFace == BrNULL)
		return;

	if( m_nFontFlag == eZapfinoFont && (ch >= 0x20 && ch <= 0xFF))
		FT_Set_Pixel_Sizes(pFace, nFontWidth /2, nFontHeight /2);
	else
	{
		FT_UInt embedH,embedW;
		if(getEmbedBitmapGlyphSize(pFace,embedW,embedH))
			FT_Set_Pixel_Sizes(pFace, embedW, embedH);
		else
			FT_Set_Pixel_Sizes(pFace, nFontWidth, nFontHeight);
	}
}

FT_Face BoraFont::setFontFaceCharmap(PO_Face pFace, FT_Error& bSetCharmap)
{
	FT_Face ft_face = BrNULL;

	if (pFace != BrNULL && pFace->ft_face != BrNULL && pFace->ft_face->charmaps != BrNULL)
	{
		ft_face = pFace->ft_face;

		//이 조건일때 0으로 처리를 해야할지 아니면 error로 처리하여야할지 고민
		if (pFace->nPrimaryCharmapIdx < 0 || pFace->nPrimaryCharmapIdx >= ft_face->num_charmaps)
			pFace->nPrimaryCharmapIdx = 0;

		FT_CharMap charmap = ft_face->charmaps[pFace->nPrimaryCharmapIdx];
		if (ft_face->charmap != charmap)
			bSetCharmap = FT_Set_Charmap(ft_face, charmap);
		else
			bSetCharmap = FT_Err_Ok;
	}
	else
		bSetCharmap = FT_THROW(Invalid_Face_Handle);

	return ft_face;
}

BrBOOL BoraFont::isOpenTypeFontCheck(PO_Face fontFace, BrBOOL bCheckCFF, BrBOOL bCheckTT)
{
	BrBOOL bRet = BrFALSE;

	if (fontFace != BrNULL)
	{
		if (fontFace->moduleName == NULL)
			fontFace->moduleName = FT_Get_Font_Format(fontFace->ft_face);

		const char* moduleName = fontFace->moduleName;
		if (moduleName && BrStrLen(moduleName) > 0)
		{
			char moduleFirstChar = BrToUpper(moduleName[0]);

			if (!bRet && bCheckTT)
				bRet |= (moduleFirstChar == 'T') && !FontStrCmp(moduleName, "TrueType");

			if (!bRet && bCheckCFF)
				bRet |= (moduleFirstChar == 'C') && !FontStrCmp(moduleName, "CFF");
		}
	}

	return bRet;
}

FT_Int BoraFont::GetCharHeight(BrBYTE fontStyle, FT_Int nFontWidth, FT_Int nFontHeight, BrBOOL bFontExistCheck)
{
#ifdef SUPPORT_ADD_FONT
#if FONT_HEIGHT_TEST_CODE_ENABLE
	PO_Face fontFace = GetFontFace(' ',fontStyle,nFontWidth,nFontHeight,bFontExistCheck);

	FT_Int nHeight = 0;
	nHeight = fontFace->ft_face->size->metrics.height >> 6;

	return nHeight;

#else
	if (getFTFaceByIndex(m_nBaseIndex) == BrNULL)
		return (((getFTFaceByIndex(0)->size->metrics.x_ppem * BASE_ASCENT) - (getFTFaceByIndex(0)->size->metrics.x_ppem * BASE_DESCENT)) / 200) >> 6;
	else
		return (((getFTFaceByIndex(m_nBaseIndex)->size->metrics.x_ppem * BASE_ASCENT) - (getFTFaceByIndex(m_nBaseIndex)->size->metrics.x_ppem * BASE_DESCENT)) / 200) >> 6;
#endif
#else
	return (((getFTFaceByIndex(m_nBaseIndex)->size->metrics.x_ppem * BASE_ASCENT) - (getFTFaceByIndex(m_nBaseIndex)->size->metrics.x_ppem * BASE_DESCENT)) / 200) >> 6;
#endif
}

FT_Int BoraFont::GetCharAscent(BrBYTE fontStyle, FT_Int nFontWidth, FT_Int nFontHeight, BrBOOL bFontExistCheck)
{
#ifdef SUPPORT_ADD_FONT
#if FONT_HEIGHT_TEST_CODE_ENABLE
	PO_Face fontFace = GetFontFace(' ', fontStyle, nFontWidth, nFontHeight, bFontExistCheck);
	FT_Int nAsc = 0;
	nAsc = fontFace->ft_face->size->metrics.ascender >> 6;

	return nAsc;

#else
	if (getFTFaceByIndex(m_nBaseIndex) == BrNULL)
		return ((getFTFaceByIndex(0)->size->metrics.x_ppem * BASE_ASCENT) / 200 + 32) >> 6;
	else
		return ((getFTFaceByIndex(m_nBaseIndex)->size->metrics.x_ppem * BASE_ASCENT) / 200 + 32) >> 6;
#endif
#else
	return ((getFTFaceByIndex(m_nBaseIndex)->size->metrics.x_ppem * BASE_ASCENT) / 200 + 32) >> 6;
#endif
}

FT_Int BoraFont::GetCharDescent(BrBYTE fontStyle, FT_Int nFontWidth, FT_Int nFontHeight, BrBOOL bFontExistCheck)
{
#ifdef SUPPORT_ADD_FONT
#if FONT_HEIGHT_TEST_CODE_ENABLE
	PO_Face fontFace = GetFontFace(' ', fontStyle, nFontWidth, nFontHeight, bFontExistCheck);
	FT_Int nDes = 0;
	nDes = fontFace->ft_face->size->metrics.descender >>6;

	return -nDes;

#else
	if(getFTFaceByIndex(m_nBaseIndex) == BrNULL)
		return ( 32 - ( (getFTFaceByIndex(0)->size->metrics.x_ppem*BASE_DESCENT) / 200 ) ) >> 6;
	else
		return ( 32 - ( (getFTFaceByIndex(m_nBaseIndex)->size->metrics.x_ppem*BASE_DESCENT) / 200 ) ) >> 6;
#endif
#else
	return ( 32 - ( (getFTFaceByIndex(m_nBaseIndex)->size->metrics.x_ppem*BASE_DESCENT) / 200 ) ) >> 6;
#endif
}


eotDefaultFormat* BoraFont::getEOTHeader(PO_Face face, LPBrFontStruct fontSt)
{
	eotDefaultFormat* eotFont = (eotDefaultFormat *)BrCalloc(1, sizeof(eotDefaultFormat));

	if (eotFont == BrNULL || face == NULL)
	{
		BR_SAFE_FREE(eotFont);
		return BrNULL;
	}
	eotFont->EOTSize = BrSizeOf(eotFont) - (5 * BrSizeOf(unsigned char*));	// FamilyName, StyleName, VersionName, FullName, FontData 제거

#if 0 /******* PO not used... *******/
	eot201Extra exData = { 0, };
	eotFont->EOTSize += (BrSizeOf(exData) - BrSizeOf(unsigned char*));	// RootString 제거
#endif

	eotFont->FontDataSize = 0;	// headerLength + dataLength... Compress 후 더 줄어듬
	eotFont->Version = 0x00010000; // 0x00020001;
	eotFont->Flags = 0;
	eotFont->MagicNumber = 0x504C;

	FT_Face fontFace = face->ft_face;
	TT_OS2* OS2 = (TT_OS2*)FT_Get_Sfnt_Table(fontFace, ft_sfnt_os2);

	eotFont->Charset = 0x1;		// DEFAULT_CHARSET
	eotFont->Weight = 400;		// 400	Normal (Regular)	FW_NORMAL
	if (OS2)
	{
		for (unsigned j = 0; j < 10; j++)
			eotFont->FontPANOSE[j] = OS2->panose[j];
		eotFont->Italic = OS2->fsSelection & 0x01;
		eotFont->Weight = OS2->usWeightClass;
		// FIXME: Should use OS2->fsType, but some TrueType fonts set it to an over-restrictive value.
		// Since ATS does not enforce this on Mac OS X, we do not enforce it either.
		//eotFont->fsType = OS2->fsType & 0x000F;
		eotFont->fsType = 0;

		eotFont->UnicodeRange1 = OS2->ulUnicodeRange1;
		eotFont->UnicodeRange2 = OS2->ulUnicodeRange2;
		eotFont->UnicodeRange3 = OS2->ulUnicodeRange3;
		eotFont->UnicodeRange4 = OS2->ulUnicodeRange4;

		eotFont->CodePageRange1 = OS2->ulCodePageRange1;
		eotFont->CodePageRange2 = OS2->ulCodePageRange2;
	}

	TT_Header* head = (TT_Header*)FT_Get_Sfnt_Table(fontFace, ft_sfnt_head);

	if (head)
	{
		eotFont->CheckSumAdjustment = head->CheckSum_Adjust;
	}

	//Name Unicode
	eotFont->FamilyNameSize = 0;
	if (fontSt != BrNULL)
	{
		BrWORD* pSystemFontHName = BrNULL;
		BrINT nTypefaceListIndex = fontSt->nTypefaceListIndex;
		if (nTypefaceListIndex >= 0)
		{
			pSystemFontHName = m_aTypeFaceList.at(nTypefaceListIndex)->sFontData.pLocName;
		}

		if (pSystemFontHName != BrNULL && BrWcsLen(pSystemFontHName) > 0)
		{
			eotFont->FamilyNameSize = (BrWcsLen(pSystemFontHName) + 1) * 2;
			eotFont->FamilyName = (unsigned char*)BrCalloc(eotFont->FamilyNameSize, 1);
			if (eotFont->FamilyName)
			{
				memcpy_s(eotFont->FamilyName, eotFont->FamilyNameSize, pSystemFontHName, BrWcsLen(pSystemFontHName) * 2);
				eotFont->EOTSize += eotFont->FamilyNameSize;
			}
		}
	}

	if (eotFont->FamilyNameSize <= 0)
	{
		eotFont->FamilyNameSize = (BrWcsLen(face->family_name_Unicode) + 1) * 2;
		eotFont->FamilyName = (unsigned char*)BrCalloc(eotFont->FamilyNameSize, 1);
		if (eotFont->FamilyName)
		{
			memcpy_s(eotFont->FamilyName, eotFont->FamilyNameSize, face->family_name_Unicode, BrWcsLen(face->family_name_Unicode) * 2);
			eotFont->EOTSize += eotFont->FamilyNameSize;
		}
	}

	FT_UInt tmCount = FT_Get_Sfnt_Name_Count(fontFace);

	BrBOOL bStyle = BrFALSE, bFullName = BrFALSE, bVersionName = BrFALSE;
	for (int j = 0; j < tmCount; j++)
	{
		BrWORD* fontName = BrNULL;
		FT_SfntName tmName;
		FT_Get_Sfnt_Name(fontFace, j, &tmName);

		if (
			(tmName.platform_id == TT_PLATFORM_MICROSOFT
#if defined(USE_FOR_IOS) || defined(MAC_FONT_SUPPORT)
				|| tmName.platform_id == TT_PLATFORM_MACINTOSH
#endif
				) &&
			(tmName.name_id == TT_NAME_ID_FONT_FAMILY || tmName.name_id == TT_NAME_ID_FONT_SUBFAMILY || tmName.name_id == TT_NAME_ID_FULL_NAME || tmName.name_id == TT_NAME_ID_VERSION_STRING)
			)
		{
			fontName = getSfntName(tmName);
			if (tmName.name_id == TT_NAME_ID_FONT_SUBFAMILY)
			{
				eotFont->StyleNameSize = (BrWcsLen(fontName) + 1) * BrSizeOf(BrWORD);
				eotFont->StyleName = (unsigned char*)fontName;
				eotFont->EOTSize += eotFont->StyleNameSize;
				bStyle = BrTRUE;
			}
			else if (tmName.name_id == TT_NAME_ID_FULL_NAME)
			{
				eotFont->FullNameSize = (BrWcsLen(fontName) + 1) * BrSizeOf(BrWORD);
				eotFont->FullName = (unsigned char*)fontName;
				eotFont->EOTSize += eotFont->FullNameSize;
				bFullName = BrTRUE;
			}
			else if (tmName.name_id == TT_NAME_ID_VERSION_STRING)
			{
				eotFont->VersionNameSize = BrWcsLen(fontName) * BrSizeOf(BrWORD);
				eotFont->VersionName = (unsigned char*)fontName;
				eotFont->EOTSize += eotFont->VersionNameSize;
				bVersionName = BrTRUE;
			}
		}

		if (bStyle && bFullName && bVersionName)
			break;
	}

	return eotFont;
}

BrUINT BoraFont::getEOTFontData(unsigned char* dst, PO_Face face, LPBrFontStruct fontSt)
{
	BrINT fontSize = 0;

	LPBrLoadFontFileList pFontFile = BrNULL;
	BrINT32 nTTFCount = 0;
	BFile file;

	BrINT ttcPos = 0;
	fontTTFheader _fontTTFHeaders;

	fontTableRec dsig;
	ttcHeader ttc;
	ttc.tag = 0;
	if (fontSt != BrNULL)
	{
		pFontFile = getLoadFontFileList(fontSt->nFontFileIdx);

		if (pFontFile != BrNULL && pFontFile->pFontPath)
		{
			BString strSrcFile = CUtil::UTF8ToBString((char*)pFontFile->pFontPath);
			if (file.Open(strSrcFile, BMV_READ_ONLY))
			{
				BrBYTE pTTCData[4 + 1] = { 0, };
				file.Read(pTTCData, 4);
				if (!FontStrCmp((const char*)pTTCData, "ttcf", 4))
				{
					ttc.tag = chars_2_BEULong(pTTCData);
					file.Read(pTTCData, 2);
					ttc.majorVersion = chars_2_BEUShort(pTTCData);
					file.Read(pTTCData, 2);
					ttc.minorVersion = chars_2_BEUShort(pTTCData);
					file.Read(pTTCData, 4);
					ttc.numFonts = chars_2_BEULong(pTTCData);
					nTTFCount = ttc.numFonts;
					for (int ttcIdx = 0; ttcIdx < ttc.numFonts; ttcIdx++)
					{
						BrUINT32 offset = 0;
						file.Read(pTTCData, 4);
						offset = chars_2_BEULong(pTTCData);
						ttc.tableDirectoryOffsets.Add(offset);
					}

#if 0			/** DSIG 관련 내용으로 현재 필요한지 판단 중**/
					if (ttc.majorVersion > 1)
					{
						file.Read(pTTCData, 4);
						dsig.tag = chars_2_BEULong(pTTCData);
						file.Read(pTTCData, 4);
						dsig.length = chars_2_BEULong(pTTCData);
						file.Read(pTTCData, 4);
						dsig.offset = chars_2_BEULong(pTTCData);

						BrINT64 pos = file.Tell();
						BrINT dsigLen = dsig.length / 4;
						dsigLen *= 4;

						BrBYTE* dsigData = (BrBYTE*)BrCalloc(dsigLen, BrSizeOf(BrBYTE));
						file.Seek(dsig.offset, BFILE_BEGIN);
						file.Read(dsigData, dsig.length);
						_calcTableChecksum(dsigData, dsigLen);

						BrFree(dsigData);
						file.Seek(pos, BFILE_BEGIN);
					}
#endif
				}

				if (ttc.tag != 0 && fontSt->nFontFileFaceIndex < nTTFCount)
				{
					ttcPos = ttc.tableDirectoryOffsets[fontSt->nFontFileFaceIndex];
				}

				file.Seek(ttcPos, BFILE_BEGIN);

				file.Read(pTTCData, 4);
				_fontTTFHeaders.sfntVersion = chars_2_BEULong(pTTCData);
				file.Read(pTTCData, 2);
				_fontTTFHeaders.numTables = chars_2_BEUShort(pTTCData);
				file.Read(pTTCData, 2);
				_fontTTFHeaders.searchRange = chars_2_BEUShort(pTTCData);
				file.Read(pTTCData, 2);
				_fontTTFHeaders.entrySelector = chars_2_BEUShort(pTTCData);
				file.Read(pTTCData, 2);
				_fontTTFHeaders.rangeShift = chars_2_BEUShort(pTTCData);

				BrINT headerLength = 12;
				BrINT dataLength = 0;
				for (int ttfHeadIdx = 0; ttfHeadIdx < _fontTTFHeaders.numTables; ttfHeadIdx++)
				{
					fontTableRec ttfHeader;
					file.Read(pTTCData, 4);
					ttfHeader.tag = chars_2_BEULong(pTTCData);
					file.Read(pTTCData, 4);
					ttfHeader.checksum = chars_2_BEULong(pTTCData);
					file.Read(pTTCData, 4);
					ttfHeader.offset = chars_2_BEULong(pTTCData);
					file.Read(pTTCData, 4);
					ttfHeader.length = chars_2_BEULong(pTTCData);

					headerLength += 16;
					dataLength += (ttfHeader.length + 3) & ~(0x3);
					_fontTTFHeaders.tables.Add(ttfHeader);
				}

				fontSize = headerLength + dataLength;
				dst = (unsigned char*)BrCalloc(fontSize, BrSizeOf(unsigned char));

				if (dst == BrNULL)
					return 0;

				BrINT wrPos = 0;
				wrPos += BE_2_Chars(dst + wrPos, _fontTTFHeaders.sfntVersion);
				wrPos += BE_2_Chars(dst + wrPos, _fontTTFHeaders.numTables);
				wrPos += BE_2_Chars(dst + wrPos, _fontTTFHeaders.searchRange);
				wrPos += BE_2_Chars(dst + wrPos, _fontTTFHeaders.entrySelector);
				wrPos += BE_2_Chars(dst + wrPos, _fontTTFHeaders.rangeShift);

				BrUINT curDataPos = headerLength;
				for (int ttfHeadIdx = 0; ttfHeadIdx < _fontTTFHeaders.numTables; ttfHeadIdx++)
				{
					fontTableRec ttfHeader = _fontTTFHeaders.tables.at(ttfHeadIdx);
					wrPos += BE_2_Chars(dst + wrPos, ttfHeader.tag);
					wrPos += BE_2_Chars(dst + wrPos, ttfHeader.checksum);
					wrPos += BE_2_Chars(dst + wrPos, curDataPos);
					wrPos += BE_2_Chars(dst + wrPos, ttfHeader.length);
					file.Seek(ttfHeader.offset, BFILE_BEGIN);
					file.Read(dst + curDataPos, ttfHeader.length);

					curDataPos += (ttfHeader.length + 3) & ~(0x3);
				}
			}

			file.Close();
		}
		else
		{
			// memory open font 처리
			;
		}

	}

	return fontSize;
}

void* BoraFont::GetEmbeddedFontData(BrINT& nLen, BrINT& error)
{
#if 0	// 개발중인 코드
	//조건 
	// 대체폰트는 내장하지 않고 해당 글꼴 없다고 팝업
	// PO에서는 내장시 version 1.0
	// 파라미터는 필요시 변경
	
	//Font matching
	//폰트이름이나 ID 등으로 폰트 매칭하는 부분 코드 작성 필요
	// 임시로 테스트코드 사용
	PO_Face face = m_Face[m_nBaseIndex]; //test code

	//get font sturct...
	LPBrFontStruct fontSt = BrNULL;
	BrINT nSystemFontIdx = face->nFontListIndex;

	if (nSystemFontIdx != -1)
		fontSt = m_RuntimeLoadFont.at(nSystemFontIdx);


	//get eot default table
	eotDefaultFormat* eotFont = getEOTHeader(face, fontSt);
	
	if (eotFont == BrNULL)
		return BrNULL;

#if 0 // Version 0x00020001. optional data
	eot201Extra eot201;
	eot202Extra eot202;
	if (eotFont->Version > 0x00010000)	// 0x00020001 over
	{
		eotFont->EOTSize += 2 + 2 + RootStringSize; //

#if 0	// Version 0x00020002
		if (eotFont->Version > 0x00020002)
		{
			;
		}
#endif
	}
#endif

	//get font data
	unsigned char* fontData = BrNULL;
	BrUINT fontSize = getEOTFontData(fontData, face, fontSt);

	if (fontSize <= 0)
	{
		BR_SAFE_FREE(eotFont->FamilyName);
		BR_SAFE_FREE(eotFont->StyleName);
		BR_SAFE_FREE(eotFont->VersionName);
		BR_SAFE_FREE(eotFont->FullName);

		BR_SAFE_FREE(eotFont);
		BR_SAFE_FREE(fontData);
		
		return BrNULL;
	}

	eotFont->FontData = fontData;
	eotFont->FontDataSize = fontSize;
	eotFont->EOTSize += eotFont->FontDataSize;

	nLen = eotFont->EOTSize;	// EOT Size

	//test CODE
	if (false)
	{
		FILE* outFile;
		fopen_s(&outFile, "e:/font1.fntdata", "wb");
		
		unsigned char*  eotHeadData = (unsigned char*)BrCalloc(eotFont->EOTSize - eotFont->FontDataSize, BrSizeOf(unsigned char));

		if (eotHeadData)
		{
			BrINT wrPos = 0;

			wrPos += LE_2_Chars(eotHeadData + wrPos, eotFont->EOTSize);
			wrPos += LE_2_Chars(eotHeadData + wrPos, eotFont->FontDataSize);
			wrPos += LE_2_Chars(eotHeadData + wrPos, eotFont->Version);
			wrPos += LE_2_Chars(eotHeadData + wrPos, eotFont->Flags);
			wrPos += LE_2_Chars(eotHeadData + wrPos, eotFont->FontPANOSE, 10);
			wrPos += LE_2_Chars(eotHeadData + wrPos, eotFont->Charset);
			wrPos += LE_2_Chars(eotHeadData + wrPos, eotFont->Italic);

			wrPos += LE_2_Chars(eotHeadData + wrPos, eotFont->Weight);
			wrPos += LE_2_Chars(eotHeadData + wrPos, eotFont->fsType);
			wrPos += LE_2_Chars(eotHeadData + wrPos, eotFont->MagicNumber);

			wrPos += LE_2_Chars(eotHeadData + wrPos, eotFont->UnicodeRange1);
			wrPos += LE_2_Chars(eotHeadData + wrPos, eotFont->UnicodeRange2);
			wrPos += LE_2_Chars(eotHeadData + wrPos, eotFont->UnicodeRange3);
			wrPos += LE_2_Chars(eotHeadData + wrPos, eotFont->UnicodeRange4);

			wrPos += LE_2_Chars(eotHeadData + wrPos, eotFont->CodePageRange1);
			wrPos += LE_2_Chars(eotHeadData + wrPos, eotFont->CodePageRange2);

			wrPos += LE_2_Chars(eotHeadData + wrPos, eotFont->CheckSumAdjustment);

			wrPos += LE_2_Chars(eotHeadData + wrPos, eotFont->Reserved1);
			wrPos += LE_2_Chars(eotHeadData + wrPos, eotFont->Reserved2);
			wrPos += LE_2_Chars(eotHeadData + wrPos, eotFont->Reserved3);
			wrPos += LE_2_Chars(eotHeadData + wrPos, eotFont->Reserved4);

			wrPos += LE_2_Chars(eotHeadData + wrPos, eotFont->Padding1);
			wrPos += LE_2_Chars(eotHeadData + wrPos, eotFont->FamilyNameSize);
			wrPos += LE_2_Chars(eotHeadData + wrPos, eotFont->FamilyName, eotFont->FamilyNameSize);

			wrPos += LE_2_Chars(eotHeadData + wrPos, eotFont->Padding2);
			wrPos += LE_2_Chars(eotHeadData + wrPos, eotFont->StyleNameSize);
			wrPos += LE_2_Chars(eotHeadData + wrPos, eotFont->StyleName, eotFont->StyleNameSize);

			wrPos += LE_2_Chars(eotHeadData + wrPos, eotFont->Padding3);
			wrPos += LE_2_Chars(eotHeadData + wrPos, eotFont->VersionNameSize);
			wrPos += LE_2_Chars(eotHeadData + wrPos, eotFont->VersionName, eotFont->VersionNameSize);

			wrPos += LE_2_Chars(eotHeadData + wrPos, eotFont->Padding4);
			wrPos += LE_2_Chars(eotHeadData + wrPos, eotFont->FullNameSize);
			wrPos += LE_2_Chars(eotHeadData + wrPos, eotFont->FullName, eotFont->FullNameSize);

			fwrite(eotHeadData, sizeof(unsigned char), wrPos, outFile);

			fwrite(fontData, sizeof(unsigned char), fontSize, outFile);
			fclose(outFile);

			BR_SAFE_FREE(eotHeadData);
		}
	}

	BR_SAFE_FREE(eotFont->FamilyName);
	BR_SAFE_FREE(eotFont->StyleName);
	BR_SAFE_FREE(eotFont->VersionName);
	BR_SAFE_FREE(eotFont->FullName);

	BR_SAFE_FREE(eotFont);
	BR_SAFE_FREE(fontData);

#endif
	return NULL;
}

void BoraFont::SetEmbeddedFontData(const BrUCHAR* pData, BrINT nLen, BrCHAR* fontKey, BrINT& error)
{
#ifdef USE_COMMON_INTERFACE
	FT_Face pFace = BrNULL;
	BrUCHAR *getFont = NULL;
	unsigned int getFontSize = 0;
	BrBOOL bResult = BrFALSE;
	PO_Face fontFace = BrNULL;

	if (nLen <= 0)
		return;

	//maybe odttf
	if(fontKey != NULL && pData != NULL && nLen >= 32)
	{
		BrCHAR* keyPtr = fontKey;
		unsigned char buf[33];
		unsigned char key[16];
		int i;

		for (i = 0; i < 32 && *keyPtr; keyPtr++)
		{
			if (IsXDigit(*keyPtr))
				buf[i++] = *keyPtr;
		}
		buf[i] = 0;

		for (i = 0; i < 16; i++)
			key[i] = unhex(buf[i*2+0]) * 16 + unhex(buf[i*2+1]);

		getFont = (BrUCHAR*)calloc(nLen, sizeof(BrUCHAR));
		if (getFont)
		{
			memcpy(getFont, pData, nLen);
			getFontSize = nLen;

			for (i = 0; i < 16; i++)
			{
				getFont[i] ^= key[15 - i];
				getFont[i + 16] ^= key[15 - i];
			}
			bResult = addFontMemory((void*)getFont, getFontSize, 0, pFace, BrTRUE);
		}
	}

	if(!bResult && pData != NULL)
	{
		const unsigned int* sizeCheck = (const unsigned int*)pData;
		const unsigned short* typeCheck = (const unsigned short*)pData;

		//eot Font Magic Number
		if(typeCheck[17] == 0x504c && sizeCheck[0] == nLen)
		{
			struct EOTMetadata out;
			enum EOTError result;

#if 0	//test code
			if (false)
			{
				FILE* outFile;
				fopen_s(&outFile, "d:/outfile.ttf", "wb");
				result = EOT2ttf_file(pData, nLen, &out, outFile);
				fclose(outFile);
			}
#endif
			result = EOT2ttf_buffer(pData, nLen, &out, &getFont,&getFontSize);

			bResult = addFontMemory((void*)getFont, getFontSize, 0, pFace, BrTRUE);

#if 0	//test code
			BrINT testnLen; 
			BrINT testerror;
			GetEmbeddedFontData(testnLen, testerror);
#endif

			EOTfreeMetadata(&out);
			//free(getFont);
		}
	}

	if(bResult)
	{
		fontFace = (PO_Face)PoSysCalloc(1, sizeof(PO_FaceRec_));

		fontFace->nFontListIndex = -1;
		fontFace->nPrimaryCharmapIdx = 0;
		if (pFace->family_name)
			fontFace->family_name_UTF8 = get_family_name_utf8(pFace, &fontFace->family_name_Unicode);
		else
			fontFace->family_name_UTF8 = BrNULL;
		fontFace->moduleName = BrNULL;
		fontFace->ft_face = pFace;

		regFontDataPool(getFont, getFontSize, fontFace);

		addInternalFontData(getFont);
		int nIndex = addInternalFontFace(fontFace);
		int InternalFontFamilyCnt = m_InternalFontFamilyList.size();

		eFontStyleIndex changeIdx = getFontListIndexStyleValue(fontFace->ft_face->style_name);

		LPBrFontStyleIdxNode pNode = (LPBrFontStyleIdxNode)PoSysMalloc(BrSizeOf(BrFontStyleIdxNode));
		pNode->pPrev = pNode->pNext = BrNULL;
		pNode->nGlyphCount = fontFace->ft_face->num_glyphs;
		pNode->nFontIndex = nIndex;
		pNode->eStyle = changeIdx;
		pNode->nPrio = 5;

		LPBrFontStyleIdxNode lastNode = BrNULL;
		for(nIndex = 0; nIndex < InternalFontFamilyCnt; nIndex++)
		{
			LPBrInternalFontListStruct pFamily = m_InternalFontFamilyList.at(nIndex);
			if( !FontWcsCmp(pFamily->pFamily_name, fontFace->family_name_Unicode) )
			{
				lastNode = pFamily->nFontIndices;
				while(lastNode->pNext)
				{
					lastNode = lastNode->pNext;
				}
				break;
			}
		}
		if(lastNode)
		{
			lastNode->pNext = pNode;
			pNode->pPrev = lastNode;
		}
		else
		{
			LPBrInternalFontListStruct pFamily = (LPBrInternalFontListStruct)PoSysMalloc(BrSizeOf(BrInternalFontListStruct));
			memset(pFamily->pFamily_name,0,sizeof(pFamily->pFamily_name));
			if(fontFace->family_name_Unicode != BrNULL)
				CUtil::WcsCpy(pFamily->pFamily_name, fontFace->family_name_Unicode);
			pFamily->nFontIndices = pNode;
			m_InternalFontFamilyList.add(pFamily);
			nIndex = m_InternalFontFamilyList.size()-1;
		}

		setInternalFontName(pFace, nIndex);
	}
	else
	{
		if(getFont != BrNULL)
			free(getFont);

		if(pData != NULL)
			BRTHREAD_ASSERT(0);
	}
#endif//ifdef USE_COMMON_INTERFACE
}

BrUSHORT BoraFont::GetPermission(const BrUCHAR* pData, BrINT nLen)
{
#ifdef USE_COMMON_INTERFACE
	BrUCHAR *getFont = NULL;
	unsigned int getFontSize = 0;

	if(pData != NULL)
	{
		struct EOTMetadata out;
		enum EOTError result;
		result = EOT2ttf_buffer(pData, nLen, &out, &getFont,&getFontSize);

		BrUSHORT nPermissions = out.permissions;
		EOTfreeMetadata(&out);
		free(getFont);
		return nPermissions;
	}

	return 0;
#endif//ifdef USE_COMMON_INTERFACE
	return 0;
}

BrBOOL BoraFont::ReleaseEmbeddedFontData()
{
	for(int i = 0; i < m_InternalFontFace.size(); i++)
	{
		FT_Done_Face( m_InternalFontFace.at(i)->ft_face );
		PoSysFree(m_InternalFontFace.at(i));
	}
	m_InternalFontFace.removeAll();
	for(int i = 0; i < m_InternalFontData.size(); i++)
		free(m_InternalFontData.at(i));
	m_InternalFontData.removeAll();

	for(int i = 0; i < m_InternalFontFamilyList.size(); i++)
	{
		LPBrInternalFontListStruct pFamily = m_InternalFontFamilyList.at(i);
		if(pFamily->nFontIndices)
		{
			LPBrFontStyleIdxNode node = pFamily->nFontIndices;
			LPBrFontStyleIdxNode nextNode = BrNULL;
			while(node)
			{
				nextNode = node->pNext;
				PoSysFree(node);
				node = nextNode;
			}
		}
		PoSysFree(pFamily);
	}
	m_InternalFontFamilyList.removeAll();
	return BrTRUE;
}

BrBOOL BoraFont::CheckNotExistFontName(BrWORD* pFontName)
{
	BrBOOL bRet = BrFALSE;

	BrINT nNotExistFontNameSize = m_aNotExistFontName.size();
	if (!m_aNotExistFontName.isNull() && nNotExistFontNameSize > 0)
	{
		for (int i = nNotExistFontNameSize - 1; i >= 0; i--)
		{
			if (!FontWcsCmp(pFontName, m_aNotExistFontName.at(i)))
			{
				bRet = BrTRUE;
				break;
			}
		}
	}

	return bRet;
}

BrBOOL BoraFont::getEmbedBitmapGlyphSize(FT_Face fontFace, FT_UInt& width, FT_UInt& height)
{
	if(IsColorEmojiFont(fontFace))
		width = height = EMBEDDED_BITMAP_SIZE;
	else if(fontFace->family_name && fontFace->family_name[0] == 0x41 && !FontStrCmp(fontFace->family_name, "Apple Color Emoji") )
		width = height = EMBEDDED_BITMAP_SIZE_IOS;
	else
	{
		width = height = 0;
		return BrFALSE;
	}
	
	if(fontFace->num_fixed_sizes > 0)
	{
		width = fontFace->available_sizes[fontFace->num_fixed_sizes-1].x_ppem/64 > 0?fontFace->available_sizes[fontFace->num_fixed_sizes-1].x_ppem/64:width;
		height = fontFace->available_sizes[fontFace->num_fixed_sizes-1].y_ppem/64 > 0?fontFace->available_sizes[fontFace->num_fixed_sizes-1].y_ppem/64:height;
	}

	return BrTRUE;
}

BrCHAR* BoraFont::get_family_name_utf8(FT_Face fontFace, BrWORD** fontName_unicode)
{
	BrCHAR* family_name_utf8 = BrNULL;
	TT_OS2* os2_table = (TT_OS2*)FT_Get_Sfnt_Table(fontFace, ft_sfnt_os2);
	BrWORD* fontName = BrNULL;
	if (os2_table)
	{
		if (os2_table->version != 0xFFFFU && os2_table->fsSelection & 256)
		{
			fontName = face_find_name(fontFace, TT_NAME_ID_FONT_FAMILY);
		}
		else
		{
			fontName = face_find_name(fontFace, TT_NAME_ID_WWS_FAMILY);
			
			if (!fontName)
				fontName = face_find_name(fontFace, TT_NAME_ID_FONT_FAMILY);
		}
	}
	else
	{
		fontName = face_find_name(fontFace, TT_NAME_ID_FONT_FAMILY);
	}

	if (fontName)
	{
		int nLength = BrMIN(MAX_FONT_LENGTH - 1, BrWcsLen(fontName) * BrSizeOf(BrCHAR) * 3);
		family_name_utf8 = (BrCHAR*)PoSysCalloc(nLength + 1, BrSizeOf(BrCHAR));

		// Unicode -> UTF-8
		BrWideCharToMultiByte(CP_UTF8, fontName, BrWcsLen(fontName), family_name_utf8, nLength + 1);

		*fontName_unicode = fontName;
	}


	if (!family_name_utf8)
	{
		family_name_utf8 = convertMultiToUTF8(fontFace->family_name, CP_ACP);
		if(*fontName_unicode == BrNULL)
			*fontName_unicode = convertMultiToUCS2(fontFace->family_name, CP_ACP);
	}
		

	return family_name_utf8;
}

/*기존 sfobjs tt_face_get_name 와 동일*/
BrLPWORD BoraFont::face_find_name(FT_Face fontFace, FT_UShort nameid)
{
	FT_UInt tmCount = FT_Get_Sfnt_Name_Count(fontFace);
	FT_Int  found_apple = -1;
	FT_Int  found_apple_roman = -1;
	FT_Int  found_apple_english = -1;
	FT_Int  found_win = -1;
	FT_Int  found_unicode = -1;

	FT_Bool  is_english = 0;

	BrLPWORD fontName = BrNULL;
	
	for (int n = 0; n < tmCount; n++)
	{
		FT_SfntName tmName;
		FT_Get_Sfnt_Name(fontFace, n, &tmName);

		if (tmName.name_id == nameid && tmName.string_len > 0)
		{
			switch (tmName.platform_id)
			{
			case TT_PLATFORM_APPLE_UNICODE:
			case TT_PLATFORM_ISO:
				/* there is `languageID' to check there.  We should use this */
				/* field only as a last solution when nothing else is        */
				/* available.                                                */
				/*                                                           */
				found_unicode = n;
				break;

			case TT_PLATFORM_MACINTOSH:
				/* This is a bit special because some fonts will use either    */
				/* an English language id, or a Roman encoding id, to indicate */
				/* the English version of its font name.                       */
				/*                                                             */
				if (tmName.language_id == TT_MAC_LANGID_ENGLISH)
					found_apple_english = n;
				else if (tmName.encoding_id == TT_MAC_ID_ROMAN)
					found_apple_roman = n;
				break;

			case TT_PLATFORM_MICROSOFT:
				/* we only take a non-English name when there is nothing */
				/* else available in the font                            */
				/*                                                       */
				if (found_win == -1 || (tmName.language_id & 0x3FF) == 0x009)
				{
					switch (tmName.encoding_id)
					{
					case TT_MS_ID_SYMBOL_CS:
					case TT_MS_ID_UNICODE_CS:
					case TT_MS_ID_UCS_4:
					case TT_MS_ID_GB2312:
					case TT_MS_ID_WANSUNG:
						is_english = FT_BOOL((tmName.language_id & 0x3FF) == 0x009);
						found_win = n;
						break;

					default:
						;
					}
				}
				break;

			default:
				;
			}
		}
	}

	found_apple = found_apple_roman;
	if (found_apple_english >= 0)
		found_apple = found_apple_english;

	FT_SfntName sfntName;
	if (found_win >= 0 && !(found_apple >= 0 && !is_english))
	{
		FT_Get_Sfnt_Name(fontFace, found_win, &sfntName);
	}
	else if (found_apple >= 0)
	{
		FT_Get_Sfnt_Name(fontFace, found_apple, &sfntName);
	}
	else if (found_unicode >= 0)
	{
		FT_Get_Sfnt_Name(fontFace, found_unicode, &sfntName);
	}
	else
	{
		return fontName;
	}

	fontName = getSfntName(sfntName);

	return fontName;
}

BrLPWORD BoraFont::getSfntName(FT_SfntName sfntName)
{
	BrLPWORD fontName = BrNULL;
	if (sfntName.platform_id == TT_PLATFORM_MICROSOFT)
	{
		switch (sfntName.encoding_id)
		{
			//swap string
		case TT_MS_ID_UNICODE_CS:
		case TT_MS_ID_UCS_4:
		case TT_MS_ID_SYMBOL_CS:
		{
			int nLength = BrMIN(MAX_FONT_LENGTH, sfntName.string_len);
			if (nLength > 0)
			{
				int nLen = nLength;
				//multibyte(CP-949 등)
				BrWORD* wFontName = getWCharBuffer();
				convertFontFaceName(sfntName.string_len, sfntName.string, wFontName, nLength);

				nLen = BrWcsLen(wFontName);

				nLength = BrMIN(MAX_FONT_LENGTH, nLen + 1);
				fontName = (BrLPWORD)PoSysCalloc(nLength, BrSizeOf(BrWORD));
				CUtil::WcsCpy(fontName, wFontName);
			}
		}
		break;
		//convert locale string
		case TT_MS_ID_SJIS:
		case TT_MS_ID_GB2312:
		case TT_MS_ID_BIG_5:
		case TT_MS_ID_WANSUNG:
		{
			int  nLength = BrMIN(MAX_FONT_LENGTH - 1, sfntName.string_len);

			if (nLength > 0)
			{
				//multibyte(CP-949 등)
				BrCHAR* mFontName = getCharBuffer();

				BrINT nLen = 0;

				for (int k = 0; k < nLength; k++)
				{
					if (sfntName.string[k] != 0)
					{
						mFontName[nLen++] = sfntName.string[k];
					}
				}
				int localeCodePage = CP_ACP;
				int nLocale = BR_LOCALE_US_ENGLISH;

				{
					if (sfntName.encoding_id == TT_MS_ID_SJIS)
						nLocale = BR_LOCALE_JAPANESE;
					else if (sfntName.encoding_id == TT_MS_ID_GB2312)
						nLocale = BR_LOCALE_S_CHINESE;
					else if (sfntName.encoding_id == TT_MS_ID_BIG_5)
						nLocale = BR_LOCALE_T_CHINESE_TW;
					else if (sfntName.encoding_id == TT_MS_ID_WANSUNG)
						nLocale = BR_LOCALE_KOREAN;
				}

				localeCodePage = getLocaleCodePage(nLocale);

				fontName = convertMultiToUCS2(mFontName, localeCodePage);
			}
		}
		break;
		}
	}
	else if (sfntName.platform_id == TT_PLATFORM_MACINTOSH)
	{
		int  nLength = BrMIN(MAX_FONT_LENGTH - 1, sfntName.string_len);

		if (nLength > 0)
		{
			//multibyte(CP-949 등)
			BrCHAR* mFontName = getCharBuffer();

			BrINT nLen = 0;

			for (int k = 0; k < nLength; k++)
			{
				if (sfntName.string[k] != 0)
				{
					mFontName[nLen++] = sfntName.string[k];
				}
			}

			int localeCodePage = CP_ACP;
			int nLocale = BR_LOCALE_US_ENGLISH;
			{
				if (sfntName.language_id == TT_MAC_LANGID_JAPANESE)
					nLocale = BR_LOCALE_JAPANESE;
				else if (sfntName.language_id == TT_MAC_LANGID_CHINESE_SIMPLIFIED)
					nLocale = BR_LOCALE_S_CHINESE;
				else if (sfntName.language_id == TT_MAC_LANGID_CHINESE_TRADITIONAL)
					nLocale = BR_LOCALE_T_CHINESE_TW;
				else if (sfntName.language_id == TT_MAC_LANGID_KOREAN)
					nLocale = BR_LOCALE_KOREAN;
			}

			localeCodePage = getLocaleCodePage(nLocale);
			fontName = convertMultiToUCS2(mFontName, localeCodePage);
		}
	}

	return fontName;
}

BrLPWORD BoraFont::convertSfntFontName(FT_Face fontFace, FT_Int nameIndex, FT_String* mac_style_name)
{
#ifdef USE_COMMON_INTERFACE
	BrLPWORD fontName = BrNULL;
	FT_SfntName tmName;
	FT_Get_Sfnt_Name( fontFace, nameIndex, &tmName );

	//[18.01.25][sglee1206][HEJ-1706] ODT편집기 전용 폰트 신명조.ttf의 경우 Postscript Font Name이 HY신명조와 동일함
	//따라서 해당 폰트가 설치된 PC의 경우 HY신명조와 충돌나므로 Postscript Font Name은 처리하지 않도록 수정
	//해당 문제는 발생하지 않도록 Font Cache부분 고도화할 필요가 있음
		//TT_PLATFORM_MACINTOSH 문제있으므로 일단 제거
	if (!((tmName.platform_id == TT_PLATFORM_MICROSOFT 
#if  defined(USE_FOR_IOS) || defined(MAC_FONT_SUPPORT)
		|| tmName.platform_id == TT_PLATFORM_MACINTOSH
#endif
		)
		&& tmName.name_id == TT_NAME_ID_FONT_FAMILY) &&
		tmName.name_id != TT_NAME_ID_FULL_NAME && tmName.name_id != TT_NAME_ID_PS_NAME &&
		tmName.name_id != TT_NAME_ID_MAC_FULL_NAME && tmName.name_id != TT_NAME_ID_WWS_FAMILY)
	{
		return fontName;
	}
#if  defined(USE_FOR_IOS) || defined(MAC_FONT_SUPPORT)
	// 해당케이스의 경우 Skip. 
	else if (BoraFontComm::IsSkipFontName(fontFace->family_name) && tmName.platform_id == TT_PLATFORM_MACINTOSH)
	{
		fontName = getSfntName(tmName);
		return BrNULL;
	}
	else if (BrStrLen(mac_style_name) > 0 && FontStrCmp(mac_style_name, fontFace->style_name) && tmName.platform_id == TT_PLATFORM_MACINTOSH)
	{
		fontName = getSfntName(tmName);
		return BrNULL;
	}
#endif

	fontName = getSfntName(tmName);

	return fontName;
#endif//ifdef USE_COMMON_INTERFACE
	return BrNULL;
}

BrBOOL BoraFont::setInternalFontName(FT_Face fontFace, int nIndex)
{
	FT_UInt tmCount = FT_Get_Sfnt_Name_Count( fontFace );

	FT_String mac_style_name[MAX_FONT_LENGTH] = { 0, };
#ifdef MAC_FONT_SUPPORT	// OS X 말고 iOS에서도 사용해야 할지 검토 필요
	FT_UShort languageMacID = TT_MAC_LANGID_KOREAN;
	FT_UShort encodingMacID = TT_MAC_ID_KOREAN;
	FT_UShort platformMacID = TT_PLATFORM_MACINTOSH;

	int nLocale = PoGetLocale();
	int localeCodePage = CP_ACP;
	const FT_UShort* retLocaleID = getLocaleIDList(nLocale);

	//[15.12.16][sglee1206] 현재는 아래 넷에 대해서만 처리. 추가 요청에 따라 늘리고 궁극적으로는 조건이 필요없어야 함
	if (retLocaleID != BrNULL)
	{
		languageMacID = retLocaleID[5];
		encodingMacID = retLocaleID[6];
		platformMacID = retLocaleID[8];
	}

	for (int j = 0; j < tmCount; j++)
	{
		FT_SfntName tmName;
		FT_Get_Sfnt_Name(fontFace, j, &tmName);
		if (tmName.language_id == languageMacID && tmName.name_id == TT_NAME_ID_FONT_SUBFAMILY && tmName.platform_id == platformMacID
			&& tmName.encoding_id == encodingMacID)
		{
			int  nLength = BrMIN(MAX_FONT_LENGTH, tmName.string_len);
			for (int k = 0; k < nLength; k++)
			{
				mac_style_name[k] = tmName.string[k];
			}
			break;
		}
	}
#endif

	for( int j = 0; j < tmCount; j++ )
	{
		BrWORD* fontName = BrNULL;	
		fontName = convertSfntFontName(fontFace, j, mac_style_name);
		if ( fontName )
		{
			m_InternalFontNameList->Insert(fontName,nIndex);
		}

	}

	return BrFALSE;
}

BrINT BoraFont::findInternalFontIndex(BrINT familyIndex, BrBYTE fontStyle)
{
	BrINT nIdx = -1;
	LPBrInternalFontListStruct pFamily = m_InternalFontFamilyList.at(familyIndex);
	if(pFamily->nFontIndices->pNext == BrNULL)
	{
		nIdx = pFamily->nFontIndices->nFontIndex;
	}
	else
	{
		LPBrFontStyleIdxNode pNode = pFamily->nFontIndices;
		if(pNode->eStyle == 0)
			nIdx = pFamily->nFontIndices->nFontIndex;
		else
			nIdx = -1;

		for(;pNode; pNode = pNode->pNext)
		{
			if(pNode->eStyle == fontStyle)
			{
				nIdx = pNode->nFontIndex;
				break;
			}
			else if(HAS_FONT_FLAG(fontStyle,FT_STYLE_FLAG_BOLD) && pNode->eStyle == eStyleBold)
			{
				nIdx = pNode->nFontIndex;
			}
		}
	}
	return nIdx;
}

BrBOOL BoraFont::AddLocaleIndexHash(BrBYTE fontStyle)
{
	if(m_pLocaleIndexHash == BrNULL)
		m_pLocaleIndexHash = new Font_LocaleIDXHash(m_pPublicMem);

	if(m_pLocaleIndexHash->Lookup_Font_LocaleIDXHash(makeLocaleIndexHashKey(fontStyle)) == BrNULL)
	{
		//add
		m_pLocaleIndexHash->Add_Font_LocaleIDXHash(m_LocaleIndexHashKey, m_LocaleFontFace, m_nLocaleFontIndex);
		return BrTRUE;
	}
	else
		return BrFALSE;
}

void BoraFont::ReleaseLocaleIndexHash()
{
	if(m_pLocaleIndexHash)
	{
		BR_SAFE_DELETE(m_pLocaleIndexHash);
	}
}

BrCHAR* BoraFont::makeLocaleIndexHashKey(BrBYTE fontStyle)
{
	BrINT32 nIndex = 0;
	BrINT fontGlyphIndex = m_pBoraMultiLang->GetFontGlyphIndex();

	m_LocaleIndexHashKey[nIndex++] = (BrCHAR)(HAS_FONT_FLAG(fontStyle,FT_STYLE_FLAG_BOLD));
	m_LocaleIndexHashKey[nIndex++] = (BrCHAR)(HAS_FONT_FLAG(fontStyle,FT_STYLE_FLAG_ITALIC));
	m_LocaleIndexHashKey[nIndex++] = (BrCHAR)(fontGlyphIndex & 0xFF);
	m_LocaleIndexHashKey[nIndex++] = (BrCHAR)((fontGlyphIndex >> 8) & 0xFF);
	m_LocaleIndexHashKey[nIndex++] = (BrCHAR)((fontGlyphIndex >> 16) & 0xFF);
	m_LocaleIndexHashKey[nIndex++] = (BrCHAR)((fontGlyphIndex >> 24) & 0xFF);

	memcpy(&m_LocaleIndexHashKey[nIndex],m_pFontName, MAX_FONT_LENGTH * sizeof(BrUSHORT));

	return m_LocaleIndexHashKey;
}

int BoraFont::getLocaleCodePage(int nLocale)
{
	int nCodePage = CP_ACP;

	switch(nLocale)
	{
	case BR_LOCALE_KOREAN:
		nCodePage = CP_KSC5601;	// 949
		break;
	case BR_LOCALE_S_CHINESE:
		nCodePage = 936;
		break;
	case BR_LOCALE_T_CHINESE_TW:
		nCodePage = CP_BIG5;		// 950
		break;
	case BR_LOCALE_JAPANESE:
		nCodePage = CP_SHIFTJIS;	// 932
		break;
	default:
		nCodePage = CP_ACP;
		break;
	}

	return nCodePage;
}

BrINT BoraFont::loadPurchaseFont()
{
#if defined( SUPPORT_ADD_FONT )
	BrINT nFontNameIndex = -1;
	BrINT nRuntimeLoadFontIndex = -1;
	BrWORD tempName[MAX_FONT_LENGTH] = {0,};

	BrINT nLen = 0;

	for(int i =0; sPurchaseFontHName[i] && i < ePurchaseFontMax; i++)
	{
		if(BrWcsLen(tempName) > 0 && !FontWcsCmp(tempName,sPurchaseFontHName[i]))
		{
			m_nLoadedPurchaseFontCnt++;
			m_bLoadedPurchaseFont[i] = BrTRUE;
			continue;
		}

		if(m_bLoadedPurchaseFont[i] == BrFALSE)
		{
			nFontNameIndex = getFontNameListIndex(sPurchaseFontHName[i]);
			if(nFontNameIndex >= 0)
			{
				nRuntimeLoadFontIndex = m_pFontNameList->GetFontListIndex(nFontNameIndex);
				BrINT nFindFontIndex = loadSystemFontFile((BrWORD*)sPurchaseFontName[i][0]);
				if(sPurchaseFontName[i][1] != BrNULL && nFindFontIndex < 0)
					nFindFontIndex = loadSystemFontFile((BrWORD*)sPurchaseFontName[i][1]);
				if(nFindFontIndex < 0)
					nFindFontIndex = loadSystemFontFile((BrWORD*)sPurchaseFontHName[i]);
				if(nFindFontIndex >= 0)
				{
					m_nLoadedPurchaseFontCnt++;
					m_bLoadedPurchaseFont[i] = BrTRUE;
					memset(tempName,0,sizeof(BrWORD) * MAX_FONT_LENGTH);
					CUtil::WcsNcpy(tempName, sPurchaseFontHName[i], BrWcsLen(sPurchaseFontHName[i]));
				}
			}
		}
	}
	return m_nLoadedPurchaseFontCnt;
#endif//defined( SUPPORT_ADD_FONT )
	return 0;
}

const BrWORD* BoraFont::GetMathFontName()
{
#ifdef USE_PC_VERSION_FONT
	if(m_pSystemMathFontName != BrNULL)
		return m_pSystemMathFontName;
	else
#endif
		return DEFAULT_MATH_FONT_NAME;
}

BrCHAR* BoraFont::GetBidiMemBlock(const BrINT32 nSize)
{
	if (m_pBidiMemBlock == BrNULL)
	{
		m_pBidiMemBlock = (BrCHAR*)PoSysMalloc(nSize);
		if (m_pBidiMemBlock == BrNULL)
		{
			m_nBidiMemBlockLen = 0;
			return BrNULL;
		}
		m_nBidiMemBlockLen = nSize;
	}
	else if (nSize > m_nBidiMemBlockLen)
	{
		PoSysFree(m_pBidiMemBlock);
		m_pBidiMemBlock = (BrCHAR*)PoSysMalloc(nSize);
		if (m_pBidiMemBlock == BrNULL)
		{
			m_nBidiMemBlockLen = 0;
			return BrNULL;
		}
		m_nBidiMemBlockLen = nSize;
	}

	if (m_pBidiMemBlock)
		memset(m_pBidiMemBlock, 0, m_nBidiMemBlockLen);

	return m_pBidiMemBlock;
}

BrBOOL BoraFont::isAlterFont(const BrWORD* fontName, const BrWORD* fontFaceName)
{
	BrWORD AlterFontName[MAX_FONT_LENGTH] = {0,};
	if(fontFaceName == BrNULL || fontName == BrNULL)
		return BrFALSE;

	//Same Font
	if(!FontWcsCmp(fontName, fontFaceName))
		return BrTRUE;

	BoraFontComm::GetAlterFontName(fontName,AlterFontName, MAX_FONT_LENGTH);
	if(FontWcsCmp(fontName,AlterFontName))	//MSAlterFontName, fontName가 다른경우
	{
		//Alter Font
		if(!FontWcsCmp(fontFaceName,AlterFontName))
			return BrTRUE;
		else
			return BrFALSE;
	}

	//[16.02.16][sglee1206] 동작 일부 변경으로 인해 true -> false
	// 대체할 폰트가 정의되어 있지 않으면 true 리턴 
	return BrFALSE;
}

BrBOOL BoraFont::existAlterFont(const BrWORD* fontName)
{
	if(fontName == BrNULL)
		return BrFALSE;

	BrWORD AlterFontName[MAX_FONT_LENGTH] = {0,};
	BoraFontComm::GetAlterFontName(fontName,AlterFontName, MAX_FONT_LENGTH);
	if(FontWcsCmp(fontName,AlterFontName))
		return BrTRUE;
	else
		return BrFALSE;
}

eFontStyleIndex BoraFont::getFontListIndexStyleValue(FT_String *styleName)
{
	eFontStyleIndex nRet = eStyleNone;
	if(styleName != BrNULL)
	{
		if(strstr(styleName,"Regular") || strstr(styleName, "Normal"))
			nRet = eStyleRegular;
		else if(strstr(styleName,"Bold") || strstr(styleName, "bold"))
		{
			if(strstr(styleName,"Italic") || strstr(styleName, "Oblique"))
				nRet = eStyleBoldItalic;
			else
				nRet = eStyleBold;
		}
		else if(strstr(styleName, "Italic") || strstr(styleName,"Oblique"))
			nRet = eStyleItalic;
		else
			nRet = eStyleExtra1;
	}

	return nRet;
}

FT_Int BoraFont::getFontFlag( BrUSHORT* strFontName, BrUINT16 nLen, BrBYTE fontStyle, BrBOOL& bToUpper, BrBOOL bReg)
{
	FT_Int nFontFlag = m_nFontFlag;
	BrBOOL bRealEMFont = BrFALSE;
	BrINT nBaseMapFontIndex = -1;
	bToUpper = BrFALSE;

	nFontFlag = BoraFontComm::GetFontFlag(strFontName, nLen, fontStyle, m_bLoadedPurchaseFont, bRealEMFont, nBaseMapFontIndex, bToUpper);

	if(nFontFlag < 0)
		nFontFlag = m_nFontFlag;

	eBEFFONT_TABLE_TYPE efIndex = findEmbFontIndex(nFontFlag);

	if (bRealEMFont)
	{
		// 내장폰트를 사용하는 것이라고 하나 실제 존재하지 않는 경우에는 False 처리함
		if (efIndex == eEF_NoneFont)
			bRealEMFont = BrFALSE;
		else if (efIndex > eEF_NoneFont && efIndex < eEF_MaxFontType && !m_bUseEFFace[efIndex])
			bRealEMFont = BrFALSE;
	}

	m_nFontFlag = nFontFlag;
	m_bRealFont = bRealEMFont;	// 세팅된 폰트에 대응하는 내장폰트 있을 시 true
	
	if (!bRealEMFont && isExistFontface(strFontName, nLen, fontStyle))
	{
		nBaseMapFontIndex = -1;
		m_bRealFont = BrTRUE;	// 폰트가 존재
		if(bReg)
			m_EFIndex = findEmbFontIndex(eNoneFont);
	}

	if(bReg)
	{
		m_nBaseMapFontIndex = nBaseMapFontIndex;

		if(m_nBaseMapFontIndex != -1)
			m_EFIndex = findEmbFontIndex(m_nBaseMapFontIndex);
		else if(bRealEMFont)
			m_EFIndex = findEmbFontIndex(nFontFlag);
		else
			m_EFIndex = findEmbFontIndex(eNoneFont);
			
	}

	return nFontFlag;
}

void BoraFont::DumpFontNameTemp(BrWORD* pFontTemp)
{
	changeFontName(pFontTemp, m_pFontName);
	changeFontName(m_pFontName, BrNULL);

	m_nFontNameIndexTemp = m_nCurFontNameIndex;
	m_nCurFontNameIndex = -1;
}

void BoraFont::RestoreFontTempName(BrWORD* pFontTemp)
{
	changeFontName(m_pFontName, pFontTemp);
	m_nCurFontNameIndex = m_nFontNameIndexTemp;
	m_nFontNameIndexTemp = -1;
}

void BoraFont::changeFontName(BrWORD* pOrg, BrWORD* pChg)
{
	//alloc된 경우에만 사용
	if (pOrg)
	{
		//""가 아닌 경우만 memset
		if (FontWcsCmp(pOrg, (const unsigned short*)u""))
			memset(pOrg, 0, m_nFontNameLength *sizeof(BrWORD));
		//pChg에 내용이 있는 경우만 복사
		if (pChg && FontWcsCmp(pChg, (const unsigned short*)u""))
			CUtil::WcsCpy(pOrg, pChg);
	}
	else
		BRTHREAD_ASSERT(0);
}

#if defined( USE_PANOSE_INFO )

/*
*	@author 	sglee1206 
*	@date  		2019.04.20
*	@return  	word* : altPanoseFontName
*	@brief  	저장된 파노스 정보중에 대체 폰트가 있는지 확인 후 해당 대체폰트 리턴
*/
BrWORD* BoraFont::existPanoseAlterFont(BrBYTE fontStyle)
{
	BrWORD* altPanoseFontName = BrNULL;
	if (m_aLoadedPanoseFont.size() > 0)
	{
		for (int i = 0; i < m_aLoadedPanoseFont.size(); i++)
		{
			LPBrPanoseInfoStruct pFontInfo = m_aLoadedPanoseFont.at(i);
			if (!FontWcsCmp(m_pFontName, pFontInfo->pFont_name))
			{
				altPanoseFontName = (BrWORD*)PoSysCalloc(MAX_FONT_LENGTH, BrSizeOf(BrWORD));

				if (!FontWcsCmp(pFontInfo->pAltFont_name, (const unsigned short*)u""))
					CUtil::WcsCpy(altPanoseFontName, pFontInfo->pBestMatchingFont_name);
				else
					CUtil::WcsCpy(altPanoseFontName, pFontInfo->pAltFont_name);

				//유사 폰트 로드
				//if (getFontNameListIndex((const char*)altPanoseFontName) == -1
				if (!isExistFontface(altPanoseFontName, BrWcsLen(altPanoseFontName), fontStyle))
				{
					loadSystemFontFile(altPanoseFontName);
				}

				m_nCurFontNameIndex = setCurFontName(altPanoseFontName);

				return altPanoseFontName;
			}
		}
	}

	if (altPanoseFontName)
	{
		PoSysFree(altPanoseFontName);
		altPanoseFontName = BrNULL;
	}

	return altPanoseFontName;
}

BrBOOL BoraFont::isLoadedPanoseFont(BrWORD* fontName)
{
	if (m_aLoadedPanoseFont.size() > 0)
	{
		for (int i = 0; i < m_aLoadedPanoseFont.size(); i++)
		{
			LPBrPanoseInfoStruct pFontInfo = m_aLoadedPanoseFont.at(i);
			if (!FontWcsCmp(fontName, pFontInfo->pFont_name))
				return BrTRUE;
		}
	}

	return BrFALSE;
}

/*
*	@author 	minseob
*	@date  		2018.05.09
*	@param		unsigned char* panose : panose info
*	@param		unsigned char* findPanose : compare panose info
*	@return  	BrBOOL : success(true), fail(false)
*	@brief  	동일한 Panose 정보인지 확인
*/
BrBOOL BoraFont::isSamePanoseInfo(unsigned char* panose, unsigned char* findPanose)
{
	for(int n = 0; n < 10; n++)
	{
		if( panose[n] != findPanose[n] )
			return BrFALSE;
	}

	return BrTRUE;
}

/*
*	@author 	minseob
*	@date  		2018.05.09
*	@param		unsigned char* otherPanose : otherPanose Another Panose instance which is being compared to this.
*	@param		unsigned char* weights : weights 10-element byte array of weights that should be used for each of the elements in the comparison.
*	@return  	BrINT : The weighted difference between the two Panose values.
*	@brief  	panose 값을 계산하여 결과값 반환
*	This constant is documented at http://www.w3.org/Fonts/Panose/pan2.html#StaticDigits
*/
BrINT BoraFont::matchingpanose(unsigned char* otherPanose, unsigned char* weights) 
{
        BrBYTE weightsToUse[10] = {1, 1, 1, 1, 1, 1, 1, 1, 1, 1};

        long matchingrate = 0;
		
		for (int i = 0; i < 10; i++) {
            int weight = weightsToUse[i];

			int submatchingrate = weights[i] - otherPanose[i];
			matchingrate += weight * submatchingrate * submatchingrate;
        }
		
        return matchingrate;
}

/*
*	@author 	minseob
*	@date  		2018.01.11
*	@params  	USHORT  lpToken : 10진수로 변환 할 값
*	@return  	BrINT32 fTmpVal : 변환된 값
*	@brief  	16진수를 10진수 값으로 변환
*/
BrINT32 BoraFont::convertCharHexToInt( USHORT  lpToken)
{
    BrINT32    fTmpVal = 0;
    
    if( lpToken  >= '0' && lpToken <= '9')
    {
        fTmpVal = ( BrINT32)( ( fTmpVal * 16) + ( BrINT32)( lpToken - '0') );
    } 
    else if( lpToken  >= 'A' && lpToken <= 'F')
    {
        fTmpVal = ( BrINT32)( ( fTmpVal * 16) + ( BrINT32)( lpToken - 'A' + 10) );  // k = 'a' + 10
    } 
    else if( lpToken  >= 'a' && lpToken <= 'f')
    {
        fTmpVal = ( BrINT32)( ( fTmpVal * 16) + ( BrINT32)( lpToken - 'a' + 10) );  // k = 'a' + 10
    }  
            
    return  fTmpVal;
}

BrBOOL BoraFont::FindAltFontUsePanose(BrWORD* fontName)
{
	BrWORD family_name[MAX_FONT_LENGTH] = { 0, };
	BrWORD panoseFont_name[MAX_FONT_LENGTH] = { 0, };
	BrWORD bestMatchingFont_name[MAX_FONT_LENGTH] = { 0, };
	BrWORD* name_tmp = BrNULL;
	BrINT bestMatchingFontFaceIndex = 0;
	bool isAlreadyInLoadFont = false;
	BrINT fontFaceIndex = 0;


	if (m_aFontNamePanoseInfo.size() > 0 && m_bFindAltFont == false)
	{
		for (int i = 0; i < m_aFontNamePanoseInfo.size(); i++)
		{
			LPBrFontInfoStruct pFontInfo = m_aFontNamePanoseInfo.at(i);
			if (!FontWcsCmp(fontName, pFontInfo->nFont_name))
			{
				isAlreadyInLoadFont = false;

				//Docx의 경우 필터 정보에 대체폰트이름이 포함된 경우가 있음
				if (BrWcsLen(pFontInfo->nAltFont_name) > 0)
				{
					CUtil::WcsCpy(family_name, pFontInfo->nAltFont_name);

					// 이미 로드된 폰트인지 확인
					FT_Face face = BrNULL;
					for (int loadedInx = 0; loadedInx < m_face_count; loadedInx++)
					{
						name_tmp = BrNULL;

						if (!m_Face[loadedInx] || !m_Face[loadedInx]->ft_face || NULL == m_Face[loadedInx]->ft_face->charmaps)
							loadedInx = m_face_count;
						else
						{
							face = m_Face[loadedInx]->ft_face;
							name_tmp = m_Face[loadedInx]->family_name_Unicode;
						}
							
						if (face && !FontWcsCmp(name_tmp, family_name))
						{
							//BrTrace("m_Face[%d]->family_name %s isAlreadyInLoadFont, pFontInfo->nFont_name : %s", loadedInx, face->family_name, pFontInfo->nFont_name);
							isAlreadyInLoadFont = true;
							bestMatchingFontFaceIndex = loadedInx;
							loadedInx = GetFontFaceCnt();
						}
						else
							isAlreadyInLoadFont = false;
					}

					if (FontWcsCmp(family_name, (const unsigned short*)u"") && isAlreadyInLoadFont == true)
					{
						//폰트명, 유사 폰트, 파노스 정보 저장
						LPBrPanoseInfoStruct pPanoseInfo = (LPBrPanoseInfoStruct)PoSysMalloc(BrSizeOf(BrPanoseInfoStruct));
						memset(pPanoseInfo, 0, BrSizeOf(BrPanoseInfoStruct));

						CUtil::WcsCpy(pPanoseInfo->pFont_name, pFontInfo->nFont_name);
						CUtil::WcsCpy(pPanoseInfo->pAltFont_name, pFontInfo->nAltFont_name);
						pPanoseInfo->nFontFaceIndex = bestMatchingFontFaceIndex;
						//BrTrace("pPanoseInfo->pFont_name %s, pPanoseInfo->pAltFont_name %s", pPanoseInfo->pFont_name, pPanoseInfo->pAltFont_name);
						m_aLoadedPanoseFont.add(pPanoseInfo);
						continue;
					}
				}

				//Panose Bstring에서 unicode로 변환
				unsigned short unicode = 0;
				FT_Byte		sPanose[10];

				BrINT subtypeCnt = 0;
				BrINT j = 0;

				//doc의 경우 Panose 형태로 전달받음
				if (pFontInfo->nPanose.bFamilyType > 0)
				{
					sPanose[0] = (pFontInfo->nPanose.bFamilyType);
					sPanose[1] = (pFontInfo->nPanose.bSerifStyle);
					sPanose[2] = (pFontInfo->nPanose.bWeight);
					sPanose[3] = (pFontInfo->nPanose.bProportion);
					sPanose[4] = (pFontInfo->nPanose.bContrast);
					sPanose[5] = (pFontInfo->nPanose.bStrokeVariation);
					sPanose[6] = (pFontInfo->nPanose.bArmStyle);
					sPanose[7] = (pFontInfo->nPanose.bLetterform);
					sPanose[8] = (pFontInfo->nPanose.bMidline);
					sPanose[9] = (pFontInfo->nPanose.bXHeight);
				}
				else
				{
					for (subtypeCnt = 0; subtypeCnt < 10; subtypeCnt++)
					{
						j = (subtypeCnt * 2) + 1;
						unicode = pFontInfo->nstrPanose[j];

						sPanose[subtypeCnt] = convertCharHexToInt(pFontInfo->nstrPanose[j]);
					}
				}

				//FamilyType이 0 일 경우 패스
				if (sPanose[0] == 0)
				{
					continue;
				}

#ifdef SUPPORT_ADD_FONT
				if (isAlreadyInLoadFont == false)
				{
					// 로드된 폰트 중에서 파노스 정보가 일치하는 폰트가 있는지 검색
					FT_Face face;
					//BrTrace("nFont_name %s ", pFontInfo->nFont_name);
					for (int loadedInx = 0; loadedInx < m_face_count; loadedInx++)
					{
						if (!m_Face[loadedInx] || !m_Face[loadedInx]->ft_face || NULL == m_Face[loadedInx]->ft_face->charmaps)
							continue;

						face = m_Face[loadedInx]->ft_face;
						TT_OS2* os2_table = (TT_OS2*)FT_Get_Sfnt_Table(face, ft_sfnt_os2);
						//if(!FontStrCmp( face->family_name, pFontInfo->nFont_name))
						{
							//BrTrace("face[%d]->family_name %s ", loadedInx, face->family_name);
							for (int n = 0; n < 10; n++)
							{
								if (os2_table && os2_table->panose[n] != sPanose[n])
								{
									isAlreadyInLoadFont = false;
									n = 10;
								}
								else if (n == 9)
								{
									//BrTrace("face[%d]->family_name %s ", loadedInx, face->family_name);
									isAlreadyInLoadFont = true;
									loadedInx = GetFontFaceCnt();
									n = 10;
								}

							}
						}
					}
				}

				long panoseMatchValue;
				long bestPanoseMatchValue = -1;

				if (isAlreadyInLoadFont == false)
				{
					// 시스템 폰트 경로내 파노스 정보가 유사한 폰트가 있는지 검색
					for (int mappingInx = 0; mappingInx < m_nRuntimeLoadFontCount; mappingInx++)
					{
						LPBrFontStruct pRuntimeLoadFont = m_RuntimeLoadFont.at(mappingInx);
						
						if (pRuntimeLoadFont->nPanose[0] == sPanose[0])
						{
							//값이 작을수록 유사한 폰트
							panoseMatchValue = matchingpanose(pRuntimeLoadFont->nPanose, sPanose);

							BrBOOL bFoundCandidate = false;
							if (panoseMatchValue == bestPanoseMatchValue) {
								bFoundCandidate = true;
							}

							if ((/*bFoundCandidate ||*/ bestPanoseMatchValue == -1) || panoseMatchValue < bestPanoseMatchValue) {
								bestPanoseMatchValue = panoseMatchValue;

								//BrTrace("bestPanoseMatchValue %d, family_name %s", bestPanoseMatchValue, m_RuntimeLoadFont.at(mappingInx)->pFamily_name);
								memset(family_name, 0, sizeof(family_name));
								CUtil::WcsCpy(family_name, pRuntimeLoadFont->pFamily_name);

								fontFaceIndex = mappingInx;

								if (bestPanoseMatchValue <= 1)
								{
									mappingInx = m_nRuntimeLoadFontCount;
									continue;
								}

							}
						}
					}

					//if (bestPanoseMatchValue < 10)
					{
						CUtil::WcsCpy(panoseFont_name, pFontInfo->nFont_name);
						CUtil::WcsCpy(bestMatchingFont_name, family_name);
						bestMatchingFontFaceIndex = fontFaceIndex;
					}
				}

#else
				long panoseMatchValue;
				long bestPanoseMatchValue = -1;

				if (isAlreadyInLoadFont == false)
				{
					// 로드된 폰트 중에서 유사한 폰트가 있는지 검색
					FT_Face face;
					for (int mappingInx = 0; mappingInx < m_face_count; mappingInx++)
					{
						if (!m_Face[mappingInx] || !m_Face[mappingInx]->ft_face || NULL == m_Face[mappingInx]->ft_face->charmaps)
							continue;

						face = m_Face[mappingInx]->ft_face;
						TT_OS2* os2_table = (TT_OS2*)FT_Get_Sfnt_Table(face, ft_sfnt_os2);
						if (os2_table && os2_table->panose[0] == sPanose[0])
						{
							//값이 작을수록 유사한 폰트
							panoseMatchValue = matchingpanose(os2_table->panose, sPanose);

							BrBOOL bFoundCandidate = false;
							if (panoseMatchValue == bestPanoseMatchValue) {
								bFoundCandidate = true;
							}

							if ((/*bFoundCandidate ||*/ bestPanoseMatchValue == -1) || panoseMatchValue < bestPanoseMatchValue) {
								bestPanoseMatchValue = panoseMatchValue;

								memset(family_name, 0, sizeof(family_name));
								BrMultiByteToWideChar(CP_UTF8, face->family_name, strlen(face->family_name),
									family_name, sizeof(family_name));
								//strncpy_s(family_name, sizeof(family_name), face->family_name, strlen(face->family_name));

								fontFaceIndex = mappingInx;

								if (bestPanoseMatchValue <= 1)
								{
									mappingInx = GetFontFaceCnt();
									continue;
								}

							}
						}
					}

					if (bestPanoseMatchValue < 10)
					{
						CUtil::WcsCpy(panoseFont_name, pFontInfo->nFont_name);
						CUtil::WcsCpy(bestMatchingFont_name, family_name);
						/*strncpy_s(panoseFont_name, sizeof(panoseFont_name), pFontInfo->nFont_name, strlen(pFontInfo->nFont_name));
						strncpy_s(bestMatchingFont_name, sizeof(bestMatchingFont_name), family_name, strlen(family_name));*/
						bestMatchingFontFaceIndex = fontFaceIndex;
					}
				}
#endif

				if (FontWcsCmp(bestMatchingFont_name, (const unsigned short*)u""))
				{
					//유사 폰트 로드
					//loadSystemFontFile(bestMatchingFont_name);

					//폰트명, 유사 폰트, 파노스 정보 저장
					LPBrPanoseInfoStruct pPanoseInfo = (LPBrPanoseInfoStruct)PoSysMalloc(BrSizeOf(BrPanoseInfoStruct));
					memset(pPanoseInfo, 0, BrSizeOf(BrPanoseInfoStruct));

					CUtil::WcsCpy(pPanoseInfo->pFont_name, panoseFont_name);
					CUtil::WcsCpy(pPanoseInfo->pBestMatchingFont_name, bestMatchingFont_name);

					pPanoseInfo->nFontFaceIndex = bestMatchingFontFaceIndex;
					//BrTrace("pFont_name %s, pBestMatchingFont_name %s ", pPanoseInfo->pFont_name, pPanoseInfo->pBestMatchingFont_name);
					m_aLoadedPanoseFont.add(pPanoseInfo);
					m_bFindAltFont = true;
				}
			}
		}
	}

	return m_bFindAltFont;
}

/*
*	@author 	minseob
*	@date  		2018.05.09
*	@param		BrLOGFONT stLogFong : font info
*	@brief  	doc 필터에서 전달받은 panose, 폰트이름 정보 저장
*/
void BoraFont::SetBLogFontInfo(BrLOGFONT stLogFong)
{
	//이미 저장되었는지 확인
	if(m_aFontNamePanoseInfo.size() > 0)
	{
		for( int cnt = 0;cnt < m_aFontNamePanoseInfo.size(); cnt++ )
		{	
			LPBrFontInfoStruct pFontInfo = m_aFontNamePanoseInfo.at(cnt);			
			if(pFontInfo->nPanose.bFamilyType == stLogFong.stPanose.bFamilyType
				&& pFontInfo->nPanose.bSerifStyle == stLogFong.stPanose.bSerifStyle
				&& pFontInfo->nPanose.bWeight == stLogFong.stPanose.bWeight
				&& pFontInfo->nPanose.bContrast == stLogFong.stPanose.bContrast
				&& pFontInfo->nPanose.bStrokeVariation == stLogFong.stPanose.bStrokeVariation
				&& pFontInfo->nPanose.bArmStyle == stLogFong.stPanose.bArmStyle
				&& pFontInfo->nPanose.bLetterform == stLogFong.stPanose.bLetterform
				&& pFontInfo->nPanose.bMidline == stLogFong.stPanose.bMidline
				&& pFontInfo->nPanose.bXHeight == stLogFong.stPanose.bXHeight
				)
				return;
		}
	}

	BrUSHORT strFontName[MAX_FONT_LENGTH] = {0,};
	memcpy(strFontName, stLogFong.lfFaceName, sizeof(stLogFong.lfFaceName));	
		
	if( stLogFong.stPanose.bFamilyType == 0  || !FontWcsCmp(strFontName, (const unsigned short*)u"") )
		return;

	LPBrFontInfoStruct pPanoseInfo = (LPBrFontInfoStruct)PoSysMalloc(BrSizeOf(BrFontInfoStruct));
	memset(pPanoseInfo, 0, BrSizeOf(BrFontInfoStruct));
	
	CUtil::WcsCpy(pPanoseInfo->nFont_name, strFontName);
	memset(pPanoseInfo->nstrPanose, 0, MAX_FONT_LENGTH * BrSizeOf(BrWORD));
	pPanoseInfo->nPanose = stLogFong.stPanose;

	m_aFontNamePanoseInfo.add(pPanoseInfo);
}

/*
*	@author 	minseob
*	@date  		2018.06.20
*	@param		CFontTableData* fontitem : fonttable info
*	@brief  	docx, pptx 필터에서 전달받은 panose, 폰트이름, 대체폰트이름 정보 저장
*/
void BoraFont::SetBFontTableData(const BrWORD* a_nFont_name, const BrWORD* a_nstrPanose, const BrWORD* a_nAltFont_name)
{
	if( a_nstrPanose == NULL || a_nFont_name == NULL )
		return;

	if (m_aFontNamePanoseInfo.size() > 0)
	{
		for (int cnt = 0; cnt < m_aFontNamePanoseInfo.size(); cnt++)
		{
			LPBrFontInfoStruct fi = m_aFontNamePanoseInfo.at(cnt);
			if (!FontWcsCmp(fi->nstrPanose, a_nstrPanose) && !FontWcsCmp(fi->nFont_name, a_nFont_name))
				return;
		}
	}
	LPBrFontInfoStruct pPanoseInfo = (LPBrFontInfoStruct)PoSysCalloc(1, BrSizeOf(BrFontInfoStruct));
	memcpy(pPanoseInfo->nstrPanose, a_nstrPanose, BrWcsLen(a_nstrPanose) * sizeof(BrWORD));
	memcpy(pPanoseInfo->nFont_name, a_nFont_name, BrWcsLen(a_nFont_name) * sizeof(BrWORD));
	if (a_nAltFont_name )
		memcpy(pPanoseInfo->nAltFont_name, a_nAltFont_name, BrWcsLen(a_nAltFont_name) * sizeof(BrWORD));
	m_aFontNamePanoseInfo.add(pPanoseInfo);
}

#endif //USE_PANOSE_INFO
PO_Face BoraFont::getInternalFontFace(int nIndex)
{
	BRTHREAD_ASSERT(m_InternalFontFace.size() > nIndex);
	return m_InternalFontFace.at(nIndex);
}

FT_Face BoraFont::getInternalFontFTFaceByIndex(int nIndex) 
{
	if(getInternalFontFace(nIndex))
		return getInternalFontFace(nIndex)->ft_face;
	else
		return BrNULL;
}

int	BoraFont::addInternalFontFace(PO_Face face)
{
	int nIndex = m_InternalFontFace.size();
	m_InternalFontFace.add(face);
	return nIndex;
}
int BoraFont::getInternalFontFaceCount()
{
	return m_InternalFontFace.size();
}
int	BoraFont::addInternalFontData(BrUCHAR* data)
{
	int nIndex = m_InternalFontData.size();	
	m_InternalFontData.add(data);
	return nIndex;
}

BrBYTE*	BoraFont::getFontTableBuffer(int &nRetSize)
{
	const int nTableDataSize = 16 * 64;
	if ( !BoraFont::m_pFontTableData )
		BoraFont::m_pFontTableData = (BrBYTE*)PoSysMalloc(nTableDataSize * BrSizeOf(BrBYTE));
	if ( BoraFont::m_pFontTableData )
	{
		memset(BoraFont::m_pFontTableData, 0, nTableDataSize);
		nRetSize = nTableDataSize;
	}
	return BoraFont::m_pFontTableData;
}
BrCHAR*	BoraFont::getCharBuffer()
{
	if ( !BoraFont::m_mFontName )
		BoraFont::m_mFontName = (BrCHAR*)PoSysMalloc(MAX_FONT_LENGTH * sizeof(BrCHAR));
	memset(BoraFont::m_mFontName, 0, MAX_FONT_LENGTH * sizeof(BrCHAR));
	return BoraFont::m_mFontName;
}
BrWORD*	BoraFont::getWCharBuffer()
{
	if ( !BoraFont::m_wFontName )
		BoraFont::m_wFontName = (BrWORD*)PoSysMalloc(MAX_FONT_LENGTH * sizeof(BrWORD));
	memset(BoraFont::m_wFontName, 0, MAX_FONT_LENGTH * sizeof(BrWORD));
	return BoraFont::m_wFontName;
}

BrCHAR* BoraFont::convertMultiToUTF8(const char* pSrc, int locale) 
{
	if ( !pSrc ) return BrNULL;

	int nLength = BrMIN(MAX_FONT_LENGTH-1, strlen(pSrc));
	if ( nLength <= 0 ) return BrNULL;

	BrWORD*	wFontName = getWCharBuffer();

	//마지막 파라미터는 스트링의 길이라서 +1로 변경
	int nLen = BrMultiByteToWideChar( locale, pSrc, nLength, wFontName, nLength+1);

	nLength = BrMIN(MAX_FONT_LENGTH-1, nLen*BrSizeOf(BrCHAR)*3);
	BrCHAR* fontName = (BrCHAR*)PoSysCalloc(nLength+1, BrSizeOf(BrCHAR));

	// Unicode -> UTF-8
	nLen = BrWideCharToMultiByte( CP_UTF8, wFontName, nLen, fontName, nLength+1);

	return fontName;
}

BrWORD* BoraFont::convertMultiToUCS2(const char* pSrc, int locale)
{
	if (!pSrc) return BrNULL;

	int nLength = BrMIN(MAX_FONT_LENGTH - 1, strlen(pSrc));
	if (nLength <= 0) return BrNULL;

	BrWORD* wFontName = getWCharBuffer();

	//마지막 파라미터는 스트링의 길이라서 +1로 변경
	int nLen = BrMultiByteToWideChar(locale, pSrc, nLength, wFontName, nLength + 1);
	nLen = BrWcsLen(wFontName);

	nLength = BrMIN(MAX_FONT_LENGTH, nLen + 1);
	BrWORD* fontName = (BrWORD*)PoSysCalloc(nLength, BrSizeOf(BrWORD));
	CUtil::WcsCpy(fontName, wFontName);

	return fontName;
}

bool BoraFont::AddFontFilePath(const char* pUtf8Path)
{
	bool bRet = false;
	BrBOOL bDirectLoading = BrTRUE;
#ifdef SUPPORT_ADD_FONT	
	BrINT nPrevTypeFaceListSize = m_aTypeFaceList.size();
	bDirectLoading = BrFALSE;
#else
	BrINT prevFontFaceCnt = GetFontFaceCnt();
#endif//#ifdef SUPPORT_ADD_FONT
	GetFontNameList();
	if (addFontFile((BrLPCSTR)pUtf8Path, -1, m_face_count, bDirectLoading))
	{
		if (bDirectLoading)
		{
			loadCharmap(m_Face, m_face_count);
		}
		clearCacheFontFace();
		for (int i = 0; i < m_aNotExistFontName.size(); i++)
		{
			PoSysFree(m_aNotExistFontName.at(i));
		}
		m_aNotExistFontName.removeAll();

#ifdef SUPPORT_ADD_FONT
		BrINT nTypeFaceListSize = m_aTypeFaceList.size();
		for (int i = nPrevTypeFaceListSize; i < nTypeFaceListSize; i++)
		{
			LPBrTypefaceStruct pFamily = m_aTypeFaceList.at(i);
			BrINT nRuntimeLoadFontIndex = -1;
			for (int familyIdx = 0; familyIdx < eFontStyleIndexMax; familyIdx++)
			{
				if (pFamily->nStyleCnt[familyIdx] > 0)
				{
					LPBrFontStyleIdxNode pNode = pFamily->nFontIndices[familyIdx];
					while (pNode != BrNULL && nRuntimeLoadFontIndex < 0)
					{
						nRuntimeLoadFontIndex = pNode->nFontIndex;
						pNode = pNode->pNext;
					}

					if (nRuntimeLoadFontIndex > -1)
						break;
				}
			}
			//if(m_nEFIndex != i && m_nSymbolIndex != i && m_nWindingIndex !=i && m_nWinding2Index !=i && m_nWinding3Index !=i && m_nWebdingsIndex !=i && m_nMathIndex !=i && m_nHWPMathIndex !=i && m_nHangulIndex != i)
			if (nRuntimeLoadFontIndex > -1)
			{
				//[16.10.25][sglee1206] i의 값은 m_aTypeFaceList의 Index인데 이것을 m_RuntimeLoadFont로 이용하면 잘못처리되므로 해당 부분 수정
				//관련 이슈[CSP-4328][CAM-5448][CAM-5072][CAM-4745][CAM-3945]
				LPBrLoadFontFileList pFontFile = getLoadFontFileList(getLoadFontStFileIndex(nRuntimeLoadFontIndex));

				if (BrWcsLen(pFamily->sFontData.pEngName) > 0 /* && pFontFile->bLoaded == BrFALSE*/)
				{
					FontList* fontData = (FontList*)PoSysCalloc(1, sizeof(FontList));
					if (fontData)
					{
						BrINT32 nLen = BrWcsLen(pFamily->sFontData.pEngName);
						BrWideCharToMultiByte(CP_UTF8, pFamily->sFontData.pEngName, nLen, (BrLPSTR)fontData->pEngName, BORA_FONTNAME_LENGTH - 1);

						nLen = BrWcsLen(pFamily->sFontData.pLocName);
						if (nLen > 0)
							BrWideCharToMultiByte(CP_UTF8, pFamily->sFontData.pLocName, nLen, (BrLPSTR)fontData->pLocName, BORA_FONTNAME_LENGTH - 1);
						fontData->nFontEncodingType = pFamily->sFontData.nFontEncodingType;

						m_aFontFace->add(fontData);
					}
				}
			}
		}
#else
		BrINT i = 0, nFontLen = 0;
		BrUSHORT wTemp[MAX_FONT_LENGTH] = { 0 };
		BrINT fontFaceCnt = GetFontFaceCnt();
		for (i = prevFontFaceCnt; i < fontFaceCnt; i++)
		{
			if (m_nEFIndex != i && m_nSymbolIndex != i && m_nWindingIndex != i && m_nWinding2Index != i && m_nWinding3Index != i && m_nWebdingsIndex != i && m_nMathIndex != i && m_nHWPMathIndex != i && m_nHangulIndex != i)
			{
				memset(wTemp, 0, sizeof(BrUSHORT) * MAX_FONT_LENGTH);
				CUtil::WcsCpy(wTemp, GetFamilyNameByIndex(i));
				nFontLen = BrWcsLen(wTemp);
				if (!isRegEmFamilyFont(wTemp, nFontLen, m_nFontFlag))
				{
					FontList* fontData = (FontList*)PoSysCalloc(1, sizeof(FontList));
					if (fontData)
					{
						BrWideCharToMultiByte(CP_UTF8, wTemp, nFontLen, fontData->pEngName, sizeof(fontData->pEngName));

						fontData->nFontEncodingType = GetFontEncodingFlag(getFTFaceByIndex(i));
						FT_Face ft_face = getFTFaceByIndex(i);
						FT_UInt tmCount = FT_Get_Sfnt_Name_Count(ft_face);
						for (int j = 0; j < tmCount; j++)
						{
							memset(wTemp, 0, sizeof(BrUSHORT) * MAX_FONT_LENGTH);
							FT_SfntName tmName;
							FT_Get_Sfnt_Name(ft_face, j, &tmName);
							//[dwchun : 2013.10.23] : 조건을 체크하는 순서 절대로 바꾸지 말 것. 속도를 위해 맞춘 순서임
							if (tmName.language_id == TT_MS_LANGID_KOREAN_EXTENDED_WANSUNG_KOREA && tmName.name_id == 1 && tmName.platform_id == TT_PLATFORM_MICROSOFT && tmName.encoding_id == TT_MS_ID_UNICODE_CS)
							{
								convertFontFaceName(tmName.string_len, tmName.string, wTemp, sizeof(BrUSHORT) * MAX_FONT_LENGTH);
								if (BrWcsLen(wTemp) > 0)
								{
									BrWideCharToMultiByte(CP_UTF8, wTemp, BrWcsLen(wTemp), (BrLPSTR)fontData->pLocName, BORA_FONTNAME_LENGTH - 1);
								}
								break;
							}
						}

						m_aFontFace->add(fontData);
					}
				}
			}
		}
#endif
		bRet = true;
	}
	return bRet;
}

bool BoraFont::AddFontMemoryBuffer(const void* pFontBuffer, int nBufferSize)
{
	bool bRet = false;
	BrBOOL bDirectLoading = BrTRUE;
#ifdef SUPPORT_ADD_FONT	
	BrINT nPrevTypeFaceListSize = m_aTypeFaceList.size();
	bDirectLoading = BrFALSE;
#else
	BrINT prevFontFaceCnt = GetFontFaceCnt();
#endif//#ifdef SUPPORT_ADD_FONT
	GetFontNameList();

	int nTTFCount = getMemoryFontFaceCount((BrBYTE*)pFontBuffer);

	for (int idx = 0; idx < nTTFCount; idx++)
	{
		FT_Face fontFace = BrNULL;
		if (addFontMemory((void*)pFontBuffer, nBufferSize, idx, fontFace, bDirectLoading))
		{
			int nFontIndex = addFontFaceByIndex(fontFace);
			PO_Face pFace = GetFontFaceByIndex(nFontIndex);
			if (bDirectLoading)
			{
				int nSysFontIndex = getSysFontIndex(pFace, -1);
#ifndef SUPPORT_ADD_FONT
				setSystemFontPath(BrNULL, fontFace, 0, bDirectLoading);
				pFace->nFontListIndex = m_nRuntimeLoadFontCount - 1;
#else
				pFace->nFontListIndex = nSysFontIndex;
#endif // !SUPPORT_ADD_FONT
				regFontDataPool((void*)pFontBuffer, nBufferSize, pFace);
				loadCharmap(m_Face, m_face_count);
			}
			bRet = true;
		}
	}

	if (bRet)
	{
		clearCacheFontFace();
		for (int i = 0; i < m_aNotExistFontName.size(); i++)
		{
			PoSysFree(m_aNotExistFontName.at(i));
		}
		m_aNotExistFontName.removeAll();

#ifdef SUPPORT_ADD_FONT
		// [20.05.26][sglee1206] 이부분은 제대로 동작하지 않으나 WASM에서는 SUPPORT_ADD_FONT를  사용하지 않으므로 우선 적용함.
		BrINT nTypeFaceListSize = m_aTypeFaceList.size();
		for (int i = nPrevTypeFaceListSize; i < nTypeFaceListSize; i++)
		{
			LPBrTypefaceStruct pFamily = m_aTypeFaceList.at(i);
			BrINT nRuntimeLoadFontIndex = -1;
			for (int familyIdx = 0; familyIdx < eFontStyleIndexMax; familyIdx++)
			{
				if (pFamily->nStyleCnt[familyIdx] > 0)
				{
					LPBrFontStyleIdxNode pNode = pFamily->nFontIndices[familyIdx];
					while (pNode != BrNULL && nRuntimeLoadFontIndex < 0)
					{
						nRuntimeLoadFontIndex = pNode->nFontIndex;
						pNode = pNode->pNext;
					}

					if (nRuntimeLoadFontIndex > -1)
						break;
				}
			}
			//if(m_nEFIndex != i && m_nSymbolIndex != i && m_nWindingIndex !=i && m_nWinding2Index !=i && m_nWinding3Index !=i && m_nWebdingsIndex !=i && m_nMathIndex !=i && m_nHWPMathIndex !=i && m_nHangulIndex != i)
			if (nRuntimeLoadFontIndex > -1)
			{
				//[16.10.25][sglee1206] i의 값은 m_aTypeFaceList의 Index인데 이것을 m_RuntimeLoadFont로 이용하면 잘못처리되므로 해당 부분 수정
				//관련 이슈[CSP-4328][CAM-5448][CAM-5072][CAM-4745][CAM-3945]
				LPBrLoadFontFileList pFontFile = getLoadFontFileList(getLoadFontStFileIndex(nRuntimeLoadFontIndex));

				if (BrWcsLen(pFamily->sFontData.pEngName) > 0 /* && pFontFile->bLoaded == BrFALSE*/)
				{
					FontList* fontData = (FontList*)PoSysCalloc(1, sizeof(FontList));
					if (fontData)
					{
						BrINT32 nLen = BrWcsLen(pFamily->sFontData.pEngName);
						BrWideCharToMultiByte(CP_UTF8, pFamily->sFontData.pEngName, nLen, (BrLPSTR)fontData->pEngName, BORA_FONTNAME_LENGTH - 1);

						nLen = BrWcsLen(pFamily->sFontData.pLocName);
						if (nLen > 0)
							BrWideCharToMultiByte(CP_UTF8, pFamily->sFontData.pLocName, nLen, (BrLPSTR)fontData->pLocName, BORA_FONTNAME_LENGTH - 1);
						fontData->nFontEncodingType = pFamily->sFontData.nFontEncodingType;

						m_aFontFace->add(fontData);
					}
				}
			}
		}
#else
		BrINT i = 0, nFontLen = 0;
		BrUSHORT wTemp[MAX_FONT_LENGTH] = { 0 };
		BrINT fontFaceCnt = GetFontFaceCnt();
		for (i = prevFontFaceCnt; i < fontFaceCnt; i++)
		{
			if (m_nEFIndex != i && m_nSymbolIndex != i && m_nWindingIndex != i && m_nWinding2Index != i && m_nWinding3Index != i && m_nWebdingsIndex != i && m_nMathIndex != i && m_nHWPMathIndex != i && m_nHangulIndex != i)
			{
				memset(wTemp, 0, sizeof(BrUSHORT) * MAX_FONT_LENGTH);
				CUtil::WcsCpy(wTemp, GetFamilyNameByIndex(i));
				nFontLen = BrWcsLen(wTemp);
				if (!isRegEmFamilyFont(wTemp, nFontLen, m_nFontFlag))
				{
					FontList* fontData = (FontList*)PoSysCalloc(1, sizeof(FontList));
					if (fontData)
					{
						BrWideCharToMultiByte(CP_UTF8, wTemp, nFontLen, fontData->pEngName, sizeof(fontData->pEngName));

						fontData->nFontEncodingType = GetFontEncodingFlag(getFTFaceByIndex(i));
						FT_Face ft_face = getFTFaceByIndex(i);
						FT_UInt tmCount = FT_Get_Sfnt_Name_Count(ft_face);
						for (int j = 0; j < tmCount; j++)
						{
							memset(wTemp, 0, sizeof(BrUSHORT) * MAX_FONT_LENGTH);
							FT_SfntName tmName;
							FT_Get_Sfnt_Name(ft_face, j, &tmName);
							//[dwchun : 2013.10.23] : 조건을 체크하는 순서 절대로 바꾸지 말 것. 속도를 위해 맞춘 순서임
							if (tmName.language_id == TT_MS_LANGID_KOREAN_EXTENDED_WANSUNG_KOREA && tmName.name_id == 1 && tmName.platform_id == TT_PLATFORM_MICROSOFT && tmName.encoding_id == TT_MS_ID_UNICODE_CS)
							{
								convertFontFaceName(tmName.string_len, tmName.string, wTemp, sizeof(BrUSHORT) * MAX_FONT_LENGTH);
								if (BrWcsLen(wTemp) > 0)
								{
									BrWideCharToMultiByte(CP_UTF8, wTemp, BrWcsLen(wTemp), (BrLPSTR)fontData->pLocName, BORA_FONTNAME_LENGTH - 1);
								}
								break;
							}
						}

						m_aFontFace->add(fontData);
					}
				}
			}
		}
#endif
	}

	return bRet;
}

void BoraFont::releaseExceptFontFileList()
{
	if (m_ExceptFileList)
	{
		for (int n = 0; n < m_ExceptFileList->size(); n++)
		{
			PoSysFree((char*)*m_ExceptFileList->getAt(n));
		}
		m_ExceptFileList->removeAll();
		delete m_ExceptFileList;
		m_ExceptFileList = BrNULL;
	}
}
void BoraFont::AddExceptFontFile(const char* pFilePath)
{
	if (!m_ExceptFileList)
	{
		m_ExceptFileList = new BSysExArray<BrCHAR*>;
	}

	if (m_ExceptFileList)
	{
		BrBOOL bAdd = BrTRUE;
		for (int n = 0; n < m_ExceptFileList->size(); n++)
		{
			if (!strcmp(pFilePath, (char*)*m_ExceptFileList->getAt(n)))
			{
				bAdd = BrFALSE;
				break;
			}
		}
		if (bAdd)
		{
			BrCHAR* pFileName = (BrCHAR*)PoSysCalloc(strlen(pFilePath) + 1, sizeof(BrCHAR));
			strncpy_s(pFileName, strlen(pFilePath) + 1, pFilePath, strlen(pFilePath));
			m_ExceptFileList->add(pFileName);
		}
	}
}
BrBOOL BoraFont::IsExceptFontFile(const char* pFilePath)
{
	BrBOOL bRet = BrFALSE;
	if (m_ExceptFileList) {
		char* pFileName;
		for (int n = 0; n < m_ExceptFileList->size(); n++)
		{
			pFileName = (char*)*m_ExceptFileList->getAt(n);
			if (!strcmp(pFilePath, pFileName))
			{
				bRet = BrTRUE;
				break;
			}
		}
	}
	return bRet;
}

#endif //defined(USE_FREETYPE2_ENGINE)
