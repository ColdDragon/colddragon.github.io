#include <OfficePreComp.hpp>

#include "brexportdc.h"
#include "bexportfont.h"

#include "painter.h"

BrExportDC::BrExportDC()
{	
	Painter* pPainter = getPainter();
	m_pExtFont = BrNULL;
	memset(&m_sExtInfo, 0, BrSizeOf(m_sExtInfo));
	memset(&m_sParentExtInfo, 0, BrSizeOf(m_sExtInfo));
	memset(&m_pLinePos, 0, BrSizeOf(m_pLinePos));
	m_nExtFalg = eNoneExtDCState;
	m_bIsTwipPenWidth = BrFALSE;
	m_bPdfPrint = BrFALSE;
	m_cPenColor = BLACK_COLOR;
	m_nPenWidth = 1;
	m_nPenStyle = eSolid;
	m_nPenType = eNormalPen;
	m_nLineStyle = eSimple;
	m_nCap = eNoneLineCap;
	m_nJoin = eMiterDefaultLineJoin;
	m_pExtCoordUnit = BrNULL;
#ifdef USE_EXT_PRINT
	m_sBaseOffset = pPainter->m_sPrintMOffset;		
#else //USE_EXT_PRINT
	BR_SET_POINT(m_sBaseOffset, 0, 0);	
#endif //USE_EXT_PRINT
	m_sExtInfo.nPosX = m_sBaseOffset.x;
	m_sExtInfo.nPosY = m_sBaseOffset.y;
	BR_SET_STATE(m_nState, eExportModeDCState);	
	m_nExportState = eNoneExtDCExportState;
	BR_SET_RECT(m_rcExtClip, 0, 0, 0, 0);
	BR_SET_RECT(m_rcPageClip, 0, 0, 0, 0);	

	m_pFTempBrush = BrNULL;
}

BrExportDC::~BrExportDC()
{
	if(m_pFont)
		m_pFont->setExportFont(BrNULL);
	if(m_pFTempBrush)
		BrDELETE m_pFTempBrush;
	
	BR_SAFE_DELETE(m_pExtFont);
}

void BrExportDC::intPageEnv()
{
	memset(&m_sExtInfo, 0, BrSizeOf(m_sExtInfo));
	memset(&m_sParentExtInfo, 0, BrSizeOf(m_sExtInfo));
	memset(&m_pLinePos, 0, BrSizeOf(m_pLinePos));
	m_nExtFalg = eNoneExtDCState;
	m_bIsTwipPenWidth = BrFALSE;
	m_bPdfPrint = BrFALSE;
	m_cPenColor = BLACK_COLOR;
	m_nPenWidth = 1;
	m_nPenStyle = eSolid;
	m_nLineStyle = eSimple;
	m_nCap = eNoneLineCap;
	m_nJoin = eMiterDefaultLineJoin;
	m_pExtCoordUnit = BrNULL;	
	BR_REL_STATE(m_nExportState, eCreatedExtDCExportState);
	BR_SET_RECT(m_rcExtClip, 0, 0, 0, 0);
	BR_SET_RECT(m_rcPageClip, 0, 0, 0, 0);	
}

void BrExportDC::setExportCoordUnit(void* pExtUnit)
{
	m_pExtCoordUnit = pExtUnit;
}

void* BrExportDC::getExportCoordUnit()
{
	return m_pExtCoordUnit;
}

void BrExportDC::enableHasExportDataFlag()
{
	BR_SET_STATE(m_nExtFalg, eHasDataExtDCState);
}

BrBYTE BrExportDC::getExportMode()
{
	BrBYTE nMode = eNormalExtMode;
	if(BR_ISSET_STATE(m_nExtFalg, eHasDirectExtDCState))
	{
		if(BR_ISSET_STATE(m_nExtFalg, eHasFillTemplateExtDCState))
			nMode = eFillTemplateDirectExtMode;
		else
			nMode = eDirectExtMode;
	}
	else if(BR_ISSET_STATE(m_nExtFalg, eHasNoneDirectExtDCState))
		nMode = eNoneDirectExtMode;	
	return nMode;
}

BrBYTE BrExportDC::setExportMode(BrBYTE nMode)
{
	BrBYTE nOldMode = getExportMode();
	if(nMode == eDirectExtMode)
	{
		if(nOldMode != eDirectExtMode)
		{
			toExport();
			BR_REL_STATE(m_nExtFalg, (eHasNoneDirectExtDCState| eHasFillTemplateExtDCState));
			BR_SET_STATE(m_nExtFalg, eHasDirectExtDCState);
			if(nOldMode == eFillTemplateDirectExtMode)
				enableRenderMode(eTemplateDCMode, BrFALSE);
			enableRenderMode(eTemplateDCMode, BrTRUE);
		}
	}
	else if(nMode == eFillTemplateDirectExtMode)
	{
		if(nOldMode != eFillTemplateDirectExtMode)
		{
			toExport();
			BR_REL_STATE(m_nExtFalg, eHasNoneDirectExtDCState);
			BR_SET_STATE(m_nExtFalg, (eHasDirectExtDCState | eHasFillTemplateExtDCState));
			if(nOldMode == eDirectExtMode)
				enableRenderMode(eTemplateDCMode, BrFALSE);
			enableRenderMode(eTemplateDCMode, BrTRUE);
		}
	}
	else if(nMode == eNoneDirectExtMode)
	{
		if(nOldMode == eDirectExtMode || nOldMode == eFillTemplateDirectExtMode)
		{
			toLineExport();
			BR_REL_STATE(m_nExtFalg, (eHasDirectExtDCState|eHasFillTemplateExtDCState));			
			enableRenderMode(eTemplateDCMode, BrFALSE);			
		}
		BR_SET_STATE(m_nExtFalg, eHasNoneDirectExtDCState);
	}
	else
	{
		if(nOldMode == eDirectExtMode || nOldMode == eFillTemplateDirectExtMode)
		{
			toLineExport();
			BR_REL_STATE(m_nExtFalg, (eHasDirectExtDCState|eHasFillTemplateExtDCState));			
			enableRenderMode(eTemplateDCMode, BrFALSE);
		}
		else if(nOldMode == eNoneDirectExtMode)
		{
			toExport();
			BR_REL_STATE(m_nExtFalg, eHasNoneDirectExtDCState);
		}
	}
	return nOldMode;
}

void BrExportDC::getExport(BrEXPORT_INFO* pInfo)
{
	if(pInfo)
	{
		*pInfo = m_sExtInfo;
		pInfo->nPosX -= m_sBaseOffset.x;
		pInfo->nPosY -= m_sBaseOffset.y;
	}
}

void BrExportDC::setExport(BrINT nPosX, BrINT nPosY, BrINT nPosW, BrINT nPosH, BrINT nRotateAngle, BrINT* pTextRotAngle)
{
	nPosX += m_sBaseOffset.x;
	nPosY += m_sBaseOffset.y;
	if(BR_ISSET_STATE(m_nExtFalg, (eHasDirectExtDCState|eHasPathExtDCState)))
	{
		if(m_sExtInfo.nPosX != nPosX || m_sExtInfo.nPosY != nPosY || m_sExtInfo.nRotateAngle != nRotateAngle)
			toExport();
	}
	m_sExtInfo.nPosX = nPosX;
	m_sExtInfo.nPosY = nPosY;
	m_sExtInfo.nPosW = nPosW;
	m_sExtInfo.nPosH = nPosH;
	m_sExtInfo.nRotateAngle = nRotateAngle;
	if(pTextRotAngle)
		m_sExtInfo.nTxtRotAngle = *pTextRotAngle;
	else
		m_sExtInfo.nTxtRotAngle = nRotateAngle;
}

void BrExportDC::setExport(BrEXPORT_INFO* pInfo)
{
	if(pInfo)
	{
		BrEXPORT_INFO sInfo = *pInfo;
		sInfo.nPosX += m_sBaseOffset.x;
		sInfo.nPosY += m_sBaseOffset.y;
		if(BR_ISSET_STATE(m_nExtFalg, eHasDirectExtDCState) || BR_ISSET_STATE(m_nExtFalg, eHasPathExtDCState))
		{
			if(m_sExtInfo.nPosX != sInfo.nPosX || m_sExtInfo.nPosY != sInfo.nPosY || m_sExtInfo.nRotateAngle != sInfo.nRotateAngle || m_sExtInfo.nTxtRotAngle != sInfo.nTxtRotAngle)
				toExport();
		}
		m_sExtInfo = sInfo;		
	}
}

#ifdef PDF_DIRECT_PRINT
BrINT BrExportDC::setExportRotAngle(BrINT nRotateAngle)
{
	BrINT nOldAngle = m_sExtInfo.nRotateAngle;
	m_sExtInfo.nRotateAngle = nRotateAngle;
	return nOldAngle;
}
#endif //PDF_DIRECT_PRINT

BFont* BrExportDC::setFont(BFont* pFont)
{
	BFont* pOld = BrDC::setFont(pFont);
	if(m_pExtFont && BR_ISSET_STATE(m_nExportState, eCreatedExtDCExportState))
		m_pExtFont->setFont(m_pFont);

	if(pOld && pOld != m_pFont)
		pOld->setExportFont(BrNULL);

	return pOld;
}

BrBOOL BrExportDC::setBitmap(PrBitmap* pBitmap)
{
	return BrDC::setBitmap(pBitmap);
}

BrBOOL BrExportDC::setBitmapDC(BrBitmap* pImage)
{
	return BrDC::setBitmapDC(pImage);
}

BrBOOL BrExportDC::setBitmap2(BrINT nWidth, BrINT nHeight)
{
	BrBOOL bRet = BrFALSE;
	BrBOOL bSetBit = BrFALSE;

	//[IAC-2765] nWidth, nHeight ���� ������������ ū ��� ���� ó��
	if(BR_ISSET_STATE(m_nExportState, eCreatedExtDCExportState)
		&& m_rcPageClip.right && m_rcPageClip.bottom)
	{
		nWidth = BrMIN(m_rcPageClip.right - m_rcPageClip.left, nWidth);
		nHeight = BrMIN(m_rcPageClip.bottom - m_rcPageClip.top, nHeight);
	}

	if(m_pBitmap)
	{
		BR_REL_STATE(m_nExtFalg, eHasDataExtDCState);
		
		if(BR_ISSET_STATE(m_nState, eHasAlphaValueDCState))
			enableAlphaBitmapDC(BrFALSE, BrTRUE);
		if(BR_ISSET_STATE(m_nState, eHasLayerDCState))
			enableLayer(BrFALSE);

		if(m_pBitmap->cx() != nWidth || m_pBitmap->cy() != nHeight)
		{
			if(nWidth < 0 || nHeight < 0)
				bRet = BrTRUE;

			if(bRet == BrFALSE)
				bRet = m_pBitmap->setCanvasSize(nWidth, nHeight);
			if(!bRet)
			{
				if(m_pBitmap->createBitmap(nWidth, nHeight))
				{
					m_pBitmap->fill(m_bkColor);
					bRet = BrTRUE;
				}
				else
				{
					// �̷� ��찡 ������ �ȵ�
					BRTHREAD_ASSERT(0);
				}
			}
			else
			{
				nWidth = m_pBitmap->cx();
				nHeight = m_pBitmap->cy();

				m_pBitmap->fill(m_bkColor);
			}
			bSetBit = bRet;
		}					
	}
	else
	{
		m_pBitmap = BrNEW PrBitmap(BrTRUE);
		m_bDelBit = BrTRUE;
		if(m_pBitmap)
		{
			if(m_pBitmap->createBitmap(nWidth, nHeight))
			{
				m_pBitmap->fill(m_bkColor);
				bSetBit = bRet = BrTRUE;
			}
			else
			{
				BrDELETE(m_pBitmap);
				m_pBitmap = BrNULL;
			}
		}
	}

	clearState(m_nState&eTemplateModeDCState);

	if(bSetBit)
	{
		bRet = updateBitmapDC(BrTRUE);		
		if(!bRet)
			clearBitmapDC();
	}

	return bRet;
}

void BrExportDC::enableFillTemplateRender(BrBOOL bEnable, BrINT nCX, BrINT nCY)
{
	BrRect rcFigureClip, rcFillClip;
	
	if(bEnable && nCX > 0 && nCY > 0)
	{
		if(m_pPen->m_sLogPen.nPenType == eGradientPen || m_pPen->getLineStyle() != eSimple || m_pPen->isDIBPen() || isFrameLineStyle())	
			return;
		else if(m_pBrush->m_sLogBrush.m_iStyle != eGradientBrush)
			return;

		BrRect oldRcFigureClip, oldRcFillClip;

		// MQP-13511 ���� �ٸ� ���� �ϳ��� ä���� ä��� ���� ����
		if (m_pFigureClipBox)
		{
			oldRcFigureClip = *m_pFigureClipBox;

			m_pFigureClipBox->right -= m_pFigureClipBox->left;
			m_pFigureClipBox->left -= m_pFigureClipBox->left;
			m_pFigureClipBox->bottom -= m_pFigureClipBox->top;
			m_pFigureClipBox->top -= m_pFigureClipBox->top;
		}

		if (m_pFillClipBox)
		{
			oldRcFillClip = *m_pFillClipBox;

			m_pFillClipBox->right -= m_pFillClipBox->left;
			m_pFillClipBox->left -= m_pFillClipBox->left;
			m_pFillClipBox->bottom -= m_pFillClipBox->top;
			m_pFillClipBox->top -= m_pFillClipBox->top;
		}
			
		if(enableTemplateMode(BrTRUE, nCX, nCY, rcFigureClip, rcFillClip))
		{
			BrBmvBrush* pTBrush = BrNULL;

			BrINT oldangle = m_sExtInfo.nRotateAngle;
			BrBYTE oldFlip = m_nFigureFlipType;
			BrDC ::setRotateAngle(0);
			BrDC::setFigureFlip(eFigureFlipNone);

			BrDC::fillRect(0, 0, nCX, nCY);			
			BR_REL_STATE(m_nExtFalg, eHasDataExtDCState);
			enableTemplateMode(BrFALSE, 0, 0, rcFigureClip, rcFillClip);
			if(m_pFTempBrush)
				BrDELETE m_pFTempBrush;

			pTBrush = BrNEW BrBmvBrush;
			pTBrush->createDIBBrush(m_pTemplate);
			m_pFTempBrush = m_pBrush;
			m_pBrush = pTBrush;
			m_pBrush->setEnableRotate(m_pFTempBrush->isEnableRotate());

			BrDC ::setRotateAngle(oldangle);
			BrDC::setFigureFlip(oldFlip);
		}

		if (m_pFigureClipBox)
		{
			*m_pFigureClipBox = oldRcFigureClip;
		}

		if (m_pFillClipBox)
		{
			*m_pFillClipBox = oldRcFillClip;
		}
	}
	else
	{
		if(m_pFTempBrush)
		{
			BrDELETE m_pBrush;
			m_pBrush = m_pFTempBrush;
			m_pFTempBrush = BrNULL;
		}
	}
}

BrBOOL BrExportDC::setExportRenderEnv(BrBOOL bFill, BrBOOL bUpdate/* = BrTRUE*/)
{
	BrINT8 nLineStyle = m_pPen->getLineStyle();
	if(bFill)
	{
		if(m_pBrush->m_sLogBrush.m_iStyle == eGradientBrush)
			return BrFALSE;
	}

#if 0 // ǥ�� �׸� ��츦 �����ϰ�, BrShape::CheckAndDirectExport �� Brshape::DrawGraphics ���� ����üũ �� ������ ������ �����ص� ������ٰ� �Ǵܵ�.
	if(m_pPen->m_sLogPen.nPenType == eGradientPen || nLineStyle != eSimple || m_pPen->isDIBPen() || isFrameLineStyle())
		return BrFALSE;
#endif

	BoraOpacity sGS = {(BrINT)m_pPen->getAlpha(), (BrINT)m_nSourceConstantAlpha};

	//BrBOOL bEnableRotate = m_pBrush->isEnableRotate();

	if(bUpdate == BrTRUE)
	{
		if(getDCType() == ePrintExtDCType)
			m_nPenWidth = m_pPen->m_sLogPen.nWidth;
		else {
			m_nPenWidth = m_pPen->getBaseLineWidthTwip(); //[2014.06.24] PDF export �� penWidth�� Baseline�� �������� ����Ѵ�.
			m_bIsTwipPenWidth = BrTRUE; //[2015.06.01][235] PDF export�� TwipPenWidth Flag�� �����Ѵ�.
		}
		m_cPenColor = BrRGB(m_pPen->m_sLogPen.nRed, m_pPen->m_sLogPen.nGreen, m_pPen->m_sLogPen.nBlue);
		m_nPenStyle = m_pPen->m_sLogPen.nPenStyle;
		m_nLineStyle = m_pPen->m_sLogPen.nLineStyle;
		m_nCap = m_pPen->m_nLineCap;
		m_nJoin = m_pPen->m_nLineJoin;
	}

	SetGState(&sGS);

	if(m_pBrush->m_sLogBrush.m_iStyle == eNullBrush || !bFill)
		setNullBrush();
	else if(m_pBrush->m_sLogBrush.m_iStyle == ePatternBrush || m_pBrush->m_sLogBrush.m_iStyle == eDIBBrush || m_pBrush->m_sLogBrush.m_iStyle == eDIBPatternBrush)
		setImageBrushByType();
	else
		setBrushColor(BrRGB(m_pBrush->m_sLogBrush.m_nRed, m_pBrush->m_sLogBrush.m_nGreen, m_pBrush->m_sLogBrush.m_nBlue));

	setPenAtt(m_nPenWidth, m_cPenColor, m_nPenStyle, m_nCap, m_nJoin);
	
	if(getDCType() == ePDFExtDCType)
	{
		BrINT nAngle = m_sExtInfo.nRotateAngle;	
		SetFlipType(m_nFigureFlipType);
		SetRotateAngle(360-nAngle);
	}

	if(bFill)	
		SetFillType(m_nPolyFillMode);

	return BrTRUE;
}

void BrExportDC::toLineExport()
{
	if(BR_ISSET_STATE(m_nExtFalg, eHasPathExtDCState))
	{
		toLineExport(&m_pLinePos.p1, &m_pLinePos.p2);
		BR_REL_STATE(m_nExtFalg, eHasPathExtDCState);
	}		
}

void BrExportDC::setLinePath(BrINT32 x1, BrINT32 y1, BrINT32 x2, BrINT32 y2, BrCOLORREF sColor, BrINT nWidth, BrBYTE nStyle, BrBYTE nLineStyle, BrBYTE nCap, BrBYTE nJoin)
{
	m_cPenColor = sColor;
	m_nPenWidth = nWidth;
	m_nPenStyle = nStyle;
	m_nLineStyle = nLineStyle;
	m_nCap = nCap;
	m_nJoin = nJoin;

	m_pLinePos.p1.x = (BrFLOAT)x1;
	m_pLinePos.p1.y = (BrFLOAT)y1;
	m_pLinePos.p2.x = (BrFLOAT)x2;
	m_pLinePos.p2.y = (BrFLOAT)y2;	
	BR_SET_STATE(m_nExtFalg, eHasPathExtDCState);
}

void BrExportDC::updateLinePath(BrINT32 x1, BrINT32 y1, BrINT32 x2, BrINT32 y2, BrCOLORREF sColor, BrINT nWidth, BrBYTE nStyle, BrBYTE nLineStyle, BrBYTE nCap, BrBYTE nJoin)
{
	if(sColor != m_cPenColor || m_nPenWidth != nWidth || m_pLinePos.p1.y != y1 || m_nPenStyle != nStyle || m_nLineStyle != nLineStyle || m_nCap !=nCap || m_nJoin !=nJoin)
	{
		toLineExport();
		setLinePath(x1, y1, x2, y2, sColor, nWidth, nStyle, nLineStyle, nCap, nJoin);
	}
	else
	{
		if(m_pLinePos.p2.x < x1 || x2 < m_pLinePos.p1.x)
		{
			toLineExport();
			setLinePath(x1, y1, x2, y2, sColor, nWidth, nStyle, nLineStyle, nCap, nJoin);
		}
		else
		{
			m_pLinePos.p1.x = BrMIN(m_pLinePos.p1.x, x1);
			m_pLinePos.p2.x = BrMAX(m_pLinePos.p2.x, x2);
		}			
	}
}

void BrExportDC::setLinePathFloat(BrFLOAT x1, BrFLOAT y1, BrFLOAT x2, BrFLOAT y2, BrCOLORREF sColor, BrINT nWidth, BrBYTE nStyle, BrBYTE nLineStyle, BrBYTE nCap, BrBYTE nJoin)
{
	m_cPenColor = sColor;
	m_nPenWidth = nWidth;
	m_nPenStyle = nStyle;
	m_nLineStyle = nLineStyle;
	m_nCap = nCap;
	m_nJoin = nJoin;

	m_pLinePos.p1.x = x1;
	m_pLinePos.p1.y = y1;
	m_pLinePos.p2.x = x2;
	m_pLinePos.p2.y = y2;	
	BR_SET_STATE(m_nExtFalg, eHasPathExtDCState);
}

void BrExportDC::updateLinePathFloat(BrFLOAT x1, BrFLOAT y1, BrFLOAT x2, BrFLOAT y2, BrCOLORREF sColor, BrINT nWidth, BrBYTE nStyle, BrBYTE nLineStyle, BrBYTE nCap, BrBYTE nJoin)
{
	if(sColor != m_cPenColor || m_nPenWidth != nWidth || m_pLinePos.p1.y != y1 || m_nPenStyle != nStyle || m_nLineStyle != nLineStyle || m_nCap !=nCap || m_nJoin !=nJoin)
	{
		toLineExport();
		setLinePathFloat(x1, y1, x2, y2, sColor, nWidth, nStyle, nLineStyle, nCap, nJoin);
	}
	else
	{
		if(m_pLinePos.p2.x < x1 || x2 < m_pLinePos.p1.x)
		{
			toLineExport();
			setLinePathFloat(x1, y1, x2, y2, sColor, nWidth, nStyle, nLineStyle, nCap, nJoin);
		}
		else
		{
			m_pLinePos.p1.x = BrMIN(m_pLinePos.p1.x, x1);
			m_pLinePos.p2.x = BrMAX(m_pLinePos.p2.x, x2);
		}			
	}
}

void BrExportDC::drawLine(BrDOUBLE x1, BrDOUBLE y1, BrDOUBLE x2, BrDOUBLE y2)
{
	if(BR_ISSET_STATE(m_nExtFalg, eHasDirectExtDCState) && !isNeedOutline())
	{
		doExport(0, 0, BrFALSE);

		if ( (m_pPen == BrNULL || m_pPen->m_sLogPen.nPenStyle == eNullPen) && BR_ISSET_STATE(m_nExtFalg, eHasClipPathExtDCState))
		{
			BR_REL_STATE(m_nExtFalg, eHasClipPathExtDCState);
			enforceEndClipPath();
			return;
		}

		else if( m_pPen == BrNULL || m_pPen->m_sLogPen.nPenStyle == eNullPen )
			return;
	
		BrCOLORREF sColor = BrRGB(m_pPen->m_sLogPen.nRed, m_pPen->m_sLogPen.nGreen, m_pPen->m_sLogPen.nBlue);

		BrINT nPenWidth = m_pPen->m_sLogPen.nWidth;
		if(getDCType() == ePDFExtDCType)
		{
			if(m_pPen->m_sLogPen.nPenType == eWaveHorizPen || m_pPen->m_sLogPen.nPenType == eWaveVertPen)
				nPenWidth = nPenWidth/2; // ������ ���Ʒ� ������ ������ ���õ�
			else
			{
				nPenWidth = m_pPen->getBaseLineWidthTwip();
				m_bIsTwipPenWidth = BrTRUE;
			}
		}

		// if(y1 == y2 && m_nFigureFlipType == eFigureFlipNone && m_pPen->m_sLogPen.nPenType != eGradientPen && !(m_pPen->isHasHeadArrow()|| m_pPen->isHasTailArrow())) //[2015.06.01][235] Arrow�� ������ ��� Export �ϵ��� ����
		if (y1 == y2 && m_nFigureFlipType == eFigureFlipNone && m_pPen->m_sLogPen.nPenType != eGradientPen && (!(m_pPen->isHasHeadArrow()|| m_pPen->isHasTailArrow()) && !BR_ISSET_STATE(m_nExtFalg, eHasClipPathExtDCState) ))
		{			
			if(BR_ISSET_STATE(m_nExtFalg, eHasPathExtDCState))
				updateLinePathFloat(x1, y1, x2, y2, sColor,nPenWidth, m_pPen->m_sLogPen.nPenStyle, m_pPen->m_sLogPen.nLineStyle, m_pPen->m_nLineCap, m_pPen->m_nLineJoin);
			else
				setLinePathFloat(x1, y1, x2, y2, sColor, nPenWidth, m_pPen->m_sLogPen.nPenStyle, m_pPen->m_sLogPen.nLineStyle, m_pPen->m_nLineCap, m_pPen->m_nLineJoin);
		}
		else 
		{
			if(BR_ISSET_STATE(m_nExtFalg, eHasClipPathExtDCState))
				BR_REL_STATE(m_nExtFalg, eHasClipPathExtDCState);

			BrFPOINT pos1 = {(BrFLOAT)x1, (BrFLOAT)y1};
			BrFPOINT pos2 = {(BrFLOAT)x2, (BrFLOAT)y2};	

			toLineExport();
			m_cPenColor = sColor;

			if(getDCType() == ePrintExtDCType) // print �� ������ baseline ���� �ʰ� ���� ��ƾ����
				m_nPenWidth = m_pPen->m_sLogPen.nWidth;
			else
				m_nPenWidth = m_pPen->getBaseLineWidthTwip();

			m_nPenStyle = m_pPen->m_sLogPen.nPenStyle;
			m_nLineStyle = m_pPen->m_sLogPen.nLineStyle;
			m_nCap = m_pPen->m_nLineCap;
			m_nJoin = m_pPen->m_nLineJoin;
			m_nPenType = m_pPen->m_sLogPen.nPenType;


			if (!(m_nPenType == eDiagonalLineVertPen || m_nPenType == eDiagonalLineHorizPen))
				toLineExport(&pos1, &pos2);
			else
				toSpecialLineExport(&pos1, &pos2);
		}
	}
	else
		BrDC::drawLine(x1, y1, x2, y2);
}

void BrExportDC::fillSolidRect(BrINT32 x1, BrINT32 y1, BrINT32 x2, BrINT32 y2, BrBYTE red, BrBYTE green, BrBYTE blue)
{
	if(BR_ISSET_STATE(m_nExtFalg, eHasDirectExtDCState) && !isNeedOutline())
	{
		BrCOLORREF sColor = BrRGB(red, green, blue);
		doExport(0, 0, BrTRUE);
		toFillSolidRectExport(x1, y1, x2, y2, sColor);
	}
	else
	{
		BR_SET_STATE(m_nExtFalg, eHasDataExtDCState);
		BrDC::fillSolidRect(x1, y1, x2, y2, red, green, blue);
	}
}

void BrExportDC::fillRect(BrINT32 x1, BrINT32 y1, BrINT32 x2, BrINT32 y2)
{
	if(BR_ISSET_STATE(m_nExtFalg, eHasDirectExtDCState) && !isNeedOutline())
	{
		//[zpd-22961][2015.12.22] ��ǥ�� normalize �ؼ� export 
		BRect rc(x1, y1, x2, y2);
		rc.NormalizeRect();
		x1 = rc.Left(); y1 = rc.Top(); x2 = rc.Right(); y2 = rc.Bottom();

		if(m_pBrush != BrNULL && m_pBrush->m_sLogBrush.m_iStyle != eNullBrush)
		{
			doExport(0, 0, BrTRUE);

			if(m_pBrush->m_sLogBrush.m_iStyle == eSolidBrush && !(m_sExtInfo.nRotateAngle%360))
			{
				BrCOLORREF cBrushColor = BrRGB(m_pBrush->m_sLogBrush.m_nRed, m_pBrush->m_sLogBrush.m_nGreen, m_pBrush->m_sLogBrush.m_nBlue);
				toFillSolidRectExport(x1, y1, x2, y2, cBrushColor);

			}
			else
			{
				BrRect rcFigureClip, rcFillClip;
				enableTemplateMode(BrTRUE, x2-x1, y2-y1, rcFigureClip, rcFillClip);
				if(m_pFigureClipBox)
					BR_RECT_MOVE_PTR(m_pFigureClipBox, -x1, -y1);
				if(m_pFillClipBox)
					BR_RECT_MOVE_PTR(m_pFillClipBox, -x1, -y1);

				//[2016.10.05][XPD-10899] ������ �ִ� �׶��̼� export
				BrDC:: enableAlphaBitmapDC(BrTRUE);
				BrDC:: fillRect(x1-x1, y1-y1, x2-x1, y2-y1);

				//[2014.12.06][ZPD-4997] ������ �� ȸ���� rect -> angle �� ���� �� ȸ�� �߽ɰ��� ���Ǿ� export �Ǿ�� �Ѵ�.
				if((m_sExtInfo.nRotateAngle%360))
				{
					BrPOINT sRotCPos = {(x2-x1)/2,(y2-y1)/2};
					doExport(x1, y1, BrFALSE, &sRotCPos);
				}
				else
					doExport(x1, y1, BrFALSE);
				enableTemplateMode(BrFALSE, 0, 0, rcFigureClip, rcFillClip);
			}				
		}
	}
	else
		BrDC:: fillRect(x1, y1, x2, y2);
}

void BrExportDC::rectangle(BrINT32 x1, BrINT32 y1, BrINT32 x2, BrINT32 y2, BrBOOL bFill)
{
	if(BR_ISSET_STATE(m_nExtFalg, eHasDirectExtDCState) && !isNeedOutline())
	{
		BrCOLORREF cBrushColor = -1;
		BrCOLORREF cPenColor = BrRGB(m_pPen->m_sLogPen.nRed, m_pPen->m_sLogPen.nGreen, m_pPen->m_sLogPen.nBlue);
		BrINT nRotAngle = m_sExtInfo.nRotateAngle%360;
		doExport(0, 0, BrTRUE);

		m_nPenWidth = m_pPen->m_sLogPen.nWidth;
		//m_cPenColor = cBrushColor;		//[dwchun : 2012.08.24] : Pen Color�� Pen ������...
		m_cPenColor = cPenColor;
		m_nPenStyle = m_pPen->m_sLogPen.nPenStyle;
		m_nLineStyle = m_pPen->m_sLogPen.nLineStyle;
				
		if(bFill || nRotAngle)
		{
			if(m_pBrush->m_sLogBrush.m_iStyle != eSolidBrush || nRotAngle)  
			{
				BrRect rcFigureClip, rcFillClip;
				enableTemplateMode(BrTRUE, x2-x1, y2-y1, rcFigureClip, rcFillClip);
				if(COLOR_OPAQUE != m_nSourceConstantAlpha)
					enableAlphaBitmapDC(BrTRUE);				
				if(m_pFigureClipBox)
					BR_RECT_MOVE_PTR(m_pFigureClipBox, -x1, -y1);
				if(m_pFillClipBox)
					BR_RECT_MOVE_PTR(m_pFillClipBox, -x1, -y1);				
				BrDC:: rectangle(x1-x1, y1-y1, x2-x1, y2-y1, bFill);

				if((m_sExtInfo.nRotateAngle%360))
				{
					BrPOINT sRotCPos = {(x2-x1)/2,(y2-y1)/2};
					doExport(x1, y1, BrFALSE, &sRotCPos);
				}
				else
					doExport(x1, y1, BrFALSE);

				if(COLOR_OPAQUE != m_nSourceConstantAlpha)
					enableAlphaBitmapDC(BrFALSE, BrTRUE);
				enableTemplateMode(BrFALSE, 0, 0, rcFigureClip, rcFillClip);				
				return;
			}

			cBrushColor = BrRGB(m_pBrush->m_sLogBrush.m_nRed, m_pBrush->m_sLogBrush.m_nGreen, m_pBrush->m_sLogBrush.m_nBlue);
		}
		toRectExport(x1, y1, x2, y2, cBrushColor, bFill);
	}
	else
	{
		BrDC::rectangle(x1, y1, x2, y2, bFill);
	}
}
BrINT32 BrExportDC::drawChars(BrULONG* strData, BrINT32 x, BrINT32 y, BrWORD* pGapX, BrINT32 strLen, BrBOOL bTwip/* = BrFALSE*/, LPBrCharGap pCharInterval, BrBOOL flipHorizontal)
{
	if(BR_ISSET_STATE(m_nExtFalg, eHasNoneDirectExtDCState))
	{
		BR_SET_STATE(m_nExtFalg, eHasDataExtDCState);
		return BrDC::drawChars(strData, x, y, pGapX,strLen);
	}
	if(BR_ISSET_STATE(m_nExtFalg, eHasDataExtDCState))
		toExport();

	return toExportChars4Bytes(strData, strLen, x, y, pGapX, bTwip, pCharInterval);
}

BrINT32 BrExportDC::drawChars(BString* strData, BrINT32 x, BrINT32 y, BrWORD* pGapX, BrBOOL bTwip/* = BrFALSE*/, LPBrCharGap pCharInterval, BrBOOL flipHorizontal)
{
	BTrace("%s(%d) %s strData->utf8()[%s]", __FILE__, __LINE__, __FUNCTION__, strData->utf8());	

	if(BR_ISSET_STATE(m_nExtFalg, eHasNoneDirectExtDCState))
	{
		BTrace("%s(%d) %s strData->utf8()[%s]", __FILE__, __LINE__, __FUNCTION__, strData->utf8());	

		BR_SET_STATE(m_nExtFalg, eHasDataExtDCState);
		return BrDC::drawChars(strData, x, y, pGapX);
	}
	if(BR_ISSET_STATE(m_nExtFalg, eHasDataExtDCState))
		toExport();

BTrace("%s(%d) %s strData->utf8()[%s]", __FILE__, __LINE__, __FUNCTION__, strData->utf8());	

	return toExportChars(strData, x, y, pGapX, bTwip, pCharInterval);
}

void BrExportDC::frameFigure(agg_scanline_p8 & sl, BrDOUBLE x1, BrDOUBLE y1, BrDOUBLE x2, BrDOUBLE y2, LPBrRect pFillBox)
{
	BR_SET_STATE(m_nExtFalg, eHasDataExtDCState);
	BrDC::frameFigure(sl, x1, y1, x2, y2, pFillBox);
}

void BrExportDC::fillFigure(agg_scanline_p8 & sl, BrDOUBLE x1, BrDOUBLE y1, BrDOUBLE x2, BrDOUBLE y2, BrBOOL bGradientCircle)
{
	BR_SET_STATE(m_nExtFalg, eHasDataExtDCState);
	BrDC::fillFigure(sl, x1, y1, x2, y2, bGradientCircle);
}

BrBOOL BrExportDC::bitBlt(BrINT32 dx, BrINT32 dy, BrINT32 dcx, BrINT32 dcy, LPBrBITMAPINFOHEADER lpbs, BrINT32 sx, BrINT32 sy, BrINT32 scx, BrINT32 scy, BrBOOL bScale, BrCOLORREF tColor, BrDWORD dwROP, BrMatrixExtension* pXYZTrans, LPBrBITMAPINFOHEADER lpba)

{
	if(BR_ISSET_STATE(m_nExtFalg, eHasDirectExtDCState) && !isNeedOutline())
	{		
		BrRect rect = {m_sExtInfo.nPosX+dx, m_sExtInfo.nPosY+dy, m_sExtInfo.nPosX+dcx+dx, m_sExtInfo.nPosY+dcy+dy};

		PrBitmap sBitmap;
		sBitmap.setDib(lpbs);
#ifndef USE_32BIT_IMAGE
		if(lpba)
			sBitmap.setMask(lpba);
#endif 
		doExport(0, 0, BrTRUE);				
		return doExportImage(&sBitmap, &rect, m_sExtInfo.nRotateAngle, BrNULL);
	}
	else
	{
		BrBOOL bRet = BrDC::bitBlt(dx, dy, dcx, dcy, lpbs, sx, sy, scx, scy, bScale, tColor, dwROP, pXYZTrans, lpba);
		if(bRet) BR_SET_STATE(m_nExtFalg, eHasDataExtDCState);
		return bRet;
	}	
}

BrBOOL BrExportDC::doExport(BrINT nPosX, BrINT nPosY, BrBOOL bExPath, BrPOINT* pRotAngleCPos)
{
	BrBOOL bRet = BrFALSE;
	if(m_pBitmap)
	{
		if(bExPath)
			toLineExport();
		if(BR_ISSET_STATE(m_nExtFalg, eHasDataExtDCState))
		{
			BrRect rect = {nPosX+m_sExtInfo.nPosX, nPosY+m_sExtInfo.nPosY, nPosX+m_sExtInfo.nPosX+m_cx, nPosY+m_sExtInfo.nPosY+m_cy};			

			BR_REL_STATE(m_nExtFalg, eHasDataExtDCState);
			if(pRotAngleCPos)
			{
				BrPOINT sRotCPos = {m_sExtInfo.nPosX + pRotAngleCPos->x, m_sExtInfo.nPosY + pRotAngleCPos->y};
				bRet = addImage(m_pBitmap, &rect, m_sExtInfo.nRotateAngle, &sRotCPos);
			}
			else
			{
				if(m_sExtInfo.nRotateAngle%360 != 0)
				{
					BrPOINT sRotCPos = {nPosX+m_sExtInfo.nPosX+(m_cx/2), nPosY+m_sExtInfo.nPosY+(m_cy/2)};	
					bRet = addImage(m_pBitmap, &rect, m_sExtInfo.nRotateAngle, &sRotCPos);
				}
				else
					bRet = addImage(m_pBitmap, &rect, m_sExtInfo.nRotateAngle, BrNULL);
			}
			clearByState();
		}
		else
			bRet = BrTRUE;
	}
	return bRet;
}

BrBOOL BrExportDC::doExportImage(PrBitmap * pImage, LPBrRect pPageRect, BrINT nAngle, BrPOINT* pRotAngleCPos)
{
	if(nAngle%360 && pRotAngleCPos)
		return addImage(pImage,pPageRect,nAngle, pRotAngleCPos);
	else
	{
		BrPOINT sRotCPos = {pPageRect->left + (pPageRect->right-pPageRect->left)/2, pPageRect->top + (pPageRect->bottom-pPageRect->top)/2};
		return addImage(pImage,pPageRect,nAngle, &sRotCPos);
	}
}

BrBOOL BrExportDC::toExport()
{
	return doExport(0, 0);
}

BrBOOL BrExportDC::toExport(BrINT nPosX, BrINT nPosY, BrPOINT* pRotAngleCPos)
{
	return doExport(nPosX, nPosY, BrTRUE, pRotAngleCPos);
}

void BrExportDC::setFontIncrementValue(BrINT nIndex)
{
	return setFontIncValue(nIndex);
}

void BrExportDC::setClipRect(BrRect *pRect)
{
	if(BR_ISSET_STATE(m_nExportState, eCreatedExtDCExportState))
	{
		BrBOOL bSetPageClip = BrFALSE;

		if(!BR_ISSET_STATE(m_nExtFalg, eHasNoneDirectExtDCState))
		{
			toExport();
		}	

		BrDC::setClipRect(pRect);

		if(!IsClipRect() && m_clipRect.left == 0 && m_clipRect.top == 0 && m_clipRect.right == m_cx && m_clipRect.bottom == m_cy 
			&& m_sExtInfo.nPosX == 0 && m_sExtInfo.nPosY == 0)
			bSetPageClip = BrTRUE;

		if(!bSetPageClip && pRect && !BRect::IsEmpty(*pRect))	
		{
			BrRect clipRect = {pRect->left+m_sExtInfo.nPosX, pRect->top+m_sExtInfo.nPosY, pRect->right+m_sExtInfo.nPosX, pRect->bottom+m_sExtInfo.nPosY};
			setClipRectExport(&clipRect);
		}
		else
		{
			BrRect clipRect = {m_rcPageClip.left, m_rcPageClip.top, m_rcPageClip.right, m_rcPageClip.bottom};		
			setClipRectExport(&clipRect);
		}	
	}
}


BRgn2* BrExportDC::setClipRgn(BRgn2* pRgn)
{	// [2016.03.18][235][ZPD-27434]
    // ODT������ ��� ǥ�� Border type���� ������ ��찡 �־���
	// Border type���� ���� ���, Direct Export Flag�� ���� ó���� ���� ���� ���·� border�� draw�ϴ� �������� clipRgn�� ȣ���ϴ� ��찡 ����
	// ������, setClipRgn call�� �� ���, NoneDirectExtDCState���¶�� ������ �����Ǿ��ִ� ��ü�� Export���ֵ��� ������ �־���, PDF / Print �������� setRgn �Լ��� setClipRgnExport()�� �и��Ͽ���
	BRgn2* pOldRgn = NULL;
	if(BR_ISSET_STATE(m_nExportState, eCreatedExtDCExportState))
	{
		if(!BR_ISSET_STATE(m_nExtFalg, eHasNoneDirectExtDCState))
		{
			toExport();
		}	

		pOldRgn = setClipRgnExport(pRgn);
	}

	return pOldRgn;
}
#define CALC_NEW_GAP(dNewGapX, dNewGapY, dXGap, dYGap, dMove, dOblique)	{ dNewGapX = dYGap * dMove/dOblique; dNewGapY = dXGap * dMove/dOblique; }
#define SET_LINE_INFO(sLineInfo, sx, sy, ex, ey, w)	(sLineInfo.nSx = sx, sLineInfo.nSy = sy, sLineInfo.nEx = ex, sLineInfo.nEy = ey, sLineInfo.nWidth = w)
#define MODIFY_NAA_WIDTH(dWidth)	{ dWidth = BrFloor(dWidth);	dWidth = BrMAX(1, dWidth); }
BrINT BrExportDC::getLineInfo(LPBrLINESTYLE_INFO& pLineInfo, LPBrFPOINT pPos1, LPBrFPOINT pPos2)
{
	BrBOOL bTwipUnit = BrFALSE;
	if (getDCType() == ePDFExtDCType)
		bTwipUnit = BrTRUE; // PDF�� ��� twip������ - 

	BrINT nPenWidth_1, nPenWidth_2, nPenWidth_3;
	BrDOUBLE dMove, dNewGapX1 = 0, dNewGapY1 = 0, dNewGapX2 = 0, dNewGapY2 = 0, dWidth1 = 0, dWidth2 = 0;
	BrDOUBLE dWidth = bTwipUnit ? twips2DeviceX(m_nPenWidth, getPainter()->getZoomScale(), getExportPDFRes()) : m_nPenWidth; 
	BrDOUBLE dXGap = 0, dYGap = 0, dOblique = 0, dGapWidth  = 0;
	BrINT nIdxCount = 0;
	nPenWidth_1 = nPenWidth_2 = nPenWidth_3 = m_nPenWidth;
	pPos1->x += (BrFLOAT)m_sExtInfo.nPosX;
	pPos1->y += (BrFLOAT)m_sExtInfo.nPosY;
	pPos2->x += (BrFLOAT)m_sExtInfo.nPosX;
	pPos2->y += (BrFLOAT)m_sExtInfo.nPosY;
	dXGap = pPos2->x - pPos1->x, dYGap = pPos2->y - pPos1->y, dOblique = sqrt(dXGap*dXGap + dYGap*dYGap);

	switch (m_nLineStyle)
	{
	case eSimple:
		{
			nIdxCount = 2;
			pLineInfo = (LPBrLINESTYLE_INFO) BrMalloc(BrSizeOf(BrLINESTYLE_INFO) * nIdxCount); // 2�� 
			SET_LINE_INFO(pLineInfo[0], pPos1->x, pPos1->y, pPos2->x, pPos2->y, nPenWidth_1);
			SET_LINE_INFO(pLineInfo[1], pPos1->x, pPos1->y, pPos2->x, pPos2->y, nPenWidth_1); // OrgLineInfo ����
		}
		break;
	case eDouble:
	case eThickThin:
	case eThinThick:
	case eThickThinSmallGap:
	case eThinThickSmallGap:
	case eThickThinLargeGap:
	case eThinThickLargeGap:
	case eUnfixedLineStyle:
		{
			nIdxCount = 3;
			pLineInfo = (LPBrLINESTYLE_INFO) BrMalloc(BrSizeOf(BrLINESTYLE_INFO) * nIdxCount); // 3��

			switch (m_nLineStyle)
			{
			case eDouble:
				{
					dGapWidth = dWidth / 3; // [2015.6.22][235] Print Export�ÿ� dGapWidth Size�� 1���� ���� ��� Pen Width�� 0���� �����ϹǷ�, �ּ� dGapWidth�� 1�� set�Ͽ� ���
					if (getDCType() == ePrintExtDCType)
						dGapWidth = BrMAX(1, dGapWidth);
					dWidth1 = dWidth2 = dMove = dGapWidth;

					CALC_NEW_GAP(dNewGapX1, dNewGapY1, dXGap, dYGap, dMove, dOblique);
					dNewGapX2 = dNewGapX1;
					dNewGapY2 = dNewGapY1;
				}
				break;
			case eThickThin:
			case eThinThick:
				{
					dGapWidth = dWidth / 5;
					if(m_nLineStyle == eThickThin)
					{
						dMove = (dWidth / 2) - (dGapWidth / 2);
						dWidth1 = dGapWidth;
					}
					else
					{
						dMove = (dWidth / 2) - (dGapWidth * 3 / 2);
						dWidth1 = dGapWidth * 3;
					}

					CALC_NEW_GAP(dNewGapX1, dNewGapY1, dXGap, dYGap, dMove, dOblique);

					if(m_nLineStyle == eThickThin)
					{
						dMove = (dWidth / 2) - (dGapWidth * 3 / 2);
						dWidth2 = dGapWidth * 3;
					}
					else
					{
						dMove = (dWidth / 2) - (dGapWidth / 2);
						dWidth2 = dGapWidth;
					}
					CALC_NEW_GAP(dNewGapX2, dNewGapY2, dXGap, dYGap, dMove, dOblique);
				}
				break;

			case eThickThinSmallGap:
			case eThinThickSmallGap:
				{
					dGapWidth = twips2DeviceX(15, m_pPen->getScaleFact(), getPainter()->m_iResX);
					dGapWidth = BrMAX(1, dGapWidth);

					if(m_nLineStyle == eThickThinSmallGap)
					{
						dMove = (dWidth / 2) - (dGapWidth / 2);
						dWidth1 = dGapWidth;
					}
					else
					{
						dMove = dGapWidth;
						dWidth1 = dWidth - (dGapWidth * 2);
					}
					CALC_NEW_GAP(dNewGapX1, dNewGapY1, dXGap, dYGap, dMove, dOblique);

					if(m_nLineStyle == eThickThinSmallGap)
					{
						dMove = dGapWidth;
						dWidth2 = dWidth - (dGapWidth * 2);
					}
					else
					{
						dMove = (dWidth / 2) - (dGapWidth / 2);
						dWidth2 = dGapWidth;
					}
					CALC_NEW_GAP(dNewGapX2, dNewGapY2, dXGap, dYGap, dMove, dOblique);
				}

				break;
			case eThickThinLargeGap:
			case eThinThickLargeGap:
				{
					dGapWidth = twips2DeviceX(15, m_pPen->getScaleFact(), getPainter()->m_iResX);
					dGapWidth = BrMAX(1, dGapWidth);

					if(m_nLineStyle == eThickThinLargeGap)
					{
						dMove = (dWidth / 2) - (dGapWidth / 2);
						dWidth1 = dGapWidth;
					}
					else
					{
						dMove = (dWidth / 2) - dGapWidth;
						dWidth1 = dGapWidth * 2;
					}
					CALC_NEW_GAP(dNewGapX1, dNewGapY1, dXGap, dYGap, dMove, dOblique);

					if(m_nLineStyle == eThickThinLargeGap)
					{
						dMove = (dWidth / 2) - dGapWidth;
						dWidth2 = dGapWidth * 2;
					}
					else
					{
						dMove = (dWidth / 2) - (dGapWidth / 2);
						dWidth2 = dGapWidth;
					}
					CALC_NEW_GAP(dNewGapX2, dNewGapY2, dXGap, dYGap, dMove, dOblique);
				}
				break;

			case eUnfixedLineStyle:
				{
					LPBrUSERLINESTYLEINFO pUserLineStyleInfo = m_pPen->getUserLineStyleInfo();

					dWidth = pUserLineStyleInfo->nOuterWidth + pUserLineStyleInfo->nInnerWidth + pUserLineStyleInfo->nGap;
					dGapWidth = pUserLineStyleInfo->nGap;

					dMove = (dWidth / 2) - (dGapWidth / 2);
					dWidth1 = pUserLineStyleInfo->nInnerWidth;

					CALC_NEW_GAP(dNewGapX1, dNewGapY1, dXGap, dYGap, dMove, dOblique);

					dMove = dGapWidth;
					dWidth2 = pUserLineStyleInfo->nOuterWidth;

					CALC_NEW_GAP(dNewGapX2, dNewGapY2, dXGap, dYGap, dMove, dOblique);
				}

				break;

			default:
				break;
			}
			if (bTwipUnit) {
				nPenWidth_1 = Device2twips(dWidth1, getPainter()->getZoomScale(), getExportPDFRes());
				nPenWidth_2 = Device2twips(dWidth2, getPainter()->getZoomScale(), getExportPDFRes());
			}
			else
			{
				nPenWidth_1 = dWidth1;
				nPenWidth_2 = dWidth2;
			}
			
			SET_LINE_INFO(pLineInfo[0], pPos1->x - dNewGapX1 , pPos1->y + dNewGapY1, pPos1->x - dNewGapX1 + dXGap, pPos1->y + dNewGapY1 + dYGap, nPenWidth_1);
			SET_LINE_INFO(pLineInfo[1], pPos1->x + dNewGapX2 , pPos1->y - dNewGapY2, pPos1->x + dNewGapX2 + dXGap, pPos1->y - dNewGapY2 + dYGap, nPenWidth_2);
			SET_LINE_INFO(pLineInfo[2], pPos1->x, pPos1->y, pPos2->x, pPos2->y, m_nPenWidth); // OrgLineInfo ����
		}
		break;

	case eTriple:
	case eTripleEqual:
	case eTripleSmallGap:
	case eTripleLargeGap:
		{
			nIdxCount = 4; 
			pLineInfo = (LPBrLINESTYLE_INFO)BrMalloc(BrSizeOf(BrLINESTYLE_INFO) * nIdxCount); // 4��
			if(pLineInfo)
			{
				BrDOUBLE dWidthC = 0;
				switch(m_nLineStyle)
				{
				case eTriple:
					dGapWidth = dWidth / 6;
					dMove = (dWidth / 2) - (dGapWidth / 2);
					dWidth1 = dGapWidth;
					CALC_NEW_GAP(dNewGapX1, dNewGapY1, dXGap, dYGap, dMove, dOblique);
					dWidthC = dGapWidth * 2;
					dWidth2 = dGapWidth;
					dNewGapX2 = dNewGapX1;
					dNewGapY2 = dNewGapY1;
					break;
				case eTripleEqual:
					dGapWidth = dWidth / 5;
					if (getDCType() == ePrintExtDCType) // [2015.6.22][235] Print Export�ÿ� dGapWidth Size�� 1���� ���� ��� Pen Width�� 0���� ����(E.g�� Int Type)�ϹǷ�, �ּ� dGapWidth�� 1�� set
						dGapWidth = BrMAX(1, dGapWidth);

					dMove = dGapWidth * 2;
					dWidth1 = dGapWidth;
					CALC_NEW_GAP(dNewGapX1, dNewGapY1, dXGap, dYGap, dMove, dOblique);
					dWidthC = dGapWidth;
					dWidth2 = dGapWidth;
					dNewGapX2 = dNewGapX1;
					dNewGapY2 = dNewGapY1;
					break;
				case eTripleSmallGap:
				case eTripleLargeGap:
					dGapWidth = twips2DeviceX(15, m_pPen->getScaleFact(), getPainter()->m_iResX);
					dGapWidth = BrMAX(1, dGapWidth);

					dMove = (dWidth / 2) - (dGapWidth / 2);
					dWidth1 = dGapWidth;
					CALC_NEW_GAP(dNewGapX1, dNewGapY1, dXGap, dYGap, dMove, dOblique);
					if(m_nLineStyle == eTripleSmallGap)
						dWidthC = dWidth - (dGapWidth * 4);
					else
						dWidthC = dGapWidth * 2;
					dWidth2 = dGapWidth;
					dNewGapX2 = dNewGapX1;
					dNewGapY2 = dNewGapY1;
					break;
				}

				if (bTwipUnit) {
					nPenWidth_1 = Device2twips(dWidth1, getPainter()->getZoomScale(), getExportPDFRes());
					nPenWidth_2 = Device2twips(dWidthC, getPainter()->getZoomScale(), getExportPDFRes());
					nPenWidth_3 = Device2twips(dWidth2, getPainter()->getZoomScale(), getExportPDFRes());
				}

				else
				{
					//nPenWidth_1 = dWidth1 >=1 ? dWidth1 : 1;
					//nPenWidth_2 = dWidthC >=1 ? dWidthC : 1;
					//nPenWidth_3 = dWidth2 >=1 ? dWidth2 : 1;
					nPenWidth_1 = dWidth1;
					nPenWidth_2 = dWidthC;
					nPenWidth_3 = dWidth2;
				}

				if(BR_ISSET_STATE(m_nState, eNoAntialiasDCState))
				{
					MODIFY_NAA_WIDTH(dWidth1);
					MODIFY_NAA_WIDTH(dWidthC);
					MODIFY_NAA_WIDTH(dWidth2);
					MODIFY_NAA_WIDTH(m_nPenWidth);
					SET_LINE_INFO(pLineInfo[0], BrFRound(pPos1->x - dNewGapX1) , BrFRound(pPos1->y + dNewGapY1), BrFRound(pPos1->x - dNewGapX1 + dXGap), BrFRound(pPos1->y + dNewGapY1 + dYGap), nPenWidth_1);
					SET_LINE_INFO(pLineInfo[1], pPos1->x, pPos1->y, pPos2->x, pPos2->y, nPenWidth_2);
					SET_LINE_INFO(pLineInfo[2], BrFRound(pPos1->x + dNewGapX2), BrFRound(pPos1->y - dNewGapY2), BrFRound(pPos1->x + dNewGapX2+dXGap), BrFRound(pPos1->y - dNewGapY2 + dYGap), nPenWidth_3);
					SET_LINE_INFO(pLineInfo[3], pPos1->x, pPos1->y, pPos2->x, pPos2->y, m_nPenWidth); // OrgLineInfo ����
				}
				else
				{
					SET_LINE_INFO(pLineInfo[0], pPos1->x - dNewGapX1 , pPos1->y + dNewGapY1, pPos1->x - dNewGapX1 + dXGap, pPos1->y + dNewGapY1 + dYGap, nPenWidth_1);
					SET_LINE_INFO(pLineInfo[1], pPos1->x, pPos1->y, pPos2->x, pPos2->y, nPenWidth_2);
					SET_LINE_INFO(pLineInfo[2], pPos1->x + dNewGapX2 , pPos1->y - dNewGapY2, pPos1->x + dNewGapX2 + dXGap, pPos1->y - dNewGapY2 + dYGap, nPenWidth_3);
					SET_LINE_INFO(pLineInfo[3], pPos1->x, pPos1->y, pPos2->x, pPos2->y, m_nPenWidth); // OrgLineInfo ����
				}
			}
		}
		break;
	default:
		break;
	}

	return nIdxCount;
}


#ifdef USE_EXT_PRINT_2_0
BrBOOL BrExportDC::doExportXImage(LPBoraXImage pXImage, LPBrRect pImageRect, LPBrRect pPageRect, BrINT nAngle, BrPOINT* pRotAngleCPos)
{
	if(nAngle%360 && pRotAngleCPos)
		return addXImage(pXImage, pImageRect, pPageRect,nAngle, pRotAngleCPos);
	else
	{
		BrPOINT sRotCPos = {pPageRect->left + (pPageRect->right-pPageRect->left)/2, pPageRect->top + (pPageRect->bottom-pPageRect->top)/2};
		return addXImage(pXImage, pImageRect, pPageRect, nAngle, &sRotCPos);
	}
}

BrBOOL BrExportDC::extStretchBlt(BrINT32 dx, BrINT32 dy, BrINT32 dcx, BrINT32 dcy, LPBoraXImage pXImage, BrINT32 sx, BrINT32 sy, BrINT32 scx, BrINT32 scy)
{
	BrRect rcPage = {m_sExtInfo.nPosX+dx, m_sExtInfo.nPosY+dy, m_sExtInfo.nPosX+dcx+dx, m_sExtInfo.nPosY+dcy+dy};
	BrRect rcImage = {sx, sy, scx, scy};
	doExport(0, 0, BrTRUE);				

	return doExportXImage(pXImage, &rcImage, &rcPage, m_sExtInfo.nRotateAngle, BrNULL);

}
#endif //USE_EXT_PRINT_2_0