#include <OfficePreComp.hpp>

#include "brexportpdfdc.h"
#include "bexportpdffont.h"
#include "PDFExportFilterApi.h"
#include "painter.h"
#include "butil.h"
#include "binterfacehandle.h"
#include "bwpObjApi.h"

BrExportPDFDC::BrExportPDFDC()
{	
	m_pExtFont = BrNEW BExportPDFFont(m_pDCFont);	
	m_bPreblended = BrFALSE;
}

BrExportPDFDC::~BrExportPDFDC()
{
}

BrBOOL BrExportPDFDC::openExport(BrCHAR* pPDFPath, LPBrRect pMaxPageRect, BrINT nExpectedTotalPage, BrBOOL bPDFAExport)
{
	BR_SET_STATE(m_nExportState, eOpenExtDCExportState);
	return poExport_Open(pPDFPath, pMaxPageRect, nExpectedTotalPage, bPDFAExport);
}

void BrExportPDFDC::closeExport(BrBOOL bSave)
{
	if(BR_ISSET_STATE(m_nExportState, eOpenExtDCExportState))
	{
		poExport_Close(bSave);
		BR_REL_STATE(m_nExportState, eOpenExtDCExportState);
	}
}

void BrExportPDFDC::cancelExport()
{
	if(BR_ISSET_STATE(m_nExportState, eOpenExtDCExportState))
	{
		poExport_Close(BrFALSE);
		BR_REL_STATE(m_nExportState, eOpenExtDCExportState);
	}	
}

void BrExportPDFDC::setBottomWaterMark(BrBOOL bBottomWaterMark)
{
	poExport_BottomWaterMark(bBottomWaterMark);
}

void BrExportPDFDC::setRemoveHyperLink(BrBOOL bRemoveHyperLink)
{
	poExport_SetRemoveHyperLink(bRemoveHyperLink);
}

BrBOOL BrExportPDFDC::getRemoveHyperLink() const
{
	return poExport_GetRemoveHyperLink();
}


void BrExportPDFDC::setFilepath(BrCHAR* pPDFPath)
{
	memset(filepath, 0, sizeof(filepath));
	strncpy_s(filepath, sizeof(filepath), pPDFPath, strlen(pPDFPath));
}

const BrCHAR* BrExportPDFDC::getFilepath()
{
	return filepath;
}

BrBOOL BrExportPDFDC::createExportPage(LPBrSize pPageSize, BrINT /*nResFactor*/)
{
	if(poExport_CreatePage(pPageSize))
	{
		BR_SET_RECT(m_rcPageClip, 0, 0, pPageSize->cx, pPageSize->cy);	
		BR_SET_RECT(m_rcExtClip, 0, 0, pPageSize->cx, pPageSize->cy);
		BR_SET_STATE(m_nExportState, eCreatedExtDCExportState);
		return BrTRUE;
	}
	return BrFALSE;
}

BrBOOL BrExportPDFDC::closeExportPage(BrINT nOrgX, BrINT nOrgY)
{
	BrBOOL ret = BrFALSE;
	if(BR_ISSET_STATE(m_nExportState, eCreatedExtDCExportState))
	{
		ret = poExport_ClosePage();	
		BrBOOL bRemoveHyperLink = getRemoveHyperLink();
		if(ret && !bRemoveHyperLink)
		{
			if(BrIsSheetDocType())
			{
				// [LQQ-9932] ��Ʈ ������ ��� ���� Ư���� �Ʒ��� ���� ��ƾ��� ����Ǵ� ��� ������ �߻��Ͽ� �б� ó����
				// 1. getTotalPages() ���Ϲ޴� ������ ������(��) ������ �μ�/PDF �������� �Ǵ� ������ ������ �ٸ�
				// 2. ������ ��Ʈ���� ���鶧���� ������ ������ �����۸�ũ ������ �����ϰ� ���� ������
				addHyperLink(poExport_GetCurPageNum() + 1);
			}
			else
			{
				BrINT nTotalPageCnt = getTotalPages();
				if(poExport_GetCurPageNum() + 1 == nTotalPageCnt)
				{
					for(BrINT i = 1; i<nTotalPageCnt+1; i++)
						addHyperLink(i, nOrgX, nOrgY);
				}
			}
		}

	}
	intPageEnv();

	return ret;
}

void BrExportPDFDC::addHyperLink(BrINT nPageNum, BrINT nOrgX, BrINT nOrgY)
{
	//[ELH-146][2015.01.22] �����۸�ũ pdf export ��� �߰�
	//Hyperlink ������ ������ ������ ��� ������ �Ǿ� �־�, ������ drawing�� ������ close page ������ �����۸�ũ �Ӽ��� ��������.

	BrINT nCnt = BrGetHyperLinkCntOfPage(nPageNum);
	if(nCnt) // if hyperlink exist
	{
		BoraHyperLinkInfo* arrHyperLinkInfo = (BoraHyperLinkInfo*)BrMalloc(BrSizeOf(BoraHyperLinkInfo) * nCnt);
		if(!arrHyperLinkInfo) return;
		memset(arrHyperLinkInfo, 0, BrSizeOf(BoraHyperLinkInfo) * nCnt);

		BrINT nRet = BrGetHyperLinkInfoOfPage(nPageNum, arrHyperLinkInfo, nCnt, BrTRUE);
		if(nRet)
		{
			for(BrINT n=0; n<nCnt; n++)
			{
				BoraHyperlinkInfo PDFHyperLinkInfo = {TYPE_GOTO, 
					arrHyperLinkInfo[n].rcArea.left + nOrgX, arrHyperLinkInfo[n].rcArea.top + nOrgY, arrHyperLinkInfo[n].rcArea.right + nOrgX, arrHyperLinkInfo[n].rcArea.bottom + nOrgY,nPageNum-1,
					arrHyperLinkInfo[n].nPageNum-1, arrHyperLinkInfo[n].nTargetXPos + nOrgX, arrHyperLinkInfo[n].nTargetYPos + nOrgY, arrHyperLinkInfo[n].szTarget};

				BrINT nLinkType = arrHyperLinkInfo[n].nLinkType;
				if((nLinkType == LINK_TO_URL) || (nLinkType == LINK_TO_EMAIL) || (nLinkType == LINK_TO_MEMO) || (nLinkType == LINK_TO_TEL))
					PDFHyperLinkInfo.nType = TYPE_URI;

				poExport_AddHyperLink(&PDFHyperLinkInfo);
			}
		}
		if(arrHyperLinkInfo)
			BR_SAFE_FREE(arrHyperLinkInfo);
	}		
	return;
}

void BrExportPDFDC::setPenAtt(BrINT nWidth, BrCOLORREF cColor, BrBYTE nStyle, BrBYTE nCap, BrBYTE nJoin)
{
	//[2016.09.21][CAM-4582] update������ �����ʰ� �ٷ� export ���Ѿ��� ��쿡 ���� twip�� ����ó��
	BrBOOL bIsOldTwipPenWidth = BrFALSE;
	if(m_bIsTwipPenWidth)
		bIsOldTwipPenWidth = poExport_SetPenWidthTwip(m_bIsTwipPenWidth); // [2015.06.08][235] Ellipse Export�� PenWidth�� Twip ������ �׸����� ����

	poExport_SetPenAtt(nWidth, cColor, nStyle, nCap, nJoin);

	poExport_SetPenWidthTwip(bIsOldTwipPenWidth);
}

void BrExportPDFDC::setNullBrush()
{
	//	m_pBrush->m_sLogBrush.m_iStyle = eNullBrush;
	poExport_ClearBrush();
}

void BrExportPDFDC::setBrushColor(BrCOLORREF cColor)
{
	poExport_SetBrushColor(cColor);
}

void BrExportPDFDC::setImageBrushByType()
{
	BrBOOL bEnableRotate = m_pBrush->isEnableRotate();

	if(m_pBrush->m_sLogBrush.m_iStyle == ePatternBrush)
	{
		rendering_buffer* pRendBuff = m_pBrush->getRenderBuffer();

		PrBitmap sBitmap;
		sBitmap.createBitmap(pRendBuff->width(), pRendBuff->height(), (BrBYTE *)pRendBuff->buf(), pRendBuff->bitcount());	
		poExport_SetImagePatternBrush( sBitmap.getDib(), BrNULL, 100, 100, eDIBPatternFlipNone, bEnableRotate);
	}
	else if(m_pBrush->m_sLogBrush.m_iStyle == eDIBBrush || m_pBrush->m_sLogBrush.m_iStyle == eDIBPatternBrush)
	{
		rendering_buffer* pRendBuff = m_pBrush->getRenderBuffer();
		LPBrBITMAPINFOHEADER pDIB = (LPBrBITMAPINFOHEADER)pRendBuff->getDIB();
		BrBYTE* pAlpha = (BrBYTE*)pRendBuff->amask(0);

		if(m_pBrush->m_sLogBrush.m_iStyle == eDIBBrush)
			poExport_SetImageBrush(pDIB, pAlpha, m_pBrush->isRatioFixed(), bEnableRotate);
		else
		{
			BrLOGDIBPATTERNBRUSH sPatternInfo = m_pBrush->getDibPatternInfo();
			BrFPOINT sScaleRatio = { sPatternInfo.fScaleX*0.01f, sPatternInfo.fScaleY*0.01f };	
#ifdef IMPORT_PDF
			BrSize sFillSize = { m_sExtInfo.nPosW, m_sExtInfo.nPosH };
			if(m_pFillClipBox)
			{
				sFillSize.cx = m_pFillClipBox->right - m_pFillClipBox->left;
				sFillSize.cy = m_pFillClipBox->bottom - m_pFillClipBox->top;
			}	
			sFillSize.cx = twips2DeviceX(Device2twips(sFillSize.cx, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
			sFillSize.cy = twips2DeviceY(Device2twips(sFillSize.cy, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, 0, TARGET_DEVICE_RESOLUTION);
			BrPoint sOffset = m_pBrush->getDIBPatternAdjustOffset(sFillSize.cx, sFillSize.cy, pDIB->biWidth*sScaleRatio.x, pDIB->biHeight*sScaleRatio.y, sPatternInfo.ptOffset, sPatternInfo.nAdjust);
			poExport_SetImagePatternBrush(pDIB, pAlpha, sPatternInfo.fScaleX, sPatternInfo.fScaleY, sPatternInfo.nFlipType, bEnableRotate, &sOffset);
#endif
		}		
	}
}

void BrExportPDFDC::SetGState(LPBoraOpacity pGsInfo)
{
	poExport_SetGState(pGsInfo->nFillOpacity, pGsInfo->nStrokeOpacity);
}	

void BrExportPDFDC::SetFlipType(BrBYTE nFlipType)
{
	poExport_SetFlipType(nFlipType);
}
void BrExportPDFDC::SetFillType(BrBYTE nFillType)
{
	poExport_SetFillType(nFillType);
}

void BrExportPDFDC::SetRotateAngle(BrINT nAngle)
{
	poExport_SetRotateAngle(nAngle);
}


BrFLOAT BrExportPDFDC::toExportChars4Bytes(BrULONG* strData, BrINT strLen, BrFLOAT x, BrFLOAT y, BrWORD* pGapX, BrBOOL bTwip/* = BrFALSE*/, LPBrCharGap pCharInterval)
{
	BrFLOAT nRet = 0;
	BrFPOINT sPos = {m_sExtInfo.nPosX+x, m_sExtInfo.nPosY+y};	
	BrFPOINT cPos = {(BrFLOAT)(m_sExtInfo.nPosX + m_sExtInfo.nPosW / 2.0f), (BrFLOAT)(m_sExtInfo.nPosY + m_sExtInfo.nPosH / 2.0f)};
	nRet = m_pExtFont->toExport4Bytes(getDCType(), strData, strLen, &sPos, &cPos, pGapX, m_sExtInfo.nTxtRotAngle+m_sExtInfo.nRotateAngle,BrTRUE, bTwip, pCharInterval);
	return nRet;
}
BrFLOAT BrExportPDFDC::toExportChars(BString* strData, BrFLOAT x, BrFLOAT y, BrWORD* pGapX, BrBOOL bTwip/* = BrFALSE*/, LPBrCharGap pCharInterval)
{
	BrFLOAT nRet = 0;
	BrFPOINT sPos = {m_sExtInfo.nPosX+x, m_sExtInfo.nPosY+y};	
	BrFPOINT cPos = { (BrFLOAT)(m_sExtInfo.nPosX + m_sExtInfo.nPosW / 2.0f), (BrFLOAT)(m_sExtInfo.nPosY + m_sExtInfo.nPosH / 2.0f)};
	nRet = m_pExtFont->toExport(getDCType(), strData, &sPos, &cPos, pGapX, m_sExtInfo.nTxtRotAngle+m_sExtInfo.nRotateAngle,BrTRUE, bTwip, pCharInterval);
	return nRet;
}

#if 0 // OLD_CODE, ���� �� �� �ֵ��� �ڵ� �������� ����
BrRect BrExportPDFDC::setClipRectExport(BrRect* pRect)
{
	toExport();
	return m_rcExtClip;
}
#endif //

void BrExportPDFDC::setClipRectExport(BrRect* pRect)
{
	poExport_SetClipRect(pRect);
}

BRgn2* BrExportPDFDC::setClipRgnExport(BRgn2* pRgn)
{
	BRgn2* pOldRgn = BrNULL;
	BRgn2* pExtRgn = pRgn;

	pOldRgn = BrDC::setClipRgn(pRgn);

	BrUINT32 nLen = pExtRgn->getRgnPathArraySize();

	if(nLen > 0)
	{
		poExport_BeginClipPath();

		for(BrINT i = 0; i<nLen; i++)
		{
			BRgnPathArray* pExtPathArray = pExtRgn->getRgnPathArray(i);

			LPBrLOGRGNPATH pExtRgnPath = BrNULL;
			pExtRgnPath = pExtPathArray->GetAt(i);

			switch(pExtRgnPath->nType)
			{
			case eRectRgnPath:
				{
					LPBrBASEOBJPATH pPath = (LPBrBASEOBJPATH)pExtRgnPath->pPath;
					BrFPOINT sStartPos = {(BrFLOAT)(pPath->left + m_sExtInfo.nPosX), (BrFLOAT)(pPath->top + m_sExtInfo.nPosY)};
					BrFPOINT sToPos = {0,};

					poExport_MoveTo(&sStartPos);
					sToPos.x = pPath->right + m_sExtInfo.nPosX, sToPos.y = pPath->top + m_sExtInfo.nPosY;
					poExport_LineTo(&sToPos);
					sToPos.y = pPath->bottom + m_sExtInfo.nPosY;
					poExport_LineTo(&sToPos);
					sToPos.x = pPath->left + m_sExtInfo.nPosX;
					poExport_LineTo(&sToPos);
					poExport_LineTo(&sStartPos);
				}
				break;
			case eEllipticRgnPath:
				{
					LPBrRRECTOBJPATH pPath = (LPBrRRECTOBJPATH)pExtRgnPath->pPath;
					BrFRect rect = {(BrFLOAT)(pPath->left+m_sExtInfo.nPosX), (BrFLOAT)(pPath->top+m_sExtInfo.nPosY), (BrFLOAT)(pPath->right+m_sExtInfo.nPosX), (BrFLOAT)(pPath->bottom+m_sExtInfo.nPosY)};
					poExport_Ellipse(rect.left, rect.top, rect.right, rect.bottom, BrFALSE, BrTRUE);
				}
				break;

			case eRoundRectRgnPath:
				{
					LPBrRRECTOBJPATH pPath = (LPBrRRECTOBJPATH)pExtRgnPath->pPath; 
					BrDOUBLE sX1 = pPath->left + m_sExtInfo.nPosX; BrDOUBLE sY1 = pPath->top + m_sExtInfo.nPosY;  
					BrDOUBLE sX2 = pPath->right + m_sExtInfo.nPosX;  BrDOUBLE sY2 = pPath->bottom + m_sExtInfo.nPosY;
					BrDOUBLE rHeight = pPath->rHeight; BrDOUBLE rWidth = pPath->rWidth;
					BrFPOINT sToPos = {0,0}, sStartPos = {0, 0};
					BrFLOAT centerX, centerY;
					BrFRect newFRect[4] = { {(BrFLOAT)sX1, (BrFLOAT)sY1, (BrFLOAT)(sX1 + rWidth), (BrFLOAT)(sY1 + rHeight)},  // 0��° �簢��
										  {(BrFLOAT)(sX2 - rWidth), (BrFLOAT)sY1, (BrFLOAT)sX2, (BrFLOAT)(sY1 + rHeight)}, 
										  {(BrFLOAT)(sX2 - rWidth), (BrFLOAT)(sY2 - rHeight), (BrFLOAT)sX2, (BrFLOAT)sY2},
										  {(BrFLOAT)sX1, (BrFLOAT)(sY2 - rHeight), (BrFLOAT)(sX1 + rWidth), (BrFLOAT)sY2} }; // 3��° �簢��

					
					for (BrINT32 i = 0 ; i < 4 ; i++) {
						centerX = newFRect[i].left + ((newFRect[i].right - newFRect[i].left) / 2);
						centerY = newFRect[i].bottom + ((newFRect[i].top - newFRect[i].bottom) / 2);

						switch (i)
						{
						
						case 0:
							sToPos.x = newFRect[i].left; sToPos.y = centerY;
							poExport_MoveTo(&sToPos);
							sStartPos = sToPos;
							poExport_ArcTo(&newFRect[i], 180, 90, BrFALSE, BrFALSE, BrTRUE, -1);
							break;

						case 1:
							sToPos.x = centerX; sToPos.y = newFRect[i].top;
							poExport_LineTo(&sToPos);
							poExport_ArcTo(&newFRect[i], 90, 0, BrFALSE, BrFALSE, BrTRUE, -1);
							break;
							
						case 2:
							sToPos.x = newFRect[i].right; sToPos.y = centerY;
							poExport_LineTo(&sToPos);
							poExport_ArcTo(&newFRect[i], 0, 270, BrFALSE, BrFALSE, BrTRUE, -1);
							break;

						case 3:
							sToPos.x = centerX; sToPos.y = newFRect[i].bottom;
							poExport_LineTo(&sToPos);
							poExport_ArcTo(&newFRect[i], 270, 180, BrFALSE, BrFALSE, BrTRUE, -1);
							poExport_LineTo(&sStartPos);
							break;

						default:
							break;
						}
					}
				}
				break;

			case ePolygonRgnPath:
				{
					LPBrPOLYGONOBJPATH pPath = (LPBrPOLYGONOBJPATH)pExtRgnPath->pPath;								
					BrFPOINT sStartPos = {0,};
					BrFPOINT sToPos = {0,};


					if(pPath->count != 0)
					{
						sStartPos.x = pPath->lpp[0].x + m_sExtInfo.nPosX;
						sStartPos.y = pPath->lpp[0].y + m_sExtInfo.nPosY;
						poExport_MoveTo(&sStartPos, BrTRUE);

						for(BrINT j = 1; j < pPath->count; j++)
						{
							sToPos.x = pPath->lpp[j].x + m_sExtInfo.nPosX;
							sToPos.y = pPath->lpp[j].y + m_sExtInfo.nPosY;
							poExport_LineTo(&sToPos, BrFALSE, BrTRUE);
						}

						poExport_LineTo(&sStartPos, BrFALSE, BrTRUE);
					}

				}
				break;

			case ePolyPolygonRgnPath:
				{
					BrFPOINT sStartPos = {0,};
					BrFPOINT sToPos = {0,};
					LPBrPOLYPOLYGONOBJPATH pPath = (LPBrPOLYPOLYGONOBJPATH)pExtRgnPath->pPath;
					LPBrPOINT pPoints = pPath->lpp;
					BrLPWORD pLpi = pPath->lpi;

					for (BrINT i = 0; i < pPath->count ; i++) {
						sStartPos.x = pPoints[0].x +  + m_sExtInfo.nPosX; sStartPos.y = pPoints[0].y + m_sExtInfo.nPosX;
						poExport_MoveTo(&sStartPos);

						for (BrINT j = 1; j < pLpi[i] ; j++) {
							sToPos.x = pPoints[j].x +  + m_sExtInfo.nPosX; sToPos.y = pPoints[j].y +  + m_sExtInfo.nPosX;
							poExport_LineTo(&sToPos);
						}

						poExport_LineTo(&sStartPos);
						pPoints += pLpi[i];
					}	
				}
				break;

#if 0 //���� ����
			case eObjPathRgnPath:
				break;
			case eStorageRgnPath:
				break;
#endif //���� ����
			}
		}

		poExport_EndClipPath(FILLPOLYGON_WINDING);
		BR_SET_STATE(m_nExtFalg, eHasClipPathExtDCState);
	}
	else
	{
		BrFPOINT sToPos = {0,};
		poExport_BeginClipPath();
		sToPos.x = m_rcExtClip.left; sToPos.y = m_rcExtClip.top;
		poExport_MoveTo(&sToPos);

		sToPos.x = m_rcExtClip.right; sToPos.y = m_rcExtClip.top; 
		poExport_LineTo(&sToPos);

		sToPos.x = m_rcExtClip.right; sToPos.y = m_rcExtClip.bottom; 
		poExport_LineTo(&sToPos);

		sToPos.x = m_rcExtClip.left; sToPos.y = m_rcExtClip.bottom; 
		poExport_LineTo(&sToPos);

		sToPos.x = m_rcExtClip.left; sToPos.y = m_rcExtClip.top; 
		poExport_LineTo(&sToPos);

		poExport_EndClipPath(FILLPOLYGON_WINDING);

		return BrNULL;
	}
			
	return pOldRgn;
}

#include "brDrawUnit.h"

void setArrowPoint(BrBmvPen *pPen, LPBrLOGARROW pArrowInfo, BrFPOINT ArrowPos[4], BrFPOINT sArrowPoint1, BrFPOINT sArrowPoint2)
{
	// sArrowPoint1, sArrowPoint2 �� ���� ȭ��ǥ�� ������ ��� �ϰ� �� ������ ������ ȭ��ǥ�� ��ǥ�� rotate�Ѵ�.

	BrINT nAngle =BrRADtoDEG(atan2(sArrowPoint1.y-sArrowPoint2.y, sArrowPoint1.x-sArrowPoint2.x));

	BrDOUBLE dHeadRadius, dWingRadius, dTailRadius;
	pPen->getArrowInfo(pPen->getBaseLineWidth(), pPen->getLineWidth(), pArrowInfo, pPen->getScaleFact(), &dHeadRadius, &dWingRadius, (pArrowInfo->nArrowType == eLineArrowStealth)? &dTailRadius:BrNULL);

	BrDOUBLE dA0 = pPen->getArrowOpenMovePoint(pPen->getLineWidth(), pArrowInfo);
	BrDOUBLE a0=0;
	BrDOUBLE a1=0;
	BrDOUBLE a2=0;

	BrFLOAT nCenterX = sArrowPoint2.x;
	BrFLOAT nCenterY = sArrowPoint2.y;

	switch(pArrowInfo->nArrowType)
	{
	case eLineArrowOpen:
		{
			a0 = dA0;
			a1 = dHeadRadius+dA0;
			a2 = dWingRadius;

			ArrowPos[0].x = sArrowPoint2.x + a1;	
			ArrowPos[0].y = sArrowPoint2.y - a2; //Moveto(a1, -a2);
			BrDrawUnit::rotatePoint(nAngle, nCenterX, nCenterY, ArrowPos[0].x, ArrowPos[0].y, ArrowPos[0].x, ArrowPos[0].y);

			ArrowPos[1].x = sArrowPoint2.x;
			ArrowPos[1].y = sArrowPoint2.y; //

			ArrowPos[2].x = sArrowPoint2.x + a1;
			ArrowPos[2].y = sArrowPoint2.y + a2; //Lineto(a1, a2);
			BrDrawUnit::rotatePoint(nAngle, nCenterX, nCenterY, ArrowPos[2].x, ArrowPos[2].y, ArrowPos[2].x, ArrowPos[2].y);

			break;
		}
	case eLineArrowCommon:
		{
			a0 = dHeadRadius;
			a1 = dWingRadius;

			ArrowPos[0].x = sArrowPoint2.x;	
			ArrowPos[0].y = sArrowPoint2.y; //Moveto(0,0);

			ArrowPos[1].x = sArrowPoint2.x + a0;
			ArrowPos[1].y = sArrowPoint2.y - a1; //Lineto(a0, -a1);
			BrDrawUnit::rotatePoint(nAngle, nCenterX, nCenterY, ArrowPos[1].x, ArrowPos[1].y, ArrowPos[1].x, ArrowPos[1].y);

			ArrowPos[2].x = sArrowPoint2.x + a0;
			ArrowPos[2].y = sArrowPoint2.y + a1; //Lineto(a0, a1);
			BrDrawUnit::rotatePoint(nAngle, nCenterX, nCenterY, ArrowPos[2].x, ArrowPos[2].y, ArrowPos[2].x, ArrowPos[2].y);

			break;
		}
	case eLineArrowStealth:
		{
			a0 = dHeadRadius;
			a1 = dWingRadius;
			a2 = dTailRadius;

			ArrowPos[0].x = sArrowPoint2.x;	
			ArrowPos[0].y = sArrowPoint2.y; //Moveto(0,0);

			ArrowPos[1].x = sArrowPoint2.x + a0;
			ArrowPos[1].y = sArrowPoint2.y - a1; //Lineto(a0, -a1);
			BrDrawUnit::rotatePoint(nAngle, nCenterX, nCenterY, ArrowPos[1].x, ArrowPos[1].y, ArrowPos[1].x, ArrowPos[1].y);

			ArrowPos[2].x = sArrowPoint2.x + a2;
			ArrowPos[2].y = sArrowPoint2.y; //Lineto(a2, 0);
			BrDrawUnit::rotatePoint(nAngle, nCenterX, nCenterY, ArrowPos[2].x, ArrowPos[2].y, ArrowPos[2].x, ArrowPos[2].y);

			ArrowPos[3].x = sArrowPoint2.x + a0;
			ArrowPos[3].y = sArrowPoint2.y + a1; //Lineto(a0, a1);
			BrDrawUnit::rotatePoint(nAngle, nCenterX, nCenterY, ArrowPos[3].x, ArrowPos[3].y, ArrowPos[3].x, ArrowPos[3].y);

			break;
		}
	case eLineArrowDiamond:
		{
			a0 = dHeadRadius;
			a1 = dWingRadius;

			ArrowPos[0].x = sArrowPoint2.x - a0;	
			ArrowPos[0].y = sArrowPoint2.y; //Moveto(-a0,0);
			BrDrawUnit::rotatePoint(nAngle, nCenterX, nCenterY, ArrowPos[0].x, ArrowPos[0].y, ArrowPos[0].x, ArrowPos[0].y);

			ArrowPos[1].x = sArrowPoint2.x;
			ArrowPos[1].y = sArrowPoint2.y - a1; //Lineto(0, -a1);
			BrDrawUnit::rotatePoint(nAngle, nCenterX, nCenterY, ArrowPos[1].x, ArrowPos[1].y, ArrowPos[1].x, ArrowPos[1].y);

			ArrowPos[2].x = sArrowPoint2.x + a0;
			ArrowPos[2].y = sArrowPoint2.y; //Lineto(a0, 0);
			BrDrawUnit::rotatePoint(nAngle, nCenterX, nCenterY, ArrowPos[2].x, ArrowPos[2].y, ArrowPos[2].x, ArrowPos[2].y);

			ArrowPos[3].x = sArrowPoint2.x;
			ArrowPos[3].y = sArrowPoint2.y + a1; //Lineto(0, a1);
			BrDrawUnit::rotatePoint(nAngle, nCenterX, nCenterY, ArrowPos[3].x, ArrowPos[3].y, ArrowPos[3].x, ArrowPos[3].y);

			break;
		}
	case eLineArrowOval: //ellipse
		{
			//0, 0, dHeadRadius, dWingRadius;
			ArrowPos[0].x = sArrowPoint2.x - dHeadRadius;	
			ArrowPos[0].y = sArrowPoint2.y - dWingRadius; //left, top

			ArrowPos[1].x = sArrowPoint2.x + dHeadRadius;
			ArrowPos[1].y = sArrowPoint2.y + dWingRadius; //right, bottom

			ArrowPos[2].x = sArrowPoint2.x;
			ArrowPos[2].y = sArrowPoint2.y; //�߽���

			break;
		}
	default:
		break;
	}
}

void BrExportPDFDC::toLineExport(LPBrFPOINT pPos1, LPBrFPOINT pPos2)
{
	LPBrLINESTYLE_INFO pLineInfo = NULL;
	BrINT nLineCount = 0;
	// line style �� ���� line ������ ������ (ex.double line �Ӽ��̸� line�� 2�� �׸� �� �ֵ��� ��ǥ �� width �� ���)
	// ���� Double Line�� ��� nLineCount�� ������ 3���̸�, ���� ���� Original Line�� ���� ������ Index�� �����Ѵ�.)
	nLineCount = getLineInfo(pLineInfo, pPos1, pPos2);

	BRTHREAD_ASSERT(nLineCount > 1 || pLineInfo == NULL); // LineInfo�� �о���� ���� ��� (Line�� ���� ��� �ּ� 2�� LineInfo�� �о��)

	if(m_pPen->m_sLogPen.nPenType == eGradientPen)
	{
		BrINT garoPenWidth = 0;
		BrINT seroPenWidth = 0;
		pPos1->x -= m_sExtInfo.nPosX; pPos1->y -= m_sExtInfo.nPosY;
		pPos2->x -= m_sExtInfo.nPosX; pPos2->y -= m_sExtInfo.nPosY;

		BrRect rcBound = {m_pFigureClipBox->left, m_pFigureClipBox->top, m_pFigureClipBox->right, m_pFigureClipBox->bottom};
		BrINT penwidth = m_pPen->getPenWidth();
		setGaroSeroGradientPenWidth(m_pPen->getPenWidth(), rcBound, &garoPenWidth, &seroPenWidth);

		BrINT oldangle = m_sExtInfo. nRotateAngle;
		BrBYTE oldFlip = m_nFigureFlipType;

		BrRect rcFigureClip, rcFillClip;

		if(enableTemplateMode(BrTRUE, BrABS(rcBound.right - rcBound.left) + (2*garoPenWidth), BrABS(rcBound.bottom- rcBound.top ) + (2*seroPenWidth), rcFigureClip, rcFillClip ))
		{
			BrFLOAT nCenterX = (pPos1->x + pPos2->x)/2;
			BrFLOAT nCenterY = (pPos1->y + pPos2->y)/2;
			BrFLOAT nPosX=0, nPosY=0;
			BrFPOINT toPos = {0,0};
			enableAlphaBitmapDC(BrTRUE);

			setFigureFlip(0);
			setRotateAngle(0);

			BrDC::drawLine(pPos1->x + garoPenWidth, pPos1->y + seroPenWidth, pPos2->x + garoPenWidth, pPos2->y + seroPenWidth);
			BR_REL_STATE(m_nExtFalg, eHasDataExtDCState);
			enableTemplateMode(BrFALSE, 0, 0, rcFigureClip, rcFillClip);

			BrLONG scaleWidth = twips2DeviceX(Device2twips(m_pTemplate->getDib()->biWidth, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
			BrLONG scaleHeight = twips2DeviceY(Device2twips(m_pTemplate->getDib()->biHeight, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, 0, TARGET_DEVICE_RESOLUTION);

			BrINT32 bibiwidth = m_pTemplate->getDib()->biWidth;
			if((m_pTemplate->getDib()->biWidth != scaleWidth) || (m_pTemplate->getDib()->biHeight != scaleHeight))
				m_pTemplate->scaleEx(scaleWidth, scaleHeight, m_pTemplate);

			BrBmvBrush* pTBrush = BrNULL;
			pTBrush = BrNEW BrBmvBrush;
			pTBrush->createDIBBrush (m_pTemplate);
			m_pBrush = pTBrush;
			setFigureFlip(oldFlip);
			setRotateAngle(oldangle);
			m_pBrush->setEnableRotate(BrTRUE);
			m_pPen->m_sLogPen.nPenType = eNormalPen;

			BrRect rcNewFigureClip = {(m_pFigureClipBox->left - garoPenWidth), (m_pFigureClipBox->top - seroPenWidth), (m_pFigureClipBox->right + garoPenWidth), (m_pFigureClipBox->bottom + seroPenWidth)};
			setFigureClipBox(&rcNewFigureClip, NULL);
			fillRect(m_pFigureClipBox->left, m_pFigureClipBox->top, m_pFigureClipBox->right, m_pFigureClipBox->bottom);
			m_pPen->m_sLogPen.nPenType = eGradientPen;

		}
		BR_SAFE_FREE(pLineInfo);
		return;
	}

	BrBOOL bSetRenderEvn = BrFALSE;

	//[2014.06.24] ������ �ִ� ������ ������ export �ؾ� �� ���
		bSetRenderEvn = BR_ISSET_STATE(m_nExtFalg, eHasPathExtDCState) ? setExportRenderEnv(BrFALSE, BrFALSE) : setExportRenderEnv(BrFALSE);

	if (!bSetRenderEvn)
		BRTHREAD_ASSERT(0);

	LPBrLOGARROW pHeadArrow = m_pPen->getHeadArrow();
	LPBrLOGARROW pTailArrow = m_pPen->getTailArrow();

	if (pHeadArrow || pTailArrow)
		toArrowExportPDF(pLineInfo, &pLineInfo[nLineCount-1], pHeadArrow, pTailArrow, nLineCount); // 2.0 Arrow�� ���� ���

	poExport_BeginPath();

	for (BrINT i = nLineCount-1 ; i != 0 ; i--)
		exportLineByLine(&pLineInfo[i-1], pPos1, pPos2);

	poExport_EndPath();

	BR_SAFE_FREE(pLineInfo);
}

void BrExportPDFDC::enforceEndClipPath()
{
	poExport_EnforceEndClipPath();
}

void BrExportPDFDC::toSpecialLineExport(LPBrFPOINT pPos1, LPBrFPOINT pPos2)
{
	// Print, PDF2.0 ���ĸ� ��� ų ��쿡,  �ߺ��ڵ带 ���ְ� ExportDC������ ���� ó���� ����
	BrFLOAT nMoveGap1 = 0.5, nMoveGap2 = 1;
	BrINT nSize = 0;
	BrBOOL bReverseY = (pPos2->y - pPos1->y) < 0 ? BrTRUE : BrFALSE;
	BrBOOL bReverseX = (pPos2->x - pPos1->x) < 0 ? BrTRUE : BrFALSE;
	BrFPOINT fMovePos = {0.0f, }, fDstPos = {0.0f, };
	BrFPOINT fTmpPos = (bReverseX || bReverseY) ? *pPos2 : *pPos1;
	BrINT nGap = (m_nPenWidth / 20);
	BrINT nMoveOffset = (nGap / 2);

	poExport_BeginPath();
	poExport_SetPenAtt(0, m_cPenColor, m_nPenStyle);

	switch (m_pPen->m_sLogPen.nPenType)
	{
	case eDiagonalLineVertPen:
		{
			nSize = BrABS(pPos2->y - pPos1->y);
			fMovePos.x = (fTmpPos.x - nMoveOffset),	fMovePos.y = (fTmpPos.y - nGap);
			fDstPos.x = (fTmpPos.x + nMoveOffset),	fDstPos.y = fMovePos.y;

			for (BrINT i = 0 ; i < nSize ; i += 3) { // 1 + 0.5*4 = 3

				// 1. moveTo ������������ �̵�
				fMovePos.y += nMoveGap2; 
				poExport_MoveTo(&fMovePos, BrTRUE);

				// 2. lineTo ������������ �̵�
				fDstPos.y = fMovePos.y - nGap; // LineTo�� ��ġ��ŭ Y�̵�
				poExport_LineTo(&fDstPos, BrTRUE, BrTRUE);

				// 3. moveGap2 ��ŭ movePos�� DstPos�� �̵�
				fMovePos.y += nMoveGap2; 
				fDstPos.y += nMoveGap2;

				for (BrINT j = 0 ; j < 4 ; j++) {
					poExport_MoveTo(&fMovePos, BrTRUE);
					poExport_LineTo(&fDstPos, BrTRUE, BrTRUE);

					// 4. moveGap1��ŭ movePos�̵�
					fMovePos.y = fMovePos.y + nMoveGap1;

					// 5. moveGap1��ŭ dstPos�̵�
					fDstPos.y = fDstPos.y + nMoveGap1; // LineTo�� ��ġ��ŭ Y�̵�
				}

				poExport_MoveTo(&fMovePos, BrTRUE);
				poExport_LineTo(&fDstPos, BrTRUE, BrTRUE);
			}
		}
		break;

	case eDiagonalLineHorizPen: 
		{
			nSize = BrABS(pPos2->x - pPos1->x);
			fMovePos.x = (fTmpPos.x - nGap),	fMovePos.y = (fTmpPos.y + nMoveOffset);
			fDstPos.x = fMovePos.x,	fDstPos.y = (fTmpPos.y - nMoveOffset);

			for (BrINT i = 0 ; i < nSize ; i += 3) {
				fMovePos.x += nMoveGap2;
				poExport_MoveTo(&fMovePos, BrTRUE);

				fDstPos.x = (fMovePos.x + nGap);
				poExport_LineTo(&fDstPos, BrTRUE, BrTRUE);

				fMovePos.x += nMoveGap2; 
				fDstPos.x += nMoveGap2;

				for (BrINT j = 0 ; j < 4 ; j++) {
					poExport_MoveTo(&fMovePos, BrTRUE);
					poExport_LineTo(&fDstPos, BrTRUE, BrTRUE);

					fMovePos.x = fMovePos.x + nMoveGap1;
					fDstPos.x = fDstPos.x + nMoveGap1;
				}

				poExport_MoveTo(&fMovePos, BrTRUE);
				poExport_LineTo(&fDstPos, BrTRUE, BrTRUE);
			}
		}
		break;

	default:
		break;
	}

	poExport_EndPath();
}

void BrExportPDFDC::exportLineByLine(LPBrLINESTYLE_INFO pLineInfo, LPBrFPOINT pPos1, LPBrFPOINT pPos2)
{
	poExport_SetPenWidthTwip(BrTRUE); // Twip������ ����
	poExport_SetPenAtt(pLineInfo->nWidth, m_cPenColor, m_nPenStyle);
	BrFPOINT toPos = {(BrFLOAT)pLineInfo->nSx, (BrFLOAT)pLineInfo->nSy};

	poExport_MoveTo(&toPos, BrTRUE);

	toPos.x = pLineInfo->nEx;
	toPos.y = pLineInfo->nEy;
	poExport_LineTo(&toPos, BrTRUE, BrTRUE);
	poExport_SetPenWidthTwip(BrFALSE); // Twip���� ����
}


void BrExportPDFDC::toArrowExportPDF(LPBrLINESTYLE_INFO& pLineInfo, LPBrLINESTYLE_INFO pOrgLineInfo, LPBrLOGARROW pHeadArrow, LPBrLOGARROW pTailArrow, BrINT nLineCount)
{
	BrFPOINT sHeadArrowPoint1 = {0, 0}, sHeadArrowPoint2 = {0, 0}; //ȭ��ǥ�� ������ ����ϱ� ���� point
	BrFPOINT sTailArrowPoint1 = {0, 0}, sTailArrowPoint2 = {0, 0};

	BrFPOINT HeadArrowpos[4] = {0,}; //ȭ��ǥ�� ���� ��ǥ
	BrFPOINT TailArrowpos[4] = {0,};

	BrBOOL isArrow = BrFALSE;
	BrFPOINT sStartPos = {(BrFLOAT)pOrgLineInfo->nSx, (BrFLOAT)pOrgLineInfo->nSy};
	BrFPOINT sDestPos = {(BrFLOAT)pOrgLineInfo->nEx, (BrFLOAT)pOrgLineInfo->nEy};
	BrFLOAT fXGap = 0;
	BrFLOAT fYGap = 0;

	// addArrowPathByType�������� PenWidth�� Twip�� �ƴ� Device��ǥ�踦 ���Ƿ�, �ϰ����� ���Ͽ� Arrow�� �׸� ������ Twip������ �����ϴ� ���� �����Ѵ�.

	sStartPos.x = pOrgLineInfo->nSx; sStartPos.y = pOrgLineInfo->nSy; 
	sDestPos.x = pOrgLineInfo->nEx; sDestPos.y = pOrgLineInfo->nEy; 

	if (pTailArrow)
	{
		BrDPoint  p3, p4;
		BrDOUBLE dHMove = 0;
		BrDOUBLE dTMove = 0;
		BrDPoint sArrowMovePos={sStartPos.x, sStartPos.y};
		BrDPoint sArrowLinePos={sDestPos.x, sDestPos.y};

		dTMove = m_pPen->getArrowInfo(m_pPen->getBaseLineWidth(), m_pPen->getLineWidth(), pTailArrow, m_pPen->getScaleFact(), BrNULL, BrNULL, BrNULL, m_pPen->getLineStyle());

		if(getLineOffsetByArrow(&sArrowMovePos, &sArrowLinePos, &dTMove, &dHMove, &p3, &p4))
		{
			fXGap = p3.x - pOrgLineInfo->nSx; // - p3.x;
			fYGap = p3.y - pOrgLineInfo->nSy; // - p3.y;

			for (BrINT i = nLineCount ; i != 0 ; i--) {
				pLineInfo[i-1].nSx += fXGap;
				pLineInfo[i-1].nSy += fYGap;
			}
		}

		sTailArrowPoint1.x = sDestPos.x;	sTailArrowPoint1.y = sDestPos.y; 
		sTailArrowPoint2.x = sStartPos.x;	sTailArrowPoint2.y = sStartPos.y;	

		setArrowPoint(m_pPen, pTailArrow, TailArrowpos, sTailArrowPoint1, sTailArrowPoint2);
		addArrowPathByType(pTailArrow, TailArrowpos[0], TailArrowpos[1], TailArrowpos[2], TailArrowpos[3]);
	}

	if (pHeadArrow)
	{									
		BrDPoint  p3, p4;
		BrDOUBLE dHMove = 0;
		BrDOUBLE dTMove = 0;
		BrDPoint sArrowMovePos={sStartPos.x, sStartPos.y};
		BrDPoint sArrowLinePos={sDestPos.x, sDestPos.y};

		dHMove = m_pPen->getArrowInfo(m_pPen->getBaseLineWidth(), m_pPen->getLineWidth(), pHeadArrow, m_pPen->getScaleFact(), BrNULL, BrNULL, BrNULL, m_pPen->getLineStyle());

		if(getLineOffsetByArrow(&sArrowMovePos, &sArrowLinePos, &dTMove, &dHMove, &p3, &p4))
		{
			fXGap = pOrgLineInfo->nEx - p4.x;
			fYGap = pOrgLineInfo->nEy - p4.y;

			for (BrINT i = nLineCount ; i != 0 ; i--) {
				pLineInfo[i-1].nEx -= fXGap;
				pLineInfo[i-1].nEy -= fYGap; // [2015.08.26][235] Original Line(���� �⺻�� �Ǵ� Line)���� Gap�� ����Ͽ� ����(Tail�� ��� ������)�� ��ǥ�� �̵���Ų��.
			}
		}

		sHeadArrowPoint1.x = sStartPos.x;	sHeadArrowPoint1.y = sStartPos.y; 
		sHeadArrowPoint2.x = sDestPos.x;	sHeadArrowPoint2.y = sDestPos.y;

		setArrowPoint(m_pPen, pHeadArrow, HeadArrowpos, sHeadArrowPoint1, sHeadArrowPoint2);
		addArrowPathByType(pHeadArrow, HeadArrowpos[0], HeadArrowpos[1], HeadArrowpos[2], HeadArrowpos[3]);
	}

	poExport_SetPenWidthTwip(BrTRUE);
	m_bIsTwipPenWidth = BrTRUE;
}

void BrExportPDFDC::toRectExport(BrINT32 x1, BrINT32 y1, BrINT32 x2, BrINT32 y2, BrCOLORREF cFillColor, BrBOOL bFill)
{
	BrFRect rect = {(BrFLOAT)(x1+m_sExtInfo.nPosX), (BrFLOAT)(y1+m_sExtInfo.nPosY), (BrFLOAT)(x2+m_sExtInfo.nPosX), (BrFLOAT)(y2+m_sExtInfo.nPosY)};
	poExport_BeginPath();
	poExport_SetPenAtt(m_nPenWidth, m_cPenColor, m_nPenStyle);	
	poExport_SetGState(m_nSourceConstantAlpha, m_pPen->getAlpha());
	if(bFill == BrFALSE)
		poExport_Rect(&rect, BrFALSE);	
	else
	{
		poExport_SetBrushColor(cFillColor);
		poExport_Rect(&rect, BrTRUE);
	}	
	poExport_EndPath();
}

void BrExportPDFDC::toFillRectExport(BrINT32 x1, BrINT32 y1, BrINT32 x2, BrINT32 y2, BrCOLORREF cFillColor)
{
	BrFRect rect = {(BrFLOAT)(x1+m_sExtInfo.nPosX), (BrFLOAT)(y1+m_sExtInfo.nPosY), (BrFLOAT)(x2+m_sExtInfo.nPosX), (BrFLOAT)(y2+m_sExtInfo.nPosY)};
	poExport_BeginPath();
	poExport_SetPenAtt(m_nPenWidth, m_cPenColor, m_nPenStyle);	
	poExport_SetBrushColor(cFillColor);
	poExport_SetGState(m_nSourceConstantAlpha, COLOR_OPAQUE);
	poExport_FillRect(&rect);
	poExport_EndPath();
}

void BrExportPDFDC::toFillSolidRectExport(BrINT32 x1, BrINT32 y1, BrINT32 x2, BrINT32 y2, BrCOLORREF cFillColor)
{
	BrFRect rect = {(BrFLOAT)(x1+m_sExtInfo.nPosX), (BrFLOAT)(y1+m_sExtInfo.nPosY), (BrFLOAT)(x2+m_sExtInfo.nPosX), (BrFLOAT)(y2+m_sExtInfo.nPosY)};

	poExport_BeginPath();
	poExport_SetPenAtt(m_nPenWidth, m_cPenColor, m_nPenStyle);	
	//[13.12.27][���¼�] ppt Export ��rect �ܰ��� �̻� ����
	//poExport_SetGState(m_nSourceConstantAlpha, COLOR_OPAQUE);
	poExport_SetGState(m_nSourceConstantAlpha, m_nSourceConstantAlpha);
	poExport_FillSolidRect(&rect, cFillColor, BrTRUE);
	poExport_EndPath();
}

BrBOOL BrExportPDFDC::addImage(PrBitmap * pImage, LPBrRect pPageRect, BrINT nAngle, BrPOINT* pRotAngleCPos)
{
	return poExport_AddImage(pImage, pPageRect, nAngle, pRotAngleCPos, m_bPreblended);
}

void BrExportPDFDC::setFontIncValue(BrINT nIndex)
{
	return poExport_SetFontIncrement(nIndex);
}

void BrExportPDFDC::setGaroSeroGradientPenWidth(BrUINT nOrgPenWidth, BrRect rcBound, BrINT* pGaroPenWidth, BrINT* pSeroPenWidth)
{
	// [2015.09.03][235] m_pTemplate->create�ÿ� m_pBitmap�� ȯ��� ������ PenWidth�� �������ش�. (DC ȯ��� ������ ���������, Boundary���� �ùٸ��� ���۽�ų �� ����)
	BrUINT nGaroGradientLength = (rcBound.right - rcBound.left) + (nOrgPenWidth / 2);
	BrUINT nSeroGradientLength = (rcBound.bottom - rcBound.top) + (nOrgPenWidth / 2); 
	BrINT nGaroGap = (m_pBitmap->getDib()->biWidth - nGaroGradientLength); // garoGap�� '+' �� ��쿡�� orgPenWidth���� DC�� bitmap ���� �۰� dib �� ����ٴ� ��
	BrINT nSeroGap = (m_pBitmap->getDib()->biHeight - nSeroGradientLength);
	*pGaroPenWidth = (nOrgPenWidth) + (nGaroGap >= 0 ? (nGaroGap / 2) : -(nGaroGap / 2));
	*pSeroPenWidth = (nOrgPenWidth) + (nSeroGap >= 0 ? (nSeroGap / 2) : -(nSeroGap / 2)); 
}

void BrExportPDFDC::fillEllipse(BrINT32 x1, BrINT32 y1, BrINT32 x2, BrINT32 y2)
{
	if(BR_ISSET_STATE(m_nExtFalg, eHasDirectExtDCState))
	{
		doExport(0, 0, BrTRUE);
		enableFillTemplateRender(BrTRUE, BrABS(x2 - x1), BrABS(y2 - y1));

		if(!setExportRenderEnv(BrTRUE))
		{
			BRTHREAD_ASSERT(0);
#if 0			
			BrRect rcFigureClip, rcFillClip;
			enableTemplateMode(BrTRUE, x2-x1, y2-y1, rcFigureClip, rcFillClip);
			if(m_pFigureClipBox)
				BR_RECT_MOVE_PTR(m_pFigureClipBox, -x1, -y1);
			if(m_pFillClipBox)
				BR_RECT_MOVE_PTR(m_pFillClipBox, -x1, -y1);				
			BrDC:: fillEllipse(x1-x1, y1-y1, x2-x1, y2-y1);
			doExport(x1, y1, BrFALSE);
			enableTemplateMode(BrFALSE, 0, 0, rcFigureClip, rcFillClip);
#endif //0			
		}
		else
		{
			BrFRect rect = {(BrFLOAT)(x1+m_sExtInfo.nPosX), (BrFLOAT)(y1+m_sExtInfo.nPosY), (BrFLOAT)(x2+m_sExtInfo.nPosX), (BrFLOAT)(y2+m_sExtInfo.nPosY)};
#if 0	//Print dc �� �� �ڵ�. ���� print export ����ȭ �۾� �� �Ʒ� ������ pdf dc ó�� setExportRenderEnv �� ���� �����ϵ��� �����Ͽ��� �Ѵ�.
		//�����丮�� ���� �ش� �κи� �ڵ带 ���ܳ��� �ٸ� �κ��� �����ϵ��� �Ѵ�.
			BrINT nAngle = m_sExtInfo.nRotateAngle;
			if(m_nFigureFlipType == eFigureFlipX || m_nFigureFlipType == eFigureFlipY)
			{	
				if(m_sExtInfo.nRotateAngle != 0) nAngle = 360 - nAngle;
				m_pPrintExt->setFlipType(m_nFigureFlipType);
			}
			else if(m_nFigureFlipType == eFigureFlipXY)
			{
				m_pPrintExt->setFlipType(m_nFigureFlipType);
			} 

			if(nAngle%360!=0)
				m_pPrintExt->setRotateAngle(nAngle);
#endif //0

			poExport_BeginPath();

			poExport_Ellipse(rect.left, rect.top, rect.right, rect.bottom, BrTRUE,  BrFALSE);
			//poExport_EndPath();
			poExport_EndPathEx(BrFALSE, BrTRUE);

#if 0	//Print dc �� �� �ڵ�. ���� print export ����ȭ �۾� �� �Ʒ� ������ pdf dc ó�� setExportRenderEnv �� ���� �����ϵ��� �����Ͽ��� �Ѵ�.
		//�����丮�� ���� �ش� �κи� �ڵ带 ���ܳ��� �ٸ� �κ��� �����ϵ��� �Ѵ�.
			if(nAngle%360!=0)
				m_pPrintExt->setRotateAngle(0);
			if(m_nFigureFlipType!=eFigureFlipNone)
				m_pPrintExt->setFlipType(eFigureFlipNone);
#endif //0			
		}
		enableFillTemplateRender(BrFALSE);
	}
	else
	{
		BrDC::fillEllipse(x1, y1, x2, y2);
	}
}

void BrExportPDFDC::ellipse(BrINT32 x1, BrINT32 y1, BrINT32 x2, BrINT32 y2, BrBOOL bFill)
{
	if(BR_ISSET_STATE(m_nExtFalg, eHasDirectExtDCState))
	{
		doExport(0, 0, BrTRUE);

		if(m_pPen->m_sLogPen.nPenType == eGradientPen)
		{
			BrRect rcBound = {m_pFigureClipBox->left, m_pFigureClipBox->top, m_pFigureClipBox->right, m_pFigureClipBox->bottom};
			BrINT garoPenWidth = 0;
			BrINT seroPenWidth = 0;
			setGaroSeroGradientPenWidth(m_pPen->getPenWidth(), rcBound, &garoPenWidth, &seroPenWidth);

			BrRect rcFigureClip, rcFillClip;
			BrINT oldangle = m_sExtInfo. nRotateAngle;
			BrBYTE oldFlip = m_nFigureFlipType;

			if(enableTemplateMode(BrTRUE, x2-x1+(2*garoPenWidth), y2-y1+(2*seroPenWidth), rcFigureClip, rcFillClip))
			{
				enableAlphaBitmapDC(BrTRUE);
				setRotateAngle(0);
				setFigureFlip(eFigureFlipNone);
				BrDC::ellipse(x1+ garoPenWidth, y1+ seroPenWidth, x2+ garoPenWidth, y2+ seroPenWidth, BrFALSE);
				BR_REL_STATE(m_nExtFalg, eHasDataExtDCState);
				enableTemplateMode(BrFALSE, 0, 0, rcFigureClip, rcFillClip);

				BrLONG scaleWidth = twips2DeviceX(Device2twips(m_pTemplate->getDib()->biWidth, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
				BrLONG scaleHeight = twips2DeviceY(Device2twips(m_pTemplate->getDib()->biHeight, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, 0, TARGET_DEVICE_RESOLUTION);

				if((m_pTemplate->getDib()->biWidth != scaleWidth) || (m_pTemplate->getDib()->biHeight != scaleHeight))
					m_pTemplate->scaleEx(scaleWidth, scaleHeight, m_pTemplate);

				BrBmvBrush* pTBrush = BrNULL;
				pTBrush = BrNEW BrBmvBrush;
				pTBrush->createDIBBrush (m_pTemplate);
				m_pBrush = pTBrush;

				setFigureFlip(oldFlip);
				setRotateAngle(oldangle);
				m_pBrush->setEnableRotate(BrTRUE);
				m_pPen->m_sLogPen.nPenType = eNormalPen;

				BrRect rcNewFigureClip = {(m_pFigureClipBox->left - garoPenWidth), (m_pFigureClipBox->top - seroPenWidth), (m_pFigureClipBox->right + garoPenWidth), (m_pFigureClipBox->bottom + seroPenWidth)};
				setFigureClipBox(&rcNewFigureClip, NULL);
				fillRect(m_pFigureClipBox->left, m_pFigureClipBox->top, m_pFigureClipBox->right, m_pFigureClipBox->bottom);
				m_pPen->m_sLogPen.nPenType = eGradientPen;
			}
			return;
		}

		enableFillTemplateRender(BrTRUE, BrABS(x2-x1), BrABS(y2-y1));
		

		BrBOOL bSetRenderEnv = setExportRenderEnv(bFill); // PDF�� ��� ExportRender Enviroment�� ���� ����
		BrBOOL bIsOldTwipPenWidth = BrFALSE;

		if(m_bIsTwipPenWidth)
			bIsOldTwipPenWidth = poExport_SetPenWidthTwip(m_bIsTwipPenWidth); // [2015.06.08][235] Ellipse Export�� PenWidth�� Twip ������ �׸����� ����

		if(!bSetRenderEnv)
		{
			BRTHREAD_ASSERT(0);
#if 0		
			BrRect rcFigureClip, rcFillClip;
			enableTemplateMode(BrTRUE, x2-x1, y2-y1, rcFigureClip, rcFillClip);
			if(m_pFigureClipBox)
				BR_RECT_MOVE_PTR(m_pFigureClipBox, -x1, -y1);
			if(m_pFillClipBox)
				BR_RECT_MOVE_PTR(m_pFillClipBox, -x1, -y1);				
			BrDC::ellipse(x1-x1, y1-y1, x2-x1, y2-y1, bFill);
			doExport(x1, y1, BrFALSE);
			enableTemplateMode(BrFALSE, 0, 0, rcFigureClip, rcFillClip);
#endif //			
		}
		else
		{
			BrFRect rect = {(BrFLOAT)(x1+m_sExtInfo.nPosX), (BrFLOAT)(y1+m_sExtInfo.nPosY), (BrFLOAT)(x2+m_sExtInfo.nPosX), (BrFLOAT)(y2+m_sExtInfo.nPosY)};
			poExport_BeginPath();
			poExport_Ellipse(rect.left, rect.top, rect.right, rect.bottom, bFill, BrTRUE);
			poExport_EndPathEx(BrTRUE, bFill);
		}
		enableFillTemplateRender(BrFALSE);
		poExport_SetPenWidthTwip(bIsOldTwipPenWidth);
	}
	else
	{
		BrDC::ellipse(x1, y1, x2, y2, bFill);
	}
}

void BrExportPDFDC::fillRect(BrINT32 x1, BrINT32 y1, BrINT32 x2, BrINT32 y2)
{
	BrCOLORREF cBrushColor = BrRGB(m_pBrush->m_sLogBrush.m_nRed, m_pBrush->m_sLogBrush.m_nGreen, m_pBrush->m_sLogBrush.m_nBlue);
	if(BR_ISSET_STATE(m_nExtFalg, eHasDirectExtDCState))
	{
		doExport(0, 0, BrTRUE);
		enableFillTemplateRender(BrTRUE, BrABS(x2-x1), BrABS(y2-y1));

		if(!setExportRenderEnv(BrTRUE))
		{
			BRTHREAD_ASSERT(0);		
		}
		else
		{
			BrFRect rect = {(BrFLOAT)(x1+m_sExtInfo.nPosX), (BrFLOAT)(y1+m_sExtInfo.nPosY), (BrFLOAT)(x2+m_sExtInfo.nPosX), (BrFLOAT)(y2+m_sExtInfo.nPosY)};
			poExport_BeginPath();
			poExport_FillRect(&rect, BrTRUE);
			poExport_EndPath();
		}
		enableFillTemplateRender(BrFALSE);
	}
	else
	{
		BrDC::fillRect(x1, y1, x2, y2);
	}
}

void BrExportPDFDC::fillSolidRect(BrINT32 x1, BrINT32 y1, BrINT32 x2, BrINT32 y2, BrBYTE red, BrBYTE green, BrBYTE blue)
{
	BrCOLORREF sColor = BrRGB(red, green, blue);
	if(BR_ISSET_STATE(m_nExtFalg, eHasDirectExtDCState))
	{
		doExport(0, 0, BrTRUE);
		enableFillTemplateRender(BrTRUE, BrABS(x2-x1), BrABS(y2-y1));

		if(!setExportRenderEnv(BrTRUE))
		{
			BRTHREAD_ASSERT(0);		
		}
		else
		{
			BrFRect rect = {(BrFLOAT)(x1+m_sExtInfo.nPosX), (BrFLOAT)(y1+m_sExtInfo.nPosY), (BrFLOAT)(x2+m_sExtInfo.nPosX), (BrFLOAT)(y2+m_sExtInfo.nPosY)};
			poExport_BeginPath();
			poExport_FillSolidRect(&rect, sColor, BrFALSE);	
			poExport_EndPath();
		}
		enableFillTemplateRender(BrFALSE);
	}
	else
	{
		BrDC::fillSolidRect(x1, y1, x2, y2, red, green, blue);
	}
}
void BrExportPDFDC::rectangle(BrINT32 x1, BrINT32 y1, BrINT32 x2, BrINT32 y2, BrBOOL bFill)
{
	if(BR_ISSET_STATE(m_nExtFalg, eHasDirectExtDCState))
	{
		doExport(0, 0, BrTRUE);

		if(m_pPen->m_sLogPen.nPenType == eGradientPen)
		{
			BrRect rcBound = {m_pFigureClipBox->left, m_pFigureClipBox->top, m_pFigureClipBox->right, m_pFigureClipBox->bottom};
			BrINT garoPenWidth = 0;
			BrINT seroPenWidth = 0;
			setGaroSeroGradientPenWidth(m_pPen->getPenWidth(), rcBound, &garoPenWidth, &seroPenWidth);

			BrRect rcFigureClip, rcFillClip;
			BrINT oldangle = m_sExtInfo. nRotateAngle;
			BrBYTE oldFlip = m_nFigureFlipType;

			if(enableTemplateMode(BrTRUE, x2-x1+(2*garoPenWidth), y2-y1+(2*seroPenWidth), rcFigureClip, rcFillClip))
			{
				enableAlphaBitmapDC(BrTRUE);
				setRotateAngle(0);
				setFigureFlip(eFigureFlipNone);
				BrDC:: rectangle(garoPenWidth, seroPenWidth, x2-x1+garoPenWidth, y2-y1+seroPenWidth, BrFALSE); //fill ���� ���� �׸��� 
				BR_REL_STATE(m_nExtFalg, eHasDataExtDCState);
				enableTemplateMode(BrFALSE, 0, 0, rcFigureClip, rcFillClip);

				BrLONG scaleWidth = twips2DeviceX(Device2twips(m_pTemplate->getDib()->biWidth, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
				BrLONG scaleHeight = twips2DeviceY(Device2twips(m_pTemplate->getDib()->biHeight, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, 0, TARGET_DEVICE_RESOLUTION);

				if((m_pTemplate->getDib()->biWidth != scaleWidth) || (m_pTemplate->getDib()->biHeight != scaleHeight))
					m_pTemplate->scaleEx(scaleWidth, scaleHeight, m_pTemplate);

				BrBmvBrush* pTBrush = BrNULL;
				pTBrush = BrNEW BrBmvBrush;
				pTBrush->createDIBBrush (m_pTemplate);
				m_pBrush = pTBrush;

				setFigureFlip(oldFlip);
				setRotateAngle(oldangle);
				m_pBrush->setEnableRotate(BrTRUE);
				m_pPen->m_sLogPen.nPenType = eNormalPen;

				BrRect rcNewFigureClip = {(m_pFigureClipBox->left - garoPenWidth), (m_pFigureClipBox->top - seroPenWidth), (m_pFigureClipBox->right + garoPenWidth), (m_pFigureClipBox->bottom + seroPenWidth)};
				setFigureClipBox(&rcNewFigureClip, NULL);
				fillRect(m_pFigureClipBox->left, m_pFigureClipBox->top, m_pFigureClipBox->right, m_pFigureClipBox->bottom);
				m_pPen->m_sLogPen.nPenType = eGradientPen;
			}
			return;
		}

		enableFillTemplateRender(BrTRUE, BrABS(x2-x1), BrABS(y2-y1));

		BrBOOL bSetRenderEnv = setExportRenderEnv(bFill); // PDF�� ��� ExportRender Enviroment�� ���� ����
		BrBOOL bIsOldTwipPenWidth = BrFALSE;

		if(m_bIsTwipPenWidth)
			bIsOldTwipPenWidth = poExport_SetPenWidthTwip(m_bIsTwipPenWidth); // [2015.06.08][235] Ellipse Export�� PenWidth�� Twip ������ �׸����� ����

		if (!bSetRenderEnv)
		{
			BRTHREAD_ASSERT(0);
#if 0			
			BrRect rcFigureClip, rcFillClip;
			enableTemplateMode(BrTRUE, x2-x1, y2-y1, rcFigureClip, rcFillClip);
			if(m_pFigureClipBox)
				BR_RECT_MOVE_PTR(m_pFigureClipBox, -x1, -y1);
			if(m_pFillClipBox)
				BR_RECT_MOVE_PTR(m_pFillClipBox, -x1, -y1);				
			BrDC:: rectangle(x1-x1, y1-y1, x2-x1, y2-y1, bFill);
			doExport(x1, y1, BrFALSE);
			enableTemplateMode(BrFALSE, 0, 0, rcFigureClip, rcFillClip);
#endif //0			
		}
		else
		{
			BrFRect rect = {(BrFLOAT)(x1+m_sExtInfo.nPosX), (BrFLOAT)(y1+m_sExtInfo.nPosY), (BrFLOAT)(x2+m_sExtInfo.nPosX), (BrFLOAT)(y2+m_sExtInfo.nPosY)};
			poExport_BeginPath();
			poExport_Rect(&rect, bFill);	
			poExport_EndPath();
		}
		enableFillTemplateRender(BrFALSE, 0, 0);
		poExport_SetPenWidthTwip(bIsOldTwipPenWidth);
	}
	else
	{
		BrDC::rectangle(x1, y1, x2, y2, bFill);
	}
}

BrBOOL BrExportPDFDC::fillPolygon(LPBrPOINT lpp, BrUINT32 nCount)
{
	if(BR_ISSET_STATE(m_nExtFalg, eHasDirectExtDCState))
	{
		BrRect rcBound;
		doExport(0, 0, BrTRUE);
		rcBound = CUtil::BrBoundary(lpp, nCount);
		enableFillTemplateRender(BrTRUE, BrABS(rcBound.right-rcBound.left), BrABS(rcBound.bottom-rcBound.top));

		if(!setExportRenderEnv(BrTRUE))
		{
			BRTHREAD_ASSERT(0);
			enableFillTemplateRender(BrFALSE);
			return BrFALSE;
		}
		else
		{
			BrPOINT sOffset = {m_sExtInfo.nPosX, m_sExtInfo.nPosY};		
			poExport_BeginPath();
			poExport_Polygon(&sOffset, lpp, nCount, BrTRUE, BrFALSE);
			poExport_EndPath();
			enableFillTemplateRender(BrFALSE);
			return BrTRUE;
		}
	}
	else
	{
		return BrDC::fillPolygon(lpp, nCount);
	}
}



BrBOOL BrExportPDFDC::polygon(LPBrPOINT lpp, BrUINT32 nCount, BrBOOL bFill)
{
	if(BR_ISSET_STATE(m_nExtFalg, eHasDirectExtDCState))
	{
		BrRect rcBound;
		doExport(0, 0, BrTRUE);
		rcBound = CUtil::BrBoundary(lpp, nCount);

		if(m_pPen->m_sLogPen.nPenType == eGradientPen)
		{
			BrINT garoPenWidth = 0;
			BrINT seroPenWidth = 0;
			setGaroSeroGradientPenWidth(m_pPen->getPenWidth(), rcBound, &garoPenWidth, &seroPenWidth);
			BrRect rcFigureClip, rcFillClip;
			BrINT oldangle = m_sExtInfo.nRotateAngle;
			BrBYTE oldFlip = m_nFigureFlipType;

			if(enableTemplateMode(BrTRUE, BrABS(rcBound.right-rcBound.left) + garoPenWidth*2, BrABS(rcBound.bottom-rcBound.top) + seroPenWidth*2, rcFigureClip, rcFillClip))
			{
				enableAlphaBitmapDC(BrTRUE);
				for(BrINT i = 0; i<nCount; i++)
				{
					lpp[i].x +=garoPenWidth;
					lpp[i].y +=seroPenWidth; // [2015.09.03][235] ���� garo, sero�� PenWidth��ŭ �����ش�.
				}
				setRotateAngle(0);
				setFigureFlip(eFigureFlipNone);
				BrDC::polygon(lpp, nCount, BrFALSE);
				BR_REL_STATE(m_nExtFalg, eHasDataExtDCState);
				enableTemplateMode(BrFALSE, 0, 0, rcFigureClip, rcFillClip);

				BrLONG scaleWidth = twips2DeviceX(Device2twips(m_pTemplate->getDib()->biWidth, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
				BrLONG scaleHeight = twips2DeviceY(Device2twips(m_pTemplate->getDib()->biHeight, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, 0, TARGET_DEVICE_RESOLUTION);

				if((m_pTemplate->getDib()->biWidth != scaleWidth) || (m_pTemplate->getDib()->biHeight != scaleHeight))
					m_pTemplate->scaleEx(scaleWidth, scaleHeight, m_pTemplate);

				BrBmvBrush* pTBrush = BrNULL;
				pTBrush = BrNEW BrBmvBrush;
				//m_pTemplate->dumpImage(0, 0, 0);
				pTBrush->createDIBBrush(m_pTemplate);
				m_pBrush = pTBrush;

				setFigureFlip(oldFlip);
				setRotateAngle(oldangle);
				m_pBrush->setEnableRotate(BrTRUE);
				m_pPen->m_sLogPen.nPenType = eNormalPen;

				// [2015.09.03][235] ClipBox�� ũ�⸦ garoPenWidth �� seroPenWidth�� +,- �������μ� �� �߾ӿ� Gradation ȿ���� ����� �� �ֵ��� ���ش�.
				BrRect rcNewFigureClip = {(m_pFigureClipBox->left - garoPenWidth), (m_pFigureClipBox->top - seroPenWidth), (m_pFigureClipBox->right + garoPenWidth), (m_pFigureClipBox->bottom + seroPenWidth)};
				setFigureClipBox(&rcNewFigureClip, NULL);
				fillRect(m_pFigureClipBox->left, m_pFigureClipBox->top, m_pFigureClipBox->right, m_pFigureClipBox->bottom);
				m_pPen->m_sLogPen.nPenType = eGradientPen;
			}
			return BrTRUE;
		}
		enableFillTemplateRender(BrTRUE, BrABS(rcBound.right-rcBound.left), BrABS(rcBound.bottom-rcBound.top));

		BrBOOL bSetRenderEnv = setExportRenderEnv(bFill); // PDF�� ��� ExportRender Enviroment�� ���� ����
		BrBOOL bIsOldTwipPenWidth = BrFALSE;

		if(m_bIsTwipPenWidth)
			bIsOldTwipPenWidth = poExport_SetPenWidthTwip(m_bIsTwipPenWidth); // [2015.06.08][235] Ellipse Export�� PenWidth�� Twip ������ �׸����� ����

		if (!bSetRenderEnv)
		{
			BRTHREAD_ASSERT(0);
			enableFillTemplateRender(BrFALSE);
			return BrFALSE;
		}
		else
		{
			BrPOINT sOffset = {m_sExtInfo.nPosX, m_sExtInfo.nPosY};		
			poExport_BeginPath();
			poExport_Polygon(&sOffset, lpp, nCount, bFill, BrTRUE);
			poExport_EndPath();
			enableFillTemplateRender(BrFALSE);
			poExport_SetPenWidthTwip(bIsOldTwipPenWidth);
			return BrTRUE;
		}
	}
	else
	{
		return BrDC::polygon(lpp, nCount, bFill);
	}
}

BrBOOL BrExportPDFDC::polyBezier(LPBrPOINT lpp, BrUINT32 nCount, BrBOOL bFill)
{
	return poExport_PolyBezier(lpp, nCount, bFill);
}

BrBOOL BrExportPDFDC::polyline(LPBrPOINT lpp, BrUINT32 nCount)
{
	if(BR_ISSET_STATE(m_nExtFalg, eHasDirectExtDCState))
	{
		BrRect rcBound;
		doExport(0, 0, BrTRUE);
		rcBound = CUtil::BrBoundary(lpp, nCount);
		enableFillTemplateRender(BrTRUE, BrABS(rcBound.right-rcBound.left), BrABS(rcBound.bottom-rcBound.top));

		BrBOOL bIsOldTwipPenWidth = BrFALSE; 
		if(m_bIsTwipPenWidth)
			bIsOldTwipPenWidth = poExport_SetPenWidthTwip(m_bIsTwipPenWidth);

		if(!setExportRenderEnv(BrTRUE))
		{
			BRTHREAD_ASSERT(0);
			enableFillTemplateRender(BrFALSE);
			return BrFALSE;
		}
		else
		{
			BrPOINT sOffset = {m_sExtInfo.nPosX, m_sExtInfo.nPosY};		
			poExport_BeginPath();
			poExport_PolyLine(&sOffset, lpp, nCount);
			poExport_EndPath();
			enableFillTemplateRender(BrFALSE);
			bIsOldTwipPenWidth = poExport_SetPenWidthTwip(m_bIsTwipPenWidth);
			return BrTRUE;
		}
	}
	else
	{
		return BrDC::fillPolygon(lpp, nCount);
	}
}


//4���� ��������Ŀ�긦 �����Ѵ�.(��ŸƮ ������ �����Ͽ� 13���� ���� ������)
BrBOOL	BrExportPDFDC::ellipse2Bezier(BrFPOINT center, BrFLOAT fRadius, BArray<BrFPOINT>& bezierPoint)
{
	bezierPoint.resize(13);	//start point ����(moveTo ����)
	const BrFLOAT magicNum = (BrFLOAT)0.5522847498;
	BrFLOAT magicRadius = magicNum * fRadius;

	bezierPoint[0].x = fRadius;			bezierPoint[0].y = 0.f;
	bezierPoint[1].x = fRadius;			bezierPoint[1].y = magicRadius;
	bezierPoint[2].x = magicRadius;		bezierPoint[2].y = fRadius;
	bezierPoint[3].x = 0.f;				bezierPoint[3].y = fRadius;

	bezierPoint[4].x = -magicRadius;	bezierPoint[4].y = fRadius;
	bezierPoint[5].x = -fRadius;		bezierPoint[5].y = magicRadius;
	bezierPoint[6].x = -fRadius;		bezierPoint[6].y = 0.f;

	bezierPoint[7].x = -fRadius;		bezierPoint[7].y = -magicRadius;
	bezierPoint[8].x = -magicRadius;	bezierPoint[8].y = -fRadius;
	bezierPoint[9].x = 0.f;				bezierPoint[9].y = -fRadius;

	bezierPoint[10].x = magicRadius;	bezierPoint[10].y = -fRadius;
	bezierPoint[11].x = fRadius;		bezierPoint[11].y = -magicRadius;
	bezierPoint[12].x = fRadius;		bezierPoint[12].y = 0.f;

	for(int i = 0 ; i < bezierPoint.size() ; i++)
	{
		bezierPoint[i].x += center.x;
		bezierPoint[i].y += center.y;
	}
	return BrTRUE;
}

//������ ������ ��ٸ����� �����Ѵ� ������ �Ʒ����� ������ �β��� �ȴ�.
BrBOOL BrExportPDFDC::makeTrapezoidPoint(BrFPOINT fCenter1, BrFLOAT fRadius1, BrFPOINT fCenter2, BrFLOAT fRadius2, BArray<BrFPOINT>& trapezoidPoint)
{
	if(fCenter1.x == fCenter2.x && fCenter1.y == fCenter2.y)
		return BrFALSE;

	if (trapezoidPoint.size() != 4)
		trapezoidPoint.resize(4);

	BrFPOINT directionVector = { fCenter2.x - fCenter1.x , fCenter2.y - fCenter1.y };
	BrFLOAT distance = BrSqrt(directionVector.x * directionVector.x + directionVector.y * directionVector.y );

	BrFPOINT normalizedVector = {directionVector.x/distance, directionVector.y/distance};

	BrFPOINT normalizedUnClockVector, normalizedClockVector; 

	normalizedClockVector.x		= -normalizedVector.y; //MS ��ǥ��(y�� ������ ������ ���)���� directionVector �� �ð�ȸ���� ��������
	normalizedClockVector.y		= normalizedVector.x;

	normalizedUnClockVector.x	= -normalizedClockVector.x;//MS ��ǥ��(y�� ������ ������ ���)���� directionVector �� �ݽð�ȸ���� ��������
	normalizedUnClockVector.y	= -normalizedClockVector.y;


	trapezoidPoint[0].x	= normalizedClockVector.x * fRadius1	+ fCenter1.x;
	trapezoidPoint[0].y	= normalizedClockVector.y * fRadius1	+ fCenter1.y;

	trapezoidPoint[1].x	= normalizedUnClockVector.x * fRadius1	+ fCenter1.x;
	trapezoidPoint[1].y	= normalizedUnClockVector.y * fRadius1	+ fCenter1.y;

	trapezoidPoint[2].x	= normalizedUnClockVector.x * fRadius2	+ fCenter2.x;
	trapezoidPoint[2].y	= normalizedUnClockVector.y * fRadius2	+ fCenter2.y;

	trapezoidPoint[3].x	= normalizedClockVector.x * fRadius2	+ fCenter2.x;
	trapezoidPoint[3].y	= normalizedClockVector.y * fRadius2	+ fCenter2.y;

	return BrTRUE;
}

#ifdef USE_PDFEXPORT_INKANNOT
void BrExportPDFDC::inkmlExport(BRect rt, BrCOLORREF color, void* inkList)
{
	BoraInkAnnotInfo annotInfo = { 0, };

	BrEXPORT_INFO exportInfo = { 0, };
	getExport(&exportInfo);

	annotInfo.bOpen = false;
	annotInfo.nLeft = rt.Left() + exportInfo.nPosX;
	annotInfo.nTop = rt.Top() + exportInfo.nPosY;
	annotInfo.nRight = rt.Right() + exportInfo.nPosX;
	annotInfo.nBottom = rt.Bottom() + exportInfo.nPosY;
	annotInfo.fColor = color;
	annotInfo.nWidth = m_pPen->getPenWidth();

	char a_szTitle[BORA_FULLPATH_LENGTH] = { 0, };
	char a_szAuthor[BORA_FULLPATH_LENGTH] = { 0, };
	char a_szModifiedBy[BORA_FULLPATH_LENGTH] = { 0, };
	char a_szAppName[BORA_FULLPATH_LENGTH] = { 0, };
	int  a_nPage = 0;
	int	 a_nWords = 0;
	bool a_bSavePreview = BrFALSE;

	BrGetSummaryData(a_szTitle, sizeof(a_szTitle), a_szAuthor, sizeof(a_szAuthor), a_szModifiedBy, sizeof(a_szModifiedBy), &a_nPage, &a_nWords, &a_bSavePreview, a_szAppName, sizeof(a_szAppName));

	if (BrStrLen(a_szAuthor))
	{
		annotInfo.nAuthorLen = BrStrLen(a_szAuthor);
		annotInfo.pszAuthor = (BrUINT16*)a_szAuthor;
	}
	else
	{
		annotInfo.nAuthorLen = 0;
		annotInfo.pszAuthor = BrNULL;
	}


	BrWCHAR strWideSubj[BORA_FULLPATH_LENGTH] = { 0, };
	
	BrINT nLen = BrMultiByteToWideChar(CP_ACP, (BrLPCSTR)"����", BrStrLen("����"), (BrLPWSTR)& strWideSubj, BORA_FULLPATH_LENGTH);

	strWideSubj[nLen] = '\0';

	if (nLen)
	{
		annotInfo.nSubjectLen = nLen;
		annotInfo.pszSubject = (BrUINT16*)strWideSubj;
	}
	else
	{
		annotInfo.nSubjectLen = 0;
		annotInfo.pszSubject = BrNULL;
	}

	annotInfo.offsetX = exportInfo.nPosX;
	annotInfo.offsetY = exportInfo.nPosY;

	annotInfo.inkList = inkList;

	poExport_AddInkAnnot(&annotInfo);
}
#endif // USE_PDFEXPORT_INKANNOT

#ifdef USE_PDFEXPORT_TEXTBOX
void BrExportPDFDC::textBoxExport(BrINT32 nPageNum, BRect rt, BrINT nBorderWidth, BrCOLORREF borderColor, BrCOLORREF bgColor, BString* strData)
{
	BoraFreetextAnnotInfo annotInfo = { 0, };

	const BChar* pCh = strData->unicode();
	BrINT strLen = strData->length();
	BrINT i = 0;

	BrEXPORT_INFO exportInfo = { 0, };
	getExport(&exportInfo);

	BrULONG* str = (BrULONG*)BrMalloc(strLen * BrSizeOf(BrULONG) + 1);
	memset(str, 0, strLen + 1);
	for (i = 0; i < strLen; i++)
	{
		str[i] = pCh[i].unicode();
	}

	annotInfo.nPageNum = nPageNum;
	annotInfo.nLeft = rt.Left() + exportInfo.nPosX;
	annotInfo.nTop = rt.Top() + exportInfo.nPosY;
	annotInfo.nRight = rt.Right() + exportInfo.nPosX;
	annotInfo.nBottom = rt.Bottom() + exportInfo.nPosY;
	annotInfo.borderWidth = nBorderWidth;
	annotInfo.borderColor = borderColor;
	annotInfo.bgColor = bgColor;
	annotInfo.szText = str;
	annotInfo.nTextLen = strLen;

	poExport_AddFreeTextBox(&annotInfo);

	BR_SAFE_FREE(str);
}
#endif // USE_PDFEXPORT_TEXTBOX

BrBOOL BrExportPDFDC::polyline_Draw_All(LPBrFPOINT lpp, BrFLOAT* width, BrUINT32 nCount, BrFPOINT* pOffset)
{
	if(nCount < 2)
		return BrFALSE;
	else if(m_pPen == BrNULL || m_pPen->m_sLogPen.nPenStyle == eNullPen)
		return BrFALSE;

	BrFPOINT sOffset = {0.,0.};
	if(pOffset)
		sOffset = *pOffset;

	BrPUBLIC_MEMPOOL sMPool = {0};
	BrUINT nLineCnt = nCount, nSize = BrSizeOf(BrDPoint)*nLineCnt;

	BArray<BrFPOINT>	floatBezierPoint(13);
	BArray<BrPoint>		intBezierPoint(13);
	BArray<BrFPOINT>	floatTrapeZoidPoint(4);
	BArray<BrPoint>		intTrapeZoidPoint(4);
	for (BrINT i = 0 ; i < nCount ; i++)
	{
		poExport_BeginPath();
		//poExport_SetPenAtt(m_nPenWidth, m_cPenColor, m_nPenStyle);	
		//poExport_SetPenAtt(m_pPen->getPenWidth(), m_pPen->getPenColor(), eSolidPen, eSquareLineCap, eMiterLineJoin);
		//poExport_SetPenAtt(m_pPen->getPenWidth(), m_pPen->getPenColor(), eSolidPen);
		poExport_SetBrushColor(m_pPen->getPenColor());
		poExport_SetGState(m_nSourceConstantAlpha, COLOR_OPAQUE);
		//poExport_BezierCurveTo(&pos1, &pos2, &pos3);
		ellipse2Bezier(lpp[i], width[i] / 2.0f , floatBezierPoint);//��������� ���� ����� �˰����� ����//width �� ���� �� �β��� �����ȴ�.
		for(int j = 0; j < 13; j++)
		{
			floatBezierPoint[j].x += m_sExtInfo.nPosX;
			floatBezierPoint[j].y += m_sExtInfo.nPosY;
		}
		//float2intPoint(floatBezierPoint, intBezierPoint);					//int ������ ����
		//inkmlMetaWriter.MoveTo(intBezierPoint[0].x, intBezierPoint[0].y);	//�н� ����
		poExport_MoveTo(&floatBezierPoint[0], BrTRUE);
		//inkmlMetaWriter.PolyBezierTo16(intBezierPoint.size() - 1 , &(intBezierPoint[1]));//PolyBezierTo16 ���ο��� closeFigure ���� ������ �����ϰ� ����
		poExport_BezierCurveTo(&floatBezierPoint[ 1], &floatBezierPoint[ 2], &floatBezierPoint[ 3]);
		poExport_BezierCurveTo(&floatBezierPoint[ 4], &floatBezierPoint[ 5], &floatBezierPoint[ 6]);
		poExport_BezierCurveTo(&floatBezierPoint[ 7], &floatBezierPoint[ 8], &floatBezierPoint[ 9]);
		poExport_BezierCurveTo(&floatBezierPoint[10], &floatBezierPoint[11], &floatBezierPoint[12]);
		poExport_EndPathEx(BrFALSE, BrTRUE);

		if ( i + 1 < nLineCnt )	//�� ��ǥ�� �������� �ƴϸ� ������ǥ�� �����Ѵٸ�
		{
			if ( lpp[i].x != lpp[i+1].x || lpp[i].y != lpp[i+1].y )	// ���� ��ǥ��� trapezoid �� ������ �ʵ��� �Ѵ�.
			{
				poExport_BeginPath();
				//poExport_SetPenAtt(m_nPenWidth, m_cPenColor, m_nPenStyle);	
				//poExport_SetPenAtt(m_pPen->getPenWidth(), m_pPen->getPenColor(), eSolidPen);
				poExport_SetBrushColor(m_pPen->getPenColor());
				poExport_SetGState(m_nSourceConstantAlpha, COLOR_OPAQUE);
				makeTrapezoidPoint(lpp[i], width[i] / 2.0f, lpp[i+1], width[i+1] / 2.0f, floatTrapeZoidPoint);	//trapezoid ����

				for(int j = 0; j < 4; j++)
				{
					floatTrapeZoidPoint[j].x += m_sExtInfo.nPosX;
					floatTrapeZoidPoint[j].y += m_sExtInfo.nPosY;
				}

				//float2intPoint(floatTrapeZoidPoint, intTrapeZoidPoint);
				//inkmlMetaWriter.MoveTo(intTrapeZoidPoint[0].x, intTrapeZoidPoint[0].y);
				poExport_MoveTo(&floatTrapeZoidPoint[0], BrTRUE);
				//inkmlMetaWriter.PolyLineTo16( intTrapeZoidPoint.size() - 1, &(intTrapeZoidPoint[1]) );//PolyLineTo16 ���ο��� closeFigure ���� ������ �����ϰ� ����
				poExport_LineTo(&floatTrapeZoidPoint[1], BrFALSE, BrTRUE);
				poExport_LineTo(&floatTrapeZoidPoint[2], BrFALSE, BrTRUE);
				poExport_LineTo(&floatTrapeZoidPoint[3], BrFALSE, BrTRUE);
				poExport_EndPathEx(BrFALSE, BrTRUE);
			}
		}
	}

	return BrTRUE;
}

BrBOOL BrExportPDFDC::drawPath(BrBOOL bFill)
{
	if(BR_ISSET_STATE(m_nExtFalg, eHasDirectExtDCState))
	{
		LPBrLOGOBJPATH pObjPath = m_ObjPath.getObjPathData();

		if(pObjPath && pObjPath->nObjCnt)
		{
			BrINT i = 0;
			BrFPOINT sToPos = {0,0}, sStartPos = {0,0};
			BrBOOL bSetStartPos = BrFALSE;

			BrBYTE nObjType = eMaxObjType;
			BrBOOL bIsAvailFillandStroke = BrFALSE;

			doExport(0, 0, BrTRUE);
			if(m_pPen->m_sLogPen.nPenType == eGradientPen) // �׶���Ʈ ���� ��� 
			{
				BrRect rcBound = {m_pFigureClipBox->left, m_pFigureClipBox->top, m_pFigureClipBox->right, m_pFigureClipBox->bottom};
				BrINT garoPenWidth = 0;
				BrINT seroPenWidth = 0;

				setGaroSeroGradientPenWidth(m_pPen->getPenWidth(), rcBound, &garoPenWidth, &seroPenWidth);
				//drawPath �� ���� �� Ư�� ���̽� ( ����� : 32-point star ���� ��� ) �� �־� penwidth �� drawpath �� Ÿ�� ��� ���� ũ�� ����ش�.
				garoPenWidth *= 3; seroPenWidth *= 3;

				BrRect rcFigureClip, rcFillClip;
				BrINT oldangle = m_sExtInfo. nRotateAngle;
				BrBYTE oldFlip = m_nFigureFlipType;

				if(enableTemplateMode(BrTRUE, BrABS(rcBound.right-rcBound.left)+(2*garoPenWidth), BrABS(rcBound.bottom-rcBound.top)+(2*seroPenWidth), rcFigureClip, rcFillClip))
				{
					enableAlphaBitmapDC(BrTRUE);
					m_ExtOffset.x = garoPenWidth;
					m_ExtOffset.y = seroPenWidth;

					setRotateAngle(0);
					setFigureFlip(eFigureFlipNone);
					BrDC::drawPath(BrFALSE);
					BR_REL_STATE(m_nExtFalg, eHasDataExtDCState);
					enableTemplateMode(BrFALSE, 0, 0, rcFigureClip, rcFillClip);

					//[2014.06.09] dpi 300 ���� �����Ͽ� ���� �� �ÿ� �������� �׶��̼� ���� ũ�� export �Ǵ� ����. dpi �������� ���� �귯�� �̹����� size�� ����Ǿ�� �� ��쿡 scale �� �ش�.

					BrLONG scaleWidth = twips2DeviceX(Device2twips(m_pTemplate->getDib()->biWidth, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
					BrLONG scaleHeight = twips2DeviceY(Device2twips(m_pTemplate->getDib()->biHeight, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, 0, TARGET_DEVICE_RESOLUTION);

					if((m_pTemplate->getDib()->biWidth != scaleWidth) || (m_pTemplate->getDib()->biHeight != scaleHeight))
						m_pTemplate->scaleEx(scaleWidth, scaleHeight, m_pTemplate);

					BrBmvBrush* pTBrush = BrNULL;
					pTBrush = BrNEW BrBmvBrush;
					pTBrush->createDIBBrush (m_pTemplate);
					m_pBrush = pTBrush;

					setFigureFlip(oldFlip);
					setRotateAngle(oldangle);
					m_pBrush->setEnableRotate(BrTRUE);
					m_pPen->m_sLogPen.nPenType = eNormalPen;

					//[2014.06.09] �׶��̼� ���� ��� ���� figurebox ���� ũ�� export �ؾ� �Ѵ�.
					BrRect rcNewFigureClip = {(m_pFigureClipBox->left - garoPenWidth), (m_pFigureClipBox->top - seroPenWidth), (m_pFigureClipBox->right + garoPenWidth), (m_pFigureClipBox->bottom + seroPenWidth)};
					setFigureClipBox(&rcNewFigureClip, BrNULL);
					fillRect(m_pFigureClipBox->left, m_pFigureClipBox->top, m_pFigureClipBox->right, m_pFigureClipBox->bottom);
					setFigureClipBox(&rcBound, BrNULL); // [2015.09.03][235] Gradation ȿ���� �� �� �̻�Ҹ��� Polygon������ ��츦 ����Ͽ� ������ �����س��� oldClipBox�� �ǵ�����.
					m_pPen->m_sLogPen.nPenType = eGradientPen;
				}
				return BrTRUE;
			}

			enableFillTemplateRender(BrTRUE, BrABS(m_pFigureClipBox->right - m_pFigureClipBox->left), BrABS(m_pFigureClipBox->bottom - m_pFigureClipBox->top));

			BrBOOL bSetRenderEnv = setExportRenderEnv(bFill); // PDF�� ��� ExportRender Enviroment�� ���� ����
			BrBOOL bIsOldTwipPenWidth = BrFALSE;

			if(m_bIsTwipPenWidth)
				bIsOldTwipPenWidth = poExport_SetPenWidthTwip(m_bIsTwipPenWidth); // [2015.06.08][235] Export�� PenWidth�� Twip ������ �׸����� ����

			if (!bSetRenderEnv)
			{
				BRTHREAD_ASSERT(0);
				enableFillTemplateRender(BrFALSE);
				return BrFALSE;
			}
			else
			{
				LPBrLOGARROW pHeadArrow = (bFill || m_pPen->isDIBPen())? BrNULL:m_pPen->getHeadArrow();
				LPBrLOGARROW pTailArrow = (bFill || m_pPen->isDIBPen())? BrNULL:m_pPen->getTailArrow();		
				BrFPOINT sHeadArrowPoint1 = {0, 0}, sHeadArrowPoint2 = {0, 0}; //ȭ��ǥ�� �׷��� line�� ����, �� ��ġ ����(�ش� ������ ������ ȭ��ǥ�� ������ ����)
				BrFPOINT sTailArrowPoint1 = {0, 0}, sTailArrowPoint2 = {0, 0};
				BrINT32 nHeadArrowObjIndex = -1;
				BrINT32 nTailArrowObjIndex = -1;

				BrFPOINT HeadArrowpos[4] = {0,};
				BrFPOINT TailArrowpos[4] = {0,};

				BrBOOL isArrow = BrFALSE;

				if(pHeadArrow || pTailArrow) 
				{
					//getArrowIndexFromObjPath(pObjPath,(pHeadArrow)? &nHeadArrowObjIndex : BrNULL, (pTailArrow)? &nTailArrowObjIndex : BrNULL);

					m_ExtOffset.x = 0;
					m_ExtOffset.y = 0;
					getStartEndLineIndexFromObjPath(pObjPath, BrNULL, BrNULL, (pTailArrow)? &nTailArrowObjIndex : BrNULL, (pHeadArrow)? &nHeadArrowObjIndex : BrNULL, m_ExtOffset); //protected
					isArrow = BrTRUE;
				}

				poExport_BeginPath();

				for(i = 0; i < pObjPath->nObjCnt; i++)
				{
					nObjType = pObjPath->aObjType.at(i);
					switch(nObjType)
					{
					case eMoveToObj:
						{
							LPBrLINEOBJPAHT pMoveTo = (LPBrLINEOBJPAHT)pObjPath->aObjPtr.at(i);
							//m_MovePos = *pMoveTo;
							sToPos.x = pMoveTo->x + m_sExtInfo.nPosX;
							sToPos.y = pMoveTo->y + m_sExtInfo.nPosY;
							if(!bSetStartPos)
							{
								sStartPos = sToPos;
								bSetStartPos = BrTRUE;
							}

							if(nTailArrowObjIndex == i+1) //���� obj �� Tail ȭ��ǥ�� �ִٸ� 
							{
								BrBYTE pNextObjType = pObjPath->aObjType.at(i+1);
								if(pNextObjType == eLineToObj || pNextObjType == ePolylineToObj || pNextObjType == ePolyBezierToObj || pNextObjType == eArcObj)
								{
									break;
								}
								else
									poExport_MoveTo(&sToPos, BrTRUE); // [2015.09.02][235] �Ҽ����� ������ �ʰ� MoveTo�ϵ��� boolean �߰�
							}
							else
								poExport_MoveTo(&sToPos, BrTRUE);
						}				
						break;
					case eLineToObj:
						{
							LPBrLINEOBJPAHT pLineTo = (LPBrLINEOBJPAHT)pObjPath->aObjPtr.at(i);
							//m_MovePos = *pLineTo;
							sToPos.x = pLineTo->x + m_sExtInfo.nPosX;
							sToPos.y = pLineTo->y + m_sExtInfo.nPosY;
							BrDPoint  p3, p4;
							BrDOUBLE dHMove = 0;
							BrDOUBLE dTMove = 0;
							BrDPoint sArrowMovePos={sStartPos.x, sStartPos.y};
							BrDPoint sArrowLinePos={sToPos.x, sToPos.y};

							if(nTailArrowObjIndex == i)
							{	
								sTailArrowPoint1.x = sToPos.x;
								sTailArrowPoint1.y = sToPos.y; 
								sTailArrowPoint2.x = sStartPos.x;	
								sTailArrowPoint2.y = sStartPos.y;	
								dTMove = m_pPen->getArrowInfo(m_pPen->getBaseLineWidth(), m_pPen->getLineWidth(), pTailArrow, m_pPen->getScaleFact(), BrNULL, BrNULL, BrNULL, m_pPen->getLineStyle());

								if(getLineOffsetByArrow(&sArrowMovePos, &sArrowLinePos, &dTMove, &dHMove, &p3, &p4))
								{
									BrFPOINT sAlterPos = {(BrFLOAT)p3.x, (BrFLOAT)p3.y};
									poExport_MoveTo(&sAlterPos);
								}
							}
							if(nHeadArrowObjIndex == i)
							{									
								sHeadArrowPoint1.x = sStartPos.x;	
								sHeadArrowPoint1.y = sStartPos.y; 
								sHeadArrowPoint2.x = sToPos.x;	
								sHeadArrowPoint2.y = sToPos.y;
								dHMove = m_pPen->getArrowInfo(m_pPen->getBaseLineWidth(), m_pPen->getLineWidth(), pHeadArrow, m_pPen->getScaleFact(), BrNULL, BrNULL, BrNULL, m_pPen->getLineStyle());

								if(getLineOffsetByArrow(&sArrowMovePos, &sArrowLinePos, &dTMove, &dHMove, &p3, &p4))
								{
									sToPos.x = p4.x;
									sToPos.y = p4.y;
								}
							}
							poExport_LineTo(&sToPos);	
						}
						break;
					case eEllipseObj:
						{
							LPBrARCOBJPATH pEllipse = (LPBrARCOBJPATH)pObjPath->aObjPtr.at(i);

							BrRect rect = {(BrLONG)(pEllipse->x1 + m_sExtInfo.nPosX), (BrLONG)(pEllipse->y1 + m_sExtInfo.nPosY), (BrLONG)(pEllipse->x2 + m_sExtInfo.nPosX), (BrLONG)(pEllipse->y2 + m_sExtInfo.nPosY)};
							poExport_Ellipse(rect.left, rect.top, rect.right, rect.bottom, bFill, !bFill); 

						}
						break;
					case ePolylineToObj:	
						{			
							LPBrPOLYGONOBJPATH pPolyLine = (LPBrPOLYGONOBJPATH)pObjPath->aObjPtr.at(i);
							BrDPoint  p3, p4;
							BrDOUBLE dHMove = 0;
							BrDOUBLE dTMove = 0;
							BrDPoint sArrowMovePos={sStartPos.x, sStartPos.y};
							BrDPoint sArrowLinePos={sToPos.x, sToPos.y};
							BrDPoint sPrevPos = {0, 0};
							BrUINT32 nPolyLineCount = pPolyLine->count;

							for(BrINT j = 0; j < nPolyLineCount; j++)
							{
								sPrevPos.x = sToPos.x;	sPrevPos.y = sToPos.y;
								sToPos.x = pPolyLine->lpp[j].x + m_sExtInfo.nPosX;
								sToPos.y = pPolyLine->lpp[j].y + m_sExtInfo.nPosY;

								sArrowLinePos.x = sToPos.x;
								sArrowLinePos.y = sToPos.y;

								if(j==0 && nTailArrowObjIndex == i)
								{
									dTMove = m_pPen->getArrowInfo(m_pPen->getBaseLineWidth(), m_pPen->getLineWidth(), pTailArrow, m_pPen->getScaleFact(), BrNULL, BrNULL, BrNULL, m_pPen->getLineStyle());
									if(getLineOffsetByArrow(&sArrowMovePos, &sArrowLinePos, &dTMove, &dHMove, &p3, &p4))
									{
										BrFPOINT sAlterPos = {(BrFLOAT)p3.x, (BrFLOAT)p3.y};
										poExport_MoveTo(&sAlterPos);
									}

									sTailArrowPoint1.x = pPolyLine->lpp[0].x + m_sExtInfo.nPosX;
									sTailArrowPoint1.y = pPolyLine->lpp[0].y + m_sExtInfo.nPosY;	
									sTailArrowPoint2.x = sStartPos.x;
									sTailArrowPoint2.y = sStartPos.y;
								}
								if(j+1 == pPolyLine->count && nHeadArrowObjIndex == i) //������ line �̰� head arrow �� ���� ��� 
								{
									sArrowMovePos.x = sPrevPos.x;	sArrowMovePos.y = sPrevPos.y; // Loop ���� �� ��ǥ ���
									/* ����ȭ ���� �ڵ�
									sArrowMovePos.x = pPolyLine->lpp[j-1].x + m_sExtInfo.nPosX;
									sArrowMovePos.y = pPolyLine->lpp[j-1].y + m_sExtInfo.nPosY; 

									if(sArrowMovePos.x == sArrowLinePos.x && sArrowMovePos.y == sArrowLinePos.y)
									{
										BrINT reCount = 2;
										while(sArrowMovePos.x == sArrowLinePos.x && sArrowMovePos.y == sArrowLinePos.y)
										{
											sArrowMovePos.x = pPolyLine->lpp[j-reCount].x + m_sExtInfo.nPosX;
											sArrowMovePos.y = pPolyLine->lpp[j-reCount].y + m_sExtInfo.nPosY;
											reCount++;
										}
									} */


									dHMove = m_pPen->getArrowInfo(m_pPen->getBaseLineWidth(), m_pPen->getLineWidth(), pHeadArrow, m_pPen->getScaleFact(), BrNULL, BrNULL, BrNULL, m_pPen->getLineStyle());

									if(getLineOffsetByArrow(&sArrowMovePos, &sArrowLinePos, &dTMove, &dHMove, &p3, &p4))
									{
										sToPos.x = p4.x;
										sToPos.y = p4.y;
									}

									/* ����ȭ ���� �ڵ�
									sHeadArrowPoint1.x = pPolyLine->lpp[pPolyLine->count-2].x + m_sExtInfo.nPosX;
									sHeadArrowPoint1.y = pPolyLine->lpp[pPolyLine->count-2].y + m_sExtInfo.nPosY; 
									sHeadArrowPoint2.x = pPolyLine->lpp[pPolyLine->count-1].x + m_sExtInfo.nPosX;
									sHeadArrowPoint2.y = pPolyLine->lpp[pPolyLine->count-1].y + m_sExtInfo.nPosY;

									if(sHeadArrowPoint1.x == sHeadArrowPoint2.x && sHeadArrowPoint1.y == sHeadArrowPoint2.y)
									{
										BrINT reCount = 3;
										while((sHeadArrowPoint1.x == sHeadArrowPoint2.x) && (sHeadArrowPoint1.y == sHeadArrowPoint2.y))
										{
											sHeadArrowPoint1.x = pPolyLine->lpp[pPolyLine->count-reCount].x + m_sExtInfo.nPosX;
											sHeadArrowPoint1.y = pPolyLine->lpp[pPolyLine->count-reCount].y + m_sExtInfo.nPosY;
											reCount++;
										}
									} */

									sHeadArrowPoint1.x = sPrevPos.x;	sHeadArrowPoint1.y = sPrevPos.y;
									sHeadArrowPoint2.x = sArrowLinePos.x;	sHeadArrowPoint2.y = sArrowLinePos.y;
								}

								if(!((j+2 == pPolyLine->count) && (sToPos.x == pPolyLine->lpp[j+1].x + m_sExtInfo.nPosX && sToPos.y == pPolyLine->lpp[j+1].y + m_sExtInfo.nPosY)))
									poExport_LineTo(&sToPos, BrFALSE, BrTRUE);
							}
						}
						break;
					case eArcObj:
						{
							LPBrARCOBJPATH pArcTo = (LPBrARCOBJPATH)pObjPath->aObjPtr.at(i);
							//poExport_ArcTo(pArcTo->x1 + m_sExtInfo.nPosX, pArcTo->y1 + m_sExtInfo.nPosY, pArcTo->x2 + m_sExtInfo.nPosX, pArcTo->y2 + m_sExtInfo.nPosY, BrDEGtoRAD(pArcTo->a0), BrDEGtoRAD(pArcTo->a1));							
							/*BrFLOAT fA0 = pArcTo->a0-(BrFLOAT)((BrINT)(pArcTo->a0/360.0)*360);
							BrFLOAT fA1 = pArcTo->a1-(BrFLOAT)((BrINT)(pArcTo->a1/360.0)*360);*/

							//poExport_ArcTo(pArcTo->x1 + m_sExtInfo.nPosX, pArcTo->y1 + m_sExtInfo.nPosY, pArcTo->x2 + m_sExtInfo.nPosX, pArcTo->y2 + m_sExtInfo.nPosY, BrDEGtoRAD(-90), BrDEGtoRAD(0));
							//poExport_ArcTo(pArcTo->x1 + m_sExtInfo.nPosX, pArcTo->y1 + m_sExtInfo.nPosY, pArcTo->x2 + m_sExtInfo.nPosX, pArcTo->y2 + m_sExtInfo.nPosY, BrDEGtoRAD(-fA0), BrDEGtoRAD(fA1));
							BrFRect fRect = {pArcTo->x1 + m_sExtInfo.nPosX, pArcTo->y1 + m_sExtInfo.nPosY, pArcTo->x2 + m_sExtInfo.nPosX, pArcTo->y2 + m_sExtInfo.nPosY};
							BrINT startAngle = pArcTo->a0;
							BrINT endAngle = pArcTo->a1;

							BrBOOL isClockwise = (pArcTo->direction == AD_CLOCKWISE ? BrTRUE : BrFALSE);

							if(nTailArrowObjIndex == i || nHeadArrowObjIndex == i) //�ش� i��°�� obj �� ȭ��ǥ�� �ִ� ���
							{
								BrDOUBLE dMove[2] = {0,}; // 0��° : tail, 1��°:head ����
								BrDOUBLE dTailradius[2] = {0,}; // 0��° : tail, 1��°:head ����
								BrFPOINT HeadArrow[2] = {0,};
								BrFPOINT TailArrow[2] = {0,};

								if(nTailArrowObjIndex == i)
									dMove[0] = m_pPen->getArrowInfo(m_pPen->getBaseLineWidth(), m_pPen->getLineWidth(), pTailArrow, m_pPen->getScaleFact(), BrNULL, BrNULL, &dTailradius[0], m_pPen->getLineStyle());
								if(nHeadArrowObjIndex == i)
									dMove[1] = m_pPen->getArrowInfo(m_pPen->getBaseLineWidth(), m_pPen->getLineWidth(), pHeadArrow, m_pPen->getScaleFact(), BrNULL, BrNULL, &dTailradius[1], m_pPen->getLineStyle());

								sToPos.x-=m_sExtInfo.nPosX;
								sToPos.y-=m_sExtInfo.nPosY;

								getExtArcInfo(pArcTo, dMove, dTailradius, HeadArrow, TailArrow, &sToPos); //���� �缳��

								if(nTailArrowObjIndex ==i)
								{
									startAngle = pArcTo->a0;
									sTailArrowPoint1.x = TailArrow[0].x+ m_sExtInfo.nPosX;
									sTailArrowPoint1.y = TailArrow[0].y+ m_sExtInfo.nPosY;
									sTailArrowPoint2.x = TailArrow[1].x+ m_sExtInfo.nPosX;
									sTailArrowPoint2.y = TailArrow[1].y+ m_sExtInfo.nPosY;
								}
								if(nHeadArrowObjIndex ==i)
								{
									endAngle = pArcTo->a1;
									sHeadArrowPoint1.x = HeadArrow[0].x+ m_sExtInfo.nPosX;
									sHeadArrowPoint1.y = HeadArrow[0].y+ m_sExtInfo.nPosY;
									sHeadArrowPoint2.x = HeadArrow[1].x+ m_sExtInfo.nPosX;
									sHeadArrowPoint2.y = HeadArrow[1].y+ m_sExtInfo.nPosY;
								}
								poExport_MoveTo(&sStartPos);

								poExport_ArcTo(&fRect, startAngle, endAngle, bFill, !bFill, isClockwise, nTailArrowObjIndex);
							}
							else
								poExport_ArcTo(&fRect, startAngle, endAngle, bFill, !bFill, isClockwise, -1);

#if 0
							sToPos.x = pArcTo->x1 + m_sExtInfo.nPosX;
							sToPos.y = pArcTo->y1 + m_sExtInfo.nPosY;
							poExport_LineTo(&sToPos);

							sToPos.x = pArcTo->x2 + m_sExtInfo.nPosX;
							sToPos.y = pArcTo->y2 + m_sExtInfo.nPosY;
							poExport_LineTo(&sToPos);
#endif //0
						}
						break;
					case ePolyBezierToObj:	
						{								
							LPBrPOLYGONOBJPATH pPolyBezier = (LPBrPOLYGONOBJPATH)pObjPath->aObjPtr.at(i);
							BrINT nCount = pPolyBezier->count/3;
							BrFPOINT pos1, pos2, pos3;
							BrPoint *pPolyPos = pPolyBezier->lpp;

							BrARROWCPOINTINFO sHArrowPointInfo = {0, 0};
							BrARROWCPOINTINFO sTArrowPointInfo = {0, 0};

							BrDPoint HeadPoint={0,0};
							BrDPoint TailPoint={0,0};
							// Tail �Ǵ� Head Arrow ��Ŀ� ���� MovePoint�� �����Ǿ�� �ϹǷ� sToPos�� ����Ѵ�.
							BrDPoint MovePoint = {sToPos.x - m_sExtInfo.nPosX, sToPos.y - m_sExtInfo.nPosY};
							BrFPOINT sAlterPos[2] = {0,0};

							if(nHeadArrowObjIndex==i || nTailArrowObjIndex==i)
							{
								if(nTailArrowObjIndex==i)
									sTArrowPointInfo.dMove = m_pPen->getArrowInfo(m_pPen->getBaseLineWidth(), m_pPen->getLineWidth(), pTailArrow, m_pPen->getScaleFact(), BrNULL, BrNULL, &sTArrowPointInfo.dTailRadius, m_pPen->getLineStyle());
								if(nHeadArrowObjIndex==i)		
									sHArrowPointInfo.dMove = m_pPen->getArrowInfo(m_pPen->getBaseLineWidth(), m_pPen->getLineWidth(), pHeadArrow, m_pPen->getScaleFact(), BrNULL, BrNULL, &sHArrowPointInfo.dTailRadius, m_pPen->getLineStyle());

								setExtCurvePathByOffset(pPolyBezier->lpp, pPolyBezier->count, (nHeadArrowObjIndex == i)? &sHArrowPointInfo : BrNULL, (nTailArrowObjIndex == i)? &sTArrowPointInfo : BrNULL, HeadPoint, TailPoint, &MovePoint, BrTRUE, sAlterPos);
							}

							for(BrINT j = 0; j < nCount; j++)
							{
								pos1.x = m_sExtInfo.nPosX + pPolyPos[0].x;
								pos1.y = m_sExtInfo.nPosY+ pPolyPos[0].y;

								pos2.x = m_sExtInfo.nPosX + pPolyPos[1].x;
								pos2.y = m_sExtInfo.nPosY+ pPolyPos[1].y;

								pos3.x = m_sExtInfo.nPosX + pPolyPos[2].x;
								pos3.y = m_sExtInfo.nPosY+ pPolyPos[2].y;

								if(j == 0 && nTailArrowObjIndex == i) //ù��° bezier && tailarrow ���
								{
									sTailArrowPoint1.x = pos1.x;
									sTailArrowPoint1.y = pos1.y;
									sTailArrowPoint2.x = sStartPos.x;
									sTailArrowPoint2.y = sStartPos.y;

									if(sAlterPos[0].x!=0 || sAlterPos[0].y!=0)
									{ //����Ͽ� ���� ������� ���� ù��° bezier�� Moveto�� �Űܾ� �� ��쿡�� �����Ѵ�.
										sTailArrowPoint1.x = TailPoint.x + m_sExtInfo.nPosX;
										sTailArrowPoint1.y = TailPoint.y + m_sExtInfo.nPosY;

										sToPos.x = sAlterPos[0].x + m_sExtInfo.nPosX;
										sToPos.y = sAlterPos[0].y + m_sExtInfo.nPosY;
									}
									poExport_MoveTo(&sToPos);
								}
								if(j+1 == nCount && nHeadArrowObjIndex == i) //������ bezier && headarrow ���
								{
									sHeadArrowPoint1.x = pos2.x;
									sHeadArrowPoint1.y = pos2.y;
									sHeadArrowPoint2.x = pos3.x;
									sHeadArrowPoint2.y = pos3.y;

									if((sAlterPos[1].x!=0 || sAlterPos[1].y!=0) && pHeadArrow->nArrowType != eLineArrowOpen)
									{ //����Ͽ� ���� ������� ���� ������ bezier�� ������ �Űܾ� �� ��쿡�� �����Ѵ�.
										sHeadArrowPoint1.x = HeadPoint.x + m_sExtInfo.nPosX;
										sHeadArrowPoint1.y = HeadPoint.y + m_sExtInfo.nPosY;

										pos2.x = sHeadArrowPoint1.x;
										pos2.y = sHeadArrowPoint1.y;

										pos3.x = sAlterPos[1].x + m_sExtInfo.nPosX;
										pos3.y = sAlterPos[1].y + m_sExtInfo.nPosY;
									}
								}
								poExport_BezierCurveTo(&pos1, &pos2, &pos3);
								pPolyPos += 3;
							}
						}
						break;
					case ePathCommandObj:				
						{
							LPBrOBJPATHCOMM pComm = (LPBrOBJPATHCOMM)pObjPath->aObjPtr.at(i);						
							if(pComm->nType == eStartPositionComm)
							{
							}
							else if(pComm->nType == eClosePathComm)
							{
								poExport_ClosePath();

								if(nTailArrowObjIndex == i)
								{	
									sTailArrowPoint1.x = sToPos.x;	sTailArrowPoint1.y = sToPos.y; 
									sTailArrowPoint2.x = sStartPos.x;	sTailArrowPoint2.y = sStartPos.y;	
								}
								if(nHeadArrowObjIndex == i)
								{
									sHeadArrowPoint1.x = sStartPos.x;	sHeadArrowPoint1.y = sStartPos.y; 
									sHeadArrowPoint2.x = sToPos.x;	sHeadArrowPoint2.y = sToPos.y;
								}
							}
							else //pComm->nType == eExtraComm
							{
								if(pComm->nValue == eObjPathFillandStroke)
									bIsAvailFillandStroke = BrTRUE;
							}
							bSetStartPos = BrFALSE;
						}
						break;
					}
				}

				if(bIsAvailFillandStroke == BrTRUE && bFill == BrTRUE && m_nPenStyle != eNullPen)
					poExport_EndPathEx(BrTRUE, BrTRUE);
				else
					poExport_EndPathEx(!bFill, bFill);

				if(m_bIsTwipPenWidth)
				{
					poExport_SetPenWidthTwip(bIsOldTwipPenWidth);
					m_bIsTwipPenWidth = BrFALSE;
				}


				if(isArrow)
				{
					if(nTailArrowObjIndex != -1)
					{
						setArrowPoint(m_pPen, pTailArrow, TailArrowpos, sTailArrowPoint1, sTailArrowPoint2); //ȭ��ǥ�� ��ǥ�� ������ ���� rotate
						addArrowPathByType(pTailArrow, TailArrowpos[0], TailArrowpos[1], TailArrowpos[2], TailArrowpos[3]); //export
					}
					if(nHeadArrowObjIndex != -1)
					{
						setArrowPoint(m_pPen, pHeadArrow, HeadArrowpos, sHeadArrowPoint1, sHeadArrowPoint2);
						addArrowPathByType(pHeadArrow, HeadArrowpos[0], HeadArrowpos[1], HeadArrowpos[2], HeadArrowpos[3]);
					}
				}
				enableFillTemplateRender(BrFALSE);
				bIsOldTwipPenWidth = poExport_SetPenWidthTwip(bIsOldTwipPenWidth); // �ߺ��ڵ��� �� ����. ���ǿ� ���� �߰��۾� �ʿ�.
				return BrTRUE;
			}						
		}
		return BrTRUE;
	}
	else
	{
		return BrDC::drawPath(bFill);
	}
}

void BrExportPDFDC::setFigureClipBox(LPBrRect pFigure, LPBrRect pFill/* = BrNULL*/, LPBrRect pFrame/* = BrNULL*/)
{
	LPBrRect pTarget = (pFill==BrNULL) ? pFigure : pFill;

	if(pTarget)
	{
		BrRect rect={0,0};
		

		{
			rect.left = pTarget->left+m_sExtInfo.nPosX;
			rect.top = pTarget->top+m_sExtInfo.nPosY;
			rect.right = pTarget->right+m_sExtInfo.nPosX;
			rect.bottom = pTarget->bottom+m_sExtInfo.nPosY;
		}
		poExport_setFigureBox(&rect);
		BrDC::setFigureClipBox(pFigure, pFill, pFrame);
	}
}

void BrExportPDFDC::addArrowPathByType(LPBrLOGARROW pArrowLog, BrFPOINT sPos1, BrFPOINT sPos2, BrFPOINT sPos3, BrFPOINT sPos4)
{
	BrINT nPenWidth = m_pPen->getPenWidth();
	BrBOOL bFill = BrFALSE;
	BrBOOL bStroke = BrFALSE;

	poExport_SetPenAtt(m_pPen->getPenWidth(), m_pPen->getPenColor(), eSolidPen, eSquareLineCap, eMiterLineJoin);
	poExport_SetBrushColor(m_pPen->getPenColor());
	poExport_BeginPath();

	switch(pArrowLog->nArrowType)
	{
	case eLineArrowOpen:
		{
			poExport_SetPenAtt(m_pPen->getPenWidth(), m_pPen->getPenColor(), eSolidPen, eRoundLineCap, eMiterLineJoin);
			poExport_MoveTo(&sPos1);
			poExport_LineTo(&sPos2);
			poExport_LineTo(&sPos3);
			bStroke = BrTRUE;
			break;
		}
	case eLineArrowCommon:
		{
			poExport_MoveTo(&sPos1);
			poExport_LineTo(&sPos2);
			poExport_LineTo(&sPos3);
			poExport_ClosePath();
			bFill = BrTRUE;
			break;
		}
	case eLineArrowStealth:
		{
			poExport_MoveTo(&sPos1);
			poExport_LineTo(&sPos2);
			poExport_LineTo(&sPos3);
			poExport_LineTo(&sPos4);
			poExport_ClosePath();
			bFill = BrTRUE;
			break;
		}
	case eLineArrowDiamond:
		{
			poExport_MoveTo(&sPos1);
			poExport_LineTo(&sPos2);
			poExport_LineTo(&sPos3);
			poExport_LineTo(&sPos4);
			poExport_ClosePath();
			bFill = BrTRUE;
			break;
		}
	case eLineArrowOval: //ellipse
		{
			poExport_Ellipse(sPos1.x, sPos1.y, sPos2.x, sPos2.y,1,1);
			bFill = BrTRUE;
			break;
		}
	default:
		break;
	}
	poExport_EndPathEx(bStroke, bFill);
}
