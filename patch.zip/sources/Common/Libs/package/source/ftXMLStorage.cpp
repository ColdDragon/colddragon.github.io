#include <OfficePreComp.hpp>

#include "ftXMLStorage.h"
#include "zip/po_unzip.h"
#include "ThreadDefines_i.h"
#include "binterfacehandle.h"
#include <regex>
#include <string>

ftXMLStorage::ftXMLStorage()
{
	memset(&m_oZipInfo, 0, BrSizeOf(BORA_ZIP_INFO));
#ifdef SUPPORT_MULTICORE
	m_pBlockZip= BrNULL;
	m_pOrgPackageMem = BrNULL;
	m_nOrgPackageMemSize = 0;
#endif //SUPPORT_MULTICORE
	m_bFileOpen = BrFALSE;
	m_bDRMOpen = BrFALSE;
}

ftXMLStorage::~ftXMLStorage()
{
	for(BrINT32 i = 0; i < m_oZipInfo.itemCount; i++)
		BR_SAFE_FREE(m_oZipInfo.zes[i]);

	BR_SAFE_FREE(m_oZipInfo.zes);

	if( m_oZipInfo.hZipFile )
		BrZipClose(m_oZipInfo.hZipFile);

#ifdef SUPPORT_MULTICORE
	if(m_pBlockZip)
		BrZipClose(m_pBlockZip);
#endif //SUPPORT_MULTICORE
	m_bFileOpen = BrFALSE;
}


HZIP ftXMLStorage::OpenZip(BrLPBYTE a_pMem, BrINT32 a_nMemSize, BrBOOL a_bDRMOpen, BrBOOL a_bMCoreZip)
{
#ifdef USE_UNZIP
	if(!a_pMem)
	{
		BrAutoChar temp = CUtil::convertBStringToChar(&m_strFilePath, CP_UTF8);
		return BrZipFileOpen((BrCHAR *)temp.get(), "", a_bMCoreZip, a_bDRMOpen);
	}
	else
		return BrZipMemoryOpen(a_pMem, a_nMemSize, BrNULL);
#else //USE_UNZIP
	return BrNULL;
#endif //USE_UNZIP
}


//[2011.10.12][�̻�][TID:725] 2007 image load ���� ���ϴ� ����.
BrBOOL ftXMLStorage::OpenZipFile()
{
	if(m_oZipInfo.hZipFile == BrNULL)
	{
		if(!m_strFilePath.isEmpty())
		{
#ifdef SUPPORT_MULTICORE
			m_pOrgPackageMem = BrNULL;
			m_nOrgPackageMemSize = 0;
#endif //SUPPORT_MULTICORE
			BrAutoChar temp = CUtil::convertBStringToChar(&m_strFilePath, CP_UTF8);
			m_oZipInfo.hZipFile = BrZipFileOpen((BrCHAR *)temp.get(), "");
		}
		unzGetGlobalOffset(m_oZipInfo.hZipFile);
	}
	return (m_oZipInfo.hZipFile != BrNULL);
}

BrINT32 ftXMLStorage::CloseZipFile()
{
	BrINT32 nResult = 0;
	if (m_oZipInfo.hZipFile)
	{
		nResult = BrZipClose(m_oZipInfo.hZipFile);
		m_oZipInfo.hZipFile = BrNULL;
	}
#ifdef SUPPORT_MULTICORE
	if(m_pBlockZip)
	{
		BrZipClose(m_pBlockZip);
		m_pBlockZip = BrNULL;
	}
	m_pOrgPackageMem = BrNULL;
	m_nOrgPackageMemSize = 0;
#endif //SUPPORT_MULTICORE
	return nResult;
}

BrBOOL ftXMLStorage::GetZipInfo(BrLPBYTE a_pMem, BrINT32 a_nMemSize)
{
	m_oZipInfo.hZipFile = OpenZip(a_pMem, a_nMemSize, m_bDRMOpen);
	if(!m_oZipInfo.hZipFile)
		return BrFALSE;

	if (a_nMemSize == 0)
		m_bFileOpen = BrZipHasHandle(m_oZipInfo.hZipFile);
	
	m_oZipInfo.itemCount = BrZipGetCount(m_oZipInfo.hZipFile);
	m_oZipInfo.zes = (ZIPENTRY**)BrMalloc(BrSizeOf(ZIPENTRY*)*m_oZipInfo.itemCount);
	memset(m_oZipInfo.zes, 0, BrSizeOf(ZIPENTRY*)*m_oZipInfo.itemCount);

	unzGetGlobalOffset(m_oZipInfo.hZipFile);

	PO_THREAD_TRY_BLOCK {
		for(BrINT32 i = 0; i < m_oZipInfo.itemCount; i++)
		{
			m_oZipInfo.zes[i] = (ZIPENTRY*)BrMalloc(BrSizeOf(ZIPENTRY));
			if(unzGetZipItem((HZIP)m_oZipInfo.hZipFile, i, m_oZipInfo.zes[i]) != ZR_OK)
			{
				BrFree(m_oZipInfo.zes[i]);
				m_oZipInfo.zes[i] = BrNULL;
				return BrFALSE;
			}
			CANCEL_LOAD_RETURN_BOOL_EX;
		}
	} PO_THREAD_CATCH_BLOCK { 

		BrZipClose(m_oZipInfo.hZipFile);
		m_oZipInfo.hZipFile = BrNULL;
	} PO_THREAD_END
#ifdef SUPPORT_MULTICORE
	m_pOrgPackageMem = a_pMem;
	m_nOrgPackageMemSize = a_nMemSize;
#endif //SUPPORT_MULTICORE

	return BrTRUE;
}

BrBOOL ftXMLStorage::IsExistPart(const BrCHAR* a_pPartName)
{
	if(!a_pPartName)
		return BrFALSE;

	for(BrINT32 nIndex = 0; nIndex < m_oZipInfo.itemCount; nIndex++)
	{
		if(!strcmp(a_pPartName, m_oZipInfo.zes[nIndex]->name))
			return BrTRUE;
	}
	return BrFALSE;
}

BrBOOL ftXMLStorage::IsExistPartWithRegex(const BrCHAR* regexString)
{
	if(!regexString)
		return BrFALSE;

	for(BrINT32 nIndex = 0; nIndex < m_oZipInfo.itemCount; nIndex++)
	{
		const std::string regex_string = std::string(regexString);
		const std::regex regex(regex_string);
		const std::string element_name = std::string(m_oZipInfo.zes[nIndex]->name);
		if(std::regex_match(element_name, regex))
			return BrTRUE;
	}
	return BrFALSE;
}

BrBOOL ftXMLStorage::IsExistNotZeroFile(const BrCHAR* a_pFilePath)
{
	if(!a_pFilePath)
		return BrFALSE;

	for(BrINT32 nIndex = 0; nIndex < m_oZipInfo.itemCount; nIndex++)
	{
		if(!strcmp(a_pFilePath, m_oZipInfo.zes[nIndex]->name) && m_oZipInfo.zes[nIndex]->unc_size > 0)
			return BrTRUE;
	}
	return BrFALSE;
}

BrUINT32 ftXMLStorage::GetIndex(const BrCHAR* a_pPartName)
{
	for(BrINT32 nIndex = 0; nIndex < m_oZipInfo.itemCount; nIndex++)
	{
#ifdef _WIN32
		if (_stricmp(a_pPartName, m_oZipInfo.zes[nIndex]->name) == 0)
#else
		if (strcasecmp(a_pPartName, m_oZipInfo.zes[nIndex]->name) == 0)
#endif
			return nIndex;
	}

	return 0xffffffff;
}

BrUINT32 ftXMLStorage::GetZipItemStream(const BrCHAR* a_pPartName, BrLPBYTE& a_pBuf)
{
	BrUINT32 nZipItemIdx = GetIndex(a_pPartName);
	if(nZipItemIdx == 0xffffffff)
		return 0;

	BrUINT32 nSize = BrZipGetItemSize(m_oZipInfo.hZipFile, nZipItemIdx);

	if(a_pBuf)
	{
		BRTHREAD_ASSERT(0);
		return 0;
	}
	a_pBuf = (BrLPBYTE)BrMalloc(nSize+1);
	if (a_pBuf == BrNULL)
	{
		g_BoraThreadAtom.m_nRetOpen = kPoErrMemory;
		SET_ERROR((PoError)kPoErrMemory, "");
		BRTHREAD_ASSERT(0);
		return 0;
	}
	memset(a_pBuf, 0, nSize+1);

	BrBOOL bRet = BrZipExtractMemory(g_szSrcZipPassword, m_oZipInfo.hZipFile, nZipItemIdx, a_pBuf);
	if(bRet == BrFALSE)
	{
		BRTHREAD_ASSERT(0);
		BR_SAFE_FREE(a_pBuf);
		return 0;
	}

	return nSize;
}