#include <OfficePreComp.hpp>

#ifdef SUPPORT_XML_PARSER
#define	XMLIMPORT		// for remove waring LNK4217 

#include "bmvstream.h"
#include "ImageFilter.h"
#include "packageBase.h"
#include "package_ct_manager.h"
#include "SAX/Expat/xmldecoder.h"
#include "SAX/Expat/XmlZipLoader.h"
#include "package_uri.h"
#include "ThreadDefines_i.h"
#include "brxmlpackage.h"
#include "ThreadDefines_i.h"
#include "binterfacehandle.h"
#include "brmcoreimpdef.h"
#include "brmcoreproc.h"
#include "bwpObjApi.h"
#include "FtXMLImageLoader.h"
#include "DOM/cmXMLDomMgr.h"
#ifdef IMPORT_OPEN_DOCUMENT
#include "package/OdManifest.h"
#endif //IMPORT_OPEN_DOCUMENT
#include "ptx_package_part_collection.h"
#include "../Bwp/Filter/slide/pptx/PPT/Presentation/EmbeddedFontLst/ptxEmbeddedFont.h"
#include "painter.h"
#include "brdc2.h"
#include "../../sources/Bwp/Filter/word/Docx/Font/DocxFont.h"
#include "expat.h"

//Embedded OpenType (EOT) File Format (https://www.w3.org/Submission/2008/SUBM-EOT-20080305/)
//4 Implementation Information
//4.1 Font Embedding Levels 
#define PREVIEW_PRINTEMBEDDING 0x0004 


BoraPackageBase::BoraPackageBase() 
{
	m_partList = BrNULL;
	m_relationships = BrNULL;
	m_contentTypeManager = BrNULL;
	m_pURIHelper = BrNULL;
	m_pImageLoader = BrNULL;
#ifdef SUPPORT_2007_OLE
	m_pOLELoader = BrNULL; 
#endif 

	m_pftXMLStorage = BrNEW ftXMLStorage();
#ifdef POLARIS_BASIC_DEVELOPMENT 
	m_pSheetFormControlRelArray = BrNULL;
#endif //POLARIS_BASIC_DEVELOPMENT 

	m_pThemeManagerRelArray = BrNULL;
	m_pMasterRelArray = BrNULL;
	m_pLayoutRelArray = BrNULL;

	m_pWritePackage = BrNULL;
}


BoraPackageBase::~BoraPackageBase()
{
	deleteAllData();
}


void BoraPackageBase::deleteAllData()
{
	BR_SAFE_DELETE(m_partList);
	BR_SAFE_DELETE(m_relationships);
	BR_SAFE_DELETE(m_contentTypeManager);
	BR_SAFE_DELETE(m_pURIHelper);

	BR_SAFE_DELETE(m_pImageLoader);
#ifdef SUPPORT_2007_OLE
	BR_SAFE_DELETE(m_pOLELoader);
#endif

	BR_SAFE_DELETE(m_pThemeManagerRelArray);
#ifdef POLARIS_BASIC_DEVELOPMENT 
	BR_SAFE_DELETE(m_pSheetFormControlRelArray);
#endif //POLARIS_BASIC_DEVELOPMENT 

	BR_SAFE_DELETE(m_pMasterRelArray);
	BR_SAFE_DELETE(m_pLayoutRelArray);
	BR_SAFE_DELETE(m_pftXMLStorage);
}


void BoraPackageBase::deleteAllDataEx()
{
	BR_SAFE_DELETE(m_partList);
	BR_SAFE_DELETE(m_relationships);
	BR_SAFE_DELETE(m_contentTypeManager);
	BR_SAFE_DELETE(m_pURIHelper);
//
	BR_SAFE_DELETE(m_pThemeManagerRelArray);
#ifdef POLARIS_BASIC_DEVELOPMENT 
	BR_SAFE_DELETE(m_pSheetFormControlRelArray);
#endif //POLARIS_BASIC_DEVELOPMENT 

	BR_SAFE_DELETE(m_pMasterRelArray);
	BR_SAFE_DELETE(m_pLayoutRelArray);
	BR_SAFE_DELETE(m_pftXMLStorage);
}


BrBOOL BoraPackageBase::InitPackage(const BrCHAR* pSrcPath , BrBOOL a_isPPTX)
{
	m_pftXMLStorage->SetFilePath(pSrcPath);
	if (!m_pftXMLStorage->GetZipInfo())
	{
		SET_INFO_LOG("getZipInfo return False");
		return BrFALSE;
	}

	m_pURIHelper = BrNEW PackagingURIHelper();

	if(a_isPPTX)
	{
#ifdef IMPROVE_EXPORT_PERFORMANCE_PPTX
		m_partList = BrNEW PtxPackagePartCollection(BrZipGetCount(m_pftXMLStorage->m_oZipInfo.hZipFile));
#else
		m_partList = BrNEW PackagePartCollection();
#endif
	}
	else{
		m_partList = BrNEW PackagePartCollection();
	}

	CallbackParam	param;
	//[2011.09.26][�����][TID:239] callbackparam �ʱ�ȭ
	memset(&param, 0, BrSizeOf(CallbackParam));
	m_contentTypeManager = BrNEW BoraContentTypeManager();
	param.pCurrentInstance = m_contentTypeManager;

	AddPackagePart(CONTENT_TYPES_PART_NAME);

	if (!ReadPackageByPartname(CONTENT_TYPES_PART_NAME, &param))
	{
		SET_INFO_LOG("READ FAIL : Content_Types.xml");
		return BrFALSE;
	}

	BString strRel = BString(RELATIONSHIP_PART_SEGMENT_NAME) + FORWARD_SLASH_STRING + RELATIONSHIP_PART_EXTENSION_NAME;
	AddPackagePart(strRel);

	m_relationships = BrNEW PackageRelationshipCollection(this);
	param.pCurrentInstance = m_relationships;
	if (!ReadPackageByPartname((BrCHAR*)strRel.data(), &param))
	{
		SET_INFO_LOG("READ FAIL : _rels.rels");
		return BrFALSE;
	}

	return BrTRUE;
}


BrBOOL BoraPackageBase::InitEmbedPackageByMem(BrLPBYTE pMem, BrINT32 nMemSize)
{
	//[2013.06.25][TID : 15624][���ؼ�] Embed�� ��Ʈ ���� ���� �� ���� ����
	if(!m_pftXMLStorage)
		m_pftXMLStorage = BrNEW ftXMLStorage();

	if(!m_pftXMLStorage->GetZipInfo(pMem, nMemSize))
		return BrFALSE;

	m_partList = BrNEW PackagePartCollection();

	CallbackParam	param;
	//[2011.09.26][�����][TID:239] callbackparam �ʱ�ȭ
	memset(&param, 0, BrSizeOf(CallbackParam));

	m_contentTypeManager = BrNEW BoraContentTypeManager();
	param.pCurrentInstance = m_contentTypeManager;

	AddPackagePart(CONTENT_TYPES_PART_NAME);

	if( !ReadPackageByPartname(CONTENT_TYPES_PART_NAME, &param) )
		return BrFALSE;

	BString strRel = BString(RELATIONSHIP_PART_SEGMENT_NAME) + FORWARD_SLASH_STRING + RELATIONSHIP_PART_EXTENSION_NAME;
	AddPackagePart(strRel);

	m_relationships = BrNEW PackageRelationshipCollection(this);
	param.pCurrentInstance = m_relationships;
	if( !ReadPackageByPartname((BrCHAR*)strRel.data(), &param) )
		return BrFALSE;

	return BrTRUE;
}

BrUINT32 BoraPackageBase::GetThemeFilePartCount(BString a_strMainRelType, BString a_strSubRelType, BString a_strRelType)
{
	BrUINT32 nSize = 0;
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(a_strMainRelType);
	if( pRel )
	{
		BoraPackagePart* pPart = getMatchingPart(pRel);
		PackageRelationshipCollection*	pMainDocRelationships = pPart->m_relationships;
		BArray<PackageRelationship*>* pRelArray = pMainDocRelationships->iterator(a_strSubRelType);

		nSize = pRelArray->size();

		BR_SAFE_DELETE(pRelArray);
	}

	return nSize;
}

BrBOOL	BoraPackageBase::ReadThemeFileThemePart_PPTX(LPCallbackParam a_pCallbackParam) //theme.xml
{
	BrBOOL bRet = BrFALSE;

	//Theme rels/.rels CORE_DOCUMENT_PART_TYPE�� �ش��ϴ� ���� ã�� -> //theme/theme/themeManager.xml
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);
	if( pRel )
	{
		//theme/theme/themeManager.xml
		BTrace("%s[%d] getRelationshipType() = %s ", __FUNCTION__, __LINE__, pRel->toString().data());
		BoraPackagePart* pThemeManagerPart = getMatchingPart(pRel);

		//theme/theme/_rels_themeManager.xml.rels ���� CORE_DOCUMENT_PART_TYPE Relsationship ã��
		PackageRelationshipCollection*	pThemeManagerRelationships = pThemeManagerPart->m_relationships;

		//THEME_PART_TYPE
		BArray<PackageRelationship*>* pThemeRelArray = pThemeManagerRelationships->iterator(THEME_PART_TYPE);

		if (pThemeRelArray->size() > 0)
		{
			pRel = pThemeRelArray->at(0);

			BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
			BrBOOL bExistPart = (m_partList->get(pPartName)!=BrNULL);
			if( !bExistPart )
				getPart(pPartName);//�̷��� �ϸ� �ش� slide �� relation ���� �鵵 ���� ������.

			bRet = ReadPartName(a_pCallbackParam, pRel);	
			//bRet = ReadPackageByPartname(pPartName->getName().data(), pCallbackParam);


			if( bExistPart )
				BrDELETE pPartName;
		}
		BR_SAFE_DELETE(pThemeRelArray);
	}
	return BrTRUE;
}

BrBOOL	BoraPackageBase::ReadThemeFileThemePart_PPTX(cmXMLDomMgr* a_pDOMmgr)
{
	BrBOOL bRet = BrFALSE;

	//Theme rels/.rels CORE_DOCUMENT_PART_TYPE�� �ش��ϴ� ���� ã�� -> //theme/theme/themeManager.xml
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);
	if( pRel )
	{
		//theme/theme/themeManager.xml
		BTrace("%s[%d] getRelationshipType() = %s ", __FUNCTION__, __LINE__, pRel->toString().data());
		BoraPackagePart* pThemeManagerPart = getMatchingPart(pRel);

		//theme/theme/_rels_themeManager.xml.rels ���� CORE_DOCUMENT_PART_TYPE Relsationship ã��
		PackageRelationshipCollection*	pThemeManagerRelationships = pThemeManagerPart->m_relationships;

		//THEME_PART_TYPE
		BArray<PackageRelationship*>* pThemeRelArray = pThemeManagerRelationships->iterator(THEME_PART_TYPE);

		if (pThemeRelArray->size() > 0)
		{
			pRel = pThemeRelArray->at(0);

			BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
			BrBOOL bExistPart = (m_partList->get(pPartName)!=BrNULL);
			if( !bExistPart )
				getPart(pPartName);//�̷��� �ϸ� �ش� slide �� relation ���� �鵵 ���� ������.

			MakeDomTree(a_pDOMmgr, pRel);
			//bRet = ReadPackageByPartname(pPartName->getName().data(), pCallbackParam);

			if( bExistPart )
				BrDELETE pPartName;
		}
		BR_SAFE_DELETE(pThemeRelArray);
	}
	return BrTRUE;
}

BrBOOL	BoraPackageBase::ReadThemeFileMasterRelPart_PPTX()
{
	BrBOOL bRet = BrFALSE;
	//Theme rels/.rels CORE_DOCUMENT_PART_TYPE�� �ش��ϴ� ���� ã�� -> //theme/theme/themeManager.xml
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);
	if( pRel )
	{
		//theme/theme/themeManager.xml
		BTrace("%s[%d] getRelationshipType() = %s ", __FUNCTION__, __LINE__, pRel->toString().data());
		BoraPackagePart* pThemeManagerPart = getMatchingPart(pRel);

		//theme/theme/_rels_themeManager.xml.rels ���� CORE_DOCUMENT_PART_TYPE Relsationship ã��
		PackageRelationshipCollection*	pThemeManagerRelationships = pThemeManagerPart->m_relationships;
		m_pThemeManagerRelArray =  pThemeManagerRelationships->iterator(CORE_DOCUMENT_PART_TYPE);

		if (m_pThemeManagerRelArray->size() > 0) 
		{
			//theme/presentation.xml 
			PackageRelationship* pPresentationRel =  m_pThemeManagerRelArray->at(0);
			if (pPresentationRel) 
			{
				BTrace("%s[%d] getRelationshipType() = %s ", __FUNCTION__, __LINE__, pPresentationRel->toString().data());
				BoraPackagePart* pPresentationPart = GetPackagePart(pPresentationRel->m_targetUri->getPath());
				if(pPresentationPart)
				{
					PackageRelationshipCollection*	pPresentationRelationships = pPresentationPart->m_relationships;
					m_pMasterRelArray = pPresentationRelationships->iterator(SLIDE_MASTER_PART_TYPE);
					if (m_pMasterRelArray && m_pMasterRelArray->size() > 0) 
					{
						if (m_pMasterRelArray && m_pMasterRelArray->size() > 0)
							bRet = BrTRUE;
					}
				}
			}
		}
	}
	return bRet;
}

BrINT BoraPackageBase::GetThemeFileMasterPartCount_PPTX()
{
	if (m_pMasterRelArray && m_pMasterRelArray->size() > 0)
		return m_pMasterRelArray->size();

	return 0;
}

BrINT BoraPackageBase::GetThemeFileLayoutPartCount_PPTX(BrINT nMasterIndex)
{
	if (m_pMasterRelArray && m_pMasterRelArray->size() > 0) 
	{
		PackageRelationship* pLayoutRel =  m_pMasterRelArray->at(nMasterIndex);
		if (pLayoutRel) 
		{
			BTrace("%s[%d] getRelationshipType() = %s ", __FUNCTION__, __LINE__, pLayoutRel->toString().data());
			BoraPackagePart* pLayoutPart = GetPackagePart(pLayoutRel->m_targetUri->getPath());
			if(pLayoutPart)
			{
				PackageRelationshipCollection*	pLayoutRelationships = pLayoutPart->m_relationships;
				if(pLayoutRelationships)
				{
					m_pLayoutRelArray = pLayoutRelationships->iterator(SLIDE_LAYOUT_PART_TYPE);
					if (m_pLayoutRelArray) 
						return m_pLayoutRelArray->size();
				}				
			}			
		}
	}

	return -1;
}

BrCHAR*	BoraPackageBase::ReadThemeFileLayoutPagePart_PPTX(LPCallbackParam a_pCallbackParam, BrINT nLayoutIndex)
{
	BrBOOL bRet = BrFALSE;
	BrCHAR *pRID = BrNULL;
	if (0 < m_pLayoutRelArray->size() && nLayoutIndex < m_pLayoutRelArray->size()) 
	{
		BTrace("%s[%d] pLayoutRelArray size = %d ", __FUNCTION__, __LINE__, m_pLayoutRelArray->size());
		PackageRelationship* pRelLayout = m_pLayoutRelArray->at(nLayoutIndex);
		//memcpy(a_pLayout, pRelLayout->m_targetUri->getPath().data(), pRelLayout->m_targetUri->getPath().length());
		AddPackagePart(pRelLayout->m_targetUri->getPath());

		bRet = ReadPackageByPartname(pRelLayout->m_targetUri->getPath().data(), a_pCallbackParam);
		pRID = (BrCHAR*)pRelLayout->getId().data();
	}
	if (bRet) {
		return pRID;
	}
	return BrNULL;
}

BrBOOL BoraPackageBase::ReadThemeFileMasterPagePart_PPTX(LPCallbackParam a_pCallbackParam) // Master Page Read
{
	BrBOOL bRet = BrFALSE;
	BTrace("%s[%d] m_pMasterRelArray size = %d ", __FUNCTION__, __LINE__, m_pMasterRelArray->size());
	PackageRelationship* pRelLayout = m_pMasterRelArray->at(0);
	//memcpy(a_pLayout, pRelLayout->m_targetUri->getPath().data(), pRelLayout->m_targetUri->getPath().length());
	AddPackagePart(pRelLayout->m_targetUri->getPath());

	bRet = ReadPackageByPartname(pRelLayout->m_targetUri->getPath().data(), a_pCallbackParam);

	return bRet;
}

BrBOOL	BoraPackageBase::ReadThemeFileMain(LPCallbackParam a_pCallbackParam, BString a_strMainRelType, BrBOOL a_bNeedSuspend)
{
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(a_strMainRelType);
	if(pRel)
		return ReadPackageByPartname(pRel->m_targetUri->getPath().data(), a_pCallbackParam, a_bNeedSuspend);

	return BrFALSE;
}
BrBOOL	BoraPackageBase::ReadThemeFilePresentaionPart_PPTX(LPCallbackParam a_pCallbackParam, BString a_strMainRelType)
{
	PackageRelationship* pRel = m_pThemeManagerRelArray->at(0);
	if(pRel)
		return ReadPackageByPartname(pRel->m_targetUri->getPath().data(), a_pCallbackParam, BrFALSE);

	return BrFALSE;
}

BrCHAR*	BoraPackageBase::FindThemeFileMasterID_PPTX(BrCHAR* nSlideRelID)
{
	//theme/presentation.xml 
	PackageRelationship* pPresentationRel =  m_pThemeManagerRelArray->at(0);
	if (pPresentationRel) 
	{
		BTrace("%s[%d] getRelationshipType() = %s ", __FUNCTION__, __LINE__, pPresentationRel->toString().data());
		BoraPackagePart* pPresentationPart = GetPackagePart(pPresentationRel->m_targetUri->getPath());
		if(pPresentationPart)
		{
			PackageRelationshipCollection*	pPresentationRelationships = pPresentationPart->m_relationships;
			if(pPresentationRelationships)
			{
				m_pMasterRelArray = pPresentationRelationships->iterator(SLIDE_MASTER_PART_TYPE);
				if (m_pMasterRelArray && m_pMasterRelArray->size() > 0)
					return (BrCHAR*)m_pMasterRelArray->at(0)->getId().data();
			}			
		}		
	}
	return BrNULL;
}

BrBOOL BoraPackageBase::ReadMain(LPCallbackParam a_pCallbackParam, BString a_strMainRelType, BrBOOL a_bNeedSuspend/* =BrFALSE */)
{
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(a_strMainRelType);
	if(pRel)
		return ReadPackageByPartname(pRel->m_targetUri->getPath().data(), a_pCallbackParam, a_bNeedSuspend);

	return BrFALSE;
}

BrBOOL BoraPackageBase::ReadPart(LPCallbackParam a_pCallbackParam, BString a_strMainRelType, BString a_strRelType, BrCHAR* a_pID)
{
	BrBOOL bRet = BrFALSE;

	//.rels ���� a_strMainRelType �ش��ϴ� relationship ã��
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(a_strMainRelType);
	if( pRel )
	{
		BoraPackagePart* pPart = getMatchingPart(pRel);
		PackageRelationshipCollection*	pMainDocRelationships = pPart->m_relationships;
		BArray<PackageRelationship*>* pRelArray = pMainDocRelationships->iterator(a_strRelType);

		if(pRelArray->size() > 0)
		{
			if(a_pID)
			{
				//a_pID �� �ش��ϴ� a_strRelType�� ã�� ����
				for(BrUINT32 nIndex = 0; nIndex < pRelArray->size(); nIndex++)
				{
					pRel = pRelArray->at(nIndex);
					if(!strcmp(pRel->m_id.data(), a_pID))
					{
						bRet = ReadPartName(a_pCallbackParam, pRel);
						break;
					}
				}
			}
			else
			{
				pRel = pRelArray->at(0);
				bRet = ReadPartName(a_pCallbackParam, pRel);
			}
		}

		BR_SAFE_DELETE(pRelArray);
	}

	return bRet;
}


BrBOOL	BoraPackageBase::ReadPartForFastRead(LPCallbackParam a_pCallbackParam, BString a_strMainRelType, BrCHAR* a_pID)
{
	BrBOOL bRet = BrFALSE;

	//.rels ���� a_strMainRelType �ش��ϴ� relationship ã��
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(a_strMainRelType);
	if( pRel )
	{
		BoraPackagePart* pPart = getMatchingPart(pRel);
		PackageRelationshipCollection*	pMainDocRelationships = pPart->m_relationships;
		BArray<PackageRelationship*>* pRelArray = pMainDocRelationships->GetBinaryOrderedRelationArray();
		BString strCmpString(a_pID);
		//Search Rid => File
		int nRet = BinarySearch( *pRelArray, strCmpString );

		if ( nRet >= 0 )
		{
			PackageRelationship* pRelation = pRelArray->at( nRet );
			bRet = ReadPackageByPartname(pRelation->m_targetUri->getPath().data(), a_pCallbackParam);
		}

	}

	return bRet;
}

BrBOOL BoraPackageBase::ReadSlideLayoutPart(LPCallbackParam a_pCallbackParam, PackageRelationshipCollection* a_pRelationships, BString a_strRelType, BrCHAR* a_pID)
{
	BrBOOL bRet = BrFALSE;
	PackageRelationship* pRel;
	BArray<PackageRelationship*>* pRelArray = a_pRelationships->iterator(a_strRelType);

	if(pRelArray->size() > 0)
	{
		if(a_pID)
		{
			for(BrUINT32 nIndex = 0; nIndex < pRelArray->size(); nIndex++)
			{
				pRel = pRelArray->at(nIndex);
				if(!strcmp(pRel->m_id.data(), a_pID))
				{
					bRet = ReadPartName(a_pCallbackParam, pRel);
					break;
				}
			}
		}
		else
		{
			pRel = pRelArray->at(0);
			bRet = ReadPartName(a_pCallbackParam, pRel);
		}
	}

	BR_SAFE_DELETE(pRelArray);

	return bRet;
}

BrBOOL BoraPackageBase::ReadPart(LPCallbackParam a_pCallbackParam, BrCHAR* a_strSrcPart)
{
	return ReadPackageByPartname(a_strSrcPart, a_pCallbackParam);
}

BString BoraPackageBase::GetReadThemePath(BString a_strPartType, BrUINT32 a_nMasterRelID)
{
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);
	BoraPackagePart* pRelativePackagePart = BrNULL;

	if( pRel )
	{
		BoraPackagePart* pPart = getMatchingPart(pRel);
		PackageRelationshipCollection*	pMainDocRelationships = pPart->m_relationships;
		BArray<PackageRelationship*>* pRelArray = pMainDocRelationships->iterator(a_strPartType);

		for(BrINT32 nIdx=0; nIdx<pRelArray->size(); nIdx++)
		{
			pRel = pRelArray->at(nIdx);
			if(a_nMasterRelID != -1)
			{
				if(BrAtoi(pRel->m_id.data()) == a_nMasterRelID)
					pRelativePackagePart = GetPackagePart(pRel->m_targetUri->getPath());
			}
			else
			{
				pRelativePackagePart = GetPackagePart(pRel->m_targetUri->getPath());
				break;
			}
		}

		BR_SAFE_DELETE(pRelArray);
	}

	if(pRelativePackagePart)
	{
		PackageRelationshipCollection*	pRelationships = pRelativePackagePart->m_relationships;
		BArray<PackageRelationship*>* pRelArray = pRelationships->iterator(THEME_PART_TYPE);

		if(pRelArray->size() > 0)
		{
			pRel = pRelArray->at(0);
			BR_SAFE_DELETE(pRelArray);

			return pRel->m_targetUri->getPath();
		}

		BR_SAFE_DELETE(pRelArray);
	}

	return BrNULL;
}

BString BoraPackageBase::GetReadThemePath_DOCX(BString a_strMainRelType, BString a_strRelType)
{
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);
	BoraPackagePart* pRelativePackagePart = BrNULL;

	if( pRel )
	{
		BoraPackagePart* pPart = getMatchingPart(pRel);
		PackageRelationshipCollection*	pMainDocRelationships = pPart->m_relationships;
		BArray<PackageRelationship*>* pRelArray = pMainDocRelationships->iterator(THEME_PART_TYPE);


		if(pRelArray->size() > 0)
		{
			pRel = pRelArray->at(0);
			BR_SAFE_DELETE(pRelArray);

			return pRel->m_targetUri->getPath();
		}

		BR_SAFE_DELETE(pRelArray);
	}

	return BrNULL;
}

// [OFF-8620] [11/4/2016 signous]
BString BoraPackageBase::GetReadThemePath_XLSX(BString a_strMainRelType, BString a_strRelType)
{
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);
	BoraPackagePart* pRelativePackagePart = BrNULL;

	if( pRel )
	{
		BoraPackagePart* pPart = getMatchingPart(pRel);
		PackageRelationshipCollection*	pMainDocRelationships = pPart->m_relationships;
		BArray<PackageRelationship*>* pRelArray = pMainDocRelationships->iterator(THEME_PART_TYPE);


		if(pRelArray->size() > 0)
		{
			pRel = pRelArray->at(0);
			BR_SAFE_DELETE(pRelArray);

			return pRel->m_targetUri->getPath();
		}

		BR_SAFE_DELETE(pRelArray);
	}

	return BrNULL;
}

BrBOOL BoraPackageBase::ReadPart(cmXMLDomMgr* a_pDOMmgr, BString a_strMainRelType, BString a_strRelType, BrCHAR* a_pID)
{
	BrBOOL bRet = BrFALSE;

	//.rels ���� a_strMainRelType �ش��ϴ� relationship ã��
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(a_strMainRelType);
	if( pRel )
	{
		BoraPackagePart* pPart = getMatchingPart(pRel);
		PackageRelationshipCollection*	pMainDocRelationships = pPart->m_relationships;
		BArray<PackageRelationship*>* pRelArray = pMainDocRelationships->iterator(a_strRelType);

		if(pRelArray->size() > 0)
		{
			if(a_pID)
			{
				//a_pID �� �ش��ϴ� a_strRelType�� ã�� ����
				for(BrUINT32 nIndex = 0; nIndex < pRelArray->size(); nIndex++)
				{
					pRel = pRelArray->at(nIndex);
					if(!strcmp(pRel->m_id.data(), a_pID))
					{
						bRet = MakeDomTree(a_pDOMmgr, pRel);
						break;
					}
				}
			}
			else
			{
				pRel = pRelArray->at(0);
				bRet = MakeDomTree(a_pDOMmgr, pRel);
			}
		}

		BR_SAFE_DELETE(pRelArray);
	}

	return bRet;
}

BrBOOL BoraPackageBase::ReadPart(cmXMLDomMgr* a_pDOMmgr, BString a_strMainRelType)
{
	BrBOOL bRet = BrFALSE;
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(a_strMainRelType);
	if( pRel )
		bRet = MakeDomTree(a_pDOMmgr, pRel);

	return bRet;
}

BrBOOL BoraPackageBase::ReadPartName(LPCallbackParam a_pCallbackParam, PackageRelationship* a_pRelationship)
{
	if(a_pRelationship->m_targetUri->getPath() == BrNULL)
		return BrFALSE;

	AddPackagePart(a_pRelationship->m_targetUri->getPath());

	return ReadPackageByPartname(a_pRelationship->m_targetUri->getPath().data(), a_pCallbackParam);
}

BrBOOL BoraPackageBase::ReadPartWithRelative(LPCallbackParam a_pCallbackParam, BString a_strMainRelation, BString a_strSubRelation, BString a_strRelativeRelType, BrCHAR* a_pRelTypeID, BrCHAR* a_pRelativeRelTypeID, BrCHAR* a_pPath)
{
	BrBOOL bRet = BrFALSE;
	BoraPackagePart* pRelativePackagePart = BrNULL;

	PackageRelationship* pRel = m_relationships->relationshipsByType_get(a_strMainRelation);
	if( pRel )
	{
		BoraPackagePart* pPart = getMatchingPart(pRel);
		PackageRelationshipCollection*	pMainRelationships = pPart->m_relationships;
		BArray<PackageRelationship*>* pRelArray = pMainRelationships->iterator(a_strSubRelation);

		for(BrUINT32 nIndex = 0; nIndex < pRelArray->size(); nIndex++)
		{
			pRel = pRelArray->at(nIndex);
			if(a_pRelTypeID)
			{
				if(!strcmp(pRel->m_id.data(), a_pRelTypeID))
				{
					pRelativePackagePart = GetPackagePart(pRel->m_targetUri->getPath());
					break;
				}
			}
			else
			{
				pRelativePackagePart = GetPackagePart(pRel->m_targetUri->getPath());
				if(!pRelativePackagePart)
					pRelativePackagePart = GetPackagePart(pRel->m_targetUri->getPath(), BrTRUE);
				break;
			}
		}

		BR_SAFE_DELETE(pRelArray);
	}

	if(pRelativePackagePart)
	{
		PackageRelationshipCollection*	pSlidesRelationships = pRelativePackagePart->m_relationships;
		BArray<PackageRelationship*>* pRelArray = pSlidesRelationships->iterator(a_strRelativeRelType);
		if(pRelArray->size() > 0)
		{
			if(a_pRelativeRelTypeID)
			{
				for(BrUINT32 nIndex = 0; nIndex < pRelArray->size(); nIndex++)
				{
					pRel = pRelArray->at(nIndex);
					if(!strcmp(pRel->m_id.data(), a_pRelativeRelTypeID))
					{
						if(a_pCallbackParam->pCurrentInstance)
						{
							bRet = ReadPartName(a_pCallbackParam, pRel);

							if(bRet == BrTRUE && a_pPath != BrNULL)
								memcpy(a_pPath, pRel->m_targetUri->getPath().data(), pRel->m_targetUri->getPath().length());
						}
						else
							bRet = BrTRUE;

						break;
					}
				}
			}
			else
			{
				pRel = pRelArray->at(0);
				if(a_pPath)
					memcpy(a_pPath, pRel->m_targetUri->getPath().data(), pRel->m_targetUri->getPath().length());

				if(a_pCallbackParam->pCurrentInstance)
					bRet = ReadPartName(a_pCallbackParam, pRel);	
				else
					bRet = BrTRUE;
			}
		}

		BR_SAFE_DELETE(pRelArray);
	}

	return bRet;
}

BrBOOL BoraPackageBase::ReadPartWithRelative(LPCallbackParam a_pCallbackParam, BString a_strMainRelation, BString a_strSubRelation, BString a_strRelativeRelType, BrCHAR* a_pRelTypeID, BRINT a_nIndex, BrCHAR* a_pPath)
{
	BrBOOL bRet = BrFALSE;
	BoraPackagePart* pRelativePackagePart = BrNULL;

	PackageRelationship* pRel = m_relationships->relationshipsByType_get(a_strMainRelation);
	if( pRel )
	{
		BoraPackagePart* pPart = getMatchingPart(pRel);
		PackageRelationshipCollection*	pMainRelationships = pPart->m_relationships;
		BArray<PackageRelationship*>* pRelArray = pMainRelationships->iterator(a_strSubRelation);

		for(BrUINT32 nIndex = 0; nIndex < pRelArray->size(); nIndex++)
		{
			pRel = pRelArray->at(nIndex);
			if(!strcmp(pRel->m_id.data(), a_pRelTypeID))
			{
				pRelativePackagePart = GetPackagePart(pRel->m_targetUri->getPath());
				break;
			}
		}

		BR_SAFE_DELETE(pRelArray);
	}

	if(pRelativePackagePart)
	{
		PackageRelationshipCollection*	pSlidesRelationships = pRelativePackagePart->m_relationships;
		BArray<PackageRelationship*>* pRelArray = pSlidesRelationships->iterator(a_strRelativeRelType);
		if(pRelArray->size() > 0)
		{
			if(a_nIndex != 0)
			{
				for(BrUINT32 nIndex = 0; nIndex < pRelArray->size(); nIndex++)
				{
					pRel = pRelArray->at(nIndex);
					if(PoStringToInt32(pRel->m_targetUri->getPath().data()) == a_nIndex)
					{
						if(a_pPath)
							memcpy(a_pPath, pRel->m_id.data(), pRel->m_id.length());

						if(a_pCallbackParam->pCurrentInstance)
							bRet = ReadPartName(a_pCallbackParam, pRel);
						else
							bRet = BrTRUE;

						break;
					}
				}
			}
			else
			{
				pRel = pRelArray->at(0);
				if(a_pPath)
					memcpy(a_pPath, pRel->m_targetUri->getPath().data(), pRel->m_targetUri->getPath().length());

				if(a_pCallbackParam->pCurrentInstance)
					bRet = ReadPartName(a_pCallbackParam, pRel);		
				else
					bRet = BrTRUE;
			}
		}

		BR_SAFE_DELETE(pRelArray);
	}

	return bRet;
}

BrBOOL BoraPackageBase::ReadPartWithRelative(cmXMLDomMgr* a_pDOMmgr, BString a_strMainRelation, BString a_strSubRelation, BString a_strRelativeRelType, BrCHAR* a_pRelTypeID, BrCHAR* a_pRelativeRelTypeID, BrCHAR* a_pPath)
{
	BrBOOL bRet = BrFALSE;
	BoraPackagePart* pRelativePackagePart = BrNULL;

	PackageRelationship* pRel = m_relationships->relationshipsByType_get(a_strMainRelation);
	if( pRel )
	{
		BoraPackagePart* pPart = getMatchingPart(pRel);
		PackageRelationshipCollection*	pMainRelationships = pPart->m_relationships;
		BArray<PackageRelationship*>* pRelArray = pMainRelationships->iterator(a_strSubRelation);

		for(BrUINT32 nIndex = 0; nIndex < pRelArray->size(); nIndex++)
		{
			pRel = pRelArray->at(nIndex);
			if(a_pRelTypeID)
			{
				if(!strcmp(pRel->m_id.data(), a_pRelTypeID))
				{
					pRelativePackagePart = GetPackagePart(pRel->m_targetUri->getPath());
					break;
				}
			}
			else
			{
				pRelativePackagePart = GetPackagePart(pRel->m_targetUri->getPath());
				break;
			}
		}

		BR_SAFE_DELETE(pRelArray);
	}

	if(pRelativePackagePart)
	{
		PackageRelationshipCollection*	pSlidesRelationships = pRelativePackagePart->m_relationships;
		BArray<PackageRelationship*>* pRelArray = pSlidesRelationships->iterator(a_strRelativeRelType);
		if(pRelArray->size() > 0)
		{
			if(a_pRelativeRelTypeID)
			{
				for(BrUINT32 nIndex = 0; nIndex < pRelArray->size(); nIndex++)
				{
					pRel = pRelArray->at(nIndex);
					if(!strcmp(pRel->m_id.data(), a_pRelativeRelTypeID))
					{
						bRet = MakeDomTree(a_pDOMmgr, pRel);
						if(a_pPath)
							memcpy(a_pPath, pRel->m_targetUri->getPath().data(), pRel->m_targetUri->getPath().length());

						break;
					}
				}
			}
			else
			{
				pRel = pRelArray->at(0);
				if(a_pPath)
					memcpy(a_pPath, pRel->m_targetUri->getPath().data(), pRel->m_targetUri->getPath().length());

				bRet = MakeDomTree(a_pDOMmgr, pRel);
			}
		}

		BR_SAFE_DELETE(pRelArray);
	}

	return bRet;
}

BrBOOL BoraPackageBase::MakeDomTree(cmXMLDomMgr* a_pDOMmgr, PackageRelationship* a_pRel)
{
	AddPackagePart(a_pRel->m_targetUri->getPath());

	BrLPBYTE pBuf = BrNULL;
	BrUINT32 nSize = m_pftXMLStorage->GetZipItemStream(a_pRel->m_targetUri->getPath().data(), pBuf);
	if(nSize)
	{
		HCM_XMLDOCUMENT hXMLDocument = a_pDOMmgr->ReadFromXMLByStream((BrCHAR*)pBuf, nSize);
		a_pDOMmgr->SetNode((HCM_XMLDOCUMENT)hXMLDocument);
		BR_SAFE_FREE(pBuf);	

		return BrTRUE;
	}

	return BrFALSE;
}


#ifdef POLARIS_BASIC_DEVELOPMENT 
BString BoraPackageBase::GetRelIDWithPartName(BString a_strRelType, BrCHAR* a_pSrcPartName)
{
	//[2012-02-02] m_partList = null �� ����� ó��(Chart_23.pptx ����)
	if(!m_partList)
		return "";

	BoraPackagePart* pPart = GetPackagePart(a_pSrcPartName);
	BString strPath;

	//if(!pPart->m_relationships)
	if(pPart && !pPart->m_relationships) //[inkkim] null check
	{
		CallbackParam callbackParam;
		//[2011.09.26][�����][TID:239] callbackparam �ʱ�ȭ
		memset(&callbackParam, 0, BrSizeOf(CallbackParam));
		pPart->m_relationships = BrNEW PackageRelationshipCollection(this);
		callbackParam.pCurrentInstance = pPart->m_relationships;
		if( !ReadPackageByPartname(a_pSrcPartName, &callbackParam) )
			return strPath;
	}

	strPath = FindRelationID(pPart, a_strRelType);

	return strPath;
}
#endif //POLARIS_BASIC_DEVELOPMENT 

#ifdef POLARIS_BASIC_DEVELOPMENT 
BString BoraPackageBase::FindRelationID(BoraPackagePart* a_pPart, BString a_strRelType)
{
	BString strID;
	if(a_pPart)
	{
		PackageRelationshipCollection*	pRelationships = a_pPart->m_relationships;
		BArray<PackageRelationship*>* pRelArray = pRelationships->iterator(a_strRelType);
		PackageRelationship* pRel;
		if(pRelArray->size() > 0)
		{
			pRel = pRelArray->at(0);
			if( pRel )
				strID = pRel->getId();
		}

		BR_SAFE_DELETE(pRelArray);
	}

	return strID;
}
#endif //POLARIS_BASIC_DEVELOPMENT 


BString BoraPackageBase::GetPathWithPartName(BString a_strRelType, const BrCHAR* a_pSrcPartName, const BrCHAR* a_pCmpPartName)
{
	//[2012-02-02] m_partList = null �� ����� ó��(Chart_23.pptx ����)
	if(!m_partList)
		return "";

	BoraPackagePart* pPart = GetPackagePart(a_pSrcPartName);
	BString strPath;

	//if(!pPart->m_relationships)
	if(pPart && !pPart->m_relationships) //[inkkim] null check
	{
		CallbackParam callbackParam;
		//[2011.09.26][�����][TID:239] callbackparam �ʱ�ȭ
		memset(&callbackParam, 0, BrSizeOf(CallbackParam));
		pPart->m_relationships = BrNEW PackageRelationshipCollection(this);
		callbackParam.pCurrentInstance = pPart->m_relationships;
		if( !ReadPackageByPartname(a_pSrcPartName, &callbackParam) )
			return strPath;
	}

	strPath = FindPath(pPart, a_strRelType, a_pCmpPartName);

	return strPath;
}

BString BoraPackageBase::GetPathWithMainRelType(BString a_strMainRelType, BString a_strRelType, BrCHAR* a_pCmpPartName /* = BrNULL */)
{
	BString strPath;
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(a_strMainRelType);
	if(pRel)
	{
		BoraPackagePart* pPart = getMatchingPart(pRel);
		strPath = FindPath(pPart, a_strRelType, a_pCmpPartName);
	}

	return strPath;
}

BString BoraPackageBase::FindPath(BoraPackagePart* a_pPart, BString a_strRelType, const BrCHAR* a_pCmpRelID)
{
	BString strEmpty;

	if(a_pPart)
	{
		PackageRelationshipCollection*	pRelationships = a_pPart->m_relationships;
		PackageRelationshipItem* item = BrNULL;
		BrINT32 nSize = pRelationships->m_relationshipsByID.size();
		if( nSize == 0 )
			return strEmpty;

		if( a_pCmpRelID )
		{
			BString strRelID(a_pCmpRelID);
			PackageRelationship* pRelationship = findRelationship(a_pPart, BrNULL, a_pCmpRelID);				
			if( pRelationship )
				return  pRelationship->m_targetUri->getPath();	
		}
		else
		{
			for(BrINT32 i = 0 ; i < nSize; i++)
			{
				item = pRelationships->m_relationshipsByID[i];
				if(a_strRelType.compare(item->m_relationship->getRelationshipType()) == 0)
					return item->m_relationship->m_targetUri->getPath();
			}
		}
	}

	return strEmpty;
}


BrUINT32 BoraPackageBase::GetPartCount(BString a_strMainRelType, BString a_strRelType)
{
	BrUINT32 nSize = 0;
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(a_strMainRelType);
	if( pRel )
	{
		BoraPackagePart* pPart = getMatchingPart(pRel);
		PackageRelationshipCollection*	pMainDocRelationships = pPart->m_relationships;
		BArray<PackageRelationship*>* pRelArray = pMainDocRelationships->iterator(a_strRelType);

		nSize = pRelArray->size();

		BR_SAFE_DELETE(pRelArray);
	}

	return nSize;
}

BrUINT32 BoraPackageBase::GetFileNumWithRelative(BString a_strMainRelType, BString a_strRelType, BrUINT32 nRelIndex)
{
	BrUINT32 nFileNum = 0;
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(a_strMainRelType);
	if( pRel )
	{
		BoraPackagePart* pPart = getMatchingPart(pRel);
		PackageRelationshipCollection*	pRelationshipCollection = pPart->m_relationships;
		BArray<PackageRelationship*>* pRelArray = pRelationshipCollection->iterator(a_strRelType);

		for(BrINT nIdx=0; nIdx<pRelArray->size(); nIdx++)
		{
			pRel = pRelArray->at(nIdx);
#ifdef SEPERATE_MASTERID
			if(BrAtoll(pRel->m_id.data()) == nRelIndex)
			{
				BrDELETE pRelArray;
				return BrAtoll(pRel->m_targetUri->getPath().data());
			}
#else //SEPERATE_MASTERID
			if(PoStringToInt32(pRel->m_id.data()) == nRelIndex)
			{
				BrDELETE pRelArray;
				return PoStringToInt32(pRel->m_targetUri->getPath().data());
			}
#endif //SEPERATE_MASTERID
		}
		BrDELETE pRelArray;
	}

	return -1;
}

BrUINT32 BoraPackageBase::GetPartCountWithRelative(BString a_strMainRelType, BString a_strRelType, BString a_strRelativeRelType, BrUINT32 nRelIndex, BrUINT32* pRelIDNum)
{
	BrUINT32 nSize = 0;
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(a_strMainRelType);
	if( pRel )
	{
		BoraPackagePart* pPart = getMatchingPart(pRel);
		PackageRelationshipCollection*	pRelationshipCollection = pPart->m_relationships;
		BArray<PackageRelationship*>* pRelArray = pRelationshipCollection->iterator(a_strRelType);

		for(BrINT nIdx=0; nIdx<pRelArray->size(); nIdx++)
		{
			pRel = pRelArray->at(nIdx);
			if(PoStringToInt32(pRel->m_targetUri->getPath().data()) == nRelIndex+1)
			{
				if(pRelIDNum)
					*pRelIDNum = PoStringToInt32(pRel->m_id.data());
				break;
			}
			else
				pRel = BrNULL;
		}

		if(!pRel)
		{
			BrDELETE pRelArray;
			return -1;
		}

		pPart = GetPackagePart(pRel->m_targetUri->getPath());
		if(pPart)
		{
			pRelationshipCollection = pPart->m_relationships;					
			BArray<PackageRelationship*>* pSubArray = pRelationshipCollection->iterator(a_strRelativeRelType);
			nSize = pSubArray->size();
			BR_SAFE_DELETE(pSubArray);
		}

		BR_SAFE_DELETE(pRelArray);
	}

	return nSize;
}

void BoraPackageBase::GetStartEndLayoutNum(BString a_strMainRelType, BString a_strRelType, BString a_strRelativeRelType, BrUINT32 nRelIndex, int& nStart, int& nEnd)
{
	BrUINT32 nSize = 0;
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(a_strMainRelType);
	if( pRel )
	{
		BoraPackagePart* pPart = getMatchingPart(pRel);
		PackageRelationshipCollection*	pRelationshipCollection = pPart->m_relationships;
		BArray<PackageRelationship*>* pRelArray = pRelationshipCollection->iterator(a_strRelType);

		for(BrINT nIdx=0; nIdx<pRelArray->size(); nIdx++)
		{
			pRel = pRelArray->at(nIdx);
			if(PoStringToInt32(pRel->m_targetUri->getPath().data()) == nRelIndex+1)
			{
				break;
			}
			else
				pRel = BrNULL;
		}

		if(!pRel)
		{
			BR_SAFE_DELETE(pRelArray);
			return;
		}

		pPart = GetPackagePart(pRel->m_targetUri->getPath());
		if(pPart)
		{
			pRelationshipCollection = pPart->m_relationships;					
			BArray<PackageRelationship*>* pSubArray = pRelationshipCollection->iterator(a_strRelativeRelType);
			nSize = pSubArray->size();

			if(nSize == 0)
			{
				BR_SAFE_DELETE(pRelArray);
				BR_SAFE_DELETE(pSubArray);
				return;
			}

			nStart = nEnd = PoStringToInt32(pSubArray->at(0)->m_targetUri->getPath());
			for(int i = 0; i < nSize ; i++)
			{
				 nStart = BrMIN(nStart, PoStringToInt32(pSubArray->at(i)->m_targetUri->getPath()));
				 nEnd = BrMAX(nEnd, PoStringToInt32(pSubArray->at(i)->m_targetUri->getPath()));
			}

			BR_SAFE_DELETE(pSubArray);
		}

		BR_SAFE_DELETE(pRelArray);
	}

	return;
}

BArray<PackageRelationship*>* BoraPackageBase::GetLayoutListOfRelations(BrINT32 a_nMasterRelID)
{
	BrINT32 nLayoutRelID = -1;
	BoraPackagePart* pRelativePackagePart = BrNULL;

	PackageRelationship* pRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);
	if( pRel )
	{
		BoraPackagePart* pPart = getMatchingPart(pRel);
		PackageRelationshipCollection*	pMainRelationships = pPart->m_relationships;
		BArray<PackageRelationship*>* pRelArray = pMainRelationships->iterator(SLIDE_MASTER_PART_TYPE);

		for(BrUINT32 nIndex = 0; nIndex < pRelArray->size(); nIndex++)
		{
			pRel = pRelArray->at(nIndex);
#ifdef SEPERATE_MASTERID
			BrINT32 nRelID = BrAtoll(pRel->m_id);
			if(nRelID == a_nMasterRelID)
#else //SEPERATE_MASTERID
			if(PoStringToInt32(pRel->m_id) == a_nMasterRelID)
#endif //SEPERATE_MASTERID
			{
				pRelativePackagePart = GetPackagePart(pRel->m_targetUri->getPath());
				break;
			}
		}

		BR_SAFE_DELETE(pRelArray);
	}

	BArray<PackageRelationship*>* pRelArray = BrNULL;
	if(pRelativePackagePart)
	{
		PackageRelationshipCollection*	pSlidesRelationships = pRelativePackagePart->m_relationships;
		pRelArray = pSlidesRelationships->iterator(SLIDE_LAYOUT_PART_TYPE);
	}

	return pRelArray;
}

BrBOOL BoraPackageBase::ReadPackageByPartname(const BrCHAR* strPartName, LPCallbackParam pCallbackParam, BrBOOL bNeedSuspend)
{
	BrINT32 nPartIndex = m_pftXMLStorage->GetIndex(strPartName);
	if( nPartIndex==-1 )
		return BrFALSE;
	BrBOOL bRet = ReadAndParsePart_XmlParser(m_pftXMLStorage->m_oZipInfo.hZipFile,  m_pftXMLStorage->m_oZipInfo.zes[nPartIndex], nPartIndex, pCallbackParam, bNeedSuspend);
	return bRet;
}

BrBOOL BoraPackageBase::ReadPackageByPartname(cmXMLDomMgr* a_pCmXmlDomMgr, const BrCHAR* strPartName)
{
	BrLPBYTE pBuf = BrNULL;
	BrUINT32 nSize = m_pftXMLStorage->GetZipItemStream(strPartName, pBuf);
	if(nSize)
	{
		HCM_XMLDOCUMENT hXMLDocument = a_pCmXmlDomMgr->ReadFromXMLByStream((BrCHAR*)pBuf, nSize);
		a_pCmXmlDomMgr->SetNode((HCM_XMLDOCUMENT)hXMLDocument);
		BR_SAFE_FREE(pBuf);	

		return BrTRUE;
	}
	return BrFALSE;
}

BrLPBYTE BoraPackageBase::GetEmbedingPackageByPartname(const BrCHAR* strPartName, BrINT32 &nMemSize)
{
	BrINT32 nPartIndex = m_pftXMLStorage->GetIndex(strPartName);
	if( nPartIndex==-1 )
		return BrNULL;

	return ReadEmbedingPackage_XmlParser(m_pftXMLStorage->m_oZipInfo.hZipFile, m_pftXMLStorage->m_oZipInfo.zes[nPartIndex], nPartIndex, nMemSize);
}

BrLPBYTE BoraPackageBase::ReadImageByPartname(const BrCHAR* strPartName, IMG_INFO* pImgInfo, BrBOOL bExport, BrBOOL a_bEffect)
{
	if( !strPartName )
		return BrNULL;

	BrINT32 nPartIndex = m_pftXMLStorage->GetIndex(strPartName);
	if( nPartIndex==-1 )
		return BrNULL;

	if(bExport && m_pWritePackage)
	{
		TCHAR* pFileName = (TCHAR*)BrMalloc(512);
		memset(pFileName, 0, 512);
		BrCHAR *pTmpPath = (BrCHAR*)BrGetTempPath();
		BrINT32 nLen = BrStrLen(pTmpPath);
		if( nLen > 0 ) {
			if(a_bEffect)
				sprintf_s(pFileName, 512, "%sImageTmp/", pTmpPath);
			else
				sprintf_s(pFileName, 512, "%s", pTmpPath);

			nLen = BrStrLen(pFileName);
			char *pName = strrchr(m_pftXMLStorage->m_oZipInfo.zes[nPartIndex]->name, '/');
			if( pFileName[nLen-1] != '/')
				sprintf_s(pFileName+nLen, 512-nLen, "%s", pName);
			else
				sprintf_s(pFileName+nLen, 512-nLen, "%s", pName+1);
		}

		//desoohn: bExport�̰� strPartName���� ����Ǿ��� ����� ������ �ش� ���� �н��� �״�� �����Ѵ�. �ߺ� �̹��� ���� �ȵǵ���.
		if(m_pWritePackage->isExistFile(strPartName))
			return (BrLPBYTE)pFileName;

		BString strFileName = CUtil::UTF8ToBString(pFileName);
		m_pWritePackage->addPartName(strPartName, strFileName);
		BR_SAFE_FREE(pFileName);
	}

#if defined(SUPPORT_MULTICORE) && defined(USE_MCORE_XSAVE)
	BRCONTEXT;
	if(getDocExt() != BORA_EXT_THMX && !m_pftXMLStorage->GetBlockZip() && m_pftXMLStorage->m_oZipInfo.hZipFile)
		m_pftXMLStorage->SetBlockZip();
	return ReadImage_XmlParser(m_pftXMLStorage->m_oZipInfo.hZipFile, m_pftXMLStorage->m_oZipInfo.zes[nPartIndex], nPartIndex, pImgInfo, bExport, m_pftXMLStorage->GetBlockZip());
#else //SUPPORT_MULTICORE && USE_MCORE_XSAVE
	return ReadImage_XmlParser(m_pftXMLStorage->m_oZipInfo.hZipFile, m_pftXMLStorage->m_oZipInfo.zes[nPartIndex], nPartIndex, pImgInfo, bExport, BrNULL, a_bEffect);
#endif //SUPPORT_MULTICORE
}

BrLPBYTE BoraPackageBase::ReadImageByPartnameForWDP(const BrCHAR* strPartName, BrBOOL a_bEffect)
{
	if( !strPartName )
		return BrNULL;

	BrINT32 nPartIndex = m_pftXMLStorage->GetIndex(strPartName);
	if( nPartIndex==-1 )
		return BrNULL;

	IMG_INFO ImgInfo = { eImage_NONE, };

// 	//desoohn: bExport�̰� strPartName���� ����Ǿ��� ����� ������ �ش� ���� �н��� �״�� �����Ѵ�. �ߺ� �̹��� ���� �ȵǵ���.
// 	if ( m_pWritePackage && m_pWritePackage->isExistFile(strPartName))
// 	{
// 		TCHAR* pFileName = (TCHAR*)BrMalloc(512);
// 		memset(pFileName, 0, 512);
// 		BrCHAR *pTmpPath = (BrCHAR*)BrGetTempPath();
// 		BrINT32 nLen = BrStrLen(pTmpPath);
// 		if( nLen > 0 ) {
// 			if( pTmpPath[nLen-1] != '/') 
// 				sprintf(pFileName, "%s/", pTmpPath);
// 			else
// 				sprintf(pFileName, "%s", pTmpPath);
// 
// 			nLen = BrStrLen(pFileName);
// 			char *pName = strrchr(m_pftXMLStorage->m_oZipInfo.zes[nPartIndex]->name, '/');
// 			if( pFileName[nLen-1] != '/')
// 				sprintf(pFileName+nLen, "%s", pName);
// 			else
// 				sprintf(pFileName+nLen, "%s", pName+1);
// 		}
// 		return (BrLPBYTE)pFileName;
// 	}

	return ReadImage_XmlParser(m_pftXMLStorage->m_oZipInfo.hZipFile, m_pftXMLStorage->m_oZipInfo.zes[nPartIndex], nPartIndex, &ImgInfo, BrTRUE, 0, a_bEffect);
}

BrBOOL BoraPackageBase::ReadImageInfoByPartname(const BrCHAR* strPartName, IMG_INFO* pImgInfo)
{
	if( !strPartName )
		return BrFALSE;

	BrINT32 nPartIndex = m_pftXMLStorage->GetIndex(strPartName);
	if( nPartIndex==-1 )
		return BrFALSE;

	return ReadImageInfo_XmlParser(m_pftXMLStorage->m_oZipInfo.hZipFile,  m_pftXMLStorage->m_oZipInfo.zes[nPartIndex], nPartIndex, pImgInfo);
}

BrBOOL BoraPackageBase::partExists(BoraPackagePartName* partName) 
{
	return (getPart(partName) != BrNULL);
}

BoraPackagePart* BoraPackageBase::getMatchingPart(PackageRelationship* partRel) 
{
	if(partRel == BrNULL)
		return BrNULL;

	PackageRelationship* pRel = m_relationships->relationshipsByType_get(partRel->getRelationshipType());
	if( pRel )
	{
		BoraPackagePartName* partName = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath());
		PackagePartItem* pPart = m_partList->get(partName);
		if( pPart )
		{
			BrDELETE partName;
			return pPart->m_pPackagePart;
		}
		BString strType = m_contentTypeManager->getContentType(partName);
		BoraPackagePart* part = BrNEW BoraPackagePart(this, partName, strType);
		m_partList->put(partName, part);
		return part;
	}

	return BrNULL;
}

BoraPackagePart* BoraPackageBase::getPart(BoraPackagePartName* partName, BrBOOL *a_pNewPart) 
{
	if(a_pNewPart)
		*a_pNewPart = BrFALSE;

	PackagePartItem* pPart = m_partList->get(partName);
	if( pPart )
		return pPart->m_pPackagePart;

	if( !IsExistPart((BrCHAR *)partName->getName().data()) )
		return BrNULL;

	if(a_pNewPart)
		*a_pNewPart = BrTRUE;
	
	BString strType = m_contentTypeManager->getContentType(partName);
	BoraPackagePart* part = BrNEW BoraPackagePart(this, partName, strType);
	m_partList->put(partName, part);

	return part;
}

BoraPackagePart* BoraPackageBase::GetPackagePart(BoraPackagePartName* a_pPartName) 
{
	if(a_pPartName == BrNULL)
		return BrNULL;
	BString strPartName = a_pPartName->m_PartNameURI.toString();
	PackagePartItem* pPart = m_partList->Get(strPartName.lower());
	if( pPart )
		return pPart->m_pPackagePart;

	if( !IsExistPart((BrCHAR *)strPartName.data()) )
		return BrNULL;

	BString strType = m_contentTypeManager->getContentType(a_pPartName);
	BoraPackagePart* part = BrNEW BoraPackagePart(this, a_pPartName, strType);
	m_partList->put(a_pPartName, part);

	return part;
}

BoraPackagePart* BoraPackageBase::GetPackagePart(const BrCHAR* a_pPath) 
{
	PackagePartItem* pPart = m_partList->Get(BString(a_pPath));
	if (pPart)
		return pPart->m_pPackagePart;

	BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(a_pPath);
	if (BrFALSE == IsExistPart((BrCHAR*)pPartName->getName().data())) {
		BrDELETE pPartName;  // coverity 22517 resource leak
		return BrNULL;
	}

	BString strType = m_contentTypeManager->getContentType(pPartName);
	BoraPackagePart* pPackagePart = BrNEW BoraPackagePart(this, pPartName, strType);
	m_partList->put(pPartName, pPackagePart);

	return pPackagePart;
}

BoraPackagePart* BoraPackageBase::GetPackagePart(const BrCHAR* a_pPath, BrBOOL bRecovery) 
{
	PackagePartItem* pPart = m_partList->Get(BString(a_pPath));
	if (pPart)
		return pPart->m_pPackagePart;

	BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(a_pPath);
	if (BrFALSE == IsExistPart((BrCHAR*)pPartName->getName().data()) && !bRecovery) 
	{
		BrDELETE pPartName;  // coverity 22517 resource leak
		return BrNULL;
	}

	BString strType = m_contentTypeManager->getContentType(pPartName);
	BoraPackagePart* pPackagePart = BrNEW BoraPackagePart(this, pPartName, strType);
	m_partList->put(pPartName, pPackagePart);

	return pPackagePart;
}

BrVOID BoraPackageBase::AddPackagePart(BString a_strPartName)
{
	PackagePartItem* pPartItem = m_partList->Get(a_strPartName);
	if(pPartItem)
		return;

	if( !IsExistPart((BrCHAR*)a_strPartName.data()) )
		return;

	BoraPackagePartName* pPackagePartName = PackagingURIHelper::createPartName(a_strPartName);
	BString strType = m_contentTypeManager->getContentType(pPackagePartName);
	BoraPackagePart* pPackagePart = BrNEW BoraPackagePart(this, pPackagePartName, strType);
	m_partList->put(pPackagePartName, pPackagePart);

	return;
}

#ifdef PPT_EDITOR
// �����ͺ� ���̾ƿ�
BrBOOL BoraPackageBase::ReadLayoutPart_PPTX(LPCallbackParam a_pCallbackParam, BrINT32 a_nMaster, BrINT32 a_nLayout, BrCHAR* a_pLayout)
{
	BrBOOL	bRet = BrFALSE;
	BoraPackagePart* pMasterPackagePart = BrNULL;

	//1. Find Slide Package Part
	//.rels ���� CORE_DOCUMENT_PART_TYPE �� �ش��ϴ� relationship ã��
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);
	if( pRel )
	{
		//  ppt/presentation.xml
		BoraPackagePart* pPart = getMatchingPart(pRel);

		//  ppt/_rels/presentation.xml.rels
		PackageRelationshipCollection*	pMainDocRelationships = pPart->m_relationships;

		//  ppt/_rels/presentation.xml.rels ���� SLIDE_MASTER_PART_TYPE �� �ش��ϴ� relationship ã��
		BArray<PackageRelationship*>* pMasterRelArray = pMainDocRelationships->iterator(SLIDE_MASTER_PART_TYPE);

		//  nID �� �ش��ϴ� slide �� ã�� ����.
		for(BrINT nIdx=0; nIdx<pMasterRelArray->size(); nIdx++)
		{
			pRel = pMasterRelArray->at(nIdx);
			if(BrAtoi(pRel->m_targetUri->getPath().data()) == a_nMaster+1)
				break;
			else
				pRel = BrNULL;
		}

		if(!pRel)
		{
			BrDELETE pMasterRelArray;
			return BrFALSE;
		}

		pMasterPackagePart = GetPackagePart(pRel->m_targetUri->getPath());
		if(pMasterPackagePart)
		{
			PackageRelationshipCollection*	pRelationships = pMasterPackagePart->m_relationships;
			BArray<PackageRelationship*>* pLayoutArray = pRelationships->iterator(SLIDE_LAYOUT_PART_TYPE);

			for(BrINT nIdx=0; nIdx<pLayoutArray->size(); nIdx++)
			{
				pRel = pLayoutArray->at(nIdx);
				if(BrAtoi(pRel->m_targetUri->getPath().data()) == a_nLayout)
					break;
				else
					pRel = BrNULL;
			}

			if(!pRel)
			{
				BrDELETE pMasterRelArray;
				BrDELETE pLayoutArray;

				return BrFALSE;
			}

			memcpy(a_pLayout, pRel->m_targetUri->getPath().data(), pRel->m_targetUri->getPath().length());

			AddPackagePart(pRel->m_targetUri->getPath());

			bRet = ReadPackageByPartname(pRel->m_targetUri->getPath().data(), a_pCallbackParam);

			BrDELETE pLayoutArray;
		}

		BrDELETE pMasterRelArray;
	}

	return BrTRUE;
}

#endif //PPT_EDITOR
#ifdef SUPPORT_PPTX_NOTEMASTER_IMPORT
BrBOOL BoraPackageBase::CheckNoteSlide(BrCHAR* a_nSlideRelID)
{
	BrBOOL bRet=BrFALSE;

	BoraPackagePart* pSlidePackagePart = BrNULL;

	//1. Find Slide Package Part
	//.rels ���� CORE_DOCUMENT_PART_TYPE �� �ش��ϴ� relationship ã��
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);
	if( pRel )
	{
		//  ppt/presentation.xml
		BoraPackagePart* pPart = getMatchingPart(pRel);

		//  ppt/_rels/presentation.xml.rels
		PackageRelationshipCollection*	pMainDocRelationships = pPart->m_relationships;

		//  ppt/_rels/presentation.xml.rels ���� SLIDE_PART_TYPE �� �ش��ϴ� relationship ã��
		BArray<PackageRelationship*>* pSlideRelArray = pMainDocRelationships->iterator(SLIDE_PART_TYPE);

		//  nID �� �ش��ϴ� slide �� ã�� ����.
		for(BrINT32 i=0; i<(BrINT32)pSlideRelArray->size(); i++)
		{
			pRel = pSlideRelArray->at(i);
			if( strcmp(pRel->m_id.data(), a_nSlideRelID)==0 )
			{
				pSlidePackagePart = GetPackagePart(pRel->m_targetUri->getPath());
				break;
			}
		}

		BrDELETE pSlideRelArray;
	}

	if(pSlidePackagePart)
	{
		PackageRelationshipCollection* pRelationShipsCollection = pSlidePackagePart->getRelationships();
		BArray<PackageRelationshipItem*> ItemArray = pRelationShipsCollection->m_relationshipsByID;

		for(BrINT32 i = 0; i<ItemArray.size(); i++)
		{
			PackageRelationshipItem* pItem = ItemArray.at(i);
			if(strcmp(pItem->m_relationship->m_relationshipType.data(), NOTES_SLIDE_PART_TYPE) == 0)
				return BrTRUE;
		}
	}	

	return BrFALSE;
}
#endif //SUPPORT_PPTX_NOTEMASTER_IMPORT

BrCHAR* BoraPackageBase::FindSlideFilename_PPTX(BrCHAR* pSlideRelID)
{
	if(!pSlideRelID)
		return BrNULL;

	PackageRelationship* pRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);
	if(pRel)
	{
		BoraPackagePart* pPart = getMatchingPart(pRel);
		PackageRelationshipCollection*	pMainDocRelationships = pPart->m_relationships;
		BArray<PackageRelationship*>* pSlideRelArray = pMainDocRelationships->iterator(SLIDE_PART_TYPE);

		for(BrINT32 i=0; i<(BrINT32)pSlideRelArray->size(); i++)
		{
			pRel = pSlideRelArray->at(i);
			
			if(pRel && !pRel->m_id.isEmpty())
			{
				if( strcmp(pRel->m_id.data(), pSlideRelID)==0 )
				{
					BrDELETE pSlideRelArray;
					return (BrCHAR*)pRel->m_targetUri->getPath().data();
				}
			}
		}

		BrDELETE pSlideRelArray;
	}

	return BrNULL;
}

BrCHAR* BoraPackageBase::FindSlideMasterID_PPTX(BrCHAR* nSlideRelID) //nID �� rId1 �� presentation.xml (main document part) �� �ִ� id ��.
{
	if(!nSlideRelID)
		return BrNULL;
	
	//slide.xml -> slide.xml.rel -> layout.xml -> layout.xml.rel -> master target ==> find id from main doc relations using master target
	BrBOOL bRet=BrFALSE;

	BrCHAR*		strMsterTarget = BrNULL;
	BoraPackagePart* pSlidePackagePart = BrNULL;

	//1. Find Slide Package Part
	//.rels ���� CORE_DOCUMENT_PART_TYPE �� �ش��ϴ� relationship ã��
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);
	if( pRel )
	{
		//  ppt/presentation.xml
		BoraPackagePart* pPart = getMatchingPart(pRel);

		//  ppt/_rels/presentation.xml.rels
		PackageRelationshipCollection*	pMainDocRelationships = pPart->m_relationships;
		
		//  ppt/_rels/presentation.xml.rels ���� SLIDE_PART_TYPE �� �ش��ϴ� relationship ã��
		BArray<PackageRelationship*>* pSlideRelArray = pMainDocRelationships->iterator(SLIDE_PART_TYPE);

        //  nID �� �ش��ϴ� slide �� ã�� ����.
		for(BrINT32 i=0; i<(BrINT32)pSlideRelArray->size(); i++)
		{
			pRel = pSlideRelArray->at(i);

			if(pRel && strcmp(pRel->m_id.data(), nSlideRelID)==0 )
			{
				pSlidePackagePart = GetPackagePart(pRel->m_targetUri->getPath());
				break;
			}
		}

		BrDELETE pSlideRelArray;
	}

	if( pSlidePackagePart )
	{
		//2. Get Master Target Name
		//  ppt/slides/_rels/slide?.xml.rels
		PackageRelationshipCollection*	pSlidesRelationships = pSlidePackagePart->m_relationships;
		
		//  ppt/slides/_rels/slide?.xml.rels ���� LAYOUT_PART_TYPE �� �ش��ϴ� relationship ã��
		BArray<PackageRelationship*>* pLayoutRelArray = pSlidesRelationships->iterator(SLIDE_LAYOUT_PART_TYPE);
		if( pLayoutRelArray && pLayoutRelArray->size() )
		{
			pRel = pLayoutRelArray->at(0);

			BoraPackagePart* pLayoutPackagePart = GetPackagePart(pRel->m_targetUri->getPath());

			if(!pLayoutPackagePart)
			{
				BrDELETE pLayoutRelArray;
				return BrNULL;
			}

			//Get Master Target Name from Layout Relationship
			PackageRelationshipCollection*	pLayoutRelationships = pLayoutPackagePart->m_relationships;
			BArray<PackageRelationship*>* pMasterRelArray = pLayoutRelationships->iterator(SLIDE_MASTER_PART_TYPE);
			if( pMasterRelArray && pMasterRelArray->size() )
			{
				pRel = pMasterRelArray->at(0);
				strMsterTarget = (BrCHAR*)pRel->m_targetUri->getPath().data();
			}
			BR_SAFE_DELETE(pMasterRelArray);
		}
		BrDELETE pLayoutRelArray;

		if( strMsterTarget )
		{
			//3. Get ID From Main Doc Relationship
			pRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);
			//  ppt/presentation.xml
			BoraPackagePart* pPart = getMatchingPart(pRel);
			//  ppt/_rels/presentation.xml.rels
			PackageRelationshipCollection*	pMainDocRelationships = pPart->m_relationships;
			//  ppt/_rels/presentation.xml.rels ���� SLIDE_MASTER_PART_TYPE �� �ش��ϴ� relationship ã��
			BArray<PackageRelationship*>* pMasterSlideRelArray = pMainDocRelationships->iterator(SLIDE_MASTER_PART_TYPE);

			for(BrINT32 i=0; i<(BrINT32)pMasterSlideRelArray->size(); i++)
			{
				pRel = pMasterSlideRelArray->at(i);
				if( strcmp(pRel->m_targetUri->getPath().data(), strMsterTarget)==0 )
				{
					BrDELETE pMasterSlideRelArray;
					return (BrCHAR*)pRel->getId().data();
				}
			}
			BrDELETE pMasterSlideRelArray;
		}
	}

	return BrNULL;
}

BrINT32 BoraPackageBase::FindSlideLayoutRelID(BrINT32 a_nMasterRelID, BrINT32 a_nLayoutNum)
{
	BrINT32 nLayoutRelID = -1;
	BoraPackagePart* pRelativePackagePart = BrNULL;

	PackageRelationship* pRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);
	if( pRel )
	{
		BoraPackagePart* pPart = getMatchingPart(pRel);
		PackageRelationshipCollection*	pMainRelationships = pPart->m_relationships;
		BArray<PackageRelationship*>* pRelArray = pMainRelationships->iterator(SLIDE_MASTER_PART_TYPE);

		for(BrUINT32 nIndex = 0; nIndex < pRelArray->size(); nIndex++)
		{
			pRel = pRelArray->at(nIndex);
#ifdef SEPERATE_MASTERID
			BrINT32 nRelID = BrAtoll(pRel->m_id);
			if(nRelID == a_nMasterRelID)
#else //SEPERATE_MASTERID
			if(PoStringToInt32(pRel->m_id) == a_nMasterRelID)
#endif //SEPERATE_MASTERID
			{
				pRelativePackagePart = GetPackagePart(pRel->m_targetUri->getPath());
				break;
			}
		}

		BR_SAFE_DELETE(pRelArray);
	}

	if(pRelativePackagePart)
	{
		PackageRelationshipCollection*	pSlidesRelationships = pRelativePackagePart->m_relationships;
		BArray<PackageRelationship*>* pRelArray = pSlidesRelationships->iterator(SLIDE_LAYOUT_PART_TYPE);
		if(pRelArray->size() > 0)
		{
			for(BrUINT32 nIndex = 0; nIndex < pRelArray->size(); nIndex++)
			{
				pRel = pRelArray->at(nIndex);
				if(PoStringToInt32(pRel->m_targetUri->getPath().data()) == a_nLayoutNum)
				{
#ifdef SEPERATE_MASTERID
					nLayoutRelID = BrAtoll(pRel->m_id);
#else //SEPERATE_MASTERID
					nLayoutRelID = PoStringToInt32(pRel->m_id);
#endif //SEPERATE_MASTERID
					break;
				}
			}
		}

		BR_SAFE_DELETE(pRelArray);
	}

	return nLayoutRelID;
}
BrCHAR* BoraPackageBase::FindThemeRelID(BrCHAR* a_strMasterRelID, BrCHAR* a_strThemePath)
{
	BoraPackagePart* pRelativePackagePart = BrNULL;

	PackageRelationship* pRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);
	if( pRel )
	{
		BoraPackagePart* pPart = getMatchingPart(pRel);
		PackageRelationshipCollection*	pMainRelationships = pPart->m_relationships;
		BArray<PackageRelationship*>* pRelArray = pMainRelationships->iterator(SLIDE_MASTER_PART_TYPE);

		for(BrUINT32 nIndex = 0; nIndex < pRelArray->size(); nIndex++)
		{
			pRel = pRelArray->at(nIndex);
			if(PoStringToInt32(pRel->m_id.data()) == PoStringToInt32(a_strMasterRelID))
			{
				pRelativePackagePart = GetPackagePart(pRel->m_targetUri->getPath());
				break;
			}
		}

		BR_SAFE_DELETE(pRelArray);
	}

	if(pRelativePackagePart)
	{
		PackageRelationshipCollection*	pSlidesRelationships = pRelativePackagePart->m_relationships;
		BArray<PackageRelationship*>* pRelArray = pSlidesRelationships->iterator(THEME_PART_TYPE);
		if(pRelArray->size() > 0)
		{
			pRel = pRelArray->at(0);
			BR_SAFE_DELETE(pRelArray);

			if(a_strThemePath != BrNULL)
				memcpy(a_strThemePath, pRel->m_targetUri->getPath().data(), pRel->m_targetUri->getPath().length());

			return (BrCHAR*)pRel->getId().data();
		}

		BR_SAFE_DELETE(pRelArray);
	}

	return BrNULL;
}

BrCHAR* BoraPackageBase::FindThemeRelID_PPTX(BrCHAR* a_strMasterRelID, BrCHAR* a_strThemePath, BrBOOL bRecovery)
{
	BoraPackagePart* pRelativePackagePart = BrNULL;

	PackageRelationship* pRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);
	if( pRel )
	{
		BoraPackagePart* pPart = getMatchingPart(pRel);
		PackageRelationshipCollection*	pMainRelationships = pPart->m_relationships;
		BArray<PackageRelationship*>* pRelArray = pMainRelationships->iterator(SLIDE_MASTER_PART_TYPE);

		for(BrUINT32 nIndex = 0; nIndex < pRelArray->size(); nIndex++)
		{
			pRel = pRelArray->at(nIndex);
			if(PoStringToInt32(pRel->m_id.data()) == PoStringToInt32(a_strMasterRelID))
			{
				pRelativePackagePart = GetPackagePart(pRel->m_targetUri->getPath(), bRecovery);
				break;
			}
		}

		BR_SAFE_DELETE(pRelArray);
	}

	if(pRelativePackagePart)
	{
		PackageRelationshipCollection*	pSlidesRelationships = pRelativePackagePart->m_relationships;
		BArray<PackageRelationship*>* pRelArray = pSlidesRelationships->iterator(THEME_PART_TYPE);
		if(pRelArray->size() > 0)
		{
			pRel = pRelArray->at(0);
			BR_SAFE_DELETE(pRelArray);

			if(a_strThemePath != BrNULL)
				memcpy(a_strThemePath, pRel->m_targetUri->getPath().data(), pRel->m_targetUri->getPath().length());

			return (BrCHAR*)pRel->getId().data();
		}

		BR_SAFE_DELETE(pRelArray);
	}

	return BrNULL;
}

BString BoraPackageBase::GetHyperlinkName(BrCHAR* strSrcPartName, BrCHAR* strCmpStr)
{
	BrLPBYTE pImage = BrNULL;
	BoraPackagePart* pPart = GetPackagePart(strSrcPartName);
	BString strPart;
	if( pPart )
	{
		PackageRelationshipCollection*	pRelationships = pPart->m_relationships;
		//[2013.04.08][�����] slidejump������ ���� ����
		BArray<PackageRelationship*>* pLinkRelArray = pRelationships->iterator();
		PackageRelationship* pRel;
		if( pLinkRelArray )
		{
			BrINT32 nSize = pLinkRelArray->size();
			for (BrINT32 n = 0;n < nSize; n++)
			{
				pRel = pLinkRelArray->at(n);				
				if( pRel && !pRel->getId().compare(BString(strCmpStr)))
				{
					strPart = pRel->m_targetUri->getUrl();
					break;
				}
			}
			BrDELETE pLinkRelArray;
		}
	}

	return strPart;
}

BArray<PackageRelationship*>* BoraPackageBase::GetPackageRelationships( BrCHAR* strSrcPartName )
{
	BoraPackagePart* pPart = GetPackagePart(strSrcPartName);
	if ( pPart )
	{
		PackageRelationshipCollection*	pRelationships = pPart->m_relationships;
		BArray<PackageRelationship*>* pLinkRelArray = pRelationships->iteratorOrderedByID();
		return pLinkRelArray;
	}
	else
	{
		return BrNULL;
	}
}

BString BoraPackageBase::GetHyperlinkName( BArray<PackageRelationship*>* a_pLinkRelArray, BrCHAR* strCmpStr )
{
	BString strPart;
	BString strCmpString(strCmpStr);
	int nRet = BinarySearch( *a_pLinkRelArray, strCmpString );
	if ( nRet >= 0 )
	{
		strPart = a_pLinkRelArray->at( nRet )->m_targetUri->getUrl();
	}
	return strPart;
}

BrINT32 BoraPackageBase::BinarySearch( BArray<PackageRelationship*>& a_rValueArray, BString& a_rValue )
{
	int nLow	= 0;
	int nHight	= a_rValueArray.count() - 1;
	int nMid	= 0;
	int nRet	= 0;

	while ( nLow <= nHight )
	{
		nMid = ( nLow + nHight ) / 2;

		nRet = a_rValueArray.at( nMid )->getId().compare( a_rValue );

		if ( nRet == 0 )
		{
			return nMid;		// Ž�� �� ���
		}
		if ( nRet > 0 )
		{
			nHight = nMid - 1;
		}
		else // ( nRet < item )
		{
			nLow = nMid + 1;
		}
	}

	return -1;
}

//�ش� link�� Relation ID�� �̿��� real path�� ���Ѵ�.
BString BoraPackageBase::ReadLinkPath(BrCHAR* strSrcPartName, BrCHAR* pRelID, BrINT8 nPartType, BrBOOL& a_bExternal)
{
	BoraPackagePart* pPart = GetPackagePart(strSrcPartName);
	if( pPart )
	{
		PackageRelationshipCollection*	pRelationships = pPart->m_relationships;
		BArray<PackageRelationship*>* pRelArray = BrNULL;

		switch (nPartType)
		{
		case 0:
			pRelArray = pRelationships->iterator(VIDEO_PART_TYPE);
			break;
		case 1:
			pRelArray = pRelationships->iterator(AUDIO_PART_TYPE);
			break;
		case 2:
			pRelArray = pRelationships->iterator(MEDIA_PART_TYPE);
			break;
		default:
			return "";
		}
		
		if(!pRelArray)
			return "";

		//  nID �� �ش��ϴ� path �� ã�� ����.
		PackageRelationship* pRel;
		for(BrINT32 i=0; i<(BrINT32)pRelArray->size(); i++)
		{
			pRel = pRelArray->at(i);
			if( strcmp(pRel->m_id.data(), pRelID)==0 )
			{
				
				BString strPath = pRel->m_targetUri->getUrl();
				a_bExternal = (pRel->getTargetMode() == EXTERNAL) ? BrTRUE : BrFALSE;
#ifdef SUPPORT_VIDEO
				if(nPartType == 0/*VIDEO_PART_TYPE*/)
				{
					BR_SAFE_DELETE(pRelArray);
					return strPath;
				}
#endif
				if ( -1 != strPath.find("file:///") )
					strPath = strPath.right(strPath.length() - strPath.find("file:///") - BrStrLen("file:///"));

				// %���� �����ϴ� ��Ʈ���� ���� ��� 0xXX�� ����Ͽ� �ٲپ� �ش�.
				int nIndex = 0, nIdx = 0;
				while ((nIndex = strPath.find("%", nIdx)) >= 0)
				{					
					strPath.replace(nIndex, 3, BChar(BrAtoX((char*)strPath.mid(nIndex+1, 2).data())));
					nIdx = nIndex + 1;
				};
				
				BR_SAFE_DELETE(pRelArray);
				return strPath;
			}
		}
		BrDELETE pRelArray;
	}

	return "";
}

//�ش� �̹����� Relation ID�� �̿��� �̹����� �д´�.
//strPartName �� �̹����� �����ϴ� Part �� �̸� �̿��� relation���� target �� ã�´�.
BrLPBYTE BoraPackageBase::ReadBlip(BrCHAR* strSrcPartName, BrCHAR* pRelID, IMG_INFO* pImgInfo, BrBOOL bExport, BrBOOL a_bWDP, BrBOOL a_bEffect)
{
	BrLPBYTE pImage = BrNULL;
	BrINT32 nType = getDocExt();

	BArray<PackageRelationship*>* pImageRelArray = BrNULL;
	BoraPackagePart* pPart = GetPackagePart(strSrcPartName);
	if( pPart )
	{
		PackageRelationshipCollection*	pRelationships = pPart->m_relationships;
		if(a_bWDP)
			pImageRelArray = pRelationships->iterator(HDPHOTO_PART_TYPE);
		else
			pImageRelArray = pRelationships->iterator(IMAGE_PART_TYPE);

		//  nID �� �ش��ϴ� image �� ã�� ����.
		PackageRelationship* pRel;
		for(BrINT32 i=0; i<(BrINT32)pImageRelArray->size(); i++)
		{
			pRel = pImageRelArray->at(i);
			if( pRel && pRel->m_id.data() && pRelID && strcmp(pRel->m_id.data(), pRelID)==0 )
			{
				pImage = ReadImageByPartname(pRel->m_targetUri->getPath().data(), pImgInfo, bExport, a_bEffect);
				break;
			}
		}

		BrDELETE pImageRelArray;
	}

	return pImage;
}

BrLPBYTE BoraPackageBase::ReadBlip_WDP(BrCHAR* strSrcPartName, BrCHAR* pRelID, BrBOOL a_bWDP, BrBOOL a_bEffect)
{
	BrLPBYTE pImage = BrNULL;
	BArray<PackageRelationship*>* pImageRelArray = BrNULL;
	BoraPackagePart* pPart = GetPackagePart(strSrcPartName);
	if( pPart )
	{
		PackageRelationshipCollection*	pRelationships = pPart->m_relationships;
		if(a_bWDP)
			pImageRelArray = pRelationships->iterator(HDPHOTO_PART_TYPE);
		else
			pImageRelArray = pRelationships->iterator(IMAGE_PART_TYPE);

		//  nID �� �ش��ϴ� image �� ã�� ����.
		PackageRelationship* pRel;
		for(BrINT32 i=0; i<(BrINT32)pImageRelArray->size(); i++)
		{
			pRel = pImageRelArray->at(i);
			if( strcmp(pRel->m_id.data(), pRelID)==0 )
			{
				pImage = ReadImageByPartnameForWDP(pRel->m_targetUri->getPath().data(), a_bEffect);
				break;
			}
		}

		BrDELETE pImageRelArray;
	}

	return pImage;
}

PackageRelationship* BoraPackageBase::findRelationship(BoraPackagePart* a_pPart, const BrCHAR* a_szPartName, const BrCHAR* a_pRelID)
{
	if( a_pPart == BrNULL || a_pRelID == BrNULL )
		return BrNULL;

	BString strUnicodRelID(a_pRelID);
	PackageRelationship* pRelationship = a_pPart->m_relationships->binarySearchRelationship(strUnicodRelID);
	if( pRelationship )
	{
		// rID���� ������ Type�� �ٸ� ��찡 ���ٰ� �ǴܵǾ� �ּ�ó�� [6/20/2019 signous]
		//BString strUnicodPartName(a_szPartName);
		//if( !bCheckPartName || strUnicodPartName.compare( pRelationship->getRelationshipType()) == 0 )
			return pRelationship;
	}
	else
		SET_EDIT_WARNING_LOG(kPoErrImportError,"find rel fail");


	return BrNULL;
}

// 2016.02.22 [donny] : Zip���� �̹����� Ŀ�� �޸𸮿� extract�� �ȵǴ� ��� zip entry���� ���� display�� �̹����� �ε�
BrBOOL BoraPackageBase::ReadBlip_Zip(PrBitmap* pBitmap, BrCHAR* strSrcPartName, BrCHAR* pRelID, int width, int height, int ratio, PrBitmapFlag bitmapFlag, void *pInfo, BrBOOL a_bWDP)
{
	DrawTarget_Info *pTargetInfo = (DrawTarget_Info *)pInfo;
	BrINT32 nType = getDocExt();

	BrINT32 nPartIndex = -1;

	BArray<PackageRelationship*>* pImageRelArray = BrNULL;
	BoraPackagePart* pPart = GetPackagePart(strSrcPartName);
	if( pPart )
	{
		PackageRelationshipCollection*	pRelationships = pPart->m_relationships;
		if(a_bWDP)
			pImageRelArray = pRelationships->iterator(HDPHOTO_PART_TYPE);
		else
			pImageRelArray = pRelationships->iterator(IMAGE_PART_TYPE);

		//  nID �� �ش��ϴ� image �� ã�� ����.
		PackageRelationship* pRel;
		for(BrINT32 i=0; i<(BrINT32)pImageRelArray->size(); i++)
		{
			pRel = pImageRelArray->at(i);
			if( pRel && pRel->m_id.data() && pRelID && strcmp(pRel->m_id.data(), pRelID)==0 )
			{
				if( pRel->m_targetUri->getPath() )
					nPartIndex = m_pftXMLStorage->GetIndex(pRel->m_targetUri->getPath().data());
				break;
			}
		}

		BrDELETE pImageRelArray;
	}

	if( nPartIndex==-1 )
		return BrFALSE;
	return pBitmap->loadImageMiniZipYield(m_pftXMLStorage->m_oZipInfo.hZipFile, nPartIndex, width, height, ratio, bitmapFlag, pTargetInfo);
}


//[2014.04.07][TID:24813][�յ���] PPTX BrImageLoadingBase_setWDP() ������ import �۾�
//PartName�� RelID�� �޾� �ش� ������ WDP�̹����� ��� ��θ� �����Ѵ�.
BString BoraPackageBase::ReadWDPImagePath(BrCHAR* strSrcPartName, BrCHAR* pRelID)
{
	BrLPBYTE pImage = BrNULL;
	BArray<PackageRelationship*>* pImageRelArray = BrNULL;
	BoraPackagePart* pPart = GetPackagePart(strSrcPartName);
	BString strBlipPath = BrNULL;
	if( pPart )
	{
		PackageRelationshipCollection*	pRelationships = pPart->m_relationships;
		pImageRelArray = pRelationships->iterator(HDPHOTO_PART_TYPE);

		//  nID �� �ش��ϴ� image �� ã�� ����.
		PackageRelationship* pRel;
		for(BrINT32 i=0; i<(BrINT32)pImageRelArray->size(); i++)
		{
			pRel = pImageRelArray->at(i);
			if( strcmp(pRel->m_id.data(), pRelID)==0 )
			{
				strBlipPath = pRel->m_targetUri->getPath();
				break;
			}
		}

		BrDELETE pImageRelArray;
	}

	return strBlipPath;
}

//�ش� �̹����� Relation ID�� �̿��� �̹����� �д´�.
//strPartName �� �̹����� �����ϴ� Part �� �̸� �̿��� relation���� target �� ã�´�.
BrLPBYTE BoraPackageBase::ReadBlip_DOCX(BrCHAR* pRelID, IMG_INFO* pImgInfo)
{

	BrLPBYTE pImage=BrNULL;
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);
	if( pRel )
	{
		//  ppt/presentation.xml
		BoraPackagePart* pPart = getMatchingPart(pRel);
		PackageRelationshipCollection*	pRelationships = pPart->m_relationships;
		BArray<PackageRelationship*>* pImageRelArray = pRelationships->iterator(IMAGE_PART_TYPE);

		//  nID �� �ش��ϴ� image �� ã�� ����.
		PackageRelationship* pRel;
		for(BrINT32 i=0; i<(BrINT32)pImageRelArray->size(); i++)
		{
			pRel = pImageRelArray->at(i);
			if( strcmp(pRel->m_id, pRelID)==0 )
			{
				pImage = ReadImageByPartname(pRel->m_targetUri->getPath().data(), pImgInfo);
				break;
			}
		}
		BrDELETE pImageRelArray;
	}

	return pImage;
}

BrBOOL BoraPackageBase::ReadBlipInfo(BrCHAR* strSrcPartName, BrCHAR* pRelID, IMG_INFO* pImgInfo, BrCHAR* strType)
{
	BrBOOL pRet = BrFALSE;
	BoraPackagePart* pPart = GetPackagePart(strSrcPartName);
	PackageRelationship* pRelationship = findRelationship(pPart, strType, pRelID);

	if(pRelationship)
		pRet = ReadImageInfoByPartname(pRelationship->m_targetUri->getPath().data(), pImgInfo);

	return pRet;
}

#ifdef SUPPORT_URL_IMAGE
BrBOOL BoraPackageBase::ReadBlipInfoExternal(BrCHAR* strSrcPartName, BrCHAR* pRelID, BString* strExternalPath)
{
	BrBOOL bExternalFlagRet = BrFALSE;
	BoraPackagePart* pPart = GetPackagePart(strSrcPartName);
	if( pPart )
	{
		PackageRelationshipCollection*	pRelationships = pPart->m_relationships;
		BArray<PackageRelationship*>* pImageRelArray = pRelationships->iterator(IMAGE_PART_TYPE);

		//  nID �� �ش��ϴ� image �� ã�� ����.
		PackageRelationship* pRel;
		for(BrINT32 i=0; i<(BrINT32)pImageRelArray->size(); i++)
		{
			pRel = pImageRelArray->at(i);
			if( strcmp(pRel->m_id.data(), pRelID)==0 )
			{
				if(pRel->m_targetMode)	bExternalFlagRet = BrTRUE;								
				*strExternalPath = pRel->m_targetUri->getUrl();
				break;
			}
		}
		BrDELETE pImageRelArray;
	}
	return bExternalFlagRet;
}
#endif
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//2007-01
BrINT32 BoraPackageBase::getInternalFileType(LPCallbackParam pCallbackParam)
{
	BrINT32	nDoctype = BORA_DOCTYPE_NONE;
	if(!m_relationships)
	{BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);		
		return nDoctype;
	}

	PackageRelationship* pRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);
	if( pRel )
	{
		BTrace("%s(%d) %s pRel->m_targetUri->getPath().data()[%s]", __FILE__, __LINE__, __FUNCTION__, pRel->m_targetUri->getPath().data());		
		if( 0 == strcmp(pRel->m_targetUri->getPath().data(), "ppt/presentation.xml"))
			return BORA_DOCTYPE_PPTX;
		else if( 0 == strncmp(pRel->m_targetUri->getPath().data(), "word/document", 13))
			return BORA_DOCTYPE_DOCX;
		else if( 0 == strcmp(pRel->m_targetUri->getPath().data(), "xl/workbook.xml"))
			return BORA_DOCTYPE_XLSX;
		else if (0 == strcmp(pRel->m_targetUri->getPath().data(), "theme/theme/themeManager.xml"))
			return BORA_DOCTYPE_THMX;
		else
			return BORA_DOCTYPE_NONE;
	}
	else
	{
		pRel = m_relationships->relationshipsByType_get(STRICT_OPENXML_PART_TYPE);
		if (pRel)
			return BORA_DOCTYPE_STRICT;
	}
BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);		
	return nDoctype;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifdef USE_INFRAWARE_CUSTOM_XML
BrBOOL BoraPackageBase::ReadInfrawareCustomInfo(LPCallbackParam pCallbackParam)
{
	BrBOOL	bRet = BrTRUE;
	if (!m_relationships)
		return BrFALSE;
	
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(INFRAWARE_CUSTOM_PART_TYPE);
	if (pRel)
	{
		BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
		if (ReadPackageByPartname(pPartName->getName().data(), pCallbackParam))
			bRet = BrTRUE;
		BrDELETE pPartName;
	}

	return bRet;
}
#endif

BrBOOL BoraPackageBase::ReadMainTheme_XLSX(LPCallbackParam pCallbackParam)
{
	BrBOOL	bRet = BrFALSE;
	if(!m_relationships)
	{
		SET_ERROR((PoError)kPoErrCorruptFile, "");
		return BrFALSE;		//[2011.08.17][�̻�] null check 
	}

	PackageRelationship* pRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);
	if( pRel )
	{
		BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
		if( !(pPartName->getName().contains("workbook.xml") || pPartName->getName().contains("themeManager.xml")) )	//[OFF-211][2014-11-04][sohyunhwnag]�ٸ� format�� ������ Ȯ���ڸ� ���� ��ȯ�Ͽ� open �� crash �߻��Ͽ� ����
		{
			SET_ERROR((PoError)kPoErrCorruptFile, "");
			BrDELETE pPartName;
			return BrFALSE;
		}

		if( ReadPackageByPartname(pPartName->getName().data(), pCallbackParam) )
			bRet = BrTRUE;
		BrDELETE pPartName;

		BoraPackagePart* pPart = getMatchingPart(pRel);

		if (pPart)
		{
			PackageRelationshipCollection*	pMainDocRelationships = pPart->m_relationships;
			BArray<PackageRelationship*>* pBookRelArray = pMainDocRelationships->iterator(THEME_PART_TYPE);

			if (pBookRelArray->size() > 0)
			{
				pRel = pBookRelArray->at(0);

				BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
				BrBOOL bExistPart = (m_partList->get(pPartName)!=BrNULL);
				if( !bExistPart )
					getPart(pPartName);//�̷��� �ϸ� �ش� slide �� relation ���� �鵵 ���� ������.

				bRet = ReadPackageByPartname(pPartName->getName().data(), pCallbackParam);

				if( bExistPart )
					BrDELETE pPartName;
			}
			BR_SAFE_DELETE(pBookRelArray);


			BArray<PackageRelationship*>* pPersonsArray = pMainDocRelationships->iterator(PERSONS_PART_TYPE);
			if (pPersonsArray->size() > 0)
			{
				pRel = pPersonsArray->at(0);

				BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
				BrBOOL bExistPart = (m_partList->get(pPartName)!=BrNULL);
				if( !bExistPart )
					getPart(pPartName);//�̷��� �ϸ� �ش� slide �� relation ���� �鵵 ���� ������.

				bRet = ReadPackageByPartname(pPartName->getName().data(), pCallbackParam);

				if( bExistPart )
					BrDELETE pPartName;
			}
			BR_SAFE_DELETE(pPersonsArray);

		}
	}

	return bRet;
}

#ifdef XLSX_DATA_CONNECTION
BrBOOL BoraPackageBase::ReadWorkBook_XLSX(LPCallbackParam pCallbackParam)
{
	BrBOOL bRet = BrFALSE;

	if(!m_relationships)
		return BrFALSE;

	PackageRelationship* pRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);
	if( pRel )
	{
		BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
		if( !(pPartName->getName().contains("workbook.xml") || pPartName->getName().contains("themeManager.xml")) )
		{
			BrDELETE pPartName;
			return BrFALSE;
		}

		if( ReadPackageByPartname(pPartName->getName().data(), pCallbackParam) )
			bRet = BrTRUE;
		BrDELETE pPartName;

		BoraPackagePart* pPart = getMatchingPart(pRel);
		PackageRelationshipCollection*	pMainDocRelationships = pPart->m_relationships;
		BArray<PackageRelationship*>* pBookRelArray = pMainDocRelationships->iterator(CONNECTIONS_PART_TYPE);

		if (pBookRelArray && pBookRelArray->size() > 0)
		{
			pRel = pBookRelArray->at(0);
			BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
			BrBOOL bExistPart = (m_partList->get(pPartName)!=BrNULL);
			if( !bExistPart )
				getPart(pPartName);//�̷��� �ϸ� �ش� slide �� relation ���� �鵵 ���� ������.
			bRet = ReadPackageByPartname(pPartName->getName().data(), pCallbackParam);
			if( bExistPart )
				BrDELETE pPartName;
		}

		BR_SAFE_DELETE(pBookRelArray);

	}

	return bRet;
}

//#ifdef USE_SHEET_INTERFACE
//BrBOOL BoraPackageBase::ReadRecursiveConnection_XLSX(LPCallbackParam pCallbackParam)
//{
//	BrBOOL bRet = BrFALSE;
//
//	if(!m_relationships)
//		return BrFALSE;
//
//	PackageRelationship* pRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);
//	if( pRel )
//	{
//		xlsBook* pBook = afxGetXlsFrame()->book();
//		xlsRecursiveContainer* pRecursiveContainer = ((xlsxBook*)pBook)->getRecursiveContainer();
//		CallbackParam	param;
//
//		BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
//		if( !(pPartName->getName().contains("workbook.xml") || pPartName->getName().contains("themeManager.xml")) )
//			return BrFALSE;
//
//
//		xlsDefinedNameRecursive* pDefinedNameRecursive = BrNEW xlsDefinedNameRecursive();
//		memset(&param, 0, BrSizeOf(CallbackParam));
//		param.pCurrentInstance = pDefinedNameRecursive;
//
//		if( ReadPackageByPartname(pPartName->getName().data(), &param) )
//			bRet = BrTRUE;
//		pRecursiveContainer->setArrDefinedNameRecursive(pDefinedNameRecursive);
//		BrDELETE pPartName;
//
//		BoraPackagePart* pPart = getMatchingPart(pRel);
//		PackageRelationshipCollection*	pMainDocRelationships = pPart->m_relationships;
//		BArray<PackageRelationship*>* pBookRelArray = pMainDocRelationships->iterator(CONNECTIONS_PART_TYPE);
//
//		if (pBookRelArray->size() > 0)
//		{
//			pRel = pBookRelArray->at(0);
//			BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
//			BrBOOL bExistPart = (m_partList->get(pPartName)!=BrNULL);
//			if( !bExistPart )
//				getPart(pPartName);//�̷��� �ϸ� �ش� slide �� relation ���� �鵵 ���� ������.
//			xlsDataConnectionRecursives* pConnectionRecursives = BrNEW xlsDataConnectionRecursives();
//			
//			memset(&param, 0, BrSizeOf(CallbackParam));
//			param.pCurrentInstance = pConnectionRecursives;
//			pRecursiveContainer->setArrDataConnections(pConnectionRecursives);
//			bRet = ReadPackageByPartname(pPartName->getName().data(), &param);
//			if( bExistPart )
//				BrDELETE pPartName;
//		}
//
//	
//
//	//===========
//		BrINT32 i;
//		PackageRelationship* pRel;
//		//  xl/_rels/workbook.xml.rels
//		pMainDocRelationships = pPart->m_relationships;
//
//		//  xl/_rels/workbook.xml.rels ���� WORKSHEET_PART_TYPE �� �ش��ϴ� relationship ã��
//		pBookRelArray = pMainDocRelationships->iterator(WORKSHEET_PART_TYPE);
//
//		for(i=0; i<(BrINT32)pBookRelArray->size(); i++)
//		{
//			pRel = pBookRelArray->at(i);
//// 			if (nID != BrNULL && strcmp(pRel->m_id.data(), nID)==0)
//// 			{
//				//  sheet?.xml
//				BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
//				PackagePartItem* pSheetParkItem = m_partList->get(pPartName);
//				BoraPackagePart* pSheetPart = NULL;
//				if (pSheetParkItem)
//					pSheetPart = pSheetParkItem->m_pPackagePart;
//				else
//					pSheetPart = getPart(pPartName);//�̷��� �ϸ� �ش� sheet �� relation ���� �鵵 ���� ������.
//
//				//sheet �� ���õ� part �� �о� �鿩�� ��.
//
//
//				//[2011.08.03][�̻�][TID:1434] 
//				PackageRelationship* pSheetRelationship;
//				PackageRelationshipCollection*	pSheetRelationships = pSheetPart->m_relationships;
//				BArray<PackageRelationship*>* pSheetRelArray = BrNULL;
//
//				if (pSheetPart)	//[sohyunhwang] table Importer �߰�
//				{	
//					pSheetRelArray = pSheetRelationships->iterator(TABLE_PART_TYPE);
//
//					for(BrINT32 i=0; i<(BrINT32)pSheetRelArray->size(); i++)
//					{
//						pSheetRelationship = pSheetRelArray->at(i);
//						BoraPackagePartName* pTablePartName = PackagingURIHelper::createPartName(pSheetRelationship->m_targetUri->getPath().data());
//						//ReadPackageByPartname(pTablePartName->getName().data(), pCallbackParam);
//			
//						PackagePartItem* pTablePartItem = m_partList->get(pTablePartName);
//						BoraPackagePart* pTablePart = NULL;
//						if (pTablePartItem)
//							pTablePart = pTablePartItem->m_pPackagePart;
//						else
//							pTablePart = getPart(pTablePartName);
//
//						PackageRelationship* pTableRelationship;
//						PackageRelationshipCollection*	pTableRelationships = pTablePart->m_relationships;
//						BArray<PackageRelationship*>* pTableRelArray = BrNULL;
//
//						if (pTablePart)	//[kjins1201] QueryTable Rel import �߰�
//						{	
//							pTableRelArray = pTableRelationships->iterator(QUERYTABLE_PART_TYPE);
//
//							for(BrINT32 j=0; j<(BrINT32)pTableRelArray->size(); j++)
//							{
//								pTableRelationship = pTableRelArray->at(j);
//								BoraPackagePartName* pQueryPartName = PackagingURIHelper::createPartName(pTableRelationship->m_targetUri->getPath().data());
//// 								xlsBook* pBook = BrNULL;
//// 								if(afxGetXlsFrame()->book()->getTmpTable())
//// 									pBook = afxGetXlsFrame()->book();
//// 								else 
//// 									break;
//// 								xlsQueryTable* pQueryTable = BrNEW xlsQueryTable();//(/*afxGetXlsFrame()->book()->getTmpTable()*/);
//// 
//// 								//import �� table ���� queryTable�� ���� �� ���� table ���� �� tablecontainer�� queryTable �߰�
//// 								pQueryTable->setTableInfo(pBook->getTmpTable());
//// 								pQueryTable->addTable();
//								CallbackParam	param;
//								memset(&param, 0, BrSizeOf(CallbackParam));
//								xlsQueryTableRecursive* pQueryTableRecursive = BrNEW xlsQueryTableRecursive();
//								param.pCurrentInstance = pQueryTableRecursive;
//
//								pRecursiveContainer->getArrQueryTable().Add(pQueryTableRecursive);
//
//
//// 								CallbackParam	param;
//// 								memset(&param, 0, BrSizeOf(CallbackParam));
//// 								param.pCurrentInstance = pQueryTable;
//								ReadPackageByPartname(pQueryPartName->getName().data(), &param);
//								afxGetXlsFrame()->book()->setTmpTable(BrNULL);
//								BrDELETE pQueryPartName;
//							}
//						}
//						BrDELETE pTableRelArray;
//					}
//					BrDELETE pSheetRelArray;
//				}
////			}
//		}
//		BrDELETE pBookRelArray;
//	}
//	return bRet;
//}
//
//BrBOOL BoraPackageBase::ReadSSTSheet_XLSX(LPCallbackParam pCallbackParam, BString a_strRId)
//{
//	BrBOOL	bRet = BrFALSE;
//	if(!m_relationships)
//		return BrFALSE;		//[2011.08.17][�̻�] null check 
//	PackageRelationship* pRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);
//	if( pRel )
//	{
//		
//
//		BoraPackagePart* pPart = getMatchingPart(pRel);
//
//		if (pPart)
//		{
//			PackageRelationshipCollection*	pMainDocRelationships = pPart->m_relationships;
//			BArray<PackageRelationship*>* pBookRelArray = pMainDocRelationships->iterator(SHARED_STRING_PART_TYPE);
//
//			if (pBookRelArray->size() > 0)
//			{
//				pRel = pBookRelArray->at(0);
//				BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
//				BrBOOL bExistPart = (m_partList->get(pPartName)!=BrNULL);
//				if( !bExistPart )
//					getPart(pPartName);//�̷��� �ϸ� �ش� slide �� relation ���� �鵵 ���� ������.
//
//				bRet = ReadPackageByPartname(pPartName->getName().data(), pCallbackParam);
//
//				if( bExistPart )
//					BrDELETE pPartName;
//			}
//			
//			pBookRelArray = pMainDocRelationships->iterator(WORKSHEET_PART_TYPE);
//			if (pBookRelArray->size() > 0)
//			{
//				for(int i = 0 ; i < pBookRelArray->size() ; i++)
//				{
//					pRel = pBookRelArray->at(i);
//					if(pRel->getId() == a_strRId)
//						break;
//				}
//				xlsBook* pBook = ((xlsFrame*)afxGetXlsFrame())->book();
//				xlsDataConnectionContainer* pContainer = pBook->getDataConnectionContainer();
//
//				BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
//				BrBOOL bExistPart = (m_partList->get(pPartName)!=BrNULL);
//				if( !bExistPart )
//					getPart(pPartName);//�̷��� �ϸ� �ش� slide �� relation ���� �鵵 ���� ������.
//
//				bRet = ReadPackageByPartname(pPartName->getName().data(), pCallbackParam);
//
//				if( bExistPart )
//					BrDELETE pPartName;
//			}
//
//			BR_SAFE_DELETE(pBookRelArray);
//		}
//	}
//
//	return bRet;
//}
//#endif //#ifndef USE_SHEET_INTERFACE

#endif
BrBOOL BoraPackageBase::ReadMainTheme_XLSX(cmXMLDomMgr* a_pDOMmgr)
{
	BrBOOL	bRet = BrFALSE;
	if(!m_relationships)
		return BrFALSE;		//[2011.08.17][�̻�] null check 
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);
	if( pRel )
	{
		BoraPackagePart* pPart = getMatchingPart(pRel);
		if (pPart)
		{
			PackageRelationshipCollection*	pMainDocRelationships = pPart->m_relationships;
			BArray<PackageRelationship*>* pBookRelArray = pMainDocRelationships->iterator(THEME_PART_TYPE);

			if (pBookRelArray->size() > 0)
			{
				pRel = pBookRelArray->at(0);

				BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
				BrBOOL bExistPart = (m_partList->get(pPartName)!=BrNULL);
				if( !bExistPart )
					getPart(pPartName);//�̷��� �ϸ� �ش� slide �� relation ���� �鵵 ���� ������.

				AddPackagePart(pRel->m_targetUri->getPath());
				bRet = MakeDomTree(a_pDOMmgr, pRel);

				if( bExistPart )
					BrDELETE pPartName;
			}
			BR_SAFE_DELETE(pBookRelArray);
		}
	}
	return bRet;
}

BrBOOL BoraPackageBase::ReadExternalLink_XLSX(LPCallbackParam pCallbackParam, BString* nRID)
{
	BrBOOL	bRet = BrFALSE;
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);
	if( pRel )
	{
		BoraPackagePart* pPart = getMatchingPart(pRel);
		//  xl/_rels/workbook.xml.rels
		PackageRelationshipCollection*	pMainDocRelationships = pPart->m_relationships;
		
		//  xl/_rels/workbook.xml.rels ���� SLIDE_PART_TYPE �� �ش��ϴ� relationship ã��
		BArray<PackageRelationship*>* pBookRelArray = pMainDocRelationships->iterator(EXTERNAL_LINK_PART_TYPE);

		int size = pBookRelArray->size();
		for(BrINT32 i=0; i<(BrINT32)size; i++)
		{
			pRel = pBookRelArray->at(i);
			if (strcmp(pRel->m_id.data(), nRID->data())==0 )
			{
				BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
				BrBOOL bExistPart = (m_partList->get(pPartName)!=BrNULL);
				if( !bExistPart )
					getPart(pPartName);//�̷��� �ϸ� �ش� slide �� relation ���� �鵵 ���� ������.
				bRet = ReadPackageByPartname(pPartName->getName().data(), pCallbackParam);
				if( bExistPart )
					BrDELETE pPartName;
			}
		}
		BrDELETE pBookRelArray;
	}

	return bRet;
}

BrBOOL BoraPackageBase::ReadStyle_XLSX(LPCallbackParam pCallbackParam)
{
	BrBOOL	bRet = BrTRUE;
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);
	if( pRel )
	{
		BoraPackagePart* pPart = getMatchingPart(pRel);

		if (pPart)
		{
			PackageRelationshipCollection*	pMainDocRelationships = pPart->m_relationships;
			BArray<PackageRelationship*>* pBookRelArray = pMainDocRelationships->iterator(STYLES_PART_TYPE);

			if (pBookRelArray->size() > 0)
			{
				pRel = pBookRelArray->at(0);
				BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
				BrBOOL bExistPart = (m_partList->get(pPartName)!=BrNULL);
				if( !bExistPart )
					getPart(pPartName);
				bRet = ReadPackageByPartname(pPartName->getName().data(), pCallbackParam);
				if( bExistPart )
					BrDELETE pPartName;

				if (!bRet)
				{
					BrDELETE pBookRelArray;
					return BrFALSE;
				}
			}
			BrDELETE pBookRelArray;
		}
	}
	return bRet;
}

BrBOOL BoraPackageBase::ReadSST_XLSX(LPCallbackParam pCallbackParam)
{
	BrBOOL	bRet = BrTRUE;
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);
	if( pRel )
	{
		BoraPackagePart* pPart = getMatchingPart(pRel);

		if (pPart)
		{
			PackageRelationshipCollection*	pMainDocRelationships = pPart->m_relationships;
			BArray<PackageRelationship*>* pBookRelArray = pMainDocRelationships->iterator(SHARED_STRING_PART_TYPE);

			if (pBookRelArray->size() > 0)
			{
				pRel = pBookRelArray->at(0);
				BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
				BrBOOL bExistPart = (m_partList->get(pPartName)!=BrNULL);
				if( !bExistPart )
					getPart(pPartName);
				bRet = ReadPackageByPartname(pPartName->getName().data(), pCallbackParam);
				if( bExistPart )
					BrDELETE pPartName;
			}
			BrDELETE pBookRelArray;
		}
	}
	return bRet;
}
#ifdef XLSX_DATA_CONNECTION
BrBOOL BoraPackageBase::ReadDataConnection_XLSX(LPCallbackParam pCallbackParam)
{
	BrBOOL	bRet = BrTRUE;
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);
	if( pRel )
	{
		BoraPackagePart* pPart = getMatchingPart(pRel);

		if (pPart)
		{
			PackageRelationshipCollection*	pMainDocRelationships = pPart->m_relationships;
			BArray<PackageRelationship*>* pBookRelArray = pMainDocRelationships->iterator(CONNECTIONS_PART_TYPE);

			if (pBookRelArray->size() > 0)
			{
				pRel = pBookRelArray->at(0);
				BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
				BrBOOL bExistPart = (m_partList->get(pPartName)!=BrNULL);
				if( !bExistPart )
					getPart(pPartName);
				bRet = ReadPackageByPartname(pPartName->getName().data(), pCallbackParam);
				if( bExistPart )
					BrDELETE pPartName;
			}
			BR_SAFE_DELETE(pBookRelArray);
		}
	}
	return bRet;
}
#endif //XLSX_DATA_CONNECTION


//[2012.05.23][���缱][TID:5456] PivotTable Importer �߰�
BrBOOL BoraPackageBase::ReadPivotCacheDefinition_XLSX(LPCallbackParam pCallbackParam, BString a_strRelationship)
{
	//_rels/.rels���� CORE_DOCUMENT_PART_TYPE�� �ش��ϴ� �κ� ã��
	PackageRelationship* pWorkBookRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);//#define CORE_DOCUMENT_PART_TYPE "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument"
	if( pWorkBookRel == BrNULL )
		return BrFALSE;

	BoraPackagePart* pWorkBookPart = getMatchingPart(pWorkBookRel);
	if( pWorkBookPart == BrNULL )
		return BrFALSE;

	//pWorkBookRel�� _rel���� ���� workbook.xml.rels������.
	PackageRelationshipCollection* pPackageRelationshipCollection = pWorkBookPart->m_relationships;
	if(pPackageRelationshipCollection == BrNULL )
		return BrFALSE;

	//////////////////PCD ����//////////////////
	//xl/_rels/workbook.xml.rels���� PIVOTCACHEDEFINITION_PART_TYPE�� �ش��ϴ� �κп� ���ؼ� ã�Ƽ� Array�� ����
	BArray<PackageRelationship*>* pPCDRelArray = pPackageRelationshipCollection->iterator(PIVOTCACHEDEFINITION_PART_TYPE);//#define PIVOTCACHEDEFINITION_PART_TYPE "http://schemas.openxmlformats.org/officeDocument/2006/relationships/pivotCacheDefinition"
	PackageRelationship* pPCDRel = BRNULL;
	bool bFind = BrFalse;
	for( int i = 0; i < pPCDRelArray->size(); i++ )
	{
		pPCDRel = pPCDRelArray->at(i);
		if( pPCDRel->m_id == a_strRelationship )
		{
			bFind = BrTRUE;
			break;
		}
	}
	BR_SAFE_DELETE(pPCDRelArray);
	if( bFind == BrFalse )
		return BrFalse;
	
	PackagePartItem* pPCDPartItem = m_partList->Get(pPCDRel->m_targetUri->getPath());//�̹� ��������ִ��� �ߺ��˻�
	if( pPCDPartItem == BRNULL )//������ �Ʒ� �� �Լ����� Name�� Part�� �������ְ�, m_partList�� ���ԵǸ鼭 PartItem�� ������� 
	{
		BoraPackagePartName* pPCDPartName = PackagingURIHelper::createPartName(pPCDRel->m_targetUri->getPath().data());
		BoraPackagePart* pPCDPart = BrNEW BoraPackagePart(this, pPCDPartName, m_contentTypeManager->getContentType(pPCDPartName));
		
		pPCDPartItem = m_partList->put(pPCDPartName, pPCDPart);//�߰������� �ε��� ��� PCD�� ���߿� ���� �� ���� �� �� ������, PO�� �ϴ��� ���� ���� �� �а� �Ǿ��ִ�.
	}
	
	//PCD Import
	if( ReadPackageByPartname(pPCDPartItem->m_pPackagePartName->getName().data(), pCallbackParam) == BrFalse )
		return BrFalse;
	//////////////////PCD ����//////////////////


	PackageRelationshipCollection* pPCDRelCollection = pPCDPartItem->m_pPackagePart->m_relationships;
	//xl/pivotCache/_rels/pivotCacheDefinition$.xml.rels�� �ִ��� üũ
	if( pPCDRelCollection == NULL )
		return BrFalse;


	//////////////////PCR ����//////////////////
	//xl/pivotCache/_rels/pivotCacheDefinition$.xml.rels���� PIVOTCACHERECORD_PART_TYPE�� �ش��ϴ� �κп� ���ؼ� ã�Ƽ� Array�� ����
	BArray<PackageRelationship*>* pPCRRelArray = pPCDRelCollection->iterator(PIVOTCACHERECORD_PART_TYPE);//#define PIVOTCACHERECORD_PART_TYPE "http://schemas.openxmlformats.org/officeDocument/2006/relationships/pivotCacheRecords"
	PackageRelationship* pPCRRel = BRNULL;
	if( pPCRRelArray->size() > 0 ) //[owen]PCR�� 0�� �Ǵ� 1�� �ۿ� ���� ������ (External Sheet�� Ȯ�� �κ� ã������ ���� ������ �ʿ��ϳ�)
	{
		pPCRRel = pPCRRelArray->at(0);
	}
	BR_SAFE_DELETE(pPCRRelArray);

	if( pPCRRel == BRNULL)
		return BrTRUE;//PCD�� PCR�� �����ϴ� ��쵵 �ְ� ���� ��쵵 �ֱ� ������

#if 0//[owen] PCR�� Relation�� ������ pPCRPartItem�� �ʿ��� ���� ����. ������ ���ӵ� ���� ���� ��쿡 �ڵ� ������ ���� �ۼ���.
	PackagePartItem* pPCRPartItem = m_partList->Get(pPCRRel->m_targetUri->getPath());//�̹� ��������ִ��� �ߺ��˻�[�߰������� �ε��� ��� �ߺ� Ȯ���Ϸ���]
	if( pPCRPartItem == BRNULL )//������ �Ʒ� �� �Լ����� Name�� Part�� �������ְ�, m_partList�� ���ԵǸ鼭 PartItem�� ������� 
	{
		BoraPackagePartName* pPCRPartName = PackagingURIHelper::createPartName(pPCRRel->m_targetUri->getPath().data());
		BoraPackagePart* pPCRPart = BrNEW BoraPackagePart(this, pPCRPartName, m_contentTypeManager->getContentType(pPCRPartName));

		pPCRPartItem = m_partList->put(pPCRPartName, pPCRPart);
	}

	//PCR Import
	if( ReadPackageByPartname(pPCRPartItem->m_pPackagePartNamertName->getName().data(), pCallbackParam) == BrFalse )
		return BrFalse;
#else
	if( ReadPackageByPartname(pPCRRel->m_targetUri->getPath(), pCallbackParam) == BrFalse )
		return BrFalse;
#endif
	//////////////////PCR ����//////////////////


	return BrTRUE;
}


BrBOOL BoraPackageBase::SheetInkMLReadPart(LPCallbackParam a_pCallbackParam, BString a_strMainRelType, BString a_strRelType, BrCHAR* a_pID)
{
	BrBOOL bRet = BrFALSE;

	//.rels ���� a_strMainRelType �ش��ϴ� relationship ã��

	//if( pRel )
	{
		BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(a_strMainRelType);
		//BrBOOL bExistPart = (m_partList->get(pPartName)!=BrNULL);

		BoraPackagePart* pPart = getPart(pPartName);
		PackageRelationship* pRel = BrNULL;
		if (pPart)
		{

			PackageRelationshipCollection*	pMainDocRelationships = pPart->m_relationships;
			BArray<PackageRelationship*>* pRelArray = pMainDocRelationships->iterator(a_strRelType);

			if(pRelArray->size() > 0)
			{
				if(a_pID)
				{
					//a_pID �� �ش��ϴ� a_strRelType�� ã�� ����
					for(BrUINT32 nIndex = 0; nIndex < pRelArray->size(); nIndex++)
					{
						pRel = pRelArray->at(nIndex);
						if(!strcmp(pRel->m_id.data(), a_pID))
							bRet = ReadPartName(a_pCallbackParam, pRel);
					}
				}
				else
				{
					pRel = pRelArray->at(0);
					bRet = ReadPartName(a_pCallbackParam, pRel);
				}
			}
			BR_SAFE_DELETE(pRelArray);
		}
	}

	return bRet;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


BrBOOL BoraPackageBase::SlideInkMLReadPart(LPCallbackParam a_pCallbackParam, BString a_strMainRelType, BString a_strRelType, BrCHAR* a_pID)
{
	BrBOOL bRet = BrFALSE;

	//.rels ���� a_strMainRelType �ش��ϴ� relationship ã��

	//if( pRel )
	{
		BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(a_strMainRelType);
		BrBOOL bExistPart = (m_partList->get(pPartName)!=BrNULL);

		BoraPackagePart* pPart = getPart(pPartName);
		PackageRelationship* pRel = BrNULL;
		if (pPart)
		{

			PackageRelationshipCollection*	pMainDocRelationships = pPart->m_relationships;
			BArray<PackageRelationship*>* pRelArray = pMainDocRelationships->iterator(a_strRelType);

			if(pRelArray->size() > 0)
			{
				if(a_pID)
				{
					//a_pID �� �ش��ϴ� a_strRelType�� ã�� ����
					for(BrUINT32 nIndex = 0; nIndex < pRelArray->size(); nIndex++)
					{
						pRel = pRelArray->at(nIndex);
						if(!strcmp(pRel->m_id.data(), a_pID))
							bRet = ReadPartName(a_pCallbackParam, pRel);
					}
				}
				else
				{
					pRel = pRelArray->at(0);
					bRet = ReadPartName(a_pCallbackParam, pRel);
				}
			}
			BR_SAFE_DELETE(pRelArray);
		}
	}

	return bRet;
}

BrBOOL BoraPackageBase::GetSlideEmbeddedFontData(ptxEmbeddedFont* a_pFont)
{
	if(a_pFont == BrNULL)
		return BrFALSE;
#ifdef IMPORT_PPTX
	//common���� bwp�� ȣ���� ���� Ȯ�� �ʿ�
	//.rels ���� CORE_DOCUMENT_PART_TYPE �� �ش��ϴ� relationship ã��
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);

	if(pRel)
	{
		//  ppt/presentation.xml
		BoraPackagePart* pPart = getMatchingPart(pRel);

		//  ppt/_rels/presentation.xml.rels
		PackageRelationshipCollection*	pMainDocRelationships = pPart->m_relationships;

		//  ppt/_rels/presentation.xml.rels ���� FONT_PART_TYPE �� �ش��ϴ� relationship ã��
		BArray<PackageRelationship*>* pSlideEFontRelArray = pMainDocRelationships->iterator(FONT_PART_TYPE);

		//  nID �� �ش��ϴ� slide �� ã�� ����.
		for(BrINT32 i=0; i<(BrINT32)pSlideEFontRelArray->size(); i++)
		{
			pRel = pSlideEFontRelArray->at(i);

			if(a_pFont->m_pRegularRID != BrNULL && strcmp(pRel->m_id.data(), a_pFont->m_pRegularRID)==0)
			{
				BrLPBYTE pData = BrNULL;
				BrINT nLen = m_pftXMLStorage->GetZipItemStream(pRel->m_targetUri->getPath().data(), pData);
				a_pFont->SetRegularFontData(pData, nLen);
				BR_SAFE_FREE(pData);
			}
			else if(a_pFont->m_pBoldRID != BrNULL && strcmp(pRel->m_id.data(), a_pFont->m_pBoldRID)==0)
			{
				BrLPBYTE pData = BrNULL;
				BrINT nLen = m_pftXMLStorage->GetZipItemStream(pRel->m_targetUri->getPath().data(), pData);
				a_pFont->SetBoldFontData(pData, nLen);
				BR_SAFE_FREE(pData);
			}
			else if(a_pFont->m_pItalicRID != BrNULL && strcmp(pRel->m_id.data(), a_pFont->m_pItalicRID)==0)
			{
				BrLPBYTE pData = BrNULL;
				BrINT nLen = m_pftXMLStorage->GetZipItemStream(pRel->m_targetUri->getPath().data(), pData);
				a_pFont->SetItalicFontData(pData, nLen);
				BR_SAFE_FREE(pData);
			}
			else if(a_pFont->m_pBoldItalicRID != BrNULL && strcmp(pRel->m_id.data(), a_pFont->m_pBoldItalicRID)==0)
			{
				BrLPBYTE pData = BrNULL;
				BrINT nLen = m_pftXMLStorage->GetZipItemStream(pRel->m_targetUri->getPath().data(), pData);
				a_pFont->SetBoldItalicFontData(pData, nLen);
				BR_SAFE_FREE(pData);
			}
		}
		
		BrDELETE pSlideEFontRelArray;
	}

	return BrTRUE;
#endif
	return BrFALSE;
}

BrBOOL BoraPackageBase::CheckReadOnlyFontData()
{
	Painter* pPainter = getPainter();
	BrDC* pDC = BrNULL;
	BFont* pBFont = BrNULL;

	if(pPainter)
		pDC= pPainter->pDC;
	else
		return BrFALSE;

	if(pDC)
		pBFont = pDC->m_pDCFont;
	else
		return BrFALSE;

	//.rels ���� CORE_DOCUMENT_PART_TYPE �� �ش��ϴ� relationship ã��
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);

	if(pRel)
	{
		//  ppt/presentation.xml
		BoraPackagePart* pPart = getMatchingPart(pRel);

		//  ppt/_rels/presentation.xml.rels
		PackageRelationshipCollection*	pMainDocRelationships = pPart->m_relationships;

		//  ppt/_rels/presentation.xml.rels ���� FONT_PART_TYPE �� �ش��ϴ� relationship ã��
		BArray<PackageRelationship*>* pSlideEFontRelArray = pMainDocRelationships->iterator(FONT_PART_TYPE);

		//  nID �� �ش��ϴ� slide �� ã�� ����.
		for(BrINT32 i=0; i<(BrINT32)pSlideEFontRelArray->size(); i++)
		{
			pRel = pSlideEFontRelArray->at(i);

			BrLPBYTE pData = BrNULL;

			BrINT nLen = m_pftXMLStorage->GetZipItemStream(pRel->m_targetUri->getPath().data(), pData);

			if(pBFont->GetPermission(pData, nLen) == PREVIEW_PRINTEMBEDDING)
			{
				BR_SAFE_FREE(pData);
				return BrTRUE;
			}

			BR_SAFE_FREE(pData);
		}

		BR_SAFE_DELETE(pSlideEFontRelArray);
	}

	return BrFALSE;
}

//#ifdef USE_SHEET_INTERFACE
//BrBOOL BoraPackageBase::ReadSheetRelationship(LPCallbackParam pCallbackParam, BoraPackagePart* pPart, BrCHAR* lpPartType, BrCHAR* nID)
//{
//	BrINT32 i;
//	PackageRelationship* pRel;
//	//  xl/_rels/workbook.xml.rels
//	PackageRelationshipCollection*	pMainDocRelationships = pPart->m_relationships;
//
//	//  xl/_rels/workbook.xml.rels ���� WORKSHEET_PART_TYPE �� �ش��ϴ� relationship ã��
//	BArray<PackageRelationship*>* pBookRelArray = pMainDocRelationships->iterator(lpPartType);
//
//	for(i=0; i<(BrINT32)pBookRelArray->size(); i++)
//	{
//		pRel = pBookRelArray->at(i);
//		if (nID != BrNULL && strcmp(pRel->m_id.data(), nID)==0)
//		{
//			//  sheet?.xml
//			BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
//			PackagePartItem* pSheetParkItem = m_partList->get(pPartName);
//			BoraPackagePart* pSheetPart = NULL;
//			if (pSheetParkItem)
//				pSheetPart = pSheetParkItem->m_pPackagePart;
//			else
//				pSheetPart = getPart(pPartName);//�̷��� �ϸ� �ش� sheet �� relation ���� �鵵 ���� ������.
//
//			//sheet �� ���õ� part �� �о� �鿩�� ��.
//
//
//			//[2011.08.03][�̻�][TID:1434] 
//			PackageRelationship* pSheetRelationship;
//			PackageRelationshipCollection*	pSheetRelationships = pSheetPart->m_relationships;
//			BArray<PackageRelationship*>* pSheetRelArray = BrNULL;
//
//			if (pSheetPart)	//[sohyunhwang] table Importer �߰�
//			{	
//				pSheetRelArray = pSheetRelationships->iterator(TABLE_PART_TYPE);
//
//				for(BrINT32 i=0; i<(BrINT32)pSheetRelArray->size(); i++)
//				{
//					pSheetRelationship = pSheetRelArray->at(i);
//					BoraPackagePartName* pTablePartName = PackagingURIHelper::createPartName(pSheetRelationship->m_targetUri->getPath().data());
//					ReadPackageByPartname(pTablePartName->getName().data(), pCallbackParam);
//#ifdef XLSX_DATA_CONNECTION					
//					PackagePartItem* pTablePartItem = m_partList->get(pTablePartName);
//					BoraPackagePart* pTablePart = NULL;
//					if (pTablePartItem)
//						pTablePart = pTablePartItem->m_pPackagePart;
//					else
//						pTablePart = getPart(pTablePartName);
//
//					PackageRelationship* pTableRelationship;
//					PackageRelationshipCollection*	pTableRelationships = pTablePart->m_relationships;
//					BArray<PackageRelationship*>* pTableRelArray = BrNULL;
//
//					if (pTablePart)	//[kjins1201] QueryTable Rel import �߰�
//					{	
//						pTableRelArray = pTableRelationships->iterator(QUERYTABLE_PART_TYPE);
//
//						for(BrINT32 j=0; j<(BrINT32)pTableRelArray->size(); j++)
//						{
//							pTableRelationship = pTableRelArray->at(j);
//							BoraPackagePartName* pQueryPartName = PackagingURIHelper::createPartName(pTableRelationship->m_targetUri->getPath().data());
//							xlsBook* pBook = BrNULL;
//							if(afxGetXlsFrame()->book()->getTmpTable())
//								pBook = afxGetXlsFrame()->book();
//							else 
//								break;
//							xlsQueryTable* pQueryTable = BrNEW xlsQueryTable();//(/*afxGetXlsFrame()->book()->getTmpTable()*/);
//							
//							//import �� table ���� queryTable�� ���� �� ���� table ���� �� tablecontainer�� queryTable �߰�
//							pQueryTable->setTableInfo(pBook->getTmpTable());
//							pQueryTable->addTable(pBook->getTmpTable()->getSheetId());
//							
//							CallbackParam	param;
//							memset(&param, 0, BrSizeOf(CallbackParam));
//							param.pCurrentInstance = pQueryTable;
//							ReadPackageByPartname(pQueryPartName->getName().data(), &param);
//							afxGetXlsFrame()->book()->setTmpTable(BrNULL);
//							BrDELETE pQueryPartName;
//						}
//					}
//
//					BrDELETE pTableRelArray;
//#endif //XLSX_DATA_CONNECTION
//				}
//#ifdef XLSX_DATA_CONNECTION
//				//sheet.rels.xml�� �ִ� queryTable Import
//				if(pSheetRelArray->size() == 0)
//				{
//					pSheetRelArray = pSheetRelationships->iterator(QUERYTABLE_PART_TYPE);
//					if(pSheetRelArray->size() > 0)
//					{
//						for(BrINT32 j=0; j<(BrINT32)pSheetRelArray->size(); j++)
//						{
//							pSheetRelationship = pSheetRelArray->at(j);
//							BoraPackagePartName* pQueryPartName = PackagingURIHelper::createPartName(pSheetRelationship->m_targetUri->getPath().data());
//							xlsBook* pBook = afxGetXlsFrame()->book();
//							if(!pBook->getDataConnectionContainer())
//								break;
//							xlsSheet* pSheet = pBook->getSheet(pBook->getDataConnectionContainer()->getCurrentSheetIndex());
//							
//							if(!pSheet->getQueryTableContainer())
//								pSheet->setQueryTableContainer(BrNEW xlsQueryTableContainer());
//
//							xlsQueryTable* pQueryTable = BrNEW xlsQueryTable(/*pBook->getTmpTable()*/);
//							pSheet->getQueryTableContainer()->addQueryTable(pQueryTable);
//							CallbackParam	param;
//							memset(&param, 0, BrSizeOf(CallbackParam));
//							param.pCurrentInstance = pQueryTable;
//							ReadPackageByPartname(pQueryPartName->getName().data(), &param);
//							BrDELETE pQueryPartName;
//						}
//					}
//				}
//#endif //XLSX_DATA_CONNECTION				
//				
//
//
//				BrDELETE pSheetRelArray;
//			}
//		}
//	}
//	BrDELETE pBookRelArray;
//
//	return BrTRUE;
//}
//#endif //USE_SHEET_INTERFACE

// BrBOOL BoraPackageBase::ReadTableRelationship(BoraPackagePart* pPart, BrCHAR* lpPartType)
// {
// 	BrINT32 i;
// 	PackageRelationship* pRel;
// 	//  xl/_rels/workbook.xml.rels
// 	PackageRelationshipCollection*	pMainDocRelationships = pPart->m_relationships;
// 
// 	//  xl/_rels/workbook.xml.rels ���� WORKSHEET_PART_TYPE �� �ش��ϴ� relationship ã��
// 	BArray<PackageRelationship*>* pBookRelArray = pMainDocRelationships->iterator(lpPartType);
// 
// 	for(i=0; i<(BrINT32)pBookRelArray->size(); i++)
// 	{
// 		pRel = pBookRelArray->at(i);
// 		//  sheet?.xml
// 		BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
// 		PackagePartItem* pSheetParkItem = m_partList->get(pPartName);
// 		BoraPackagePart* pSheetPart = NULL;
// 		if (pSheetParkItem)
// 			pSheetPart = pSheetParkItem->m_pPackagePart;
// 		else
// 			pSheetPart = getPart(pPartName);//�̷��� �ϸ� �ش� sheet �� relation ���� �鵵 ���� ������.
// 
// 		//sheet �� ���õ� part �� �о� �鿩�� ��.
// 
// 		PackageRelationship* pSheetRelationship;
// 		PackageRelationshipCollection*	pSheetRelationships = pSheetPart->m_relationships;
// 		BArray<PackageRelationship*>* pSheetRelArray = BrNULL;
// 
// 		if (pSheetPart)	
// 		{	
// 			pSheetRelArray = pSheetRelationships->iterator(TABLE_PART_TYPE);
// 
// 			for(BrINT32 j=0; j<(BrINT32)pSheetRelArray->size(); j++)
// 			{
// 				pSheetRelationship = pSheetRelArray->at(j);
// 				BoraPackagePartName* pTablePartName = PackagingURIHelper::createPartName(pSheetRelationship->m_targetUri->getPath().data());
// 
//  				PackagePartItem* pTablePartItem = m_partList->get(pTablePartName);
//  				BoraPackagePart* pTablePart = NULL;
// 				if (pTablePartItem)
// 					pTablePart = pTablePartItem->m_pPackagePart;
//  				else
// 					pTablePart = getPart(pTablePartName);
// 
// 				PackageRelationship* pTableRelationship;
// 				PackageRelationshipCollection*	pTableRelationships = pTablePart->m_relationships;
// 				BArray<PackageRelationship*>* pTableRelArray = BrNULL;
// 
// 				if (pTablePart)	//[kjins1201] QueryTable Rel import �߰�
// 				{	
// 					pTableRelArray = pTableRelationships->iterator(QUERYTABLE_PART_TYPE);
// 
// 					for(BrINT32 k=0; k<(BrINT32)pTableRelArray->size(); k++)
// 					{
// 						pTableRelationship = pTableRelArray->at(k);
// 						BoraPackagePartName* pQueryPartName = PackagingURIHelper::createPartName(pTableRelationship->m_targetUri->getPath().data());
// 						xlsQueryTable* pQueryTable = BrNEW xlsQueryTable();
// 						//afxGetXlsFrame()->book()->setQueryTable(pQueryTable);
// 						CallbackParam	param;
// 						memset(&param, 0, BrSizeOf(CallbackParam));
// 						param.pCurrentInstance = pQueryTable;
// 						ReadPackageByPartname(pQueryPartName->getName().data(), &param);
// 						BrDELETE pQueryPartName;
// 					}
// 				}
// 
// 				BrDELETE pTableRelArray;
// 			}
// 			BrDELETE pSheetRelArray;
// 		}
// 	}
// 	BrDELETE pBookRelArray;
// 
// 	return BrTRUE;
// }

BrBOOL BoraPackageBase::ReadSheet(LPCallbackParam pCallbackParam, BoraPackagePart* pPart, BrCHAR* lpPartType, BrCHAR* nID)
{
	BrINT32 i;
	BrBOOL	bRet = BrFALSE;
	PackageRelationship* pRel;
	//  xl/_rels/workbook.xml.rels
	PackageRelationshipCollection*	pMainDocRelationships = pPart->m_relationships;
	
	//  xl/_rels/workbook.xml.rels ���� WORKSHEET_PART_TYP/E �� �ش��ϴ� relationship ã��
	BArray<PackageRelationship*>* pBookRelArray = pMainDocRelationships->iterator(lpPartType);

	for(i=0; i<(BrINT32)pBookRelArray->size(); i++)
	{
		pRel = pBookRelArray->at(i);
		if (nID != BrNULL && strcmp(pRel->m_id.data(), nID)==0)
		{
			//  sheet?.xml
			BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
			PackagePartItem* pSheetParkItem = m_partList->get(pPartName);
			BoraPackagePart* pSheetPart = NULL;
			if (pSheetParkItem)
				pSheetPart = pSheetParkItem->m_pPackagePart;
			else
				pSheetPart = getPart(pPartName);//�̷��� �ϸ� �ش� sheet �� relation ���� �鵵 ���� ������.

			//sheet �� ���õ� part �� �о� �鿩�� ��.


			//[2011.08.03][�̻�][TID:1434] 
			PackageRelationship* pSheetRelationship;
			//fix submit - Coverity - CID:19043 Jarvis - pSheetPart - Dereference before null check
			PackageRelationshipCollection*	pSheetRelationships = BrNULL;
			BArray<PackageRelationship*>* pSheetRelArray = BrNULL;

			if(BrNULL != pSheetPart)
				pSheetRelationships = pSheetPart->m_relationships;
/*
���� ���� �̽��� ParseDefinedNamesFormula Ƚ�� �ѹ��� �ϱ� ����
���̺��� �д� �κ��� ReadSheetRelationship �Լ� ��ƾ���� ���� ������Ѽ�
���Ŀ� �̻� ������ ���� [9/19/2014 chunrans4]
/*
			if (pSheetPart)	//[sohyunhwang] table Importer �߰�
			{	
				pSheetRelArray = pSheetRelationships->iterator(TABLE_PART_TYPE);

				for(BrINT32 i=0; i<(BrINT32)pSheetRelArray->size(); i++)
				{
					pSheetRelationship = pSheetRelArray->at(i);
					BoraPackagePartName* pTablePartName = PackagingURIHelper::createPartName(pSheetRelationship->m_targetUri->getPath().data());
					ReadPackageByPartname(pTablePartName->getName().data(), pCallbackParam);
					BrDELETE pTablePartName;
				}
				BrDELETE pSheetRelArray;
			}
			((xlsxBook* )afxGetXlsFrame()->book())->ParseDefinedNamesFormula();
*/

			// VML data ������ �������� [4/6/2015 signous]
			//[2011.08.03][�̻�][TID:1434] Comment Part Read 
			if(BrNULL != pSheetPart && BrNULL != pSheetRelationships)
			{
				pSheetRelArray = pSheetRelationships->iterator(COMMENT_PART_TYPE);
				if(BrNULL != pSheetRelArray) {
					for(BrINT32 i=0; i<(BrINT32)pSheetRelArray->size(); i++)
					{
						pSheetRelationship = pSheetRelArray->at(i);
						BoraPackagePartName* pCommentPartName = PackagingURIHelper::createPartName(pSheetRelationship->m_targetUri->getPath().data());
						ReadPackageByPartname(pCommentPartName->getName().data(), pCallbackParam);
						BR_SAFE_DELETE ( pCommentPartName);
					}
					BrDELETE pSheetRelArray;
				}
			}

#ifdef SHEET_SUPPORT_THREADED_COMMENT
			// threaded Comment
			if(BrNULL != pSheetPart && BrNULL != pSheetRelationships)
			{	
				pSheetRelArray = pSheetRelationships->iterator(THREADED_COMMENT_PART_TYPE);

				if(BrNULL != pSheetRelArray) {
					for(BrINT32 i=0; i<(BrINT32)pSheetRelArray->size(); i++)
					{
						pSheetRelationship = pSheetRelArray->at(i);
						BoraPackagePartName* pThreadedCommentPartName = PackagingURIHelper::createPartName(pSheetRelationship->m_targetUri->getPath().data());
						ReadPackageByPartname(pThreadedCommentPartName->getName().data(), pCallbackParam);
						BR_SAFE_DELETE ( pThreadedCommentPartName ); //  [4/2/2014 sylee0335] leak prevent
					}
					BrDELETE pSheetRelArray;
				}
			}
#endif

			//  sheet.xml �� ����.
			bRet = ReadPackageByPartname(pPartName->getName().data(), pCallbackParam);
			if (BrNULL != pSheetParkItem)
				BrDELETE pPartName;


#ifdef POLARIS_BASIC_DEVELOPMENT 
			if(BrNULL != pSheetPart && BrNULL != pSheetRelationships)
			{
				//pSheetRelArray = pSheetRelationships->iterator(CONTROL_PART_TYPE);
				//for(BrINT32 i=0; i<(BrINT32)pSheetRelArray->size(); i++)
				//{
				//	pSheetRelationship = pSheetRelArray->at(i);
				//	BoraPackagePartName* pControlPartName = PackagingURIHelper::createPartName(pSheetRelationship->m_targetUri->getPath().data());
				//	PackagePartItem* pControlPartItem = m_partList->get(pControlPartName);
				//	BoraPackagePart* pControlPart = NULL;
				//	if (pControlPartItem)
				//		pControlPart = pControlPartItem->m_pPackagePart;
				//	else
				//		pControlPart = getPart(pControlPartName);//�̷��� �ϸ� �ش� sheet �� relation ���� �鵵 ���� ������.
				//	ReadPackageByPartname(pControlPartName->getName().data(), pCallbackParam);
				//}
				//BrDELETE pSheetRelArray;
				pSheetRelArray = pSheetRelationships->iterator(CONTROL_PART_TYPE);

				if(BrNULL != pSheetRelArray) {
					for(BrINT32 i=0; i<(BrINT32)pSheetRelArray->size(); i++)
					{
						pSheetRelationship = pSheetRelArray->at(i);
						BoraPackagePartName* pControlPartName = PackagingURIHelper::createPartName(pSheetRelationship->m_targetUri->getPath().data());
						ReadPackageByPartname(pControlPartName->getName().data(), pCallbackParam);
						BR_SAFE_DELETE ( pControlPartName);
					}

					BR_SAFE_DELETE(m_pSheetFormControlRelArray);	// �ּҰ��� �����ϱ� ���� ������ ������ ��ü�� �޸𸮸� �����Ѵ�.
					m_pSheetFormControlRelArray = pSheetRelArray;
				}
			}			
#endif //POLARIS_BASIC_DEVELOPMENT 


			if (!bRet)
			{
				BrDELETE pBookRelArray;
				return BrFALSE;
			}

			if(BrNULL != pSheetPart && BrNULL != pSheetRelationships)
			{	
				pSheetRelArray = pSheetRelationships->iterator(DRAWING_PART_TYPE);

				if(BrNULL != pSheetRelArray) {
					for(BrINT32 i=0; i<(BrINT32)pSheetRelArray->size(); i++)
					{
						pSheetRelationship = pSheetRelArray->at(i);
						BoraPackagePartName* pDrawPartName = PackagingURIHelper::createPartName(pSheetRelationship->m_targetUri->getPath().data());
						ReadPackageByPartname(pDrawPartName->getName().data(), pCallbackParam);
						BR_SAFE_DELETE ( pDrawPartName ); //  [4/2/2014 sylee0335] leak prevent
					}
					BrDELETE pSheetRelArray;
				}
			}

			if(BrNULL != pSheetPart && BrNULL != pSheetRelationships) //[2012.05.23][���缱][TID:5456] PivotTable Importer �߰�
			{
				pSheetRelArray = pSheetRelationships->iterator(PIVOTTABLE_PART_TYPE);
				if(BrNULL != pSheetRelArray) {
					for(BrINT32 i=0; i<(BrINT32)pSheetRelArray->size(); i++)
					{
						pSheetRelationship = pSheetRelArray->at(i);
						BoraPackagePartName* pPivotTablePartName = PackagingURIHelper::createPartName(pSheetRelationship->m_targetUri->getPath().data());
						PackagePartItem* pPivotTablePartItem = m_partList->get(pPivotTablePartName);
						BoraPackagePart* pPivotTablePart = NULL;
						if (pPivotTablePartItem)
							pPivotTablePart = pPivotTablePartItem->m_pPackagePart;
						else
							pPivotTablePart = getPart(pPivotTablePartName);//�̷��� �ϸ� �ش� sheet �� relation ���� �鵵 ���� ������.
						ReadPackageByPartname(pPivotTablePartName->getName().data(), pCallbackParam);
					}
					BrDELETE pSheetRelArray;
				}
			}

			break;
		}
	}
	BrDELETE pBookRelArray;

	return bRet;
}

BrBOOL BoraPackageBase::ReadPage_XLSX_Relationship(LPCallbackParam pCallbackParam, BrCHAR* nID, BrINT *pnError)
{
	BrBOOL	bRet = BrFALSE;
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);

	if (pRel)
	{
		BoraPackagePart* pPart = getMatchingPart(pRel);
		bRet = ReadSheetRelationship(pCallbackParam, pPart, WORKSHEET_PART_TYPE, nID, pnError);
	}

	return bRet;
}

BrBOOL BoraPackageBase::ReadPage_XLSX(LPCallbackParam pCallbackParam, BrCHAR* nID, BrBOOL& bChartSheet)
{
	BrBOOL	bRet = BrFALSE;
	//[AOM-38969] Crash Dump ����.
	if( !m_relationships )
		return bRet;
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);

	if (pRel)
	{
		BoraPackagePart* pPart = getMatchingPart(pRel);

		bRet = ReadSheet(pCallbackParam, pPart, WORKSHEET_PART_TYPE, nID);
		if (!bRet)
		{
			bRet = ReadSheet(pCallbackParam, pPart, CHARTSHEET_PART_TYPE, nID);
			if (bRet)
				bChartSheet = BrTRUE;
		}
	}

	return bRet;
}

#ifdef SUPPORT_2007_OLE
BString BoraPackageBase::ReadOLEPath( BrCHAR* strSrcPartName,  BrCHAR* a_strOleRelId)
{
	BoraPackagePart* pPackagePart = GetPackagePart(strSrcPartName);
	if (!pPackagePart)
		return NULL;
	PackageRelationshipCollection* pRelationships = pPackagePart->m_relationships;
	BString strOlePartName;
	BrINT32 nRelationCount = pRelationships->size();
	for(BrINT32 nRelIndex = 0; nRelIndex <nRelationCount; nRelIndex++)
	{
		PackageRelationship* pRel = pRelationships->getRelationship(nRelIndex);
		if(0 == strcmp(pRel->getId().data(), a_strOleRelId))
			return pRel->m_targetUri->getPath();
	
	}
	return NULL;
}
#endif 

#ifdef USE_POLARISBASIC
// vbaProject.bin������ �д� �Լ�.
// ReadStyle_XLSX()�Լ��� �����Ͽ���.
BrBOOL BoraPackageBase::ReadVbaProject(BString type, BrLPBYTE& pVbaData, BrINT32& nDataSize)
{
	BrBOOL bRet = BrFALSE;
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(type);
	if (pRel == BrNULL)
		return bRet;

	BoraPackagePart* pPart = getMatchingPart(pRel);
	if (pPart == BrNULL)
		return bRet;

	PackageRelationshipCollection*	pMainDocRelationships = pPart->m_relationships;
	BArray<PackageRelationship*>* pBookRelArray = pMainDocRelationships->iterator(VBAPROJECT_PART_TYPE);

	if (pBookRelArray->size() > 0) {
		pRel = pBookRelArray->at(0);
		BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
		BrBOOL bExistPart = (m_partList->get(pPartName)!=BrNULL);
		if( !bExistPart )
			getPart(pPartName);//�̷��� �ϸ� �ش� relation ������ ���� ������.

		bRet = ReadVbaProjectPackageByPartName(pPartName->getName().data(), pVbaData, nDataSize);
		if( bExistPart )
			BrDELETE pPartName;

		if (!bRet)
		{
			BrDELETE pBookRelArray;
			return BrFALSE;
		}
	}
	else {
		// vbaProject.bin������ �������� �������� �����Ƿ�
		bRet = BrTRUE;
	}

	BrDELETE pBookRelArray;

	return bRet;
}

// zip���Ϸκ��� vbaProject.bin���Ͻ�ü�� �����ϴ� �Լ�.
BrBOOL BoraPackageBase::ReadVbaProjectPackageByPartName(const BrCHAR* strPartName, BrLPBYTE& pData, BrINT32& nDataSize)
{
	BrINT32 nPartIndex = m_pftXMLStorage->GetIndex(strPartName);
	if( nPartIndex==-1 )
		return BrFALSE;

	BrINT32 nZipItemIndex = nPartIndex;
	ZIPENTRY* ze = m_pftXMLStorage->m_oZipInfo.zes[nPartIndex];
	HZIP hZip = m_pftXMLStorage->m_oZipInfo.hZipFile;
	BrUINT32 nSize = BrZipGetItemSize(hZip, nZipItemIndex);
	BrLPBYTE pMem = (BrLPBYTE)BrMalloc(nSize);
	if(pMem) {
		if(BrZipExtractMemory("", hZip, nZipItemIndex, pMem)) {
			pData = pMem;
			nDataSize = nSize;
		}

		return BrTRUE;
	}
	else {
		BrFree(pMem);
		return BrFALSE;
	}
}
#endif // USE_POLARISBASIC

#ifdef SHEET_PRINTER_SETTINGS_BIN_IMPORT
BrBOOL BoraPackageBase::ReadPrinterSettingsPackageByPartName(const BrCHAR* strPartName, BrLPBYTE& pData, BrINT32& nDataSize)
{
	BrINT32 nPartIndex = m_pftXMLStorage->GetIndex(strPartName);
	if(nPartIndex == -1)
		return BrFALSE;

	BrINT32 nZipItemIndex = nPartIndex;
	ZIPENTRY* ze = m_pftXMLStorage->m_oZipInfo.zes[nPartIndex];
	HZIP hZip = m_pftXMLStorage->m_oZipInfo.hZipFile;
	BrUINT32 nSize = BrZipGetItemSize(hZip, nZipItemIndex);
	BrLPBYTE pMem = (BrLPBYTE)BrMalloc(nSize);
	if(pMem)
	{
		if(BrZipExtractMemory("", hZip, nZipItemIndex, pMem))
		{
			pData = pMem;
			nDataSize = nSize;
		}
		return BrTRUE;
	}
	else
	{
		BrFree(pMem);
		return BrFALSE;
	}
}
#endif	// SHEET_PRINTER_SETTINGS_BIN_IMPORT

BrBOOL BoraPackageBase::ReadExternalLinkFileName(BString* pStrRID, BString* pStrFileName, bool* a_bPathMissing )
{
	BrBOOL	bRet = BrFALSE;
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);
	if( pRel )
	{
		BoraPackagePart* pPart = getMatchingPart(pRel);
		//  xl/_rels/workbook.xml.rels
		PackageRelationshipCollection*	pMainDocRelationships = pPart->m_relationships;
		
		//  xl/_rels/workbook.xml.rels ���� SLIDE_PART_TYPE �� �ش��ϴ� relationship ã��
		BArray<PackageRelationship*>* pExternalLinkRelArray = pMainDocRelationships->iterator(EXTERNAL_LINK_PART_TYPE);

		int size = pExternalLinkRelArray->size();
		for(BrINT32 i=0; i<(BrINT32)size; i++)
		{
			pRel = pExternalLinkRelArray->at(i);
			if (strcmp(pRel->m_id.data(), pStrRID->data())==0 )
			{
				//  ppt/slides/slide?.xml
				BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
				PackagePartItem* pSheetParkItem = m_partList->get(pPartName);
				BoraPackagePart* pSheetPart = NULL;
				if (pSheetParkItem)
				{
					pSheetPart = pSheetParkItem->m_pPackagePart;
					BrDELETE pPartName;
				}
				else
					pSheetPart = getPart(pPartName);//�̷��� �ϸ� �ش� slide �� relation ���� �鵵 ���� ������.

				if (pSheetPart)
				{
					BArray<PackageRelationship*>* pExternalLinkArray = pSheetPart->m_relationships->iterator(EXTERNAL_LINKPATH_PART_TYPE);
					if ( pExternalLinkArray && pExternalLinkArray->size() > 0 )
					{
						for(BrINT32 i=0; i<(BrINT32)pExternalLinkArray->size(); i++)
						{
							// 						BString strTarget = pExternalLinkArray->at(i)->m_targetUri->getPath();
							// 						int nIndex = strTarget.findRev('/');
							// 						if (nIndex == -1)
							// 							*pStrFileName = strTarget;
							// 						else
							// 							*pStrFileName = strTarget.mid(nIndex+1);

							//  [12/13/2013 chunrans4] externalLink.xml.rel�� �ִ� �ܺ� ��ũ �ּ� �߸��� ���� ������ ������ �Ʒ��� ����
							BString strTarget = pExternalLinkArray->at(i)->m_targetUri->getUrl();
							*pStrFileName = strTarget;
							*a_bPathMissing = false;
						}
					}
					BR_SAFE_DELETE(pExternalLinkArray);
				
					BArray<PackageRelationship*>* pExternalLinkArrayXlStartUp = pSheetPart->m_relationships->iterator(EXTERNAL_LINKPATH_XLSTARTUP_PART_TYPE); 
					if ( pExternalLinkArrayXlStartUp && pExternalLinkArrayXlStartUp->size() > 0 )
					{
						for(BrINT32 i=0; i<(BrINT32)pExternalLinkArrayXlStartUp->size(); i++)
						{
							BString strTarget = pExternalLinkArrayXlStartUp->at(i)->m_targetUri->getUrl();
							*pStrFileName = strTarget;
							*a_bPathMissing = false;
						}
					}
					BR_SAFE_DELETE(pExternalLinkArrayXlStartUp);

					BArray<PackageRelationship*>* pExternalLinkArrayXlPathMissing = pSheetPart->m_relationships->iterator(EXTERNAL_LINKPATH_XLPATHMISSING_PART_TYPE); 
					if ( pExternalLinkArrayXlPathMissing && pExternalLinkArrayXlPathMissing->size() > 0 )
					{
						for(BrINT32 i=0; i<(BrINT32)pExternalLinkArrayXlPathMissing->size(); i++)
						{
							BString strTarget = pExternalLinkArrayXlPathMissing->at(i)->m_targetUri->getUrl();
							*pStrFileName = strTarget;
							*a_bPathMissing = true;
						}
					}
					BR_SAFE_DELETE(pExternalLinkArrayXlPathMissing);
				}
				break;
			}
		}
		BrDELETE pExternalLinkRelArray;
	}

	return bRet;
}

// [2010-11-26][Begin] ChartSheet SubStream
BrBOOL BoraPackageBase::ReadChart_XLSX(LPCallbackParam pCallbackParam, BrCHAR* nSheetID, BrCHAR* nChartID, BrBOOL bChartSheetType)
{
	BrBOOL	bRet = BrFALSE;
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);
	if( pRel )
	{
		BoraPackagePart* pPart = getMatchingPart(pRel);

		//  xl/_rels/workbook.xml.rels
		PackageRelationshipCollection*	pMainDocRelationships = pPart->m_relationships;
		
		BArray<PackageRelationship*>* pBookRelArray = NULL;
		// [Dandong][2010-11-26][Begin] ChartSheet SubStream
		if (bChartSheetType)
			pBookRelArray = pMainDocRelationships->iterator(CHARTSHEET_PART_TYPE);
		else //  xl/_rels/workbook.xml.rels ���� SLIDE_PART_TYPE �� �ش��ϴ� relationship ã��
			pBookRelArray = pMainDocRelationships->iterator(WORKSHEET_PART_TYPE);
		// [Dandong][2010-11-26][End] ChartSheet SubStream

		int size = pBookRelArray->size();
		for(BrINT32 i=0; i<(BrINT32)size; i++)
		{
			pRel = pBookRelArray->at(i);
			if (strcmp(pRel->m_id.data(), nSheetID)==0 )
			{
				//  ppt/slides/slide?.xml
				BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
				PackagePartItem* pSheetParkItem = m_partList->get(pPartName);
				BoraPackagePart* pSheetPart = NULL;
				if (pSheetParkItem)
				{
					pSheetPart = pSheetParkItem->m_pPackagePart;
					BrDELETE pPartName;
				}
				else
					pSheetPart = getPart(pPartName);//�̷��� �ϸ� �ش� slide �� relation ���� �鵵 ���� ������.

				if (pSheetPart)
				{
					PackageRelationship* pSheetRelationship;
					PackageRelationshipCollection*	pSheetRelationships = pSheetPart->m_relationships;
					BArray<PackageRelationship*>* pSheetRelArray = pSheetRelationships->iterator(DRAWING_PART_TYPE);

					for(BrINT32 i=0; i<(BrINT32)pSheetRelArray->size(); i++)
					{
						pSheetRelationship = pSheetRelArray->at(i);
						BoraPackagePartName* pDrawPartName = PackagingURIHelper::createPartName(pSheetRelationship->m_targetUri->getPath().data());
						PackagePartItem* pDrawtParkItem = m_partList->get(pDrawPartName);
						BoraPackagePart* pDrawPart = NULL;
						if (pDrawtParkItem)
						{
							pDrawPart = pDrawtParkItem->m_pPackagePart;
							BrDELETE pDrawPartName;
						}
						else
							pDrawPart = getPart(pDrawPartName);//�̷��� �ϸ� �ش� slide �� relation ���� �鵵 ���� ������.

						if (pDrawPart)
						{
							PackageRelationship* pDrawRelationship;
							PackageRelationshipCollection*	pDrawRelationships = pDrawPart->m_relationships;
							BArray<PackageRelationship*>* pChartRelArray = pDrawRelationships->iterator(CHART_PART_TYPE);
							BArray<PackageRelationship*>* pChartExRelArray = pDrawRelationships->iterator(CHARTEX_PART_TYPE);

							for(BrINT32 i=0; i<(BrINT32)pChartRelArray->size(); i++)
							{
								pDrawRelationship = pChartRelArray->at(i);
								if (strcmp(pDrawRelationship->m_id.data(), nChartID)==0 )
								{
									BoraPackagePartName* pDrawPartName = PackagingURIHelper::createPartName(pDrawRelationship->m_targetUri->getPath().data());
									bRet = ReadPackageByPartname(pDrawPartName->getName().data(), pCallbackParam);
									BR_SAFE_DELETE(pDrawPartName);
									break;
								}
							}

							for(BrINT32 i=0; i<(BrINT32)pChartExRelArray->size(); i++)
							{
								pDrawRelationship = pChartExRelArray->at(i);
								if (strcmp(pDrawRelationship->m_id.data(), nChartID)==0 )
								{
									BoraPackagePartName* pDrawPartName = PackagingURIHelper::createPartName(pDrawRelationship->m_targetUri->getPath().data());
									bRet = ReadPackageByPartname(pDrawPartName->getName().data(), pCallbackParam);
									BR_SAFE_DELETE(pDrawPartName);
									break;
								}
							}
							BrDELETE pChartRelArray;
							BrDELETE pChartExRelArray;
						}
					}
					BrDELETE pSheetRelArray;
				}
				break;
			}
		}
		BrDELETE pBookRelArray;
	}

	return bRet;
}

BrBOOL BoraPackageBase::CurruptedXmlParser(BrLPVOID pCallbackInst)
{
	BrCallbackBase*	pObject = (BrCallbackBase*)pCallbackInst;
	BoraXmlParserContext* pContext = (BoraXmlParserContext*)pObject->GetXmlParserContext();
	if( pContext->parser )
		return XML_StopParser(pContext->parser, BrFALSE)==XML_STATUS_OK;

	return BrFALSE;
}

BrBOOL BoraPackageBase::SuspendXmlParser(BrLPVOID pCallbackInst)
{
	BrCallbackBase*	pObject = (BrCallbackBase*)pCallbackInst;
	BoraXmlParserContext* pContext = (BoraXmlParserContext*)pObject->GetXmlParserContext();
	if( pContext->parser )
		return XML_StopParser(pContext->parser, BrTRUE)==XML_STATUS_OK;

	return BrFALSE;
}

BrBOOL BoraPackageBase::ResumeXmlParser(BrLPVOID pCallbackInst)
{
	BrCallbackBase*	pObject = (BrCallbackBase*)pCallbackInst;
	BoraXmlParserContext* pContext = (BoraXmlParserContext*)pObject->GetXmlParserContext();
	if (pContext->parser) {
		int result = 0;
		if (pContext->stream)
			result = __BR_XML_continue_parsing(pContext->parser, pContext->stream);
		else
			result = __BR_XML_continue_parsing(pContext->parser, pContext->xloader);
        return (result >= 0);
    }

	return BrTRUE;
}

void BoraPackageBase::EndXmlParser(BrLPVOID pCallbackInst)
{
	BrCallbackBase*	pObject = (BrCallbackBase*)pCallbackInst;
	BoraXmlParserContext* pContext = (BoraXmlParserContext*)pObject->GetXmlParserContext();
	if( pContext->parser )
	{
		if (pContext->stream)
		{
			if( pContext->stream->GetDataBuf() )
				BrFree(pContext->stream->GetDataBuf());
			BrDELETE pContext->stream;
		}
		if (pContext->xloader)
			BrDELETE pContext->xloader;
		XML_ParserFree(pContext->parser);
		BrFree(pContext);
	}
	pObject->SetXmlParserContext(BrNULL);
}

BrImageLoadingBase* BoraPackageBase::GetImageLoader(const BString& strPartName, const BString& strRelID, BrDOUBLE CropLeft, BrDOUBLE CropTop, BrDOUBLE CropRight, BrDOUBLE CropBottom)
{
	BrImageLoadingBase* pLoader = m_pImageLoader;

	while(pLoader)
	{
		if( ((FtXMLImageLoader*)pLoader)->GetRefRelID() == strRelID && ((FtXMLImageLoader*)pLoader)->GetRefPartName() == strPartName )
		{
			if (!((FtXMLImageLoader*)pLoader)->CompareProperty(CropLeft, CropTop, CropRight, CropBottom))
				goto MAKE_LOADER;
			return pLoader;
		}
		pLoader = pLoader->m_pNext;
	}

MAKE_LOADER:
	pLoader = BrNEW FtXMLImageLoader(this, strPartName, strRelID, CropLeft, CropTop, CropRight, CropBottom);
	if( !m_pImageLoader )
		m_pImageLoader = pLoader;
	else
		m_pImageLoader->AddImageLoader(pLoader);
	return pLoader;
}

#ifdef SUPPORT_2007_OLE
//#define SUPPORT_2007_OLE_DEBUG
BrOLELoadingBase* BoraPackageBase::GetOLELoader(BString strPartName, BrINT32 nMediaType, BrBOOL a_bIsExternal)
{
	//Frame ���� �� SubFrame �����ϸ鼭 delete�ϹǷ� ������ list�� ���� �� �ʿ䰡 ���� �ι� delete�ϴ� ���� �߻��Ͽ� �ּ�ó��
//	BrOLELoadingBase* pLoader = m_pOLELoader;
//
//	while(pLoader)
//	{
//		if( ((BrOLEFileLoader*)pLoader)->GetFileName() == strPartName)
//			return pLoader;
//
//		pLoader = pLoader->m_pNext;
//	}
//
//	//[2012.06.11][TID:#6896]�Լ����� Ÿ���� ������.
//	//pLoader = BrNEW BrOLEFileLoader(this, LOADER_PPTX, 0, strPartName, 0, BrNULL);
//	pLoader = BrNEW BrOLEFileLoader(this, OLE_LOADER_PPTX, strPartName, OLE_EMBEDDED_TYPE, BrNULL, nMediaType);
//#ifdef SUPPORT_2007_OLE_DEBUG
//	BrBOOL bRet = pLoader->LoadOLE();
//#endif
//	if(!m_pOLELoader) {
//		m_pOLELoader = pLoader;
//	}
//	else {
//		m_pOLELoader->AddOLELoader(pLoader);
//	}

	BrOLELoadingBase* pLoader = BrNEW BrOLEFileLoader(this, OLE_LOADER_PPTX, strPartName, (a_bIsExternal ? OLE_LINKED_TYPE : OLE_EMBEDDED_TYPE), BrNULL, nMediaType, a_bIsExternal);

	return pLoader;
}

BrOLELoadingBase* BoraPackageBase::GetOLELoader(BString strPartName, BString strRelID)
{
	BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(strPartName);
	BoraPackagePart* pPackagePart = getPart(pPartName);
	PackageRelationshipCollection* pRelationships = pPackagePart->m_relationships;
	BString strOleFileName;
	BrINT32 nRelationCount = pRelationships->size();
	for(BrINT32 nRelIndex = 0; nRelIndex <nRelationCount; nRelIndex++)
	{
		PackageRelationship* pRel = pRelationships->getRelationship(nRelIndex);
		if(!pRel->getId().compare(strRelID))
		{
			strOleFileName = pRel->m_targetUri->getPath();
			break;
		}
	}

	if(!strOleFileName.length())
		return BrNULL;

	BrOLELoadingBase* pLoader = BrNEW BrOLEFileLoader(this, OLE_LOADER_DOCX, strOleFileName, OLE_EMBEDDED_TYPE, BrNULL);
	return pLoader;
}

//[2012.06.20][�̻�][TID:7039] 
BrOLELoadingBase* BoraPackageBase::GetOLELoader_XLSX(BString strPartName)
{
	BrOLELoadingBase* pLoader = m_pOLELoader;

	while(pLoader)
	{
		if( ((BrOLEFileLoader*)pLoader)->GetFileName() == strPartName)
			return pLoader;

		pLoader = pLoader->m_pNext;
	}

	//[2012.06.11][TID:#6896]�Լ����� Ÿ���� ������.
	//pLoader = BrNEW BrOLEFileLoader(this, LOADER_PPTX, 0, strPartName, 0, BrNULL);
	pLoader = BrNEW BrOLEFileLoader(this, OLE_LOADER_XLSX, strPartName, OLE_EMBEDDED_TYPE, BrNULL);

#ifdef SUPPORT_2007_OLE_DEBUG
	BrBOOL bRet = pLoader->LoadOLE();
#endif
	if(!m_pOLELoader) {
		m_pOLELoader = pLoader;
	}
	else {
		m_pOLELoader->AddOLELoader(pLoader);
	}
	return pLoader;
}

#endif

//[TID:404][��ȸ��]Image Frame Effect : Bitmap Flag Setting : Loader ����
//BrBOOL BoraPackageBase::ReadImage(BrLPVOID target_info, PrBitmap* pBitmap, BString strPartName, BString strRelID, BrCOLORREF tColor, BrDOUBLE dCropLeft, BrDOUBLE dCropTop, BrDOUBLE dCropRight, BrDOUBLE dCropBottom)
//BrBOOL BoraPackageBase::ReadImage(BrLPVOID target_info, PrBitmap* pBitmap, BString strPartName, BString strRelID, BrCOLORREF tColor, BrDOUBLE dCropLeft, BrDOUBLE dCropTop, BrDOUBLE dCropRight, BrDOUBLE dCropBottom, BrINT32 nBright, BrINT32 nContrast , BrUINT32 nAlpha, BrUINT32 nLighter , BrUINT32 nDarker, BrUINT8 bGray, BrUINT8 bBlackWhite , BrUINT8 bInvert, BrUINT8 bSepia, BrUINT8 bFlip, BrUINT8 bMirror)
BrBOOL BoraPackageBase::ReadImage(BrLPVOID target_info, PrBitmap* pBitmap, PrBitmapFlag bitmapFlag, BString strPartName, BString strRelID, BrBOOL bWdp)
{
	BrBOOL bRet = BrFALSE;
	BrDOUBLE dCropLeft = 0.0;
	BrDOUBLE dCropTop = 0.0;
	BrDOUBLE dCropRight = 0.0;
	BrDOUBLE dCropBottom = 0.0;
	bitmapFlag.getCrop(dCropLeft,dCropTop,dCropRight,dCropBottom);
	BrBOOL bCropping = (dCropLeft!=0.0 || dCropRight!=0.0 || dCropTop!=0.0 || dCropBottom!=0.0);
	IMG_INFO ImgInfo = { eImage_NONE, };
	
	if (strPartName.data() == NULL)
		return bRet;

	BrLPVOID pImageData = BrNULL;
	DrawTarget_Info* target_info1 = (DrawTarget_Info*)target_info;

	// br_try ������ ���� catch �ΰ� ����ȭ �Ǿ� free �ڵ尡 �����.
	pImageData = ReadBlip((BrCHAR*)strPartName.data(), (BrCHAR*)strRelID.data(), &ImgInfo, BrFALSE, bWdp);
	PO_THREAD_TRY_BLOCK {	
		//PrBitmapFlag sFlag;
		//sFlag.setTrans(tColor);
		
		//[TID:404][��ȸ��]Image Frame Effect : Bitmap Flag Setting
		// A. Cropping
		// B. Alpha, Brightness, Contrast, LighteX r, Darker ����
		// C. Gray, BlackWhite, Invert, Sepia ����
		// D. Flip, Mirror ����
		/*
		// A. Cropping
		if(bCropping)
			sFlag.setCrop(dCropLeft, dCropTop, dCropRight, dCropBottom);
		
		// B. Alpha, Brightness, Contrast, Lighter, Darker ����
		sFlag.setAlpha(nAlpha);
		sFlag.setBright(nBright);
		sFlag.setContrast(nContrast);
		sFlag.setLightColor(nLighter);
		sFlag.setDarkColor(nDarker);
		
		// C. Gray, BlackWhite, Invert, Sepia ����
		sFlag.setGray(bGray);
		sFlag.setBlackWhite(bBlackWhite);
		sFlag.setInvert(bInvert);
		sFlag.setSepia(bSepia);

		// D. Flip, Mirror ����
		sFlag.setFlip(bFlip);
		sFlag.setMirror(bMirror);
		*/
		int w = 0, h = 0;
		if (target_info1)
		{
			target_info1->nImageType = (BrImageType)ImgInfo.type;
			target_info1->orgSize.cx = ImgInfo.width;
			target_info1->orgSize.cy = ImgInfo.height;
			target_info1->nResX = ImgInfo.nResX;
			target_info1->nResY = ImgInfo.nResY;
			
			if (target_info1->eImageProcess == eImagePureBitmap) {
				w = target_info1->nTargetRC.right - target_info1->nTargetRC.left;
				h = target_info1->nTargetRC.bottom - target_info1->nTargetRC.top;
			}
		}

		if(pImageData)
			bRet = pBitmap->loadImagePtrYield(pImageData, ImgInfo.nRawSize, w, h, 100, bitmapFlag, target_info1);
		else
			bRet = ReadBlip_Zip(pBitmap, (BrCHAR*)strPartName.data(), (BrCHAR*)strRelID.data(), w, h, 100, bitmapFlag, target_info1, bWdp);

	} PO_THREAD_CATCH_BLOCK { 
		BR_SAFE_FREE(pImageData);
	} PO_THREAD_END

	BR_SAFE_FREE(pImageData);

#ifdef B_DEBUG
	if (bRet && (pBitmap->cx() != ImgInfo.width || pBitmap->cy() != ImgInfo.height))
		BrTrace("%s(%d) ReadImage src[%d,%d] dst[%d,%d]", __FILE__, __LINE__, ImgInfo.width, ImgInfo.height, pBitmap->cx(), pBitmap->cy());	
#endif	
	
	return bRet;
}

BrLPVOID BoraPackageBase::ReadRawImage(BString strPartName, BString strRelID)
{
	IMG_INFO ImgInfo = { eImage_NONE, };
	return ReadBlip((BrCHAR*)strPartName.data(), (BrCHAR*)strRelID.data(), &ImgInfo);
}


#ifdef IMPORT_DIAGRAMX
BrBOOL BoraPackageBase::ReadDiagramData(LPCallbackParam pCallbackParam, BrCHAR* strSrcPartName, BrCHAR* pPartType,BrCHAR* plID)
{
	BrBOOL bRet = BrFALSE;	
	BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(strSrcPartName);
	BrBOOL bExistPart = (m_partList->get(pPartName)!=BrNULL);

	BoraPackagePart* pPart = getPart(pPartName);
	if( pPart )
	{
		PackageRelationshipCollection*	pRelationships = pPart->m_relationships;
		BArray<PackageRelationship*>* pChartRelArray = pRelationships->iterator(pPartType);

		//  nID �� �ش��ϴ� chart �� ã�� ����.
		PackageRelationship* pRel;
		for(BrINT32 i=0; i<(BrINT32)pChartRelArray->size(); i++)
		{
			pRel = pChartRelArray->at(i);
			if( strcmp(pRel->m_id.data(), plID)==0 )
			{
				BoraPackagePartName* pPartName1 = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
				BrBOOL bExistPart1 = (m_partList->get(pPartName1)!=BrNULL);
				if( !bExistPart )
					getPart(pPartName1);
				bRet = ReadPackageByPartname(pPartName1->getName().data(), pCallbackParam);

				if( bExistPart1 )
					BrDELETE pPartName1;
				break;
			}
		}
		BrDELETE pChartRelArray;
	}
	if( bExistPart )
		BrDELETE pPartName;

	return bRet;
}
#endif //IMPORT_DIAGRAMX

BrBOOL BoraPackageBase::ReadEmbedChart(LPCallbackParam pCallbackParam, BrCHAR* strSrcPartName, BrCHAR* nEmbedChartID)
{
	BrBOOL bRet = BrFALSE;
	BrLPBYTE pImage=BrNULL;
	BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(strSrcPartName);
	BrBOOL bExistPart = (m_partList->get(pPartName)!=BrNULL);

	BoraPackagePart* pPart = getPart(pPartName);
	if( pPart )
	{
		PackageRelationshipCollection*	pRelationships = pPart->m_relationships;
		BArray<PackageRelationship*>* pChartRelArray = pRelationships->iterator(CHART_PART_TYPE);
		BArray<PackageRelationship*>* pChartExRelArray = pRelationships->iterator(CHARTEX_PART_TYPE);

		//  nID �� �ش��ϴ� chart �� ã�� ����.
		PackageRelationship* pRel;
		for(BrINT32 i=0; i<(BrINT32)pChartRelArray->size(); i++)
		{
			pRel = pChartRelArray->at(i);
			if( strcmp(pRel->m_id.data(), nEmbedChartID)==0 )
			{
				BoraPackagePartName* pPartName1 = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
				BrBOOL bExistPart1 = (m_partList->get(pPartName1)!=BrNULL);
				if( !bExistPart )
					getPart(pPartName1);
				bRet = ReadPackageByPartname(pPartName1->getName().data(), pCallbackParam);

				if( bExistPart1 )
					BrDELETE pPartName1;
				break;
			}
		}

		for(BrINT32 i=0; i<(BrINT32)pChartExRelArray->size(); i++)
		{
			pRel = pChartExRelArray->at(i);
			if( strcmp(pRel->m_id.data(), nEmbedChartID)==0 )
			{
				BoraPackagePartName* pPartName1 = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
				BrBOOL bExistPart1 = (m_partList->get(pPartName1)!=BrNULL);
				if( !bExistPart )
					getPart(pPartName1);
				bRet = ReadPackageByPartname(pPartName1->getName().data(), pCallbackParam);

				if( bExistPart1 )
					BrDELETE pPartName1;
				break;
			}
		}

		BrDELETE pChartRelArray;
		BrDELETE pChartExRelArray;
	}
	if( bExistPart )
		BrDELETE pPartName;

	return bRet;
}

BString BoraPackageBase::GetEmbedChartDataPackage(BrCHAR* strSrcPartName, BrCHAR* nEmbedPackageID)
{
	BString strPackage;
	BrLPBYTE pImage=BrNULL;
	BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(strSrcPartName);
	BrBOOL bExistPart = (m_partList->get(pPartName)!=BrNULL);

	BoraPackagePart* pPart = getPart(pPartName);
	if( pPart )
	{
		PackageRelationshipCollection*	pRelationships = pPart->m_relationships;
		BArray<PackageRelationship*>* pPackageRelArray = pRelationships->iterator(EMBED_PACKAGE_PART_TYPE);

		//  nID �� �ش��ϴ� package �� ã��.
		PackageRelationship* pRel;
		for(BrINT32 i=0; i<(BrINT32)pPackageRelArray->size(); i++)
		{
			pRel = pPackageRelArray->at(i);
			if( strcmp(pRel->m_id.data(), nEmbedPackageID)==0 )
			{
				BoraPackagePartName* pPartName1 = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
				BrBOOL bExistPart1 = (m_partList->get(pPartName1)!=BrNULL);
				if( !bExistPart )
					getPart(pPartName1);
				strPackage = pPartName1->getName().data();

				if( bExistPart1 )
					BrDELETE pPartName1;
				break;
			}
		}
		BrDELETE pPackageRelArray;
	}
	if( bExistPart )
		BrDELETE pPartName;

	return strPackage;
}

BString BoraPackageBase::GetEmbedOrgFileName(BrCHAR* a_szSrcPartName, BString a_strPartType, BString* a_pRid)
{
	BString strEmbedChartOrgName;
	BArray<PackageRelationship*>* pRelEmbedArray = BrNULL;
	BoraPackagePart* pPart = GetPackagePart(a_szSrcPartName);
	if( pPart )
	{
		PackageRelationshipCollection*	pRelationships = pPart->m_relationships;
		pRelEmbedArray = pRelationships->iterator(a_strPartType);
		if( pRelEmbedArray->size() < 0 )
			return strEmbedChartOrgName;

		PackageRelationship* pRel = BrNULL;
		if( a_pRid  == BrNULL )
			pRel = pRelEmbedArray->at(0);		
		else
		{
			for(BrINT32 i=0; i<(BrINT32)pRelEmbedArray->size(); i++)
			{
				pRel = pRelEmbedArray->at(i);
				if( strcmp(pRel->m_id.data(), a_pRid->data())==0 )
					break;
			}
		}

		if(pRel)
		{
			BString strTarget = pRel->m_targetUri->getPath();
			if( strTarget.isEmpty() == BrFALSE )
			{
				BrINT32 nSlashOffset = strTarget.findRev('/')+1;
				BrINT32 nlength = strTarget.length();

				strEmbedChartOrgName = strTarget.right(nlength - nSlashOffset);
			}
		}

		BrDELETE pRelEmbedArray;
	}

	return strEmbedChartOrgName;
}

//#ifdef USE_SHEET_INTERFACE
//BrBOOL BoraPackageBase::ReadEmbedXlsxByChart(BrCHAR* strSrcPartName, BrCHAR* nEmbedChartID)
//{
//	BrCHAR pChartXmlRelFileName[BORA_FULLPATH_LENGTH] = {0,};
//	BrCHAR pSheetFileName[BORA_FULLPATH_LENGTH] = {0,};
//	BrBOOL bRet = BrFALSE;
//	BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(strSrcPartName);
//	BrBOOL bExistPart = (m_partList->get(pPartName)!=BrNULL);
//
//	BoraPackagePart* pPart = getPart(pPartName);
//	if (pPart)
//	{
//		PackageRelationshipCollection*	pRelationships = pPart->m_relationships;
//		BArray<PackageRelationship*>* pChartRelArray = pRelationships->iterator(CHART_PART_TYPE);
//
//		//  nID �� �ش��ϴ� chart �� ã�� �׿� �����ϴ� xlsx �� �̸��� ����.
//		PackageRelationship* pRel;
//		for(BrINT32 i=0; i<(BrINT32)pChartRelArray->size(); i++)
//		{
//			pRel = pChartRelArray->at(i);
//			if(pRel == BrNULL)
//				continue;
//
//			if( strcmp(pRel->m_id.data(), nEmbedChartID)==0 )
//			{
//				int nChartNum = 0;
//				int nPos = pRel->m_targetUri->getPath().find(".xml");
//				if(nPos < 0)
//					continue;
//
//				int nUnit = 1;
//				const char* pChartXmlName = pRel->m_targetUri->getPath().data();
//				while(--nPos > 0 && pChartXmlName[nPos] >= '0' && pChartXmlName[nPos] <= '9')
//				{
//					nChartNum += nUnit * (pChartXmlName[nPos] - '0');
//					nUnit *= 10;
//				}
//				
//				// read chart.xml.rels
//				BrBOOL bDocx = (strSrcPartName && strncmp(strSrcPartName, "word/", BrStrLen("word/")) == 0) ? BrTRUE : BrFALSE;
//				sprintf(pChartXmlRelFileName, "%s/charts/_rels/chart%d.xml.rels", 
//					(bDocx == BrTRUE) ? "word" : "ppt", nChartNum);
//
//				BrINT32 nMemSize = 0;
//				BrLPBYTE pBuffer = BrNULL;
//				pBuffer = GetEmbedingPackageByPartname((const BrCHAR*)pChartXmlRelFileName, nMemSize);
//				if (pBuffer != BrNULL) {
//					BString str((const char*)pBuffer);
//					int nPos1 = str.find(" Target=\"../embeddings");	// jhc[2012.10.24] - embedding xlsx�� ���� �ٸ� �����̼��� �ִ� ��� crash.
//					int nPos2 = -1;
//					if (nPos1 >= 0)
//					{
//						nPos1 += BrStrLen(" Target=\"..");
//						nPos2 = str.find("\"", nPos1);
//						if (nPos2 >= 0)
//						{
//							sprintf(pSheetFileName, "%s%s", 
//								(bDocx == BrTRUE) ? "word" : "ppt", str.mid(nPos1, nPos2 - nPos1).data());
//						}
//						//[�̻�ȣ][ticket:17731] chart���� embedding ã�°�� ../embeddings/xxx.xlsx sheet Ȯ���� ������ ������ �������� ���� 
//						//Target="../embeddings/oleObject1.bin" oleObject�� ������ �׾������ �̽� ����
//						BString checkOleStr((const char*)pSheetFileName);
//// 						if(checkOleStr.find("oleObject") > 0)
//// 							memset(pSheetFileName, BrFALSE, BrSizeOf(pSheetFileName));
//					}
//
//					BrFree(pBuffer);
//				}
//			}
//		}
//		BrDELETE pChartRelArray;
//
//		// [2012-11-06][Begin] extern chart �� ��� embedding xlsx �� ����
//		if (strcmp(pSheetFileName + BrStrLen(pSheetFileName) - 4, "xlsx") != 0)
//			return BrFALSE;
//		// [2012-11-06][End]
//
//		// embedding xlsx �� ����.
//		if (BrStrLen(pSheetFileName) > 0)
//		{
//			BrINT32 nMemSize = 0;
//			BrLPBYTE pBuffer = BrNULL;
//			pBuffer = GetEmbedingPackageByPartname((const BrCHAR*)pSheetFileName, nMemSize);
//			if (pBuffer != BrNULL) {
//				BrBOOL nRet = BrFALSE;
//				// jhc[2012.12.10] - embedding xlsx ���� parsing ���� ����.
//				xlsBook* pBook = BrNULL;
//				pBook = g_pXLSFrame->book();
//				if (pBook)
//				{	
//					pBook->removeOleResourceFile();
//					// [Dandong][2014-02-21] word, ppt �� �������� chart �� �ִ� ��� image �� ���Ե� embedding xlsx ���� ��Ÿ���� crash ����.
//					// [�̻�ȣ] �Ʒ� �ڵ� ������ 2�� �̻� ��Ʈ �ִ� ����, �� ��Ʈ ���뿡 �̹��� ������ ��� Read�ÿ� �� �� ��Ʈ�� �̹����� ��µǴ� ���� ����
//					// ZPD-5806 ����
//// 					if (pBook->getImageArray()->GetSize())
//// 						pBook->getImageArray()->RemoveAll();
//
//					int nError = 0;
//					BrINT32 nCurSheetIndex = ((xlsxBook*)pBook)->m_nBoundSheet;
//					((xlsxBook*)pBook)->m_bInsideContainer = BrTRUE;
//					((xlsxBook*)pBook)->m_Package.InitEmbedPackageByMem(pBuffer, nMemSize);
//					((xlsxBook*)pBook)->ReadXlsxMain();
//					//pBook->InitBuiltInFormat();
//					//pBook->shrink();
//					//pBook->onNewBook();
//					((xlsxBook*)pBook)->ReadXlsxPage( nCurSheetIndex, &nError);
//					pBook->getSheet(nCurSheetIndex)->setFinishedLoading(BrTRUE);
//					bRet = BrTRUE;
//				}
//				BrFree(pBuffer);
//			}
//		}
//	}
//	if (bExistPart)
//		BrDELETE pPartName;
//
//	return bRet;
//}
//#endif//USE_SHEET_INTERFACE

// jhc[2012.10.26][Mantis:15881] - themeOverride parsing ���� �ڵ� �߰�.
BrBOOL BoraPackageBase::ReadThemeOverrideByChart(LPCallbackParam pCallbackParam, BrCHAR* strSrcPartName, BrCHAR* nEmbedChartID)
{
	BrBOOL bRet = BrFALSE;
	BrLPBYTE pImage=BrNULL;
	BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(strSrcPartName);
	BrBOOL bExistPart = (m_partList->get(pPartName)!=BrNULL);
	BoraPackagePart* pPart = getPart(pPartName);
	if( pPart )
	{
		PackageRelationshipCollection* pRelationships = pPart->m_relationships;
		BArray<PackageRelationship*>* pChartRelArray = pRelationships->iterator(CHART_PART_TYPE);
		//  nID �� �ش��ϴ� chart �� ã�� ����.
		PackageRelationship* pRel;
		for(BrINT32 i=0; i<(BrINT32)pChartRelArray->size(); i++)
		{
			pRel = pChartRelArray->at(i);
			if( strcmp(pRel->m_id.data(), nEmbedChartID)==0 )
			{
				BoraPackagePartName* pPartName1 = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
				BrBOOL bExistPart1 = (m_partList->get(pPartName1)!=BrNULL);
				///////////////////////////////
				BoraPackagePart* pPart1 = getPart(pPartName1);
				if(pPart1) {
					pRelationships = pPart1->m_relationships;
					BArray<PackageRelationship*>* pThemeOverrideRelArray = pRelationships->iterator(THEME_OVERRIDE_PART_TYPE);
					if (pThemeOverrideRelArray->size() > 0) {
						pRel = pThemeOverrideRelArray->at(0);
						BoraPackagePartName* pPartName2 = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
						BrBOOL bExistPart2 = (m_partList->get(pPartName2)!=BrNULL);
						bRet = ReadPackageByPartname(pPartName2->getName().data(), pCallbackParam);
						if (bExistPart2)
							BrDELETE pPartName2;
					}
					BrDELETE pThemeOverrideRelArray;
				}
				///////////////////////////////////
				if( bExistPart1 )
					BrDELETE pPartName1;
				break;
			}
		}
		BrDELETE pChartRelArray;
	}
	if( bExistPart )
		BrDELETE pPartName;

	return bRet;
}
// [Dandong][2013-06-11] - XLSX themeOverride parsing ���� �ڵ� �߰�.
BrBOOL BoraPackageBase::ReadThemeOverrideByChart_XLSX(LPCallbackParam pCallbackParam, BrCHAR* nSheetID, BrCHAR* nChartID, BrBOOL bChartSheetType)
{
	BrBOOL	bRet = BrFALSE;
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);
	if( pRel )
	{
		BoraPackagePart* pPart = getMatchingPart(pRel);
		PackageRelationshipCollection*	pMainDocRelationships = pPart->m_relationships;

		BArray<PackageRelationship*>* pBookRelArray = NULL;
		if (bChartSheetType)
			pBookRelArray = pMainDocRelationships->iterator(CHARTSHEET_PART_TYPE);
		else
			pBookRelArray = pMainDocRelationships->iterator(WORKSHEET_PART_TYPE);

		int size = pBookRelArray->size();
		for(BrINT32 i=0; i<(BrINT32)size; i++)
		{
			pRel = pBookRelArray->at(i);
			if (strcmp(pRel->m_id.data(), nSheetID)==0 )
			{
				BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
				PackagePartItem* pSheetParkItem = m_partList->get(pPartName);
				BoraPackagePart* pSheetPart = NULL;
				if (pSheetParkItem)
				{
					pSheetPart = pSheetParkItem->m_pPackagePart;
					BrDELETE pPartName;
				}
				else
					pSheetPart = getPart(pPartName);

				if (pSheetPart)
				{
					PackageRelationship* pSheetRelationship;
					PackageRelationshipCollection*	pSheetRelationships = pSheetPart->m_relationships;
					BArray<PackageRelationship*>* pSheetRelArray = pSheetRelationships->iterator(DRAWING_PART_TYPE);

					for(BrINT32 i=0; i<(BrINT32)pSheetRelArray->size(); i++)
					{
						pSheetRelationship = pSheetRelArray->at(i);
						BoraPackagePartName* pDrawPartName = PackagingURIHelper::createPartName(pSheetRelationship->m_targetUri->getPath().data());
						PackagePartItem* pDrawtParkItem = m_partList->get(pDrawPartName);
						BoraPackagePart* pDrawPart = NULL;
						if (pDrawtParkItem)
						{
							pDrawPart = pDrawtParkItem->m_pPackagePart;
							BrDELETE pDrawPartName;
						}
						else
							pDrawPart = getPart(pDrawPartName);

						if (pDrawPart)
						{
							PackageRelationship* pDrawRelationship;
							PackageRelationshipCollection*	pDrawRelationships = pDrawPart->m_relationships;
							BArray<PackageRelationship*>* pDrawRelArray = pDrawRelationships->iterator(CHART_PART_TYPE);

							for(BrINT32 i=0; i<(BrINT32)pDrawRelArray->size(); i++)
							{
								pDrawRelationship = pDrawRelArray->at(i);
								if (strcmp(pDrawRelationship->m_id.data(), nChartID)==0 )
								{
									BoraPackagePartName* pChartPartName = PackagingURIHelper::createPartName(pDrawRelationship->m_targetUri->getPath().data());
									BoraPackagePart* pChartPart = getPart(pChartPartName);

									PackageRelationshipCollection* pChartRelationships = pChartPart->m_relationships;
									BArray<PackageRelationship*>* pThemeOverrideRelArray = pChartRelationships->iterator(THEME_OVERRIDE_PART_TYPE);
									if (pThemeOverrideRelArray->size() > 0) {
										PackageRelationship* pThemeOverrideRel = pThemeOverrideRelArray->at(0);
										BoraPackagePartName* ppThemeOverrideRelPartName = PackagingURIHelper::createPartName(pThemeOverrideRel->m_targetUri->getPath().data());
										BrBOOL bExistThemeOverridePart = (m_partList->get(ppThemeOverrideRelPartName)!=BrNULL);
										bRet = ReadPackageByPartname(ppThemeOverrideRelPartName->getName().data(), pCallbackParam);
										if (bExistThemeOverridePart)
											BrDELETE ppThemeOverrideRelPartName;
									}
									BrDELETE pThemeOverrideRelArray;									
									break;
								}
							}
							BrDELETE pDrawRelArray;
						}
					}
					BrDELETE pSheetRelArray;
				}
				break;
			}
		}
		BrDELETE pBookRelArray;
	}

	return bRet;
}

// [Dandong][2014-03-26] Word, PPT���� Chart/Style%d.xml parsing �����ڵ�
BrBOOL BoraPackageBase::ReadChartStyle(LPCallbackParam pCallbackParam, BrCHAR* strSrcPartName, BrCHAR* nEmbedChartID)
{
	BrBOOL bRet = BrFALSE;
	BrLPBYTE pImage=BrNULL;
	BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(strSrcPartName);
	BrBOOL bExistPart = (m_partList->get(pPartName)!=BrNULL);
	BoraPackagePart* pPart = getPart(pPartName);
	if( pPart )
	{
		PackageRelationshipCollection* pRelationships = pPart->m_relationships;
		BArray<PackageRelationship*>* pChartRelArray = pRelationships->iterator(CHART_PART_TYPE);
		//  nID �� �ش��ϴ� chart �� ã�� ����.
		PackageRelationship* pRel;
		for(BrINT32 i=0; i<(BrINT32)pChartRelArray->size(); i++)
		{
			pRel = pChartRelArray->at(i);
			if( strcmp(pRel->m_id.data(), nEmbedChartID)==0 )
			{
				BoraPackagePartName* pPartName1 = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
				BrBOOL bExistPart1 = (m_partList->get(pPartName1)!=BrNULL);
				///////////////////////////////
				BoraPackagePart* pPart1 = getPart(pPartName1);
				if(pPart1) {
					pRelationships = pPart1->m_relationships;
					BArray<PackageRelationship*>* pThemeOverrideRelArray = pRelationships->iterator(CHART_STYLE_PART_TYPE);
					if (pThemeOverrideRelArray->size() > 0) {
						pRel = pThemeOverrideRelArray->at(0);
						BoraPackagePartName* pPartName2 = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
						BrBOOL bExistPart2 = (m_partList->get(pPartName2)!=BrNULL);
						bRet = ReadPackageByPartname(pPartName2->getName().data(), pCallbackParam);
						if (bExistPart2)
							BrDELETE pPartName2;
					}
					BrDELETE pThemeOverrideRelArray;
				}
				///////////////////////////////////
				if( bExistPart1 )
					BrDELETE pPartName1;
				break;
			}
		}
		BrDELETE pChartRelArray;
	}
	if( bExistPart )
		BrDELETE pPartName;

	return bRet;
}

BrBOOL BoraPackageBase::ReadChartRelationFiles_PPTX(BrCHAR* strSrcPartName, BrCHAR* nEmbedChartID, BrBOOL bChartEx)
{
	BrBOOL bRet = BrTRUE;
	BrINT32 nPartIndex = -1;
	BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(strSrcPartName);
	BrBOOL bExistPart = (m_partList->get(pPartName)!=BrNULL);
	BoraPackagePart* pPart = getPart(pPartName);
	if( pPart )
	{
		PackageRelationshipCollection* pRelationships = pPart->m_relationships;
		BArray<PackageRelationship*>* pChartRelArray = BrNULL;
		if(bChartEx)
			pChartRelArray = pRelationships->iterator(CHARTEX_PART_TYPE);
		else
			pChartRelArray = pRelationships->iterator(CHART_PART_TYPE);

		//  nID �� �ش��ϴ� chart �� ã�� ����.
		PackageRelationship* pRel;
		for(BrINT32 i=0; i<(BrINT32)pChartRelArray->size(); i++)
		{
			pRel = pChartRelArray->at(i);
			if( strcmp(pRel->m_id.data(), nEmbedChartID)==0 )
			{
				BoraPackagePartName* pPartName1 = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
				BrBOOL bExistPart1 = (m_partList->get(pPartName1)!=BrNULL);
				///////////////////////////////
				BoraPackagePart* pPart1 = getPart(pPartName1);
				if(pPart1)
				{
					pRelationships = pPart1->m_relationships;
					BArray<PackageRelationship*>* pChartRelItemArray = pRelationships->iterator();
					for(BrINT32 i = 0 ; i < pChartRelItemArray->size() ; i++)
					{
						pRel = pChartRelItemArray->at(i);
						if(pRel && pRel->m_id.data())
						{
							if( pRel->m_targetUri->getPath() )
								nPartIndex = m_pftXMLStorage->GetIndex(pRel->m_targetUri->getPath().data());	

							if(pRel->getTargetMode() == EXTERNAL)
								continue;

							if(nPartIndex == -1)
							{
								bRet = BrFALSE;
								break;
							}
						}
					}
					BrDELETE pChartRelItemArray;
				}
				else
				{
					bRet = BrFALSE;
				}
				///////////////////////////////////
				if( bExistPart1 )
					BrDELETE pPartName1;
				break;
			}
		}
		BrDELETE pChartRelArray;
	}
	if( bExistPart )
		BrDELETE pPartName;

	return bRet;
}

BrBOOL BoraPackageBase::ReadChartStyle_XLSX(LPCallbackParam pCallbackParam, BrCHAR* nSheetID, BrCHAR* nChartID, BrBOOL bChartSheetType)
{
	BrBOOL	bRet = BrFALSE;
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);
	if( pRel )
	{
		BoraPackagePart* pPart = getMatchingPart(pRel);
		PackageRelationshipCollection*	pMainDocRelationships = pPart->m_relationships;

		BArray<PackageRelationship*>* pBookRelArray = NULL;
		if (bChartSheetType)
			pBookRelArray = pMainDocRelationships->iterator(CHARTSHEET_PART_TYPE);
		else
			pBookRelArray = pMainDocRelationships->iterator(WORKSHEET_PART_TYPE);

		int size = pBookRelArray->size();
		for(BrINT32 i=0; i<(BrINT32)size; i++)
		{
			pRel = pBookRelArray->at(i);
			if (strcmp(pRel->m_id.data(), nSheetID)==0 )
			{
				BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
				PackagePartItem* pSheetParkItem = m_partList->get(pPartName);
				BoraPackagePart* pSheetPart = NULL;
				if (pSheetParkItem)
				{
					pSheetPart = pSheetParkItem->m_pPackagePart;
					BrDELETE pPartName;
				}
				else
					pSheetPart = getPart(pPartName);

				if (pSheetPart)
				{
					PackageRelationship* pSheetRelationship;
					PackageRelationshipCollection*	pSheetRelationships = pSheetPart->m_relationships;
					BArray<PackageRelationship*>* pSheetRelArray = pSheetRelationships->iterator(DRAWING_PART_TYPE);

					for(BrINT32 i=0; i<(BrINT32)pSheetRelArray->size(); i++)
					{
						pSheetRelationship = pSheetRelArray->at(i);
						BoraPackagePartName* pDrawPartName = PackagingURIHelper::createPartName(pSheetRelationship->m_targetUri->getPath().data());
						PackagePartItem* pDrawtParkItem = m_partList->get(pDrawPartName);
						BoraPackagePart* pDrawPart = NULL;
						if (pDrawtParkItem)
						{
							pDrawPart = pDrawtParkItem->m_pPackagePart;
							BrDELETE pDrawPartName;
						}
						else
							pDrawPart = getPart(pDrawPartName);

						if (pDrawPart)
						{
							PackageRelationship* pDrawRelationship;
							PackageRelationshipCollection*	pDrawRelationships = pDrawPart->m_relationships;
							BArray<PackageRelationship*>* pDrawRelArray = pDrawRelationships->iterator(CHART_PART_TYPE);

							for(BrINT32 i=0; i<(BrINT32)pDrawRelArray->size(); i++)
							{
								pDrawRelationship = pDrawRelArray->at(i);
								if (strcmp(pDrawRelationship->m_id.data(), nChartID)==0 )
								{
									BoraPackagePartName* pChartPartName = PackagingURIHelper::createPartName(pDrawRelationship->m_targetUri->getPath().data());
									BoraPackagePart* pChartPart = getPart(pChartPartName);

									PackageRelationshipCollection* pChartRelationships = pChartPart->m_relationships;
									BArray<PackageRelationship*>* pThemeOverrideRelArray = pChartRelationships->iterator(CHART_STYLE_PART_TYPE);
									if (pThemeOverrideRelArray->size() > 0) {
										PackageRelationship* pThemeOverrideRel = pThemeOverrideRelArray->at(0);
										BoraPackagePartName* ppThemeOverrideRelPartName = PackagingURIHelper::createPartName(pThemeOverrideRel->m_targetUri->getPath().data());
										BrBOOL bExistThemeOverridePart = (m_partList->get(ppThemeOverrideRelPartName)!=BrNULL);
										bRet = ReadPackageByPartname(ppThemeOverrideRelPartName->getName().data(), pCallbackParam);
										if (bExistThemeOverridePart)
											BrDELETE ppThemeOverrideRelPartName;
									}
									BrDELETE pThemeOverrideRelArray;									
									break;
								}
							}
							BrDELETE pDrawRelArray;
						}
					}
					BrDELETE pSheetRelArray;
				}
				break;
			}
		}
		BrDELETE pBookRelArray;
	}

	return bRet;
}

BrBOOL BoraPackageBase::ReadChartUserShapes(LPCallbackParam pCallbackParam, BrCHAR* strSrcPartName, BrCHAR* nEmbedChartID)
{
	BrBOOL bRet = BrFALSE;
	BrLPBYTE pImage=BrNULL;
	BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(strSrcPartName);
	BrBOOL bExistPart = (m_partList->get(pPartName)!=BrNULL);
	BoraPackagePart* pPart = getPart(pPartName);
	if( pPart )
	{
		PackageRelationshipCollection* pRelationships = pPart->m_relationships;
		BArray<PackageRelationship*>* pChartRelArray = pRelationships->iterator(CHART_PART_TYPE);
		//  nID �� �ش��ϴ� chart �� ã�� ����.
		PackageRelationship* pRel;
		for(BrINT32 i=0; i<(BrINT32)pChartRelArray->size(); i++)
		{
			pRel = pChartRelArray->at(i);
			if( strcmp(pRel->m_id.data(), nEmbedChartID)==0 )
			{
				BoraPackagePartName* pPartName1 = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
				BrBOOL bExistPart1 = (m_partList->get(pPartName1)!=BrNULL);
				///////////////////////////////
				BoraPackagePart* pPart1 = getPart(pPartName1);
				if(pPart1) {
					pRelationships = pPart1->m_relationships;
					BArray<PackageRelationship*>* pUserShapesRelArray = pRelationships->iterator(CHART_USER_SHAPES_PART_TYPE);
					if (pUserShapesRelArray->size() > 0) {
						pRel = pUserShapesRelArray->at(0);
						BoraPackagePartName* pPartName2 = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
						BrBOOL bExistPart2 = (m_partList->get(pPartName2)!=BrNULL);
						if( !bExistPart2 )
							getPart(pPartName2);
						bRet = ReadPackageByPartname(pPartName2->getName().data(), pCallbackParam);
						if (bExistPart2)
							BrDELETE pPartName2;
					}
					BrDELETE pUserShapesRelArray;
				}
				///////////////////////////////////
				if( bExistPart1 )
					BrDELETE pPartName1;
				break;
			}
		}
		BrDELETE pChartRelArray;
	}
	if( bExistPart )
		BrDELETE pPartName;

	return bRet;
}

BrBOOL BoraPackageBase::ReadChartUserShapes_XLSX(LPCallbackParam pCallbackParam, BrCHAR* nSheetID, BrCHAR* nChartID, BrBOOL bChartSheetType)
{
	BrBOOL	bRet = BrFALSE;
	PackageRelationship* pRel = m_relationships->relationshipsByType_get(CORE_DOCUMENT_PART_TYPE);
	if( pRel )
	{
		BoraPackagePart* pPart = getMatchingPart(pRel);
		PackageRelationshipCollection*	pMainDocRelationships = pPart->m_relationships;

		BArray<PackageRelationship*>* pBookRelArray = NULL;
		if (bChartSheetType)
			pBookRelArray = pMainDocRelationships->iterator(CHARTSHEET_PART_TYPE);
		else
			pBookRelArray = pMainDocRelationships->iterator(WORKSHEET_PART_TYPE);

		int size = pBookRelArray->size();
		for(BrINT32 i=0; i<(BrINT32)size; i++)
		{
			pRel = pBookRelArray->at(i);
			if (strcmp(pRel->m_id.data(), nSheetID)==0 )
			{
				BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(pRel->m_targetUri->getPath().data());
				PackagePartItem* pSheetParkItem = m_partList->get(pPartName);
				BoraPackagePart* pSheetPart = NULL;
				if (pSheetParkItem)
				{
					pSheetPart = pSheetParkItem->m_pPackagePart;
					BrDELETE pPartName;
				}
				else
					pSheetPart = getPart(pPartName);

				if (pSheetPart)
				{
					PackageRelationship* pSheetRelationship;
					PackageRelationshipCollection*	pSheetRelationships = pSheetPart->m_relationships;
					BArray<PackageRelationship*>* pSheetRelArray = pSheetRelationships->iterator(DRAWING_PART_TYPE);

					for(BrINT32 i=0; i<(BrINT32)pSheetRelArray->size(); i++)
					{
						pSheetRelationship = pSheetRelArray->at(i);
						BoraPackagePartName* pDrawPartName = PackagingURIHelper::createPartName(pSheetRelationship->m_targetUri->getPath().data());
						PackagePartItem* pDrawtParkItem = m_partList->get(pDrawPartName);
						BoraPackagePart* pDrawPart = NULL;
						if (pDrawtParkItem)
						{
							pDrawPart = pDrawtParkItem->m_pPackagePart;
							BrDELETE pDrawPartName;
						}
						else
							pDrawPart = getPart(pDrawPartName);

						if (pDrawPart)
						{
							PackageRelationship* pDrawRelationship;
							PackageRelationshipCollection*	pDrawRelationships = pDrawPart->m_relationships;
							BArray<PackageRelationship*>* pDrawRelArray = pDrawRelationships->iterator(CHART_PART_TYPE);

							for(BrINT32 i=0; i<(BrINT32)pDrawRelArray->size(); i++)
							{
								pDrawRelationship = pDrawRelArray->at(i);
								if (strcmp(pDrawRelationship->m_id.data(), nChartID)==0 )
								{
									BoraPackagePartName* pChartPartName = PackagingURIHelper::createPartName(pDrawRelationship->m_targetUri->getPath().data());
									BoraPackagePart* pChartPart = getPart(pChartPartName);

									PackageRelationshipCollection* pChartRelationships = pChartPart->m_relationships;
									BArray<PackageRelationship*>* pThemeOverrideRelArray = pChartRelationships->iterator(CHART_STYLE_PART_TYPE);
									if (pThemeOverrideRelArray->size() > 0) {
										PackageRelationship* pThemeOverrideRel = pThemeOverrideRelArray->at(0);
										BoraPackagePartName* ppThemeOverrideRelPartName = PackagingURIHelper::createPartName(pThemeOverrideRel->m_targetUri->getPath().data());
										BrBOOL bExistThemeOverridePart = (m_partList->get(ppThemeOverrideRelPartName)!=BrNULL);
										bRet = ReadPackageByPartname(ppThemeOverrideRelPartName->getName().data(), pCallbackParam);
										if (bExistThemeOverridePart)
											BrDELETE ppThemeOverrideRelPartName;
									}
									BrDELETE pThemeOverrideRelArray;									
									break;
								}
							}
							BrDELETE pDrawRelArray;
						}
					}
					BrDELETE pSheetRelArray;
				}
				break;
			}
		}
		BrDELETE pBookRelArray;
	}

	return bRet;
}

//////////////////////////////////////////////////////////////////////////////////////////
///////���������ڵ� �߰� 2011.02.09 hnsong////////////////////////////////////////////////
///////BrXmlLoader ���� call��!		//////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
#include "BrCeZip.h"
BString* BoraPackageBase::savePartFile(const BrCHAR *pPartFileName, BrCHAR *pSaveFileName, BrBOOL* pSaveReg, BrBOOL bDoNotUseBlockZip, BrCHAR *pSaveThmxName, int pSaveThmxNameSize, BrBOOL bIsMediaFile, BrBOOL bIsAddExceptFile)
{
	BrBOOL bRet=BrFALSE;

	if(pSaveReg)
		*pSaveReg = BrTRUE;
	BrUINT32 nPartIndex = m_pftXMLStorage->GetIndex(pPartFileName);
	if(nPartIndex == 0xffffffff)
		return BrNULL;

	BString *pFileName = BrNEW BString(CUtil::UTF8ToBString((BrCHAR*)BrGetTempPath()));
	//if( pFileName->findRev('/') != pFileName->length()-1)
	//	pFileName->append('/');

	BrCHAR szPartFileName[BORA_FULLPATH_LENGTH]={0,};
	strncpy_s(szPartFileName, sizeof(szPartFileName),pPartFileName, strlen(pPartFileName));
	if( pSaveFileName)
	{
		if(bIsMediaFile)
			pFileName->append("media/");

		pFileName->append(pSaveFileName);
#ifdef USE_MCORE_XSAVE
		// [2013.10.08][�赵��] Xsave �����̵� ���� �� ���� �̽�
		// pPartFileName�� ���� �̸��� pSaveFileName���� ���� �� ����		
		if(getDocExt() != BORA_EXT_ODT && getDocExt() != BORA_EXT_ODP)
		{
			BrBOOL bRetReplace = BrFALSE;
			if(pSaveThmxName)
				bRetReplace = BrReplaceFileNameFromPath(pSaveThmxName, pSaveThmxNameSize, pSaveFileName);
			else
				bRetReplace = BrReplaceFileNameFromPath(szPartFileName, sizeof(szPartFileName), pSaveFileName);

			if(bRetReplace == BrFALSE) BRTHREAD_ASSERT(0);
		}
#endif //USE_MCORE_XSAVE
	}
	else {
		//[2013.04.26][Dandong] chart�� drawing1.xml������ �ִ°�� �ߺ��Ǵ°��� ���� ���� Smartart diagram�� �� Folder�� ����� �����Ѵ�...
#if 1	//Andrew C.Lee BString���� ��ȯ�Ͽ� append�ϵ��� ����
		int nPos = -1;
		BString strTempName = CUtil::UTF8ToBString(pPartFileName), strNext, strRemain;
		if ( (nPos = strTempName.find("/")) > 0 )
			strNext = strTempName.mid(nPos+1);
		if ( strNext.find("diagrams") == 0 )
			pFileName->append(strNext);
		else
		{
			if ( (nPos = strTempName.findRev("/")) > 0 )
			{
				strRemain = strTempName.mid(nPos+1);
				pFileName->append(strRemain);
			}
		}
#else
		BrCHAR* temp = (BrCHAR*)strpbrk((char*)pPartFileName, "/");
		++temp;
		if (!strncmp(temp, "diagrams", 8))
			pFileName->append(temp);
		else
			pFileName->append(strrchr(pPartFileName, '/')+1);
#endif
	}

	PO_THREAD_TRY_BLOCK {
#if defined(SUPPORT_MULTICORE) && defined(USE_MCORE_XSAVE)
		BrBYTE nError = eMCORE_NOTSUPPORT_ETYPE;
		if(!m_pftXMLStorage->GetBlockZip() && m_pftXMLStorage->m_oZipInfo.hZipFile && !bDoNotUseBlockZip)
			m_pftXMLStorage->SetBlockZip();
		
		if(m_pftXMLStorage->GetBlockZip() && !bDoNotUseBlockZip)
		{
			//Andrew C.Lee ���ϸ��� ���� utf8�� ��ȯ�Ͽ� ó����
			BrAutoChar autoPath = CUtil::convertBStringToChar(pFileName, CP_UTF8);
			char* pAutoPath = autoPath.get();
			
			if(pSaveThmxName)
				nError = BrSetXSaveFileExtZipMCoreEvent(pSaveThmxName, (BrCHAR*)pAutoPath, "", m_pftXMLStorage->GetBlockZip(), nPartIndex);
			else
				nError = BrSetXSaveFileExtZipMCoreEvent(szPartFileName, (BrCHAR*)pAutoPath, "", m_pftXMLStorage->GetBlockZip(), nPartIndex);
			if(nError == eMCORE_NO_ETYPE)
			{
				if(pSaveReg)
					*pSaveReg = BrFALSE;
				bRet = BrTRUE;
			}		
			else if(nError == eMCORE_NOTSUPPORT_ETYPE)
			{			
				bRet = BrZipExtractUserFile("", m_pftXMLStorage->m_oZipInfo.hZipFile, nPartIndex, pAutoPath, strlen(pAutoPath)+1);	

				//if ( bRet == BrTRUE )
				//{
				//	pFileName->setLength(0);
				//	pFileName->append(pAutoPath);
				//}
			}	
			else
				bRet = BrFALSE;
		}
		else
		{
			BrAutoChar autoPath = CUtil::convertBStringToChar(pFileName, CP_UTF8);
			char* pAutoPath = autoPath.get();
			bRet = BrZipExtractUserFile("", m_pftXMLStorage->m_oZipInfo.hZipFile, nPartIndex, pAutoPath, strlen(pAutoPath)+1);	

			//if ( bRet == BrTRUE )
			//{
			//	pFileName->setLength(0);
			//	pFileName->append(pAutoPath);
			//}
		}
#else //SUPPORT_MULTICORE && USE_MCORE_XSAVE
		BrAutoChar autoPath = CUtil::convertBStringToChar(pFileName, CP_UTF8);
		char* pAutoPath = autoPath.get();

		//[EMO-1031][Ryan] Memory Open �� FileList �߰�
		//[WO-1766][minseob] �̵�� ������ ���󿡼��� �޸� ������ �ʿ��Ͽ� ���� ��Ͽ� �߰����� �ʵ��� ó��
		if (bIsMediaFile)
			bIsAddExceptFile = BrFALSE;

		if (bIsAddExceptFile) {
			AdjustPathSeparator(pAutoPath);
			AddExceptFileList(pAutoPath);
		}

		bRet = BrZipExtractUserFile("", m_pftXMLStorage->m_oZipInfo.hZipFile, nPartIndex, pAutoPath, strlen(pAutoPath)+1);	
		//if ( bRet == BrTRUE )
		//{
		//	pFileName->setLength(0);
		//	pFileName->append(pAutoPath);
		//}
#endif //SUPPORT_MULTICORE

#ifdef ZIP_FILE_DEBUG  
		char* szTempPath = (char*)BrGetTempPath();
		if (strcmp(szTempPath, pFileName->data()) == 0)
		{
			//Extra �� ������ TempPath �� ���� �� �����ϴ� ��θ� Ȯ�� �ٶ��ϴ�.
			BRTHREAD_ASSERT(BrFALSE);
			ERR_TRACE_EX(kPoErrOrgFileNotFound);
		}
#endif

	} PO_THREAD_CATCH_BLOCK { 	
		BrDELETE pFileName;
		pFileName = BrNULL;
	} PO_THREAD_END

	if( !bRet ) 
	{
		BrDELETE pFileName;
		pFileName = BrNULL;
	}

	return pFileName;
}

BString BoraPackageBase::GetPathAndFileName(BString strPartName, BString strRelID)
{
	if(strPartName.length() == 0 || strRelID == 0)
		return BString();

	BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(strPartName);
	BoraPackagePart* pPackagePart = getPart(pPartName);
	PackageRelationshipCollection* pRelationships = pPackagePart->m_relationships;
	BString strFileName;
	BrINT32 nRelationCount = pRelationships->size();
	for(BrINT32 nRelIndex = 0; nRelIndex <nRelationCount; nRelIndex++)
	{
		PackageRelationship* pRel = pRelationships->getRelationship(nRelIndex);
		if(!pRel->getId().compare(strRelID))
		{
			strFileName = pRel->m_targetUri->getPath();
			break;
		}
	}

	return strFileName;
}

BrBOOL BoraPackageBase::GetDocxEmbeddedFontData(CDocxFontEmbedData* docxFontData)
{
	if (BrNULL == docxFontData)
		return BrFALSE;

#ifdef IMPORT_DOCX
	// common���� bwp�� ȣ���� ���� Ȯ�� �ʿ�
	BString fontDataRel = docxFontData->getRID();
	//  /word/fonttable.xml.rel
	BString fontPartName("word/fontTable.xml");
	BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(fontPartName);
	if (BrNULL == pPartName)
		return BrTRUE;

	BrBOOL bNewPart = BrFALSE;
	BoraPackagePart* pFontPart = getPart(pPartName, &bNewPart);
	PackageRelationshipCollection* pFontTableRelationships = pFontPart? pFontPart->m_relationships: BrNULL;
	if (BrNULL == pFontTableRelationships)
		return BrTRUE;

	BArray<PackageRelationship*>* pFontRelArray = pFontTableRelationships->iterator(FONT_PART_TYPE);
	if (BrNULL == pFontRelArray)
		return BrTRUE;

	for (BrINT32 i = 0; i < pFontRelArray->size(); i++) {
		PackageRelationship* fontRel = pFontRelArray->at(i);
		if (fontRel && strcmp(fontRel->m_id.data(), fontDataRel.data()) == 0)
		{
			BrLPBYTE pData = BrNULL;
			BrINT nLen = m_pftXMLStorage->GetZipItemStream(fontRel->m_targetUri->getPath().data(), pData);
			docxFontData->setOdttfData(pData, nLen);
			BR_SAFE_FREE(pData);
		}
	}

	BrDELETE pFontRelArray;  // coverity 101120 Resource leak
	return BrTRUE;
#else
    return BrFALSE;
#endif
}

#endif //SUPPORT_XML_PARSER
