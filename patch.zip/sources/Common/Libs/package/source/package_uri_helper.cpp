#include <OfficePreComp.hpp>

#ifdef SUPPORT_XML_PARSER



#include "package_partname.h"
#include "package_uri_helper.h"
#include "binterfacehandle.h"


#ifndef NOT_USE_GLOBAL_VARIABLE
Bora_URI* PackagingURIHelper::BoraPackageRootUri = BrNULL;
Bora_URI* PackagingURIHelper::PACKAGE_RELATIONSHIPS_ROOT_URI = BrNULL;
BoraPackagePartName* PackagingURIHelper::PACKAGE_RELATIONSHIPS_ROOT_PART_NAME = BrNULL;
Bora_URI* PackagingURIHelper::CORE_PROPERTIES_URI = BrNULL;
BoraPackagePartName* PackagingURIHelper::CORE_PROPERTIES_PART_NAME = BrNULL;
Bora_URI* PackagingURIHelper::PACKAGE_ROOT_URI = BrNULL;
BoraPackagePartName* PackagingURIHelper::PACKAGE_ROOT_PART_NAME = BrNULL;
#endif //!NOT_USE_GLOBAL_VARIABLE

PackagingURIHelper::PackagingURIHelper()
{
	// Make URI
	Bora_URI* uriPACKAGE_ROOT_URI = BrNULL;
	Bora_URI* uriPACKAGE_RELATIONSHIPS_ROOT_URI = BrNULL;
	Bora_URI* uriPACKAGE_PROPERTIES_URI = BrNULL;

	uriPACKAGE_ROOT_URI = BrNEW Bora_URI("/");
	uriPACKAGE_RELATIONSHIPS_ROOT_URI = BrNEW Bora_URI(BString(FORWARD_SLASH_CHAR)
					+ RELATIONSHIP_PART_SEGMENT_NAME + FORWARD_SLASH_CHAR
					+ RELATIONSHIP_PART_EXTENSION_NAME);
	BoraPackageRootUri = BrNEW Bora_URI("/");
	uriPACKAGE_PROPERTIES_URI = BrNEW Bora_URI(BString(FORWARD_SLASH_CHAR)
					+ PACKAGE_PROPERTIES_SEGMENT_NAME + FORWARD_SLASH_CHAR
					+ PACKAGE_CORE_PROPERTIES_NAME);

	PACKAGE_ROOT_URI = uriPACKAGE_ROOT_URI;
	PACKAGE_RELATIONSHIPS_ROOT_URI = uriPACKAGE_RELATIONSHIPS_ROOT_URI;
	CORE_PROPERTIES_URI = uriPACKAGE_PROPERTIES_URI;

	// Make part name from previous URI
	BoraPackagePartName* tmpPACKAGE_ROOT_PART_NAME = BrNULL;
	BoraPackagePartName* tmpPACKAGE_RELATIONSHIPS_ROOT_PART_NAME = BrNULL;
	BoraPackagePartName* tmpCORE_PROPERTIES_URI = BrNULL;

	tmpPACKAGE_RELATIONSHIPS_ROOT_PART_NAME = createPartName(PACKAGE_RELATIONSHIPS_ROOT_URI);
	tmpCORE_PROPERTIES_URI = createPartName(CORE_PROPERTIES_URI);
	tmpPACKAGE_ROOT_PART_NAME = createPartName(PACKAGE_ROOT_URI);

	PACKAGE_RELATIONSHIPS_ROOT_PART_NAME = tmpPACKAGE_RELATIONSHIPS_ROOT_PART_NAME;
	CORE_PROPERTIES_PART_NAME = tmpCORE_PROPERTIES_URI;
	PACKAGE_ROOT_PART_NAME = tmpPACKAGE_ROOT_PART_NAME;
}

PackagingURIHelper::~PackagingURIHelper()
{
	BrDELETE BoraPackageRootUri;
	BoraPackageRootUri = BrNULL;
	BrDELETE PACKAGE_RELATIONSHIPS_ROOT_URI;
	PACKAGE_RELATIONSHIPS_ROOT_URI = BrNULL;
	BrDELETE PACKAGE_RELATIONSHIPS_ROOT_PART_NAME;
	PACKAGE_RELATIONSHIPS_ROOT_PART_NAME = BrNULL;
	BrDELETE CORE_PROPERTIES_URI;
	CORE_PROPERTIES_URI = BrNULL;
	BrDELETE CORE_PROPERTIES_PART_NAME;
	CORE_PROPERTIES_PART_NAME = BrNULL;
	BrDELETE PACKAGE_ROOT_URI;
	PACKAGE_ROOT_URI = BrNULL;
	BrDELETE PACKAGE_ROOT_PART_NAME;
	PACKAGE_ROOT_PART_NAME = BrNULL;
}

BoraPackagePartName* PackagingURIHelper::createPartName(Bora_URI* partUri)
{
	if (partUri == BrNULL)
	{
#ifdef BORA_THREAD_SUPPORT
			BRTHREAD_ASSERT(BrFALSE);
#endif
			return BrNULL;
	}

	return BrNEW BoraPackagePartName(partUri, BrTRUE);
}

BoraPackagePartName* PackagingURIHelper::createPartName(BString partName)
{
	BTrace("%s(%d) %s partName.data()[%s]", __FILE__, __LINE__, __FUNCTION__, partName.data());
	
	Bora_URI partNameURI(partName);
	BTrace("%s(%d) %s partNameURI.getPath().data()[%s]", __FILE__, __LINE__, __FUNCTION__, partNameURI.getPath().data());
		
	return createPartName(&partNameURI);
}

Bora_URI* PackagingURIHelper::GetPackageRootUri() 
{
	return BoraPackageRootUri;
}

BrBOOL PackagingURIHelper::IsRelationshipPartURI(Bora_URI* partUri) 
{
	if (partUri == BrNULL)
		return BrFALSE;

	if( partUri->path().contains(RELATIONSHIP_PART_SEGMENT_NAME) && 
		partUri->fileName().right(strlen(RELATIONSHIP_PART_EXTENSION_NAME))==RELATIONSHIP_PART_EXTENSION_NAME )
		return BrTRUE;
	return BrFALSE;
}

BString PackagingURIHelper::GetFilename(Bora_URI* uri) 
{
	if (uri != BrNULL) 
	{
		BString path = uri->path();
		BrINT32 len = path.length();
		BrINT32 num2 = len;
		while (--num2 >= 0) 
		{
			BrCHAR ch1 = path.at(num2);
			if (ch1 == FORWARD_SLASH_CHAR)
				return path.right(len-(num2 + 1));
		}
		return path;
	}
	return "";
}

BString PackagingURIHelper::GetFilenameWithoutExtension(Bora_URI* uri) 
{
	BString filename = GetFilename(uri);
	BrINT32 dotIndex = filename.findRev('.');
	if (dotIndex == -1)
		return filename;
	return filename.left(dotIndex);
}

Bora_URI* PackagingURIHelper::GetPath(Bora_URI* uri) 
{
	if (uri != BrNULL) 
	{
		BString path = uri->path();
		BrINT32 len = path.length();
		BrINT32 num2 = len;
		while (--num2 >= 0) 
		{
			BrCHAR ch1 = path.at(num2);
			if (ch1 == FORWARD_SLASH_CHAR) 
			{
				return BrNEW Bora_URI(path.left(num2));
			}
		}
	}
	return BrNULL;
}

Bora_URI* PackagingURIHelper::combine(Bora_URI* prefix, Bora_URI* suffix) 
{
	return BrNEW Bora_URI(combine(prefix->path(), suffix->path()));
}

BString PackagingURIHelper::combine(BString prefix, BString suffix) 
{
	if( prefix[(BrINT32)prefix.length()-1] != FORWARD_SLASH_CHAR &&
		suffix[0] != FORWARD_SLASH_CHAR )
	{
		return prefix + FORWARD_SLASH_CHAR + suffix;
	}
	else if( prefix[(BrINT32)prefix.length()-1] != FORWARD_SLASH_CHAR && suffix[0] == FORWARD_SLASH_CHAR ||
			 (prefix[(BrINT32)prefix.length()-1] == FORWARD_SLASH_CHAR && suffix[0] != FORWARD_SLASH_CHAR) )
	{
		 return prefix + suffix;
	}
	else
		return "";
}

Bora_URI* PackagingURIHelper::RelativizeURI(Bora_URI* sourceURI, Bora_URI* targetURI) 
{
	BString retVal;
	BString strSource = sourceURI->path();
	BString strTarget = targetURI->path();
	BArray<BString*> segmentsSource = SplitBySep(strSource, '/');
	BArray<BString*> segmentsTarget = SplitBySep(strTarget, '/');

	if (segmentsSource.size() == 0)
			return BrNULL;

	// If target URI is empty
	if (segmentsTarget.size() == 0) 
	{
		if (sourceURI->path()[0]==FORWARD_SLASH_STRING) 
		{
			return BrNEW Bora_URI(sourceURI->path().left(1));
		} 
		else
		{
			Bora_URI* newSourceURI = BrNEW Bora_URI();
			*newSourceURI=*sourceURI;
			return newSourceURI;
		}
	}

	BrINT32 i, j;
	// Relativize the source URI against the target URI.
	for (i = 0, j = 0; i < (BrINT32)segmentsSource.size()
				&& j < (BrINT32)segmentsTarget.size(); ++i, ++j) 
	{
		if (strcmp(segmentsSource[i]->lower().data(), segmentsTarget[j]->lower().data())==0) 
		{
			if (i < (BrINT32)segmentsSource.size() - 1) 
			{
				continue;
			} 
			else 
			{
				// We add the last segment whatever it happens
				retVal.append(BChar('/'));
				retVal.append(*segmentsTarget[i]);
				break;
			}
		} 
		else 
		{
			for (; i < (BrINT32)segmentsSource.size(); ++i) 
			{
				retVal.append(BChar('/'));
				retVal.append(*segmentsSource[i]);
			}
			break;
		}
	}

	for(i=0; i<(BrINT32)segmentsSource.size(); i++)
		BrDELETE segmentsSource[i];
	for(i=0; i<(BrINT32)segmentsTarget.size(); i++)
		BrDELETE segmentsTarget[i];

	BoraPackagePartName retPartName(retVal, BrTRUE);
	return BrNEW Bora_URI(retPartName.getURI()->path().left(1));
}

Bora_URI* PackagingURIHelper::ResolvePartUri(Bora_URI* sourcePartUri, Bora_URI* targetUri) 
{
	if (sourcePartUri == BrNULL || !sourcePartUri->isRelativeUrl(sourcePartUri->getUrl()) ) 
	{
		return BrNULL;
	}

	if (targetUri == BrNULL || !targetUri->isRelativeUrl(targetUri->getUrl())) 
	{
		return BrNULL;
	}

	return targetUri->Resolve(sourcePartUri);
}

Bora_URI* PackagingURIHelper::getURIFromPath(BString path) 
{
	return BrNEW Bora_URI(path);
}

Bora_URI* PackagingURIHelper::getSourcePartUriFromRelationshipPartUri(Bora_URI* relationshipPartUri) 
{
	if (relationshipPartUri == BrNULL)
	{
		SET_INFO_LOG("Le param?re relationshipPartUri ne doit pas ?re null !");
#ifdef BORA_THREAD_SUPPORT
		BRTHREAD_ASSERT(BrFALSE);
#endif
		return BrNULL;
	}

	if (!IsRelationshipPartURI(relationshipPartUri))
	{
		SET_INFO_LOG("L'URI ne doit pas ?re celle d'une partie de type relation.");
#ifdef BORA_THREAD_SUPPORT
		BRTHREAD_ASSERT(BrFALSE);
#endif
		return BrNULL;
	}

	if (relationshipPartUri==PACKAGE_RELATIONSHIPS_ROOT_URI)
		return PACKAGE_ROOT_URI;

	BString filename = relationshipPartUri->path();
	BString filenameWithoutExtension = GetFilenameWithoutExtension(relationshipPartUri);
	filename = filename.left(((filename.length() - filenameWithoutExtension.length()) - strlen(RELATIONSHIP_PART_EXTENSION_NAME)));
	filename = filename.left(filename.length() - strlen(RELATIONSHIP_PART_SEGMENT_NAME) - 1);
	filename = combine(filename, filenameWithoutExtension);
	return getURIFromPath(filename);
}

BoraPackagePartName* PackagingURIHelper::createPartName(BString partName, BoraPackagePart* relativePart) 
{
//BoraPackagePart ������ �� ����
#pragma message("!!!! need to implement PackagingURIHelper::createPartName")
#ifdef BORA_THREAD_SUPPORT
	BRTHREAD_ASSERT(BrFALSE);
	return BrNULL;
#else
	return BrNULL;
#endif
#if 0
	BoraPackagePartName* pRet;
	Bora_URI* newPartNameURI;
	Bora_URI tmpURI(partName);

	newPartNameURI = ResolvePartUri(relativePart->getPartName()->getURI(), &tmpURI);

	pRet = createPartName(newPartNameURI);

	BrDELETE newPartNameURI;

	return pRet;
#endif
}

BoraPackagePartName* PackagingURIHelper::createPartName(Bora_URI* partName, BoraPackagePart* relativePart) 
{
//BoraPackagePart ������ �� ����
#pragma message("!!!! need to implement PackagingURIHelper::createPartName")
#ifdef BORA_THREAD_SUPPORT
	BRTHREAD_ASSERT(BrFALSE);
	return BrNULL;
#else
	return BrNULL;
#endif
#if 0
	Bora_URI* newPartNameURI = resolvePartUri(relativePart->getPartName()->getURI(), partName);
	BoraPackagePartName* pRet;
	pRet = createPartName(newPartNameURI);
	return pRet;
#endif
}

BrBOOL PackagingURIHelper::IsValidPartName(Bora_URI* partUri) 
{
	if (partUri == BrNULL) {
#ifdef BORA_THREAD_SUPPORT
		BRTHREAD_ASSERT(BrFALSE);
#endif
		return BrFALSE;
	}

#if 1  // converity 22575 resource leak & logically dead
	return BrTRUE;
#else
	BoraPackagePartName* p = createPartName(partUri);
	if( p )
		return BrTRUE;
	return BrFALSE;
#endif
}

BString PackagingURIHelper::DecodeURI(Bora_URI* uri) 
{
	BString retVal;
	BString uriStr = uri->getUrl();
	BrCHAR c;
	BrCHAR	buf[8];

	for (BrINT32 i = 0; i < (BrINT32)uriStr.length(); ++i) 
	{
		c = uriStr.at(i);
		if (c == '%') {
			// We certainly found an encoded character, check for length
			// now ( '%' HEXDIGIT HEXDIGIT)
			if (((uriStr.length() - i) < 2)) 
			{
				SET_INFO_LOG("contain invalid encoded character !");
#ifdef BORA_THREAD_SUPPORT
				BRTHREAD_ASSERT(BrFALSE);
#endif
				return "";
			}

			// Decode the encoded character
			memset(buf, 0, 8);
			buf[0] = uriStr[i+1].latin1();
			buf[1] = uriStr[i+2].latin1();
			i += 2;

			// Decode the encoded character
			BrCHAR decodedChar = (BrCHAR) BrAtoX(buf);
			retVal.append(decodedChar);
			i += 2;
			continue;
		}
		retVal.append(c);
	}
	return retVal;
}

BoraPackagePartName* PackagingURIHelper::GetRelationshipPartName(BoraPackagePartName* partName) 
{
	if (partName == BrNULL)
	{
		return BrNULL;
	}

#ifdef NOT_USE_GLOBAL_VARIABLE
	if (g_pBInterfaceHandle->m_PACKAGE_ROOT_URI && g_pBInterfaceHandle->m_PACKAGE_ROOT_URI->path() == partName->getURI()->path() )
		return g_pBInterfaceHandle->m_PACKAGE_RELATIONSHIPS_ROOT_PART_NAME;
#else //NOT_USE_GLOBAL_VARIABLE
	if (PackagingURIHelper::PACKAGE_ROOT_URI && PackagingURIHelper::PACKAGE_ROOT_URI->path() == partName->getURI()->path() )
		return PackagingURIHelper::PACKAGE_RELATIONSHIPS_ROOT_PART_NAME;
#endif //NOT_USE_GLOBAL_VARIABLE

	if (partName->IsRelationshipPartURI())
	{
		SET_INFO_LOG("Can't be a relationship part");
#ifdef BORA_THREAD_SUPPORT
		BRTHREAD_ASSERT(BrFALSE);
#endif
		return BrNULL;
	}

	BString fullPath = partName->getURI()->getPath();
	BTrace("%s(%d) %s fullPath.data()[%s]", __FILE__, __LINE__, __FUNCTION__, fullPath.data());
	BString filename = GetFilename(partName->getURI());
	BTrace("%s(%d) %s filename.data()[%s]", __FILE__, __LINE__, __FUNCTION__, filename.data());
	fullPath = fullPath.left(fullPath.length() - filename.length());
	BTrace("%s(%d) %s fullPath.data()[%s]", __FILE__, __LINE__, __FUNCTION__, fullPath.data());
	if( fullPath.isEmpty() )
		fullPath = BString(RELATIONSHIP_PART_SEGMENT_NAME);
	else
		fullPath = combine(fullPath, BString(RELATIONSHIP_PART_SEGMENT_NAME));
	BTrace("%s(%d) %s fullPath.data()[%s]", __FILE__, __LINE__, __FUNCTION__, fullPath.data());
	fullPath = combine(fullPath, filename);
	BTrace("%s(%d) %s fullPath.data()[%s]", __FILE__, __LINE__, __FUNCTION__, fullPath.data());
	fullPath = fullPath + BString(RELATIONSHIP_PART_EXTENSION_NAME);
	BTrace("%s(%d) %s fullPath.data()[%s]", __FILE__, __LINE__, __FUNCTION__, fullPath.data());
	return createPartName(fullPath);
}

BrBOOL PackagingURIHelper::CanDelete(BoraPackagePartName* partName)
{
	return partName!=PACKAGE_RELATIONSHIPS_ROOT_PART_NAME && 
			partName!=CORE_PROPERTIES_PART_NAME &&
			partName!=PACKAGE_ROOT_PART_NAME;
}

BArray<BString*> PackagingURIHelper::SplitBySep(BString& str, BrCHAR sep)
{
	BArray<BString*>	strArray;
	BrINT32 i, nLen = str.length();
	for(i=0; i<nLen; i++)
	{
		if( i==0 && str[i]==sep )
			continue;

		BString* s = BrNEW BString;
		for(;i<nLen; i++)
		{
			if( str[i]==sep )
				break;

			*s += str[i];
		}
		if( i && !s->isEmpty())			
			strArray.Add(s);
		else
			BrDELETE s;
	}

	return strArray;
}


void test_uri(BString str)
{
#if 0
	//BString str = "/ppt/slideLayouts/slideLayout2.xml";
	Bora_URI	uri( str );
//	BrTrace("protocol: %s", uri.protocol());
//	BrTrace("host: %s", uri.host());
	BrTrace("path: %s", uri.path().data());
//	BrTrace("port: %d", uri.port());
	BrTrace("file name: %s", uri.fileName().data());
	CANCEL_LOAD_RETURN_VOID_EX1


	Bora_URI uri1("docs/guide/collections/designfaq.html#28");
	Bora_URI uri_base("http://java.sun.com/j2se/1.3/test.html");
	Bora_URI * res = uri_base.Resolve(&uri1);
	BrTrace(res->path().data());
#endif

}


#endif
