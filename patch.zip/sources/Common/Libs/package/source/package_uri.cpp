#include <OfficePreComp.hpp>

#ifdef SUPPORT_XML_PARSER

#include "package_uri.h"
#include "binterfacehandle.h"


static BrUSHORT hex_to_int( BrUSHORT c )
{
    if ( c >= 'A' && c <= 'F' )
		return c - 'A' + 10;
    if ( c >= 'a' && c <= 'f')
		return c - 'a' + 10;
    if ( c >= '0' && c <= '9')
		return c - '0';
    return 0;
}

void bora_slashify( BString& s, BrBOOL allowMultiple)
{
    BrBOOL justHadSlash = BrFALSE;
	BrINT32 i;
    for ( i = 0; i < (BrINT32)s.length(); i++ ) 
	{
		if ( !allowMultiple && justHadSlash &&
			 ( s[ i ] == '/' || s[ i ] == '\\' ) ) 
		{
			s.remove( i, 1 );
			--i;
			continue;
		}
		if ( s[ i ] == '\\' )
			s[ i ] = '/';
		if ( s[ i ] == '/' )
			justHadSlash = BrTRUE;
		else
			justHadSlash = BrFALSE;
    }
}


Bora_URI::Bora_URI()
{
    m_isValid = BrFALSE;
    m_port = -1;
    m_cleanPathDirty = BrTRUE;
}
Bora_URI::Bora_URI( const BString& url )
{
    m_protocol = "file";
    m_port = -1;
    parse( url );
}
Bora_URI::Bora_URI( const Bora_URI& url )
{
    m_protocol = url.m_protocol;
    m_user = url.m_user;
    m_pass = url.m_pass;
    m_host = url.m_host;
    m_path = url.m_path;
	m_cleanPath = url.m_cleanPath;
    m_refEncoded = url.m_refEncoded;
    m_queryEncoded = url.m_queryEncoded;
    m_isValid = url.m_isValid;
    m_port = url.m_port;
    m_cleanPathDirty = url.m_cleanPathDirty;
}

Bora_URI::Bora_URI( const Bora_URI& url, const BString& relUrl, BrBOOL checkSlash )
{
	reset(); //coverity - 15093

    BString rel = relUrl;
    bora_slashify( rel );

    Bora_URI urlTmp( url );
    if ( !urlTmp.isValid() ) 
	{
		urlTmp.reset();
    }
    if ( isRelativeUrl( rel ) ) 
	{
		if ( rel[ 0 ] == '#' ) 
		{
			*this = urlTmp;
			rel.remove( 0, 1 );
			decode( rel );
			setRef( rel );
		} 
		else if ( rel[ 0 ] == '?' ) 
		{
			*this = urlTmp;
			rel.remove( 0, 1 );
			setQuery( rel );
		} 
		else 
		{
		    decode( rel );
		    *this = urlTmp;
			setRef( "" );
			if ( checkSlash && m_cleanPath[(BrINT32)path().length()-1] != '/' ) 
			{
				if ( isRelativeUrl( path() ) )
					setEncodedPathAndQuery( rel );
				else
					setFileName( rel );
			} 
			else 
			{
				BString p = urlTmp.path();
				if ( p.isEmpty() )
				    p = "/";
				if ( p.right( 1 ) != "/" )
				    p += "/";
				p += rel;
				m_path = p;
				m_cleanPathDirty = BrTRUE;
			}
		}
    } 
	else 
	{
		if ( rel[ 0 ] == BChar( '/' ) ) 
		{
			*this = urlTmp;
			setEncodedPathAndQuery( rel );
		} 
		else 
		{
			*this = rel;
		}
    }
}
Bora_URI::~Bora_URI()
{
}

BString Bora_URI::getUrl()
{
	return m_url;
}

BString Bora_URI::protocol() const
{
    return m_protocol;
}
void Bora_URI::setProtocol( const BString& protocol )
{
    m_protocol = protocol;
}

BString Bora_URI::user() const
{
    return  m_user;
}

void Bora_URI::setUser( const BString& user )
{
    m_user = user;
}

BrBOOL Bora_URI::hasUser() const
{
	return !m_user.isEmpty();
}


BString Bora_URI::password() const
{
    return m_pass;
}

void Bora_URI::setPassword( const BString& pass )
{
    m_pass = pass;
}

BrBOOL Bora_URI::hasPassword() const
{
    return !m_pass.isEmpty();
}


BString Bora_URI::host() const
{
    return m_host;
}

void Bora_URI::setHost( const BString& host )
{
    m_host = host;
}

BrBOOL Bora_URI::hasHost() const
{
    return !m_host.isEmpty();
}


BrINT32 Bora_URI::port() const
{
    return m_port;
}

void Bora_URI::setPort( BrINT32 port )
{
    m_port = port;
}

BrBOOL Bora_URI::hasPort() const
{
    return m_port >= 0;
}


void Bora_URI::setPath( const BString& path )
{
    m_path = path;
    bora_slashify( m_path );
    m_cleanPathDirty = BrTRUE;
}

BrBOOL Bora_URI::isRelativePath( const BString &path )
{
    BrINT32 len = path.length();
    if ( len == 0 )
		return BrTRUE;
    return (path[0] != '/')? true : false;
}

BString Bora_URI::cleanDirPath( const BString &filePath )
{
    BString name = filePath;
    BString newPath;

    if ( name.isEmpty() )
		return name;

    bora_slashify( name );

    BrBOOL addedSeparator;
    if ( isRelativePath(name) ) 
	{
		addedSeparator = BrTRUE;
		name.insert( 0, '/' );
    } 
	else 
	{
		addedSeparator = BrFALSE;
    }

    BrINT32 ePos, pos, upLevel;

    pos = ePos = name.length();
    upLevel = 0;
    BrINT32 len;

    while ( pos && (pos = name.findRev('/',--pos)) != -1 ) 
	{
		len = ePos - pos - 1;
		if ( len == 2 && name.at(pos + 1) == '.'
		      && name.at(pos + 2) == '.' ) 
		{
			upLevel++;
		} 
		else 
		{
			if ( len != 0 && (len != 1 || name.at(pos + 1) != '.') ) 
			{
				if ( !upLevel )
					newPath = BString::fromLatin1("/") + name.mid(pos + 1, len) + newPath;
				else
				    upLevel--;
			}
		}
		ePos = pos;
    }
    if ( addedSeparator ) 
	{
		while ( upLevel-- )
		    newPath.insert( 0, BString::fromLatin1("/..") );
		if ( !newPath.isEmpty() )
			newPath.remove( 0, 1 );
		else
			newPath = BString::fromLatin1(".");
    } 
	else 
	{
		if ( newPath.isEmpty() )
			newPath = BString::fromLatin1("/");
    }
    return newPath;
}

BString Bora_URI::path( BrBOOL correct )
{
    if ( !correct )
		return m_path;

    if ( m_cleanPathDirty ) 
	{
		if ( isRelativePath( m_path ) ) 
		{
			m_cleanPath = m_path;
		} 
		else if ( isLocalFile() ) 
		{
			m_cleanPath = m_path;
#ifdef _BORA_THREAD_SUPPORT
			BRTHREAD_ASSERT(BrFALSE);
#endif
		}
		else 
		{
		    if ( m_path != "/" && m_path[ (BrINT32)m_path.length() - 1 ] == '/' )
				m_cleanPath = cleanDirPath( m_path ) + "/";
			else
				m_cleanPath = cleanDirPath( m_path );
		}

	    bora_slashify( m_cleanPath, BrFALSE );
		m_cleanPathDirty = BrFALSE;
    }

    return m_cleanPath;
}


BrBOOL Bora_URI::hasPath() const
{
    return !m_path.isEmpty();
}


BString Bora_URI::encodedPathAndQuery()
{
    BString p = path();
    if ( p.isEmpty() )
		p = "/";

    encode( p );

    if ( !m_queryEncoded.isEmpty() ) 
	{
		p += "?";
		p += m_queryEncoded;
    }

    return p;
}

void Bora_URI::setEncodedPathAndQuery( const BString& pathAndQuery )
{
    m_cleanPathDirty = BrTRUE;
	int pos = pathAndQuery.find( '?' );
    if ( pos == -1 ) 
	{
		m_path = pathAndQuery;
		m_queryEncoded = "";
    } else {
		m_path = pathAndQuery.left( pos );
		m_queryEncoded = pathAndQuery.mid( pos + 1 );
    }

    decode( m_path );
    m_cleanPathDirty = BrTRUE;
}

void Bora_URI::setQuery( const BString& txt )
{
    m_queryEncoded = txt;
}

BString Bora_URI::query() const
{
    return m_queryEncoded;
}

void Bora_URI::encode( BString& url )
{
    BrINT32 oldlen = url.length();

    if ( !oldlen )
		return;

    BString newUrl;
    BrINT32 newlen = 0;

    for ( int i = 0; i < oldlen ;++i ) 
	{
		BrUSHORT inCh = url[ i ].unicode();

		if ( inCh >= 128 ||
			BString( "<>#@\"&%$:,;?={}|^~[]\'`\\ \n\t\r" ).contains(BChar(inCh)) ) 
		{
			newUrl[ newlen++ ] = BChar( '%' );

			BrUSHORT c = inCh / 16;
			c += c > 9 ? 'A' - 10 : '0';
			newUrl[ newlen++ ] = c;

			c = inCh % 16;
			c += c > 9 ? 'A' - 10 : '0';
			newUrl[ newlen++ ] = c;
		} else {
			newUrl[ newlen++ ] = url[ i ];
		}
    }

    url = newUrl;
}

void Bora_URI::decode( BString& url )
{
	BrINT32 oldlen = url.length();
    if ( !oldlen )
		return;

    BrINT32 newlen = 0;

    BString newUrl;

    BrINT32 i = 0;
    while ( i < oldlen ) 
	{
		BrUSHORT c = url[ i++ ].unicode();
		if ( c == '%' ) 
		{
			c = hex_to_int( url[ i ].unicode() ) * 16 + hex_to_int( url[ i + 1 ].unicode() );
			i += 2;
		}
		newUrl [ newlen++ ] = c;
    }

    url = newUrl;
}

void Bora_URI::reset()
{
    m_protocol = "file";
    m_user = "";
    m_pass = "";
    m_host = "";
    m_path = "";
    m_queryEncoded = "";
    m_refEncoded = "";
    m_isValid = BrTRUE;
    m_port = -1;
    m_cleanPathDirty = BrTRUE;
}

BrBOOL Bora_URI::isRelativeUrl( const BString &url )
{
    BrINT32 colon = url.find( ":" );
    BrINT32 slash = url.find( "/" );

    return ( slash != 0 && ( colon == -1 || ( slash != -1 && colon > slash ) ) );
}

BString Bora_URI::ref() const
{
    return m_refEncoded;
}

void Bora_URI::setRef( const BString& txt )
{
    m_refEncoded = txt;
}

BrBOOL Bora_URI::hasRef() const
{
    return !m_refEncoded.isEmpty();
}

BrBOOL Bora_URI::isValid() const
{
    return m_isValid;
}

BrBOOL Bora_URI::isLocalFile() const
{
    return m_protocol == "file";
}

BrBOOL Bora_URI::parse( const BString& url )
{
    m_url = url;
    bora_slashify( m_url );

    if ( m_url.isEmpty() ) 
	{
		m_isValid = BrFALSE;
		return BrFALSE;
    }

    m_cleanPathDirty = BrTRUE;
    m_isValid = BrTRUE;
    BString oldProtocol = m_protocol;
    m_protocol = "";

	const BrINT32 Init	= 0;
	const BrINT32 Proto	= 1;
	const BrINT32 Sep1= 2; // :
	const BrINT32 Sep2= 3; // :/
	const BrINT32 Sep3= 4; // :// or more slashes
	const BrINT32 User	= 5;
	const BrINT32 Pass	= 6;
	const BrINT32 Host	= 7;
	const BrINT32 Path	= 8;
	const BrINT32 Ref	= 9;
	const BrINT32 Query	= 10;
	const BrINT32 Port	= 11;
	const BrINT32 Done	= 12;

	const BrINT32 InputAlpha= 1;
	const BrINT32 InputDigit= 2;
	const BrINT32 InputSlash= 3;
	const BrINT32 InputColon= 4;
	const BrINT32 InputAt	= 5;
	const BrINT32 InputHash = 6;
	const BrINT32 InputQuery= 7;

#ifndef NOT_USE_GLOBAL_VARIABLE
	const BrINT32 nTableRow = 12;
	const BrINT32 nTableColumn = 8;

	const BrUCHAR s_PackageUriTable[ nTableRow ][ nTableColumn ] = {
		/* None       InputAlpha  InputDigit  InputSlash  InputColon  InputAt     InputHash   InputQuery */
		{ 0,       Proto,   0,          Path,       0,          0,          0,          0,         }, // Init
		{ 0,       Proto,   Proto,   0,          Sep1, 0,          0,          0,         }, // Proto
		{ 0,       Path,       Path,       Sep2, 0,          0,          0,          0,         }, // Sep1
		{ 0,       Path,       Path,       Sep3, 0,          0,          0,          0,         }, // Sep2
		{ 0,       User,       User,       Sep3, Pass,       Host,       0,          0,         }, // Sep3
		{ 0,       User,       User,       User,       Pass,       Host,       User,       User,      }, // User
		{ 0,       Pass,       Pass,       Pass,       Pass,       Host,       Pass,       Pass,      }, // Pass
		{ 0,       Host,       Host,       Path,       Port,       Host,       Ref,        Query,     }, // Host
		{ 0,       Path,       Path,       Path,       Path,       Path,       Ref,        Query,     }, // Path
		{ 0,       Ref,        Ref,        Ref,        Ref,        Ref,        Ref,        Query,     }, // Ref
		{ 0,       Query,      Query,      Query,      Query,      Query,      Query,      Query,     }, // Query
		{ 0,       0,          Port,       Path,       0,          0,          0,          0,         }  // Port
	};
#endif //!NOT_USE_GLOBAL_VARIABLE

	BrBOOL bForceRelation = BrFALSE;
	BrBOOL bRelationPath = BrFALSE;

	BrINT32 nColSep = m_url.find( ":/" );
	if ( nColSep == 1 )
	{
		bRelationPath = BrTRUE;
		bForceRelation = BrTRUE;
	}
	BrINT32 nNoHost = -1;
	if ( nColSep != -1 ) 
		nNoHost = m_url.find( "///", nColSep );
	s_PackageUriTable[ Sep3 ][ Proto ] = User;
	s_PackageUriTable[ Sep3 ][ Sep1 ] = User;
	if ( nColSep == -1 || bForceRelation ) 
	{
		if ( url.find( ':' ) == -1 || bForceRelation ) 
		{
			s_PackageUriTable[ 0 ][ 1 ] = Path;
			s_PackageUriTable[ 0 ][ 2 ] = Path;
		} 
		else 
		{
			s_PackageUriTable[ 0 ][ 1 ] = Proto;
		}
		bRelationPath = BrTRUE;
	} 
	else 
	{ 
		s_PackageUriTable[ 0 ][ 1 ] = Proto;

		++nColSep;
		while ( m_url[ nColSep ] == '/' )
			++nColSep;
		int slash = m_url.find( "/", nColSep );
		if ( slash == -1 )
			slash = m_url.length() - 1;
		BString strTmp = m_url.mid( nColSep, slash - nColSep + 1 );

		if ( !strTmp.isEmpty() ) 
		{ 
			BrINT32 nAtPos = strTmp.find( "@" );
			if ( nAtPos != -1 )
				nAtPos += nColSep;

			if ( nAtPos == -1 ) 
			{
				if ( m_url.left( 4 ) == "file" || nNoHost != -1 )
					s_PackageUriTable[ 4 ][ 1 ] = Path;
				else
					s_PackageUriTable[ 4 ][ 1 ] = Host;
				s_PackageUriTable[ 4 ][ 2 ] = s_PackageUriTable[ 4 ][ 1 ];
			}
		}
	}

	BrINT32 state = Init; 
	BrINT32 input; 

    BChar c = m_url[ 0 ];
    BrINT32 i = 0;
    BString port;

    for ( ;; ) 
	{
		switch ( c ) 
		{
		case '?':
			input = InputQuery;
			break;
		case '#':
			input = InputHash;
			break;
		case '@':
			input = InputAt;
			break;
		case ':':
			input = InputColon;
			break;
		case '/':
			input = InputSlash;
			break;
		case '1': case '2': case '3': case '4': case '5':
		case '6': case '7': case '8': case '9': case '0':
			input = InputDigit;
			break;
		default:
			input = InputAlpha;
		}

		state = s_PackageUriTable[ state ][ input ];

		switch ( state ) 
		{
			case Proto:
				m_protocol += c;
				break;
			case User:
				m_user += c;
				break;
			case Pass:
				m_pass += c;
				break;
			case Host:
				m_host += c;
				break;
			case Path:
				m_path += c;
				break;
			case Ref:
				m_refEncoded += c;
				break;
			case Query:
				m_queryEncoded += c;
				break;
			case Port:
				port += c;
				break;
			default:
				break;
		}

		++i;
		if ( i > (int)m_url.length() - 1 || state == Done || state == 0 )
			break;
		c = m_url[ i ];

    }

    if ( !port.isEmpty() ) {
		port.remove( 0, 1 );
		m_port = strtol( port.latin1() , BrNULL, 10);
    }

    // error
    if ( i < (int)m_url.length() - 1 ) {
		m_isValid = FALSE;
		return BrFALSE;
    }


    if ( m_protocol.isEmpty() )
		m_protocol = oldProtocol;

    if ( m_path.isEmpty() )
		m_path = "/";

    // hack for windows
    if ( m_path.length() == 2 && m_path[ 1 ] == ':' )
		m_path += "/";

    // #### do some corrections, should be done nicer too
    if ( !m_pass.isEmpty() ) {
		if ( m_pass[ 0 ] == ':' )
		    m_pass.remove( 0, 1 );
		decode( m_pass );
    }
    if ( !m_user.isEmpty() ) {
		decode( m_user );
    }
    if ( !m_path.isEmpty() ) {
	if ( m_path[ 0 ] == '@' || m_path[ 0 ] == ':' )
	    m_path.remove( 0, 1 );
	if ( m_path[ 0 ] != '/' && !bRelationPath && m_path[ 1 ] != ':' )
	    m_path.prepend( "/" );
    }
    if ( !m_refEncoded.isEmpty() && m_refEncoded[ 0 ] == '#' )
		m_refEncoded.remove( 0, 1 );
    if ( !m_queryEncoded.isEmpty() && m_queryEncoded[ 0 ] == '?' )
		m_queryEncoded.remove( 0, 1 );
    if ( !m_host.isEmpty() && m_host[ 0 ] == '@' )
		m_host.remove( 0, 1 );

//    decode( m_path );
    m_cleanPathDirty = BrTRUE;

////    BrTrace( "URL: %s", m_url.latin1() );
#if 0
    BrTrace( "protocol: %s", m_protocol.latin1() );
    BrTrace( "user: %s", m_user.latin1() );
    BrTrace( "pass: %s", m_pass.latin1() );
    BrTrace( "host: %s", m_host.latin1() );
    BrTrace( "path: %s", path().latin1() );
    BrTrace( "ref: %s", m_refEncoded.latin1() );
    BrTrace( "query: %s", m_queryEncoded.latin1() );
    BrTrace( "port: %d\n\n----------------------------\n\n", m_port );
#endif

    return BrTRUE;
}

void Bora_URI::setFileName( const BString& name )
{
    BString fn( name );
    bora_slashify( fn );

    while ( fn[ 0 ] == '/' )
		fn.remove( 0, 1 );

    BString p;
    if ( path().isEmpty() ) 
	{
		p = "/";
    } 
	else 
	{
		p = path();
		BrINT32 slash = p.findRev( BChar( '/' ) );
		if ( slash == -1 ) {
			p = "/";
		} 
		else if ( p[ (int)p.length() - 1 ] != '/' ) 
		{
			p.truncate( slash + 1 );
		}
    }

    p += fn;
    if ( !m_queryEncoded.isEmpty() )
		p += "?" + m_queryEncoded;
    setEncodedPathAndQuery( p );
}

BString Bora_URI::fileName() const
{
    if ( m_path.isEmpty() )
		return "";

    BrINT32 p = m_path.findRev( '/' );
    if ( p == -1 ) 
		return m_path;
	else 
		return m_path.mid(p+1);
}

BString Bora_URI::dirPath() const
{
    if ( m_path.isEmpty() )
		return "";

    BrINT32 p = m_path.findRev( '/' );
    if ( p == -1 ) 
		return BString("");
	else 
		return m_path.left(p+1);
}

void Bora_URI::addPath( const BString& pa )
{
    if ( pa.isEmpty() )
		return;

    BString p( pa );
    bora_slashify( p );

    if ( path().isEmpty() ) 
	{
		if ( p[ 0 ] != BChar( '/' ) )
			m_path = "/" + p;
		else
			m_path = p;
    } 
	else 
	{
		if ( p[ 0 ] != BChar( '/' ) && m_path[ (BrINT32)m_path.length() - 1 ] != '/' )
		    m_path += "/" + p;
		else
			m_path += p;
    }
    m_cleanPathDirty = BrTRUE;
}

Bora_URI& Bora_URI::operator=( const BString& url )
{
    reset();
    parse( url );

    return *this;
}

Bora_URI& Bora_URI::operator=( const Bora_URI& url )
{
	m_protocol = url.m_protocol;
	m_user = url.m_user;
	m_pass = url.m_pass;
	m_host = url.m_host;
	m_path = url.m_path;
	m_queryEncoded = url.m_queryEncoded;
	m_refEncoded = url.m_refEncoded;
	m_isValid = url.m_isValid;
	m_port = url.m_port;

    return *this;
}

BrBOOL Bora_URI::operator==( const Bora_URI& url ) const
{
    if ( !isValid() || !url.isValid() )
		return BrFALSE;

    if ( m_protocol == url.m_protocol &&
	 m_user == url.m_user &&
	 m_pass == url.m_pass &&
	 m_host == url.m_host &&
	 m_path == url.m_path &&
	 m_queryEncoded == url.m_queryEncoded &&
	 m_refEncoded == url.m_refEncoded &&
	 m_isValid == url.m_isValid &&
	 m_port == url.m_port )
	return BrTRUE;

    return BrFALSE;
}

BrBOOL Bora_URI::operator==( const BString& url ) const
{
    Bora_URI u( url );
    return ( *this == u );
}

Bora_URI* Bora_URI::Resolve( Bora_URI* url ) const
{
    Bora_URI *newUrl = BrNEW Bora_URI;
    
	newUrl->m_protocol = m_protocol;

	if( url->hasHost() )
	{
		newUrl->m_host = url->m_host;
		newUrl->m_path = url->m_path;
		newUrl->m_port = url->m_port;
	}
	else
	{
		newUrl->m_host = m_host;
		if( !url->isRelativePath(url->m_path) )
			newUrl->m_path = url->m_path;
		else
			newUrl->m_path = m_path+url->m_path;
		newUrl->m_port = m_port;
	}

	return newUrl;
}

BString Bora_URI::toString( BrBOOL encodedPath, BrBOOL forcePrependProtocol ) const
{
	BTrace("%s(%d) %s m_path.data()[%s]", __FILE__, __LINE__, __FUNCTION__, m_path.data());
		
    BString res, p = m_path;
    if ( encodedPath )
		encode( p );

    if ( isLocalFile() ) 
	{
		if ( forcePrependProtocol )
		    res = m_protocol + ":" + p;
		else
			res = p;
		BTrace("%s(%d) %s res.data()[%s]", __FILE__, __LINE__, __FUNCTION__, res.data());
	
    } 
	else if ( m_protocol == "mailto" ) 
	{
		res = m_protocol + ":" + p;
BTrace("%s(%d) %s res.data()[%s]", __FILE__, __LINE__, __FUNCTION__, res.data());
    } 
	else 
	{
		res = m_protocol + "://";
		if ( !m_user.isEmpty() || !m_pass.isEmpty() ) 
		{
		    BString tmp;
		    if ( !m_user.isEmpty() ) 
			{
				tmp = m_user;
				encode( tmp );
				res += tmp;
			}
			if ( !m_pass.isEmpty() ) 
			{
				tmp = m_pass;
				encode( tmp );
				res += ":" + tmp;
			}
			res += "@";
		}
		res += m_host;
		BTrace("%s(%d) %s res.data()[%s]", __FILE__, __LINE__, __FUNCTION__, res.data());
	
		if ( m_port != -1 )
		{
			res = res + ":" + BString( "%1" ).arg( m_port, 0, 10 );
		BTrace("%s(%d) %s res.data()[%s]", __FILE__, __LINE__, __FUNCTION__, res.data());
	
		}
		if ( !p.isEmpty() ) 
		{
			if ( !m_host.isEmpty() && p[0]!='/' )
				res += "/";
			res += p;
		BTrace("%s(%d) %s res.data()[%s]", __FILE__, __LINE__, __FUNCTION__, res.data());
	
		}
    }

    if ( !m_refEncoded.isEmpty() )
		res += "#" + m_refEncoded;
    if ( !m_queryEncoded.isEmpty() )
		res += "?" + m_queryEncoded;
BTrace("%s(%d) %s res.data()[%s]", __FILE__, __LINE__, __FUNCTION__, res.data());
	
    return res;
}

BrBOOL Bora_URI::equals(Bora_URI* pUri)
{
	return toString().lower().compare(pUri->toString().lower())==0;
}

BrINT32 Bora_URI::hashCode()
{
	return toString().hashCode();
}

#endif //SUPPORT_XML_PARSER
