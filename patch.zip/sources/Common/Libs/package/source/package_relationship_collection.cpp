#include <OfficePreComp.hpp>

#ifdef SUPPORT_XML_PARSER

#include "bwpObjApi.h"
#include "bmvstream.h"

#include "SAX/Expat/xmldecoder.h"

#include "packageBase.h"
#include "package_part.h"
#include "package_partname.h"
#include "package_uri_helper.h"
#include "package_relationship_collection.h"
#include "package_relationship.h"
#include "binterfacehandle.h"
#include "ThreadDefines_i.h"
#include "binterfacehandle.h"
#include "ftLibraryBase.h"

PackageRelationshipItem::PackageRelationshipItem(PackageRelationship* relationship, BString identifier)
{
	m_relationship = relationship;
	m_identifier = identifier;
};
PackageRelationshipItem::~PackageRelationshipItem() 
{
	BrDELETE m_relationship;
};

PackageRelationshipCollection::PackageRelationshipCollection() 
{
	m_relationshipPart = BrNULL;
	m_sourcePart = BrNULL;
	m_partName = BrNULL;
	m_container = BrNULL;
}

PackageRelationshipCollection::PackageRelationshipCollection(PackageRelationshipCollection* coll, BString filter) 
{
	BrINT32 i;
	PackageRelationship* rel;

	m_relationshipPart = BrNULL;
	m_sourcePart = BrNULL;
	m_partName = BrNULL;
	m_container = BrNULL;

	BrBOOL bFilterNull = filter.isEmpty();

	for(i=0; i<(BrINT32)coll->m_relationshipsByID.size(); i++)
	{
		rel = coll->m_relationshipsByID[i]->m_relationship;
		if( bFilterNull || rel->getRelationshipType()==filter )
			addRelationship(rel);
	}
}

PackageRelationshipCollection::PackageRelationshipCollection(BoraPackageBase* container)
{
	ConstructPackageRelationshipCollection(container, BrNULL);
}

PackageRelationshipCollection::PackageRelationshipCollection(BoraPackagePart* part)
{
	ConstructPackageRelationshipCollection(part->m_container, part);
}

PackageRelationshipCollection::PackageRelationshipCollection(BoraPackageBase* container, BoraPackagePart* part)
{
	if (container == BrNULL)
		return;

	ConstructPackageRelationshipCollection(container, part);
}

void PackageRelationshipCollection::ConstructPackageRelationshipCollection(BoraPackageBase* container, BoraPackagePart* part)
{
	//[2013.07.31][TID : 16371][���ؼ�] �ӵ������ ���� getPart �Լ� ��ü
	m_container = container;
	m_sourcePart = part;
	m_partName = getRelationshipPartName(part);
	m_relationshipPart = m_container->GetPackagePart(m_partName);
	if(m_relationshipPart)
	{
		//package �� ���Ե� m_partName �����͸� ���� ���� �� ������ �Ǿ� ���纻�� ������.
		if(m_relationshipPart->m_partName == m_partName)
			m_partName = m_partName->clone();

		parseRelationshipsPart(m_relationshipPart);
	}
}

PackageRelationshipCollection::~PackageRelationshipCollection() 
{
	BrINT32 i, sz=(BrINT32)m_relationshipsByID.size();
	for(i=0; i<sz; i++)
		BrDELETE m_relationshipsByID[i];

	//static ���� ���ǵ� part name ���� ���⼭ ������ �ʴ´�.
	if( PackagingURIHelper::CanDelete(m_partName) )
		BrDELETE m_partName;
}

BoraPackagePartName* PackageRelationshipCollection::getRelationshipPartName(BoraPackagePart* part)
{
	BoraPackagePartName* partName;
	if (part == BrNULL)
#ifdef NOT_USE_GLOBAL_VARIABLE
		partName = PACKAGE_ROOT_PART_NAME;
#else //NOT_USE_GLOBAL_VARIABLE
		partName = PackagingURIHelper::PACKAGE_ROOT_PART_NAME;
#endif //NOT_USE_GLOBAL_VARIABLE
	else 
		partName = part->getPartName();

	return PackagingURIHelper::GetRelationshipPartName(partName);
}

void PackageRelationshipCollection::addRelationship(PackageRelationship* relPart) 
{
	BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);	

	PackageRelationshipItem* p = BrNEW PackageRelationshipItem(relPart, relPart->getRelationshipType());
	m_relationshipsByID.Add(p);

	binarySearchNInsert(m_BinaryOrderRelationshipsByID,p->m_relationship);

////	p = BrNEW PackageRelationshipItem(relPart, relPart->getRelationshipType());
////	m_relationshipsByType.Add(p);
}

PackageRelationship* PackageRelationshipCollection::relationshipsByID_get(BString id)
{
	BrINT32 i;
	PackageRelationshipItem*	item;

	for(i=0; i<(BrINT32)m_relationshipsByID.size(); i++)
	{
		item = m_relationshipsByID[i];
		if( item->m_identifier==id )
			return item->m_relationship;
	}

	return BrNULL;
}

PackageRelationship* PackageRelationshipCollection::relationshipsByType_get(BString type)
{
	BrINT32 i;
	PackageRelationshipItem*	item;
BTrace("%s(%d) %s type.utf8()[%s]", __FILE__, __LINE__, __FUNCTION__, type.utf8());	
	for(i=0; i<(BrINT32)m_relationshipsByID.size(); i++)
	{
		item = m_relationshipsByID[i];

		if( item == BrNULL || item->m_relationship == BrNULL )
		{
			SET_EDIT_WARNING_LOG(kPoWarnMissObject, "");		
			continue;
		}
BTrace("%s(%d) %s item->m_relationship->m_relationshipType[%s]", __FILE__, __LINE__, __FUNCTION__, item->m_relationship->m_relationshipType.utf8());	
		if( item->m_relationship->m_relationshipType==type )
			return item->m_relationship;
	}

	return BrNULL;
}

PackageRelationship* PackageRelationshipCollection::addRelationship(Bora_URI* targetUri, TargetMode targetMode, BString relationshipType, BString id) 
{
BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);	
	if (id.isEmpty()) 
	{
		// Generate a unique ID is id parameter is null.
		BrINT32 i = 0;
		do {
			id = BString("rId") + BString::number(++i);
		} while (relationshipsByID_get(id) != BrNULL);
	}
BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);	

	PackageRelationship* rel = BrNEW PackageRelationship(m_container,
				m_sourcePart, targetUri, targetMode, relationshipType, id);

	PackageRelationshipItem* p = BrNEW PackageRelationshipItem(rel, rel->getId());
	m_relationshipsByID.Add(p);

BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);	
	binarySearchNInsert(m_BinaryOrderRelationshipsByID,p->m_relationship);

////	p = BrNEW PackageRelationshipItem(rel, rel->getRelationshipType());
////	m_relationshipsByType.Add(p);
	return rel;
}

void PackageRelationshipCollection::relationshipsByID_remove(BString id)
{
	BrINT32 i;
	PackageRelationshipItem*	item;

	for(i=0; i<(BrINT32)m_relationshipsByID.size(); i++)
	{
		item = m_relationshipsByID[i];
		if( item->m_identifier==id )
		{
			removeBinaryOrderRelationships(id);
			BrDELETE item;
			m_relationshipsByID.RemoveAt(i);
			return;
		}
	}
}

void PackageRelationshipCollection::removeRelationship(BString id) 
{
	if (m_relationshipsByID.size() != 0 /* && m_relationshipsByType.size() != 0*/ ) 
	{
		PackageRelationship* rel = relationshipsByID_get(id);
		if (rel != BrNULL) 
		{
			relationshipsByID_remove(rel->getId());
			////relationshipsByType.values().remove(rel);
		}
	}
}


void PackageRelationshipCollection::removeRelationship(PackageRelationship* rel) 
{
	if (rel == BrNULL)
			return;

	BrINT32 i;
	PackageRelationshipItem*	item;

	for(i=0; i<(BrINT32)m_relationshipsByID.size(); i++)
	{
		item = m_relationshipsByID[i];
		if( item->m_relationship==rel )
		{
			BString strRelID = rel->getId();
			removeBinaryOrderRelationships(strRelID);

			BrDELETE item;
			m_relationshipsByID.RemoveAt(i);
			return;
		}
	}
////	relationshipsByType.values().remove(rel);
}

void PackageRelationshipCollection::removeBinaryOrderRelationships(BString& a_strRelID)
{
	BrINT32 nFindIndex = -1;
	PackageRelationship* pRelationship = binarySearchRelationship(a_strRelID, &nFindIndex);
	if( nFindIndex != -1 && pRelationship == BrNULL )
		m_BinaryOrderRelationshipsByID.RemoveAt(nFindIndex);
}

PackageRelationship* PackageRelationshipCollection::getRelationship(BrINT32 index) 
{
	if (index < 0 || index > (BrINT32)m_relationshipsByID.size() )
			return BrNULL;

	return m_relationshipsByID[index]->m_relationship;
}

PackageRelationship* PackageRelationshipCollection::getRelationshipByID(BString id) 
{
	return relationshipsByID_get(id);
}

BrINT32 PackageRelationshipCollection::size() 
{
	return (BrINT32)m_relationshipsByID.size();
}

BrBOOL PackageRelationshipCollection::parseRelationshipsPart(BoraPackagePart* relPart)
{
	CallbackParam	param;
	//[2011.09.26][�����][TID:239] callbackparam �ʱ�ȭ
	memset(&param, 0, BrSizeOf(CallbackParam));
	param.pCurrentInstance = this;
	return relPart->m_container->ReadPackageByPartname(relPart->m_partName->getName().data(), &param);
}

#if 0
PackageRelationshipCollection* PackageRelationshipCollection::getRelationships(BString typeFilter) 
{
	PackageRelationshipCollection* coll = BrNEW PackageRelationshipCollection(this, typeFilter);
	return coll;
}
#endif

BArray<PackageRelationship*>* PackageRelationshipCollection::iterator() 
{
	BArray<PackageRelationship*>* retArr = BrNEW BArray<PackageRelationship*>();
	PackageRelationshipItem*	item;
	BrINT32 nSize = m_relationshipsByID.size();
	for(BrINT32 i = 0 ; i < nSize; i++)
	{
		item = m_relationshipsByID[i];
		retArr->Add(item->m_relationship);
	}

	return retArr;
}

BArray<PackageRelationship*>* PackageRelationshipCollection::iterator(BString typeFilter) 
{
	BArray<PackageRelationship*>* retArr = BrNEW BArray<PackageRelationship*>();
	PackageRelationshipItem*	item;
	BrINT32 nSize = m_relationshipsByID.size();
	for(BrINT32 i = 0; i < nSize; i++)
	{
		item = m_relationshipsByID[i];
		if( item->m_relationship->getRelationshipType()==typeFilter )
			retArr->Add(item->m_relationship);
	}

	return retArr;
}

BArray<PackageRelationship*>* PackageRelationshipCollection::iteratorOrderedByID() 
{
	BArray<PackageRelationship*>* retArr = BrNEW BArray<PackageRelationship*>();
	PackageRelationshipItem*	item;
	BrINT32 nSize = m_relationshipsByID.size();
	for(BrINT32 i = 0 ; i < nSize; i++)
	{
		//[20141219][jdjang][OFF-354] ANR �̽� ����
		if ( (i % 100) == 0 )
			BoraThreadYield( BIHANDLE_BRCONTEXT );

		item = m_relationshipsByID[i];
		binarySearchNInsert( *retArr, item->m_relationship );
	}

	return retArr;
}

BrINT32	PackageRelationshipCollection::binarySearchNInsert( BArray<PackageRelationship*>& a_rValueArray, PackageRelationship* a_pValue )
{
	int nLow	= 0;
	int nHight	= a_rValueArray.count() - 1;
	int nMid	= 0;
	int nRet	= 0;

	bool bIsHigh = false;
	bool bIsLow = false;

	int nInsertIndex = 0;

	while ( nLow <= nHight )
	{
		bIsHigh = false;
		bIsLow = false;

		nMid = ( nLow + nHight ) / 2;

		nRet = a_rValueArray.at( nMid )->getId().compare( a_pValue->getId() );

		if ( nRet == 0 )
		{
			return nMid;		// Ž�� �� ���
		}
		if ( nRet > 0 )
		{
			nHight = nMid - 1;
			bIsLow = true;
		}
		else // ( nRet < item )
		{
			nLow = nMid + 1;
			bIsHigh = true;
		}
	}

	if( bIsHigh ) nInsertIndex = nMid + 1;
	if( bIsLow ) nInsertIndex = nMid;

	a_rValueArray.InsertAtFast( nInsertIndex, a_pValue );		// Ž�� ���� ���� ��� Insert

	return -1;
}

PackageRelationship* PackageRelationshipCollection::binarySearchRelationship(BString& a_refRelID, BrINT32* a_pFindIndex)
{
	if( m_BinaryOrderRelationshipsByID.size() != m_relationshipsByID.size() )
		return BrNULL;

	int nLow	= 0;
	int nHight	= m_BinaryOrderRelationshipsByID.count() - 1;
	int nMid	= 0;
	int nRet	= 0;

	bool bIsHigh = false;
	bool bIsLow = false;

	int nInsertIndex = 0;

	while ( nLow <= nHight )
	{
		bIsHigh = false;
		bIsLow = false;

		nMid = ( nLow + nHight ) / 2;

		nRet = m_BinaryOrderRelationshipsByID.at( nMid )->getId().compare( a_refRelID );

		if ( nRet == 0 )
		{
			if( a_pFindIndex )
				*a_pFindIndex = nMid;

			return m_BinaryOrderRelationshipsByID.at( nMid );		// Ž�� �� ���
		}
		if ( nRet > 0 )
		{
			nHight = nMid - 1;
			bIsLow = true;
		}
		else // ( nRet < item )
		{
			nLow = nMid + 1;
			bIsHigh = true;
		}
	}

	if( bIsHigh ) nInsertIndex = nMid + 1;
	if( bIsLow ) nInsertIndex = nMid;

	return BrNULL;
}

void PackageRelationshipCollection::clear() 
{

	BrINT32 nIndex = 0;

	for(BrINT32 i=0; i<(BrINT32)m_relationshipsByID.size(); i++)
		BrDELETE m_relationshipsByID[i];

	m_relationshipsByID.resize(0);
	////relationshipsByType.clear();

	m_BinaryOrderRelationshipsByID.resize(0); // ������ ���� �ϱ� ������ ���� ����

}

BString PackageRelationshipCollection::toString() 
{
	BString str;
	if (m_relationshipsByID.size()==0) 
	{
		str = "relationshipsByID=null";
	} 
	else 
	{
		str = BString::number((BrINT32)m_relationshipsByID.size()) + " relationship(s) = [";
	}
	
	if ((m_relationshipPart != BrNULL) && (m_relationshipPart->m_partName != BrNULL)) 
	{
		str = str + "," + m_relationshipPart->m_partName->getName();
	} 
	else 
	{
		str = str + ",relationshipPart=null";
	}

	// Source of this relationship
	if ((m_sourcePart != BrNULL) && (m_sourcePart->m_partName != BrNULL)) 
	{
		str = str + "," + m_sourcePart->m_partName->getName();
	} 
	else 
	{
		str = str + ",sourcePart=null";
	}
	if (m_partName != BrNULL) 
	{
		str = str + "," + m_partName->getName();
	} 
	else 
	{
		str = str + ",uri=null)";
	}
	return str + "]";
}

void PackageRelationshipCollection::MakeFullTargetName(BString& strName)
{
	if( !m_sourcePart )
		return;

	BString strDir = m_sourcePart->getPartName()->m_PartNameURI.dirPath();
	if( strstr(strName.data(), "./")==BrNULL ) // current dir : "./",  up dir : "../"
	{
		if( strncmp(strName.data(), "http://", 7)==0 )
			return;
		else if( strncmp(strName.data(), "mailto:", 7)==0 )
			return;
		else if ( strncmp(strName.data(), "#", 1) == 0)
			return;
		strName = strDir + strName;
		return;
	}

	BrINT32	i, sz;
	BArray<BString*> strSrcArr = PackagingURIHelper::SplitBySep(strDir, '/');
	BArray<BString*> strArr = PackagingURIHelper::SplitBySep(strName, '/');

	sz=strArr.size();
	for(i=0; i<sz; i++)
	{
		if( strcmp(strArr[i]->ascii(), "..")==0 )
		{
			BrDELETE strArr[i];
			strArr[i] = BrNULL;
			
			if( strSrcArr.size() )
			{
				BrDELETE strSrcArr[(BrINT32)strSrcArr.size()-1];
				strSrcArr.RemoveAt((BrINT32)strSrcArr.size()-1);
			}
		}
		else if( strcmp(strArr[i]->ascii(), ".")==0 )
		{
			BrDELETE strArr[i];
			strArr[i] = BrNULL;
		}
	}

	BString	strNew;
	sz=strSrcArr.size();
	for(i=0; i<sz; i++)
	{
		strNew += *strSrcArr[i];
		strNew += BString(FORWARD_SLASH_CHAR);
		BrDELETE strSrcArr[i];
	}

	sz=strArr.size();
	for(i=0; i<sz; i++)
	{
		if( !strArr[i] )
			continue;
		strNew += *strArr[i];
		if( i < sz-1 )
			strNew += BString(FORWARD_SLASH_CHAR);
		BrDELETE strArr[i];
	}
	
	strName = strNew;
}

BrBOOL PackageRelationshipCollection::CallbackStartElement(LPVOID pParam)
{
	XMLDataDecodeParam* pInfo = (XMLDataDecodeParam*)pParam;

	pInfo->callbackParam.pCurrentInstance = this;

	//[20141219][jdjang][OFF-354] ANR �̽� ����
	if ( (size() % 100) == 0 )
		BoraThreadYield( BIHANDLE_BRCONTEXT );

	BrINT32	i;
	if( strcmp(pInfo->pElementData->pElementName, RELATIONSHIP_TAG_NAME)==0 )
	{
		BrBOOL fCorePropertiesRelationship = BrFALSE, bNeedFullTargetName = BrFALSE;
		BString id, type, str;
		TargetMode	targetMode = INTERNAL;
		Bora_URI*	target=BrNULL;
		for (i = 0; pInfo->pElementData->pAttributePairs[i]; i += 2)
		{
			if( strcmp(pInfo->pElementData->pAttributePairs[i], ID_ATTRIBUTE_NAME)==0 )
			{
				id = pInfo->pElementData->pAttributePairs[i+1];
			}
			else if( strcmp(pInfo->pElementData->pAttributePairs[i], TYPE_ATTRIBUTE_NAME)==0 )
			{
				type = pInfo->pElementData->pAttributePairs[i+1];
				if( strcmp(pInfo->pElementData->pAttributePairs[i+1], CORE_PROPERTIES_PART_TYPE)==0 )
				{
					if (!fCorePropertiesRelationship)
						fCorePropertiesRelationship = BrTRUE;
					else
					{
#ifdef BORA_THREAD_SUPPORT
						BRTHREAD_ASSERT(BrFALSE);
#endif
						return BrFALSE;
					}
				}
			}
			else if( strcmp(pInfo->pElementData->pAttributePairs[i], TARGET_ATTRIBUTE_NAME)==0 )
			{
#if 1			// ���� ����Ÿ�� latin�� �ƴ� ��찡 �־ �ڵ� ��ȯ�� 
				int nLen =  BrStrLen(pInfo->pElementData->pAttributePairs[i+1]);
				if( nLen > 0)
				{
					nLen = BrMIN( nLen, BORA_LENGTH_2048 ); // [2017/5/30][hyunwook][XPD-17433] �ִ� ���� ����( ��Ȯ�� ������ ���� 2048�� �ִ�ġ ���� )
					BrUSHORT *pOutput = (BrUSHORT*)BrMalloc((nLen + 1)*2);
					memset(pOutput, 0, (nLen + 1)*2);	
					
					//[TID:30093][sohyunhwang] ù ���ڰ� '/' �� ���, ��ȯ�ϴ� ���ڿ��� ���̴� �����ϴµ�, �����ϱ� �� ���̸� �״�� ����Ͽ� ��ȯ�ϴ� �κ� ����
					BrBOOL isSlashAtFirstChar = pInfo->pElementData->pAttributePairs[i+1][0]=='/' ;
					int nSize= BrMultiByteToWideChar( CP_UTF8, (BrLPCSTR)pInfo->pElementData->pAttributePairs[i+1]+(isSlashAtFirstChar?1:0), nLen-(isSlashAtFirstChar?1:0), (BrLPWSTR)pOutput, nLen-(isSlashAtFirstChar?1:0));
					
					for (int n=0;n<nSize;n++)
						str += BChar(pOutput[n]);
					bora_slashify(str);
					if (pInfo->pElementData->pAttributePairs[i+1][0]!='/')
						bNeedFullTargetName = BrTRUE;

					BrFree(pOutput);
				}
#else
				if( strlen(pInfo->pElementData->pAttributePairs[i+1]) > 1 && pInfo->pElementData->pAttributePairs[i+1][0]=='/' ) //target �� relative �� �������� �Ѵ�. Office Mobile ���� .rels ������ target �� /xx/xxx.xml �� �Ǿ� ����.
				{
					//�����н��� �Ǿ� �ִ� ���� �״�� ����Ѵ�. �����н� ������ ù ���ڰ� '/' �� ���� ������.
					str = pInfo->pElementData->pAttributePairs[i+1]+1;
					bora_slashify(str);
				}
				else
				{
					str = pInfo->pElementData->pAttributePairs[i+1];
					bora_slashify(str);
					MakeFullTargetName(str);
				}
#endif
			}
			else if( strcmp(pInfo->pElementData->pAttributePairs[i], TARGET_MODE_ATTRIBUTE_NAME)==0 )
			{
				if( BString(pInfo->pElementData->pAttributePairs[i+1]).lower()=="internal" )
					targetMode = INTERNAL;
				else
					targetMode = EXTERNAL;
			}
		}

		if(bNeedFullTargetName && EXTERNAL != targetMode)//MakeFullTargetName�� ��� TargetMode�� External�� ��� ���� �ʾƾ� �ϹǷ� ���� ����
			MakeFullTargetName(str);

		if(EXTERNAL == targetMode && GetDocumentTypeBwp() == BORA_DOCTYPE_DOCX && !type.contains("hyperlink"))
		{
			BrINT32 nLen = 0;
			BrBYTE* pOutData = BrNULL;
			pOutData = CUtil::UnicodeToKSC5601(str, &nLen);
			BString strImageFilePath((char*)pOutData);

			str = strImageFilePath;
			ftLibraryBase::URLDecode(str);
			str.ascii();
			BR_SAFE_FREE(pOutData);
		}

		//  [12/13/2013 chunrans4] sheet/externalLink.xml.rel �� target ���� �ּ� '/' �� �ڸ��°� ���� ���ؼ� ����
		if(EXTERNAL == targetMode && pInfo->pElementData->pAttributePairs[i+1][0]=='/')
			str.insert(0,'/');


		target = BrNEW Bora_URI(str);
//		BTrace("target=%s targetMode=%d, type=%s, id=%s", target->getPath().data(), targetMode, type.data(), id.data());
BTrace("%s(%d) %s target=%s targetMode=%d, type=%s, id=%s", __FILE__, __LINE__, __FUNCTION__, target->getPath().data(), targetMode, type.data(), id.data());

		addRelationship(target, targetMode, type, id);
	}

	return BrTRUE;
}


//test code
void PackageRelationshipCollection::display()
{
	BrTrace("[[[[PackageRelationshipCollection]]]]");
	for(BrINT32 i=0; i<(BrINT32)m_relationshipsByID.size(); i++)
		m_relationshipsByID[i]->m_relationship->display();
}


BrBYTE PackageRelationshipCollection::GetDocumentTypeBwp()
{
	return poBwp_getDocType();
}
#endif //SUPPORT_XML_PARSER
