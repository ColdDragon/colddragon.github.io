#include <OfficePreComp.hpp>

#ifdef SUPPORT_XML_PARSER

#include "package_partname.h"
#include "package_uri_helper.h"
#include "binterfacehandle.h"
#include "butil.h"

#ifndef MAX_PATH
#define MAX_PATH          260
#endif

BoraPackagePartName::BoraPackagePartName(Bora_URI* uri, BrBOOL checkConformance)
{
#if 0
	if (checkConformance) 
	{
		IsInvalidPartUri(uri);
	} 
	else 
	{
		if (!(*PackagingURIHelper::PACKAGE_ROOT_URI==*uri)) 
		{
			SET_INFO_LOG("OCP conformance must be check for ALL part name except special cases : ['/']");
#ifdef BORA_THREAD_SUPPORT
			BRTHREAD_ASSERT(BrFALSE);
#endif
		}
	}
#endif

	m_PartNameURI = *uri;
	m_bIsRelationship = IsRelationshipPartURI(&m_PartNameURI);
}

BoraPackagePartName::BoraPackagePartName(BString partName, BrBOOL checkConformance)
{
	Bora_URI partURI(partName);

	if (checkConformance) 
	{
		if( !IsInvalidPartUri(&partURI) )
		{
			SET_INFO_LOG(partURI.path().data());
#ifdef BORA_THREAD_SUPPORT
			BRTHREAD_ASSERT(BrFALSE);
#endif
		}
	} 
	else 
	{
#ifdef NOT_USE_GLOBAL_VARIABLE
		if (!(*PACKAGE_ROOT_URI==partURI)) 
#else //NOT_USE_GLOBAL_VARIABLE
		if (!(*PackagingURIHelper::PACKAGE_ROOT_URI==partURI)) 
#endif //NOT_USE_GLOBAL_VARIABLE
		{
			SET_INFO_LOG("OCP conformance must be check for ALL part name except special cases : ['/']");
			SET_INFO_LOG(partURI.path().data());
#ifdef BORA_THREAD_SUPPORT
			BRTHREAD_ASSERT(BrFALSE);
#endif
		}
	}
	m_PartNameURI = partURI;
	m_bIsRelationship = IsRelationshipPartURI(&m_PartNameURI);
}

BoraPackagePartName::~BoraPackagePartName()
{
}

BrBOOL BoraPackagePartName::DoesPartNameNotStartsWithForwardSlashChar(Bora_URI* partUri) 
{
	BString uriPath = partUri->path();
	if (uriPath.length() > 0
		&& uriPath.at(0) != FORWARD_SLASH_CHAR)
	{
		SET_INFO_LOG("A part name shall start with a forward slash ('/') character [M1.4]:");
		SET_INFO_LOG(partUri->path().data());
#ifdef BORA_THREAD_SUPPORT
		BRTHREAD_ASSERT(BrFALSE);
#endif
		return BrFALSE;
	}
	return BrTRUE;
}


BrBOOL BoraPackagePartName::DoesPartNameEndsWithForwardSlashChar(Bora_URI* partUri)
{
	BString uriPath = partUri->path();
	if (uriPath.length() > 0
			&& uriPath.at((BrINT32)uriPath.length() - 1) == FORWARD_SLASH_CHAR)
	{
		SET_INFO_LOG("A part name shall not have a forward slash as the last character [M1.5]:");
		SET_INFO_LOG(partUri->path().data());
#ifdef BORA_THREAD_SUPPORT
		BRTHREAD_ASSERT(BrFALSE);
#endif
		return BrFALSE;
	}
	return BrTRUE;
}

BrBOOL BoraPackagePartName::IsInvalidPartUri(Bora_URI* partUri)
{
	if (partUri == BrNULL)
	{
		SET_INFO_LOG("part name is null !!!!");
#ifdef BORA_THREAD_SUPPORT
		BRTHREAD_ASSERT(BrFALSE);
#endif
		return BrFALSE;
	}
	// Check if the part name URI is empty [M1.1]
	if( !IsEmptyURI(partUri) )
		return BrFALSE;

	// Check if the part name URI is absolute
	if( !IsAbsoluteUri(partUri) )
		return BrFALSE;

	// Check if the part name URI starts with a forward slash [M1.4]
	if( !DoesPartNameNotStartsWithForwardSlashChar(partUri) )
		return BrFALSE;

	// Check if the part name URI ends with a forward slash [M1.5]
	if( !DoesPartNameEndsWithForwardSlashChar(partUri) )
		return BrFALSE;

	// Check if the part name does not have empty segments. [M1.3]
	// Check if a segment ends with a dot ('.') character. [M1.9]
	if( !DoesPartNameHaveInvalidSegments(partUri) )
		return BrFALSE;

	return BrTRUE;
}

BrBOOL BoraPackagePartName::DoesPartNameHaveInvalidSegments(Bora_URI* partUri)
{
	if (partUri->path()=="") 
	{
		BString url = partUri->getUrl();
		BrAutoChar autoURI = CUtil::convertBStringToChar(&url, CP_UTF8);
		SET_ERROR_LOG_FILE(kPoErr, 0, (char*)autoURI.get(), "PartNameHaveInvalidSegments", false);
#ifdef BORA_THREAD_SUPPORT
//		BRTHREAD_ASSERT(BrFALSE);
#endif
		return BrFALSE;
	}

	BrCHAR	buf[MAX_PATH];
	
	BString url = partUri->getUrl();

	BrINT32 urlLen = url.length();
	BrINT32	i, nIndex;

	for(i=0; i<urlLen; i++)
	{
		memset(buf, 0, MAX_PATH);
		nIndex = 0;
		for(;i<urlLen; i++)
		{
			if( url.at(i).latin1()=='/' )
				break;
			buf[nIndex++] = url.at(i).latin1();
		}

		if(!nIndex )
			continue;

		if( buf[nIndex-1]=='.' )
			return BrFALSE;

		if(!CheckPCharCompliance(buf) )
			return BrFALSE;
	}

	return BrTRUE;
}

BrBOOL BoraPackagePartName::IsAbsoluteUri(Bora_URI* partUri)
{
	
	if (partUri->isRelativeUrl(partUri->path()))
	{
		BrTrace("Absolute URI forbidden");
		BrTrace("[%s] : [%s][%d]", (char*)partUri->path().data(), __FILE__, __LINE__ );
#ifdef BORA_THREAD_SUPPORT
//		BRTHREAD_ASSERT(BrFALSE);
#endif
		return BrFALSE;
	}
	return BrTRUE;
}

BrBOOL BoraPackagePartName::IsEmptyURI(Bora_URI* partURI)
{
	if (partURI == BrNULL)
	{
		SET_INFO_LOG("partURI is null !!!!");
#ifdef BORA_THREAD_SUPPORT
//		BRTHREAD_ASSERT(BrFALSE);
#endif
		return BrFALSE;
	}

	BString uriPath = partURI->path();
	if (uriPath.length() == 0
		|| ((uriPath.length() == 1) && (uriPath.at(0) == FORWARD_SLASH_CHAR)))
	{
		BrAutoChar autoURI = CUtil::convertBStringToChar(&uriPath, CP_UTF8);
		SET_ERROR_LOG_FILE(kPoErr, 0, (char*)autoURI.get(), "A part name shall not be empty [M1.1]:", false);
#ifdef BORA_THREAD_SUPPORT
//		BRTHREAD_ASSERT(BrFALSE);
#endif
		return BrFALSE;
	}
	return BrTRUE;
}

BrBOOL BoraPackagePartName::IsRelationshipPartURI() 
{
	return m_bIsRelationship;
}

BrBOOL BoraPackagePartName::IsRelationshipPartURI(Bora_URI* partUri) 
{
	if (partUri == BrNULL)
	{
		SET_INFO_LOG("A part name shall not be null");
#ifdef BORA_THREAD_SUPPORT
//		BRTHREAD_ASSERT(BrFALSE);
#endif
		return BrFALSE;
	}

	if( partUri->path().contains(RELATIONSHIP_PART_SEGMENT_NAME) && partUri->fileName().contains(RELATIONSHIP_PART_EXTENSION_NAME) )
		return BrTRUE;
	return BrFALSE;
}

BrBOOL BoraPackagePartName::CheckPCharCompliance(BrCHAR* segment)
{
	BrBOOL	errorFlag;
	BrCHAR	buf[8];
	BrINT32	len = BrStrLen(segment);

	for (BrINT32 i = 0; i < len; ++i) 
	{
		BrCHAR c = segment[i];
		errorFlag = BrTRUE;

		/* Check rule M1.6 */

		// Check for digit or letter
		if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')
				|| (c >= '0' && c <= '9')) 
		{
			errorFlag = BrFALSE;
		} 
		else 
		{
			BrINT32 j;
			// Check "-", ".", "_", "~"
			for (j = 0; j < RFC3986_PCHAR_UNRESERVED_SUP_LENGTH; ++j) 
			{
				if (c == RFC3986_PCHAR_UNRESERVED_SUP[j]) 
				{
					errorFlag = BrFALSE;
					break;
				}
			}

			// Check ":", "@"
			for (j = 0; errorFlag
					&& j < RFC3986_PCHAR_AUTHORIZED_SUP_LENGTH; ++j) 
			{
				if (c == RFC3986_PCHAR_AUTHORIZED_SUP[j]) 
				{
					errorFlag = BrFALSE;
				}
			}

			// Check "!", "$", "&", "'", "(", ")", "*", "+", ",", ";", "="
			for (j = 0; errorFlag
					&& j < RFC3986_PCHAR_SUB_DELIMS_LENGTH; ++j) 
			{
				if (c == RFC3986_PCHAR_SUB_DELIMS[j]) 
				{
					errorFlag = BrFALSE;
				}
			}
		}

		if (errorFlag && c == '%') 
		{
			// We certainly found an encoded character, check for length
			// now ( '%' HEXDIGIT HEXDIGIT)
			if (((len - i) < 2)) 
			{
				BrTrace("The segment contain invalid encoded character !");
				BrTrace(segment);
#ifdef BORA_THREAD_SUPPORT
				BRTHREAD_ASSERT(BrFALSE);
#endif
				return BrFALSE;
			}

			// If not percent encoded character error occur then reset the
			// flag -> the character is valid
			errorFlag = BrFALSE;

			// Decode the encoded character
			memset(buf, 0, 8);
			buf[0] = segment[i+1];
			buf[1] = segment[i+2];
			i += 2;

			BrCHAR decodedChar = (BrCHAR) BrAtoX(buf);

			/* Check rule M1.7 */
			if (decodedChar == '/' || decodedChar == '\\')
			{
				SET_INFO_LOG("A segment shall not contain percent-encoded forward slash ('/'), or backward slash ('\') characters. [M1.7]");
#ifdef BORA_THREAD_SUPPORT
				BRTHREAD_ASSERT(BrFALSE);
#endif
				return BrFALSE;
			}

			/* Check rule M1.8 */

			// Check for unreserved character like define in RFC3986
			if ((decodedChar >= 'A' && decodedChar <= 'Z')
					|| (decodedChar >= 'a' && decodedChar <= 'z')
					|| (decodedChar >= '0' && decodedChar <= '9'))
				errorFlag = BrTRUE;

			// Check for unreserved character "-", ".", "_", "~"
			for (BrINT32 j = 0; !errorFlag
					&& j < RFC3986_PCHAR_UNRESERVED_SUP_LENGTH; ++j) {
				if (c == RFC3986_PCHAR_UNRESERVED_SUP[j]) {
					errorFlag = BrTRUE;
					break;
				}
			}
			if (errorFlag)
			{
				SET_INFO_LOG("A segment shall not contain percent-encoded unreserved characters. [M1.8]");
#ifdef BORA_THREAD_SUPPORT
				BRTHREAD_ASSERT(BrFALSE);
#endif
				return BrFALSE;
			}
		}

		if (errorFlag)
		{
			SET_INFO_LOG("A segment shall not hold any characters other than pchar characters. [M1.6]");
#ifdef BORA_THREAD_SUPPORT
			BRTHREAD_ASSERT(BrFALSE);
#endif
			return BrFALSE;
		}
	}

	return BrTRUE;
}

BrINT32 BoraPackagePartName::CompareTo(BoraPackagePartName* otherPartName) 
{
	if (otherPartName == BrNULL)
		return -1;
	return m_PartNameURI.toString().lower().compare(otherPartName->m_PartNameURI.toString().lower());
}

BString BoraPackagePartName::getExtension() 
{
	BString fragment = m_PartNameURI.path();
	if (fragment.length() > 0) 
	{
		BrINT32 i = fragment.findRev('.');
		if (i > -1)
			return fragment.right(fragment.length()-(i + 1));
	}
	return "";
}

BrBOOL BoraPackagePartName::equals(BoraPackagePartName* otherPartName)
{
	if (otherPartName == BrNULL )
			return BrFALSE;
	return m_PartNameURI.toString().lower().compare(otherPartName->m_PartNameURI.toString().lower())==0;
}

BrBOOL BoraPackagePartName::equals(BString a_strPartName)
{
	if (a_strPartName == BrNULL )
		return BrFALSE;
	return m_PartNameURI.toString().lower().compare(a_strPartName)==0;
}

BrINT32 BoraPackagePartName::hashCode() 
{
	const BrCHAR* pChar = m_PartNameURI.getUrl().data();
	BrINT32 i, nLen = BrStrLen(pChar);
	BrINT32 code=0;
	for(i=0; i<nLen; i++)
	{
		code += pChar[i]*32^(nLen-i-1);
	}
	return code;
}

Bora_URI* BoraPackagePartName::getURI() 
{
	return &m_PartNameURI;
}

BString BoraPackagePartName::getName() 
{
	return m_PartNameURI.toString(BrFALSE, BrFALSE);
}

BoraPackagePartName* BoraPackagePartName::clone()
{
	BoraPackagePartName* pPartName = PackagingURIHelper::createPartName(&m_PartNameURI);
	pPartName->m_bIsRelationship = m_bIsRelationship;
	return pPartName;
}

BString BoraPackagePartName::toString() 
{
	return getName();
}

#endif //SUPPORT_XML_PARSER
