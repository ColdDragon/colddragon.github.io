#include <OfficePreComp.hpp>

#ifdef SUPPORT_XML_PARSER


#include "bmvstream.h"
#include "SAX/Expat/xmldecoder.h"
#include "package_uri_helper.h"
#include "package_ct_manager.h"
#include "package_partname.h"


Override_ContentType::Override_ContentType(BoraPackagePartName* partName, BString contentType)
{
	m_partname = partName;
	m_contenttype = contentType;
};

Override_ContentType::~Override_ContentType() 
{
	BrDELETE m_partname;
};

/////
void BoraContentTypeManager::display()
{
	BrINT32 i;
	BrTrace("----- default content type");
	for(i=0; i<(BrINT32)m_defContentTypeArray.size();i++)
	{
		BrTrace("Extention=\"%s\" ContentType=\"%s\"", m_defContentTypeArray[i]->m_extention.data(), m_defContentTypeArray[i]->m_contenttype.data());
	}

	BrTrace("----- override content type");
	for(i=0; i<(BrINT32)m_overrideContentTypeArray.size();i++)
	{
		BrTrace("Partname=\"%s\" ContentType=\"%s\"", m_overrideContentTypeArray[i]->m_partname->getURI()->toString().data(), m_overrideContentTypeArray[i]->m_contenttype.data());
	}
}

BoraContentTypeManager::BoraContentTypeManager()
{
}

BoraContentTypeManager::~BoraContentTypeManager()
{
	BrINT32 i;

	for(i=0; i<(BrINT32)m_defContentTypeArray.size();i++)
		BrDELETE m_defContentTypeArray[i];
	m_defContentTypeArray.resize(0);

	for(i=0; i<(BrINT32)m_overrideContentTypeArray.size();i++)
		BrDELETE m_overrideContentTypeArray[i];
	m_overrideContentTypeArray.resize(0);
}

BrBOOL BoraContentTypeManager::CallbackStartElement(LPVOID pParam)
{
	XMLDataDecodeParam* pInfo = (XMLDataDecodeParam*)pParam;

	pInfo->callbackParam.pCurrentInstance = this;

	BrINT32	i;
	if( strcmp(pInfo->pElementData->pElementName, DEFAULT_TAG_NAME)==0 )
	{
		BString extension;
		BString contentType;
		for (i = 0; pInfo->pElementData->pAttributePairs[i]; i += 2)
		{
			if( strcmp(pInfo->pElementData->pAttributePairs[i], EXTENSION_ATTRIBUTE_NAME)==0 )
				extension = pInfo->pElementData->pAttributePairs[i+1];
			else if( strcmp(pInfo->pElementData->pAttributePairs[i], CONTENT_TYPE_ATTRIBUTE_NAME)==0 )
			{
				contentType = pInfo->pElementData->pAttributePairs[i+1];
			}
		}
		if (!extension.isEmpty() && !contentType.isEmpty())
			addDefaultContentType(extension, contentType);
	}
	else if( strcmp(pInfo->pElementData->pElementName, OVERRIDE_TAG_NAME)==0 )
	{
		BoraPackagePartName* pPartName=BrNULL;
		//[2012.04.12][�����][TID:5680] [Content_Types].xml�� �޸� override element�� attribute������ �ݴ�� �� ��� �״� ���� ����
		BString contentType;
		for (i = 0; pInfo->pElementData->pAttributePairs[i]; i += 2)
		{
			if( strcmp(pInfo->pElementData->pAttributePairs[i], PART_NAME_ATTRIBUTE_NAME)==0 )
			{
				BString strUri = pInfo->pElementData->pAttributePairs[i+1];
				Bora_URI uri(strUri);
				pPartName = PackagingURIHelper::createPartName(&uri);
			}
			else if( strcmp(pInfo->pElementData->pAttributePairs[i], CONTENT_TYPE_ATTRIBUTE_NAME)==0 )
				contentType = pInfo->pElementData->pAttributePairs[i+1];
		}

		if (pPartName && contentType.length())
		{
			addOverrideContentType(pPartName, contentType);
			pPartName = BrNULL;
		}
		BR_SAFE_DELETE(pPartName);
	}

	return BrFALSE;
}

BrBOOL BoraContentTypeManager::defaultContentType_containsKey(BString& ext)
{
	for(BrINT32 i=0; i<(BrINT32)m_defContentTypeArray.size();i++)
	{
		if( ext==m_defContentTypeArray[i]->m_extention )
			return BrTRUE;
	}
	return BrFALSE;
}

BrBOOL BoraContentTypeManager::overrideContentType_containsKey(BoraPackagePartName* partName)
{
	BString strPartName = partName->m_PartNameURI.toString().lower();
	for(BrINT32 i=0; i<(BrINT32)m_overrideContentTypeArray.size();i++)
	{
		if( m_overrideContentTypeArray[i]->m_partname->equals(strPartName) )
			return BrTRUE;
	}
	return BrFALSE;
}

BrBOOL BoraContentTypeManager::defaultContentType_containsValue(BString& contentType)
{
	for(BrINT32 i=0; i<(BrINT32)m_defContentTypeArray.size();i++)
	{
		if( contentType==m_defContentTypeArray[i]->m_contenttype )
			return BrTRUE;
	}
	return BrFALSE;
}

void BoraContentTypeManager::addContentType(BoraPackagePartName* partName, BString contentType) 
{
	BrBOOL defaultCTExists = BrFALSE;
	BString extension = partName->getExtension().lower();
	if ((extension.length() == 0)
				|| (defaultContentType_containsKey(extension) && !(defaultCTExists = defaultContentType_containsValue(contentType))))
	{
		addOverrideContentType(partName, contentType);
	}
	else if (!defaultCTExists)
	{
		addDefaultContentType(extension, contentType);
	}
}

void BoraContentTypeManager::addDefaultContentType(BString extension, BString contentType) 
{
	Default_ContentType* p = BrNEW Default_ContentType(extension.lower(), contentType.lower());
	m_defContentTypeArray.Add(p);
}

void BoraContentTypeManager::addOverrideContentType(BoraPackagePartName* partName, BString contentType) 
{
	Override_ContentType* p = BrNEW Override_ContentType(partName, contentType);
	m_overrideContentTypeArray.Add(p);
}

BString BoraContentTypeManager::defaultContentType_get(BString& ext)
{
	for(BrINT32 i=0; i<(BrINT32)m_defContentTypeArray.size();i++)
	{
		if( ext==m_defContentTypeArray[i]->m_extention )
			return m_defContentTypeArray[i]->m_contenttype;
	}
	return "";
}

BString BoraContentTypeManager::overrideContentType_get(BoraPackagePartName* partName)
{
	for(BrINT32 i=0; i<(BrINT32)m_overrideContentTypeArray.size();i++)
	{
		if( m_overrideContentTypeArray[i]->m_partname->equals(partName) )
			return m_overrideContentTypeArray[i]->m_contenttype;
	}
	return "";
}

void BoraContentTypeManager::overrideContentType_remove(BoraPackagePartName* partName)
{
	for(BrINT32 i=0; i<(BrINT32)m_overrideContentTypeArray.size();i++)
	{
		if( m_overrideContentTypeArray[i]->m_partname->equals(partName) )
		{
			BrDELETE m_overrideContentTypeArray[i];
			m_overrideContentTypeArray.RemoveAt(i);
			return;
		}
	}
}

void BoraContentTypeManager::defaultContentType_remove(BString extensionToDelete)
{
	for(BrINT32 i=0; i<(BrINT32)m_defContentTypeArray.size();i++)
	{
		if( extensionToDelete==m_defContentTypeArray[i]->m_extention )
		{
			BrDELETE m_defContentTypeArray[i];
			m_defContentTypeArray.RemoveAt(i);
			return;
		}
	}
}

void BoraContentTypeManager::removeContentType(BoraPackagePartName* partName)
{
	if (partName == BrNULL)
			return;

	/* Override content type */
	if (m_overrideContentTypeArray.size() && (overrideContentType_get(partName) != BrNULL)) 
	{
		// Remove the override definition for the specified part.
		overrideContentType_remove(partName);
		return;
	}

	/* Default content type */
	BString extensionToDelete = partName->getExtension();
	BrBOOL deleteDefaultContentTypeFlag = BrTRUE;

#if 1 //package ���� ��
#pragma	message("need to implement : type delete (package_ct_manager.cpp)")
#endif

		// Remove the default content type, no other part use this content type.
		if (deleteDefaultContentTypeFlag) {
			defaultContentType_remove(extensionToDelete);
		}
#if 1
#pragma	message("need to implement : type delete (package_ct_manager.cpp)")
#endif
}

BrBOOL BoraContentTypeManager::overrideContentType_containsValue(BString contentType)
{
	for(BrINT32 i=0; i<(BrINT32)m_overrideContentTypeArray.size();i++)
	{
		if( m_overrideContentTypeArray[i]->m_contenttype==contentType )
			return BrTRUE;
	}
	return BrFALSE;
}

BrBOOL BoraContentTypeManager::isContentTypeRegister(BString contentType) 
{
	if (contentType.isEmpty())
		return BrFALSE;

	return (defaultContentType_containsValue(contentType) || (m_overrideContentTypeArray.size() && overrideContentType_containsValue(contentType)));
}

BString BoraContentTypeManager::getContentType(BoraPackagePartName* partName) 
{
	if(partName == BrNULL)
		return "";

	//[2013.08.24][TID : 16752][���ؼ�] ContentType ȹ�� ��� ����
	BString extension = partName->getExtension().lower();
	if(defaultContentType_containsKey(extension))
		return defaultContentType_get(extension);

	if(m_overrideContentTypeArray.size() && overrideContentType_containsKey(partName))
		return overrideContentType_get(partName);

	return "";
}

void BoraContentTypeManager::clearAll() 
{
	BrINT32 i;
	for(i=0; i<(BrINT32)m_defContentTypeArray.size();i++)
		BrDELETE m_defContentTypeArray[i];
	m_defContentTypeArray.resize(0);

	for(i=0; i<(BrINT32)m_overrideContentTypeArray.size();i++)
		BrDELETE m_overrideContentTypeArray[i];
	m_overrideContentTypeArray.resize(0);
}

void BoraContentTypeManager::clearOverrideContentTypes() 
{
	BrINT32 i;
	for(i=0; i<(BrINT32)m_overrideContentTypeArray.size();i++)
		BrDELETE m_overrideContentTypeArray[i];
	m_overrideContentTypeArray.resize(0);
}

#endif
