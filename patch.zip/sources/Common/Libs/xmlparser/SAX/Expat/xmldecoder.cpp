#include <OfficePreComp.hpp>

#ifdef SUPPORT_XML_PARSER

#include "xmldecoder.h"
#include "SystemTypes_i.h"
#include "expat.h"
#include "bmvstream.h"
#include "PrImageSignature.h"
#include "XmlZipLoader.h"
#include "brmcoreimpdef.h"
#include "brmcoreproc.h"
#include "prbitmap.h"
#include "binterfacehandle.h"
#include "../Error/ErrorHandle.h"  // ErrMsg
//#define	DEBUG_MESSAGE


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

static void  
BR_XML_InitUserData(BR_XML_Parser_User_Data *pParser_User_Data, LPCallbackParam pCallbackParam)
{
	if( pCallbackParam==BrNULL )
	{
		memset(pParser_User_Data, 0, sizeof(BR_XML_Parser_User_Data));
		return;
	}
	pParser_User_Data->depth = 0;
	pParser_User_Data->szCharacterData[0] = '\0';
	pParser_User_Data->iCharacterDataIndex = 0;

	pParser_User_Data->szCharacterDataExt = 0;
	pParser_User_Data->iCharacterDataIndexExt = 0;
	
	memset(&pParser_User_Data->CallbackInfo, 0, sizeof(BR_XML_Parser_Callback_Info)*MAX_ELEMENT_DEPTH);
	
	//�ֻ��� Element �� ó���� callback �Լ��� �����Ѵ�.
	memcpy(&pParser_User_Data->CallbackInfo[0].callbackParam, pCallbackParam, sizeof(CallbackParam));
}

static void XMLCALL
BR_XML_Start_Element(void *userData, const char *name, const char **atts)
{
	BR_XML_Parser_User_Data* pParserUserData = (BR_XML_Parser_User_Data*) userData;

	const int depth = pParserUserData->depth;
	if (MAX_ELEMENT_DEPTH <= depth)  // AOM-52924 beyond MAX_ELEMENT_DEPTH
		BRTERMINATE(kPoErrBufferOverFlow, ErrMsg("depth=%d", depth), PO_FILTER_CLASS);

	//���� Element �� �θ� Instance ���� ó���Ѵ�.
	BrINT32	nParentIndex = BrMAX(0, depth - 1);

	XMLDataDecodeParam	param;
	param.pCurPackagePartName = pParserUserData->pCurPackagePartName;
	param.pElementData = &pParserUserData->elementData;
	param.pElementData->pAttributePairs = atts;
	param.pElementData->pElementName = name;//trimNamespace(name);
	param.pElementData->pTextData = 0;
	param.nElementOption = pParserUserData->CallbackInfo[nParentIndex].nElementOption & BR_XML_SKIP_ELEMENT; //skip �� �θ� ����� �Ѵ�.
	memcpy(&param.callbackParam, &pParserUserData->CallbackInfo[nParentIndex].callbackParam, sizeof(CallbackParam));

	if( !(pParserUserData->CallbackInfo[nParentIndex].nElementOption & BR_XML_SKIP_ELEMENT) )
	{
		//�� Element �� ó�� �ϵ��� ������Ʈ�� �Լ��� ȣ���Ѵ�.
		if( param.callbackParam.pCurrentInstance )
			((BrCallbackBase*)param.callbackParam.pCurrentInstance)->CallbackStartElement(&param);
	}

	//Element �� ó���� �� ���� ������ ������Ʈ�� �����Ѵ�. 
	//�� ������Ʈ�� �Լ��� �ڽ� Element(pParserUserData->depth+1) ó�� �� ȣ��ȴ�.
	memcpy(&pParserUserData->CallbackInfo[depth].callbackParam, &param.callbackParam, sizeof(CallbackParam));
	//Skip ������ �����Ѵ�.
	pParserUserData->CallbackInfo[depth].nElementOption = param.nElementOption;

#ifdef	DEBUG_MESSAGE
	char	szMessage[2048];
	szMessage[0] = 0;

	char	szTemp[1024];
	int i;
	for (i = 0; i < depth; i++)
		strcat(szMessage, "  ");	// indentation;

	//		Tag name;
	sprintf(szTemp, "[%s]", name);
	strcat(szMessage, szTemp);
	BrTrace(szMessage);

	//		Attributes;
	szMessage[0] = 0;
	for (i = 0; i < depth; i++)
		strcat(szMessage, "  ");	// indentation;
	for (i = 0; atts[i]; i += 2)
		BrTrace("%s%s='%s'", szMessage, atts[i], atts[i + 1]);
#endif //DEBUG_MESSAGE

	//	Character Data Buffer Initialize;
	pParserUserData->szCharacterData[0] = '\0'; 
	pParserUserData->iCharacterDataIndex = 0;

	pParserUserData->depth++;
}


/* desoohn:
	�Ʒ��� ���� ���, EndElement callback�� ���ؼ� char �����͸� ���� ����. 
	expat ���̺귯���� Start/End callback�� �Բ� char ������ callback�� ���� ����ؾ� ��.

	<text:p text:style-name="P1">
		<text:change-start text:change-id="ct244949160"/>
		Abcd ef
		<text:change-end text:change-id="ct244949160"/>
		<text:change-start text:change-id="ct244949472"/>
		aa
		<text:change-end text:change-id="ct244949472"/>
	</text:p>
*/
static void XMLCALL
BR_XML_Character_Data_ODT(BrINT32 nParentIndex, BR_XML_Parser_User_Data *pParserUserData, BrBOOL bNormal)
{
	if ((pParserUserData->CallbackInfo[nParentIndex].nElementOption & BR_XML_NEED_CHAR_DATA) == 0)
		return;

	XMLDataDecodeParam param;
	param.pCurPackagePartName = pParserUserData->pCurPackagePartName;
	param.pElementData = &pParserUserData->elementData;
	param.pElementData->pAttributePairs = 0;
	if (bNormal) {
		param.pElementData->pTextData = pParserUserData->szCharacterData;
		param.pElementData->nTextData = pParserUserData->iCharacterDataIndex;
	} else {
		param.pElementData->pTextData = pParserUserData->szCharacterDataExt;
		param.pElementData->nTextData = pParserUserData->iCharacterDataIndexExt;
	}

	memcpy(&param.callbackParam, &pParserUserData->CallbackInfo[pParserUserData->depth].callbackParam, sizeof(CallbackParam));
	BrCallbackBase* callback = (BrCallbackBase*)pParserUserData->CallbackInfo[BrMAX(0, pParserUserData->depth-1)].callbackParam.pCurrentInstance;
	if (callback == BrNULL)
		return;

	callback->CallbackCharData(&param);

	if (bNormal) {
		pParserUserData->szCharacterData[0] = '\0'; 
		pParserUserData->iCharacterDataIndex = 0;
	} else {
		pParserUserData->szCharacterDataExt[0] = '\0'; 
		pParserUserData->iCharacterDataIndexExt = 0;
	}
	pParserUserData->CallbackInfo[pParserUserData->depth].nElementOption = 0;
	memset(&pParserUserData->CallbackInfo[pParserUserData->depth].callbackParam, 0, sizeof(CallbackParam));
}


static void XMLCALL
BR_XML_Character_Data(void *userData, const char *pData, int len)
{
	BR_XML_Parser_User_Data *pParserUserData = (BR_XML_Parser_User_Data *) userData;

	//���� Element �� �θ� Instance ���� ó���Ѵ�.
	BrINT32	nParentIndex = BrMAX(0, pParserUserData->depth-1);

	// �� �κ��� parser ���� �߸� ó���Ǵ� ���� ������ ������ �ӽ÷� ��.( �����Ǵ� ���.  <t xml:space="preserve"></t> t ���̿� �����Ͱ� ����.)
	//if( len > 1024*5 )
	//	return;

	if( ((pParserUserData->iCharacterDataIndex + len) >= BR_XML_CHARACTER_DATA_BUFFER_LENGTH) ||
		pParserUserData->iCharacterDataIndexExt > 0 )
	{
		BrINT32 nTotalLen, nPrevLen;
		nTotalLen = nPrevLen = 0;
		if( 0 == pParserUserData->iCharacterDataIndexExt)
		{
			nTotalLen = pParserUserData->iCharacterDataIndex + len;
			nPrevLen = pParserUserData->iCharacterDataIndex;

#if 0 // [T16855] ihwa : 2013/08/30
			pParserUserData->szCharacterDataExt = (char*)BrMalloc(nTotalLen+1);
#else
			pParserUserData->szCharacterDataExt = (char*)BrMalloc(nTotalLen + BR_XML_CHARACTER_DATA_BUFFER_LENGTH);
			pParserUserData->iCharacterDataExt = nTotalLen + BR_XML_CHARACTER_DATA_BUFFER_LENGTH;
#endif
			memcpy(pParserUserData->szCharacterDataExt, pParserUserData->szCharacterData, nPrevLen);
			memcpy(pParserUserData->szCharacterDataExt+nPrevLen, pData, len);
		}
		else 
		{
			nTotalLen = pParserUserData->iCharacterDataIndexExt + len;
			nPrevLen = pParserUserData->iCharacterDataIndexExt;
#if 0 // [T16855] ihwa : 2013/08/30
			pParserUserData->szCharacterDataExt = (char*)BrRealloc(pParserUserData->szCharacterDataExt, nTotalLen);
#else
			if (nTotalLen >= pParserUserData->iCharacterDataExt) {
				pParserUserData->iCharacterDataExt = nTotalLen + BR_XML_CHARACTER_DATA_BUFFER_LENGTH;
				pParserUserData->szCharacterDataExt = (char*)BrRealloc(pParserUserData->szCharacterDataExt, pParserUserData->iCharacterDataExt);
			}
#endif
			memcpy(pParserUserData->szCharacterDataExt+nPrevLen, pData, len);
		}

		pParserUserData->szCharacterDataExt[nTotalLen] = '\0';	// NULL-termination;
		pParserUserData->iCharacterDataIndexExt = nTotalLen;

		BR_XML_Character_Data_ODT(nParentIndex, pParserUserData, BrFALSE);
		return;
	}

	len = BrMIN(len, BR_XML_CHARACTER_DATA_BUFFER_LENGTH-1);
	if( len <= 0 )
		return;
	//		Accumulate character data;
	memcpy(pParserUserData->szCharacterData + pParserUserData->iCharacterDataIndex, pData, len);

	pParserUserData->iCharacterDataIndex += len;
	pParserUserData->szCharacterData[pParserUserData->iCharacterDataIndex] = '\0';	// NULL-termination;

	BR_XML_Character_Data_ODT(nParentIndex, pParserUserData, BrTRUE);


#ifdef DEBUG_MESSAGE
	char	szTemp[128];
	szTemp[0]=0;
	for (int i = 0; i < pParserUserData->depth; i++)
		strcat(szTemp, "  ");	// indentation;

	BrTrace("%s%s", szTemp, pParserUserData->szCharacterData);
#endif
}

static void XMLCALL
BR_XML_End_Element(void *userData, const char *name)
{
	BR_XML_Parser_User_Data *pParserUserData = (BR_XML_Parser_User_Data *) userData;
	pParserUserData->depth -= 1;

	if( (pParserUserData->iCharacterDataIndex > 0 || pParserUserData->iCharacterDataIndexExt > 0) || (pParserUserData->CallbackInfo[pParserUserData->depth].nElementOption & BR_XML_NEED_END_ELEMENT) )
	{
		XMLDataDecodeParam	param;
		param.pCurPackagePartName = pParserUserData->pCurPackagePartName;
		param.pElementData = &pParserUserData->elementData;
		param.pElementData->pAttributePairs = 0;
		param.pElementData->pElementName = name;//trimNamespace(name);

		//hnsong:2013-03-18
		if( pParserUserData->iCharacterDataIndexExt > 0)
		{
			param.pElementData->pTextData = pParserUserData->szCharacterDataExt;
			param.pElementData->nTextData = pParserUserData->iCharacterDataIndexExt;	
		}
		else
		{
			param.pElementData->pTextData = pParserUserData->szCharacterData;
			param.pElementData->nTextData = pParserUserData->iCharacterDataIndex;
		}

		memcpy(&param.callbackParam, &pParserUserData->CallbackInfo[pParserUserData->depth].callbackParam, sizeof(CallbackParam));

		if( !(pParserUserData->CallbackInfo[pParserUserData->depth].nElementOption & BR_XML_SKIP_ELEMENT) )
		{
			//�� Element �� ó�� �ϵ��� ������Ʈ�� �Լ��� ȣ���Ѵ�.
			//end element �� ���� element�� callback�� ȣ���Ѵ�.
			BrCallbackBase* pCallback = (BrCallbackBase*)pParserUserData->CallbackInfo[BrMAX(0, pParserUserData->depth-1)].callbackParam.pCurrentInstance;
			if( pCallback )
				pCallback->CallbackEndElement(&param);
		}

		//hnsong:2013-03-18
		if( pParserUserData->iCharacterDataIndexExt > 0)
		{
			BR_SAFE_FREE(pParserUserData->szCharacterDataExt);
			pParserUserData->iCharacterDataIndexExt = 0;
		}
		pParserUserData->szCharacterData[0] = '\0'; 
		pParserUserData->iCharacterDataIndex = 0;
	}

	pParserUserData->CallbackInfo[pParserUserData->depth].nElementOption = 0;
	memset(&pParserUserData->CallbackInfo[pParserUserData->depth].callbackParam, 0, sizeof(CallbackParam));

#ifdef DEBUG_MESSAGE
	char	szMessage[8192];
	char	szTemp[1024];
	int i;

	//		Tag name;
	szMessage[0] = '\0';
	for (i = 0; i < pParserUserData->depth; i++)
		strcat(szMessage, "  ");	// indentation;
	sprintf(szTemp, "[%s/]", name);
	strcat(szMessage, szTemp);
	BrTrace(szMessage);
#endif //DEBUG_MESSAGE

	XML_SetElementHandler(pParserUserData->parser, BR_XML_Start_Element, BR_XML_End_Element);
	XML_SetCharacterDataHandler(pParserUserData->parser, BR_XML_Character_Data);
}

int
__BR_XML_continue_parsing(XML_Parser p, CXmlLoader *pLoader)
{
	enum XML_Status status = XML_ResumeParser(p);
	switch (status) {
		case XML_STATUS_ERROR:
			/* handle error... */
			return 0;
		case XML_ERROR_NOT_SUSPENDED:
			/* handle error... */
			return 0;
		case XML_STATUS_SUSPENDED:
			return 1;
	}
	int ret = __BR_XML_parse_xml(p, pLoader);
	if (ret != 1)
	{
		XML_Error error = XML_GetErrorCode(p);
		if (error != XML_ERROR_NONE)
		{
			BTrace("%s(%d) %s XML_GetErrorCode[0x%x]", __FILE__, __LINE__, __FUNCTION__, error);
			BRTERMINATE(kPoErrDocumentXmlCoorupted, "Failure __BR_XML_parse_xml", PO_FILTER_CLASS);
		}
	}
	return ret;
}

#include "ThreadDefines_i.h"
int
	__BR_XML_parse_xml(XML_Parser p, CXmlLoader *pLoader)
{
	PO_THREAD_TRY_BLOCK {
		const int yield_limit = 500;
		int count = 0;
		for (;;) {
			if( (count++ % yield_limit) == 0 )
				BoraThreadYield( BIHANDLE_BRCONTEXT );
			{
				int bytes_read;
				enum XML_Status status;

				void *buff = XML_GetBuffer(p, XML_BUFFER_SIZE); // 16 MB
				if (buff == NULL) {
					/* handle error... */
					return -1;
				}
				bytes_read = pLoader->Read((char*)buff);
				if (bytes_read < 0) {
					/* handle error... */
					return -1;
				}
				status = XML_ParseBuffer(p, bytes_read, bytes_read == 0);
				
				//if (XML_GetErrorCode(p) == XML_ERROR_INVALID_TOKEN)
				//	return -1;

				switch (status) {
				case XML_STATUS_ERROR:
					/* handle error... */
					return -1;
				case XML_STATUS_SUSPENDED:
					return 1;
				}
				if (bytes_read == 0)
					return 0;
			}
		}
	} PO_THREAD_CATCH_BLOCK {
		::XML_ParserFree(p);
	} PO_THREAD_END
	return -1;
}


void *_BrMalloc_XML(size_t size) {
  return _BrMalloc(size);
}


void *_BrRealloc_XML(void *ptr, size_t size) {
  return _BrRealloc(ptr, size);
}


void _BrFree_XML(void *ptr) {
  return _BrFree(ptr);
}


BrBOOL ParseXMLInfo(CXmlLoader* pLoader, LPCallbackParam pCallbackParam, BoraXmlParserContext* pContext)
{
	BrBOOL	bRet = BrTRUE;

	BR_XML_InitUserData(pContext, pCallbackParam);

	if( !pContext->parser )
	{
		XML_Memory_Handling_Suite	ms;
		ms.malloc_fcn = _BrMalloc_XML;
		ms.realloc_fcn = _BrRealloc_XML;
		ms.free_fcn = _BrFree_XML;
		pContext->parser = XML_ParserCreate_MM(NULL, &ms, NULL);
	}
	else
		XML_ParserReset(pContext->parser, BrNULL);

	if( !pContext->parser )
		return BrFALSE;

	XML_SetUserData(pContext->parser, pContext);
	XML_SetElementHandler(pContext->parser, BR_XML_Start_Element, BR_XML_End_Element);
	XML_SetCharacterDataHandler(pContext->parser, BR_XML_Character_Data);

	if(pLoader)
		pContext->xloader = pLoader;
	bRet = __BR_XML_parse_xml(pContext->parser, pContext->xloader) != -1;
	if (!bRet)
	{
		XML_Error error = XML_GetErrorCode(pContext->parser);
		if (error == XML_ERROR_NO_MEMORY)
		{
			BTrace("%s(%d) %s XML_GetErrorCode[0x%x]", __FILE__, __LINE__, __FUNCTION__, error);
			BRTERMINATE(kPoErrMemory, "Failure __BR_XML_parse_xml", PO_FILTER_CLASS);
		}
	}
	return bRet;
}


int
__BR_XML_continue_parsing(XML_Parser p, BMVStream *stream)
{
	enum XML_Status status = XML_ResumeParser(p);
	switch (status) {
		case XML_STATUS_ERROR:
			/* handle error... */
			return 0;
		case XML_ERROR_NOT_SUSPENDED:
			/* handle error... */
			return 0;
		case XML_STATUS_SUSPENDED:
			return 1;
	}
	int ret = __BR_XML_parse_xml(p, stream);
	if (ret != 1)
	{
		XML_Error error = XML_GetErrorCode(p);
		if (error != XML_ERROR_NONE)
		{
			BTrace("%s(%d) %s XML_GetErrorCode[0x%x]", __FILE__, __LINE__, __FUNCTION__, error);
			BRTERMINATE(kPoErrDocumentXmlCoorupted, "Failure __BR_XML_parse_xml", PO_FILTER_CLASS);
		}
	}
	return ret;
}

/* Parse a document from the open file descriptor 'fd' until the parse
   is complete (the document has been completely parsed, or there's
   been an error), or the parse is stopped.  Return non-zero when
   the parse is merely suspended.
*/
int
__BR_XML_parse_xml(XML_Parser p, BMVStream *stream)
{
	for (;;) {
		int bytes_read;
		enum XML_Status status;

		void *buff = XML_GetBuffer(p, BUFF_SIZE);
		if (buff == NULL) {
			/* handle error... */
			return -1;
		}
		bytes_read = stream->Read((char*)buff, BUFF_SIZE);
		if (bytes_read < 0) {
			/* handle error... */
			return -1;
		}
		status = XML_ParseBuffer(p, bytes_read, bytes_read == 0);
		switch (status) {
			case XML_STATUS_ERROR:
				/* handle error... */
				return -1;
			case XML_STATUS_SUSPENDED:
				return 1;
		}
		if (bytes_read == 0)
			return 0;
	}
}

BrBOOL ParseXMLInfo(BMVStream* pStream, LPCallbackParam pCallbackParam, BoraXmlParserContext* pContext)
{
	BrBOOL	bRet = BrTRUE;

	BR_XML_InitUserData(pContext, pCallbackParam);

	if( !pContext->parser )
	{
		XML_Memory_Handling_Suite	ms;
		ms.malloc_fcn = _BrMalloc_XML;
		ms.realloc_fcn = _BrRealloc_XML;
		ms.free_fcn = _BrFree_XML;
		pContext->parser = XML_ParserCreate_MM(NULL, &ms, NULL);
	}
	else
		XML_ParserReset(pContext->parser, BrNULL);

	if( !pContext->parser )
		return BrFALSE;

	XML_SetUserData(pContext->parser, pContext);
	XML_SetElementHandler(pContext->parser, BR_XML_Start_Element, BR_XML_End_Element);
	XML_SetCharacterDataHandler(pContext->parser, BR_XML_Character_Data);

	if(pStream)
		pContext->stream = pStream;
	bRet = __BR_XML_parse_xml(pContext->parser, pContext->stream) != -1;
	if (!bRet)
	{
		XML_Error error = XML_GetErrorCode(pContext->parser);
		if (error == XML_ERROR_NO_MEMORY)
		{
			BTrace("%s(%d) %s XML_GetErrorCode[0x%x]", __FILE__, __LINE__, __FUNCTION__, error);
			BRTERMINATE(kPoErrMemory, "Failure __BR_XML_parse_xml", PO_FILTER_CLASS);
		}
	}
	return bRet;
}

//�Ѱ��� xml ��Ʈ ó���� ȣ��
void Initialize_XmlParser(BR_XML_Parser_User_Data* pParserContext)
{
	BR_XML_InitUserData(pParserContext, 0);
}

//�Ѱ��� xml ��Ʈ ó�� ���� �� ȣ��
void Finalize_XmlParser(BR_XML_Parser_User_Data* pParserContext)
{
	if( pParserContext->parser )
		XML_ParserFree(pParserContext->parser);
	BR_XML_InitUserData(pParserContext, 0);
}


//�Ѱ��� Part �� ã�� Parse �Ѵ�.
BrBOOL ReadAndParsePart_XmlParser(HZIP hZip, ZIPENTRY* ze, BrINT32 nZipItemIndex, LPCallbackParam pCallbackParam, BrBOOL bNeedSuspend)
{
	BrBOOL nRet = BrFALSE;

	BrUINT32 nSize = BrZipGetItemSize(hZip, nZipItemIndex);
	if(nSize == 0)
	{
		g_BoraThreadAtom.m_nRetOpen = kPoErrXmlSizeZeroParsingFail;
		SET_ERROR((PoError)kPoErrXmlSizeZeroParsingFail, "");

		return BrFALSE;
	}

	if (!bNeedSuspend)	// [WPD-3072] xmlparser �� suspend/resume�� XmlZipLoader�� ���� �ȸ´� �� ����. suspend�Ǵ� stream�� ��� BmvStream �����ϵ��� ��.
	{
		BoraXmlParserContext* context = (BoraXmlParserContext*)BrMalloc(sizeof(BoraXmlParserContext));
		if( !context )
			return BrFALSE;
			
		memset(context, 0, sizeof(BoraXmlParserContext));

		if( bNeedSuspend )
			((BrCallbackBase*)pCallbackParam->pCurrentInstance)->SetXmlParserContext(context);

		Initialize_XmlParser(context);

		context->pCurPackagePartName = ze->name;

#ifdef T_DEBUG
			BrTrace("Read Part : %s", ze.name);
#endif

		CXmlZipLoader *pLoader = BrNEW CXmlZipLoader(hZip, nZipItemIndex, XML_BUFFER_SIZE);	// ���� ũ�⿡ ���� �ӵ����� �̹���
		if (!pLoader)
		{
			g_BoraThreadAtom.m_nRetOpen = kPoErrMemory;
			SET_ERROR((PoError)kPoErrMemory, "");
			return BrFALSE;
		}

		nRet = ParseXMLInfo(pLoader, pCallbackParam, context);

		if( !bNeedSuspend )
		{
			BrDELETE pLoader;
			Finalize_XmlParser(context);
			BrFree(context);
		}
	}
	else
	{
		BrLPBYTE pMem = (BrLPBYTE)BrMalloc(nSize);
		if(pMem)
		{
			if( BrZipExtractMemory(g_szSrcZipPassword, hZip, nZipItemIndex, pMem) )
			{
				BoraXmlParserContext* context = (BoraXmlParserContext*)BrMalloc(sizeof(BoraXmlParserContext));
				if( !context )
					return BrFALSE;
			
				memset(context, 0, sizeof(BoraXmlParserContext));

				if( bNeedSuspend )
					((BrCallbackBase*)pCallbackParam->pCurrentInstance)->SetXmlParserContext(context);

				Initialize_XmlParser(context);

				context->pCurPackagePartName = ze->name;

	#ifdef T_DEBUG
				BrTrace("Read Part : %s", ze.name);
	#endif
				BMVMemStream*  pStream = BrNEW BMVMemStream((char*)pMem, ze->unc_size);
				nRet = ParseXMLInfo(pStream, pCallbackParam, context);

				if( !bNeedSuspend )
				{
					BrFree(pMem);
					BrDELETE pStream;
					Finalize_XmlParser(context);
					BrFree(context);
				}
			}
			else
				BrFree(pMem);
		}
		else
		{
			g_BoraThreadAtom.m_nRetOpen = kPoErrMemory;
			SET_ERROR((PoError)kPoErrMemory, "");
		}
	}
	return nRet;
}


//embeding �� part�� �޸� ������ �д´�.
BrLPBYTE ReadEmbedingPackage_XmlParser(HZIP hZip, ZIPENTRY* ze, BrINT32 nZipItemIndex, BrINT32 &nMemSize)
{
	nMemSize = BrZipGetItemSize(hZip, nZipItemIndex);
	BrLPBYTE pMem = (BrLPBYTE)BrMalloc(nMemSize+1);
	if(pMem)
	{
		*(pMem + nMemSize ) = 0;
		if( BrZipExtractMemory(g_szSrcZipPassword, hZip, nZipItemIndex, pMem) )
			return pMem;
		else
			BrFree(pMem);
	}

	return BrNULL;
}

//�̹��� �����͸� �����Ѵ�.
BrLPBYTE ReadImage_XmlParser(HZIP hZip, ZIPENTRY* ze, BrINT32 nZipItemIndex, IMG_INFO* pImgInfo, BrBOOL bExport, HZIP hBlockZip, BrBOOL a_bEffect)
{
	if( bExport ) {//2007���� ����� �޸𸮷� load���� �ʰ� �ٷ� ��������!!
		BrBOOL bRet = BrFALSE;
		TCHAR* pFileName = (TCHAR*)BrMalloc(512);
		memset(pFileName, 0, 512);
		BrCHAR *pTmpPath = (BrCHAR*)BrGetTempPath();
		BrINT32 nLen = BrStrLen(pTmpPath);
		
		if(nLen > 0)
		{
			if(a_bEffect)
				sprintf_s(pFileName, 512, "%sImageTmp/", pTmpPath); //"~tmp/ImageTmp/abc.jpg"
			else
				sprintf_s(pFileName, 512, "%s", pTmpPath);
		}

#if defined(SUPPORT_MULTICORE) && defined(USE_MCORE_XSAVE)
		BrBYTE nError = eMCORE_NOTSUPPORT_ETYPE;
		if(hBlockZip && *(DWORD*)hBlockZip)
		{
			int nLen = BrStrLen(pFileName);
			char *pName = strrchr(ze->name, '/');
			if( pFileName[nLen-1] != '/')
				sprintf_s(pFileName+nLen, 512-nLen, "%s", pName);
			else
				sprintf_s(pFileName+nLen, 512-nLen, "%s", pName+1);

			nError = BrSetXSaveFileExtZipMCoreEvent(ze->name, pFileName, "", hBlockZip, nZipItemIndex);

			if(nError == eMCORE_NO_ETYPE)
				bRet = BrTRUE;		
			else if(nError == eMCORE_NOTSUPPORT_ETYPE)
				bRet = BrZipExtractUserFile("", hZip, nZipItemIndex, pFileName, 512);
			else
				bRet = BrFALSE;
		}
		else
			bRet = BrZipExtractUserFile("", hZip, nZipItemIndex, pFileName, 512, BrTRUE);	
#else //SUPPORT_MULTICORE
		bRet = BrZipExtractUserFile("", hZip, nZipItemIndex, pFileName, 512, BrTRUE);	
#endif //SUPPORT_MULTICORE
		if(!bRet) {
			BrCHAR strMemMsg[2070] = {0,};
			sprintf_s(strMemMsg, sizeof(strMemMsg), "BrZipExtractUserFileFail. pFileName:%s", pFileName);
			SET_INFO_LOG(strMemMsg);

			BrFree(pFileName);
			return BrNULL;
		}

		// �ֿ� ���� �̽� ���� http://confluence.infraware.net:8090/pages/viewpage.action?pageId=18842137

		return (BrLPBYTE)pFileName;
	}

	BrUINT32 nSize = BrZipGetItemSize(hZip, nZipItemIndex);

	if(nSize == 0)
	{
		SET_EDIT_WARNING_LOG(kPoWarnReadZeroSizeImage,"Read ZeroSize Image");
		return BrNULL;
	}

	BrLPBYTE pMem = (BrLPBYTE)BrMalloc(nSize);
	
	if(pMem)
	{
		if( BrZipExtractMemory(g_szSrcZipPassword, hZip, nZipItemIndex, pMem) )
		{
			IMG_INFO ImgInfo = {eImage_NONE, };

			if( !PrBitmap::getImageInfoPtr((void*)pMem, nSize, &ImgInfo) )
			{
				BrFree(pMem);
				pMem = BrNULL;
				pImgInfo->type = eImage_NONE;
			} else {
				pImgInfo->type = ImgInfo.type;
				pImgInfo->width = ImgInfo.width;
				pImgInfo->height = ImgInfo.height;
				pImgInfo->bBit = ImgInfo.bBit;
				pImgInfo->nTotalPage = ImgInfo.nTotalPage;
				pImgInfo->nRawSize = nSize;
				pImgInfo->nResX = ImgInfo.nResX;
				pImgInfo->nResY = ImgInfo.nResY;
			}
		}
		else
		{
			BrFree(pMem);
			pMem = BrNULL;
		}

	}
	else
	{
		SET_ERROR((PoError)kPoErrMemory, "");
	}

	return pMem;
}

//�̹��� ������ �����Ѵ�.
BrBOOL ReadImageInfo_XmlParser(HZIP hZip, ZIPENTRY* ze, BrINT32 nZipItemIndex, IMG_INFO* pImgInfo)
{
	BrUINT32 nOrgSize = BrZipGetItemSize(hZip, nZipItemIndex);
	// TODO : nSize �� ũ�� �Ǹ� zoom, panning ���۽� ���� ���� �Ҽ� ����
	BrUINT32 nSize = BrMIN(8192, nOrgSize);

	// Split IDAT chunk,  For efficiency reasons, some applications, do not write IDAT chunks larger than some fixed size (say, 8192 bytes).
	BrLPBYTE pMem = (BrLPBYTE)BrMalloc(nSize);
	BrBOOL bInfo = BrFALSE, bExtract = BrFALSE;
	BrImageType nType = eImage_NONE;

	if(pMem)
	{
		if( BrZipExtractMemory(g_szSrcZipPassword, hZip, nZipItemIndex, pMem, nSize) )
		{
			IMG_INFO ImgInfo = {eImage_NONE, };
			bExtract = BrTRUE;

			if( PrBitmap::getImageInfoPtr((void*)pMem, nSize, &ImgInfo) ) 
			{
				pImgInfo->type = ImgInfo.type;
				pImgInfo->width = ImgInfo.width;
				pImgInfo->height = ImgInfo.height;
				pImgInfo->bBit = ImgInfo.bBit;
				pImgInfo->nTotalPage = ImgInfo.nTotalPage;
				pImgInfo->nRawSize = nOrgSize;
				pImgInfo->nResX = ImgInfo.nResX;
				pImgInfo->nResY = ImgInfo.nResY;
				bInfo = BrTRUE;
			}
			else
				nType = GetImageHeaderType2(pMem, nSize, ze->unc_size);
		}
		BR_SAFE_FREE(pMem);
	}

	if( BrFALSE == bInfo && nType != eImage_UNSUPPORT && BrTRUE == bExtract) 	// if success extract, 
	{
		// [2012.05.07][donny][BBTS:0011230] tiff �� ��ü ũ�Ⱑ ���� �־�� header ������ ������ ����
		BrINT32 nHeaderSize = 8192;

		switch (nType) {
		case eImage_TIFF:
		case eImage_JPEG:
		case eImage_JPG:
		case eImage_PNG:
			nHeaderSize = ze->unc_size;
			break;
		default:
			nHeaderSize = 8192;
			break;
		}

		if (nHeaderSize <= ze->unc_size) {
			bInfo = ReadImageInfo_XmlParser_Extend(hZip, ze, nZipItemIndex, pImgInfo, nHeaderSize);
		}
	}

	return bInfo;
}

BrBOOL ReadImageInfo_XmlParser_Extend(HZIP hZip, ZIPENTRY* ze, BrINT32 nZipItemIndex, IMG_INFO* pImgInfo, BrINT32 &nHeaderSize)
{
	BrUINT32 nOrgSize = (BrINT32)BrZipGetItemSize(hZip, nZipItemIndex);
	BrUINT32 nSize = BrMIN(nHeaderSize, nOrgSize);
	BrLPBYTE pMem = (BrLPBYTE)BrMalloc(nSize);
	BrBOOL bInfo = BrFALSE, bExtract = BrFALSE;

	if(pMem)
	{
		if( BrZipExtractMemory(g_szSrcZipPassword, hZip, nZipItemIndex, pMem, nSize) )
		{
			bExtract = BrTRUE;
			IMG_INFO ImgInfo = {eImage_NONE, };

			if( PrBitmap::getImageInfoPtr((void*)pMem, nSize, &ImgInfo) ) 
			{
				pImgInfo->type = ImgInfo.type;
				pImgInfo->width = ImgInfo.width;
				pImgInfo->height = ImgInfo.height;
				pImgInfo->bBit = ImgInfo.bBit;
				pImgInfo->nTotalPage = ImgInfo.nTotalPage;
				pImgInfo->nRawSize = nSize;
				pImgInfo->nResX = ImgInfo.nResX;
				pImgInfo->nResY = ImgInfo.nResY;
				bInfo = BrTRUE;
			}
		}
		BR_SAFE_FREE(pMem);
	}

	if( BrFALSE == bInfo && nHeaderSize < ze->unc_size && BrTRUE == bExtract)	// if success extract, 
	{
		nHeaderSize = (nHeaderSize*2) < ze->unc_size ? nHeaderSize*2 : ze->unc_size;
		bInfo = ReadImageInfo_XmlParser_Extend(hZip, ze, nZipItemIndex, pImgInfo, nHeaderSize );
	}

	return bInfo;
}


BrBOOL ReadAndParseMem_XmlParser(void* data, int data_size, const BrCHAR* part,
                                 LPCallbackParam param, BrBOOL is_need_suspend)
{
	if (BrNULL == data || 0 == data_size)
		return SET_ERROR(kPoErrXmlSizeZeroParsingFail, BrNULL);

	if (is_need_suspend) {
		char* buf = (char*)BrMalloc(data_size);
		if (BrNULL == buf)
			return SET_ERROR(kPoErrMemory, BrNULL);
		memcpy(buf, data, data_size);

		BoraXmlParserContext* context = (BoraXmlParserContext*)BrCalloc(1, sizeof(BoraXmlParserContext));
		if (BrNULL == context) {
			BrFree(buf);  // coverity 101119 Resource leak
			return SET_ERROR(kPoErrMemory, BrNULL);
		}
		((BrCallbackBase*)param->pCurrentInstance)->SetXmlParserContext(context);

		Initialize_XmlParser(context);
		context->pCurPackagePartName = part;

		BMVMemStream* stream = BrNEW BMVMemStream(buf, data_size);
		return ParseXMLInfo(stream, param, context);
	}

	BoraXmlParserContext context = {};
	Initialize_XmlParser(&context);
	context.pCurPackagePartName = part;

	CXmlMemLoader loader(data, data_size, XML_BUFFER_SIZE);
	BrBOOL result = ParseXMLInfo(&loader, param, &context);
	Finalize_XmlParser(&context);
	return result;
}


#endif //SUPPORT_XML_PARSER
