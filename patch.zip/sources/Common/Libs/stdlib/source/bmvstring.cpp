#include <OfficePreComp.hpp>
#include "bmvstring.h"
#include "binterfacehandle.h"
#include "BaseDefines_i.h"
#include "brmcoreimp.h"
#include "ThreadDefines_i.h"
#include "BrLocaleLanguageDef.h"

static const unsigned char ui_00[] = {
    0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa,
    0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa,
    0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa,
    0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa,
    7, 0x1a, 0x1a, 0x1a, 28, 0x1a, 0x1a, 0x1a,
    22, 23, 0x1a, 27, 0x1a, 21, 0x1a, 0x1a,
    4, 4, 4, 4, 4, 4, 4, 4,
    4, 4, 0x1a, 0x1a, 27, 27, 27, 0x1a,
    0x1a, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf,
    0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf,
    0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf,
    0xf, 0xf, 0xf, 22, 0x1a, 23, 29, 20,
    29, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10,
    0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10,
    0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10,
    0x10, 0x10, 0x10, 22, 27, 23, 27, 0xa,
    0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa,
    0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa,
    0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa,
    0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa, 0xa,
    7, 0x1a, 28, 28, 28, 28, 30, 30,
    29, 30, 0x10, 24, 27, 21, 30, 29,
    30, 27, 6, 6, 29, 0x10, 30, 0x1a,
    29, 6, 0x10, 25, 6, 6, 6, 0x1a,
    0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf,
    0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf,
    0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 27,
    0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0xf, 0x10,
    0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10,
    0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10,
    0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 27,
    0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10,
};
#ifndef NOT_USE_GLOBAL_VARIABLE
BStringData *BString::s_pBstringshared_null = 0;
#endif //! NOT_USE_GLOBAL_VARIABLE
#define AUTO_GROWSIZE 50
#define AUTO_GROWSIZE_LARGESCALE 1024*1024

BChar BChar::lower(BrBOOL a_bUseLocaleStr) const
{
	if(row())
	{
		if(a_bUseLocaleStr)
			return BChar(BrToLower(unicode(), a_bUseLocaleStr));
		else
			return *this;
	}
	else
		return BChar(BrToLower(latin1()));
}

BChar BChar::upper(BrBOOL a_bUseLocaleStr) const
{
	if(row())
	{
		if(a_bUseLocaleStr)
			return BChar(BrToUpper(unicode(), a_bUseLocaleStr));
		else
			return *this;
	}
	else
		return BChar(BrToUpper(latin1()));
}

bool BChar::isLower()
{
	return BrIsLower( latin1() ) ? true : false ;
}

bool BChar::isUpper()
{
	return BrIsUpper( latin1() ) ? true : false ;
}

bool BChar::isAlphabet()
{
	return isUpper() || isLower();
}

BChar::Category BChar::category() const
{
    if ( rw == 0 ) 
		return (Category)(ui_00[cell()]);
    
    return eLetter_Uppercase;
}

bool BChar::isSpace() const
{
    if( !row() )
	if( cell() >= 9 && cell() <=13 ) return true;
    Category c = category();
    return c >= eSeparator_Space && c <= eSeparator_Paragraph;
}

BChar* BString::asciiToUnicode( const char *str, unsigned int* len, unsigned int maxlen )
{
    BChar* result = 0;
    unsigned int l = 0;

    if ( str ) 
	{
		if ( maxlen != (unsigned int)-1 ) 
		{
			while ( l < maxlen && str[l] )
				l++;
		} 
		else 
		{
			l = BrStrLen(str);
		}

////Ư�� armcc �� �׾ �Ʒ��� ��ħ. 06.07.05 sunklee
		//BChar *uc = BrNEW BChar[ l ]; 
		BChar *uc = (BChar *) BrMalloc(BrSizeOf(BChar)*l); 
		result = uc;

		unsigned int i = l;
		while ( i-- )
			*uc++ = *str++;
    }

    if ( len )
		*len = l;

    return result;
}

static BChar* internalAsciiToUnicode( const char *str, unsigned int* len,
				      unsigned int maxlen = (unsigned int)-1 )
{
    BChar* result = 0;
    unsigned int l = 0;

    if ( str ) 
	{
		if ( maxlen != (unsigned int)-1 ) 
		{
			while ( l < maxlen && str[l] )
				l++;
		} 
		else 
		{
			l = BrStrLen(str);
		}

		BChar *uc = l ? B_ALLOC_QCHAR_VEC( l ) : 0;
		result = uc;

		unsigned int i = l;
		while ( i-- )
			*uc++ = *str++;
    }

    if ( len )
		*len = l;
    
	return result;
}

char* BString::unicodeToAscii(const BChar *uc, unsigned int l)
{
    if (!uc) 
		return 0;

    char *a = (char*)BrMalloc(BrSizeOf(char)*(l+1));
    char *result = a;

#ifdef __sparc__
	int k = 0;
	do
	{
		a[k] = uc[k].row();
	}while (k++ < l);
#else
    while (l--)
		*a++ = *uc++;
#endif

    *a = '\0';
    return result;
}

char* BString::unicodeToUtf8(const BChar *uc, unsigned int l)
{
    if (!uc) 
		return 0;

    char *a = (char*)BrMalloc(4*l+1);
	if (a) {
		memset(a, 0, 4*l+1);
		BrWideCharToMultiByte(CP_UTF8, (BrLPCWSTR)uc, l, (BrLPSTR)a, 4*l+1);
	}

	return a;
}

static int ucstrcmp( const BString &as, const BString &bs )
{
    const BChar *a = as.unicode();
    const BChar *b = bs.unicode();
    
	if ( a == b ) return 0;
    if ( a == 0 ) return 1;
    if ( b == 0 ) return -1;

    int l=BrMIN(as.length(),bs.length());
	int nMin = l;
    
	while ( l-- && *a == *b )
		a++,b++;
    
	if ( l==-1 )
	{
		if ( as.length() != bs.length() )
		{
			if ( nMin == as.length() )
				return 0 - b->unicode();
			else if (nMin == bs.length() )
				return a->unicode() - 0;
		}

		return ( as.length()-bs.length() );
	}

    return a->unicode() - b->unicode();
}

static int ucstrncmp( const BChar *a, const BChar *b, int l )
{
    while ( l-- && *a == *b )
		a++,b++;
    
	if ( l==-1 ) return 0;

    return a->unicode() - b->unicode();
}

static int ucstrncmp(const NRChar* a, const NRChar* b, int l)
{
	while (l-- && *a == *b)
		a++, b++;

	if (l == -1) return 0;

	return a->unicode() - b->unicode();
}

static int ucstrnicmp( const BChar *a, const BChar *b, int l )
{
    while ( l-- && a->lower() == b->lower() )
		a++,b++;

    if ( l==-1 ) return 0;

    BChar al = a->lower();
    BChar bl = b->lower();
    
	return al.unicode() - bl.unicode();
}

static int ucstrnicmp(const NRChar* a, const NRChar* b, int l)
{
	while (l-- && a->lower() == b->lower())
		a++, b++;

	if (l == -1) return 0;

	NRChar al = a->lower();
	NRChar bl = b->lower();

	return al.unicode() - bl.unicode();
}

// for Find
// "[\t\n\r ~\\`!@#$%^&*()-_+=|\\{}[];:\'\"<>?,./]"
const unsigned short BString::BSEPARATOR[] = {0x005B, 0x0009, 0x0D0A, 0x000D, 0x0020,
							0x007E, 0x005C, 0x0060, 0x0021, 0x0040,
							0x0023, 0x0024, 0x0025, 0x005E, 0x0026,
							0x002A, 0x0028, 0x0029, 0x002D, 0x005F,
							0x002B, 0x003D, 0x007C, 0x005C, 0x007B,
							0x007D, 0x005B, 0x005D, 0x003B, 0x003A,
							0x0027, 0x0022, 0x003C, 0x003E, 0x003F,
							0x002C, 0x002E, 0x002F, 0x005D,	0x00A0, 0x000A};
#define SEPARATOR_NUM 41

BString::BString() :
   d(s_pBstringshared_null ? s_pBstringshared_null : makeSharedNull())
{
    d->ref();
}

BString::BString( const BChar& ch )
{
    d = BrNEW BStringData( B_ALLOC_QCHAR_VEC( 1 ), 1, 1 );
    d->unicode[0] = ch;
}

BString::BString( const BString &s ) :
    d(s.d)
{
     d->ref();
}

BString::BString( int size, bool /*dummy*/ )
{
    if ( size ) 
	{
		int l = size;	
		BChar* uc = B_ALLOC_QCHAR_VEC( l );
		d = BrNEW BStringData( uc, 0, l );
    } 
	else 
	{	
		d = s_pBstringshared_null ? s_pBstringshared_null : (s_pBstringshared_null=BrNEW BStringData);
		d->ref();
    }
}

BString::BString( const BChar* unicode, unsigned int length )
{
    if ( !unicode && !length ) 
	{
		d = s_pBstringshared_null ? s_pBstringshared_null : makeSharedNull();
		d->ref();
    } 
	else 
	{
		BChar* uc = B_ALLOC_QCHAR_VEC( length );
	
		if (!uc)
			BRTERMINATE(kPoErrMemory, "", PO_PUBLIC_CLASS);

		if ( unicode && uc )
			memcpy(uc, unicode, length*BrSizeOf(BChar));

		d = BrNEW BStringData(uc,unicode ? length : 0,length);
    }
}

// ASCCII CODE�� str �� ���� ��������. ��Ƽ ����Ʈ�� �������ϴ�. 
BString::BString( const char *str )
{
    unsigned int l;
    BChar *uc = internalAsciiToUnicode(str,&l);
    d = BrNEW BStringData(uc,l,l);
#ifdef __sparc__
	UINT8* srcData = (UINT8*)d->unicode;
	for (int n = 0; n < length() * 2; n += 2)
	{
		UINT8 tmp = srcData[n + 1];

		srcData[n + 1] = srcData[n];
		srcData[n] = tmp;
	}
#endif
}

BString::BString(const value_type *src, size_type count)
	: d(s_pBstringshared_null ? s_pBstringshared_null : makeSharedNull())
{
	d->ref();
	setLatin1(src, count);
}

BString::~BString()
{
    if (d->deref() ) 
	{
		if ( d == s_pBstringshared_null )
			s_pBstringshared_null = 0;
		d->deleteSelf();
    }
}

void BString::staticDeleteEx(BStringData** lpData)
{
	if( *lpData )
	{
		BrDELETE *lpData;
		*lpData = 0;
	}
}

void BString::staticDelete()
{
	BString::staticDeleteEx(&s_pBstringshared_null);	
}

void BString::real_detach()
{
    setLength( length() );
}

void BString::deref()
{
    if ( d && d->deref() ) 
	{
		if ( d == s_pBstringshared_null )
			s_pBstringshared_null = 0;
		BrDELETE d;
		d = 0; 
    }
}

void BStringData::deleteSelf()
{
    BrDELETE this;
}

BString &BString::operator=( const BChar& c )
{ 
	return *this = BString(c); 
}

BString &BString::operator=( char c )
{ 
	return *this = BString(BChar(c)); 
}

BString &BString::operator=( const BString &s )
{
    s.d->ref();
    deref();
    d = s.d;

    return *this;
}

BString &BString::operator=( const char *str )
{
    return setLatin1(str);
}

BString &BString::operator=( BrWCHAR wc )
{
    *this = "";
	*this += wc;
	return *this;
}

BString &BString::operator=( BrLPCWSTR wsz )
{
	BrLPWSTR p = (BrLPWSTR) wsz;

	while( *p++ );


	this->setUnicodeCodes( wsz ,  p-wsz-1 );


	return *this;
}


bool BString::isNull() const
{ 
	return unicode() == 0; 
}

unsigned int BString::length() const
{ 
	return d->len; 
}

bool BString::isEmpty() const
{ 
	return length() == 0; 
}

bool BString::isNumber() const
{
    char lowest=0;
    
	unsigned int i;
	for (i=0; i<length(); i++) 
	{
		char dig = at(i);
		if ( dig < '0' || dig > '9' )
			return false;
	}

	return true;
}

bool BString::isHexNumber() const
{
	unsigned int i;
	for(i = 0; i < length(); i++) 
	{
		char dig = at(i);

		if('0' <= dig && dig <= '9')
			continue;
		if('A' <= dig && dig <= 'F')
			continue;
		if('a' <= dig && dig <= 'f')
			continue;

		return false;
	}

	return true;
}

bool BString::isFloatNumber() const
{
	char lowest=0;

	unsigned int i;
	for (i=0; i<length(); i++) 
	{
		char dig = at(i);
		if ( (dig < '0' || dig > '9') && dig != '.')
			return false;
	}

	return true;
}

bool BString::isNumberConsiderWithNegative() const
{
	char lowest=0;

	unsigned int i;
	for (i=0; i<length(); i++) 
	{
		char dig = at(i);
		if ( dig == '-' && i == 0)	// check negative
			continue;

		if ( dig < '0' || dig > '9' )
			return false;
	}

	return true;
}

bool BString::isNumberConsiderWithPositive() const
{
	char lowest=0;

	unsigned int i;
	for (i=0; i<length(); i++) 
	{
		char dig = at(i);
		if ( dig == '+' && i == 0)	// check positive
			continue;

		if ( dig < '0' || dig > '9' )
			return false;
	}

	return true;
}

bool BString::isFloatNumberConsiderWithNegative() const
{
	char lowest=0;

	int nCommaCnt = 0;
	unsigned int i;
	for (i=0; i<length(); i++) 
	{
		char dig = at(i);
		
		if ( dig == '-' && i == 0)	// check negative
			continue;

		if ( dig == '.') // if count of comma is over one, it is not float number.
		{
			 if( nCommaCnt == 0 )
				 nCommaCnt++;
			 else
				 return false;
		}

		if ( (dig < '0' || dig > '9') && dig != '.')
			return false;
	}

	return true;
}

bool BString::isFloatNumberConsiderWithPositive() const
{
	char lowest=0;

	int nCommaCnt = 0;
	unsigned int i;
	for (i=0; i<length(); i++) 
	{
		char dig = at(i);

		if ( dig == '+' && i == 0)	// check positive
			continue;

		if ( dig == '.') // if count of comma is over one, it is not float number.
		{
			if( nCommaCnt == 0 )
				nCommaCnt++;
			else
				return false;
		}

		if ( (dig < '0' || dig > '9') && dig != '.')
			return false;
	}

	return true;
}

bool BString::isFormulaWithBlank() const
{
	bool bIsFirstChar = true;
	bool bIsFirstBlank = false;
	bool bNeedDivOp = false;

	unsigned int i = 0;
	unsigned int nBlankIdx = -1;
	
	do {
		char dig = at(i);
		if (i == 0 && dig == ' ') { i++; bIsFirstBlank = true; continue; }

		if (bIsFirstChar) {
			if (dig != '+' && dig != '-') { return false; }
			bIsFirstChar = false;
		}
		else {
			if (dig != '+' && dig != '-' && dig != '*' && dig != '/') 
			{ 
				if (nBlankIdx + 1 == i && dig >= '0' && dig <= '9')
					bNeedDivOp = true;
				else
					return false; 
			}
			else if (bIsFirstBlank) { return false; }
		}
		i++;

		for (; i < length(); i++) {
			char tmp_dig = at(i);
			if (tmp_dig >= '0' && tmp_dig <= '9') { continue; }
			else if (tmp_dig == ' ') {
				nBlankIdx = i;
				i++;
				break;
			}
			else if (bNeedDivOp && tmp_dig == '/')
			{
				bNeedDivOp = false;
			}
			else { return false; }
		}
	} while (i < length());

	if (bNeedDivOp)
		return false;

	return true;
}


#define MAX_SIGNIFICANT_DIGIT 15
#define MAX_STRING_NUMBER_LENGTH 265 // EXCEL 2013 ����

enum{
	number_state_start,					// ���� ����
	number_state_sign_part_mantissa,	// ��ȣ(����)
	number_state_sign_part_exponent,	// ��ȣ(����)
	number_state_integer_part,			// ������
	number_state_thousand_char,			// õ�ڸ� ��ȣ
	number_state_decimal_char,			// �Ҽ� ��ȣ
	number_state_fraction_part,			// �Ҽ���
	number_state_exponent_char,			// ���� ��ȣ
	number_state_exponent_part,			// ������
	number_state_space_first,			// ����(����)
	number_state_space_sign,			// ����(��ȣ����)
	number_state_space_last,			// ����(������)
};

bool BString::isNumberString() const
{
	// [whitespace] [sign] [whitespace] [digits] {thousand_char} [digits] [.digits] [{e | E }[sign]digits] [whitespace]

	BrINT nLength = length();
	if( nLength <= 0 || nLength > MAX_STRING_NUMBER_LENGTH )
		return false;

	BrINT nIntNumCnt = 0; // ������(����)
	BrINT nFrcNumCnt = 0; // �Ҽ���(����)
	BrINT nExpNumCnt = 0; // ����

	BrINT nState = number_state_start; // ���� ����(���ۻ��·� ����)

	for( int i = 0; i < nLength ; i++)
	{
		char curCh = at(i);	

		switch (nState)
		{
		case number_state_start: // ����
			{
				if( curCh == '+' || curCh == '-' )
					nState = number_state_sign_part_mantissa;	
				else if( curCh == ' ' || curCh == '\t' )
					nState = number_state_space_first;
				else if( curCh == '.'  )
					nState = number_state_decimal_char;
				else if( IsDigit(curCh) )
					nState = number_state_integer_part;
				else
					return false;
			}
			break;
		case number_state_sign_part_mantissa: // ��ȣ(������)
			{
				if( curCh == ' ')
					nState = number_state_space_sign;
				else if( IsDigit(curCh) )
					nState = number_state_integer_part;
				else
					return false;
			}
			break;
		case number_state_sign_part_exponent: // ��ȣ(������)
			{
				 if( IsDigit(curCh) )
					 nState = number_state_exponent_part;
				 else
					 return false;
			}
			break;
		case number_state_integer_part: // ������
			{
				nIntNumCnt++;

				if( IsDigit(curCh) )
					;//nState = number_state_integer;
				else if( curCh == ',' )
					nState = number_state_thousand_char;
				else if( curCh == '.' )
					nState = number_state_decimal_char;
				else if( curCh == 'e' ||  curCh == 'E' )
					nState = number_state_exponent_char;
				else if( curCh == ' ')
					nState = number_state_space_last;
				else
					return false;
			}
			break;
		case number_state_thousand_char: // õ�ڸ� ����
			{
				BrINT nNumCnt = 0;
				while( IsDigit(curCh) && nNumCnt < 3 )
				{
					nIntNumCnt++;
					nNumCnt++;
					curCh = at(++i);
				}

				if( nNumCnt == 3)
				{
					if( IsDigit(curCh) )
						nState = number_state_integer_part; // ������
					else if( curCh == '.')
						nState = number_state_decimal_char; // �Ҽ��� ��ȣ
					else if( curCh == ',')
						nState = number_state_thousand_char;// õ�ڸ� ��ȣ
				}
				else
					return false;
			}
			break;
		case number_state_decimal_char: // �Ҽ� ��ȣ
			{
				if( IsDigit(curCh) )
					nState = number_state_fraction_part;
				else if( curCh == 'e' ||  curCh == 'E' )
					nState = number_state_exponent_char;
				else
					return false;
			}
			break;
		case number_state_fraction_part: // �Ҽ���
			{
				nFrcNumCnt++;

				if( IsDigit(curCh) )
					;//nState = number_state_fraction;
				else if( curCh == ' ')
					nState = number_state_space_last;
				else if( curCh == 'e' ||  curCh == 'E' )
					nState = number_state_exponent_char;
				else
					return false;
			}
			break;
		case number_state_exponent_char: // ���� ��ȣ
			{
				if( IsDigit(curCh) )
					nState = number_state_exponent_part;	
				else if( curCh == '+' || curCh == '-' )
					nState = number_state_sign_part_exponent;	
				else
					return false;
			}
			break;
		case number_state_exponent_part: // ������
			{
				nExpNumCnt++;

				if( nExpNumCnt > 3 )
					return false;

				if( IsDigit(curCh) )
					;//nState = number_state_exponent_part;
				else if( curCh == ' ')
					nState = number_state_space_last;
				else
					return false;
			}
			break;
		
		case number_state_space_first: //  ����(�������� ����or��ȣ��)
			{
				while( curCh == ' ' || curCh == '\t' )
					curCh = at(++i);

				if( i == nLength )
					return false;
				
				if( curCh == '+' || curCh == '-'  )
					nState = number_state_sign_part_mantissa;
				else if( IsDigit(curCh) )
					nState = number_state_integer_part;
				else
					return false;
			}
			break;
		case number_state_space_sign: //  ����(�������� ���ڸ�)
			{
				while( curCh == ' ' || curCh == '\t' )
					curCh = at(++i);

				if( i == nLength )
					return false;

				if( IsDigit(curCh) )
					nState = number_state_integer_part;
				else
					return false;
			}
			break;
		case number_state_space_last: //  ����(������ ����)
			{
				while( curCh == ' ' || curCh == '\t' )
					curCh = at(++i);

				if( i != nLength )
					return false;
			}
			break;
		}
	}

 	if( nState == number_state_thousand_char  )
 		return false;

	if( nState == number_state_exponent_char )
		return false;

	if( nIntNumCnt == 0 && nFrcNumCnt == 0 )
		return false;

	return true;
}

bool BString::getDouble(BrDOUBLE &dValue) const
{
	if(isNull())
	{
		dValue  = 0.0;
		return true;
	}

	if(0 == length())
	{
		dValue  = 0.0;
		return true;	
	}

	BrINT nIndex = find('.');
	if (nIndex > 0)
	{
		BString strSub = left(nIndex);
		dValue = ((0 < strSub.length()) && (strSub.isNull() == false)) ? (BrDOUBLE) strtoll(left(nIndex), BrNULL, 10) : 0.0;

		strSub = right(length()-(nIndex+1));
		BrDOUBLE dSub = ((0 < strSub.length()) && (strSub.isNull() == false)) ? (BrDOUBLE) strtoll(strSub, BrNULL, 10) : 0.0;

		BrINT nSubSize = strSub.length();
		for (BrINT ii=0 ; ii<nSubSize ; ii++)
			dSub = dSub / 10;
		dValue = dValue + dSub;
	}
	else
		dValue = (BrDOUBLE) strtol(data(), BrNULL, 10);

	return true;
}

bool BString::getDoubleEx(BrDOUBLE &dValue) const
{
	if(isNull())
	{
		dValue  = 0.0;
		return true;
	}

	if(0 == length())
	{
		dValue  = 0.0;
		return true;	
	}

	BrINT nIndex = find('.');
	if (nIndex > 0)
	{
		dValue = (BrDOUBLE) strtod(left(nIndex), BrNULL);
		BString strSub = right(length()-(nIndex+1));
		BrDOUBLE dSub = (BrDOUBLE) strtod(strSub, BrNULL);
		BrINT nSubSize = strSub.length();
		for (BrINT ii=0 ; ii<nSubSize ; ii++)
			dSub = dSub / 10;
		dValue = dValue + dSub;
	}
	else
		dValue = (BrDOUBLE) strtol(data(), BrNULL, 10);

	return true;
}

bool BString::getDoubleConsiderWithExponent(BrDOUBLE* a_pValue) const
{
	BrINT nLength = length();

	if(isNull() || ( nLength == 0 || nLength > MAX_STRING_NUMBER_LENGTH ) )
		return false;

	BrINT nIntDigits = 0; // ����(������)
	BrINT nFrcDigits = 0; // �Ҽ�(������)
	BrINT nExpDigits = 0; // ����

	// true = +, false = -
	BrBOOL bMantissaSign = true;	// ������ ��ȣ
	BrBOOL bExpSign = true;			// ������ ��ȣ

	BrDOUBLE dIntValue = 0;	// ������(������)
	BrDOUBLE dFrcValue = 0;	// �Ҽ���(������)
	BrINT nExpValue = 0;		// ������

	BrBOOL bCountingDigit = false;  // ��ȿ �ڸ��� ī���� ����
	BrINT nSignificantDigits = 0;				// ���� ��ȿ�ڸ���(�ִ밪 SIGNIFICANT_DIGIT)

	BrINT nState = number_state_start;
	for( int i = 0 ; i < nLength ; i++ )
	{
		char curCh = at(i);	

		switch (nState)
		{
		case number_state_start:
			{
				if( curCh == '+' || curCh == '-' )
				{
					bMantissaSign = curCh == '+' ? true : false;
					nState = number_state_sign_part_mantissa;	
				}
				else if( curCh == ' ' || curCh == '\t' )
					nState = number_state_space_first;
				else if( curCh == '.'  )
					nState = number_state_decimal_char;
				else if( IsDigit(curCh) )
				{
					dIntValue = curCh - '0';

					bCountingDigit = curCh != '0' ? true : false;
					if( bCountingDigit )
						nSignificantDigits++;

					nIntDigits++;

					nState = number_state_integer_part;
				}
				else
					return false;
			}
			break;
		case number_state_sign_part_mantissa: // ��ȣ(������)
			{
				if( IsDigit(curCh) )
				{
					dIntValue = curCh - '0';

					bCountingDigit = curCh != '0' ? true : false;
					if( bCountingDigit )
						nSignificantDigits++;

					nIntDigits++;

					nState = number_state_integer_part;
				}
				else
					return false;
			}
			break;
		case number_state_sign_part_exponent: // ��ȣ(������)
			{
				if( IsDigit(curCh) )
				{
					nExpValue = curCh - '0';
					nState = number_state_exponent_part;
				}
				else
					return false;
			}
			break;
		case number_state_integer_part: // ������
			{
				if( IsDigit(curCh) )
				{
					nIntDigits++;

					if( !bCountingDigit )
						bCountingDigit = curCh != '0' ? true : false;

					if( bCountingDigit )
						nSignificantDigits++;

					if( nSignificantDigits > MAX_SIGNIFICANT_DIGIT )
						dIntValue = dIntValue*10;
					else
						dIntValue = dIntValue*10 + (curCh-'0');
				}
				else if( curCh == '.' )
					nState = number_state_decimal_char;
				else if( curCh == ',' )
					nState = number_state_thousand_char;
				else if( curCh == 'e' ||  curCh == 'E' )
					nState = number_state_exponent_char;
				else
					return false;
			}
			break;
		case number_state_thousand_char: // õ�ڸ� ����
			{
				BrINT nNumCnt = 0;
				while( IsDigit(curCh) && nNumCnt < 3 )
				{
					if( bCountingDigit )
						nSignificantDigits++;

					nIntDigits++;
					nNumCnt++;

					if( nSignificantDigits > MAX_SIGNIFICANT_DIGIT )
						dIntValue = dIntValue*10;
					else
						dIntValue = dIntValue*10 + (curCh-'0');

					curCh = at(++i);
				}

				if( nNumCnt == 3 )
				{
					if( IsDigit(curCh) )
					{
						if( bCountingDigit )
							nSignificantDigits++;

						nIntDigits++;

						if( nSignificantDigits > MAX_SIGNIFICANT_DIGIT )
							dIntValue = dIntValue*10;
						else
							dIntValue = dIntValue*10 + (curCh-'0');

						nState = number_state_integer_part; // ������
					}
					else if( curCh == '.')
						nState = number_state_decimal_char; // �Ҽ��� ��ȣ
					else if( curCh == ',')
						nState = number_state_thousand_char;// õ�ڸ� ��ȣ
					else if( i == nLength )
						nState = number_state_integer_part;
				}
				else
					return false;
			}
			break;
		case number_state_decimal_char: // �Ҽ� ��ȣ
			{
				if( IsDigit(curCh) )
				{
					if( !bCountingDigit )
						bCountingDigit = curCh != '0' ? true : false;

					if( bCountingDigit )
						nSignificantDigits++;

					nFrcDigits++;

					if( nSignificantDigits > MAX_SIGNIFICANT_DIGIT )
						dFrcValue = 0;
					else
						dFrcValue = curCh - '0';

					nState = number_state_fraction_part;
				}
				else if( curCh == 'e' ||  curCh == 'E' )
					nState = number_state_exponent_char;
				else
					return false;
			}
			break;
		case number_state_fraction_part: // �Ҽ���
			{
				if( IsDigit(curCh) )
				{
					if( !bCountingDigit )
						bCountingDigit = curCh != '0' ? true : false;

					if( bCountingDigit )
						nSignificantDigits++;

					nFrcDigits++;

					if( nSignificantDigits > MAX_SIGNIFICANT_DIGIT )
						dFrcValue = dFrcValue * 10;
					else
						dFrcValue = dFrcValue * 10 + ( curCh - '0' );
				}
				else if( curCh == 'e' ||  curCh == 'E' )
					nState = number_state_exponent_char;
				else
					return false;
			}
			break;
		case number_state_exponent_char: // ���� ��ȣ
			{
				if( IsDigit(curCh) )
				{
					nExpDigits++;
					nExpValue = curCh - '0';
					nState = number_state_exponent_part;	
				}
				else if( curCh == '+' || curCh == '-' )
				{
					bExpSign = curCh == '+' ? true : false;
					nState = number_state_sign_part_exponent;	
				}
				else
					return false;
			}
			break;
		case number_state_exponent_part: // ������
			{
				if( nExpValue > 308 )
					return false;

				if( IsDigit(curCh) )
				{
					nExpDigits++;
					nExpValue = nExpValue * 10 + ( curCh - '0' );
				}
				else
					return false;
			}
			break;
		case number_state_space_first: //  ����(�������� ����or��ȣ��)
			{
				while( curCh == ' ' || curCh == '\t' )
					curCh = at(++i);

				if( i == nLength )
					return false;

				if( curCh == '+' || curCh == '-'  )
					nState = number_state_sign_part_mantissa;
				else if( IsDigit(curCh) )
				{
					dIntValue = curCh - '0';

					bCountingDigit = curCh != '0' ? true : false;
					if( bCountingDigit )
						nSignificantDigits++;

					nIntDigits++;

					nState = number_state_integer_part;
				}
				else
					return false;
			}
			break;
		case number_state_space_sign: //  ����(�������� ���ڸ�)
			{
				while( curCh == ' ' || curCh == '\t' )
					curCh = at(++i);

				if( i == nLength )
					return false;

				if( IsDigit(curCh) )
				{
					dIntValue = curCh - '0';

					bCountingDigit = curCh != '0' ? true : false;
					if( bCountingDigit )
						nSignificantDigits++;

					nIntDigits++;

					nState = number_state_integer_part;
				}
				else
					return false;
			}
			break;
		case number_state_space_last: //  ����(������ ����)
			{
				while( curCh == ' ' || curCh == '\t' )
					curCh = at(++i);

				if( i != nLength )
					return false;
			}
			break;
		}
	}

	if( nState == number_state_thousand_char  )
		return false;

	if( nState == number_state_exponent_char )
		return false;

	if( nIntDigits == 0 && nFrcDigits == 0 )
		return false;

	BrDOUBLE dValue = 0;

	// ������
	if( dIntValue )
		dValue = dIntValue;	

	// �Ҽ���
	if( dFrcValue )
	{
		for( BrINT i = 0 ; i < nFrcDigits; i++ )
			dFrcValue = dFrcValue / 10;

		dValue = dValue + dFrcValue;
	}

	// ������
	if( nExpValue )
	{
		for( BrINT i = 0 ; i < nExpValue ; i++ )
		{
			if( bExpSign )	
				dValue = dValue * 10; // +
			else			
				dValue = dValue / 10; // -
		}
	}

	if( dValue != 0 )
	{
		if( dValue > 1.78e+308 || dValue < 1.78e-308 ) // ��ȿ ���� ���� Check
			return false;
	}
	
	// ���е� ���� �۾�
	BrDOUBLE dAdjstedValue = 0;
	BrINT nExp = BrLog10(dValue)-(MAX_SIGNIFICANT_DIGIT-1);
	dAdjstedValue = BrFloor( dValue * BrPow( 10, -nExp ) + 0.5 );
	dAdjstedValue = dAdjstedValue * BrPow( 10, nExp );

	// ��ȣ
	if( !bMantissaSign )
		dValue = -dValue;

	if( a_pValue )
		*a_pValue = dValue;

	return true;
}

bool BString::useHighByte() 
{
	int l=length();

	if ( l ) 
	{
		register BChar *p= d->unicode;
		if ( p ) 
		{
			while ( l-- ) 
			{
				if( (p->unicode() & 0xff00) != 0 )
					return true;
				p++;
			}
		}
	}

	return false;
}

void BString::truncate( unsigned int newLen )
{
    if ( newLen < d->len )
		setLength( newLen );
}

void BString::setLength( unsigned int newLen )
{
    if ( d->count != 1 || newLen > d->maxl/* || ( newLen*4 < d->maxl && d->maxl > 4 ) */) 
	{	
//		unsigned int newMax = 4;	
//		while ( newMax < newLen )
//			newMax *= 2;
		///////////////////////////////////
		// Performane Tunning
		unsigned int newMax = d->maxl;	
		do
		{
			newMax += AUTO_GROWSIZE;
		} while ( newMax < newLen );
		///////////////////////////////////

		BChar* nd = B_ALLOC_QCHAR_VEC( newMax );

		if( nd )
		{
			unsigned int len = BrMIN( d->len, newLen );
			
			if ( d->unicode )
				memcpy( nd, d->unicode, BrSizeOf(BChar)*len );

			deref();
			d = BrNEW BStringData( nd, newLen, newMax );
#ifdef __sparc__
			UINT8* srcData = (UINT8*)d->unicode;
			for (int n = 0; n < length() * 2; n += 2)
			{
				UINT8 tmp = srcData[n + 1];

				srcData[n + 1] = srcData[n];
				srcData[n] = tmp;
			}
#endif
		}
		else
		{
			char pMsg[80] = {0,};
			sprintf_s(pMsg, sizeof(pMsg), "newLen : %d, newMax : %d", newLen, newMax);
			SET_ERROR_LOG(kPoErrMaxHeapSizeOver, pMsg, __FUNCTION__);
		}
    } 
	else 
	{
		d->len = newLen;
		d->dirtyascii = 1;
    }
}

void BString::setExactLengthAndClear(unsigned int length)
{
	if (d->count != 1 || length > d->maxl/* || ( newLen*4 < d->maxl && d->maxl > 4 ) */)
	{
		BChar* nd = B_ALLOC_QCHAR_VEC(length);

		if (nd)
		{
			deref();
			d = BrNEW BStringData(nd, 0, length);
		}
		else
		{
			char pMsg[80] = { 0, };
			sprintf_s(pMsg, sizeof(pMsg), "newLen : %d, newMax : %d", length, length);
			SET_ERROR_LOG(kPoErrMaxHeapSizeOver, pMsg, __FUNCTION__);
		}
	}
	else
	{
		d->len = 0;
		memset(d->unicode, 0, BrSizeOf(BChar)*d->maxl);
		d->dirtyascii = 1;
	}
}

void BString::setLengthWithLargeGrowth( unsigned int newLen )
{
	if ( d->count != 1 || newLen > d->maxl/* || ( newLen*4 < d->maxl && d->maxl > 4 ) */) 
	{	
		//		unsigned int newMax = 4;	
		//		while ( newMax < newLen )
		//			newMax *= 2;
		///////////////////////////////////
		// Performane Tunning
		unsigned int newMax = d->maxl;	
		do
		{
			newMax += AUTO_GROWSIZE_LARGESCALE;
		} while ( newMax < newLen );
		///////////////////////////////////

		BChar* nd = B_ALLOC_QCHAR_VEC( newMax );

		if( nd )
		{
			unsigned int len = BrMIN( d->len, newLen );

			if ( d->unicode )
				memcpy( nd, d->unicode, BrSizeOf(BChar)*len );

			deref();
			d = BrNEW BStringData( nd, newLen, newMax );
		}
		else
		{
			char pMsg[80] = {0,};
			sprintf_s(pMsg, sizeof(pMsg), "newLen : %d, newMax : %d", newLen, newMax);
			SET_EDIT_WARNING_LOG(kPoErrMaxHeapSizeOver, pMsg);
		}
	} 
	else 
	{
		d->len = newLen;
		d->dirtyascii = 1;
	}
}


BString BString::arg(const BString& a, int fieldwidth) const
{
    int pos, len;
    BString r = *this;

    if ( !findArg( pos, len ) ) 
	{
		r += ' ';
		pos = r.length();
		len = 0;
    }

    r.replace( pos, len, a );
    if ( fieldwidth < 0 ) 
	{
		BString s;
		while ( (unsigned int)-fieldwidth > a.length() ) 
		{
			s += ' ';
			fieldwidth++;
		}
		r.insert( pos + a.length(), s );
	} 
	else if ( fieldwidth ) 
	{
		BString s;
		while ( (unsigned int)fieldwidth > a.length() ) 
		{
			s += ' ';
			fieldwidth--;
		}
		r.insert( pos, s );
    }

    return r;
}

BString BString::arg(BrLONG a, int fieldwidth, int base) const
{
    return arg( BString::number( a, base ), fieldwidth );
}

BString BString::arg(BrULONG a, int fieldwidth, int base) const
{
    return arg( BString::number( a, base ), fieldwidth );
}

BString BString::arg(char a, int fieldwidth) const
{
    BString c;
    c += a;

    return arg( c, fieldwidth );
}

BString BString::arg( const BChar& a, int fieldwidth) const
{
    BString c;
    c += a;

    return arg( c, fieldwidth );
}

BString BString::arg(double a, int fieldwidth, char fmt, int prec) const
{
    return arg( BString::number( a, fmt, prec ), fieldwidth );
}

bool BString::findArg(int& pos, int& len) const
{
    char lowest=0;
    
	unsigned int i;
	for (i=0; i<length(); i++) 
	{
		if ( at(i) == '%' && i+1<length() ) 
		{
			char dig = at(i+1);
			if ( dig >= '0' && dig <= '9' ) 
			{
				if ( !lowest || dig < lowest ) 
				{
					lowest = dig;
					pos = i;
					len = 2;
				}
			}
		}
    }

    return lowest != 0;
}

void BString::fill( const BChar& c, int len )
{
    if ( len < 0 )
		len = length();

    if ( len == 0 ) 
	{
		*this = "";
    } 
	else 
	{
		deref();
		BChar * nd = B_ALLOC_QCHAR_VEC( len );
		d = BrNEW BStringData(nd,len,len);
	
		while (len--) *nd++ = c;
    }
}

BString BString::BrCopy() const
{ 
	return BString( *this ); 
}

int BString::find( BChar c, int index, bool cs ) const
{
    if ( index < 0 )
		index += length();

    if ( (unsigned int)index >= length() )
		return -1;

    register const BChar *uc;
    uc = unicode()+index;
    int n = length()-index;

    if ( cs ) 
	{
		while ( n-- && *uc != c )
			uc++;
    } 
	else 
	{
		c = c.lower();
		while ( n-- && uc->lower() != c )
			uc++;
    }

    if ( (unsigned int)(uc - unicode()) >= length() )
		return -1;

    return (int)(uc - unicode());
}

int BString::find( const BString& string, int index, bool cs ) const
{
    if ( index < 0 )
		index += length();
    
	int lstr = string.length();
    int lthis = length() - index;

    if ( (unsigned int)lthis > length() )
		return -1;

    int delta = lthis - lstr;
    
	if ( delta < 0 )
		return -1;

    const BChar *uthis = unicode() + index;
    const BChar *ustring = string.unicode();
    unsigned int hthis = 0;
    unsigned int hstr = 0;
    int i;

    if ( cs ) 
	{
		for ( i = 0; i < lstr; i++ ) 
		{
			hthis += uthis[i].cell();
			hstr += ustring[i].cell();
		}

		i = 0;
		while ( true ) 
		{
			if ( hthis == hstr && ucstrncmp(uthis + i, ustring, lstr) == 0 )
				return index + i;

			if ( i == delta )
				return -1;

			hthis += uthis[i + lstr].cell();
			hthis -= uthis[i].cell();
			i++;
		}
	} 
	else 
	{
		for ( i = 0; i < lstr; i++ ) 
		{
			hthis += uthis[i].lower().cell();
			hstr += ustring[i].lower().cell();
		}

		i = 0;

		while ( true ) 
		{
			if ( hthis == hstr && ucstrnicmp(uthis + i, ustring, lstr) == 0 )
				return index + i;

			if ( i == delta )
				return -1;

			hthis += uthis[i + lstr].lower().cell();
			hthis -= uthis[i].lower().cell();
			i++;
		}
    }

    return -1;
}

int BString::find( char c, int index, bool cs ) const
{ 
	return find(BChar(c), index, cs); 
}

int BString::findWord(const BString& str, int index, bool cs) const
{
RE_FINDWORD:
	int idx = find( str, index, cs);
	
	unsigned int jj;
	if(idx >= 0)
	{
		bool bPreTok = false, bPostTok = false;

		if(idx <= 0) bPreTok = true;
		if(idx+str.length() >= length()) bPostTok = true;

		for(jj=0; jj < SEPARATOR_NUM; jj++)
		{
			if(!bPreTok)
			{
				if(at(idx-1) == BChar(BSEPARATOR[jj]))
					bPreTok = true;
			}

			if(!bPostTok)
			{
				if(at(idx+str.length()) == BChar(BSEPARATOR[jj]))
					bPostTok = true;
			}

			if(bPreTok && bPostTok)
				break;
		}
			
		if(!bPreTok || !bPostTok)
			if (idx+str.length() < length())
			{
				index = idx+1;
				goto RE_FINDWORD;
			}
			else
			idx = -1;
	}

	return idx;
}

int BString::findRev( char c, int index, bool cs) const
{ 
	return findRev( BChar(c), index, cs ); 
}

int BString::find( const char* str, int index ) const
{ 
	return find(BString::fromLatin1(str), index); 
}

int BString::findRev( const char* str, int index ) const
{ 
	return findRev(BString::fromLatin1(str), index); 
}

int BString::findRev( const BChar& c, int index, bool cs ) const
{
    BString t( c );

    return findRev( t, index, cs );
}

int BString::findRev( const BString& string, int idx, bool cs ) const
{
    int lthis = length();
    if ( idx < 0 )
		idx += lthis;

    int lstr = string.length();
    int delta = lthis - lstr;
    if ( idx < 0 || idx > lthis || delta < 0 )
		return -1;

    if ( idx > delta )
		idx = delta;

    const BChar *uthis = unicode();
    const BChar *ustring = string.unicode();
    unsigned int hthis = 0;
    unsigned int hstr = 0;
    int i;

    if ( cs ) 
	{
		for ( i = 0; i < lstr; i++ ) 
		{
			hthis += uthis[idx + i].cell();
			hstr += ustring[i].cell();
		}

		i = idx;
		while ( true ) 
		{
			if ( hthis == hstr && ucstrncmp(uthis + i, ustring, lstr) == 0 )
				return i;
			
			if ( i == 0 )
				return -1;

			i--;
			hthis -= uthis[i + lstr].cell();
			hthis += uthis[i].cell();
		}
    } 
	else 
	{
		for ( i = 0; i < lstr; i++ ) 
		{
			hthis += uthis[idx + i].lower().cell();
			hstr += ustring[i].lower().cell();
		}

		i = idx;
		while ( true ) 
		{
			if ( hthis == hstr && ucstrnicmp(uthis + i, ustring, lstr) == 0 )
				return i;
			
			if ( i == 0 )
				return -1;

			i--;
			hthis -= uthis[i + lstr].lower().cell();
			hthis += uthis[i].lower().cell();
		}
    }

    return -1;
}

int BString::findRevWord( const BString& str, int index, bool cs ) const
{
RE_FINDREVBrWORD:
	if (index == -1)
	{
		return index;
	}
	int idx = findRev( str, index, cs);
	unsigned int jj;
	if(idx >= 0)
	{
		bool bPreTok = false, bPostTok = false;

		if(idx-1 < 0) bPreTok = true;
		if(idx+str.length() >= length()) bPostTok = true;

		for(jj=0; jj < SEPARATOR_NUM; jj++)
		{
			if(!bPreTok)
			{
				if(at(idx-1) == BChar(BSEPARATOR[jj]))
					bPreTok = true;
			}

			if(!bPostTok)
			{
				if(at(idx+str.length()) == BChar(BSEPARATOR[jj]))
					bPostTok = true;
			}

			if(bPreTok && bPostTok)
				break;
		}
			
		if(!bPreTok || !bPostTok)
			if (idx+str.length() < length())
			{
				index = idx-1;
				goto RE_FINDREVBrWORD;
			}
			else
			idx = -1;
	}

	return idx;
}

int BString::contains( BChar c, bool cs ) const
{
    int count = 0;
    const BChar *uc = unicode();
    
	if ( !uc )
		return 0;

    int n = length();

    if ( cs ) 
	{
		while ( n-- )
			if ( *uc++ == c )
			count++;
    } 
	else 
	{
		c = c.lower();
		while ( n-- ) 
		{
			if ( uc->lower() == c )
			count++;
			uc++;
		}
    }
    
	return count;
}

int BString::contains( const char* str, bool cs ) const
{
    return contains(BString(str),cs);
}

int BString::contains( const BString &str, bool cs ) const
{
    int count = 0;
    const BChar *uc = unicode();
    
	if ( !uc )
		return 0;
    
	int len = str.length();
    int n = length();

    while ( n-- ) 
	{		
		if ( cs ) 
		{
			if ( ucstrncmp( uc, str.unicode(), len ) == 0 )
				count++;
		} 
		else 
		{
			if ( ucstrnicmp(uc, str.unicode(), len) == 0 )
				count++;
		}
		uc++;
    }
    return count;
}

BString BString::left( unsigned int len ) const
{
    if ( isEmpty() ) 
	{
		return BString();
    } 
	else if ( len == 0 ) 
	{
		return BString::fromLatin1("");
    } 
	else if ( len > length() ) 
	{
		return *this;
    } 
	else 
	{
		BString s( len, true );
		memcpy( s.d->unicode, d->unicode, len*BrSizeOf(BChar) );
		s.d->len = len;

		return s;
    }
}

BString BString::right( unsigned int len ) const
{
    if ( isEmpty() ) 
	{
		return BString();
    } 
	else if ( len == 0 ) 
	{
		return BString::fromLatin1("");
    } 
	else 
	{
		unsigned int l = length();
		if ( len > l )
			len = l;
		
		BString s( len, true );
		memcpy( s.d->unicode, d->unicode+(l-len), len*BrSizeOf(BChar) );
		s.d->len = len;
		
		return s;
    }
}

BString BString::mid( unsigned int index, unsigned int len ) const
{
    unsigned int slen = length();
    if ( isEmpty() || index >= slen ) 
	{
		return BString();
    } 
	else if ( len == 0 ) 
	{
		return BString::fromLatin1("");
    } 
	else 
	{
		if ( len > slen-index )
			len = slen - index;

		if ( index == 0 && len == length() )
			return *this;

		register const BChar *p = unicode()+index;
		
		BString s( len, true );
		memcpy( s.d->unicode, p, len*BrSizeOf(BChar) );
		s.d->len = len;

		return s;
    }
}

BString BString::leftJustify( unsigned int width, BChar fill, bool truncate ) const
{
    BString result;
    int len = length();
    int padlen = width - len;

    if ( padlen > 0 ) 
	{
		result.setLength(len+padlen);
		
		if ( len )
			memcpy( result.d->unicode, unicode(), BrSizeOf(BChar)*len );

		BChar* uc = result.d->unicode + len;
		while (padlen--)
			*uc++ = fill;
    } 
	else 
	{
		if ( truncate )
			result = left( width );
		else
			result = *this;
    }

    return result;
}

BString BString::rightJustify( unsigned int width, BChar fill, bool truncate ) const
{
    BString result;
    int len = length();
    int padlen = width - len;
    
	if ( padlen > 0 ) 
	{
		result.setLength( len+padlen );
		BChar* uc = result.d->unicode;
		
		while (padlen--)
			*uc++ = fill;
		if ( len )
			memcpy( uc, unicode(), BrSizeOf(BChar)*len );
	} 
	else 
	{
		if ( truncate )
			result = left( width );
		else
			result = *this;
    }

    return result;
}

BString BString::lower() const
{
    BString s(*this);
    int l=length();
    
	if ( l ) 
	{
		s.real_detach();
		register BChar *p=s.d->unicode;
		if ( p ) 
		{
			while ( l-- ) 
			{
				*p = p->lower();
				p++;
			}
		}
    }
    return s;
}

BString BString::upper() const
{
    BString s(*this);
    int l=length();
    
	if ( l ) 
	{
		s.real_detach();
		register BChar *p=s.d->unicode;
		if ( p ) 
		{
			while ( l-- ) 
			{
				*p = p->upper();
				p++;
			}
		}
    }
    return s;
}

BString &BString::insert( unsigned int index, const BString &s )
{
    return insert( index, s.unicode(), s.length() );
}

BString &BString::insert( unsigned int index, const BChar* s, unsigned int len )
{
    if ( len == 0 )
		return *this;

    unsigned int olen = length();
    int nlen = olen + len;

    int df = s - d->unicode;
    if ( df >= 0 && (unsigned int)df < d->maxl ) 
	{
		BChar *tmp = B_ALLOC_QCHAR_VEC( len );
		memcpy(tmp,s,len*BrSizeOf(BChar));
		insert(index,tmp,len);
		B_DELETE_QCHAR_VEC( tmp );

		return *this;
    }

    if ( index >= olen ) 
	{
		setLength( len+index );
		int n = index-olen;
		BChar* uc = d->unicode+olen;
		while (n--)
			*uc++ = ' ';
		memcpy( d->unicode+index, s, BrSizeOf(BChar)*len );
    } 
	else 
	{
		setLength( nlen );
		BrMemmove( d->unicode+index+len, (BrLPVOID)(unicode()+index),
			 BrSizeOf(BChar)*(olen-index) );
		BrMemmove( d->unicode+index, (BrLPVOID)s, BrSizeOf(BChar)*len );
    }

    return *this;
}

//[20140327][jdjang] BChar insert ����ȭ
BString &BString::insert( unsigned int index, const BChar& c )
{
    //BString s( c );
    //return insert( index, s );

	return insert( index, &c, 1 );
}

BString &BString::prepend( const BString & s )
{ 
	return insert(0,s); 
}

BString &BString::prepend(const BChar& c )
{ 
	return insert(0,c); 
}

BString &BString::prepend( char c )
{ 
	return insert(0,c); 
}

BString &BString::remove( unsigned int index, unsigned int len )
{
    unsigned int olen = length();

    if ( index >= olen  ) ;
	else if ( index + len >= olen ) 
	{
        setLength( index );
    } 
	else if ( len != 0 ) 
	{
		real_detach();
		BrMemmove( d->unicode+index, (BrLPVOID)(d->unicode+index+len),
			 BrSizeOf(BChar)*(olen-index-len) );
		setLength( olen-len );
    }

    return *this;
}

BString &BString::replace( unsigned int index, unsigned int len, const BString &s )
{
    return replace( index, len, s.unicode(), s.length() );
}

BString &BString::replace( unsigned int index, unsigned int len, const BChar* s, unsigned int slen )
{
    if ( len == slen && index + len <= length() ) 
	{
		real_detach();
		memcpy( d->unicode+index, s, len*BrSizeOf(BChar) );
    } 
	else 
	{
		int df = s - d->unicode;
		if ( df >= 0 && (unsigned int)df < d->maxl ) 
		{
			BChar *tmp = B_ALLOC_QCHAR_VEC( slen );
			memcpy(tmp,s,slen*BrSizeOf(BChar));
			replace(index,len,tmp,slen);
			B_DELETE_QCHAR_VEC( tmp );

			return *this;
		}

		remove( index, len );
		insert( index, s, slen );
    }

    return *this;
}

BString &BString::setNum( BrLONG n, int base )
{
    char   charbuf[65*BrSizeOf(BChar)];
    BChar *buf = (BChar*)charbuf;
    BChar *p = &buf[64];
    int  len = 0;
    bool neg;

    if ( n < 0 ) 
	{
		neg = true;
		if ( n == B_INT_MIN ) 
		{
			BString s1, s2;
			s1.setNum(n/base);
			s2.setNum((-(n+base))%base);
			*this = s1 + s2;

			return *this;
		}
		n = -n;
    } 
	else 
	{
		neg = false;
    }

    do {
		*--p = "0123456789abcdefghijklmnopqrstuvwxyz"[((int)(n%base))];
		n /= base;
		len++;
    } while ( n );

    if ( neg ) 
	{
		*--p = '-';
		len++;
    }

    return setUnicode( p, len );
}

BString &BString::setNum( BrULONG n, int base )
{
    char   charbuf[65*BrSizeOf(BChar)];
    BChar *buf = (BChar*)charbuf;
    BChar *p = &buf[64];
    int len = 0;

    do {
		*--p = "0123456789abcdefghijklmnopqrstuvwxyz"[((int)(n%base))];
		n /= base;
		len++;
    } while ( n );

    return setUnicode(p,len);
}

BString &BString::setNum( long long n, int base )
{
    char   charbuf[65*BrSizeOf(BChar)];
    BChar *buf = (BChar*)charbuf;
    BChar *p = &buf[64];
    int len = 0;

    do {
		*--p = "0123456789abcdefghijklmnopqrstuvwxyz"[((int)(n%base))];
		n /= base;
		len++;
    } while ( n );

    return setUnicode(p,len);
}

BString &BString::setNum( double n, char f, int prec )
{
    char format[20]={0,};
    char buf[120]={0,};
    char *fs = format;

    *fs++ = '%';

    if ( prec >= 0 ) 
	{
		if ( prec > 99 )
			prec = 99;
		*fs++ = '.';

		if ( prec >= 10 ) 
		{
			*fs++ = prec / 10 + '0';
			*fs++ = prec % 10 + '0';
		} 
		else 
		{
			*fs++ = prec + '0';
		}
    }

    *fs++ = 'l';
    *fs++ = f;
    *fs = '\0';
    ::sprintf_s( buf, sizeof(buf), format, n );

    return setLatin1(buf);
}

BString BString::number( long long n, int base )
{
    BString s;
    s.setNum( n, base );

    return s;
}


BString BString::number( int n, int base )
{
    BString s;
    s.setNum( n, base );

    return s;
}

BString BString::number( unsigned int n, int base )
{
    BString s;
    s.setNum( n, base );

    return s;
}

BString BString::number( double n, char f, int prec )
{
    BString s;
    s.setNum( n, f, prec );

    return s;
}

void BString::setExpand( unsigned int index, BChar c )
{
    int spaces = index - d->len;
    ref(index) = c;

    while (spaces-->0)
		d->unicode[--index]=' ';
}

BString& BString::operator+=( const BString &str )
{
    unsigned int len1 = length();
    unsigned int len2 = str.length();
    
	if ( len2 ) 
	{
		setLength(len1+len2);
		if( len1 < length() )
			memcpy( d->unicode+len1, str.unicode(), BrSizeOf(BChar)*len2 );
    } 
	else if ( isNull() && !str.isNull() ) 
	{
		*this = fromLatin1("");
    }

    return *this;
}

BString &BString::operator+=(const BChar& c )
{
    setLength(length()+1);
    d->unicode[length()-1] = c;

    return *this;
}

BString &BString::operator+=( char c )
{
    setLength(length()+1);
    d->unicode[length()-1] = c;

    return *this;
}

BString &BString::operator+=(BrLPCSTR sz)
{
	if (sz == BrNULL || *sz == 0)
		return *this;

	int old_len = length();
	int new_len = old_len + BrStrLen(sz);
	setLength(new_len);

	for (int i = old_len; i < new_len; ++i)
		d->unicode[i] = sz[i - old_len];

    return *this;
}

BString &BString::operator+=( BrWCHAR wc )
{
    setLength(length()+1);
    d->unicode[length()-1] = wc;

    return *this;
}

BString &BString::operator+=( BrLPCWSTR wsz )
{
	if( wsz ==BrNULL || *wsz == 0 )
		return *this;

	int add_len = BrWcsLen( wsz );
	int org_len = length();
    setLength( org_len + add_len );

	for( int i = org_len; i<org_len + add_len ;i++ )
		d->unicode[i] = *(wsz+i-org_len);

    return *this;
}

BString& BString::appendHtml(BrLPCWSTR wsz)
{
	if (wsz == BrNULL || *wsz == 0)
		return *this;

	int add_len = BrWcsLen(wsz);
	int org_len = length();
	setLength(org_len + add_len);

	// [AOM-51900][crash] setLength() �����ϴ� ���, unicode �߰� ���� �ʰ� �����ϵ��� ����ó��
	if (d->unicode != NULL)
	{
		for (int i = org_len; i < org_len + add_len; i++)
			d->unicode[i] = *(wsz + i - org_len);
	}

	return *this;
}

//  [4/29/2016 sylee0335] append ���� ���� 
BString &BString::appendWithLargeGrowth( char c )
{
	setLengthWithLargeGrowth(length()+1);
	d->unicode[length()-1] = c;

	return *this;
}


//  [4/29/2016 sylee0335] append ���� ���� 
BString &BString::appendWithLargeGrowth( BChar c )
{
	setLengthWithLargeGrowth(length()+1);
	d->unicode[length()-1] = c;

	return *this;
}




const char* BString::latin1() const
{
    if ( d->ascii ) 
	{
		if ( d->dirtyascii )
			BrFree(d->ascii);
		else
			return d->ascii;
    }

    d->ascii = unicodeToAscii( d->unicode, d->len );
    d->dirtyascii = 0;

    return d->ascii;
}

const char* BString::ascii() const
{
    return latin1();
}

#if defined( _DEBUG )
const char* BString::_utf8(char* pFile, int nLine) const
{
	BTrace("CheckFileName %s call %s(%d)", __FUNCTION__, pFile, nLine);
    if ( d->ascii ) 
		BrFree(d->ascii);

    d->ascii = unicodeToUtf8( d->unicode, d->len );
    d->dirtyascii = 0;

    return d->ascii;
}
#else
const char* BString::utf8() const
{
    if ( d->ascii ) 
		BrFree(d->ascii);

    d->ascii = unicodeToUtf8( d->unicode, d->len );
    d->dirtyascii = 0;

    return d->ascii;
}
#endif

BString BString::fromLatin1(const char* chars, int len)
{
    unsigned int l;
    BChar *uc;
    
	if ( len < 0 ) 
		uc = internalAsciiToUnicode(chars,&l);
	else 
		uc = internalAsciiToUnicode(chars,&l,len);

	BStringData* dd = BrNEW BStringData(uc, l, l);
#ifdef __sparc__
	UINT8* srcData = (UINT8*)dd->unicode;
	for (int n = 0; n < l * 2; n += 2)
	{
		UINT8 tmp = srcData[n + 1];

		srcData[n + 1] = srcData[n];
		srcData[n] = tmp;
	}
#endif

	return BString(dd, true);
}

void BString::subat( unsigned int i )
{
    unsigned int olen = d->len;
    if ( i >= olen ) 
	{
		setLength( i+1 );
		unsigned int j;
		for ( j=olen; j<=i; j++ )
			d->unicode[j] = BChar();
    } 
	else 
	{
		real_detach();
    }
}

BString& BString::setUnicode( const BChar *unicode, unsigned int len )
{
    if ( len == 0 ) 
	{
		if ( d != s_pBstringshared_null ) 
		{
			deref();
			d = s_pBstringshared_null ? s_pBstringshared_null : makeSharedNull();
			d->ref();
		}
    } 
	else if ( d->count != 1 || len > d->maxl ||
		 ( len*4 < d->maxl && d->maxl > 4 ) ) 
	{
		unsigned int newMax = 4;
		while ( newMax < len )
			newMax *= 2;

		BChar* nd = B_ALLOC_QCHAR_VEC( newMax );

		if ( unicode )
			memcpy( nd, unicode, BrSizeOf(BChar)*len );

		deref();
		
		d = BrNEW BStringData( nd, len, newMax );
	} 
	else 
	{
		d->len = len;
		d->dirtyascii = 1;

		if ( unicode )
			memcpy( d->unicode, unicode, BrSizeOf(BChar)*len );
    }
    return *this;
}

BString& BString::setUnicodeCodes( const unsigned short* unicode_as_ushorts, unsigned int len )
{
    setUnicode((const BChar*)unicode_as_ushorts, len);
    BChar t(0x1234);

    if ( unicode_as_ushorts && *((unsigned short*)&t) == 0x3412 ) 
	{		
		char* b = (char*)d->unicode;
		while ( len-- ) 
		{
			char c = b[0];
			b[0] = b[1];
			b[1] = c;
			b += BrSizeOf(BChar);
		}
    }

    return *this;
}

BString &BString::setLatin1( const char *str, int len )
{
    if ( str == 0 )
		return setUnicode(0,0);

    if ( len < 0 )
		len = BrStrLen(str);

    if ( len == 0 ) 
	{
		deref();
		unsigned int l;
		BChar *uc = internalAsciiToUnicode(str,&l);
		d = BrNEW BStringData(uc,l,l);
    } 
	else 
	{
		setUnicode( 0, len );
		BChar *p = d->unicode;
	
		while ( len-- )
			*p++ = *str++;
    }
#ifdef __sparc__
	UINT8* srcData = (UINT8*)d->unicode;
	for (int n = 0; n < length() * 2; n += 2)
	{
		UINT8 tmp = srcData[n + 1];

		srcData[n + 1] = srcData[n];
		srcData[n] = tmp;
	}
#endif
    return *this;
}

int BString::compare( const BString& s ) const
{
    return ucstrcmp(*this,s);
}

bool BString::startsWith( const BString& s ) const
{
	int i;
    for (i =0; i < (int) s.length(); i++ ) 
	{
		if ( i >= (int) length() || d->unicode[i] != s[i] )
			return false;
    }

    return true;
}


BString BString::simplifyWhiteSpace() const
{
    if ( isEmpty() )				
		return *this;
    BString res;
    res.setLength( length() );
    const BChar *from = unicode();
    const BChar *fromend = from+length();
    int outc=0;
    BChar *to	= res.d->unicode;
    
	for (;;) 
	{
		while ( from!=fromend && from->isSpace() )
			from++;
		while ( from!=fromend && !from->isSpace() )
			to[outc++] = *from++;
		if ( from!=fromend )
			to[outc++] = ' ';
		else
			break;
    }

    if ( outc > 0 && to[outc-1] == ' ' )
		outc--;
    res.truncate( outc );
    
	return res;
}

BString BString::stripWhiteSpace() const
{
    if ( isEmpty() )				
		return *this;

    if ( !at(0).isSpace() && !at(length()-1).isSpace() )
		return *this;

    register const BChar *s = unicode();
    BString result = fromLatin1("");

    int start = 0;
    int end = length() - 1;
    while ( start<=end && s[start].isSpace() )	
	start++;
    if ( start > end ) {			
	return result;
    }
    while ( end && s[end].isSpace() )		
	end--;
    int l = end - start + 1;
    result.setLength( l );
    if ( l )
	memcpy( result.d->unicode, &s[start], BrSizeOf(BChar)*l );
    return result;
}

void BString::getString(UINT16 *pOutStr,  int nLen)
{
	int i, nSrcLen = length();
	
	for (i=0; i<nLen ; i++)
	{
		if (nSrcLen > i)
			pOutStr[i] = at(i).unicode();
		else
		{
			pOutStr[i] = 0;
			break;
		}
	}	
}

//  [3/31/2015 sylee0335] string hash code ���� ����� ���� magic number �� prime number �̾�� ��. 32 -> 31
int BString::hashCode() const
{
	const char* pChar = ascii();
	int i, nLen = BrStrLen(pChar);
	int code=0;
	for(i=0; i<nLen; i++)
		code = 31 * code +  pChar[i];
		//code += pChar[i]*31^(nLen-i-1); // h = 31 * h + val[i];
			
	return code;
}

int BString::hashCodeUnicode() const
{
	const BChar* pChar = unicode();
	int i, nLen = d->len;
	int code = 0;
	for (i = 0; i < nLen; i++)
		code = 31 * code + pChar[i].unicode();

	return code;
}

int BString::IgnoreCaseHashCodeUnicode(bool a_bLocaleLatin) const {
	const BChar* pChar = unicode();
	int i, nLen = d->len;
	int code = 0;
	for (i = 0; i < nLen; i++) {
		if(a_bLocaleLatin)
			code = 31 * code + pChar[i].lower().unicode();
		else
			code = 31 * code + pChar[i].upper().unicode();
	}
	return code;
}

int BString::hashCodeUTF8() const
{
	if( d->len == 0 ) return 0;//[owen] xpd-23126 BString�� ���� 0�� ��� hashCodeUTF8() ũ���� �߻�.

	const char* pChar = utf8(); //�޸� ���� - �Ҵ� ����.
	int i, nLen = BrStrLen(pChar);
	int code=0;
	for(i=0; i<nLen; i++)
		code = 31 * code +  pChar[i];
	//code += pChar[i]*31^(nLen-i-1); // h = 31 * h + val[i];
	return code;
}

BStringData* BString::makeSharedNull()
{
	return s_pBstringshared_null = BrNEW BStringData;
}

bool operator==( const BString &s1, const BString &s2 )
{
    return ( s1.length() == s2.length() ) && s1.isNull() == s2.isNull() &&
	   ( memcmp( (char*)s1.unicode(), (char*)s2.unicode(), s1.length() * BrSizeOf(BChar) ) == 0 );
}

bool operator!=( const BString &s1, const BString &s2 )
{ return !(s1==s2); }

void BString::setMultiByte(unsigned int code_page, const char *szAsc )
{
	int wlen = 0;
	if( szAsc != BrNULL &&  *szAsc != '\0' )
		wlen = BrMultiByteToWideChar( code_page , szAsc , BrStrLen( szAsc ) , BrNULL , 0 );

	BrLPWSTR wbuf = BrNULL;
	if( wlen )
	{
		wbuf = (BrLPWSTR)BrCalloc( (wlen+1) , BrSizeOf( BrWCHAR ) );
		if( wbuf )
		{
			BrMultiByteToWideChar( code_page , szAsc , BrStrLen( szAsc ) , wbuf , wlen );

			setUnicodeCodes( wbuf , wlen );

			BrFree( wbuf );
		}
	}
	else
	{
		setUnicode( BrNULL , 0 ); 
	}
}

//lower() ��� X
// �빮�ڸ� �ҹ��ڷ� ��ȯ�Ͽ� ��(Ư�����ں񱳸� ���Ͽ�)
int BString::compareIgnorUpperLower( const BString& s ) const
{
	int nThisLength = this->length();
	int a_nLength = s.length();

	int nlength = ( nThisLength < a_nLength ) ? nThisLength : a_nLength ;


	for(int i = 0 ; i < nlength ; i ++)
	{
		BChar ch1 = this->at(i);
		BChar ch2 = s.at(i);

		if( ch1 >= 'A' && ch1 <= 'Z')
		{
			ch1 = 'a' + (ch1 - 'A');
		}
		if( ch2 >= 'A' && ch2 <= 'Z')
		{
			ch2 = 'a' + (ch2 - 'A');
		}

		if( ch1 == ch2 )
			continue;
		else
		{
			return ( ch1 < ch2 ) ? -1 : 1 ;
		}
	}

	return ( nThisLength == a_nLength ) ? 0 : ( ( nThisLength < a_nLength ) ? -1 : 1 );
}

int BString::compareIgnoreCase(const BString& a_str, bool a_bLocaleLatin) const
{
	int nThisLength = this->length();
	int a_nLength = a_str.length();
	int loopLen = (nThisLength < a_nLength) ? nThisLength : a_nLength;
	for (int i = 0; i < loopLen; i++)
	{
		if (a_bLocaleLatin) {
			BChar lower = this->d->unicode[i].lower();
			BChar a_lower = a_str.d->unicode[i].lower();
			if (lower == a_lower)
				continue;

			return lower < a_lower ? -1 : 1;
		}
		else {
			BChar upper = this->d->unicode[i].upper();
			BChar a_upper = a_str.d->unicode[i].upper();
			if (upper == a_upper)
				continue;

			return upper < a_upper ? -1 : 1;
		}
	}

	return (nThisLength == a_nLength) ? 0 : ((nThisLength < a_nLength) ? -1 : 1);
}

// MS�� ControlCharacter�� �Ϲ����� ControlCharacter�� ���� ( _x000a_ -> x0a, _x005f_ -> _ )
void BString::convertToControlCharacter()
{
	/**************************************************************************************** 
	  ��ȯ�ϴ� MS Control Character ���
	  _x005f_, _x0000_,
	  _x0001_, _x0002_, _x0003_, _x0004_, _x0005_, _x0006_, _x0007_, _x0008_, _x0009_, _x000a_, _x000b_, _x000c_, _x000d_, _x000e_, _x000f_,
	  _x0010_, _x0011_, _x0012_, _x0013_, _x0014_, _x0015_, _x0016_, _x0017_ ,_x0018_, _x0019_, _x001a_, _x001b_, _x001c_, _x001d_, _x001e_, _x001f_,
	  _xd800 ~ _xdbff(high surrogate)
	******************************************************************************************/

	int nLength = this->length();
	if ( nLength >= 7 ) // MS ControlCharacter(_x005f_) ���̰� 7�̹Ƿ�, �����ִ� Data�� 7���� ���� ���� ���� �ʿ� ����
	{
		BChar oCharacter;
		int   nControlCharacterLen = 7;

		BChar* pTempBuffer = BrNULL;
		int    nTempBufferLen = 0;
		int    nTempBufferIndex = 0;

		BChar  oCheckControlCharacterPrePart[4] = { BChar(0x5f), BChar(0x78), BChar(0x30), BChar(0x30) }; // _x00
		BChar  oCheckHighSurrogatePrePart[2] = { BChar(0x5f), BChar(0x78) };//_x

		int    nControlCharacterPrePartLen = 4;
		int    nHas_ControlCharacterPrePart = 1;

		int    nHighSurrogatePrePartLen = 2;
		int    nHas_HighSurrogatePrePart = 1;

		int    nPartIndex = 0;

		for(int nIndex = 0 ; nIndex < nLength ; nIndex++, nTempBufferIndex++)
		{
			oCharacter = this->at(nIndex);

			if ( oCharacter.unicode() == 0x005f )  // '_' �� ��
			{
				if ( (nLength - nIndex) >= 7 )
				{
					nHas_ControlCharacterPrePart = memcmp( this->unicode()+nIndex, oCheckControlCharacterPrePart, (BrSizeOf(BChar)*nControlCharacterPrePartLen) );
					nPartIndex = nIndex;

					if ( nHas_ControlCharacterPrePart == 0 )
					{
						nPartIndex += nControlCharacterPrePartLen;
						oCharacter = this->at(nPartIndex++);
						switch (oCharacter.unicode())
						{
						case 0x0035:
							{
								oCharacter = this->at(nPartIndex++);
								if ( oCharacter.unicode() == 0x0066 || oCharacter.unicode() == 0x0046 ) // ��ҹ��� ��� 
								{
									oCharacter = this->at(nPartIndex++);
									if ( oCharacter.unicode() == 0x005f )
									{
										convertToControlCharacter_Substitution(&pTempBuffer, nIndex, nLength, nTempBufferIndex, nTempBufferLen);
										*(d->unicode+nIndex) = BChar(0x5f);
									}
								}
							}
							break;
						case 0x0030:
							{
								oCharacter = this->at(nPartIndex++);
								switch (oCharacter.unicode())
								{
								case 0x0030:
									{
										oCharacter = this->at(nPartIndex++);
										if ( oCharacter.unicode() == 0x005f )
										{
											convertToControlCharacter_Substitution(&pTempBuffer, nIndex, nLength, nTempBufferIndex, nTempBufferLen);
											*(d->unicode+nIndex) = BChar(0x00);
										}
									}
									break;
								case 0x0031:
									{
										oCharacter = this->at(nPartIndex++);
										if ( oCharacter.unicode() == 0x005f )
										{
											convertToControlCharacter_Substitution(&pTempBuffer, nIndex, nLength, nTempBufferIndex, nTempBufferLen);
											*(d->unicode+nIndex) = BChar(0x01);
										}
									}
									break;
								case 0x0032:
									{
										oCharacter = this->at(nPartIndex++);
										if ( oCharacter.unicode() == 0x005f )
										{
											convertToControlCharacter_Substitution(&pTempBuffer, nIndex, nLength, nTempBufferIndex, nTempBufferLen);
											*(d->unicode+nIndex) = BChar(0x02);
										}
									}
									break;
								case 0x0033:
									{
										oCharacter = this->at(nPartIndex++);
										if ( oCharacter.unicode() == 0x005f )
										{
											convertToControlCharacter_Substitution(&pTempBuffer, nIndex, nLength, nTempBufferIndex, nTempBufferLen);
											*(d->unicode+nIndex) = BChar(0x03);
										}
									}
									break;
								case 0x0034:
									{
										oCharacter = this->at(nPartIndex++);
										if ( oCharacter.unicode() == 0x005f )
										{
											convertToControlCharacter_Substitution(&pTempBuffer, nIndex, nLength, nTempBufferIndex, nTempBufferLen);
											*(d->unicode+nIndex) = BChar(0x04);
										}
									}
									break;
								case 0x0035:
									{
										oCharacter = this->at(nPartIndex++);
										if ( oCharacter.unicode() == 0x005f )
										{
											convertToControlCharacter_Substitution(&pTempBuffer, nIndex, nLength, nTempBufferIndex, nTempBufferLen);
											*(d->unicode+nIndex) = BChar(0x05);
										}
									}
									break;
								case 0x0036:
									{
										oCharacter = this->at(nPartIndex++);
										if ( oCharacter.unicode() == 0x005f )
										{
											convertToControlCharacter_Substitution(&pTempBuffer, nIndex, nLength, nTempBufferIndex, nTempBufferLen);
											*(d->unicode+nIndex) = BChar(0x06);
										}
									}
									break;
								case 0x0037:
									{
										oCharacter = this->at(nPartIndex++);
										if ( oCharacter.unicode() == 0x005f )
										{
											convertToControlCharacter_Substitution(&pTempBuffer, nIndex, nLength, nTempBufferIndex, nTempBufferLen);
											*(d->unicode+nIndex) = BChar(0x07);
										}
									}
									break;
								case 0x0038:
									{
										oCharacter = this->at(nPartIndex++);
										if ( oCharacter.unicode() == 0x005f )
										{
											convertToControlCharacter_Substitution(&pTempBuffer, nIndex, nLength, nTempBufferIndex, nTempBufferLen);
											*(d->unicode+nIndex) = BChar(0x08);
										}
									}
									break;
								case 0x0039:
									{
										oCharacter = this->at(nPartIndex++);
										if ( oCharacter.unicode() == 0x005f )
										{
											convertToControlCharacter_Substitution(&pTempBuffer, nIndex, nLength, nTempBufferIndex, nTempBufferLen);
											*(d->unicode+nIndex) = BChar(0x09);
										}
									}
									break;
								case 0x0041: // �빮��
								case 0x0061: // �ҹ��� 
									{
										oCharacter = this->at(nPartIndex++);
										if ( oCharacter.unicode() == 0x005f )
										{
											convertToControlCharacter_Substitution(&pTempBuffer, nIndex, nLength, nTempBufferIndex, nTempBufferLen);
											*(d->unicode+nIndex) = BChar(0x0a);
										}
									}
									break;
								case 0x0042: 
								case 0x0062:
									{
										oCharacter = this->at(nPartIndex++);
										if ( oCharacter.unicode() == 0x005f )
										{
											convertToControlCharacter_Substitution(&pTempBuffer, nIndex, nLength, nTempBufferIndex, nTempBufferLen);
											*(d->unicode+nIndex) = BChar(0x0b);
										}
									}
									break;
								case 0x0043: 
								case 0x0063:
									{
										oCharacter = this->at(nPartIndex++);
										if ( oCharacter.unicode() == 0x005f )
										{
											convertToControlCharacter_Substitution(&pTempBuffer, nIndex, nLength, nTempBufferIndex, nTempBufferLen);
											*(d->unicode+nIndex) = BChar(0x0c);
										}
									}
									break;
								case 0x0044:
								case 0x0064:
									{
										oCharacter = this->at(nPartIndex++);
										if ( oCharacter.unicode() == 0x005f )
										{
											convertToControlCharacter_Substitution(&pTempBuffer, nIndex, nLength, nTempBufferIndex, nTempBufferLen);
											*(d->unicode+nIndex) = BChar(0x0d);
										}
									}
									break;
								case 0x0045:
								case 0x0065:
									{
										oCharacter = this->at(nPartIndex++);
										if ( oCharacter.unicode() == 0x005f )
										{
											convertToControlCharacter_Substitution(&pTempBuffer, nIndex, nLength, nTempBufferIndex, nTempBufferLen);
											*(d->unicode+nIndex) = BChar(0x0e);
										}
									}
									break;
								case 0x0046:
								case 0x0066:
									{
										oCharacter = this->at(nPartIndex++);
										if ( oCharacter.unicode() == 0x005f )
										{
											convertToControlCharacter_Substitution(&pTempBuffer, nIndex, nLength, nTempBufferIndex, nTempBufferLen);
											*(d->unicode+nIndex) = BChar(0x0f);
										}
									}
									break;
								default:
									break;
								}
							}
							break;
						case 0x0031:
							{
								oCharacter = this->at(nPartIndex++);
								switch (oCharacter.unicode())
								{
								case 0x0030:
									{
										oCharacter = this->at(nPartIndex++);
										if ( oCharacter.unicode() == 0x005f )
										{
											convertToControlCharacter_Substitution(&pTempBuffer, nIndex, nLength, nTempBufferIndex, nTempBufferLen);
											*(d->unicode+nIndex) = BChar(0x10);
										}
									}
									break;
								case 0x0031:
									{
										oCharacter = this->at(nPartIndex++);
										if ( oCharacter.unicode() == 0x005f )
										{
											convertToControlCharacter_Substitution(&pTempBuffer, nIndex, nLength, nTempBufferIndex, nTempBufferLen);
											*(d->unicode+nIndex) = BChar(0x11);
										}
									}
									break;
								case 0x0032:
									{
										oCharacter = this->at(nPartIndex++);
										if ( oCharacter.unicode() == 0x005f )
										{
											convertToControlCharacter_Substitution(&pTempBuffer, nIndex, nLength, nTempBufferIndex, nTempBufferLen);
											*(d->unicode+nIndex) = BChar(0x12);
										}
									}
									break;
								case 0x0033:
									{
										oCharacter = this->at(nPartIndex++);
										if ( oCharacter.unicode() == 0x005f )
										{
											convertToControlCharacter_Substitution(&pTempBuffer, nIndex, nLength, nTempBufferIndex, nTempBufferLen);
											*(d->unicode+nIndex) = BChar(0x13);
										}
									}
									break;
								case 0x0034:
									{
										oCharacter = this->at(nPartIndex++);
										if ( oCharacter.unicode() == 0x005f )
										{
											convertToControlCharacter_Substitution(&pTempBuffer, nIndex, nLength, nTempBufferIndex, nTempBufferLen);
											*(d->unicode+nIndex) = BChar(0x14);
										}
									}
									break;
								case 0x0035:
									{
										oCharacter = this->at(nPartIndex++);
										if ( oCharacter.unicode() == 0x005f )
										{
											convertToControlCharacter_Substitution(&pTempBuffer, nIndex, nLength, nTempBufferIndex, nTempBufferLen);
											*(d->unicode+nIndex) = BChar(0x15);
										}
									}
									break;
								case 0x0036:
									{
										oCharacter = this->at(nPartIndex++);
										if ( oCharacter.unicode() == 0x005f )
										{
											convertToControlCharacter_Substitution(&pTempBuffer, nIndex, nLength, nTempBufferIndex, nTempBufferLen);
											*(d->unicode+nIndex) = BChar(0x16);
										}
									}
									break;
								case 0x0037:
									{
										oCharacter = this->at(nPartIndex++);
										if ( oCharacter.unicode() == 0x005f )
										{
											convertToControlCharacter_Substitution(&pTempBuffer, nIndex, nLength, nTempBufferIndex, nTempBufferLen);
											*(d->unicode+nIndex) = BChar(0x17);
										}
									}
									break;
								case 0x0038:
									{
										oCharacter = this->at(nPartIndex++);
										if ( oCharacter.unicode() == 0x005f )
										{
											convertToControlCharacter_Substitution(&pTempBuffer, nIndex, nLength, nTempBufferIndex, nTempBufferLen);
											*(d->unicode+nIndex) = BChar(0x18);
										}
									}
									break;
								case 0x0039:
									{
										oCharacter = this->at(nPartIndex++);
										if ( oCharacter.unicode() == 0x005f )
										{
											convertToControlCharacter_Substitution(&pTempBuffer, nIndex, nLength, nTempBufferIndex, nTempBufferLen);
											*(d->unicode+nIndex) = BChar(0x19);
										}
									}
									break;
								case 0x0041: // �빮��
								case 0x0061: // �ҹ���
									{
										oCharacter = this->at(nPartIndex++);
										if ( oCharacter.unicode() == 0x005f )
										{
											convertToControlCharacter_Substitution(&pTempBuffer, nIndex, nLength, nTempBufferIndex, nTempBufferLen);
											*(d->unicode+nIndex) = BChar(0x1a);
										}
									}
									break;
								case 0x0042:
								case 0x0062:
									{
										oCharacter = this->at(nPartIndex++);
										if ( oCharacter.unicode() == 0x005f )
										{
											convertToControlCharacter_Substitution(&pTempBuffer, nIndex, nLength, nTempBufferIndex, nTempBufferLen);
											*(d->unicode+nIndex) = BChar(0x1b);
										}
									}
									break;
								case 0x0043:
								case 0x0063:
									{
										oCharacter = this->at(nPartIndex++);
										if ( oCharacter.unicode() == 0x005f )
										{
											convertToControlCharacter_Substitution(&pTempBuffer, nIndex, nLength, nTempBufferIndex, nTempBufferLen);
											*(d->unicode+nIndex) = BChar(0x1c);
										}
									}
									break;
								case 0x0044:
								case 0x0064:
									{
										oCharacter = this->at(nPartIndex++);
										if ( oCharacter.unicode() == 0x005f )
										{
											convertToControlCharacter_Substitution(&pTempBuffer, nIndex, nLength, nTempBufferIndex, nTempBufferLen);
											*(d->unicode+nIndex) = BChar(0x1d);
										}
									}
									break;
								case 0x0045:
								case 0x0065:
									{
										oCharacter = this->at(nPartIndex++);
										if ( oCharacter.unicode() == 0x005f )
										{
											convertToControlCharacter_Substitution(&pTempBuffer, nIndex, nLength, nTempBufferIndex, nTempBufferLen);
											*(d->unicode+nIndex) = BChar(0x1e);
										}
									}
									break;
								case 0x0046:
								case 0x0066:
									{
										oCharacter = this->at(nPartIndex++);
										if ( oCharacter.unicode() == 0x005f )
										{
											convertToControlCharacter_Substitution(&pTempBuffer, nIndex, nLength, nTempBufferIndex, nTempBufferLen);
											*(d->unicode+nIndex) = BChar(0x1f);
										}
									}
									break;
								default:
									break;
								}
							}
							break;
						default:
							break;
						}
					}

					// [2018/1/16][hyunwook][OFF-14079] _xD800 ~ _xDBFF(High surrogate) ����
					nHas_HighSurrogatePrePart = memcmp( this->unicode()+nIndex, oCheckHighSurrogatePrePart, (BrSizeOf(BChar)*nHighSurrogatePrePartLen) );
					nPartIndex = nIndex;
					if( nHas_HighSurrogatePrePart == 0 )
					{
						nPartIndex += nHighSurrogatePrePartLen;

						oCharacter = this->at(nPartIndex++);
						int nUniCode = (int)oCharacter.unicode();

						int nValue = 0;
						int nNumberLenth = 0;
						while((nUniCode >= '0' && nUniCode <= '9') || 
							  (nUniCode >= 'A' && nUniCode <= 'F') ||
							  (nUniCode >= 'a' && nUniCode <= 'f')) 
						{
							if (nUniCode >= '0' && nUniCode <= '9') nValue = nValue * 16 + nUniCode - '0';
							if (nUniCode >= 'A' && nUniCode <= 'F') nValue = nValue * 16 + 10 + nUniCode - 'A';
							if (nUniCode >= 'a' && nUniCode <= 'f') nValue = nValue * 16 + 10 + nUniCode - 'a';

							oCharacter = this->at(nPartIndex++);
							nUniCode = (int)oCharacter.unicode();

							nNumberLenth++;
							if( nNumberLenth == 4) 
								break;;
						}

						if( nNumberLenth == 4 && ( nValue >= 0xd800 && nValue <= 0xdbff ) ) // _xD800 ~ _xDBFF���θ� ����
						{
							convertToControlCharacter_Substitution(&pTempBuffer, nIndex, nLength, nTempBufferIndex, nTempBufferLen);
							*(d->unicode+nIndex) = BChar(nValue);
						}
					}
				}
			}
		}

		if ( pTempBuffer )
			B_DELETE_QCHAR_VEC( pTempBuffer );
	}
}

void BString::convertToControlCharacter_Substitution( BChar** a_pTempBuffer, int a_nIndex, int& a_nLength, int& a_nTempBufferIndex, int& a_nTempBufferLen )
{
	if ( (*a_pTempBuffer) == BrNULL )
	{
		(*a_pTempBuffer) = B_ALLOC_QCHAR_VEC( a_nLength );
		memcpy( (*a_pTempBuffer), this->unicode(), BrSizeOf(BChar)*a_nLength );
		a_nTempBufferLen = a_nLength;
	}

	memcpy( d->unicode+a_nIndex+1, (*a_pTempBuffer)+a_nTempBufferIndex+7, (BrSizeOf(BChar)*(a_nTempBufferLen - a_nTempBufferIndex - 7)) );

	a_nLength -= 6;
	setLength( a_nLength );

	a_nTempBufferIndex += 6;
}

//

bool operator<( const BString &s1, const BString &s2 )
{ return ucstrcmp(s1,s2) < 0; }

bool operator<=( const BString &s1, const BString &s2 )
{ return ucstrcmp(s1,s2) <= 0; }

bool operator>( const BString &s1, const BString &s2 )
{ return ucstrcmp(s1,s2) > 0; }

bool operator>=( const BString &s1, const BString &s2 )
{ return ucstrcmp(s1,s2) >= 0; }

//[20140327][jdjang] char* �� ����ȭ
bool operator==( const BString &s1, const char *s2 )
{
	if ( s2 == BrNULL )
	{
		return (s1.unicode() == BrNULL) ? true : false;
	}
	else
	{
		unsigned int nSize;
		BChar *uc = internalAsciiToUnicode( s2, &nSize );

		bool bRet = ( s1.length() == nSize ) &&
					( s1.isNull() == ( uc == BrNULL ) );
		if(bRet && uc != BrNULL)
			bRet = ( memcmp( (char*)s1.unicode(), (char*)uc, s1.length()*BrSizeOf(BChar) ) == 0 );

		B_DELETE_QCHAR_VEC(uc);

		return bRet;
	}
}

//[20140327][jdjang] char* �� ����ȭ
bool operator==( const char *s1, const BString &s2 )
{
	if ( s1 == BrNULL )
	{
		return (s2.unicode() == BrNULL) ? true : false;
	}
	else
	{
		unsigned int nSize;
		BChar *uc = internalAsciiToUnicode( s1, &nSize );

		bool bRet = ( s2.length() == nSize ) &&
					( s2.isNull() == ( uc == BrNULL ) );
		if(bRet && uc != BrNULL)
			bRet = ( memcmp( (char*)uc, (char*)s2.unicode(), nSize*BrSizeOf(BChar) ) == 0 );

		B_DELETE_QCHAR_VEC(uc);

		return bRet;
	}
}

bool operator!=( const BString &s1, const char *s2 )
{ return !(s1==s2); }

bool operator!=( const char *s1, const BString &s2 )
{ return !(s1==s2); }

bool operator<( const BString &s1, const char *s2 )
{ return ucstrcmp(s1,s2) < 0; }

bool operator<( const char *s1, const BString &s2 )
{ return ucstrcmp(s1,s2) < 0; }

bool operator<=( const BString &s1, const char *s2 )
{ return ucstrcmp(s1,s2) <= 0; }

bool operator<=( const char *s1, const BString &s2 )
{ return ucstrcmp(s1,s2) <= 0; }

bool operator>( const BString &s1, const char *s2 )
{ return ucstrcmp(s1,s2) > 0; }

bool operator>( const char *s1, const BString &s2 )
{ return ucstrcmp(s1,s2) > 0; }

bool operator>=( const BString &s1, const char *s2 )
{ return ucstrcmp(s1,s2) >= 0; }

bool operator>=( const char *s1, const BString &s2 )
{ return ucstrcmp(s1,s2) >= 0; }


///////////////////////////////////////////////////////////////////////////////////////////////////////////
static NRChar* internalAsciiToUnicode_TC( const char *str, unsigned int* len )
{
	NRChar* result = 0;
	unsigned int l = 0;

	if ( str ) 
	{
		NRChar *uc = BrNULL;	
		l = BrStrLen(str);
		if ( l )
		{
			PO_THREAD_TRY_BLOCK {
				uc = B_ALLOC_NRCHAR_VEC( l );
				if ( !uc )
					g_pBInterfaceHandle->POForceThreadCancel();				
			} PO_THREAD_CATCH_BLOCK { 	
			} PO_THREAD_END
			result = uc;
			unsigned int i = l;
			while ( i-- )
				*uc++ = *str++;
		}		
	}

	if ( len )
		*len = l;

	return result;
}

NRChar NRChar::lower(BrBOOL a_bUseLocaleStr) const
{
	if(row())
	{
		if(a_bUseLocaleStr)
			return NRChar(BrToLower(unicode(), a_bUseLocaleStr));
		else
			return *this;
	}
	else
		return NRChar(BrToLower(latin1()));
}

NRChar NRChar::upper(BrBOOL a_bUseLocaleStr) const
{
	if(row())
	{
		if(a_bUseLocaleStr)
			return NRChar(BrToUpper(unicode(), a_bUseLocaleStr));
		else
			return *this;
	}
	else
		return NRChar(BrToUpper(latin1()));
}

NRString::NRString()
{
	init();
}

NRString::NRString( const char *str )
{
	init();
	unsigned int l = 0;
	NRChar *uc = internalAsciiToUnicode_TC(str,&l);
	m_unicode = uc;
	len = l;
	maxl = l;
	ascii = const_cast< char*> (str);
}

NRString::NRString( const NRChar& ch )
{
	init();
	PO_THREAD_TRY_BLOCK {
		m_unicode = (NRChar*) B_ALLOC_NRCHAR_VEC( 1 );
		if ( !m_unicode )
			g_pBInterfaceHandle->POForceThreadCancel();		
	} PO_THREAD_CATCH_BLOCK { 	
	} PO_THREAD_END

	if(m_unicode)
		m_unicode[0] = ch;
	len = 1;
	maxl = 1;
	ascii = unicodeToAscii( &ch, 1 );
}

NRString::NRString( const BString& s )
{		
	init();
	PO_THREAD_TRY_BLOCK {
		if(!s.isEmpty())
		{
			BChar* nonConst = const_cast < BChar* > ( s.unicode() );
			NRChar* pAdaptStr = reinterpret_cast < NRChar* > (nonConst);

			m_unicode = (NRChar*) B_ALLOC_NRCHAR_VEC( s.length());
			if ( !m_unicode )
				g_pBInterfaceHandle->POForceThreadCancel();

			memcpy( m_unicode, pAdaptStr, s.length() * BrSizeOf ( NRChar ) );
			ascii = const_cast< char*> (s.ascii());
			len = s.length();
			maxl = len;	
		}					
	} PO_THREAD_CATCH_BLOCK {
	} PO_THREAD_END
}

#ifdef SPECIALBASE_STD_MEMORY_RELEASE
NRString::NRString( const NRString& s )
{
	init();
	append(s);
}
#endif

NRString::~NRString()
{
#ifdef SPECIALBASE_STD_MEMORY_RELEASE
	if (m_unicode)
	{
		B_DELETE_QCHAR_VEC(m_unicode);
		m_unicode = BrNULL;
	}
#endif	// SPECIALBASE_STD_MEMORY_RELEASE
}

unsigned int NRString::length() const
{ 
	return len; 
}

#ifdef SPECIALBASE_STD_MEMORY_RELEASE
void NRString::setString(const BString& s)
{
	if (m_unicode)
	{
		B_DELETE_QCHAR_VEC(m_unicode);
		m_unicode = BrNULL;
	}

	PO_THREAD_TRY_BLOCK{
		if (!s.isEmpty())
		{
			BChar* nonConst = const_cast <BChar*> (s.unicode());
			NRChar* pAdaptStr = reinterpret_cast <NRChar*> (nonConst);

			m_unicode = (NRChar*)B_ALLOC_NRCHAR_VEC(s.length());
			if (!m_unicode)
				g_pBInterfaceHandle->POForceThreadCancel();

			memcpy(m_unicode, pAdaptStr, s.length() * BrSizeOf(NRChar));
			ascii = const_cast<char*> (s.ascii());
			len = s.length();
			maxl = len;
		}
	} PO_THREAD_CATCH_BLOCK{
	} PO_THREAD_END
}
void NRString::setString(const char* str)
{
	if (m_unicode)
	{
		B_DELETE_QCHAR_VEC(m_unicode);
		m_unicode = BrNULL;
	}

	unsigned int l = 0;
	NRChar* uc = internalAsciiToUnicode_TC(str, &l);
	m_unicode = uc;
	len = l;
	maxl = l;
	ascii = const_cast<char*> (str);

}

void NRString::setString(NRChar ch)
{
	PO_THREAD_TRY_BLOCK{
	m_unicode = (NRChar*)B_ALLOC_NRCHAR_VEC(1);
	if (!m_unicode)
		g_pBInterfaceHandle->POForceThreadCancel();
	} PO_THREAD_CATCH_BLOCK{
	} PO_THREAD_END

	if (m_unicode)
		m_unicode[0] = ch;
	len = 1;
	maxl = 1;
	ascii = unicodeToAscii(&ch, 1);
}

NRString& NRString::operator=(NRString s)
{
	if(m_unicode && len > 0)
		B_DELETE_QCHAR_VEC(m_unicode);

	init();
	append(s);

	return *this;
}
#endif

NRString &NRString::operator=( const NRChar& c )
{ 
#ifdef SPECIALBASE_STD_MEMORY_RELEASE
	setString(c);
	return *this; 
#else
	return *this = NRString(c); 
#endif
}

NRString &NRString::operator=( char c )
{ 
#ifdef SPECIALBASE_STD_MEMORY_RELEASE
	setString(c);
	return *this; 
#else
	return *this = NRString(BChar(c)); 
#endif
}

NRString& NRString::operator+=( const NRString &str )
{
	unsigned int len1 = length();
	unsigned int len2 = str.length();

	if ( len2 ) 
	{
		setLength(len1+len2);
		if( len1 < length() )
			memcpy( m_unicode+len1, str.unicode(), BrSizeOf(NRChar)*len2 );
	} 
	return *this;
}

NRString &NRString::operator+=( const NRChar& c )
{
	setLength(length()+1);
	m_unicode[length()-1] = c;

	return *this;
}

//  [4/29/2016 sylee0335] append ���� ���� 
NRString &NRString::appendWithLargeGrowth( char c )
{
	setLengthWithLargeGrowth(length()+1);
	m_unicode[length()-1] = c;
	return *this;
}


//  [4/29/2016 sylee0335] append ���� ���� 
NRString &NRString::appendWithLargeGrowth( const NRChar& c )
{
	setLengthWithLargeGrowth(length()+1);
	m_unicode[length()-1] = c;

	return *this;
}


bool operator==( const NRString &s1, const NRString &s2 )
{
	return ( s1.length() == s2.length() ) && s1.isNull() == s2.isNull() &&
		( memcmp( (char*)s1.unicode(), (char*)s2.unicode(), s1.length() * BrSizeOf(NRChar) ) == 0 );
}

bool operator!=( const NRString &s1, const NRString &s2 )
{ return !(s1==s2); }

bool operator!=( const NRString &s1, const char *s2 )
{ return !(s1==s2); }

bool operator!=( const char *s1, const NRString &s2 )
{ return !(s1==s2); }

void NRString::setLength( unsigned int newLen )
{
	if ( newLen > maxl) 
	{	
		// Performane Tunning
		unsigned int newMax = maxl;	
		do
		{
			newMax += AUTO_GROWSIZE;
		} while ( newMax < newLen );
		///////////////////////////////////

		NRChar* nd = BrNULL;
		PO_THREAD_TRY_BLOCK {
			nd = B_ALLOC_NRCHAR_VEC(newMax);		
			if ( !nd )
				g_pBInterfaceHandle->POForceThreadCancel();
		} PO_THREAD_CATCH_BLOCK { 	
		} PO_THREAD_END

		unsigned int tmpLen = BrMIN( length(), newLen );
		if ( m_unicode )
			memcpy( nd, m_unicode, BrSizeOf(NRChar)*tmpLen );

		m_unicode = nd ;
		ascii=0;
		len= newLen;
		maxl= newMax;
	} 
	else 
		len = newLen;
}

void NRString::setLengthWithLargeGrowth( unsigned int newLen )
{
	if ( newLen > maxl) 
	{	
		// Performane Tunning
		unsigned int newMax = maxl;	
		do
		{
			newMax += AUTO_GROWSIZE_LARGESCALE;
		} while ( newMax < newLen );
		///////////////////////////////////

		NRChar* nd = BrNULL;
		PO_THREAD_TRY_BLOCK {
			nd = B_ALLOC_NRCHAR_VEC(newMax);
			if ( !nd )
				g_pBInterfaceHandle->POForceThreadCancel();
		} PO_THREAD_CATCH_BLOCK { 	
		} PO_THREAD_END

		unsigned int tmpLen = BrMIN( length(), newLen );
		if ( m_unicode )
			memcpy( nd, m_unicode, BrSizeOf(NRChar)*tmpLen );

		m_unicode = nd ;
		ascii=0;
		len= newLen;
		maxl= newMax;
	} 
	else 
		len = newLen;
}

bool NRString::isNull() const
{ 
	return unicode() == 0; 
}

bool NRString::isEmpty() const
{ 
	return length() == 0; 
}


static int ucstrcmp( const NRString &as, const NRString &bs )
{
	const NRChar *a = as.unicode();
	const NRChar *b = bs.unicode();

	if ( a == b ) return 0;
	if ( a == 0 ) return 1;
	if ( b == 0 ) return -1;

	int l=BrMIN(as.length(),bs.length());
	int nMin = l;

	while ( l-- && *a == *b )
		a++,b++;

	if ( l==-1 )
	{
		if ( as.length() != bs.length() )
		{
			if ( nMin == as.length() )
				return 0 - b->unicode();
			else if (nMin == bs.length() )
				return a->unicode() - 0;
		}

		return ( as.length()-bs.length() );
	}

	return a->unicode() - b->unicode();
}


int NRString::compare( const NRString& s ) const
{
	return ucstrcmp(*this,s);
}

NRString &NRString::insert( unsigned int index, const NRChar& c )
{
	return insert( index, &c, 1 );
}

NRString &NRString::insert( unsigned int index, const NRChar* s, unsigned int len )
{
	if ( len == 0 )
		return *this;

	unsigned int olen = length();
	int nlen = olen + len;

	int df = s - m_unicode;
	if ( df >= 0 && (unsigned int)df < maxl ) 
	{
		NRChar *tmp = BrNULL;
		PO_THREAD_TRY_BLOCK {
			tmp = B_ALLOC_NRCHAR_VEC ( len );
			if ( !tmp )
				g_pBInterfaceHandle->POForceThreadCancel();		
		} PO_THREAD_CATCH_BLOCK { 	
		} PO_THREAD_END

		memcpy(tmp,s,len*BrSizeOf(NRChar));
		insert(index,tmp,len);
		return *this;
	}

	if ( index >= olen ) 
	{
		setLength( len+index );
		int n = index-olen;
		NRChar* uc = m_unicode+olen;
		while (n--)
			*uc++ = ' ';
		memcpy( m_unicode+index, s, BrSizeOf(NRChar)*len );
	} 
	else 
	{
		setLength( nlen );
		BrMemmove( m_unicode+index+len, (BrLPVOID)(unicode()+index),
			BrSizeOf(BChar)*(olen-index) );
		BrMemmove( m_unicode+index, (BrLPVOID)s, BrSizeOf(NRChar)*len );
	}

	return *this;
}

const char* NRString::latin1()
{
	ascii = unicodeToAscii( m_unicode, len );
	return ascii ;
}

char* NRString::unicodeToAscii(const NRChar *uc, unsigned int l)
{
	if (!uc) 
		return 0;

	char *a = BrNULL;
	PO_THREAD_TRY_BLOCK {
		a = (char*)BrSpecialBlockMalloc(BrSizeOf(char)*(l+1));
		if ( !a )
			g_pBInterfaceHandle->POForceThreadCancel();		
	} PO_THREAD_CATCH_BLOCK { 	
	} PO_THREAD_END
	char *result = a;
	while (l--)
		*a++ = *uc++;

	*a = '\0';
	return result;

}
 
NRString & NRString::remove(unsigned int index, unsigned int len)
{
	 unsigned int olen = length();

    if ( index >= olen  ) ;
	else if ( index + len >= olen ) 
	{
        setLength( index );
    } 
	else if ( len != 0 ) 
	{
		 setLength( length() );
		BrMemmove( m_unicode+index, (BrLPVOID)(m_unicode+index+len),
			 BrSizeOf(NRChar)*(olen-index-len) );
		setLength( olen-len );
    }
    return *this;
}

NRString &NRString::replace( unsigned int index, unsigned int len, const NRString &s )
{
	return replace( index, len, s.unicode(), s.length() );
}

NRString &NRString::replace( unsigned int index, unsigned int len, const NRChar* s, unsigned int slen )
{
	if ( len == slen && index + len <= length() ) 
	{
		real_detach();
		memcpy( m_unicode+index, s, len*BrSizeOf(NRChar) );
	} 
	else 
	{
		int df = s - m_unicode;
		if ( df >= 0 && (unsigned int)df < maxl ) 
		{
			NRChar *tmp = BrNULL;
			PO_THREAD_TRY_BLOCK {
				tmp = B_ALLOC_NRCHAR_VEC( slen );
				if ( !tmp )
					g_pBInterfaceHandle->POForceThreadCancel();						
			} PO_THREAD_CATCH_BLOCK { 	
			} PO_THREAD_END

			memcpy(tmp,s,slen*BrSizeOf(NRChar));
			replace(index,len,tmp,slen);
			B_DELETE_QCHAR_VEC( tmp );
			return *this;
		}

		remove( index, len );
		insert( index, s, slen );
	}

	return *this;
}

int NRString::contains(const char* str, bool cs) const
{
	return contains(NRString(str), cs);
}

int NRString::contains(const NRString& str, bool cs) const
{
	int count = 0;
	const NRChar* uc = m_unicode;

	if (!uc)
		return 0;

	int len = str.length();
	int n = length();

	while (n--)
	{
		if (cs)
		{
			if (ucstrncmp(uc, str.unicode(), len) == 0)
				count++;
		}
		else
		{
			if (ucstrnicmp(uc, str.unicode(), len) == 0)
				count++;
		}
		uc++;
	}
	return count;
}

void NRString::real_detach()
{
	setLength( length() );
}


int NRString::find( char c, int index, bool cs ) const
{ 
	return find(NRChar(c), index, cs); 
}

int NRString::contains(NRChar c, bool cs) const
{
	int count = 0;
	const NRChar* uc = m_unicode;

	if (!uc)
		return 0;

	int n = length();

	if (cs)
	{
		while (n--)
			if (*uc++ == c)
				count++;
	}
	else
	{
		c = c.lower();
		while (n--)
		{
			if (uc->lower() == c)
				count++;
			uc++;
		}
	}

	return count;
}


int NRString::find( NRChar c, int index, bool cs ) const
{
	if ( index < 0 )
		index += length();

	if ( (unsigned int)index >= length() )
		return -1;

	register const NRChar *uc;
	uc = unicode()+index;
	int n = length()-index;

	if ( cs ) 
	{
		while ( n-- && *uc != c )
			uc++;
	} 
	else 
	{
		c = c.lower();
		while ( n-- && uc->lower() != c )
			uc++;
	}

	if ( (unsigned int)(uc - unicode()) >= length() )
		return -1;

	return (int)(uc - unicode());
}



