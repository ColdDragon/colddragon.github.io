#include <OfficePreComp.hpp>
#include "POFileManager.h"
#include "butil.h"
#include "BFile.h"
#include "../Error/ErrorHandle.h"
#include "../Error/CPublicErrorObj.h"

PoFileManager::PoFileManager()
{
	fileInfoArray.clear();
	oleFileArray.clear();
	qbkFile = BrNULL;
	document = BrNULL;
	themeFile = BrNULL;
	decryptedFile = BrNULL;
}

PoFileManager::~PoFileManager()
{
	releaseAllData();
}

bool PoFileManager::changeStatus(void* filePointer, file_status fileStatus)
{
	if (filePointer)
	{
		PoFileInfoArray::iterator it;
		PoFileInfoArray* fileArray = &fileInfoArray;
		for (it = fileArray->begin(); it != fileArray->end(); it++)
		{
			if (*it == BrNULL)
				return false;

			PoFileInfo* fileItem = *it;
			if (fileItem->fp == filePointer)
			{
				fileItem->fs = fileStatus;
				if (fileItem->fs == PO_FILE_CLOSE)
					fileItem->fp = BrNULL;
				else
					fileItem->fp = filePointer;
				return true;
			}
		}
	}
	return false;
}
bool PoFileManager::fileRegister(const BString& fileName, void* filePointer, file_status fileStatue, const BString& openMode, bool fontFile)
{
	if(fileName.length() == 0 || filePointer == BrNULL)
		return BrFALSE;

	BrBOOL bFind = BrFALSE;
	BrAutoChar tmp = CUtil::convertBStringToChar(&fileName, CP_UTF8);
	char* strFileName = (char*)tmp.get();	
	BrAutoChar openTmp = CUtil::convertBStringToChar(&openMode, CP_UTF8);
	char* strOpenMode = (char*)openTmp.get();	
	PoFileInfoArray::iterator it;	
	PoFileInfoArray* fileArray = &fileInfoArray;

	if(fileArray == BrNULL)
		return SetErrorFReturn(CPublicError(kPoErrFileIOFileUsingType));

	for (it = fileArray->begin(); it != fileArray->end(); it++)
	{
		if(*it == BrNULL)
			return BrFALSE;

		PoFileInfo* fileItem = *it;	
		if (fileItem->filePathName && 0 == strcmp(strFileName, fileItem->filePathName) && fileItem->fp == filePointer)
		{
			bFind = BrTRUE;
			setData(fileItem, strFileName, filePointer, fileStatue, strOpenMode);
			break;
		}
	}

	if(!bFind)
	{
		PoFileInfo* fileItem = (PoFileInfo*)BrSysCalloc(sizeof(PoFileInfo), 1);
		memset(fileItem, 0, sizeof(PoFileInfo));
		setData(fileItem, strFileName, filePointer, fileStatue, strOpenMode);
		fileItem->fontFile = fontFile;
		fileArray->push_back(fileItem);
	}

	/* �Ʒ� if�� ������ false�� ���� ���� ���� �� �����ϰ� ���� */
 	if (getDocType() != BORA_DOCTYPE_PPT && getDocType() != BORA_DOCTYPE_PPTX &&
		fileStatue == PO_FILE_OPEN && 
		g_pBInterfaceHandle->getQBKPathName() &&
		0 == strcmp(g_pBInterfaceHandle->getQBKPathName(), strFileName) && 
		0 != openMode.compare("r") && 
		0 != openMode.compare("rb")) //only wb qbk file
 	{
			if(qbkFile)
			{
				if(qbkFile->filePathName && 0 == strcmp(qbkFile->filePathName, strFileName) && 0 == openMode.compare(qbkFile->fileOpenMode) )
					return BrTRUE;
				else
				{
					BrSysFree(qbkFile->filePathName);
					qbkFile->filePathName = BrNULL;
					qbkFile->fp = BrNULL;
					memset(qbkFile->fileOpenMode, 0, FILE_OPEN_MODE_SIZE);
					qbkFile->fs = file_status::PO_FILE_NONE;
				}
			}
			else
				qbkFile = (PoFileInfo*)BrSysCalloc(sizeof(PoFileInfo), 1);

			setData(qbkFile, strFileName, filePointer, fileStatue, strOpenMode);
 	}

	return BrTRUE;
}

bool PoFileManager::setData(PoFileInfo* fileInfo, const char* fileName, void* filePointer, const file_status& fileStatus, const char* openMode)
{
	if(!fileInfo || !fileName || !filePointer)
		return BrFALSE;

	BrSysFree(fileInfo->filePathName);
	int namaLen  = strlen(fileName);
	fileInfo->filePathName = (char*)BrSysCalloc(namaLen + 1, sizeof(char));
	memset(fileInfo->filePathName, 0, namaLen + 1);
	strncpy_s(fileInfo->filePathName, namaLen+1, fileName, namaLen);
	if(openMode)
	{
		BrINT32 openModeLen = strlen(openMode) >= 4 ? 3 : strlen(openMode);
		memset(fileInfo->fileOpenMode, 0, FILE_OPEN_MODE_SIZE);
		strncpy_s(fileInfo->fileOpenMode, FILE_OPEN_MODE_SIZE, openMode, openModeLen);
	}
	fileInfo->fs = fileStatus;
	fileInfo->fp = filePointer;

	return BrTRUE;
}

bool PoFileManager::oleFileRegister(const BString& fileName, const BString& partName)
{
	if(fileName.length() == 0 || partName.length() == 0)
		return BrFALSE;

	std::vector<PoOleFileData*>::iterator it;
	BrBOOL findFile = BrFALSE;

	BrAutoChar tmpFile = CUtil::convertBStringToChar(&fileName, CP_UTF8);
	char* strFileName = (char*)tmpFile.get();
	BrAutoChar tmpPart = CUtil::convertBStringToChar(&partName, CP_UTF8);
	char* strPartName = (char*)tmpPart.get();	

	for (it = oleFileArray.begin(); it < oleFileArray.end(); it++)
	{
		if(*it == BrNULL)
			return BrFALSE;

		PoOleFileData* oleItem = *it;
		if ( 0 == strcmp(strFileName, oleItem->fileName) && 0 == strcmp(strPartName, oleItem->partName) )
		{
			findFile = BrTRUE;
			break;
		}		
	}

	if(findFile == BrFALSE)
	{
		PoOleFileData* oleItem = (PoOleFileData*)BrSysCalloc(sizeof(PoOleFileData), 1);
		int namaLen  = strlen(strFileName);
		oleItem->fileName = (char*)BrSysCalloc(namaLen + 1, sizeof(char));
		memset(oleItem->fileName, 0, namaLen + 1);
		strncpy_s(oleItem->fileName, namaLen+1, fileName, namaLen);

		int partLen = strlen(strPartName);
		oleItem->partName = (char*)BrSysCalloc(partLen + 1, sizeof(char));
		memset(oleItem->partName, 0, partLen + 1);
		strncpy_s(oleItem->partName, partLen + 1, strPartName, partLen);

		oleFileArray.push_back(oleItem);
	}

	return BrTRUE;
}

bool PoFileManager::hasSavedOle(const BString& fileName, const BString& partName)
{
	std::vector<PoOleFileData*>::iterator it;
	BrBOOL findFile = BrFALSE;

	BrAutoChar tmpFile = CUtil::convertBStringToChar(&fileName, CP_UTF8);
	char* strFileName = (char*)tmpFile.get();
	BrAutoChar tmpPart = CUtil::convertBStringToChar(&partName, CP_UTF8);
	char* strPartName = (char*)tmpPart.get();	

	for (it = oleFileArray.begin(); it < oleFileArray.end(); it++)
	{
		if(*it == BrNULL)
			return BrFALSE;

		PoOleFileData* oleItem = *it;
		if ( 0 == strcmp(strFileName, oleItem->fileName) && 0 == strcmp(strPartName, oleItem->partName) )
		{
			findFile = BrTRUE;
			break;
		}		
	}

	return findFile;
}

bool PoFileManager::releaseAllData()
{
	PoFileInfoArray::iterator it;
	for (it = fileInfoArray.begin(); it != fileInfoArray.end(); it++)
	{
		PoFileInfo* fileItem = *it;
		if (fileItem->filePathName)
			BrSysFree(fileItem->filePathName);
		if (fileItem->olePartName)
			BrSysFree(fileItem->olePartName);
		BrSysFree(fileItem);
	}
	fileInfoArray.resize(0);
	releaseDocumentScopeRangeData();
	return BrTRUE;
}

bool PoFileManager::releaseDocumentScopeRangeData()
{
	PoFileInfoArray::iterator it;
	for(it = fileInfoArray.begin(); it != fileInfoArray.end(); )
	{
		PoFileInfo* fileItem = *it;
		if (!fileItem->fontFile)
		{
			if (fileItem->filePathName)
				BrSysFree(fileItem->filePathName);
			if (fileItem->olePartName)
				BrSysFree(fileItem->olePartName);
			BrSysFree(fileItem);
			it = fileInfoArray.erase(it);
		}
		else
			++it;
	}
	//fileInfoArray.resize(0);
	std::vector<PoOleFileData*>::iterator oleIt;
	for(oleIt = oleFileArray.begin(); oleIt != oleFileArray.end(); oleIt++)
	{
		PoOleFileData* oleItem = *oleIt;
		if(oleItem->fileName)
			BrSysFree(oleItem->fileName);
		if(oleItem->partName)
			BrSysFree(oleItem->partName);
		BrSysFree(oleItem);
	}
	oleFileArray.resize(0);
	BrSysFree(qbkFile);
	qbkFile = BrNULL;
	return BrTRUE;
}

bool PoFileManager::getFileInfo(PoFileInfo** fileInfoList, int fileInfoListSize)
{
	if(!fileInfoList || fileInfoListSize == 0)
		return SetErrorFReturn(CPublicError(kPoErrArgumentNull));

	int listcount = BrMIN(fileInfoListSize, fileInfoArray.size());
	for (int n=0;n<listcount;n++)
	{
		PoFileInfo* fileItem = (PoFileInfo*)fileInfoArray.at(n);
		fileInfoList[n] = (PoFileInfo*)calloc(1, sizeof(PoFileInfo));
		if ( fileInfoList[n] )
		{
			int nameLen = strlen(fileItem->filePathName);
			if (nameLen > 0)
			{
			fileInfoList[n]->filePathName = (char*)calloc(nameLen + 1, sizeof(char));
			memset(fileInfoList[n]->filePathName, 0, nameLen + 1);
			memcpy(fileInfoList[n]->filePathName, fileItem->filePathName, nameLen);
			}			
			fileInfoList[n]->fp = fileItem->fp;
			fileInfoList[n]->fs = fileItem->fs;
			int openModeLen = strlen(fileItem->fileOpenMode);
			if (openModeLen)
			{
				memset(fileInfoList[n]->fileOpenMode, 0, FILE_OPEN_MODE_SIZE);
				strncpy_s(fileInfoList[n]->fileOpenMode, FILE_OPEN_MODE_SIZE, fileItem->fileOpenMode, openModeLen);
			}
			fileInfoList[n]->fontFile = fileItem->fontFile;
		}
	}

	return BrTRUE;
}

void* PoFileManager::getQBKfileHandle(const char* qbkPathName, const char* qbkOpenMode)
{
	//slide�� qbk handling ����
	if (getDocType() == BORA_DOCTYPE_PPT || getDocType() == BORA_DOCTYPE_PPTX)
		return BrNULL;

	//file���� ���� ��� ���� qbk ���� �ڵ��� ���� ������ �����Ѵ�.
	if(!qbkPathName)
	{
		SetErrorFReturn(CPublicError(kPoErrArgumentNull));
		return BrNULL;
	}

	void* fileHandle = BrNULL;

	if(qbkFile )
	{
		if(!qbkOpenMode)
			fileHandle = qbkFile->fp;   // file close�ϴ� ���
		else
		{
			if(qbkFile->filePathName && 0 == strcmp(qbkFile->filePathName, qbkPathName))
			{
				if(0 == strcmp(qbkOpenMode, qbkFile->fileOpenMode))
				{
					fileHandle = qbkFile->fp; //�ٸ� write ������ open mode�� ��û�� ���		
					BFseek64(qbkFile->fp, 0, 0);
				}
				else
					releaseQBKData(qbkPathName); //open mode�� �ٸ� ��� close �� �ٽ� open
			}
			else
				releaseQBKData(qbkPathName); //qbk file���� �ٸ� ��� close�� �ٽ� open
		}
	}

	return fileHandle;
}

void PoFileManager::releaseQBKData(const BString &qbkPath)
{
	if (getDocType() == BORA_DOCTYPE_PPTX || getDocType() == BORA_DOCTYPE_PPT)
		return;

	if(qbkPath.length() == 0)
		return;
	BrAutoChar tmpPart = CUtil::convertBStringToChar(&qbkPath, CP_UTF8);
	char* qbkName = (char*)tmpPart.get();	

	if(qbkFile && qbkFile->filePathName && 0 == strcmp(qbkFile->filePathName, qbkName))
	{
		BrINT ret = BFclose((void*)qbkFile->fp);
		if(qbkFile->filePathName)
			BrSysFree(qbkFile->filePathName);
		memset(qbkFile, 0, sizeof(PoFileInfo));
	}
}

void PoFileManager::QBKFlush()
{
	if (getDocType() == BORA_DOCTYPE_PPTX || getDocType() == BORA_DOCTYPE_PPT)
		return;

	if(qbkFile && qbkFile->filePathName)
		BFflush(qbkFile->fp);
}

bool PoFileManager::isStoredQbkFile(void* filePointer)
{
	if (getDocType() == BORA_DOCTYPE_PPTX || getDocType() == BORA_DOCTYPE_PPT)
		return BrFALSE;

	if(!filePointer)
		return BrFALSE;

	if(qbkFile && filePointer == qbkFile->fp)
		return BrTRUE;

	return BrFALSE;
}


BFile* PoFileManager::getDocument()
{
	return document;
}
void PoFileManager::setDocument(bool bOpen)
{
	BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
	BR_SAFE_DELETE(document);
	if (bOpen)
	{
		document = BrNEW BFile();
		BrBOOL bRet = document->Open(CUtil::UTF8ToBString(getDocFileName()), "rb");
		if (bRet)
		{
			BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
			document->MakeMemoryFile();
		}
	}
}
void PoFileManager::setDocumentByMemory(bool bOpen, char* pBuffer, int nBufferSize)
{
	BR_SAFE_DELETE(document);
	if (bOpen)
	{
		document = BrNEW BFile();
		document->MemoryOpen(CUtil::UTF8ToBString(getDocFileName()), pBuffer, nBufferSize);
	}
}

BFile* PoFileManager::getThemeFile()
{
	return themeFile;
}
void PoFileManager::setThemeFile(const char* pPath)
{
	BR_SAFE_DELETE(themeFile);
	if (pPath && strcmp(pPath, ""))
	{
		BString filename = CUtil::UTF8ToBString(pPath);
		if (BFile::Exist(filename))
		{
			themeFile = BrNEW BFile();
			BrBOOL bRet = themeFile->Open(filename, "rb");
			if (bRet)
			{
				themeFile->MakeMemoryFile();
			}
		}
	}
}

BFile* PoFileManager::getDecryptedFile()
{
	return decryptedFile;
}
void PoFileManager::makeDecryptedFile(const char* pPath)
{
	BR_SAFE_DELETE(decryptedFile);
	if (pPath && strcmp(pPath, ""))
	{
		BString filename = CUtil::UTF8ToBString(pPath);
		decryptedFile = BrNEW BFile();
		BrBOOL bRet = decryptedFile->Open(filename, "wb");
		if (bRet)
		{
			decryptedFile->MakeMemoryFile();
		}
	}
}

int PoFileManager::closeDecryptedFile()
{
	int ret = 0;
	if(decryptedFile)
		ret = decryptedFile->Close();
	BR_SAFE_DELETE(decryptedFile);
	return ret;
}
