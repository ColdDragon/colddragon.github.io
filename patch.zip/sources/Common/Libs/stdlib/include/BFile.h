#ifndef __BFILE_H
#define __BFILE_H

#include "../types_i/PoDefines_i.h"
#include "bmvstring.h"

#define BFILE_BEGIN		0
#define BFILE_CURRENT	1
#define BFILE_END		2

#define ST_INT_MEM	0
#define ST_EXT_MEM	1

typedef enum {
	F_EPERM = 1,
	F_ENOENT,
	F_ESRCH,
	F_EINTR,
	F_EIO,
	F_ENXIO,
	F_E2BIG,
	F_ENOEXEC,
	F_EBADF,
	F_ECHILD,
	F_EAGAIN,
	F_ENOMEM,
	F_EACCES,
	F_EFAULT,
	F_EBUSY = 16,
	F_EEXIST,
	F_EXDEV,
	F_ENODEV,
	F_ENOTDIR,
	F_EISDIR,
	F_EINVAL,
	F_ENFILE,
	F_EMFILE,
	F_ENOTTY,
	F_EFBIG = 27,
	F_ENOSPC,
	F_ESPIPE,
	F_EROFS,
	F_EMLINK,
	F_EPIPE,
	F_EDOM,
	F_ERANGE,
	F_EDEADLK = 36,
	//F_EDEADLOCK,
	F_ENAMETOOLONG = 38,
	F_ENOLCK,
	F_ENOSYS,
	F_ENOTEMPTY,
	F_EILSEQ,
	F_STRUNCATE = 80,

}ERRNO_SYS_ERRLIST;

/*	file I/O wrapper class 
	based CFile class(MFC)
*/

class MemoryFile;
class PO_EXPORT_API BFile : public BrBase
{
public:
	BFile( );	
	BFile(const BFile* hFile);
	~BFile(void);

public:
	const BString& getName() const;

	BrBOOL		MemoryOpen(const BString& strFileName, void* pBuffer, int nBufferSize);
	BrBOOL		Open(const BString &strPathName, const BString &openMode, BrBYTE nExtType = 0, BrBOOL bDRMOpen = BrFALSE, BrBOOL bMCoreZip = BrFALSE);	
	BrINT		Close();

	BrINT32		Read(void *bufP, BrUINT32 numBytes);
	BrINT32		Write(const void *dataP, BrUINT32 numBytes);

	BrBOOL		Seek(BrINT64 offset = 0, UINT16 position = BFILE_CURRENT);
	BrBOOL		SeekToBegin();
	BrBOOL		SeekToEnd();
	
	void		setManualFlush( bool a_bManualFlush) ;
	void		flush();
	BrUINT64	Size();
	BrINT64		Tell();

	static BrSIZE_T	Size(const BString& path);
	static PoError	Rename(const BString &strPathName, const BString &strNewName);
	static PoError	Remove(const BString &strPathName);
	static PoError	ReplaceFile(const BString& strPathName, const BString& strNewName);

	BrBOOL Remove();

	static BString ConvertFilePath(const BString &pSrcPath);
	static BrBOOL CompareFilePath(const BString &pOrgPath, const BString &pCmpPath, BrBOOL bFind=BrFALSE);
	static PoError PoBufferCopyFile(const BString &pExistingFileName, const BString &pNewFileName);
	static BrBOOL Exist(const BString &pSrcPath);

	BrBYTE	GetTypeFlag();

	static PoError  PackagingFile(const BString &strSrcPath, const BString &strDstPath, BrLPVOID pEvent);
	static PoError  CreateDRMFile(const BString &strSrcPath, const BString &strDstPath, BrBOOL isTempSave);
	static PoError  SaveFinalFile(const BString &strSrcPath, const BString &strDstPath, BrBOOL bRemoveSrcFile = BrTRUE, int nOptimizeSave = 0);

	static BString getNotExistFileName(BString strFileName);

	bool isTempPath();
	static BrBOOL isTempPath(BString strPath);
#ifdef _WIN32
	static BrBOOL SetPolarisTimeSignature(FILETIME* lpFileTime, int nSigIndex);
	static BrINT32 GetPolarisTimeSignature(const BString &strSrcPath);
#endif

	BrINT32 GetSystemErrorNo();
	void MakeMemoryFile(BrBOOL bWriteMode = BrFALSE);

	static BrBOOL		CheckBInaryEncryptionHeader(const void* pBuffer, int nCheckSize = 8);
	static void			AddBInaryEncryptionHeader(const BString& a_sFileName);

private:
	BrINT32		       CheckFileError();
	static PoError     SetFileHidden(const BString& filePathName);
	static PoError     SetFileUnHidden(const BString& filePathName);
	static PoError     TryTmpFileRename(const BString& targetFilePathName, const BString& tmpFilePathName); //target folder�� .tmp������ ���� �� ���� movefileEx ���� �� qbk�� rename�ϴ� �Լ�
	
	BrBOOL shareMemoryFile(MemoryFile* a_pMemoryFIle);
	void* encryptBuffer(const void* a_dataP, BrUINT32 numBytes);
	void decryptBuffer(void* a_bufP, BrUINT32 numBytes);
	void setFilePath(const BString& filePath);
	BrBOOL CheckReservedFile(const BString& strFileName);	
	bool IsEncryptableState();

private:
	BrLPBORAFILEINFO	m_pFile;	
	BString				m_strFileName;
	BrINT32				m_nErrno;
	MemoryFile*			m_pMemoryFile;
	int					m_nExtType;
	bool				m_bBinaryFormat;
	bool				m_bXmlFormat;
	bool				m_bSaveBackupFormat;//.qbk, .qpk
	bool				m_bInTempPath;
	bool				m_bEncryptableState;	//enable encyrpt, decrypt

private:
	static BrBYTE		m_ucBinaryEncryptionHeader[8];
	//BrCHAR				m_szEncryptionPassword[32 + 1];

public:
	static BrBYTE*		getBinaryEncryptionHeader();
	static int			getBinaryEncryptionHeaderLength();
	void				checkEncryptionHeader();
	void				setEncryptableState(bool bSet);
	static BrBOOL		IsInTempPath(const BString& filePath);

	static BrBOOL		isSameFileExtension(const char* orignalPath, const char* comparePath);
};


#endif //__BFILE_H