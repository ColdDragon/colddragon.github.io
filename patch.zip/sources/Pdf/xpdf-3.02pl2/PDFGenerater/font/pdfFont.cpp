#include <OfficePreCompPDF.hpp>

#ifdef EXPORT_PDF

#include <stdio.h>
#include <math.h>

#include "BFile.h"
#include "butil.h"
#include "pdfFont.h"

#ifdef fprintf
#undef fprintf
#endif

#define STEM_V_CODE			0x6C
#define CAP_HEIGHT_CODE		0x48
#define TTF_HEADER_SIZE		12		// TTC Header���� offset table�� ������ ũ��

void ReverseBuffer(BrUSHORT* pBuf, BrUSHORT bufLen);

PDFFont::PDFFont()
{
	initMembers();
	// variables for embed font
	m_nGlyphCount = 0;
	m_nEmbedDataSize = 0;
	for (int i=0; i<EMBED_TABLE_COUNT; i++)
	{
		m_pTagTableData[i] = BrNULL;
	}
	m_pOffsetTables = BrNULL;

	m_pUnicodeData = BrNULL;
	m_pFontGlyphData = BrNULL;
	m_pWidths = BrNULL;
	m_eExportTextType = ePDF_TEXT_TYPE_NORMAL;
	m_nEmbed_Table_Count = EMBED_TABLE_COUNT;
	m_pFontFaceName = BrNULL;
}

PDFFont::~PDFFont()
{
	clear();
}

void PDFFont::initMembers()
{
	// Members of structure BrXPDFFontInfo
	memset(m_szFontName, 0, BrSizeOf(m_szFontName));
	m_BBox.top = m_BBox.bottom = m_BBox.left = m_BBox.right = 0;
	m_fontType = eXPDFFontType1;
	m_nFlags = 0;
	m_nAscent = 0;
	m_nDescent = 0;
	m_nAngle = 0;
	m_nCapHeight = 0;
	m_nStemV = 0;
	memset(m_aAnsiWidthArray, 0, BrSizeOf(m_aAnsiWidthArray));
	memset(m_szEncoding, 0, BrSizeOf(m_szEncoding));
	strncpy_s(m_szEncoding, sizeof(m_szEncoding), "WinAnsiEncoding", strlen("WinAnsiEncoding"));

	// Members of structure BrCIDSystemInfo
	memset(m_pszRegistry, 0, BrSizeOf(m_pszRegistry));
	memset(m_pszOrdering, 0, BrSizeOf(m_pszOrdering));
	m_nSupplement = 0;

	// internal variables
	m_pFontData = BrNULL;
	m_pLocaData = BrNULL;
	m_nGlyfSize = 0;
	m_nNumberOfHMetrics = 0;
	m_bIndexToLocFormat = BrFALSE;
	memset(m_aAnsiCodeMap, 0, BrSizeOf(m_aAnsiCodeMap));
	memset(&m_ttMainHeadInfo, 0, BrSizeOf(m_ttMainHeadInfo));
	m_nUnitsPerEm = 1024;

	m_bCFF = BrFALSE;
	vorg = BrNULL;
	cff = BrNULL;
	file.Close();

	m_pFontFileStream.closeFile();
	last_in_Tag = 0;
}

BrBOOL PDFFont::parse(char* szFontPath, BrLONG *nFontFileSize /*= BrNULL*/)
{
	BrINT nRet = 0;
	//[15.12.15][sglee1206] Type ����
	//[16.06.16][sglee1206] Long���� ���� �� ����ó�� �߰�
	BrLONG len;

	initMembers();

	BString strSrcFile = CUtil::UTF8ToBString((char*)szFontPath);
	if(!file.Open(strSrcFile, BMV_READ_ONLY))
		return	BrFALSE;

	len = file.Size();
 	//[coverity][2016.06.16] ftell err���� ���� 
	if(len <= 0)
	{
		file.Close();
		return	BrFALSE;
	}


#ifndef WINDOWS_8
	m_pFontFileStream = PoFileStream(&file, len, true);
#else	//PC������ ��쿡�� ����Ͽ� ���� �޸� ������ �����Ƿ� �޸� �Ҵ��ϵ� �Ҵ� ���нÿ��� ���Ϸ� ó��
	m_pFontData = (BrBYTE*)BrCalloc(len, sizeof(BrBYTE));
	if (m_pFontData == BrNULL)
	{
		m_pFontFileStream = PoFileStream(&file, len,true);
	}
	else
	{
		nRet = file.Read(m_pFontData, len);
		//[15.12.15][sglee1206] ����ó�� �߰�
		if (nRet == 0)
		{
			BR_SAFE_FREE(m_pFontData);
			return	BrFALSE;
		}

		m_pFontStream = PoStream(m_pFontData, len);
	}
	
#endif

	return loadEmbedData(nFontFileSize);

}
bool g_bShowMsgFont = false;
BrBOOL PDFFont::loadEmbedData(BrLONG *nFontFileSize /*= BrNULL*/)
{
	if ( !g_bShowMsgFont ) BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
	
	BrBOOL ret = BrTRUE;
	ret = loadTtfTags();
	if (nFontFileSize != BrNULL)
	{
		*nFontFileSize = m_nEmbedDataSize;
	}
if ( !g_bShowMsgFont ) {
	g_bShowMsgFont=true;
	BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
}
	if( FALSE == ret)
		return	BrFALSE;

	return	ret;
}

BrBOOL PDFFont::parseMem(void* pData, BrLONG nSize)
{
	if ( !g_bShowMsgFont ) BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
	
	if( !pData || nSize == 0 )
	{
		if ( !g_bShowMsgFont ) {
			g_bShowMsgFont=true;
			BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
		}
		return BrFALSE;
	}

	BrBOOL ret = BrTRUE;

	initMembers();
if ( !g_bShowMsgFont ) BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
	
	m_pFontData = (BrBYTE*) BrCalloc(nSize, sizeof(BrBYTE));
	if (m_pFontData == BrNULL)
	{
		if ( !g_bShowMsgFont ) {
			g_bShowMsgFont=true;
			BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
		}
		return	BrFALSE;
	}
if ( !g_bShowMsgFont ) BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
	
	memcpy(m_pFontData, pData, nSize);
	m_pFontStream = PoStream(m_pFontData, nSize);
if ( !g_bShowMsgFont ) {
	// g_bShowMsgFont=true;
	BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
}
	return loadEmbedData(BrNULL);
}

void PDFFont::clear()
{
	BR_SAFE_FREE(m_pFontData);
	BR_SAFE_FREE(m_pOffsetTables);
	
	for (int i=0; i<EMBED_TABLE_COUNT; i++)
		BR_SAFE_FREE(m_pTagTableData[i]);

	BR_SAFE_FREE(m_pUnicodeData);
	BR_SAFE_FREE(m_pFontGlyphData);
	BR_SAFE_FREE(m_pWidths);
	BR_SAFE_FREE(m_pFontFaceName);
	
	BR_SAFE_DELETE(cff);
	initMembers();
}

//[14.05.13][sglee1206] �Ϻ� ���� �ʿ�
BrBOOL PDFFont::getFontInfo(BrXPDFFontInfo* pFontInfo)
{
	BrBOOL ret = BrTRUE;
	XRect sBBox = getBBox();
	pFontInfo->sBBox.left = sBBox.left;
	pFontInfo->sBBox.top = sBBox.top;
	pFontInfo->sBBox.right = sBBox.right;
	pFontInfo->sBBox.bottom = sBBox.bottom;
	pFontInfo->nFlags = m_nFlags;
	pFontInfo->nAscent = m_nAscent;
	pFontInfo->nDescent = m_nDescent;
	pFontInfo->nAngle = m_nAngle;	
	pFontInfo->nCapHeight = m_nCapHeight;
	pFontInfo->nStemV = m_nStemV;
	
	pFontInfo->bCFF = m_bCFF;
	if(m_bCFF)
		pFontInfo->nType = eXPDFCIDFontType0;
	else
		pFontInfo->nType = eXPDFCIDFontType2;
	
	//BrStrCpy(pFontInfo->szFaceName,m_szFontName,MAX_FONT_LEN);
	if(m_eExportTextType == ePDF_TEXT_TYPE_UCS4)
		strncat_s(pFontInfo->szFaceName, sizeof(pFontInfo->szFaceName), "-UCS4", strlen("-UCS4"));
	//[14.07.03][sglee1206] sCodeTable dummy
	//PDFExportTextData::makeExportData()���� ��ó����
	{
		pFontInfo->sCodeTable.nLen = 0;
		pFontInfo->sCodeTable.nDefWidth = -1;
		pFontInfo->sCodeTable.pData = BrNULL;
	}
	
	return ret;
}

BrULONG CalcTableChecksum(BrBYTE *tableData, BrULONG length)
{
	BrINT nLongs = (length + (sizeof(BrULONG)-1)) / sizeof(BrULONG);
	BrULONG Sum = 0;
	BrULONG *Table = (BrULONG*)tableData; 
	BrINT nCount = 0;
	BrULONG temp = 0;
	BrDWORD yyyy = 0x4C2F8486;
	while (nLongs-- > 0) {
		if ( !nLongs && (nCount+1)*sizeof(BrULONG) != length )
		{
			int nSize = sizeof(BrULONG) - ((nCount+1)*sizeof(BrULONG) - length);
			temp = 0;
			memcpy(&temp, &Table[nCount], nSize);
		}
		else
			temp = Table[nCount];

		Sum += SWAPLONG(temp);
		nCount++;
	}
	return Sum;
}

//BrULONG	CalcTableChecksum(
//						  BrBYTE		*ipTable,
//						  BrULONG				ilLength)
//{
//	BrULONG		theSum = 0L;
//	BrDWORD	theFullByte, theTemp = 0, theRemainByte;
//
//	theFullByte = ilLength / BrSizeOf(BrULONG);
//	theRemainByte = ilLength - theFullByte * 4;
//
//	BrULONG* pData = (BrULONG*)ipTable;
//
//	for( BrDWORD i = 0; i < theFullByte; i++)
//		theSum += SWAPLONG( *pData++ );
//	if( theRemainByte)	{
//		memcpy( &theTemp, (void*) pData, theRemainByte);
//		theSum += theTemp;
//	}
//	return theSum;
//}

BrBOOL PDFFont::generateEmbedFontInfo(BrBYTE *pEmbedFontData)
{
	if( !pEmbedFontData )
		return BrFALSE;

	BrBOOL errRet = true;
	BrUSHORT searchRange = 1;
	BrUSHORT entrySelector = 0;
	while(searchRange <= m_nEmbed_Table_Count)
	{
		searchRange = searchRange<<1;
		entrySelector = entrySelector+1;
	}
	searchRange = searchRange>>1;
	entrySelector = entrySelector -1;
	m_ttMainHeadInfo.version = SWAPLONG(m_ttMainHeadInfo.version);
	m_ttMainHeadInfo.numTables = SWAPBrWORD(m_nEmbed_Table_Count);
	
	m_ttMainHeadInfo.searchRange = SWAPBrWORD(searchRange * 16);
	m_ttMainHeadInfo.entrySelector = SWAPBrWORD(entrySelector);
	m_ttMainHeadInfo.rangeShift = SWAPBrWORD(SWAPBrWORD(m_ttMainHeadInfo.numTables) * 16 - SWAPBrWORD(m_ttMainHeadInfo.searchRange));

// ������ check�ϰ� �ֱ� ������ �ϱ� ��ƾ�� ���� �ȵ�.
//	if (pEmbedFontData == BrNULL)
//	{
//		pEmbedFontData = (BrBYTE*)BrMalloc(m_nEmbedDataSize);

//		if (pEmbedFontData == BrNULL)
//		{
//			SET_ERROR((PoError)kPoErrMemory, "");
//			return BrFALSE;
//		}

//		memset(pEmbedFontData, 0, m_nEmbedDataSize);
//	}

	BrDWORD offset = 0, deltaByte;
	BrDWORD checkSumAdjustment = 0;
	BrBYTE *checkSumField = BrNULL;	//[14.05.09][sglee1206]	Coverity... Uninitialize

	memcpy(pEmbedFontData, &m_ttMainHeadInfo, TTF_HEADER_SIZE);
	offset += TTF_HEADER_SIZE;

	for(int i=0; i< EMBED_TABLE_COUNT; i++)
	{
		if(m_pTagTableData[i] == BrNULL)
			continue;

		memcpy(pEmbedFontData+offset, (m_pOffsetTables+i), BrSizeOf(TTableDir));
		offset += BrSizeOf(TTableDir);
	}

	for(int i=0; i< EMBED_TABLE_COUNT; i++)
	{
		if(m_pTagTableData[i] == BrNULL)
			continue;

		if (i == eTable_head)  // head table
		{
			checkSumField = pEmbedFontData + offset + 8; // offset of checkSumAdjustment field
		}
		memcpy(pEmbedFontData+offset, m_pTagTableData[i], SWAPLONG(m_pOffsetTables[i].length));
		offset += SWAPLONG(m_pOffsetTables[i].length);

		// 4byte ���߱�
		deltaByte = SWAPLONG(m_pOffsetTables[i].length) % 4;
		if (deltaByte == 1)
		{
			deltaByte += 2;
		}
		offset += deltaByte;
	}

	// head table�� checkSumAdjustment ����
	BrDWORD checkTop = 0xB1B0AFBA;
	checkSumAdjustment = CalcTableChecksum(pEmbedFontData, m_nEmbedDataSize);
	checkSumAdjustment = SWAPLONG(checkTop - checkSumAdjustment);
	
	//[14.05.09][sglee1206]	Coverity... Using uninitialized pointer checkSumField
	if(checkSumField)
		memcpy(checkSumField, &checkSumAdjustment, 4);

	return errRet;
}

BrBOOL PDFFont::loadTtfTags()
{
	if ( !g_bShowMsgFont ) BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
	
	BrBOOL ret = BrTRUE;

	BrLONG	ver = 0;
	
	if(m_pFontFileStream.hasFile())
		m_pFontFileStream >> ver;
	else
		m_pFontStream >> ver;
	//readData(&ver, 0, BrSizeOf(BrLONG));

	BrLONG	theOffset = 0;
	BrLONG	fontCount = 0;
	ver = SWAPLONG(ver);
if ( !g_bShowMsgFont ) BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
		
	if ( ver != TT_STANDARD_VERSION )
	{
		if(ver == OTF_STANDARD_VERSION)
		{
			m_fontType = eXPDFFontOpenType;
		}
		else if( ver == TAG_ID_TTC)
		{
			if (m_pFontFileStream.hasFile())
			{
				m_pFontFileStream.setPos(8);
				m_pFontFileStream >> fontCount;
			}
			else
			{
				m_pFontStream.setPos(8);
				m_pFontStream >> fontCount;
			}
			//readData(&fontCount, 8, BrSizeOf(BrLONG));
			fontCount = SWAPLONG(fontCount);
		}
		else
		{
			m_fontType = exPDFNoneFont;
			if ( !g_bShowMsgFont ) BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
	
			return BrFALSE;
		}
	}

	// Read the main header info.
	if(ver == TAG_ID_TTC)
	{
		if ( !g_bShowMsgFont ) BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
	
		for(int i = 0; i < fontCount; i++)
		{
			if (m_pFontFileStream.hasFile())
			{
				m_pFontFileStream.setPos(12 + 4 * i);
				m_pFontFileStream >> theOffset;
			}
			else
			{
				m_pFontStream.setPos(12 + 4 * i);
				m_pFontStream >> theOffset;
			}

			//readData(&theOffset, 12+4*i, BrSizeOf(BrLONG));
			theOffset = SWAPLONG(theOffset);

			ret = getTtfHeadInfo( theOffset);
			if (ret  == BrFALSE )
			{
				if ( !g_bShowMsgFont ) BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
	
				return ret;
			}
			
			BrBYTE const * nameData = BrNULL;
			BrLONG dataLen = 0;
			BrBOOL bOk = BrTRUE;

			nameData = (BrBYTE const *)getTtfTagInfo(TAG_ID_NAME, dataLen);
			if (nameData == BrNULL)
			{
				if ( !g_bShowMsgFont ) BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
				return BrFALSE;
			}

			bOk = readFontName(nameData);
			nameData = BrNULL;

			//SubSet Len : 7
			if(bOk && BrStrLen(m_pFontFaceName) > 7 && strcmp(m_szFontName,m_pFontFaceName+7) == 0)
			{
				if ( !g_bShowMsgFont ) BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
	
				//BTrace("%s",m_szFontName);
				break;
			}
			BrFree(m_pOffsetTables);
			m_pOffsetTables = BrNULL;
		}
	}

if ( !g_bShowMsgFont ) BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
	
	if( m_pOffsetTables == BrNULL)
	{
		ret = getTtfHeadInfo( theOffset);
		if (ret  == BrFALSE )
		{if ( !g_bShowMsgFont ) BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
			return ret;
		}
	}
	
	// Common tags
	ret = loadMaxpTag();		// 'maxp' tag
	if (ret == BrFALSE)
	{
		if ( !g_bShowMsgFont ) BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
		return ret;
	}
		
	
	ret = loadCmapTag();		// 'cmap' tag
	if (ret == BrFALSE)
	{
		if ( !g_bShowMsgFont ) BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
		return ret;
	}

	ret = loadPostTag();		// 'post' tag
	if (ret == BrFALSE)
	{
		if ( !g_bShowMsgFont ) BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
		return ret;
	}

	ret = loadHeadTag();		// 'head' tag
	if (ret == BrFALSE)
	{
		if ( !g_bShowMsgFont ) BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
		return ret;
	}
	
	ret = loadNameTag();		// 'name' tag
	if (ret == BrFALSE)
	{
		if ( !g_bShowMsgFont ) BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
		return ret;
	}
	
	ret = loadLocaTag();		// 'loca' tag
	if (ret == BrFALSE)
	{
		if (eXPDFFontOpenType != m_fontType)
		{
			if ( !g_bShowMsgFont ) BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
			return ret;
		}
	}

	ret = loadGlyfTag();		// 'glyf' tag
	if (ret == BrFALSE)
	{
		if(m_fontType == eXPDFFontOpenType)
		{
			ret = loadCFFTag();
			if (ret == BrFALSE)
			{
				if ( !g_bShowMsgFont ) BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
				return ret;
			}
			m_bCFF = BrTRUE;
		}
		else
		{
			if ( !g_bShowMsgFont ) BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
			return ret;
		}

	}

	ret = loadHheaTag();		// 'hhea' tag
	if (ret == BrFALSE)
	{
		if ( !g_bShowMsgFont ) BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
		return ret;
	}

	ret = loadHmtxTag();		// 'hmtx' tag
	if (ret == BrFALSE)
	{
		if ( !g_bShowMsgFont ) BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
		return ret;
	}

	ret = loadOS2Tag();			// 'OS/2' tag

	if ( ePDF_TEXT_TYPE_NORMAL <m_eExportTextType && m_eExportTextType < ePDF_TEXT_TYPE_MAX)
	{
		ret = loadOtherTags();
		if (ret == BrFalse)
		{
			if ( !g_bShowMsgFont ) BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
			return ret;
		}
	}
	if ( !g_bShowMsgFont ) BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
	return ret;
}
BrBOOL PDFFont::getTtfHeadInfo(BrLONG il_Offset)
{
	if ( !g_bShowMsgFont ) BTrace("%s(%d) %s il_Offset[0x%x]", __FILE__, __LINE__, __FUNCTION__, il_Offset);
	if (m_pFontFileStream.hasFile())
	{
		m_pFontFileStream.setPos(il_Offset);
		m_pFontFileStream.read(&m_ttMainHeadInfo, BrSizeOf(m_ttMainHeadInfo));
	}
	else
	{
		m_pFontStream.setPos(il_Offset);
		m_pFontStream.read(&m_ttMainHeadInfo, BrSizeOf(m_ttMainHeadInfo));
	}

	//readData( &m_ttMainHeadInfo, il_Offset, BrSizeOf(m_ttMainHeadInfo));
	BrWORD	numTag = SWAPBrWORD(m_ttMainHeadInfo.numTables);
	if ( !g_bShowMsgFont ) BTrace("%s(%d) %s m_ttMainHeadInfo.numTables[0x%x]", __FILE__, __LINE__, __FUNCTION__, m_ttMainHeadInfo.numTables);
	#ifdef __sparc__
		numTag = m_ttMainHeadInfo.numTables;
	#endif
	if ( !g_bShowMsgFont ) BTrace("%s(%d) %s numTag[0x%x]", __FILE__, __LINE__, __FUNCTION__, numTag);
	if( numTag > TT_MAX_TAGS)
	{
		if ( !g_bShowMsgFont ) BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
		return	BrFALSE;
	}

	BrLONG	ver = 0;
	BrLONG	fontCount = 0;
	if (m_pFontFileStream.hasFile())
	{
		m_pFontFileStream.setPos(il_Offset);
		m_pFontFileStream >> ver;
	}
	else
	{
		m_pFontStream.setPos(il_Offset);
		m_pFontStream >> ver;
	}

	//readData(&ver, il_Offset, BrSizeOf(BrLONG));
	ver = SWAPLONG(ver);
	if ( !g_bShowMsgFont ) BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
	if ( ver != TT_STANDARD_VERSION )
	{
		if(ver == OTF_STANDARD_VERSION)
		{
			m_fontType = eXPDFFontOpenType;
			BTrace("This Font is OTF Collection(OTC)");
		}
		//[15.11.24][sglee1206] ����� ������ �� ������ ���� �ڵ�� ���ϼ��� �����ϱ� ���� �ۼ���
		else if( ver == TAG_ID_TTC)
		{
			if (m_pFontFileStream.hasFile())
			{
				m_pFontFileStream.setPos(il_Offset + 8);
				m_pFontFileStream >> fontCount;
			}
			else
			{
				m_pFontStream.setPos(il_Offset + 8);
				m_pFontStream >> fontCount;
			}
			//readData(&fontCount, il_Offset+8, BrSizeOf(BrLONG));
			fontCount = SWAPLONG(fontCount);
		}
		else
		{
			m_fontType = exPDFNoneFont;
			BTrace("ver : 0x%x",ver);
			return BrFALSE;
		}
	}

	m_ttMainHeadInfo.searchRange	= SWAPBrWORD( m_ttMainHeadInfo.searchRange);
	m_ttMainHeadInfo.entrySelector	= SWAPBrWORD( m_ttMainHeadInfo.entrySelector);
	m_ttMainHeadInfo.rangeShift		= SWAPBrWORD( m_ttMainHeadInfo.rangeShift);
	m_ttMainHeadInfo.version		= SWAPLONG( m_ttMainHeadInfo.version);
	m_ttMainHeadInfo.numTables		= SWAPBrWORD( m_ttMainHeadInfo.numTables);
	for(int i = 0; i < numTag; i++)	{
		m_ttMainHeadInfo.tables[i].tag		= SWAPLONG( m_ttMainHeadInfo.tables[i].tag);
		m_ttMainHeadInfo.tables[i].checkSum	= SWAPLONG( m_ttMainHeadInfo.tables[i].checkSum);
		m_ttMainHeadInfo.tables[i].offset	= SWAPLONG( m_ttMainHeadInfo.tables[i].offset);
		m_ttMainHeadInfo.tables[i].length	= SWAPLONG( m_ttMainHeadInfo.tables[i].length);
	}
	BrINT removeTableCount = 0;

	if(m_fontType != eXPDFFontOpenType)
		removeTableCount = eTable_MAX - eTable_CFF;

	m_pOffsetTables = (TTableDir*)BrCalloc((EMBED_TABLE_COUNT-removeTableCount), BrSizeOf(TTableDir));
	m_pData = PoStream(m_pOffsetTables, (EMBED_TABLE_COUNT-removeTableCount)*BrSizeOf(TTableDir));
	m_nEmbedDataSize = TTF_HEADER_SIZE + (EMBED_TABLE_COUNT-removeTableCount)*BrSizeOf(TTableDir);

	return BrTRUE;
}

BrLONG PDFFont::getTtfTagInfoEx(BrLONG in_Tag, void* out_pData, BrLONG in_dataLen)
{
	TTableDir	ttTag;
	BrBOOL bFound = BrFALSE;

	// Search the tag info.
	for( int i = 0; i < m_ttMainHeadInfo.numTables; i++) {
		if ( m_ttMainHeadInfo.tables[i].tag == in_Tag )	{
			ttTag = m_ttMainHeadInfo.tables[i];
			bFound = BrTRUE;
			break;
		}
	}

	if (bFound == BrFALSE)
		return 0;

	// Check the info.
	//if( ttTag.length > in_dataLen)
	//{
	//	return 0;
	//}

	// Load the tag info.
	memset(out_pData, 0, in_dataLen);
	//readData(out_pData, ttTag.offset, in_dataLen);
	if (m_pFontFileStream.hasFile())
	{
		m_pFontFileStream.setPos(ttTag.offset);
		m_pFontFileStream.read(out_pData, in_dataLen);
	}
	else
	{
		m_pFontStream.setPos(ttTag.offset);
		m_pFontStream.read(out_pData, in_dataLen);
	}
	
	return	ttTag.length;
}

void const * const PDFFont::getTtfTagInfo(BrLONG in_Tag, BrLONG& out_dataLen, BrBOOL bDataCpoy, BrBYTE** copyData)
{
	TTableDir	ttTag;
	BrBOOL bFound = BrFALSE;
	void* pData = BrNULL;

	// Search the tag info.
	for( int i = 0; i < m_ttMainHeadInfo.numTables; i++) {
		if ( m_ttMainHeadInfo.tables[i].tag == in_Tag )	{
			ttTag = m_ttMainHeadInfo.tables[i];
			bFound = BrTRUE;
			break;
		}
	}

	if (bFound == BrFALSE)
		return BrNULL;

	// Malloc memory
	out_dataLen = ttTag.length;
#if 0
	pData = BrMalloc(out_dataLen);
	if (pData == BrNULL)
		return BrNULL;
	
	// Load the tag info.
	memset(pData, 0, out_dataLen);
	readData(pData, ttTag.offset, out_dataLen);
#endif
	if (m_pFontFileStream.hasFile())
	{

		if (bDataCpoy)
		{
			BR_SAFE_FREE(*copyData);
			*copyData = (BrBYTE*)BrCalloc(ttTag.length, sizeof(BrBYTE));

			if (*copyData != BrNULL)
			{
				m_pFontFileStream.setPos(ttTag.offset);
				m_pFontFileStream.read(*copyData, ttTag.length, true);
				last_in_Tag = in_Tag;

				return *copyData;
			}
		}
		
		//CMAP Tag ó���� ������ ȣ��ǹǷ� ���ʿ��� free/malloc ���� �ʵ��� ��
		if (last_in_Tag != in_Tag)
		{
			BR_SAFE_FREE(m_pFontData);
			m_pFontData = (BrBYTE*)BrCalloc(ttTag.length, sizeof(BrBYTE));

			if (m_pFontData != BrNULL)
			{
				m_pFontFileStream.setPos(ttTag.offset);
				m_pFontFileStream.read(m_pFontData, ttTag.length, true);
			}
		}
		else
			m_pFontFileStream.setPos(ttTag.offset);

		last_in_Tag = in_Tag;

		return m_pFontData;
	}
	else
	{
		m_pFontStream.setPos(ttTag.offset);

		if (bDataCpoy)
		{
			*copyData = (BrBYTE*)BrMalloc(out_dataLen);

			if (*copyData == BrNULL)
				SET_ERROR((PoError)kPoErrMemory, "");
			else
				memcpy(*copyData, (m_pFontData + ttTag.offset), out_dataLen);
		}
		//return (void*)m_pFontStream.getBuffer();
		return (m_pFontData + ttTag.offset);
	}
}

BrBOOL PDFFont::loadMaxpTag()
{
	BrLONG ret = 0;
	TMaxpTable maxpData;

	ret = getTtfTagInfoEx(TAG_ID_MAXP, &maxpData, BrSizeOf(maxpData));
	if (ret == 0)
		return BrFALSE;

	if ( ePDF_TEXT_TYPE_NORMAL <m_eExportTextType && m_eExportTextType < ePDF_TEXT_TYPE_MAX)
	{
		// Offset Table
		BrULONG tableLength = ret;
		BrUSHORT tempNumGlyphs = maxpData.numGlyphs;
		m_pTagTableData[eTable_maxp] = (BrBYTE*)BrMalloc(tableLength);
		memcpy(m_pTagTableData[eTable_maxp], &maxpData, tableLength);

		m_pData.setPos(eTable_maxp * sizeof(TTableDir));
		m_pData << SWAPLONG(TAG_ID_MAXP);
		BrULONG checkSum = CalcTableChecksum(m_pTagTableData[eTable_maxp], tableLength);
		m_pData << SWAPLONG(checkSum);
		m_pData.movePos(4);
		m_pData << SWAPLONG(tableLength);
		//m_pOffsetTables[eTable_maxp].tag = SWAPLONG(TAG_ID_MAXP);
		//m_pOffsetTables[eTable_maxp].length = SWAPLONG(tableLength);
		/////////////////////////////////////////////////////
		
		
		//maxpData.numGlyphs = tempNumGlyphs;
		m_nEmbedDataSize += tableLength;
	}
	else
		m_nGlyphCount = SWAPBrWORD(maxpData.numGlyphs);

	m_nGlyfSize = SWAPBrWORD(maxpData.numGlyphs);

	return BrTRUE;
}

BrBOOL PDFFont::loadOS2Tag()
{
	BrLONG ret = 0;
	TOs2Table os2Data;
	
	m_nCapHeight = 700;

	ret = getTtfTagInfoEx(TAG_ID_OS2, &os2Data, BrSizeOf(os2Data));
	if (ret == 0)
		return BrFALSE;

	//[16.08.16][sglee1206] OS/2 Table�� �������� �ʾƼ� ���� ó�� �� �����ϴ� ��� ����(iOS ��Ʈ�� ���)
	//�ش� ���� ������
#if 0
	if ( ePDF_TEXT_TYPE_NORMAL <m_eExportTextType && m_eExportTextType < ePDF_TEXT_TYPE_MAX)
	{
		// Offset Table
		BrULONG tableLength = ret;
		m_pOffsetTables[eTable_OS2].tag = SWAPLONG(TAG_ID_OS2);
		m_pOffsetTables[eTable_OS2].length = SWAPLONG(tableLength);
		/////////////////////////////////////////////////////
		m_pTagTableData[eTable_OS2] = (BrBYTE*)BrMalloc(tableLength);
		memcpy(m_pTagTableData[eTable_OS2], &os2Data, tableLength);
		m_pOffsetTables[eTable_OS2].checkSum = SWAPLONG(CalcTableChecksum(m_pTagTableData[eTable_OS2], tableLength));
		m_nEmbedDataSize += tableLength;
	}
#endif

	m_nCapHeight = (BrSHORT)SWAPBrWORD(os2Data.sCapHeight) * 1000 / m_nUnitsPerEm;//500;

	return BrTRUE;
}

BrBOOL PDFFont::loadCmapTag()
{
	BrBOOL ret = BrTRUE;
	BrBYTE const * cmapData = BrNULL;
	BrLONG cmapLen = 0;
	BrBOOL bSymbol = BrFALSE;

	cmapData = (BrBYTE const *)getTtfTagInfo(TAG_ID_CMAP, cmapLen);
	if (cmapData == BrNULL)
		return BrFALSE;

	if ( ePDF_TEXT_TYPE_NORMAL <m_eExportTextType && m_eExportTextType < ePDF_TEXT_TYPE_MAX)
	{
		// Offset Table
		BrULONG tableLength = cmapLen;
		m_pTagTableData[eTable_cmap] = (BrBYTE*)BrMalloc(tableLength);
		if (m_pFontFileStream.hasFile())
			m_pFontFileStream.read(m_pTagTableData[eTable_cmap], tableLength, true);
		else
			m_pFontStream.read(m_pTagTableData[eTable_cmap], tableLength, true);
		//memcpy(m_pTagTableData[eTable_cmap], cmapData, tableLength);		

		m_pData.setPos(eTable_cmap * sizeof(TTableDir));
		m_pData << SWAPLONG(TAG_ID_CMAP);
		BrULONG checkSum = CalcTableChecksum(m_pTagTableData[eTable_cmap], tableLength);
		m_pData << SWAPLONG(checkSum);
		m_pData.movePos(4);
		m_pData << SWAPLONG(tableLength);
		//m_pOffsetTables[eTable_cmap].tag = SWAPLONG(TAG_ID_CMAP);
		//m_pOffsetTables[eTable_cmap].length = SWAPLONG(tableLength);
		/////////////////////////////////////////////////////
		
		m_nEmbedDataSize += tableLength;
	}


	// Set the Flags
	TCmapTable	Cmap ={0,};
	int nPos = 0;
	if (m_pFontFileStream.hasFile())
	{
		nPos = m_pFontFileStream.getPos();
		m_pFontFileStream.read(&Cmap, sizeof(Cmap), false);
	}
	else
	{
		nPos = m_pFontStream.getPos();
		m_pFontStream.read(&Cmap, sizeof(Cmap), false);
	}
	
	TCmapTable	*pCmap = (TCmapTable*)cmapData;
	pCmap = &Cmap;
	int encodeSize = SWAPBrWORD(pCmap->numEncod);
	TCMapPlat cmapPlat = {0,};
	cmapPlat = pCmap->plats[0];
	int nCMapPlat2 = 0;
	if (m_pFontFileStream.hasFile())
		nCMapPlat2 = m_pFontFileStream.getPos();
	else
		nCMapPlat2= m_pFontStream.getPos();

	for (int i = 0; i < encodeSize; i++)
	{
		if (i > 0)
		{
			if (m_pFontFileStream.hasFile())
			{
				m_pFontFileStream.setPos(nCMapPlat2 + (sizeof(cmapPlat) * (i - 1)));
				m_pFontFileStream.read(&cmapPlat, sizeof(cmapPlat), false);
			}
			else
			{
				m_pFontStream.setPos(nCMapPlat2 + (sizeof(cmapPlat) * (i - 1)));
				m_pFontStream.read(&cmapPlat, sizeof(cmapPlat), false);
			}	
		}
		if( SWAPBrWORD(cmapPlat.platID) == TT_PLATFORM_MS && cmapPlat.platEncodID == 0)
		{
			bSymbol = BrTRUE;
			break;
		}
	}
	m_nFlags |= bSymbol ? 0x04 : 0x20; // Bit 3 : Symbolic, Bit 6 : Nonsymbolic

	// Load the ASCII code map.
	if (m_pFontFileStream.hasFile())
		m_pFontFileStream.setPos(nPos);
	else
		m_pFontStream.setPos(nPos);
	ret = getCodeMap(cmapData);

	// other
	if (cmapData)
	{
		cmapData = BrNULL;
	}
	return ret;
}

BrBOOL PDFFont::getCodeMap(BrBYTE const * const in_pData)
{
	BrBOOL ret = BrTRUE;
	TCmapTable	Cmap ={0,};
	int nPos = 0;
	if (m_pFontFileStream.hasFile())
	{
		nPos = m_pFontFileStream.getPos();
		m_pFontFileStream.read(&Cmap, sizeof(Cmap), false);
	}
	else
	{
		nPos = m_pFontStream.getPos();
		m_pFontStream.read(&Cmap, sizeof(Cmap), false);
	}
	
	TCmapTable	*pCmap = (TCmapTable*)in_pData;
	pCmap = &Cmap;
	int encodeSize = SWAPBrWORD(pCmap->numEncod);
	TCMapPlat cmapPlat = {0,};
	cmapPlat = pCmap->plats[0];
	BrDWORD			lOff = 0;
	short			nFormat;
	BrUSHORT		platEncodID;
	BrUSHORT		platformID;
	/******************** Get the cmap info ********************/
	nFormat = -1;
	int nTextType = getExportTextType();
	int nCMapPlat2 = 0;
	if (m_pFontFileStream.hasFile())
		nCMapPlat2 = m_pFontFileStream.getPos();
	else
		nCMapPlat2 = m_pFontStream.getPos();
	for (int i = 0; i < encodeSize; i++)	{
		if (i > 0)
		{
			if (m_pFontFileStream.hasFile())
			{
				m_pFontFileStream.setPos(nCMapPlat2 + (sizeof(cmapPlat) * (i - 1)));
				m_pFontFileStream.read(&cmapPlat, sizeof(cmapPlat), false);
			}
			else
			{
				m_pFontStream.setPos(nCMapPlat2 + (sizeof(cmapPlat) * (i - 1)));
				m_pFontStream.read(&cmapPlat, sizeof(cmapPlat), false);
			}
		}
		// Check the platform and encoding.
		platformID = SWAPBrWORD( cmapPlat.platID);
		if( platformID != TT_PLATFORM_MS
#if 1//def USE_FOR_IOS
		&& platformID != TT_PLATFORM_APPLE_UNICODE
#endif
			)
			continue;

		platEncodID = SWAPBrWORD( cmapPlat.platEncodID);
		if ( ePDF_TEXT_TYPE_NORMAL <m_eExportTextType && m_eExportTextType < ePDF_TEXT_TYPE_MAX)
		{

			if( nTextType == ePDF_TEXT_TYPE_UCS4 )
			{
				if (platformID == TT_PLATFORM_MS && platEncodID != MS_ENCODING_4B_UCS)
					continue;
				else if (platformID == TT_PLATFORM_APPLE_UNICODE && platEncodID != APPLE_ID_UNICODE_32)
					continue;
			}
			
			lOff = SWAPLONG( cmapPlat.offset);
			if (m_pFontFileStream.hasFile())
			{
				m_pFontFileStream.setPos(nPos + lOff);
				m_pFontFileStream.read(&nFormat, sizeof(nFormat), true);
			}
			else
			{
				m_pFontStream.setPos(nPos + lOff);
				m_pFontStream.read(&nFormat, sizeof(nFormat), true);
				//memcpy( &nFormat, in_pData + lOff, 2);
			}
			
			
			nFormat = SWAPBrWORD(nFormat);
			if(nFormat > 12)
			{
				lOff = 0;
				nFormat = -1;
				continue;
			}
			else
				break;

		}
		
		// Get the format number of cmap.
		lOff = SWAPLONG( cmapPlat.offset);
		if (m_pFontFileStream.hasFile())
		{
			m_pFontFileStream.setPos(nPos + lOff);
			m_pFontFileStream.read(&nFormat, sizeof(nFormat), true);
			//memcpy( &nFormat, in_pData + lOff, 2);
		}
		else
		{
			m_pFontStream.setPos(nPos + lOff);
			m_pFontStream.read(&nFormat, sizeof(nFormat), true);
			//memcpy( &nFormat, in_pData + lOff, 2);
		}

		
		nFormat = SWAPBrWORD(nFormat);
		if(nFormat > 12)
		{
			lOff = 0;
			nFormat = -1;
			continue;
		}
		else
			break;
	}
	if (m_pFontFileStream.hasFile())
		m_pFontFileStream.setPos(nPos);
	else
		m_pFontStream.setPos(nPos);
	if (lOff == 0 || nFormat == -1)
		return BrFALSE;

	/*********** Compute the ansi-code mapping glyph-index table **********/
	BrDWORD lCode;
	BrWORD glyfIndex = 0;

	if (!( ePDF_TEXT_TYPE_NORMAL < m_eExportTextType && m_eExportTextType < ePDF_TEXT_TYPE_MAX) )
	{
		for (int i = 0; i < ANSI_CODE_SIZE; i++)
		{
			lCode = ANSI_START_CODE + i;
			if (m_pFontFileStream.hasFile())
				m_pFontFileStream.setPos(nPos + lOff);
			else
				m_pFontStream.setPos(nPos + lOff);
			glyfIndex = getGlyfIndex(nFormat, in_pData, lOff, lCode);
			if (glyfIndex == 0)
			{
				BRTHREAD_ASSERT( glyfIndex != 0 );	//[dwchun : 2014.02.18] : �̷� ���� ��Ʈ ������ �߸��� ����Դϴ�.
				ret = BrFALSE;
			}

			m_aAnsiCodeMap[i] = glyfIndex;
		}
	}
	else
	{

#if 0 //OTF Test Code
		if(m_fontType = eXPDFFontOpenType)
		{
			BrINT unicodeCount = 0xFFFF;
			if (unicodeCount > 0)
				m_pFontGlyphData = (BrINT*)BrMalloc(sizeof(BrINT)*unicodeCount);

			for (int uni= 0x0; uni < 0xFFFF; uni++)
			{
				if (m_pFontFileStream.hasFile())
					m_pFontFileStream.setPos(nPos + lOff);
				else
					m_pFontStream.setPos(nPos + lOff);
				BrINT temp = getGlyfIndex(nFormat, in_pData, lOff, uni);  // 4297
				if (temp == 0 && uni != 0x20)
				{
					BRTHREAD_ASSERT( temp != 0 );	//[dwchun : 2014.02.18] : �̷� ���� ��Ʈ ������ �߸��� ����Դϴ�.
					ret = BrFALSE;
				}
				else
				{
					m_pFontGlyphData[temp] = uni;
				}
			}
		}
		else
#endif
		if(m_pFontGlyphData == BrNULL && m_nGlyphCount > 0)		// UNICODE ���� Glyph�� ��� ���
		{
			BrINT unicodeCount = m_nGlyphCount -1;	// m_nGlyphCount�� glyph ������ġ ���� Count�̱� ������ 1�� ������
			if (unicodeCount > 0)
				m_pFontGlyphData = (BrINT*)BrMalloc(BrSizeOf(BrINT)*unicodeCount);

			for (int i=0; i < unicodeCount; i++)
			{
				if (m_pFontFileStream.hasFile())
					m_pFontFileStream.setPos(nPos + lOff);
				else
					m_pFontStream.setPos(nPos + lOff);
				m_pFontGlyphData[i] = getGlyfIndex(nFormat, in_pData, lOff, m_pUnicodeData[i]);  // 4297
				if (m_pFontGlyphData[i] == 0 && m_pUnicodeData[i] != 0x20)
				{
					BRTHREAD_ASSERT( m_pFontGlyphData[i] != 0 );	//[dwchun : 2014.02.18] : �̷� ���� ��Ʈ ������ �߸��� ����Դϴ�.
					ret = BrFALSE;
				}
			}
		}
	}

	return ret;
}

BrWORD PDFFont::getCodeFromCodeMap(BrULONG uniCode)
{
	BrWORD ret = 0;
	BrBYTE const * cmapData = BrNULL;
	BrLONG cmapLen = 0;

	cmapData = (BrBYTE const *)getTtfTagInfo(TAG_ID_CMAP, cmapLen);
	if (cmapData == BrNULL)
		return ret;

	int nPos = 0;
	TCmapTable	Cmap = { 0, };
	if (m_pFontFileStream.hasFile())
	{
		nPos = m_pFontFileStream.getPos();
		m_pFontFileStream.read(&Cmap, sizeof(Cmap), false);
	}
	else
	{
		nPos = m_pFontStream.getPos();
		m_pFontStream.read(&Cmap, sizeof(Cmap), false);
	}
		
	TCmapTable	*pCmap = (TCmapTable*)cmapData;
	pCmap = &Cmap;
	int encodeSize = SWAPBrWORD(pCmap->numEncod);
	TCMapPlat cmapPlat = {0,};
	cmapPlat = pCmap->plats[0];
	BrDWORD			lOff = 0;
	short			nFormat;
	BrUSHORT		platEncodID;
	BrUSHORT		platformID;

	/******************** Get the cmap info ********************/
	nFormat = -1;
	int nTextType = getExportTextType();
	int nCMapPlat2 = 0;
	if (m_pFontFileStream.hasFile())
		nCMapPlat2 = m_pFontFileStream.getPos();
	else
		nCMapPlat2 = m_pFontStream.getPos();
	for (int i = 0; i < encodeSize; i++)	{
		if (i > 0)
		{
			if (m_pFontFileStream.hasFile())
			{
				m_pFontFileStream.setPos(nCMapPlat2 + (sizeof(cmapPlat) * (i - 1)));
				m_pFontFileStream.read(&cmapPlat, sizeof(cmapPlat), false);
			}
			else
			{
				m_pFontStream.setPos(nCMapPlat2 + (sizeof(cmapPlat) * (i - 1)));
				m_pFontStream.read(&cmapPlat, sizeof(cmapPlat), false);
			}
		}

		// Check the platform and encoding.
		platformID = SWAPBrWORD( cmapPlat.platID);
		if( platformID != TT_PLATFORM_MS
#if 1//def USE_FOR_IOS
			&& platformID != TT_PLATFORM_APPLE_UNICODE
#endif
			)
			continue;

		platEncodID = SWAPBrWORD( cmapPlat.platEncodID);
		if ( ePDF_TEXT_TYPE_NORMAL <m_eExportTextType && m_eExportTextType < ePDF_TEXT_TYPE_MAX)
		{
			if( nTextType == ePDF_TEXT_TYPE_UCS4 )
			{
				if (platformID == TT_PLATFORM_MS && platEncodID != MS_ENCODING_4B_UCS)
					continue;
				else if (platformID == TT_PLATFORM_APPLE_UNICODE && platEncodID != APPLE_ID_UNICODE_32)
					continue;
			}
			else if( nTextType == ePDF_TEXT_TYPE_UNICODE )
			{
				
				if (platformID == TT_PLATFORM_MS && (MS_ENCODING_KOREAN == platEncodID) &&
					(uniCode > 0x80) )
				{
					char pOutout[3] = {0,};
					FT_UShort wansungCh = 0;	//[16.06.16][sglee1206] Coverity medium ó�� ����
					wansungCh = (uniCode&0xFFFF);
					if ( BrWideCharToMultiByte( CP_ACP, (BrLPCWSTR)&wansungCh, 1, (BrLPSTR)pOutout, sizeof(pOutout)) )
						uniCode = (pOutout[0] << 8)&0xff00 | (pOutout[1]&0xff);
				}
			}
			lOff = SWAPLONG( cmapPlat.offset);
			if (m_pFontFileStream.hasFile())
			{
				m_pFontFileStream.setPos(nPos + lOff);
				m_pFontFileStream.read(&nFormat, sizeof(nFormat), true);
			}
			else
			{
				m_pFontStream.setPos(nPos + lOff);
				m_pFontStream.read(&nFormat, sizeof(nFormat), true);
			}
			
			//memcpy( &nFormat, cmapData + lOff, 2);
			nFormat = SWAPBrWORD(nFormat);
			if(nFormat > 12)
			{
				lOff = 0;
				nFormat = -1;
				continue;
			}
			else
				break;

		}
		
		// Get the format number of cmap.
		lOff = SWAPLONG( cmapPlat.offset);
		if (m_pFontFileStream.hasFile())
		{
			m_pFontFileStream.setPos(nPos + lOff);
			m_pFontFileStream.read(&nFormat, sizeof(nFormat), true);
		}
		else
		{
			m_pFontStream.setPos(nPos + lOff);
			m_pFontStream.read(&nFormat, sizeof(nFormat), true);
		}
		
		//memcpy( &nFormat, cmapData + lOff, 2);
		nFormat = SWAPBrWORD(nFormat);
		if(nFormat > 12)
		{
			lOff = 0;
			nFormat = -1;
			continue;
		}
		else
			break;
	}
	if (m_pFontFileStream.hasFile())
		m_pFontFileStream.setPos(nPos);
	else
		m_pFontStream.setPos(nPos);

	//[14.05.09][sglee1206]	Coverity... Memory Leak cmapData
	if (lOff != 0 || nFormat != -1)
	{
		if (m_pFontFileStream.hasFile())
			m_pFontFileStream.setPos(nPos + lOff);
		else
			m_pFontStream.setPos(nPos + lOff);
		ret = getGlyfIndex(nFormat, cmapData, lOff, uniCode);
	}

	return ret;
}

BrSHORT PDFFont::getGlyfIndex(short format, BrBYTE const * const in_pData, BrULONG offset, BrULONG lCode)
{
	BrWORD glyfIndex;// , glyfIndexTmp;

	switch( format)	{
		case	TT_CMAP_0:
			{
			//TCmap0 Cmap = {0,};
			//m_pFontStream.read(&Cmap, sizeof(Cmap), true);
			//glyfIndex = Cmap0GlyphIndex( &Cmap, lCode);
			glyfIndex = Cmap0GlyphIndex( (TCmap0*) (in_pData + offset), lCode);
			}
			break;
		case	TT_CMAP_2:
			{
			//TCmap2 Cmap = {0,};
			//m_pFontStream.read(&Cmap, sizeof(Cmap), true);
			//glyfIndex = Cmap2GlyphIndex( &Cmap, lCode);
			glyfIndex = Cmap2GlyphIndex( (TCmap2*) (in_pData + offset), lCode);
			}
			break;
		case	TT_CMAP_4:
			{
			//TCmap4 Cmap = {0,};
			//m_pFontStream.read(&Cmap, sizeof(Cmap), true);
			//glyfIndex = Cmap4GlyphIndex( &Cmap, lCode);
			glyfIndex = Cmap4GlyphIndex( (TCmap4*) (in_pData + offset), lCode);
			}
			break;
		case	TT_CMAP_6:
			{
			//TCmap6 Cmap = {0,};
			//m_pFontStream.read(&Cmap, sizeof(Cmap), true);
			//glyfIndex = Cmap6GlyphIndex( &Cmap, lCode);
			glyfIndex = Cmap6GlyphIndex( (TCmap6*) (in_pData + offset), lCode);
			}
			break;
		case	TT_CMAP_8:
			{
			//TCmap8 Cmap = {0,};
			//m_pFontStream.read(&Cmap, sizeof(Cmap), true);
			//glyfIndex = Cmap8GlyphIndex( &Cmap, lCode);
			glyfIndex = Cmap8GlyphIndex( (TCmap8*) (in_pData + offset), lCode);
			}
			break;
		case	TT_CMAP_10:
			{
			//TCmap10 Cmap = {0,};
			//m_pFontStream.read(&Cmap, sizeof(Cmap), true);
			//glyfIndex = Cmap10GlyphIndex( &Cmap, lCode);
			glyfIndex = Cmap10GlyphIndex( (TCmap10*) (in_pData + offset), lCode);
			}
			break;
		case	TT_CMAP_12:
			{
			//TCmap12 Cmap = {0,};
			//m_pFontStream.read(&Cmap, sizeof(Cmap), true);
			//glyfIndex = Cmap12GlyphIndex( &Cmap, lCode);
			glyfIndex = Cmap12GlyphIndex( (TCmap12*) (in_pData + offset), lCode);
			}
			break;
		default:					// other is format = 2 or 6, this is not used MS/UCS encoding.
			glyfIndex = 0;
			break;
	}

	return glyfIndex;
}

BrBOOL PDFFont::loadPostTag()
{
	BrLONG ret = 0;
	TPostTable postData;

	ret = getTtfTagInfoEx(TAG_ID_POST, &postData, BrSizeOf(TPostTable));
	if (ret == 0)
		return BrFALSE;

	// Compute the italic angle.
	m_nAngle = SWAPLONG(postData.italicAngle);
	// Compute the flags.
	m_nFlags |= postData.isFixedPitch == 0? 0 : 1; // Bit 1 : FixedPitch

	return BrTRUE;
}

BrBOOL PDFFont::loadHeadTag()
{
	BrLONG ret = 0;
	THeadTable headData;

	ret = getTtfTagInfoEx(TAG_ID_HEAD, &headData, BrSizeOf(headData));
	if (ret == 0)
		return BrFALSE;

	if ( ePDF_TEXT_TYPE_NORMAL <m_eExportTextType && m_eExportTextType < ePDF_TEXT_TYPE_MAX)
	{
		// Offset Table
		BrULONG tableLength = ret;
		m_pTagTableData[eTable_head] = (BrBYTE*)BrMalloc(tableLength);
		headData.checkSumAdjustment = 0;
		memcpy(m_pTagTableData[eTable_head], &headData, tableLength);

		m_pData.setPos(eTable_head * sizeof(TTableDir));
		m_pData << SWAPLONG(TAG_ID_HEAD);
		BrULONG checkSum = CalcTableChecksum(m_pTagTableData[eTable_head], tableLength);
		m_pData << SWAPLONG(checkSum);
		m_pData.movePos(4);
		m_pData << SWAPLONG(tableLength);
		//m_pOffsetTables[eTable_head].tag = SWAPLONG(TAG_ID_HEAD);
		//m_pOffsetTables[eTable_head].length = SWAPLONG(tableLength);
		/////////////////////////////////////////////////////
		
		//m_pOffsetTables[eTable_head].checkSum = SWAPLONG(CalcTableChecksum(m_pTagTableData[eTable_head], tableLength));
		m_nEmbedDataSize += tableLength;
	}
	m_nUnitsPerEm	= SWAPBrWORD(headData.unitsPerEm);

	// Compute the bounding box.
	m_BBox.left		= (BrSHORT)SWAPBrWORD(headData.xMin) * 1000 / m_nUnitsPerEm;
	m_BBox.right	= (BrSHORT)SWAPBrWORD(headData.xMax) * 1000 / m_nUnitsPerEm;
	m_BBox.top		= (BrSHORT)SWAPBrWORD(headData.yMax) * 1000 / m_nUnitsPerEm;
	m_BBox.bottom	= (BrSHORT)SWAPBrWORD(headData.yMin) * 1000 / m_nUnitsPerEm;
	
	// Compute the flags.
	if ((SWAPBrWORD(headData.macStyle) & 0x02) != 0) // Bit 7 : Italic
		m_nFlags |= 0x40;
	if ((SWAPBrWORD(headData.macStyle) & 0x01) != 0) // Bit 19 : Bold
		m_nFlags |= 0x40000;

	// other.
	m_bIndexToLocFormat = SWAPBrWORD(headData.indexToLocFormat)? true : false;
	return BrTRUE;
}

BrBOOL PDFFont::loadNameTag()
{
	BrBYTE const * nameData = BrNULL;
	BrLONG dataLen = 0;
	BrBOOL bOk = BrTRUE;

	nameData = (BrBYTE const *)getTtfTagInfo(TAG_ID_NAME, dataLen);
	if (nameData == BrNULL)
		return BrFALSE;

	int nPos = 0;
	if (m_pFontFileStream.hasFile())
		nPos = m_pFontFileStream.getPos();
	else
		nPos = m_pFontStream.getPos();
	bOk = readFontName(nameData);

	if ( ePDF_TEXT_TYPE_NORMAL <m_eExportTextType && m_eExportTextType < ePDF_TEXT_TYPE_MAX)
	{
		// Offset Table
		BrULONG tableLength = dataLen;
		m_pTagTableData[eTable_name] = (BrBYTE*)BrMalloc(tableLength);
		if (m_pFontFileStream.hasFile())
		{
			m_pFontFileStream.setPos(nPos);
			m_pFontFileStream.read(m_pTagTableData[eTable_name], tableLength, true);
		}
		else
		{
			m_pFontStream.setPos(nPos);
			m_pFontStream.read(m_pTagTableData[eTable_name], tableLength, true);
			//memcpy(m_pTagTableData[eTable_name], nameData, tableLength);
		}
		
		m_pData.setPos(eTable_name * sizeof(TTableDir));
		m_pData << SWAPLONG(TAG_ID_NAME);
		BrULONG checkSum = CalcTableChecksum(m_pTagTableData[eTable_name], tableLength);
		m_pData << SWAPLONG(checkSum);
		m_pData.movePos(4);
		m_pData << SWAPLONG(tableLength);
		//m_pOffsetTables[eTable_name].tag = SWAPLONG(TAG_ID_NAME);
		//m_pOffsetTables[eTable_name].length = SWAPLONG(tableLength);
		/////////////////////////////////////////////////////
		
		//m_pOffsetTables[eTable_name].checkSum = SWAPLONG(CalcTableChecksum(m_pTagTableData[eTable_name], tableLength));
		m_nEmbedDataSize += tableLength;
	}
	if (nameData != BrNULL)
	{
		nameData = BrNULL;
	}

	return bOk;
}

BrBOOL PDFFont::readFontName(BrBYTE const * in_pNameData)
{
	TNameTable *pNameBuff = (TNameTable*)in_pNameData;
	BrUSHORT strLen, strOff;
	BrBYTE const * strBuf = in_pNameData + SWAPBrWORD( pNameBuff->stringOffset);
	int nPos = SWAPBrWORD( pNameBuff->stringOffset);
	if (m_pFontFileStream.hasFile())
	{
		nPos += m_pFontFileStream.getPos();
		m_pFontFileStream.setPos(nPos);
	}
	else
	{
		nPos += m_pFontStream.getPos();
		m_pFontStream.setPos(nPos);
	}
	
	BrBOOL bOK = BrFALSE;
	BrUSHORT strTemp[256] = {0,};
	BrUSHORT nameRecordCount = SWAPBrWORD(pNameBuff->count);

	//memset(strTemp, 0, BrSizeOf(strTemp));

	for(int i = 0; i < nameRecordCount; i++)		{
		TNameRec		*pName;

		pName = (TNameRec*) &(pNameBuff->sName[i]);
		if (SWAPBrWORD(pName->nameID) != NAME_ID_POST)
			continue;

		strLen = SWAPBrWORD(pName->strLen);
		strOff = SWAPBrWORD(pName->strOff);
		if (SWAPBrWORD(pName->platform) == TT_PLATFORM_MAC && SWAPBrWORD(pName->script) == MAC_SCRIPT_ROMAN)
		{
			if (m_pFontFileStream.hasFile())
			{
				m_pFontFileStream.setPos(nPos + strOff);
				m_pFontFileStream.read(m_szFontName, strLen);
			}
			else
			{
				m_pFontStream.setPos(nPos + strOff);
				m_pFontStream.read(m_szFontName, strLen);
				//memcpy( m_szFontName, strBuf + strOff, strLen);
			}
			
			m_szFontName[strLen] = 0;
			bOK = BrTRUE;
			break;
		}
		else if (SWAPBrWORD(pName->platform) == TT_PLATFORM_MS)	{
			if(SWAPBrWORD(pName->script) == MS_ENCODING_UNICODE)
			{
				if (m_pFontFileStream.hasFile())
				{
					m_pFontFileStream.setPos(nPos + strOff);
					m_pFontFileStream.read(strTemp, strLen);
				}
				else
				{
					m_pFontStream.setPos(nPos + strOff);
					m_pFontStream.read(strTemp, strLen);
					//memcpy( strTemp, strBuf + strOff, strLen);
				}
							
				int len = CUtil::WcsLen(strTemp);
				ReverseBuffer(strTemp, len);

				BrWideCharToMultiByte(CP_ACP, strTemp, len, m_szFontName, len*2+1);
				bOK = BrTRUE;
				break;
			}
			else if(PoGetLocale() == BR_LOCALE_KOREAN && SWAPBrWORD(pName->script) == MS_ENCODING_KOREAN)
			{
				if (m_pFontFileStream.hasFile())
				{
					m_pFontFileStream.setPos(nPos + strOff);
					m_pFontFileStream.read(strTemp, strLen);
				}
				else
				{
					m_pFontStream.setPos(nPos + strOff);
					m_pFontStream.read(strTemp, strLen);
					//memcpy( strTemp, strBuf + strOff, strLen);
				}
							
				int len = CUtil::WcsLen(strTemp);
				ReverseBuffer(strTemp, len);

				//[15.11.24][sglee1206] CP_ACP -> CP_949
				BrWideCharToMultiByte(949, strTemp, len, m_szFontName, len*2+1);
				bOK = BrTRUE;
			}
		}
	}

	// Trim the spaces in font-name string.
	if (bOK == BrTRUE)
	{
		BrCHAR temp[MAX_FONT_LEN]={0,};
		BrCHAR seps[] = " ";
		BrCHAR* token;

		strncpy_s(temp, sizeof(temp), m_szFontName, strlen(m_szFontName));
		memset(m_szFontName, 0, BrSizeOf(m_szFontName));

		char* pContext = BrNULL;
		token = strtok_s(temp, seps, &pContext);
		while( token != BrNULL)
		{
			strncat_s(m_szFontName, sizeof(m_szFontName), token, strlen(token));
			token = strtok_s(BrNULL, seps, &pContext);
		}
	}

	return bOK;
}

BrBOOL PDFFont::loadLocaTag()
{
	BrLONG dataLen = 0;

	m_pLocaData = (BrBYTE const *)getTtfTagInfo(TAG_ID_LOCA, dataLen);
	if (m_pLocaData == BrNULL)
		return BrFALSE;

	if (m_pFontFileStream.hasFile())
		m_pFontData = BrNULL;

	m_LocaStream = PoStream((void* )m_pLocaData, dataLen);
	return BrTRUE;
}

BrINT PDFFont::getLocOfGlyf(BrINT in_glyfIndex)
{
	int locOff = 0, locOffTmp = 0;
	
	if (m_bIndexToLocFormat == BrFALSE)
	{
		m_LocaStream.setPos(in_glyfIndex * sizeof(BrSHORT));
		BrSHORT tmp = 0;
		m_LocaStream >> tmp;
		//locOff = SWAPBrWORD( ((BrSHORT *)m_pLocaData)[in_glyfIndex] ) * 2;
		locOffTmp = SWAPBrWORD( tmp ) * 2;
	}
	else
	{
		m_LocaStream.setPos(in_glyfIndex * sizeof(BrLONG));
		BrLONG tmp = 0;
		m_LocaStream >> tmp;
		//locOff = SWAPLONG( ((BrLONG *)m_pLocaData)[in_glyfIndex] );
		locOffTmp = SWAPLONG( tmp );
	}

	return locOff;
}

BrBOOL PDFFont::loadGlyfTag()
{
	BrBOOL ret = BrTRUE;
	BrBYTE const * glyfData = BrNULL;
	BrLONG dataLen = 0;

	glyfData = (BrBYTE const *)getTtfTagInfo(TAG_ID_GLYF, dataLen);
	if (glyfData == BrNULL)
		return BrFALSE;

	int nPos = 0;
	if (m_pFontFileStream.hasFile())
		nPos = m_pFontFileStream.getPos();
	else
		nPos = m_pFontStream.getPos();
//	ret = doAnsiGlyfExtent(glyfData);
	if (m_nCapHeight <= 0)
	{
		BrINT glyfIndex = m_aAnsiCodeMap[CAP_HEIGHT_CODE - ANSI_START_CODE];
		m_nCapHeight = getGlyfHeight(glyfData, glyfIndex);

	}

	if ( ePDF_TEXT_TYPE_NORMAL <m_eExportTextType && m_eExportTextType < ePDF_TEXT_TYPE_MAX)
	{
		if (m_pFontFileStream.hasFile())
			m_pFontFileStream.setPos(nPos);
		else
			m_pFontStream.setPos(nPos);
		if(m_bIndexToLocFormat)
			ret = doExtractGlyfData(glyfData);
		else
			ret = doExtractShortGlyfData(glyfData);
	}

	glyfData = BrNULL;

	return ret;
}

BrBOOL PDFFont::doExtractShortGlyfData(BrBYTE const * const in_pGlyfData)
{
	BrBOOL ret = BrTRUE;

	int nPos = 0;
	if (m_pFontFileStream.hasFile())
		nPos = m_pFontFileStream.getPos();
	else
		nPos = m_pFontStream.getPos();

	BrULONG tableLength = 0;
	//[14.05.09][sglee1206]	Coverity... Uninitialize
	BrWORD *glfyLoc = BrNULL;
	BrWORD *glfySize = BrNULL;
	
	// Loca Table
	m_pData.setPos(eTable_loca * sizeof(TTableDir));
	m_pData << SWAPLONG(TAG_ID_LOCA);
	//m_pOffsetTables[eTable_loca].tag = SWAPLONG(TAG_ID_LOCA);
	BrULONG locaTblLength = (m_nGlyfSize+1)*2;
	m_pTagTableData[eTable_loca] = (BrBYTE*)BrCalloc(locaTblLength, sizeof(BrBYTE));
	if(m_pTagTableData[eTable_loca] == BrNULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");
		return BrFALSE;
	}
	PoStream localData(m_pTagTableData[eTable_loca], locaTblLength);
	m_pData.movePos(8);
	m_pData << SWAPLONG(locaTblLength);	
	//m_pOffsetTables[eTable_loca].length = SWAPLONG(locaTblLength);	

	glfyLoc = (BrWORD*)BrCalloc(locaTblLength,1);
	if(glfyLoc == BrNULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");

		BR_SAFE_FREE(m_pTagTableData[eTable_loca]);
		//m_pOffsetTables[eTable_loca].length = 0;

		return BrFALSE;
	}
	glfySize = (BrWORD*)BrCalloc(locaTblLength,1);
	if(glfySize == BrNULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");

		BR_SAFE_FREE(m_pTagTableData[eTable_loca]);
		//m_pOffsetTables[eTable_loca].length = 0;

		BrFree(glfyLoc);

		return BrFALSE;
	}

	BrINT glyfIndex;
	BrWORD curLoc, nextLoc;

	if (m_nGlyphCount == 0)
	{
		if ( ePDF_TEXT_TYPE_NORMAL <m_eExportTextType && m_eExportTextType < ePDF_TEXT_TYPE_MAX)
		{
			glyfIndex = 0;
			m_LocaStream.setPos(2*glyfIndex);
			m_LocaStream >> curLoc;
			//memcpy(&curLoc, m_pLocaData+2*glyfIndex, 2);
			curLoc = SWAPBrWORD(curLoc);

			m_LocaStream >> nextLoc;
			//memcpy(&nextLoc, m_pLocaData+2*(glyfIndex+1), 2);
			nextLoc = SWAPBrWORD(nextLoc);

			glfyLoc[0] = curLoc;
			glfySize[0] = nextLoc - curLoc;
		}
	}
	else
	{

		for (int i=0; i<m_nGlyphCount; i++)
		{
			if (i == 0)
			{
				glyfIndex = 0;
			}
			else {
				glyfIndex = m_pFontGlyphData[i-1];
			}

			m_LocaStream.setPos(2*glyfIndex);
			m_LocaStream >> curLoc;
			//memcpy(&curLoc, m_pLocaData+2*glyfIndex, 2);
			curLoc = SWAPBrWORD(curLoc);

			m_LocaStream >> nextLoc;
			//memcpy(&nextLoc, m_pLocaData+2*(glyfIndex+1), 2);
			nextLoc = SWAPBrWORD(nextLoc);

			glfyLoc[i] = curLoc;
			glfySize[i] = nextLoc - curLoc;
		}
	}

	// Composite Glyph
	int nComponentGlyphCount = 0;
	//[15.02.03][sglee1206] Polaris batang m_nGlyfSize�� 60000�̻��̹Ƿ� Short �� ��� ó�� ����.
	BrUSHORT *componentGlyphIndices = NULL;

	// Get component glyph indices
	for(int i = 0; i < m_nGlyphCount; i++)
	{
		TGlyphTable glyphHeader;
		if (m_pFontFileStream.hasFile())
		{
			m_pFontFileStream.setPos(nPos + glfyLoc[i] * 2);
			m_pFontFileStream.read(&glyphHeader, BrSizeOf(TGlyphTable));
		}
		else
		{
			m_pFontStream.setPos(nPos + glfyLoc[i] * 2);
			m_pFontStream.read(&glyphHeader, BrSizeOf(TGlyphTable));
			//memcpy(&glyphHeader, in_pGlyfData+glfyLoc[i]*2, BrSizeOf(TGlyphTable));
		}
		
		glyphHeader.numberOfContours = SWAPBrWORD(glyphHeader.numberOfContours);

		if(glyphHeader.numberOfContours < 0) // Composite Glyph
		{
			BrSHORT flags = 1<<5;	//MORE_COMPONENTS
			BrSHORT glyphIndex = 0;
			int glyphReadLoc = 0;
			glyphReadLoc += BrSizeOf(TGlyphTable);
			//[17.07.12][sglee1206] ���� �߰�. 0x20(1<<5) �� ��� MORE_COMPONENTS(Indicates at least one more glyph after this one.) 
			//���� Do While�� ó���Ͽ��� �ϳ� ��� 1�� �̻��� Glyph�� �����Ѵٴ� �����Ͽ� flags �ʱⰪ�� MORE_COMPONENTS�� �Ͽ� ó��
			while(glyphReadLoc < glfySize[i]*2 && (flags & 1<<5))
			{
				if (m_pFontFileStream.hasFile())
				{
					m_pFontFileStream.setPos(nPos + glfyLoc[i] * 2 + glyphReadLoc);
					m_pFontFileStream >> flags;
				}
				else
				{
					m_pFontStream.setPos(nPos + glfyLoc[i] * 2 + glyphReadLoc);
					m_pFontStream >> flags;
					//memcpy(&flags, in_pGlyfData+glfyLoc[i]*2 + glyphReadLoc, BrSizeOf(BrUSHORT));
				}
				
				flags = SWAPBrWORD(flags);
				glyphReadLoc += BrSizeOf(BrUSHORT);
				
				if (m_pFontFileStream.hasFile())
					m_pFontFileStream >> glyphIndex;
				else
					m_pFontStream >> glyphIndex;
				//memcpy(&glyphIndex, in_pGlyfData+glfyLoc[i]*2 + glyphReadLoc, BrSizeOf(BrUSHORT));
				glyphIndex = SWAPBrWORD(glyphIndex);
				glyphReadLoc += BrSizeOf(BrUSHORT);
				if(flags & 1)
					glyphReadLoc += 2 * BrSizeOf(BrUSHORT);
				else
					glyphReadLoc += BrSizeOf(BrUSHORT);
				//glyphReadLoc += BrSizeOf(TCompositeGlyphDesc);

				//[15.11.24][sglee1206] Refer : http://www.microsoft.com/typography/otspec/glyf.htm
				if ( flags & (1<<3)/*WE_HAVE_A_SCALE*/ ) {
					glyphReadLoc += BrSizeOf(BrUSHORT);//F2Dot14  scale;    /* Format 2.14 */
				} else if ( flags & (1<<6)/*WE_HAVE_AN_X_AND_Y_SCALE*/ ) {
					glyphReadLoc += 2 * BrSizeOf(BrUSHORT);
					//F2Dot14  xscale;    /* Format 2.14 */
					//F2Dot14  yscale;    /* Format 2.14 */
				} else if ( flags & (1<<7)/*WE_HAVE_A_TWO_BY_TWO*/ ) {
					glyphReadLoc += 4 * BrSizeOf(BrUSHORT);
					//F2Dot14  xscale;    /* Format 2.14 */
					//F2Dot14  scale01;   /* Format 2.14 */
					//F2Dot14  scale10;   /* Format 2.14 */
					//F2Dot14  yscale;    /* Format 2.14 */
				}

				if(glyphIndex < 0)
				{
					//[15.02.03][sglee1206] Polaris batang m_nGlyfSize�� 60000�̻��̹Ƿ� Short �� ��� ó�� ���Ͽ� ���� ó��
					if((BrUSHORT)glyphIndex > m_nGlyfSize)
						continue;
				}
				bool isExisting = false;
				for(int k = 0; k < nComponentGlyphCount; k++)
				{
					if((BrUSHORT)glyphIndex == componentGlyphIndices[k])
					{
						isExisting = true;
						break;
					}
				}
				if(isExisting)
					continue;
				nComponentGlyphCount++;
#if 1
				if ( !componentGlyphIndices )
					componentGlyphIndices = (BrUSHORT*)BrMalloc(BrSizeOf(BrUSHORT) * nComponentGlyphCount);
				else
					componentGlyphIndices = (BrUSHORT*)BrRealloc(componentGlyphIndices, BrSizeOf(BrUSHORT) * nComponentGlyphCount);
#else
				BrUSHORT* tempIndices = NULL;
				if(nComponentGlyphCount - 1 > 0)
				{
					tempIndices = (BrUSHORT*)BrMalloc((nComponentGlyphCount - 1) * BrSizeOf(BrUSHORT));
					memcpy(tempIndices, componentGlyphIndices, BrSizeOf(BrUSHORT) * (nComponentGlyphCount - 1));
				}
				if(componentGlyphIndices != NULL)
					BrFree(componentGlyphIndices);
				componentGlyphIndices = (BrUSHORT*)BrMalloc(BrSizeOf(BrUSHORT) * nComponentGlyphCount);
				if(nComponentGlyphCount - 1 > 0)
				{
					memcpy(componentGlyphIndices, tempIndices, BrSizeOf(BrSHORT) * (nComponentGlyphCount - 1));
					BrFree(tempIndices);
				}
#endif
				componentGlyphIndices[nComponentGlyphCount - 1] = (BrUSHORT)glyphIndex;
			}
		}
	}

	for (int i=0; i<m_nGlyfSize; i++)
	{
		glyfIndex = i;

		bool isExisting = false;
		for(int j = 0; j < m_nGlyphCount-1; j++)
		{
			if(m_pFontGlyphData[j] == glyfIndex)
			{
				isExisting = true;
				break;
			}
		}
		for(int j = 0; j < nComponentGlyphCount; j++)
		{
			if(componentGlyphIndices[j] == glyfIndex)
			{
				isExisting = true;
				break;
			}
		}

		m_LocaStream.setPos(2*glyfIndex);
		m_LocaStream >> curLoc;
		//memcpy(&curLoc, m_pLocaData+2*glyfIndex, 2);
		curLoc = SWAPBrWORD(curLoc);

		m_LocaStream >> nextLoc;
		//memcpy(&nextLoc, m_pLocaData+2*(glyfIndex+1), 2);
		nextLoc = SWAPBrWORD(nextLoc);

		localData.setPos(2*i);
		localData << curLoc;
		//memcpy(m_pTagTableData[eTable_loca]+2*i, &curLoc, 2);
		glfyLoc[i] = curLoc;
		glfyLoc[i+1] = nextLoc;
		glfySize[i] = nextLoc - curLoc;
		// glyph 0 ��°(undefied)�� �׻� �⺻ ž���Ѵ�.
		// ���극�� ��Ÿ ���ÿ����� ��� glyph�� �⺻ž���ϰ� ����.
		if(i != 0)// && getExportTextType() != ePDF_TEXT_TYPE_UCS4)
		{
			//������ ����� ��Ʈ�� ��� glyph 0 ��°(undefied)�� �������� ���� �� �����Ƿ� 1��° glyph�� ���ؼ� ó���ϵ��� �߰�
			if(!isExisting && tableLength != 0)
				glfySize[i] = 0;
		}
		tableLength += glfySize[i];	
	}
	BrFree(componentGlyphIndices);
	BrWORD endianLength = SWAPBrWORD(tableLength);
	localData.setPos(2*m_nGlyphCount);
	localData << endianLength;
	//memcpy(m_pTagTableData[eTable_loca]+2*m_nGlyphCount, &endianLength, 2);

	// Offset Table - Glyf Table
	m_pData.setPos(eTable_glyf * sizeof(TTableDir));
	m_pData << SWAPLONG(TAG_ID_GLYF);
	//m_pOffsetTables[eTable_glyf].tag = SWAPLONG(TAG_ID_GLYF);
	//m_pOffsetTables[eTable_glyf].length = SWAPLONG(tableLength*2);
	/////////////////////////////////////////////////////
	m_pTagTableData[eTable_glyf] = (BrBYTE*)BrMalloc(tableLength*2);
	if(m_pTagTableData[eTable_glyf] == BrNULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");

		//BR_SAFE_FREE(m_pTagTableData[eTable_loca]);
		//m_pOffsetTables[eTable_loca].length = 0;

		BrFree(glfyLoc);
		BrFree(glfySize);

		return BrFALSE;
	}
	PoStream tableData(m_pTagTableData[eTable_glyf], tableLength*2);

	BrUSHORT tOffSet = 0;

	int nBufferSize = 0, nGlfySize = 0;
	BrBYTE* pBuffer = BrNULL;
	for (int i=0; i<=m_nGlyfSize; i++)
	{
		nGlfySize = glfySize[i]*2;		
		if ( nBufferSize == 0 )
		{
			nBufferSize = nGlfySize;

			BR_SAFE_FREE(pBuffer);	//CID-100718
			pBuffer = (BrBYTE*)BrMalloc(nBufferSize);
		}
		else if ( nBufferSize < nGlfySize )
		{
			nBufferSize = nGlfySize;
			pBuffer = (BrBYTE*)BrRealloc(pBuffer, nBufferSize);
		}
		memset(pBuffer, 0, nBufferSize);

		if (m_pFontFileStream.hasFile())
		{
			m_pFontFileStream.setPos(nPos + 2 * glfyLoc[i], nGlfySize);
			m_pFontFileStream.read(pBuffer, nGlfySize);
		}
		else
		{
			m_pFontStream.setPos(nPos + 2 * glfyLoc[i]);
			m_pFontStream.read(pBuffer, nGlfySize);
		}
		

		tableData.setPos(tOffSet*2);
		tableData.write((void*)pBuffer, nGlfySize);
		//memcpy(m_pTagTableData[eTable_glyf]+tOffSet*2, in_pGlyfData+2*glfyLoc[i], glfySize[i]*2);
		if (i > 0) // replace loca table
		{
			short bigEndiOffset = SWAPBrWORD(tOffSet);
			localData.setPos(2*i);
			localData << bigEndiOffset;
			//memcpy(m_pTagTableData[eTable_loca]+2*i, &bigEndiOffset, 2);
		}
		tOffSet += glfySize[i];
	}
	BrFree(pBuffer);
	BrULONG checkSum = CalcTableChecksum((BrBYTE*)tableData.getBuffer(), tableLength);
	m_pData << SWAPLONG(checkSum);
//	m_pOffsetTables[eTable_glyf].checkSum = SWAPLONG(CalcTableChecksum(m_pTagTableData[eTable_glyf], tableLength));
	m_pData.movePos(4);
	m_pData << SWAPLONG(tableLength*2);
	m_nEmbedDataSize += locaTblLength + tableLength*2;

	m_pData.setPos(eTable_loca * sizeof(TTableDir));
	m_pData.movePos(4);	
	checkSum = CalcTableChecksum((BrBYTE*)localData.getBuffer(), locaTblLength);
	m_pData << SWAPLONG(checkSum);
	//m_pOffsetTables[eTable_loca].checkSum = SWAPLONG(CalcTableChecksum(m_pTagTableData[eTable_loca], locaTblLength));

	if (glfyLoc)
	{
		BrFree(glfyLoc);
		glfyLoc = BrNULL;
	}
	//[14.05.09][sglee1206]	Coverity...
	if (glfySize)
	{
		BrFree(glfySize);
		glfySize = BrNULL;
	}
	return ret;
}



BrBOOL PDFFont::doExtractGlyfData(BrBYTE const * const in_pGlyfData)
{
	BrBOOL ret = BrTRUE;

	int nPos = 0;
	if (m_pFontFileStream.hasFile())
		nPos = m_pFontFileStream.getPos();
	else
		nPos = m_pFontStream.getPos();
	BrULONG tableLength = 0;
	//[14.05.09][sglee1206]	Coverity... Uninitialize
	BrDWORD *glfyLoc = BrNULL;
	BrDWORD *glfySize = BrNULL;
	
	// Loca Table
	m_pData.setPos(eTable_loca * sizeof(TTableDir));
	m_pData << SWAPLONG(TAG_ID_LOCA);
	//m_pOffsetTables[eTable_loca].tag = SWAPLONG(TAG_ID_LOCA);
	BrULONG locaTblLength = (m_nGlyfSize+1)*4;
	m_pTagTableData[eTable_loca] = (BrBYTE*)BrCalloc(locaTblLength, sizeof(BrBYTE));
	if(m_pTagTableData[eTable_loca] == BrNULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");
		return BrFALSE;
	}
	PoStream TagTableStream(m_pTagTableData[eTable_loca], locaTblLength);
	m_pData.movePos(8);
	m_pData << SWAPLONG(locaTblLength);	
	//m_pOffsetTables[eTable_loca].length = SWAPLONG(locaTblLength);	

	glfyLoc = (BrDWORD*)BrCalloc(locaTblLength,1);
	if(glfyLoc == BrNULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");

		BR_SAFE_FREE(m_pTagTableData[eTable_loca]);
		//m_pOffsetTables[eTable_loca].length = 0;

		return BrFALSE;
	}
	glfySize = (BrDWORD*)BrCalloc(locaTblLength,1);
	if(glfySize == BrNULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");

		BR_SAFE_FREE(m_pTagTableData[eTable_loca]);
		//m_pOffsetTables[eTable_loca].length = 0;

		BrFree(glfyLoc);

		return BrFALSE;
	}

	BrINT glyfIndex;
	BrDWORD curLoc, nextLoc;

	if (m_nGlyphCount == 0)
	{
		if ( ePDF_TEXT_TYPE_NORMAL <m_eExportTextType && m_eExportTextType < ePDF_TEXT_TYPE_MAX)
		{
			glyfIndex = 0;
			m_LocaStream.setPos(4*glyfIndex);
			m_LocaStream >> curLoc;
			//memcpy(&curLoc, m_pLocaData+4*glyfIndex, 4);
			curLoc = SWAPLONG(curLoc);

			m_LocaStream >> nextLoc;
			//memcpy(&nextLoc, m_pLocaData+4*(glyfIndex+1), 4);
			nextLoc = SWAPLONG(nextLoc);

			glfyLoc[0] = curLoc;
			glfySize[0] = nextLoc - curLoc;
		}
	}
	else
	{

		for (int i=0; i<m_nGlyphCount; i++)
		{
			if (i == 0)
			{
				glyfIndex = 0;
			}
			else {
				glyfIndex = m_pFontGlyphData[i-1];
			}

			m_LocaStream.setPos(4*glyfIndex);
			m_LocaStream >> curLoc;
			//memcpy(&curLoc, m_pLocaData+4*glyfIndex, 4);
			curLoc = SWAPLONG(curLoc);

			m_LocaStream >> nextLoc;
			//memcpy(&nextLoc, m_pLocaData+4*(glyfIndex+1), 4);
			nextLoc = SWAPLONG(nextLoc);

			glfyLoc[i] = curLoc;
			glfySize[i] = nextLoc - curLoc;
		}
	}


	// Composite Glyph
	int nComponentGlyphCount = 0;
	//[15.02.03][sglee1206] Polaris batang m_nGlyfSize�� 60000�̻��̹Ƿ� Short �� ��� ó�� ����.
	BrUSHORT *componentGlyphIndices = NULL;

	// Get component glyph indices
	for(int i = 0; i < m_nGlyphCount; i++)
	{
		TGlyphTable glyphHeader;
		if (m_pFontFileStream.hasFile())
		{
			m_pFontFileStream.setPos(nPos + glfyLoc[i]);
			m_pFontFileStream.read(&glyphHeader, BrSizeOf(TGlyphTable));
		}
		else
		{
			m_pFontStream.setPos(nPos + glfyLoc[i]);
			m_pFontStream.read(&glyphHeader, BrSizeOf(TGlyphTable));
			//memcpy(&glyphHeader, in_pGlyfData+glfyLoc[i], BrSizeOf(TGlyphTable));
		}
		
		glyphHeader.numberOfContours = SWAPBrWORD(glyphHeader.numberOfContours);
		if(glyphHeader.numberOfContours < 0) // Composite Glyph
		{
			BrSHORT flags = 1<<5; // MORE_COMPONENTS
			BrSHORT glyphIndex = 0;
			int glyphReadLoc = 0;
			glyphReadLoc += BrSizeOf(TGlyphTable);
			//[17.07.12][sglee1206] ���� �߰�. 0x20(1<<5) �� ��� MORE_COMPONENTS(Indicates at least one more glyph after this one.) 
			//���� Do While�� ó���Ͽ��� �ϳ� ��� 1�� �̻��� Glyph�� �����Ѵٴ� �����Ͽ� flags �ʱⰪ�� MORE_COMPONENTS�� �Ͽ� ó��
			while(glyphReadLoc < glfySize[i] && (flags & 1<<5))
			{
				if (m_pFontFileStream.hasFile())
				{
					m_pFontFileStream.setPos(nPos + glfyLoc[i] + glyphReadLoc);
					m_pFontFileStream >> flags;
				}
				else
				{
					m_pFontStream.setPos(nPos + glfyLoc[i] + glyphReadLoc);
					m_pFontStream >> flags;
					//memcpy(&flags, in_pGlyfData+glfyLoc[i] + glyphReadLoc, BrSizeOf(BrUSHORT));
				}
				
				flags = SWAPBrWORD(flags);
				glyphReadLoc += BrSizeOf(BrUSHORT);
				if (m_pFontFileStream.hasFile())
					m_pFontFileStream >> glyphIndex;
				else
					m_pFontStream >> glyphIndex;
				//memcpy(&glyphIndex, in_pGlyfData+glfyLoc[i] + glyphReadLoc, BrSizeOf(BrUSHORT));
				glyphIndex = SWAPBrWORD(glyphIndex);
				glyphReadLoc += BrSizeOf(BrUSHORT);
				if(flags & 1)
					glyphReadLoc += 2 * BrSizeOf(BrUSHORT);
				else
					glyphReadLoc += BrSizeOf(BrUSHORT);
				//glyphReadLoc += BrSizeOf(TCompositeGlyphDesc);

				//[15.11.24][sglee1206] Refer : http://www.microsoft.com/typography/otspec/glyf.htm
				if ( flags & (1<<3)/*WE_HAVE_A_SCALE*/ ) {
					glyphReadLoc += BrSizeOf(BrUSHORT);//F2Dot14  scale;    /* Format 2.14 */
				} else if ( flags & (1<<6)/*WE_HAVE_AN_X_AND_Y_SCALE*/ ) {
					glyphReadLoc += 2 * BrSizeOf(BrUSHORT);
					//F2Dot14  xscale;    /* Format 2.14 */
					//F2Dot14  yscale;    /* Format 2.14 */
				} else if ( flags & (1<<7)/*WE_HAVE_A_TWO_BY_TWO*/ ) {
					glyphReadLoc += 4 * BrSizeOf(BrUSHORT);
					//F2Dot14  xscale;    /* Format 2.14 */
					//F2Dot14  scale01;   /* Format 2.14 */
					//F2Dot14  scale10;   /* Format 2.14 */
					//F2Dot14  yscale;    /* Format 2.14 */
				}

				if(glyphIndex < 0)
				{
					//[15.02.03][sglee1206] Polaris batang m_nGlyfSize�� 60000�̻��̹Ƿ� Short �� ��� ó�� ���Ͽ� ���� ó��
					if((BrUSHORT)glyphIndex > m_nGlyfSize)
						continue;
				}
				bool isExisting = false;
				for(int k = 0; k < nComponentGlyphCount; k++)
				{
					if((BrUSHORT)glyphIndex == componentGlyphIndices[k])
					{
						isExisting = true;
						break;
					}
				}
				if(isExisting)
					continue;
				nComponentGlyphCount++;
#if 1
				if ( !componentGlyphIndices )
					componentGlyphIndices = (BrUSHORT*)BrMalloc(BrSizeOf(BrUSHORT) * nComponentGlyphCount);
				else
					componentGlyphIndices = (BrUSHORT*)BrRealloc(componentGlyphIndices, BrSizeOf(BrUSHORT) * nComponentGlyphCount);
#else
				BrUSHORT* tempIndices = NULL;
				if(nComponentGlyphCount - 1 > 0)
				{
					tempIndices = (BrUSHORT*)BrMalloc((nComponentGlyphCount - 1) * BrSizeOf(BrUSHORT));
					memcpy(tempIndices, componentGlyphIndices, BrSizeOf(BrUSHORT) * (nComponentGlyphCount - 1));
				}
				BrFree(componentGlyphIndices);
				componentGlyphIndices = (BrUSHORT*)BrMalloc(BrSizeOf(BrUSHORT) * nComponentGlyphCount);
				if(nComponentGlyphCount - 1 > 0)
				{
					memcpy(componentGlyphIndices, tempIndices, BrSizeOf(BrUSHORT) * (nComponentGlyphCount - 1));
					BrFree(tempIndices);
				}
#endif
				componentGlyphIndices[nComponentGlyphCount - 1] = (BrUSHORT)glyphIndex;
			}
		}
	}

	for (int i=0; i<m_nGlyfSize; i++)
	{
		glyfIndex = i;

		bool isExisting = false;
		for(int j = 0; j < m_nGlyphCount-1; j++)
		{
			if(m_pFontGlyphData[j] == glyfIndex)
			{
				isExisting = true;
				break;
			}
		}
		for(int j = 0; j < nComponentGlyphCount; j++)
		{
			if(componentGlyphIndices[j] == glyfIndex)
			{
				isExisting = true;
				break;
			}
		}

		m_LocaStream.setPos(4*glyfIndex);
		m_LocaStream >> curLoc;
		//memcpy(&curLoc, m_pLocaData+4*glyfIndex, 4);
		curLoc = SWAPLONG(curLoc);

		m_LocaStream >> nextLoc;
		//memcpy(&nextLoc, m_pLocaData+4*(glyfIndex+1), 4);
		nextLoc = SWAPLONG(nextLoc);

		TagTableStream.setPos(4*i);
		TagTableStream << curLoc;
		//memcpy(m_pTagTableData[eTable_loca]+4*i, &curLoc, 4);
		glfyLoc[i] = curLoc;
		glfyLoc[i+1] = nextLoc;
		glfySize[i] = nextLoc - curLoc;
		// glyph 0 ��°(undefied)�� �׻� �⺻ ž���Ѵ�.
		// ���극�� ��Ÿ ���ÿ����� ��� glyph�� �⺻ž���ϰ� ����.
		if(i != 0)// && getExportTextType() != ePDF_TEXT_TYPE_UCS4)
		{
			//������ ����� ��Ʈ�� ��� glyph 0 ��°(undefied)�� �������� ���� �� �����Ƿ� 1��° glyph�� ���ؼ� ó���ϵ��� �߰�
			if(!isExisting && tableLength != 0)
				glfySize[i] = 0;
		}
		tableLength += glfySize[i];	
	}
	BrFree(componentGlyphIndices);
	BrDWORD endianLength = SWAPLONG(tableLength);
	if ( m_nGlyfSize+1 > m_nGlyphCount )
	{
		TagTableStream.setPos(4*m_nGlyphCount);
		TagTableStream << endianLength;
		//memcpy(m_pTagTableData[eTable_loca]+4*m_nGlyphCount, &endianLength, 4);
	}

	// Offset Table - Glyf Table
	m_pData.setPos(eTable_glyf * sizeof(TTableDir));
	m_pData << SWAPLONG(TAG_ID_GLYF);
	//m_pOffsetTables[eTable_glyf].tag = SWAPLONG(TAG_ID_GLYF);
	//m_pOffsetTables[eTable_glyf].length = SWAPLONG(tableLength);
	/////////////////////////////////////////////////////
	m_pTagTableData[eTable_glyf] = (BrBYTE*)BrMalloc(tableLength);
	BrINT tOffSet = 0;

	for (int i=0; i<=m_nGlyfSize; i++)
	{
		if (m_pFontFileStream.hasFile())
		{
			m_pFontFileStream.setPos(nPos + glfyLoc[i], glfySize[i]);
			m_pFontFileStream.read(m_pTagTableData[eTable_glyf] + tOffSet, glfySize[i]);
		}
		else
		{
			m_pFontStream.setPos(nPos + glfyLoc[i]);
			m_pFontStream.read(m_pTagTableData[eTable_glyf] + tOffSet, glfySize[i]);
			//memcpy(m_pTagTableData[eTable_glyf]+tOffSet, in_pGlyfData+glfyLoc[i], glfySize[i]);
		}
		if (i > 0) // replace loca table
		{
			int bigEndiOffset = SWAPLONG(tOffSet);
			TagTableStream.setPos(4*i);
			TagTableStream << bigEndiOffset;
			//memcpy(m_pTagTableData[eTable_loca]+4*i, &bigEndiOffset, 4);
		}
		tOffSet += glfySize[i];
	}
	BrULONG checkSum = CalcTableChecksum(m_pTagTableData[eTable_glyf], tableLength);
	m_pData << SWAPLONG(checkSum);
	m_pData.movePos(4);
	m_pData << SWAPLONG(tableLength);
	//m_pOffsetTables[eTable_glyf].checkSum = SWAPLONG(CalcTableChecksum(m_pTagTableData[eTable_glyf], tableLength));
	m_nEmbedDataSize += locaTblLength + tableLength;


	//// replace loca table	
	//tOffSet = 0;
	//for (int i=1; i<m_nGlyphCount; i++)
	//{
	//
	//	tOffSet += glfySize[i-1];
	//	int bigEndiOffset = SWAPLONG(tOffSet);
	//	memcpy(m_pTagTableData[4]+4*i, &bigEndiOffset, 4);
	//}
	m_pData.setPos(eTable_loca * sizeof(TTableDir));
	m_pData.movePos(4);
	checkSum = CalcTableChecksum(m_pTagTableData[eTable_loca], locaTblLength);
	m_pData << SWAPLONG(checkSum);
	//m_pOffsetTables[eTable_loca].checkSum = SWAPLONG(CalcTableChecksum(m_pTagTableData[eTable_loca], locaTblLength));

	if (glfyLoc)
	{
		BrFree(glfyLoc);
		glfyLoc = BrNULL;
	}
	//[14.05.09][sglee1206]	Coverity...
	if (glfySize)
	{
		BrFree(glfySize);
		glfySize = BrNULL;
	}
	return ret;
}

BrBOOL PDFFont::doAnsiGlyfExtent(BrBYTE const * const in_pGlyfData)
{
	BrINT nWidth, glyfIndex;

	if (in_pGlyfData == BrNULL)
		return BrFALSE;

	for (int i = 0; i < ANSI_CODE_SIZE; i++)
	{
		glyfIndex = m_aAnsiCodeMap[i];
		nWidth = getGlyfExtent(in_pGlyfData, glyfIndex);
		m_aAnsiWidthArray[i] = nWidth * 1000 / m_nUnitsPerEm;
	}

	return BrTRUE;
}

BrINT PDFFont::getGlyfExtent(BrBYTE const * const in_pGlyfData, BrINT in_glyfIndex)
{
	TGlyphTable		*pGlyph = BrNULL;
	BrINT offset, len, width;

	offset = getLocOfGlyf(in_glyfIndex);
	len = getLocOfGlyf(in_glyfIndex+1) - offset;
	if(len == 0 )
		return	0;

	pGlyph = (TGlyphTable*)BrCalloc(abs(len), 1);
	memcpy((BYTE*)pGlyph, in_pGlyfData + offset, abs(len));

	width = SWAPBrWORD(pGlyph->xMax) - SWAPBrWORD(pGlyph->xMin);
	
	BrFree(pGlyph);
	pGlyph = BrNULL;
	return width;
}

BrINT PDFFont::getGlyfHeight(BrBYTE const* const in_pGlyfData, BrINT in_glyfIndex)
{
	TGlyphTable* pGlyph = BrNULL;
	BrINT offset, len, height;

	offset = getLocOfGlyf(in_glyfIndex);
	len = getLocOfGlyf(in_glyfIndex + 1) - offset;
	if (len == 0)
		return	0;

	pGlyph = (TGlyphTable*)BrCalloc(abs(len), 1);
	if (m_pFontFileStream.hasFile())
	{
		m_pFontFileStream.movePos(offset);
		m_pFontFileStream.read((BYTE*)pGlyph, abs(len));
	}
	else
	{
		m_pFontStream.movePos(offset);
		m_pFontStream.read((BYTE*)pGlyph, abs(len));
		//memcpy((BYTE*)pGlyph, in_pGlyfData + offset, abs(len));
	}
	

	height = SWAPBrWORD(pGlyph->yMax);// - SWAPBrWORD(pGlyph->yMin);

	BrFree(pGlyph);
	pGlyph = BrNULL;
	return height;
}

BrBOOL PDFFont::loadHheaTag()
{
	BrLONG ret = 0;
	THheaTable hheaData;

	ret = getTtfTagInfoEx(TAG_ID_HHEA, &hheaData, BrSizeOf(hheaData));
	if (ret == 0)
		return BrFALSE;

	m_nAscent		= (BrSHORT)SWAPBrWORD(hheaData.ascender) * 1000 / m_nUnitsPerEm;
	m_nDescent		= (BrSHORT)SWAPBrWORD(hheaData.descender) * 1000 / m_nUnitsPerEm;
	m_nNumberOfHMetrics = SWAPBrWORD(hheaData.numberLongMetric);
	

	if ( ePDF_TEXT_TYPE_NORMAL <m_eExportTextType && m_eExportTextType < ePDF_TEXT_TYPE_MAX)
	{
		// Offset Table
		BrULONG tableLength = ret, checkSum;
		m_pData.setPos(eTable_hhea * sizeof(TTableDir));
		m_pData << SWAPLONG(TAG_ID_HHEA);
		//m_pOffsetTables[eTable_hhea].tag = SWAPLONG(TAG_ID_HHEA);
		//m_pOffsetTables[eTable_hhea].length = SWAPLONG(tableLength);
		/////////////////////////////////////////////////////
		m_pTagTableData[eTable_hhea] = (BrBYTE*)BrMalloc(tableLength);
		memcpy(m_pTagTableData[eTable_hhea], &hheaData, BrSizeOf(hheaData));
		checkSum = CalcTableChecksum(m_pTagTableData[eTable_hhea], tableLength);
		m_pData << SWAPLONG(checkSum);
		m_pData.movePos(4);
		m_pData << SWAPLONG(tableLength);
		//m_pOffsetTables[eTable_hhea].checkSum = SWAPLONG(CalcTableChecksum(m_pTagTableData[eTable_hhea], tableLength));
		m_nEmbedDataSize += tableLength;
	}

	return BrTRUE;
}

BrBOOL PDFFont::loadHmtxTag()
{
	BrBOOL ret = BrTRUE;
	BrBYTE const * hmtxData = BrNULL;
	BrLONG dataLen = 0;

	hmtxData = (BrBYTE const *)getTtfTagInfo(TAG_ID_HMTX, dataLen);
	if (hmtxData == BrNULL)
		return BrFALSE;

	int nPos = 0;
	if (m_pFontFileStream.hasFile())
		nPos = m_pFontFileStream.getPos();
	else
		nPos = m_pFontStream.getPos();
	ret = doAnsiGlyfWidth(hmtxData);
	
	m_pWidths = (BrUINT16*)BrMalloc(BrSizeOf(BrUINT16)*m_nGlyfSize);
	for(int i = 0; i < m_nGlyfSize;i++)
	{
		if (m_pFontFileStream.hasFile())
			m_pFontFileStream.setPos(nPos);
		else
			m_pFontStream.setPos(nPos);
		
		if(i >= m_nNumberOfHMetrics)
			m_pWidths[i] = (BrUINT16)(getGlyfWidth(hmtxData, m_nNumberOfHMetrics-1))*1000/m_nUnitsPerEm;
		else
			m_pWidths[i] = (BrUINT16)(getGlyfWidth(hmtxData, i))*1000/m_nUnitsPerEm;
	}
	
	m_nStemV = 80; // m_aAnsiWidthArray[STEM_V_CODE-ANSI_START_CODE];

	if ( ePDF_TEXT_TYPE_NORMAL <m_eExportTextType && m_eExportTextType < ePDF_TEXT_TYPE_MAX)
	{
		// Offset Table

		BrULONG tableLength = dataLen, checkSum;//m_nGlyfSize*BrSizeOf(THmtxMetric);
		m_pData.setPos(eTable_hmtx * sizeof(TTableDir));
		m_pData << SWAPLONG(TAG_ID_HMTX);
		//m_pOffsetTables[eTable_hmtx].tag = SWAPLONG(TAG_ID_HMTX);
		//m_pOffsetTables[eTable_hmtx].length = SWAPLONG(tableLength);
		/////////////////////////////////////////////////////
		//[14.05.21][sglee1206] coverity Type ����
		BrLONG hIndex = 0;
		m_pTagTableData[eTable_hmtx] = (BrBYTE*)BrMalloc(tableLength);

		if (m_pFontFileStream.hasFile())
		{
			m_pFontFileStream.setPos(nPos);
			m_pFontFileStream.read(m_pTagTableData[eTable_hmtx], tableLength);
		}
		else
		{
			m_pFontStream.setPos(nPos);
			m_pFontStream.read(m_pTagTableData[eTable_hmtx], tableLength);
			//memcpy(m_pTagTableData[eTable_hmtx], hmtxData, tableLength);
		}
				
		checkSum = CalcTableChecksum(m_pTagTableData[eTable_hmtx], tableLength);
		m_pData << SWAPLONG(checkSum);
		m_pData.movePos(4);
		m_pData << SWAPLONG(tableLength);
		//m_pOffsetTables[eTable_hmtx].checkSum = SWAPLONG(CalcTableChecksum(m_pTagTableData[eTable_hmtx], tableLength));
		m_pData.movePos(4);
		m_pData << SWAPLONG(tableLength);
		m_nEmbedDataSize += tableLength;
	}

	hmtxData = BrNULL;

	return ret;
}

BrBOOL PDFFont::loadOtherTags()
{
	BrBOOL ret = BrTRUE;
	BrBYTE const * tableData = BrNULL;
	BrLONG dataLen = 0;

	BrINT removeTableCount = 3;	// cvt

	if(m_fontType != eXPDFFontOpenType)
		removeTableCount += eTable_MAX - eTable_CFF;

	BrUSHORT tableNum = EMBED_TABLE_COUNT - removeTableCount;

	tableData = (BrBYTE const* )getTtfTagInfo(TAG_ID_CVT, dataLen);
	if (tableData != BrNULL)
	{		
		// Offset Table
		BrULONG tableLength = dataLen, checkSum;
		m_pTagTableData[eTable_cvt] = (BrBYTE*)BrMalloc(tableLength);
		if (m_pFontFileStream.hasFile())
			m_pFontFileStream.read(m_pTagTableData[eTable_cvt], tableLength);
		else
			m_pFontStream.read(m_pTagTableData[eTable_cvt], tableLength);
		//memcpy(m_pTagTableData[eTable_cvt], tableData, tableLength);
		m_pData.setPos(eTable_cvt * sizeof(TTableDir));
		m_pData << SWAPLONG(TAG_ID_CVT);
		//m_pOffsetTables[eTable_cvt].tag = SWAPLONG(TAG_ID_CVT);
		//m_pOffsetTables[eTable_cvt].length = SWAPLONG(tableLength);
		checkSum = CalcTableChecksum(m_pTagTableData[eTable_cvt], tableLength);
		m_pData << SWAPLONG(checkSum);
		//m_pOffsetTables[eTable_cvt].checkSum = SWAPLONG(CalcTableChecksum(m_pTagTableData[eTable_cvt], tableLength));
		m_pData.movePos(4);
		m_pData << SWAPLONG(tableLength);
		/////////////////////////////////////////////////////
		m_nEmbedDataSize += tableLength;

		//[dwchun : 2014.02.18] : Memory Leak ����
		tableData = BrNULL;
		tableNum++;
	}
	else
	{
		//[dwchun : 2014.02.18] : Export�� �������� ���� ��Ʈ�Դϴ�.
		//[14.05.25][sglee1206] font�� ���� �������� �ʴ� ��쵵 ����
		//BRTHREAD_ASSERT(false);
		//return BrFALSE;
		m_nEmbedDataSize -= BrSizeOf(TTableDir);
	}

	tableData = (BrBYTE const *)getTtfTagInfo(TAG_ID_FPGM, dataLen);
	if (tableData != BrNULL)
	{		
		// Offset Table
		BrULONG tableLength = dataLen, checkSum;
		m_pTagTableData[eTable_fpgm] = (BrBYTE*)BrMalloc(tableLength);
		if (m_pFontFileStream.hasFile())
			m_pFontFileStream.read(m_pTagTableData[eTable_fpgm], dataLen);
		else
			m_pFontStream.read(m_pTagTableData[eTable_fpgm], dataLen);
		//memcpy(m_pTagTableData[eTable_fpgm], tableData, dataLen);
		m_pData.setPos(eTable_fpgm * sizeof(TTableDir));
		m_pData << SWAPLONG(TAG_ID_FPGM);
		//m_pOffsetTables[eTable_fpgm].tag = SWAPLONG(TAG_ID_FPGM);
		//m_pOffsetTables[eTable_fpgm].length = SWAPLONG(tableLength);
		checkSum = CalcTableChecksum(m_pTagTableData[eTable_fpgm], tableLength);
		m_pData << SWAPLONG(checkSum);
		//m_pOffsetTables[eTable_fpgm].checkSum = SWAPLONG(CalcTableChecksum(m_pTagTableData[eTable_fpgm], tableLength));
		m_pData.movePos(4);
		m_pData << SWAPLONG(tableLength);
		/////////////////////////////////////////////////////
		m_nEmbedDataSize += tableLength;

		//[dwchun : 2014.02.18] : Memory Leak ����
		tableData = BrNULL;
		tableNum++;
	}
	else
	{
		//[dwchun : 2014.02.18] : Export�� �������� ���� ��Ʈ�Դϴ�.
		//[14.05.25][sglee1206] font�� ���� �������� �ʴ� ��쵵 ����
		//BRTHREAD_ASSERT(false);
		//return BrFALSE;
		m_nEmbedDataSize -= BrSizeOf(TTableDir);
	}

	//memset(tableData, 0, dataLen);
	tableData = (BrBYTE const *)getTtfTagInfo(TAG_ID_PREP, dataLen);
	if (tableData != BrNULL)
	{
		// Offset Table
		BrULONG tableLength = dataLen, checkSum;
		m_pTagTableData[eTable_prep] = (BrBYTE*)BrMalloc(tableLength);
		if (m_pFontFileStream.hasFile())
			m_pFontFileStream.read(m_pTagTableData[eTable_prep], dataLen);
		else
			m_pFontStream.read(m_pTagTableData[eTable_prep], dataLen);
		//memcpy(m_pTagTableData[eTable_prep], tableData, dataLen);
		m_pData.setPos(eTable_prep * sizeof(TTableDir));
		m_pData << SWAPLONG(TAG_ID_PREP);
		//m_pOffsetTables[eTable_prep].tag = SWAPLONG(TAG_ID_PREP);
		//m_pOffsetTables[eTable_prep].length = SWAPLONG(tableLength);
		checkSum = CalcTableChecksum(m_pTagTableData[eTable_prep], tableLength);
		m_pData << SWAPLONG(checkSum);
		//m_pOffsetTables[eTable_prep].checkSum = SWAPLONG(CalcTableChecksum(m_pTagTableData[eTable_prep], tableLength));
		m_pData.movePos(4);
		m_pData << SWAPLONG(tableLength);
		/////////////////////////////////////////////////////
		m_nEmbedDataSize += tableLength;

		//[dwchun : 2014.02.18] : Memory Leak ����
		tableData = BrNULL;
		tableNum++;
	}
	else
	{
		//[dwchun : 2014.02.18] : Export�� �������� ���� ��Ʈ�Դϴ�.
		//[14.05.25][sglee1206] font�� ���� �������� �ʴ� ��쵵 ����
		//BRTHREAD_ASSERT(false);
		//return BrFALSE;
		m_nEmbedDataSize -= BrSizeOf(TTableDir);
	}

	m_nEmbed_Table_Count = tableNum;

	// offsetǥ���� ��ġ ���
	BrULONG nOffset = m_nEmbed_Table_Count * BrSizeOf(TTableDir) + TTF_HEADER_SIZE;
	BrDWORD tableLength;
	BrDWORD lengthOffset;

	for (int i=0; i<EMBED_TABLE_COUNT; i++)
	{
		if(m_pTagTableData[i] == BrNULL)
			continue;

		m_pOffsetTables[i].offset = SWAPLONG(nOffset);
		tableLength = SWAPLONG(m_pOffsetTables[i].length);
		// 4byte ũ�� ���߱�
		lengthOffset = tableLength % 4;
		if (lengthOffset == 1)
		{
			lengthOffset += 2;
		}
		m_nEmbedDataSize += lengthOffset;
		tableLength += lengthOffset;
		nOffset += tableLength;
	}

	return ret;

}
BrBOOL PDFFont::doAnsiGlyfWidth(BrBYTE const * const  in_pHmtxData)
{
	BrINT nWidth, glyfIndex, nLSB;
	BrBOOL bFixed = ((m_nFlags & 0x01) == 1)? BrTRUE : BrFALSE;

	if (in_pHmtxData == BrNULL)
		return BrFALSE;

	int nPos = 0;
	if (m_pFontFileStream.hasFile())
		nPos = m_pFontFileStream.getPos();
	else
		nPos = m_pFontStream.getPos();
	for (int i = 0; i < ANSI_CODE_SIZE; i++)
	{		
		glyfIndex = (bFixed == BrTRUE)? 0 : m_aAnsiCodeMap[i];
		if (m_pFontFileStream.hasFile())
			m_pFontFileStream.setPos(nPos);
		else
			m_pFontStream.setPos(nPos);
		nWidth = getGlyfWidth(in_pHmtxData, glyfIndex);
		
		if (m_pFontFileStream.hasFile())
			m_pFontFileStream.setPos(nPos);
		else
			m_pFontStream.setPos(nPos);
		nLSB = getLeftSideBearing(in_pHmtxData, glyfIndex);
		m_aAnsiWidthArray[i] = floor(0.5f + (nWidth) * 1000.0f / m_nUnitsPerEm);
	}

	return BrTRUE;
}

BrINT PDFFont::getLeftSideBearing(BrBYTE const * const in_pHmtxData, BrINT in_glyfIndex)
{	
	BrULONG value;// , valueTmp;
	BrINT lsb;

	if (m_pFontFileStream.hasFile())
	{
		m_pFontFileStream.movePos(sizeof(BrULONG) * in_glyfIndex);
		m_pFontFileStream >> value;
	}
	else
	{
		m_pFontStream.movePos(sizeof(BrULONG) * in_glyfIndex);
		m_pFontStream >> value;
		//valueTmp = ((BrULONG*)in_pHmtxData)[in_glyfIndex];
	}
	
	value = SWAPLONG(value);
	lsb = value & 0xFF;

	return lsb;
}

BrINT PDFFont::getGlyfWidth(BrBYTE const * const in_pHmtxData, BrINT in_glyfIndex)
{
	BrULONG value;// , valueTmp;
	BrINT width;

	if (m_pFontFileStream.hasFile())
	{
		m_pFontFileStream.movePos(sizeof(BrULONG) * in_glyfIndex);
		m_pFontFileStream >> value;
	}
	else
	{
		m_pFontStream.movePos(sizeof(BrULONG) * in_glyfIndex);
		m_pFontStream >> value;
		//valueTmp = ((BrULONG*)in_pHmtxData)[in_glyfIndex];
	}
	
	value = SWAPLONG(value);
	width = value >> 16;

	return width;
}

BrCHAR* PDFFont::getFontName()
{
	return m_szFontName;
}

XRect PDFFont::getBBox()
{
	float tmp;
	if(m_BBox.left >= m_BBox.right)
	{
		tmp = m_BBox.left;
		m_BBox.left = m_BBox.right;
		m_BBox.right = tmp;
	}
	if(m_BBox.top >= m_BBox.bottom)
	{
		tmp = m_BBox.top;
		m_BBox.top = m_BBox.bottom;
		m_BBox.bottom = tmp;
	}
	return m_BBox;
}

BrBYTE PDFFont::getType()
{
	return m_fontType;
}

BrULONG PDFFont::getFlags()
{
	return m_nFlags;
}

BrSHORT PDFFont::getAscent()
{
	return m_nAscent;
}

BrSHORT PDFFont::getDescent()
{
	return m_nDescent;
}

BrLONG PDFFont::getAngle()
{
	return m_nAngle;
}

BrSHORT PDFFont::getCapHeight()
{
	return m_nCapHeight;
}

BrINT PDFFont::getStemV()
{
	return m_nStemV;
}
BrINT PDFFont::getGlyfCount()
{
	return m_nGlyfSize;
}
//BrINT PDFFont::getAnsiWidthArray(BrINT* pWidth, BrINT& nCount)
//{
//	if (pWidth != NULL)
//	{
//		BrFree(pWidth);
//	}
//
//	nCount = ANSI_CODE_SIZE;
//	pWidth = (BrINT*)BrMalloc(BrSizeOf(m_aAnsiWidthArray));
//	memcpy(pWidth, m_aAnsiWidthArray, BrSizeOf(m_aAnsiWidthArray));
//
//	return nCount;
//}

BrINT PDFFont::getCharWidth(BrULONG nCode)
{
	if (nCode < ANSI_START_CODE || nCode > ANSI_LAST_CODE)
	{
		return 0;
	}

	int index = nCode - ANSI_START_CODE;
	BrINT width = m_aAnsiWidthArray[index];

	return width;
}

void PDFFont::setNumberOfGlyphs(BrINT count)
{
	m_nGlyphCount = count;
}

void PDFFont::setUnicodeData(BrULONG *unicodes, BrINT* pGlyphs, BrINT len)
{
	if(unicodes != BrNULL)
	{
		m_pUnicodeData = (BrULONG*)BrMalloc(BrSizeOf(BrULONG)*len);
		memcpy(m_pUnicodeData, unicodes, BrSizeOf(BrULONG)*len);
	}

	if(pGlyphs != BrNULL)
	{
		m_pFontGlyphData = (BrINT*)BrMalloc(BrSizeOf(BrINT)*len);
		memcpy(m_pFontGlyphData, pGlyphs, BrSizeOf(BrINT)*len);
	}
}
void PDFFont::setFontEncoding(BrCHAR* pszEncoding)
{
	memset(m_szEncoding, 0, sizeof(m_szEncoding));
	strncpy_s(m_szEncoding, sizeof(m_szEncoding), pszEncoding, strlen(pszEncoding));
	if (strcmp(m_szEncoding, "WinAnsiEncoding") == 0)
		m_fontType = eXPDFFontType1;
	else
		m_fontType = eXPDFCIDFontType2;
}

void PDFFont::setCIDSystemInfo(BrCHAR* pszRegistry, BrCHAR* pszOrdering, BrINT nSupplement)
{
	memset(m_pszRegistry, 0, sizeof(m_pszRegistry));
	memset(m_pszOrdering, 0, sizeof(m_pszOrdering));
	strncpy_s(m_pszRegistry, sizeof(m_pszRegistry), pszRegistry, strlen(pszRegistry));
	strncpy_s(m_pszOrdering, sizeof(m_pszOrdering), pszOrdering, strlen(pszOrdering));
	m_nSupplement = nSupplement;
}

void PDFFont::setExportTextFontFaceName( BrCHAR* fontFaceName )
{
	if(fontFaceName !=BrNULL)
	{
		if(m_pFontFaceName != BrNULL)
		{
			BrFree(m_pFontFaceName);
			m_pFontFaceName = BrNULL;
		}
		m_pFontFaceName = (BrCHAR *)BrCalloc(BrStrLen(fontFaceName)+1, BrSizeOf(BrCHAR));
		strncpy_s(m_pFontFaceName, BrStrLen(fontFaceName)+1, fontFaceName, strlen(fontFaceName));
	}
}

//void PDFFont::readData(void *out_pData, BrLONG in_Offset, BrLONG in_Len)
//{
//	memcpy( (BrBYTE*)out_pData, (BrBYTE*)m_pFontData + in_Offset, in_Len);
//}

BrWORD PDFFont::Cmap0GlyphIndex(TCmap0* ipCmap0, BrDWORD ilCode)
{
	if (ilCode >= 0x100)
		return 0;

	BrWORD glyphIndex = ipCmap0->glyphIndexArray[ilCode];

	return glyphIndex;
}

BrWORD PDFFont::Cmap2GlyphIndex(TCmap2* ipCmap2, BrDWORD ilCode)
{
	BrWORD		nHigh, nFirst, nCount, nIDDelta, nIDRanOff, nLow;
	BrWORD		lGlyphIndex = 0;

	if( ilCode > 0x10000)
		return	lGlyphIndex;
	nHigh = SWAPBrWORD( ipCmap2->subHeaderKeys[ilCode >> 8] )/8;
	nFirst = SWAPBrWORD( ipCmap2->subHeaders[nHigh].firstCode );
	nCount = SWAPBrWORD( ipCmap2->subHeaders[nHigh].entryCount );
	nIDDelta = SWAPBrWORD( ipCmap2->subHeaders[nHigh].idDelta );
	nIDRanOff = SWAPBrWORD( ipCmap2->subHeaders[nHigh].idRangeOffset );
	nLow = (BrWORD) (ilCode & 0xFF);

	if( (nFirst <= nLow) && (nLow < nFirst + nCount) ) {
		char	*lPtr = (char *) &ipCmap2->subHeaders[nHigh];

		// IdRangeOffset
		lPtr += BrSizeOf(nFirst) + BrSizeOf(nCount) + BrSizeOf(nIDDelta) + nIDRanOff;

		lGlyphIndex = SWAPBrWORD( ((BrWORD *) lPtr)[ nLow - nFirst] );

		if( lGlyphIndex )
			lGlyphIndex = lGlyphIndex + nIDDelta;
	}
	return	lGlyphIndex;
}

BrWORD PDFFont::Cmap4GlyphIndex( 
						  TCmap4*		ipCmap4,
						  BrDWORD			ilCode)
{
	BrWORD		nSeg, *pOffset, i;
	BrWORD		idDelta, idRangeOff;
	BrDWORD		endCode, startCode;
	BrWORD		lGlyphIndex = 0;

	if( ilCode > 0x10000)
		return	lGlyphIndex;
	nSeg = SWAPBrWORD( ipCmap4->segCountX2) / 2;
	pOffset = (BrWORD *) ((char*) ipCmap4 +BrSizeOf( TCmap4));
	for( i = 0; i < nSeg-1; i++ ) {				// except 0xFFFF.

		startCode = (BrDWORD) SWAPBrWORD( pOffset[i + nSeg + 1]);
		if( ilCode < startCode)
			break;
		endCode = (BrDWORD) SWAPBrWORD( pOffset[i]);
		if( i > 105)
			idDelta = 0;

		if( ilCode >= startCode && ilCode <= endCode)	{
			idDelta = SWAPBrWORD( pOffset[i + nSeg*2 + 1]);
			idRangeOff = SWAPBrWORD( pOffset[i + nSeg*3 + 1]);
			lGlyphIndex = (BrWORD) (( ilCode + idDelta - 1) & 0xFFFF);
			if( idRangeOff == 0 )
				lGlyphIndex++;
			else	{
				BrWORD	*pTemp;

				pTemp = (USHORT*)( idRangeOff/2 + (ilCode-startCode) + &pOffset[i + nSeg*3 + 1]);
				lGlyphIndex = SWAPBrWORD(*pTemp);
			}
			break;
		}
	}
	return	lGlyphIndex;
}

BrWORD PDFFont::Cmap6GlyphIndex( 
						  TCmap6*		ipCmap6,
						  BrDWORD			ilCode)
{
	BrWORD		nIndex;
	BrWORD		lGlyphIndex = 0;

	if( ilCode > 0x10000)
		return	lGlyphIndex;
	if( 0xFFFF == SWAPBrWORD( ipCmap6->firstCode))
		return	lGlyphIndex;

	nIndex = (BrWORD)(ilCode - SWAPBrWORD(ipCmap6->firstCode));

	if( nIndex < SWAPBrWORD( ipCmap6->entryCount))
		lGlyphIndex = SWAPBrWORD(ipCmap6->glyphIndexArray[nIndex] );
	return lGlyphIndex;
}

BrWORD PDFFont::Cmap8GlyphIndex( 
						  TCmap8*		ipCmap8,
						  BrDWORD			ilCode)
{
	BrDWORD		i, lNumSub, lStart, lEnd, lStartGI, lNumGlyph;
	BrDWORD		lHigh, lLow;
	BYTE		*pIS32;
	BrWORD		lGlyphIndex = 0;

	lNumSub = SWAPLONG( ipCmap8->numGroups);
	pIS32 = (BYTE*) &(ipCmap8->is32);

	for( i = 0; i < lNumSub; i++ ) {
		lStart		= SWAPLONG( ipCmap8->subs[i].startCharCode);
		lEnd		= SWAPLONG( ipCmap8->subs[i].endCharCode);
		lStartGI	= SWAPLONG( ipCmap8->subs[i].startGlyphIndex);
		lNumGlyph	= lEnd - lStart + 1;

		for( ; lNumGlyph > 0; lNumGlyph--, lStart++ ) {
			lHigh = lStart >> 16;
			lLow = lStart & 0xFFFF;

			if( lHigh == 0 ) {
				if ( (pIS32[lLow >> 3] & (0x80 >> (lLow & 7))) == 0 )
					lGlyphIndex = (BrWORD) (lStartGI + (ilCode - lStart));
			}
			else {
				if( ((pIS32[lHigh >> 3] & (0x80 >> (lHigh & 7))) != 0) &&
					((pIS32[lLow >> 3] & (0x80 >> (lLow & 7))) != 0) )
					lGlyphIndex = (BrWORD) (lStartGI + (ilCode - lStart));
			}
		}
	}
	return lGlyphIndex;
}

BrWORD PDFFont::Cmap10GlyphIndex( 
						   TCmap10*		ipCmap10,
						   BrDWORD			ilCode)
{
	BrDWORD		lCount, lStart;
	BrWORD		lGlyphIndex = 0;

	lStart = SWAPLONG( ipCmap10->startCharCode);
	if( ilCode >= lStart)	{
		lCount = ilCode - lStart;
		if( lCount < (BrDWORD)SWAPLONG( ipCmap10->numChars) )
			lGlyphIndex = SWAPBrWORD( (ipCmap10->glyphs)[ lCount] );
	}
	return	lGlyphIndex;
}

BrWORD PDFFont::Cmap12GlyphIndex( 
						   TCmap12*		ipCmap12,
						   BrDWORD			ilCode)
{
	BrDWORD		i, lStart;
	BrWORD		lGlyphIndex = 0;

	for( i = 0; i < (BrDWORD)SWAPLONG( ipCmap12->nGroup); i++ ) {
		lStart	= SWAPLONG( ipCmap12->groups[i].startCharCode);
		if( lStart > ilCode)
			break;
		if( lStart <= ilCode && (BrDWORD)SWAPLONG( ipCmap12->groups[i].endCharCode) >= ilCode) {
			//lGlyphIndex = (BrWORD) SWAPLONG( ipCmap12->groups[i].startGlyphIndex + (ilCode - lStart));
			lGlyphIndex = (BrWORD) SWAPLONG( ipCmap12->groups[i].startGlyphIndex) + (ilCode - lStart);
			break;
		}
	}
	return	lGlyphIndex;
}

void ReverseBuffer(BrUSHORT* pBuf, BrUSHORT bufLen)
{
	if (pBuf == BrNULL || bufLen == 0)
		return;

	for (int i = 0; i < bufLen; i++)
	{
		pBuf[i] = SWAPBrWORD(pBuf[i]);
	}
}

#endif//#ifdef EXPORT_PDF