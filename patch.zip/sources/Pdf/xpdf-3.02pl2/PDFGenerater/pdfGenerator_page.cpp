#include <OfficePreCompPDF.hpp>

#ifdef EXPORT_PDF

#include "goo/GString.h"
#include "xpdf/config.h"
#include "xpdf/Page.h"
#include "xpdf/GlobalParams.h"
#include "xpdf/Catalog.h"
//#include "xpdf/Stream.h"
#include "xpdf/XRef.h"
//#include "xpdf/OutputDev.h"
#include "xpdf/Error.h"
#include "xpdf/ErrorCodes.h"
#include "xpdf/PDFDoc.h"

#include "pdfGenerator.h"
#include "encoders/pdfEncoder.h"
#include "encoders/pdfFlateEncoder.h"
#include "XStream.h"

#include "pdfExportTextData.h"

#include "image/image.h"
char* XObjectName(int a_nNumber)
{
	GString* str = GString::format("FXX{0:d}", a_nNumber + 1);
	int len = str->getLength() + 1;

	char* pszName = (char*) BrMalloc(len * BrSizeOf(char));
	if (pszName == NULL)
	{
		BrDELETE str;
		SET_ERROR((PoError)kPoErrMemory, "");
		return NULL;
	}
	memset(pszName, 0, len);

	gmemcpy(pszName, str->getCString(), len);

	BrDELETE str;

	return pszName;
}

char* PatternObjectName(int a_nNumber)
{
	GString* str = GString::format("P{0:d}", a_nNumber + 1);
	int len = str->getLength() + 1;

	char* pszName = (char*) BrMalloc(len * BrSizeOf(char));
	if (pszName == NULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");
		BrDELETE str;
		return NULL;
	}
	memset(pszName, 0, len);

	gmemcpy(pszName, str->getCString(), len);

	BrDELETE str;

	return pszName;
}

char* FontObjectName(int a_nNumber)
{
	GString* str = GString::format("FXF{0:d}", a_nNumber);
	int len = str->getLength() + 1;

	char* pszName = (char*) BrMalloc(len * BrSizeOf(char));
	if (pszName == NULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");
		BrDELETE str;
		return NULL;
	}
	memset(pszName, 0, len);

	gmemcpy(pszName, str->getCString(), len);

	BrDELETE str;

	return pszName;
}

char* GSObjectName(int a_nNumber)
{
	GString* str = GString::format("FXE{0:d}", a_nNumber);
	int len = str->getLength() + 1;

	char* pszName = (char*) BrMalloc(len * BrSizeOf(char));
	if (pszName == NULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");
		BrDELETE str;
		return NULL;
	}
	memset(pszName, 0, len);

	gmemcpy(pszName, str->getCString(), len);

	BrDELETE str;

	return pszName;
}
int	PDFGenerator::GetPageRect(int a_nPageIndex, XRect* a_pRect)
{
	// 1. Check error condition
	if (a_nPageIndex < 0 || a_nPageIndex > m_nPageCount || a_pRect == NULL)
		return errInvalidParameter;

	Object* pPage = (Object*)m_ppObjects[m_pPageNumbers[a_nPageIndex]];
	if (pPage == NULL)
		return errBadCatalog;

	// 2. Get the rectangle of relevant page.
	Object oMediaBox;
	pPage->getDict()->lookupNF("MediaBox", &oMediaBox);
	if (!oMediaBox.isNull())
	{
		Object coord;
		oMediaBox.getArray()->get(0, &coord);
		a_pRect->left = coord.getReal();

		oMediaBox.getArray()->get(1, &coord);
		a_pRect->top = coord.getReal();

		oMediaBox.getArray()->get(2, &coord);
		a_pRect->right = coord.getReal();

		oMediaBox.getArray()->get(3, &coord);
		a_pRect->bottom = coord.getReal();

		oMediaBox.free();
		return errNone;
	}
	oMediaBox.free();

	// 3. If Mediabox entry don't exist in relevant page,
	// get the rectangle of parent page.
	Object oParent;
	pPage->getDict()->lookupNF("Parent", &oParent);
	if (!oParent.isNull())
	{
		Ref ref = oParent.getRef();
		Object* pParent = (Object*)m_ppObjects[ref.num];

		pParent->getDict()->lookupNF("MediaBox", &oMediaBox);
		if (!oMediaBox.isNull())
		{
			Object coord;
			oMediaBox.getArray()->get(0, &coord);
			a_pRect->left = coord.getReal();

			oMediaBox.getArray()->get(1, &coord);
			a_pRect->top = coord.getReal();

			oMediaBox.getArray()->get(2, &coord);
			a_pRect->right = coord.getReal();

			oMediaBox.getArray()->get(3, &coord);
			a_pRect->bottom = coord.getReal();

			oParent.free();
			oMediaBox.free();
			return errNone;
		}
		oParent.free();
		oMediaBox.free();
	}
	oParent.free();
	oMediaBox.free();

	return errDamaged;
}

int	PDFGenerator::ConvPageCoord(int a_nPageIndex, XRect* a_pSrcRect, XRect* a_pDstRect, BrPOINT* pRotAngleCTPos)
{
	int result;
	XRect pageRect;
	result = GetPageRect(m_nCurPage, &pageRect);

	float pageHeight = pageRect.bottom - pageRect.top;

	a_pDstRect->top		= pageHeight - a_pSrcRect->bottom;
	a_pDstRect->bottom	= pageHeight - a_pSrcRect->top;
	a_pDstRect->left	= a_pSrcRect->left;
	a_pDstRect->right	= a_pSrcRect->right;

	if(pRotAngleCTPos)
		pRotAngleCTPos->y = pageHeight - pRotAngleCTPos->y;
	return result;
}

int	PDFGenerator::ConvPageCoord(int a_nPageIndex, float& x, float& y, int y_delta)
{
	int result;
	XRect pageRect;

	result = GetPageRect(m_nCurPage, &pageRect);
	float pageHeight = pageRect.bottom - pageRect.top;
	y = pageHeight - y;// - y_delta;

	return result;
}

void PDFGenerator::SetUCS4Unicode(BrULONG *unicode, int length)
{
	if (length > 0 )
	{
		BrULONG space = 0x20;
		if( m_pExportData.GetSize() == m_nCurEmbeddedFont )
		{
			m_pExportData.Add(BrNEW PDFExportTextData());
			m_pExportData.at(m_nCurEmbeddedFont)->addText(&space, m_nIncIndex);
			m_pExportData.at(m_nCurEmbeddedFont)->addText(unicode, m_nIncIndex);
			m_pExportData.at(m_nCurEmbeddedFont)->setExportTextType(m_eTextType);
		}
		else
		{

			m_pExportData.at(m_nCurEmbeddedFont)->addText(&space, m_nIncIndex);
			m_pExportData.at(m_nCurEmbeddedFont)->addText(unicode, m_nIncIndex);
		}
	}
}

void PDFGenerator::SetGlyfIndexCode(BrULONG* pTextData, BrINT nFontIndex, int length)
{
	if (length > 0 )
	{
		BrULONG space = 0x20;
		if( m_pExportData.GetSize() == m_nCurEmbeddedFont )
		{
			m_pExportData.Add(BrNEW PDFExportTextData());
			m_pExportData.at(m_nCurEmbeddedFont)->addGylfIndex(pTextData, nFontIndex);
			m_pExportData.at(m_nCurEmbeddedFont)->setExportTextType(m_eTextType);
		}
		else
		{
			m_pExportData.at(m_nCurEmbeddedFont)->addGylfIndex(pTextData, nFontIndex);
		}
	}
}

int		PDFGenerator::GeneratePage(int a_nPageIndex)
{
	BrINT errRet = errNone;
	if (a_nPageIndex >= m_nPageCount)
	{
		int * tmp = m_pPageNumbers;
		int oldCount = m_nPageCount;
		m_nPageCount += m_nPageCount;
		m_pPageNumbers = (int*)BrMalloc(m_nPageCount * BrSizeOf(int));
		if (m_pPageNumbers == NULL)
		{
			SET_ERROR((PoError)kPoErrMemory, "");
			return errMemoryNotEnough;
		}

		memcpy(m_pPageNumbers, tmp, BrSizeOf(int) * oldCount);
		memset(m_pPageNumbers+oldCount, 0, BrSizeOf(int) * (m_nPageCount-oldCount));

		BrFree(tmp);
		//return errBadPageNum;
	}

	Object pagesRef;
	pagesRef.initRef(m_nPagesObjNumber, 0);

	Object* pPage = BrNEW Object();
	if (pPage == NULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");
		return errMemoryNotEnough;
	}

	pPage->initDict((XRef*)NULL);

	Object *pType = BrNEW Object();
	if (pType == NULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");
		return errMemoryNotEnough;
	}
	pType->initName("Page");

	pPage->getDict()->add(XGetKey("Type"), pType);
	pPage->getDict()->add(XGetKey("Parent"), &pagesRef);

	BrDELETE pType;

	errRet = AddXRefEntry(pPage);
	m_pPageNumbers[m_nTotalPage] = m_nEntryIndex;
	//m_pEntries[m_pPageNumbers[a_nPageIndex]].gen = 0;
	//m_pEntries[m_pPageNumbers[a_nPageIndex]].type = xrefEntryUncompressed;
	//m_ppObjects[m_pPageNumbers[a_nPageIndex]] = pPage;

	m_nCurPage = a_nPageIndex;
	m_nFontObjectCount = 0;

	return errRet;
}

int		PDFGenerator::ProcessXStreamRawBuffer(XStream* a_pXStream)
{
	PDFEncoder* pEncoder = GetEncoder(a_pXStream->GetType());
	if (pEncoder == NULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");
		return errMemoryNotEnough;
	}

	ResetEncodeBuffer(a_pXStream->GetRawBufferLength());

	void*	pSrc = a_pXStream->GetRawBuffer();
	int		srcLen = a_pXStream->GetRawBufferLength();
	void*	pDest = m_pEncodeBuffer;
	unsigned int destLen = m_nEncodeBufferLen;

	if (0 != pEncoder->Encode(pDest, &destLen, pSrc, srcLen))
		return errFailToEncodeBuffer;

	a_pXStream->SetStreamBuffer(pDest, destLen);

	return 0;
}

int		PDFGenerator::CompletePage(int a_nPageIndex)
{
	int errRet = errNone;
	if (a_nPageIndex >= m_nPageCount)
		return errBadPageNum;

	if (m_ppObjects == BrNULL)
		return errMemoryNotEnough;

	Object* pPage = (Object*) m_ppObjects[m_pPageNumbers[a_nPageIndex]];
	if (pPage == NULL)
		return errBadCatalog;

	Object oContentsRef;
	ImageXStream* pContents = NULL;

	pPage->getDict()->lookupNF("Contents", &oContentsRef);
	if (!oContentsRef.isNull()){
		//return errNone; // contents�� ������ page�� ������ �ʴ� ���� �ƴ� �� page�� �ǵ��� ����

		pContents = (ImageXStream*)m_ppObjects[oContentsRef.getRef().num];
		if (pContents == NULL)
		{
			oContentsRef.free();
			return errDamaged;
		}

		// Write Contents Obj 
		if (0 != ProcessXStreamRawBuffer(pContents))
		{
			oContentsRef.free();
			return errFailToEncodeBuffer;
		}

		Ref ref;
		ref.num = oContentsRef.getRef().num;
		ref.gen = oContentsRef.getRef().gen;

		Guint offset;
		errRet = WriteStream(pContents, &ref, m_pOutStream, &offset);
		m_pbWrited[ref.num] = true;
		m_pEntries[ref.num].offset = offset;
		if(errRet != errNone)
		{
			oContentsRef.free();
			return errRet;
		}
	}

	Object kids;
	Object* pPages = ((Object*)m_ppObjects[m_nPagesObjNumber]);

	pPages->getDict()->lookup("Kids", &kids);

	if(kids.isNull()){
		kids.initArray((XRef*)NULL);
	}

	Object oRef;
	oRef.initRef(m_pPageNumbers[m_nTotalPage++], 0);
	kids.getArray()->add(&oRef);
	pPages->getDict()->set("Kids", &kids);
	//pPages->getDict()->remove("Kids");
	//pPages->getDict()->add(XGetKey("Kids"), &kids);

	// Transparency Group

	/*Object* group = BrNEW Object();
	//if (group == NULL)
	//{
	//	g_BoraThreadAtom.m_nErrorCode = kPoErrMemory;
	//	ERR_TRACE(kPoErrMemory);
	//	return errMemoryNotEnough;
	//}

	group->initDict((XRef*)NULL);
	{
		Object oName;
		oName.initName("Group");
		group->getDict()->add(XGetKey("Type"), &oName);

		Object oName1;
		oName.initName("Transparency");
		group->getDict()->add(XGetKey("S"), &oName);

		Object oName2;
		oName.initName("DeviceRGB");
		group->getDict()->add(XGetKey("CS"), &oName);
	}
	pPage->getDict()->add(XGetKey("Group"), group);
*/
	Object oResoucesDict;

	pPage->getDict()->lookupNF("Resources", &oResoucesDict);
	if (oResoucesDict.isNull())
	{
		oResoucesDict.initDict((XRef*)NULL);
		pPage->getDict()->add(XGetKey("Resources"), &oResoucesDict);
		oResoucesDict.getDict()->incRef();
	}

	//// Check Default Font 
	//{
	//	Object oResoucesDict;

	//	pPage->getDict()->lookupNF("Resources", &oResoucesDict);
	//	if (oResoucesDict.isNull())
	//		return errNone;


	//	Object oFontDict;
	//	Object* pFont;
	//	oResoucesDict.getDict()->lookupNF("Font", &oFontDict);
	//	if (oFontDict.isNull())
	//	{
	//		oFontDict.initDict((XRef*)NULL);
	//		oResoucesDict.getDict()->add("Font", &oFontDict);
	//		
	//		pFont = GenerateDefalutFont();

	//		Object oFontObjRef;
	//		char* pszFontObjName = FontObjectName(m_nFontObjectCount);
	//		oFontObjRef.initRef(m_nEntryIndex, 0);

	//		oFontDict.getDict()->add(pszFontObjName, &oFontObjRef);
	//	}
	//}

	if (pContents != NULL)
		BrDELETE pContents;
	oResoucesDict.free();
	//kids.free();
	oContentsRef.free();

	return errRet;
}


int		PDFGenerator::SetPageRect(int a_nPageIndex, XRect* a_pBox)
{
	if (a_nPageIndex >= m_nPageCount)
		return errBadPageNum;

	// 1. Media Box & Crop Box 
	Object* pPage = (Object*) m_ppObjects[m_pPageNumbers[a_nPageIndex]];
	if (pPage == NULL)
		return errBadCatalog;

	// 1.1 Media Box 
	Object oMediaBox;
	oMediaBox.initArray((XRef*)NULL);
	{
		Object coord;

		coord.initReal(a_pBox->left);
		oMediaBox.getArray()->add(&coord);

		coord.initReal(a_pBox->top);
		oMediaBox.getArray()->add(&coord);

		coord.initReal(a_pBox->right);
		oMediaBox.getArray()->add(&coord);

		coord.initReal(a_pBox->bottom);
		oMediaBox.getArray()->add(&coord);
	}
	pPage->getDict()->add(XGetKey("MediaBox"), &oMediaBox);

	// 1.2 Crop Box
	Object oCropBox;
	oCropBox.initArray((XRef*)NULL);
	{
		Object coord;

		coord.initInt(a_pBox->left);
		oCropBox.getArray()->add(&coord);

		coord.initInt(a_pBox->top);
		oCropBox.getArray()->add(&coord);

		coord.initInt(a_pBox->right);
		oCropBox.getArray()->add(&coord);

		coord.initInt(a_pBox->bottom);
		oCropBox.getArray()->add(&coord);

	}
	pPage->getDict()->add(XGetKey("CropBox"), &oCropBox);

	return errNone;
}

XStream*	PDFGenerator::GenerateContents(int type)
{
	XStream* pStream = NULL;

	//switch(type)
	//{
	//case IMAGE_TYPE:
	//	pStream = BrNEW ImageXStream(ePDF_ENCODE_FLATE);
	//	break;
	//case GRAPHICS_TYPE:
	//	XRect pageRect;
	//	GetPageRect(m_nCurPage, &pageRect);
	//	pStream = BrNEW GraphicsXStream(ePDF_ENCODE_FLATE, pageRect);
	//	break;
	//case TEXT_TYPE:
	//	pStream = BrNEW TextXStream(ePDF_ENCODE_FLATE);
	//	break;
	//}

	pStream = BrNEW XStream(ePDF_ENCODE_FLATE);

	if (pStream == NULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");
		return NULL;
	}

	if(AddXRefEntry(pStream, BrTRUE) == errNone)
		return pStream;

	BrDELETE pStream;
	return BrNULL;
}

int			PDFGenerator::AddContents(ImageXStream* a_pStream, char* a_pszImageName, int a_Angle, XRect* a_pRect, XRect* a_pClipRect, BrPOINT* pRotAngleCTPos)
{
	int result = errNone;
	if( !a_pClipRect )
	{
		// 1. Calculate the coordinate
		XRect coord;
		result = ConvPageCoord(m_nCurPage, a_pRect, &coord, pRotAngleCTPos);

		// 2.BMC
		if(result == errNone)
		result = a_pStream->BMC(m_nBMC++);

		// 3. Generate the operators and operands according to PDF spec.
		if(result == errNone)
			result = a_pStream->SaveGraphicsState();
		if(result == errNone)
			result = a_pStream->SetPosition(a_Angle, &coord, pRotAngleCTPos);
		if(result == errNone)
			result = a_pStream->DrawImage(a_pszImageName);
		if(result == errNone)
			result = a_pStream->RestoreGraphicsState();

		//4.EMC
		if(result == errNone)
			result = a_pStream->EMC();
	}
	else
	{
		// 1. Calculate the coordinate
		XRect coord;
		if(a_pClipRect)
		{
			XRect coord1;
			result = ConvPageCoord(m_nCurPage, a_pClipRect, &coord1);
			XRect pageRect;
			result = GetPageRect(m_nCurPage, &pageRect);
			if(result == errNone)
			result = a_pStream->Clip(a_Angle, &coord1);
		}

		// 2.BMC
		if(result == errNone)
			result = a_pStream->BMC(m_nBMC++);

		// 3. Generate the operators and operands according to PDF spec.
		if(result == errNone)
			result = a_pStream->SetFlat(1);
		if(result == errNone)
			result = ConvPageCoord(m_nCurPage, a_pRect, &coord, pRotAngleCTPos);
		if(result == errNone)
			result = a_pStream->SetPosition(a_Angle, &coord, pRotAngleCTPos);
		if(result == errNone)
			result = a_pStream->DrawImage(a_pszImageName);

		//4.EMC
		if(result == errNone)
			result = a_pStream->EMC();

		if(a_pClipRect)
			a_pStream->RestoreGraphicsState();
	}
	return result;
}

int	PDFGenerator::AddContents(TextXStream* a_pStream, LPBrUseFontInfo pFontInfo, BrBYTE nTextType, void* pText,  BrINT nTextLen, float x, float y, XRect* a_pRect, BrBYTE m_nFDFlag, LPBrCharGap pCharInterval)
{
	int result = errNone;

	// clip rect?
	if(a_pRect)
	{
		XRect coord;
		result = ConvPageCoord(m_nCurPage, a_pRect, &coord);
		a_pStream->SetClipRect(&coord);
	}

	// 0. BMC
	if(result == errNone)
	result = a_pStream->BMC(m_nBMC++);

	// 1. Set Font
	if(result == errNone)
	result = a_pStream->BeginText();

	// 1.1 Get the the object name of fontRef.
	Object* pPage = (Object*)m_ppObjects[m_pPageNumbers[m_nCurPage]];

	if (pPage == NULL)
		return errBadCatalog;

	Object oResoucesDict, oFontDict;

	Dict* pagedict = pPage->getDict();

	if(pagedict == BrNULL)
		return errBadCatalog;

	pagedict->lookupNF("Resources", &oResoucesDict);
	oResoucesDict.getDict()->lookupNF("Font", &oFontDict);

	Dict* dict = oFontDict.getDict();
	Object obj;
	BString fontObjName = "";
	if( dict )
	{
	for (int i = 0; i < dict->getLength(); i++) {
		dict->getVal(i, &obj);
		if (obj.getRefNum() == m_nCurFontRef) {
			fontObjName = dict->getKey(i);
				obj.free();
			break;
			}
			obj.free();
		}
		oFontDict.free();
	}
	oResoucesDict.free();

	if (fontObjName == "")
		return errInvalidParameter;

	// 1.2 Set the font info
	char pszFontObjName[16];
	memset(pszFontObjName, 0, BrSizeOf(pszFontObjName));
	memcpy(pszFontObjName, fontObjName.ascii(), fontObjName.length());

	if(result == errNone)
	result = a_pStream->SetFont(pszFontObjName, pFontInfo->nFontSize);
	if(result == errNone)
	result = a_pStream->SetFontStyle(pFontInfo->nFontSize,pFontInfo->nColor, pFontInfo->nBgColor,m_nFDFlag);

	// 3. Set Horizontal Scale
	//if (m_nTextScale != pFontInfo->nHorzScale || pFontInfo->nHorzScale == 0)
	if (pFontInfo->nHorzScale != 100)
	{
		m_nTextScale = pFontInfo->nHorzScale;
		if(result == errNone)
			result = a_pStream->SetHorzScale(m_nTextScale);	//Color���� ���� �����Ѵ�. Scale���� ������ DeviceRGB�� ���� ������ ��ħ
	}

	// 4. Set Color
	if(result == errNone)
	result = a_pStream->SetColor(pFontInfo->nColor, pFontInfo->nBgColor);

	// 5. Set Position
	m_nTextXScale = pFontInfo->fScaleX;
	if(result == errNone)
	result = ConvPageCoord(m_nCurPage, x, y, pFontInfo->nFontSize);
	if(result == errNone)
	result = a_pStream->SetPos(pFontInfo->nAngle, x, y, m_nTextXScale, m_nTextYScale, m_nFDFlag & 0x02);

	// 6. Set Text
	if(result == errNone)
	{
		if ( m_eTextType != ePDF_TEXT_TYPE_NORMAL )
		{
			result = a_pStream->SetTextW((BString*)pText,BrFALSE, pCharInterval);
		}
		else
		{
			if(m_bIsUnicode)
			{
				if(nTextType == eXPDFUniIndexTextType)
					result = a_pStream->SetTextIndex((BrUSHORT*)pText, nTextLen);
				else
					result = a_pStream->SetTextW((BString*)pText);			
			}
			else
			{
				result = a_pStream->SetText((char*)((BString*)pText)->data());
			}
		}
	}

	if(result == errNone)
	result = a_pStream->EndText();

	if(result == errNone)
	result = a_pStream->EMC();

	if(a_pRect)
		a_pStream->RestoreClipRect();

	return result;
}

XStream*	PDFGenerator::GenerateXObject(XBitmap* a_pBitmap, bool a_bHasAlpha)
{
	XStream* pXObject = NULL;

	pXObject = BrNEW XStream(ePDF_ENCODE_FLATE);
	if (pXObject == NULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");
		return NULL;
	}

	if(AddXRefEntry(pXObject, BrTRUE) != errNone)
	{
		BrDELETE pXObject;
		SET_ERROR((PoError)kPoErrMemory, "");
		return NULL;
	}

	//1. Type -> XObject
	{
		Object obj;

		obj.initName("XObject");
		pXObject->GetDict()->getDict()->add(XGetKey("Type"), &obj);
	}

	//2. Subtype -> Image
	{
		Object obj;

		obj.initName("Image");
		pXObject->GetDict()->getDict()->add(XGetKey("Subtype"), &obj);
	}

	//3. Width, Height
	{
		Object obj;

		obj.initReal(a_pBitmap->width);
		pXObject->GetDict()->getDict()->add(XGetKey("Width"), &obj);

		obj.initReal(a_pBitmap->height);
		pXObject->GetDict()->getDict()->add(XGetKey("Height"), &obj);
	}

	//4. ColorSpace 
	{
		Object obj;

		if (a_pBitmap->bytesPerPixel == 3)
			obj.initName("DeviceRGB");
		else
			obj.initName("DeviceGray");
		pXObject->GetDict()->getDict()->add(XGetKey("ColorSpace"), &obj);
	}

	//5. BitsPerComponent
	{
		Object obj;

		obj.initInt(8);
		pXObject->GetDict()->getDict()->add(XGetKey("BitsPerComponent"), &obj);
	}

	//6. Soft Mask
	if (a_bHasAlpha == true)
	{
		Object obj;
		obj.initRef(m_nEntryIndex - 1, 0);
		pXObject->GetDict()->getDict()->add(XGetKey("SMask"), &obj);
	}

	unsigned int destLen; 
	//7. Filter -> FlateDecode
	{
		PDFEncoder* pEncoder = GetEncoder(pXObject->GetType());
		unsigned int nSrcLen = a_pBitmap->bytesPerPixel * a_pBitmap->width * a_pBitmap->height;
		pEncoder->Reset();
		if(!ResetEncodeBuffer(nSrcLen))
		{
			BrDELETE pXObject;
			SET_ERROR((PoError)kPoErrMemory, "");
			return NULL;
		}

		destLen = m_nEncodeBufferLen;

		if (0 != pEncoder->Encode(m_pEncodeBuffer, &destLen, a_pBitmap->buffer, nSrcLen))
		{
			BrDELETE pXObject;
			return NULL;
		}

		pXObject->SetStreamBuffer(m_pEncodeBuffer, destLen);
	}

	return pXObject;
}

XStream* PDFGenerator::GenerateXObject(XImage* a_pImage)
{
	XStream* pXObject = NULL;
	EPDF_ENCODE_TYPE encodeType = ePDF_ENCODE_NONE;

	if (a_pImage->format == eXIMAGE_JPEG)
		encodeType = ePDF_ENCODE_DCT;
	else if (a_pImage->format == eXIMAGE_PNG || a_pImage->format == eXIMAGE_ALPHA)
		encodeType = ePDF_ENCODE_FLATE;
	else
		return NULL;

	pXObject = BrNEW XStream(encodeType);
	if (pXObject == NULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");
		return NULL;
	}

	if(AddXRefEntry(pXObject, BrTRUE) != errNone)
	{
		BrDELETE pXObject;
		SET_ERROR((PoError)kPoErrMemory, "");
		return NULL;
	}

	//1. Type -> XObject
	{
		Object obj;

		obj.initName("XObject");
		pXObject->GetDict()->getDict()->add(XGetKey("Type"), &obj);
	}

	//2. Subtype -> Image
	{
		Object obj;

		obj.initName("Image");
		pXObject->GetDict()->getDict()->add(XGetKey("Subtype"), &obj);
	}

	//3. Width, Height
	{
		Object obj;

		obj.initReal(a_pImage->width);
		pXObject->GetDict()->getDict()->add(XGetKey("Width"), &obj);

		obj.initReal(a_pImage->height);
		pXObject->GetDict()->getDict()->add(XGetKey("Height"), &obj);
	}

	//4. ColorSpace 
	{
		Object obj;

		switch (a_pImage->colorSpace)
		{
		case ePDF_COLORSPACE_RGB:
			{
				obj.initName("DeviceRGB");
			}
			break;

		case ePDF_COLORSPACE_GRAY:
			{
				obj.initName("DeviceGray");
			}
			break;
		}

		pXObject->GetDict()->getDict()->add(XGetKey("ColorSpace"), &obj);
	}

	//5. BitsPerComponent
	{
		Object obj;

		obj.initInt(8);
		pXObject->GetDict()->getDict()->add(XGetKey("BitsPerComponent"), &obj);
	}

	 //6. Soft Mask
	if (a_pImage->isHasAlpha == true)
	{
		Object obj;
		obj.initRef(m_nEntryIndex - 1, 0);
		pXObject->GetDict()->getDict()->add(XGetKey("SMask"), &obj);
	}

	//7. Filter -> FlateDecode
	{
		UINT destLen = a_pImage->length;
		void* buffer = a_pImage->buffer;
		if (encodeType == ePDF_ENCODE_FLATE)
		{
			BYTE* bmpBuffer = NULL;
			int result = -1, size = 0;

			PDFEncoder* pEncoder = GetEncoder(pXObject->GetType());
			pEncoder->Reset();
						
			switch (a_pImage->format)
			{
			case eXIMAGE_PNG:
				size = png_to_bitmap((BYTE*)a_pImage->buffer, a_pImage->length, bmpBuffer);
				ResetEncodeBuffer(size);
				destLen = m_nEncodeBufferLen;
//				if( size != -1 )
					result = pEncoder->Encode(m_pEncodeBuffer, &destLen, bmpBuffer, size);
				break;
			case eXIMAGE_ALPHA:
				{

					Object obj;

					obj.initArray((XRef*)NULL);
					{
						Object coord;

						coord.initInt(0);
						obj.getArray()->add(&coord);

						coord.initInt(0);
						obj.getArray()->add(&coord);

						coord.initInt(0);
						obj.getArray()->add(&coord);

					}

					pXObject->GetDict()->getDict()->add(XGetKey("Matte"), &obj);

				size = alpha_from_png((BYTE*)a_pImage->buffer, a_pImage->length, bmpBuffer);
				ResetEncodeBuffer(size);
				destLen = m_nEncodeBufferLen;
//				if( size != -1 )
					result = pEncoder->Encode(m_pEncodeBuffer, &destLen, bmpBuffer, size);
				}
				break;
			default:
				ResetEncodeBuffer(a_pImage->length);
				destLen = m_nEncodeBufferLen;
				if (result != pEncoder->Encode(m_pEncodeBuffer, &destLen, a_pImage->buffer, a_pImage->length))
				{
					return NULL;
				}
			}

			if (bmpBuffer != NULL)
				BrFree(bmpBuffer);

			if (result != 0)
				return NULL;

			buffer = m_pEncodeBuffer;
		}

		pXObject->SetStreamBuffer(buffer, destLen);
	}

	return pXObject;
}

XStream*	PDFGenerator::GeneratePattern(int a_nEntryIndex, int a_patternType, int a_paintType, int a_tilingType, XRect a_bbox, int a_xStep, int a_yStep, float a_mat[6], int nAngle)
{
	XStream* stream = BrNEW XStream(ePDF_ENCODE_FLATE);

	stream->GetDict()->initDict((XRef*)NULL);
	//Object* pPattern = BrNEW Object();

	//pPattern->initDict((XRef*)NULL);

	// Type 
	Object oType;
	oType.initName("Pattern");
	stream->GetDict()->getDict()->add(XGetKey("Type"), &oType);

	// Pattern Type
	Object oPatternType;
	oPatternType.initInt(a_patternType);
	stream->GetDict()->getDict()->add(XGetKey("PatternType"), &oPatternType);

	// Paint Type
	Object oPaintType;
	oPaintType.initInt(a_paintType);
	stream->GetDict()->getDict()->add(XGetKey("PaintType"), &oPaintType);

	// Tiling Type
	Object oTilingType;
	oTilingType.initInt(a_tilingType);
	stream->GetDict()->getDict()->add(XGetKey("TilingType"), &oTilingType);

	// BBox
	Object obj1, obj2;
	obj1.initArray((XRef*)NULL);
	obj1.arrayAdd(obj2.initReal(a_bbox.left));
	obj1.arrayAdd(obj2.initReal(a_bbox.top));
	obj1.arrayAdd(obj2.initReal(a_bbox.right));
	obj1.arrayAdd(obj2.initReal(a_bbox.bottom));
	stream->GetDict()->getDict()->add(XGetKey("BBox"), &obj1);

	// Matrix
	obj1.initArray((XRef*)NULL);
	for (int i = 0; i < 6; i++)
		obj1.arrayAdd(obj2.initReal(a_mat[i]));
	stream->GetDict()->getDict()->add(XGetKey("Matrix"), &obj1);

	// XStep
	Object oXStep;
	oXStep.initInt(a_xStep);
	stream->GetDict()->getDict()->add(XGetKey("XStep"), &oXStep);

	// YStep
	Object oYStep;
	oYStep.initInt(a_yStep);
	stream->GetDict()->getDict()->add(XGetKey("YStep"), &oYStep);

	// Resources
	//Object oResources;
	//oResources.initRef(a_nEntryIndex, 0);
	//stream->GetDict()->getDict()->add(XGetKey("Resources"), &oResources);

	Object oXObject;
	oXObject.initDict((XRef*)(NULL));
	Object oImage;
	oImage.initDict((XRef*)(NULL));
	Object oImageRef;
	oImageRef.initRef(a_nEntryIndex, 0);

	char * oXObjName = XObjectName(m_nXObjectCount);

	oImage.getDict()->add(XGetKey(oXObjName), &oImageRef);
	oXObject.getDict()->add(XGetKey("XObject"), &oImage);
	stream->GetDict()->getDict()->add(XGetKey("Resources"), &oXObject);

	Object oFilter;
	GString* str = BrNEW GString("FlateDecode");
	oFilter.initString(str);
	stream->GetDict()->getDict()->add(XGetKey("Filter"), &oFilter);

	BrINT ret = errNone;

	if(ret == errNone)
		ret = ((ImageXStream*)stream)->SaveGraphicsState();
	if(ret == errNone)
		ret = ((ImageXStream*)stream)->SetPosition(0, &a_bbox);
	if(ret == errNone)
		ret = ((ImageXStream*)stream)->DrawImage(oXObjName);
	if(ret == errNone)
		ret = ((ImageXStream*)stream)->RestoreGraphicsState();

	stream->SetStreamBuffer(stream->GetRawBuffer(), stream->GetRawBufferLength());
	if(ret == errNone)
		ret = AddXRefEntry(stream, BrTRUE);

	//[16.12.13] Coverity-22102
	BR_SAFE_FREE(oXObjName);

	if(ret != errNone)
	{
		BrDELETE stream;
		SET_ERROR((PoError)kPoErrMemory, "");
		return NULL;
	}
	m_nPatternCount++;

	return stream;
}

int PDFGenerator::GenerateCIDSet()
{
	int errRet = errNone;
	XStream* pStream = BrNEW XStream(ePDF_ENCODE_FLATE);
	if (pStream == NULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");
		return errMemoryNotEnough;
	}

	errRet = AddXRefEntry(pStream, BrTRUE);
	if(errRet != errNone)
	{
		BrDELETE pStream;
		return errRet;
	}

	// build the stream dictionary
	//1. Compress stream
	PDFEncoder* pEncoder = GetEncoder(pStream->GetType());

	if (0 != pEncoder->Encode(m_pExportData.at(m_nCurEmbeddedFont)->m_pEncodeCIDSetBuffer, &m_pExportData.at(m_nCurEmbeddedFont)->m_nEncodeCIDSetBufferLen, m_pExportData.at(m_nCurEmbeddedFont)->m_pCIDSetBuf, m_pExportData.at(m_nCurEmbeddedFont)->m_nCIDSetSize))
	{
		//[16.01.05][sglee1206] Encode error �� ���� Data Free ���� ����
		BR_SAFE_FREE(m_pExportData.at(m_nCurEmbeddedFont)->m_pCIDSetBuf);
		m_pExportData.at(m_nCurEmbeddedFont)->m_nCIDSetSize = 0;
		if(m_pExportData.at(m_nCurEmbeddedFont)->m_pEncodeCIDSetBuffer != NULL)
		{
			gfree(m_pExportData.at(m_nCurEmbeddedFont)->m_pEncodeCIDSetBuffer);
			m_pExportData.at(m_nCurEmbeddedFont)->m_pEncodeCIDSetBuffer = NULL;
		}
		m_pExportData.at(m_nCurEmbeddedFont)->m_nEncodeCIDSetBufferLen = 0;
		return errFailToEncodeBuffer;
	}
	pStream->SetStreamBuffer(m_pExportData.at(m_nCurEmbeddedFont)->m_pEncodeCIDSetBuffer, m_pExportData.at(m_nCurEmbeddedFont)->m_nEncodeCIDSetBufferLen);

	return errRet;
}

#endif // EXPORT_PDF
