#include <OfficePreCompPDF.hpp>
 
#ifdef EXPORT_PDF

#include "goo/GString.h"
#include "xpdf/config.h"
#include "xpdf/Page.h"
#include "xpdf/GlobalParams.h"
#include "xpdf/Catalog.h"
//#include "xpdf/Stream.h"
#include "xpdf/XRef.h"
//#include "xpdf/OutputDev.h"
#include "xpdf/Error.h"
#include "xpdf/ErrorCodes.h"
#include "xpdf/PDFDoc.h"
#include "xpdf/Decrypt.h"

#include "pdfGenerator.h"
#include "encoders/pdfEncoder.h"
#include "encoders/pdfFlateEncoder.h"
#include "XStream.h"

#include "pdfExportTextData.h"

#include "ThreadDefines_i.h"

#include "BFile.h"
#include "butil.h"
#include <time.h>

#include "xpdf/SecurityHandler.h"
#include "../security/OfficeCrypto/OfficeCryptoContainer.h"

//#define ENCODE_BUFFER_LENGTH		300000	-> XCommon.h�� �ű�
//#define ENCODE_BUFFER_LENGTH		800000

#define SIZE_PDFA_METADATA			2593

PDFGenerator::PDFGenerator()
{
	m_bComplete = false;

	m_pPageNumbers = NULL;

	m_nEntryIndex = 0;
	m_nEntryCount = 0;

	m_nTotalPage = 0;

	m_pEntries = NULL;
	m_ppObjects = NULL;
	m_pbXStream = NULL;

	m_fPDFVersion = 1.6f;

	m_pEncodeBuffer = NULL;
	m_nEncodeBufferLen = 0;

	m_pOutStream = NULL;
	m_pFileInfo = NULL;

	m_pbWrited = NULL;

	m_nXObjectCount = 0;
	m_nFontObjectCount = 0;
	m_nGSObjectCount = 0;
	m_nPatternCount = 0;

	m_nCurPage = -1;
	m_nCurFontRef = -1;
	m_fontArray.RemoveAll();
	m_bIsUnicode = false;
	m_nTextScale = 100;
	m_nTextXScale = m_nTextYScale = 1.0;

	m_eWritingMode = eXPDF_WRITING_LEFT_TO_RIGHT;

	memset(m_pEncoders, 0, BrSizeOf(m_pEncoders));

	m_nBMC = 0;
	m_nTreeRootRefNum = 0;
	m_nCatalogRefNum = 0;

	//[2012.09.17][ekaloss] Text ũ�⿡ ���� shadowOffset ũ�Ⱑ ������� �ʴ� ����.
	m_nShadowOffset = 0;
	
	m_FontnEntryIndex = 0;
	m_eTextType = ePDF_TEXT_TYPE_NORMAL;
	m_pExportData.RemoveAll();
	m_nCurEmbeddedFont = 0;
	m_nIncIndex = 0;

	m_EFFace = (PO_Face*)BrGetEMFamilyFontFace();
	m_poFullSetFont = (FullSetFont*)BrGetFullSetFontFace();
	m_Face = NULL;

	getSysFontFace();
	
	//[16.01.05][sglee1206] ������ Font Pool Index ������ ����Ǿ� ������ ���� ������
	//EG Print�� ���� PDF Export�� ������ �־ ������
	//Font Pool Index ������ ������ ����
	//m_Face[prev m_EFFace first] ~ m_Face[prev m_EFFace last], m_EFFace[first] ~ m_EFFace[last], m_poFullSetFont~, m_Face[post m_poFullSetFont] ...
	for(int i = 0; i < 6; i++)
	{
		m_FontPoolIndex[i] = -1;
	}

	if(m_Face != BrNULL)
	{
		int i = 0;
		if(m_Face[0]->nFontPoolIndex == 0)
		{
			m_FontPoolIndex[0] = m_Face[0]->nFontPoolIndex;
			m_FontPoolIndex[1] = m_Face[0]->nFontPoolIndex;
			for(i = 1; m_Face[i]; i++)
			{
				if(m_Face[i]->nFontPoolIndex == i)
				{
					m_FontPoolIndex[1] = m_Face[i]->nFontPoolIndex;
					continue;
				}
				else
					break;
			}
		}
		if(m_Face[i])
			m_FontPoolIndex[2] = m_Face[i]->nFontPoolIndex - i;
	}
	if(m_EFFace != BrNULL)
	{
		int lastIndex = eEF_MaxFontType;

		m_FontPoolIndex[3] = m_EFFace[0]->nFontPoolIndex;
		if(lastIndex > 0)
			m_FontPoolIndex[4] = m_EFFace[lastIndex -1]->nFontPoolIndex;
	}
	//[17.04.12][sglee1206] pEFTFont�� ���� �� fullset�� �������̹Ƿ� ����
	if(m_poFullSetFont != BrNULL)
		m_FontPoolIndex[5] =  m_poFullSetFont->pFullSet->nFontPoolIndex;

	//USE_EMFAMILY_HEADER_FONT�� ������� �ʴ� ���
	if(m_poFullSetFont == BrNULL && m_EFFace == BrNULL)
		m_FontPoolIndex[2] = 0;
	
	//Coverity 14784
	m_nPageCount = 0;

	m_nRootGeneration = 0;
	m_nRootNumber = 1;

	m_nPagesObjNumber = 0;
	m_nDocumentInfoNumber = 0;
	m_bFontEmbedded = false;
	m_xref = NULL;
	currentRef.num = 0; currentRef.gen = 0;
	dontUseFileKey = false;
}

PDFGenerator::~PDFGenerator()
{
	if(m_Face)
		free(m_Face);
	//int*		m_pPageNumbers;
	//XRefEntry*	m_pEntries;
	//Object**	m_ppObjects;

	BrFree(m_pPageNumbers);
	BrFree(m_pEncodeBuffer);
	m_pEncodeBuffer = NULL;
	BrFree(m_pEntries);

	if(m_pbWrited != BrNULL)
		for (int i = 0; i < m_nEntryCount; i++)
		{
			if(m_pbWrited[i] == false){
				if(m_pbXStream != BrNULL)
					if (m_pbXStream[i]){
						if(m_ppObjects != BrNULL){
							if(m_ppObjects[i]!= BrNULL){
							BrDELETE ((XStream*)m_ppObjects[i]);
							}
						}
					}
					else
					{
						Object* pObj = BrNULL;
						if(m_ppObjects != BrNULL)
							pObj = (Object*)m_ppObjects[i];
						if (pObj != NULL)
						{
							pObj->free();

							BrDELETE pObj;
						}
					}
			}
		}

	BrFree(m_pbWrited);
	BrFree(m_ppObjects);
	BrFree(m_pbXStream);

	for (int j = 0; j < 2; j ++)
	{
		if (m_pEncoders[j] != NULL)
			BrDELETE m_pEncoders[j];
	}

	if(m_pExportData.GetSize() > 0)
	{
		for(int idx = 0; idx < m_pExportData.GetSize() ; idx++)
			BrDELETE m_pExportData.at(idx);
		m_pExportData.RemoveAll();
	}

	BR_SAFE_DELETE(m_xref);
}

BrINT	 PDFGenerator::GetCurrentPageNum()
{ 
	return m_nCurPage; 
}

int		PDFGenerator::GenerateDocumentInfo(time_t createTime)
{
	int ret = errNone;
	Object* pDocInfo = BrNEW Object();
	if (pDocInfo == NULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");

		return errMemoryNotEnough;
	}

	pDocInfo->initDict((XRef*)NULL);

	Object objProducer;
	GString* str = BrNEW GString("Polaris PDF Viewer");
	if (str == NULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");
		return errMemoryNotEnough;
	}
	objProducer.initString(str);
	pDocInfo->getDict()->add(XGetKey("Producer"), &objProducer);

	{
		Object objCreator;
		GString* str = BrNULL;
		if (IsEditorMode(gpPaint) == EDITOR_WORD)
		{
			str = BrNEW GString("Polaris Word");
		}
		else if (IsEditorMode(gpPaint) == EDITOR_PPT)
		{
			str = BrNEW GString("Polaris Slide");
		}
		else if (IsEditorMode(gpPaint) == EDITOR_SHEET)
		{
			str = BrNEW GString("Polaris Sheet");
		}
		else
		{
			str = BrNEW GString("Polaris PDF Viewer");
		}
		
		if (str == NULL)
		{
			SET_ERROR((PoError)kPoErrMemory, "");
			return errMemoryNotEnough;
		}
		objCreator.initString(str);
		pDocInfo->getDict()->add(XGetKey("Creator"), &objCreator);
	}

	{
		Object obj;
		char szTitle[1024] = { 0, };
		char szAuthor[1024] = { 0, };
		char szModifiedBy[1024] = { 0, };
		char szAppName[1024] = { 0, };
		int  page = 0;
		int words = 0;
		bool bSavePreview = FALSE;
		BrGetSummaryData(szTitle, sizeof(szTitle), szAuthor, sizeof(szAuthor), szModifiedBy, sizeof(szModifiedBy), &page, &words, &bSavePreview, szAppName, sizeof(szAppName));

		BString str = CUtil::UTF8ToBString(szTitle);
		GString* value = BString2GString(&str);

		obj.initString(value);
		pDocInfo->getDict()->add(XGetKey("Title"), &obj);

		str = CUtil::UTF8ToBString(szAuthor);
		value = BString2GString(&str);

		obj.initString(value);
		pDocInfo->getDict()->add(XGetKey("Author"), &obj);
	}

	{
		Object obj;
		time_t timep = createTime != 0? createTime :time(NULL);
		struct tm* lt;
		struct tm* gt;
#ifdef _WIN32
		struct tm tmptimeinfo;
		localtime_s(&tmptimeinfo, &timep);
		lt = &tmptimeinfo;
#else
		lt = localtime(&timep);
#endif

#ifdef _WIN32	
		struct tm timeinfo_gm;
		errno_t err1 = gmtime_s(&timeinfo_gm, &timep);
		gt = &timeinfo_gm;
#else
		gt = gmtime(&timep);
#endif	

		BrSIZE_T len = 0;
		BrCHAR s[5] = { 0, };

		if (gt != BrNULL && lt != BrNULL)
		{
			int gmthour = lt->tm_hour - gt->tm_hour;
			int gmtmin = lt->tm_min - gt->tm_min;
			if (gmtmin < 0)
			{
				gmthour += 1;
				gmtmin += 60;
			}
			gmthour = gmthour <= -12 ? gmthour + 24 : gmthour; // �̷��� �ٲٴ°� �´��� ������ �� �𸣰ڴٸ� ���� �ѱ��� �´°� ����.

			// for info dict
			GString modDate("D:");
			/* Year YYYY */
			len = BrVTULONG(strftime(s, BrSizeOf(s), "%Y", lt));
			modDate.append(s, len);

			/* Month MM */
			len = BrVTULONG(strftime(s, BrSizeOf(s), "%m", lt));
			modDate.append(s, len);

			/* Day DD */
			len = BrVTULONG(strftime(s, BrSizeOf(s), "%d", lt));
			modDate.append(s, len);

			/* Hour HH */
			len = BrVTULONG(strftime(s, BrSizeOf(s), "%H", lt));
			modDate.append(s, len);

			/* Minute mm */
			len = BrVTULONG(strftime(s, BrSizeOf(s), "%M", lt));
			modDate.append(s, len);

			/* Second SS */
			len = BrVTULONG(strftime(s, BrSizeOf(s), "%S", lt));
			modDate.append(s, len);

			if (gmthour > 0)
				modDate.append('+');

			modDate.appendf("{0:02d}\'{1:02d}\'", gmthour, gmtmin);

			obj.initString(BrNEW GString(modDate.getCString()));
			pDocInfo->getDict()->add(XGetKey("CreationDate"), &obj);
			obj.initString(BrNEW GString(modDate.getCString()));
			pDocInfo->getDict()->add(XGetKey("ModDate"), &obj);
		}
	}

	ret = AddXRefEntry(pDocInfo);

	m_nDocumentInfoNumber = m_nEntryIndex;

	return ret;
}

void PDFGenerator::settingEncryptInfo(CryptAlgorithm encrypt)
{

	// �⺻ Encrpyt ���� Setting �� ����
	// [ /O , /U , /P ] �� ���� Setting
	Guchar passwordPad[32] = {
		0x28, 0xbf, 0x4e, 0x5e, 0x4e, 0x75, 0x8a, 0x41,
		0x64, 0x00, 0x4e, 0x56, 0xff, 0xfa, 0x01, 0x08,
		0x2e, 0x2e, 0x00, 0xb6, 0xd0, 0x68, 0x3e, 0x80,
		0x2f, 0x0c, 0xa9, 0xfe, 0x64, 0x53, 0x69, 0x7a
	};

	Object oAuthEvent;
	oAuthEvent.initName("DocOpen");

	Object oCFM;
	Object oLength;
	Object oLengthEncrypt;
	Object oRevision;
	Object oVersion;

	if (encrypt == cryptAES)
	{
		oCFM.initName("AESV2");
		oLength.initInt(16);

		oLengthEncrypt.initInt(128);
		oRevision.initInt(4);
		oVersion.initInt(4);
	}
	else if (encrypt == cryptAES256)
	{
		oCFM.initName("AESV3");
		oLength.initInt(32);

		oLengthEncrypt.initInt(256);
		oRevision.initInt(6);
		oVersion.initInt(5);
	}


	Object oStdCF;
	oStdCF.initDict(m_xref);

	oStdCF.dictSet("AuthEvent", &oAuthEvent);
	oStdCF.dictSet("CFM", &oCFM);
	oStdCF.dictSet("Length", &oLength);

	Object oCF;
	oCF.initDict(m_xref);
	oCF.dictSet("StdCF", &oStdCF);

	Object oEncryptMetadata;
	oEncryptMetadata.initBool(gTrue);

	Object oFilter;
	oFilter.initName("Standard");


	GString* nEmptyString;
	GString* nEmptyString2;

	nEmptyString = BrNEW GString((char*)passwordPad, 32);
	nEmptyString2 = BrNEW GString((char*)passwordPad, 32);

	Object oOwnerPassword;
	oOwnerPassword.initString(nEmptyString);

	Object oUserPassword;
	oUserPassword.initString(nEmptyString2);

	Object oPermission;

	oPermission.initInt(-1028);
	//(-3392) | (1<<3)| (1<<5)| (1<<8)

	Object oStmF;
	oStmF.initName("StdCF");

	Object oStrF;
	oStrF.initName("StdCF");

	Object oNewEncrypt;
	oNewEncrypt.initDict(m_xref);

	oNewEncrypt.dictSet("CF", &oCF);
	oNewEncrypt.dictSet("Filter", &oFilter);
	oNewEncrypt.dictSet("Length", &oLengthEncrypt);
	oNewEncrypt.dictSet("O", &oOwnerPassword);
	oNewEncrypt.dictSet("P", &oPermission);
	oNewEncrypt.dictSet("R", &oRevision);
	oNewEncrypt.dictSet("StmF", &oStmF);
	oNewEncrypt.dictSet("StrF", &oStrF);
	oNewEncrypt.dictSet("U", &oUserPassword);
	oNewEncrypt.dictSet("V", &oVersion);

	Ref RefEncrypt = m_xref->addIndirectObject(&oNewEncrypt);

	Object initObj;	
	m_xref->getEncryptDict()->dictSet("Encrypt", initObj.initRef(RefEncrypt.num, RefEncrypt.gen));
}
void PDFGenerator::settingPassword()
{
	OfficeCryptoContainer* crypto = OfficeCryptoContainer::GetInstance();

	BrAutoChar szPass = CUtil::convertBStringToChar(&crypto->GetReadPasswords(), CP_UTF8);
	BrAutoChar szUserPass = CUtil::convertBStringToChar(&crypto->GetWritePasswords(), CP_UTF8);

	GString* setUserPW = NULL;
	GString* setOwnerPW = NULL;
	if ( szPass.get() )
		setUserPW = BrNEW GString((const char*)szPass.get());
	if (szUserPass.get())
		setOwnerPW = BrNEW GString((const char*)szUserPass.get());
	if (setOwnerPW == NULL && setUserPW == NULL)
		return;
	
	////////////////////////////////////////////////////////////////////
	BrPDFEncryptInfo* info = crypto->getPDFEncryptInfo();
	CryptAlgorithm setCryptAlgo = (CryptAlgorithm)info->nAlgorithmLevel;

	// ���� PDF ��ȣȭ�� ��� RC4 �� Setting �� ������ �ϸ� ASE128 , ASE 256 �� �����Ѵ�.
	if (setCryptAlgo == cryptRC4)
		setCryptAlgo = cryptAES;

	XRef* xref = BrNEW XRef();
	m_xref = xref;	
	int setPrintOption = info->nPrintOption;
	int setEditorOption = info->nEditorOption;
	GBool ownerPasswordOk = false;
	char dateTime[30] = { 0, };
	char fileID[40] = { 0, };
	getCurrentDateTimeString(dateTime, sizeof(dateTime));
	//	getFileID(dateTime, fileID, sizeof(fileID));

	Decrypt::md5((Guchar*)dateTime, 16, (Guchar*)fileID);

	Object obj1, initObj;
	GString* temp = BrNEW GString((const char*)fileID, 16);
	obj1.initString(temp);

	initObj.initArray(NULL);
	initObj.arrayAdd(&obj1);

	xref->getEncryptDict()->initDict(xref);
	xref->getEncryptDict()->dictSet("ID", &initObj);
	////////////////////////////////////////////////////////////////////
	//if (bNewPassword == gFalse)
	//	return;

	//bNewPassword = gFalse;

	CryptAlgorithm encAlgorithm;
	CryptType nEncryptType = cryptNone;
	Ref ref;
	Object encrypt, ownerKeyObj, RefEncrypt;

	GBool encrypted;
	SecurityHandler* secHdlr;
	//	GBool ret;

	GString* nOwnerPW, * nUserPW;

	int nPermission = -1028; // Default Permission


	encAlgorithm = setCryptAlgo;


	// CryptTpye Setting
	//if (isEncrypted())
	//	nEncryptType = cryptChangePassword;
	//else
	nEncryptType = cryptNewPassword;

	// Encrypt ���� ��� ���� Set--PW �׸��� Null �� ��� Delete �� üũ
	//if (setOwnerPW == NULL && setUserPW == NULL)
	//	nEncryptType = cryptDeletePassword;


	if (nEncryptType == cryptNewPassword /*|| nEncryptType == cryptChangePassword*/)
	{
		// New Password �ϰ�� Encrpyt Setting
		if (nEncryptType == cryptNewPassword)
			settingEncryptInfo(encAlgorithm);

		if (setOwnerPW != NULL)
		{
			if (setPrintOption == BR_PDF_PRINT_NONE)
				nPermission = -3392; // BR_PDF_PRINT_NONE && BR_PDF_EDITOR_NONE
			else if (setPrintOption == BR_PDF_PRINT_LOW_RES)
				nPermission = -3388; // BR_PDF_PRINT_LOW_RES && BR_PDF_EDITOR_NONE
			else if (setPrintOption == BR_PDF_PRINT_HIGHT_RES)
				nPermission = -1340; // BR_PDF_PRINT_HIGHT_RES && BR_PDF_EDITOR_NONE

			if (setEditorOption == BR_PDF_EDITOR_ASSEMBLY)
				nPermission = nPermission | (1 << 10);
			else if (setEditorOption == BR_PDF_EDITOR_FORM)
				nPermission = nPermission | (1 << 8);
			else if (setEditorOption == BR_PDF_EDITOR_ANNOT_FORM)
				nPermission = nPermission | (1 << 5) | (1 << 8);
			else if (setEditorOption == BR_PDF_EDITOR_ACCESBILLY)
				nPermission = nPermission | (1 << 3) | (1 << 5) | (1 << 8);

		}
	}
	//else if (nEncryptType == cryptDeletePassword)
	//{

	//	xref->getEncryptDict()->dictLookup("Encrypt", &encrypt);
	//	xref->getEncryptDict()->dictLookupNF("Encrypt", &RefEncrypt);
	//	if (encrypt.isDict())
	//	{
	//		xref->setEncryptDelete();
	//		xref->getEncryptDict()->dictRemove("Encrypt");

	//		XRefEntry* entry = xref->getEntry(RefEncrypt.getRefNum());
	//		if (entry)
	//			entry->removed = BrTRUE;
	//	}

	//	return;
	//}

	xref->getEncryptDict()->dictLookup("Encrypt", &encrypt);
	xref->getEncryptDict()->dictLookupNF("Encrypt", &RefEncrypt);

	// Permission ���氪 Setting SecurityHandler Make �� Setting �� �ʿ��ϴ�
	if (setOwnerPW != NULL)
		encrypt.getDict()->set("P", obj1.initInt(nPermission));


	ref.num = RefEncrypt.getRefNum();
	ref.gen = RefEncrypt.getRefGen();

	// ����� Password Info Set Obj
	xref->setModifiedObject(&encrypt, ref);

	encrypted = encrypt.isDict();
	if (encrypted)
	{
		secHdlr = SecurityHandler::make(xref->getEncryptDict(), &encrypt);
		if (secHdlr)
		{
			if (encAlgorithm == cryptAES) // AES 128
			{
				nOwnerPW = secHdlr->newOwnerPW_AES128(setOwnerPW, setUserPW);
				nUserPW = secHdlr->newUserPW_AES128(setOwnerPW, setUserPW, nOwnerPW);

				encrypt.getDict()->set("O", obj1.initString(nOwnerPW));
				encrypt.getDict()->set("U", obj1.initString(nUserPW));
			}
			else if (encAlgorithm == cryptAES256)
			{
				// AES 256 Setting
				secHdlr->newAES256_Setting(setOwnerPW, setUserPW, nPermission);

				encrypt.getDict()->set("U", obj1.initString(secHdlr->getUserKey()->copy()));
				encrypt.getDict()->set("UE", obj1.initString(secHdlr->getUserEncKey()->copy()));

				encrypt.getDict()->set("O", obj1.initString(secHdlr->getOwnerKey()->copy()));
				encrypt.getDict()->set("OE", obj1.initString(secHdlr->getOwnerEncKey()->copy()));

				encrypt.getDict()->set("Perms", obj1.initString(secHdlr->getPerms()->copy()));
			}

			// ����� Password Info Set Obj
			xref->setModifiedObject(&encrypt, ref);

			BrDELETE secHdlr;
			secHdlr = BrNULL;

			secHdlr = SecurityHandler::make(xref->getEncryptDict(), &encrypt);
			if (secHdlr)
			{
				if (secHdlr->checkEncryption(setOwnerPW, setUserPW))
				{
					// authorization succeeded
					if (nEncryptType == cryptNewPassword)
					{
						ownerPasswordOk = secHdlr->getOwnerPasswordOk();
						xref->setEncryption(secHdlr->getPermissionFlags(),
							secHdlr->getOwnerPasswordOk(),
							secHdlr->getFileKey(),
							secHdlr->getFileKeyLength(),
							secHdlr->getEncVersion(),
							secHdlr->getEncRevision(),
							secHdlr->getEncAlgorithm(), nEncryptType);
					}
					else if (nEncryptType == cryptChangePassword)
						xref->setEncryptionNewFileKey(secHdlr->getFileKey(), secHdlr->getFileKeyLength(), nEncryptType);
				}
			}

			BrDELETE secHdlr;
		}
	}
	BR_SAFE_DELETE(setOwnerPW);
	BR_SAFE_DELETE(setUserPW);
}

int		PDFGenerator::GenerateDocument(int a_nPageCount, XRect* a_pRect, GString* a_pFileName, time_t createTime)
{
	int result = errNone;

	// default �� ����
	if(a_nPageCount <= 0)
		a_nPageCount = 10;

	// 1. Page count 
	m_nPageCount = a_nPageCount;
	//m_nCurPage = 0;

	// 2. Create XRef
	result = GenerateXRef();
	if (result)
		return result;

	// 3 generate Page Tree
	// 3.1 generate Catalog Dict
	Object* pCatalogDict = BrNEW Object();
	if (pCatalogDict == NULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");
		return errMemoryNotEnough;
	}

	pCatalogDict->initDict((XRef*)NULL);
	{
		Object oName;

		oName.initName("Catalog");
		pCatalogDict->getDict()->add(XGetKey("Type"), &oName);

		// set PageLayout to document
		Object oPageLayout;
		oPageLayout.initName("OneColumn");
		pCatalogDict->getDict()->add(XGetKey("PageLayout"), &oPageLayout);
	}
	
	if(AddXRefEntry(pCatalogDict) == errMemoryNotEnough)
	{
		BrDELETE pCatalogDict;
		SET_ERROR((PoError)kPoErrMemory, "");
		return errMemoryNotEnough;
	}
	m_nCatalogRefNum = m_nEntryIndex;

	// 3.2 generate Pages Dict
	Object* pPages = BrNEW Object();
	if (pPages == NULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");
		return errMemoryNotEnough;
	}

	pPages->initDict((XRef*)NULL);
	{
		Object oName;
		oName.initName("Pages");
		pPages->getDict()->add(XGetKey("Type"), &oName);

		Object oCount;
		oCount.initInt(a_nPageCount);
		pPages->getDict()->add(XGetKey("Count"), &oCount);

		//Object oMediaBox;
		//oMediaBox.initArray((XRef*)NULL);
		//{
		//	Object coord;

		//	coord.initReal(a_pRect->left);
		//	oMediaBox.getArray()->add(&coord);

		//	coord.initReal(a_pRect->top);
		//	oMediaBox.getArray()->add(&coord);

		//	coord.initReal(a_pRect->right);
		//	oMediaBox.getArray()->add(&coord);

		//	coord.initReal(a_pRect->bottom);
		//	oMediaBox.getArray()->add(&coord);
		//}
		//pPages->getDict()->add(XGetKey("MediaBox"), &oMediaBox);

	}
	if(AddXRefEntry(pPages) == errMemoryNotEnough)
	{
		BrDELETE pPages;
		BrDELETE pCatalogDict;
		SET_ERROR((PoError)kPoErrMemory, "");
		return errMemoryNotEnough;
	}

	// 3.2.1 malloc m_pPageNumbers
	m_pPageNumbers = (int*)BrMalloc(m_nPageCount * BrSizeOf(int));
	if (m_pPageNumbers == NULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");
		return errMemoryNotEnough;
	}

	memset(m_pPageNumbers, 0, BrSizeOf(int) * m_nPageCount);

	// 3.3 Add pagesRef to Catalog Dict
	Object pagesRef;
	pagesRef.initRef(m_nEntryIndex, 0);
	pCatalogDict->getDict()->add(XGetKey("Pages"), &pagesRef);
	m_nPagesObjNumber = m_nEntryIndex;

	// 3.4 generate pages kids
	//result = GenerateKids(pPages, &pagesRef);

	// 3.5 Add pagesRef to Catalog Dict
	/*Object* markInfo = BrNEW Object();
	if (markInfo == NULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");
		return errMemoryNotEnough;
	}
	*/
	Object markInfo;
	

	markInfo.initDict((XRef*)NULL);
	{
		Object marked;
		marked.initBool(true);

		markInfo.getDict()->add(XGetKey("Marked"), &marked);
	}
	pCatalogDict->getDict()->add(XGetKey("MarkInfo"), &markInfo);

	//4. Open File
	if(result == errNone)
		result = OpenFile(a_pFileName);

	// 5 Generate Document Info
	if(result == errNone)
		result = GenerateDocumentInfo(createTime);

	if (result == errNone)
		settingPassword();

	return result;
}

int PDFGenerator::GeneratePdfEntry(BrBOOL bPDFA, time_t createTime)
{
	Object*	pCatalogDict;
	Object*	pMetaDataDict;
	Object	obj;
	// Stream For MetaData Entry
	XStream*	pMetaHeadEntry = NULL;
	XStream*	pMetaDataEntry = NULL;
	BrINT		nTemp;
	BrCHAR*		pMetaHead;
	BrBYTE*		pMetaData;

	// m_nEntryIndex + 1	:		MetaData Dict
	// m_nEntryIndex + 2	:		MetaData Entry
	// m_nEntryIndex + 3	:		Stream

	{	// Catalog Dict
		pCatalogDict = (Object*)m_ppObjects[1];

		if (pCatalogDict == BrNULL)
			return errDamaged;

		if(bPDFA == BrTRUE)
		{
			// obj.initRef(m_nEntryIndex + 1, 0);	pCatalogDict->getDict()->add(XGetKey("OutputIntents"),	&obj);
			obj.initRef(m_nEntryIndex + 2, 0);	pCatalogDict->getDict()->add(XGetKey("Metadata"),		&obj);
		}
		else
		{
			obj.initRef(m_nEntryIndex + 1, 0);	pCatalogDict->getDict()->add(XGetKey("Metadata"),		&obj);
		}
	}
		
	if(bPDFA == BrTRUE)
	{	// MetaData Dict
		pMetaDataDict = BrNEW Object();

		if (pMetaDataDict == NULL)
		{
			SET_ERROR((PoError)kPoErrMemory, "");
			return errMemoryNotEnough;
		}

		pMetaDataDict->initDict((XRef*)NULL);

		obj.initName("OutputIntent");							pMetaDataDict->getDict()->add(XGetKey("Type"),						&obj);
		obj.initName("GTS_PDFA1");								pMetaDataDict->getDict()->add(XGetKey("S"),							&obj);
		obj.initString(BrNEW GString("sRGB IEC61966-2.1"));		pMetaDataDict->getDict()->add(XGetKey("Info"),						&obj);
		obj.initRef(m_nEntryIndex + 3, 0);						pMetaDataDict->getDict()->add(XGetKey("DestOutputProfile"),			&obj);
		obj.initString(BrNEW GString("sRGB"));					pMetaDataDict->getDict()->add(XGetKey("OutputConditionIdentifier"),	&obj);
		obj.initString(BrNEW GString("http://www.color.org"));	pMetaDataDict->getDict()->add(XGetKey("RegistryName"),				&obj);

		if(AddXRefEntry(pMetaDataDict) == errMemoryNotEnough)
		{
			SET_ERROR((PoError)kPoErrMemory, "");
			return errMemoryNotEnough;
		}
		Object	arrayObj;
		arrayObj.initArray((XRef*)NULL);
		obj.initRef(m_nEntryIndex, 0);	
		arrayObj.arrayAdd(&obj);
		pCatalogDict->getDict()->add(XGetKey("OutputIntents"),	&arrayObj);
	}

	{	// MetaHead Entry
		pMetaHeadEntry = BrNEW XStream(ePDF_ENCODE_FLATE);

		if (pMetaHeadEntry == NULL)
		{
			SET_ERROR((PoError)kPoErrMemory, "");
			return errMemoryNotEnough;
		}

		pMetaHeadEntry->GetDict()->dictRemove("Filter");
		pMetaHeadEntry->GetDict()->dictAdd(XGetKey("Type"),		obj.initName("Metadata"));
		pMetaHeadEntry->GetDict()->dictAdd(XGetKey("Subtype"),	obj.initName("XML"));


		pMetaHead = (BrCHAR*)BrCalloc(1024 * 3, sizeof(BrCHAR));
		nTemp = GenerateXPacket(pMetaHead, 1024 * 3, bPDFA, createTime);

		pMetaHeadEntry->SetStreamBuffer(pMetaHead, nTemp, true);

		if(AddXRefEntry(pMetaHeadEntry, BrTRUE) == errMemoryNotEnough)
		{
			SET_ERROR((PoError)kPoErrMemory, "");
			return errMemoryNotEnough;
		}
	}

	if(bPDFA == BrTRUE)
	{	// MetaData Entry
		pMetaDataEntry = BrNEW XStream(ePDF_ENCODE_FLATE);

		if (pMetaDataEntry == NULL)
		{
			SET_ERROR((PoError)kPoErrMemory, "");
			return errMemoryNotEnough;
		}

		pMetaDataEntry->GetDict()->dictAdd(XGetKey("N"),		obj.initInt(3));

		pMetaData = (BrBYTE*)BrMalloc(SIZE_PDFA_METADATA);
		GenerateMetaData(pMetaData);
		pMetaDataEntry->SetStreamBuffer(pMetaData, SIZE_PDFA_METADATA, true);

		if(AddXRefEntry(pMetaDataEntry, BrTRUE) == errMemoryNotEnough)
		{
			SET_ERROR((PoError)kPoErrMemory, "");
			return errMemoryNotEnough;
		}
	}

	return errNone;
}

int PDFGenerator::GenerateXPacket(BrCHAR* pMetaHead, int pMetaDataSize, BrBOOL bPDFA, time_t createTime)
{
	BrCHAR	STR_PACKET_HDR[]	=	"<?xpacket begin='   ' id='W5M0MpCehiHzreSzNTczkc9d'?><x:xmpmeta xmlns:x='adobe:ns:meta/' x:xmptk='3.1-701'>";	// Must keep 3 spaces at begin value
	STR_PACKET_HDR[17] = (BrCHAR)0xEF;		STR_PACKET_HDR[18] = (BrCHAR)0xBB;		STR_PACKET_HDR[19] = (BrCHAR)0xBF;

	BrCHAR*	STR_RDF_HDR		=			"<rdf:RDF xmlns:rdf='http://www.w3.org/1999/02/22-rdf-syntax-ns#'>";

	BrCHAR*	STR_DSC1_HDR	=				"<rdf:Description rdf:about=''\n";

	BrCHAR*	STR_DSC2_HDR	=				"xmlns:xmp='http://ns.adobe.com/xap/1.0/'\n";
	//BrCHAR*	STR_DSC3_HDR	=				"xmlns:xmpMM='http://ns.adobe.com/xap/1.0/mm/'\n";
	BrCHAR*	STR_DSC4_HDR	=				"xmlns:dc='http://purl.org/dc/elements/1.1/'\n";
	BrCHAR*	STR_DSC5_HDR	=				"xmlns:pdf='http://ns.adobe.com/pdf/1.3/'\n";
	BrCHAR*	STR_DSC6_HDR	=				"xmlns:pdfaid='http://www.aiim.org/pdfa/ns/id/'";
	BrCHAR*	STR_DSC7_HDR	=				">";

	BrCHAR*	STR_CREATE_HDR	=					"<xmp:CreateDate>";		//2015-01-01T11:11:11+11:11
	BrCHAR*	STR_CREATE_FTR	=					"</xmp:CreateDate>";
	BrCHAR*	STR_MODIFY_HDR	=					"<xmp:ModifyDate>";		//2015-01-01T11:11:11+11:11
	BrCHAR*	STR_MODIFY_FTR	=					"</xmp:ModifyDate>";
	BrCHAR*	STR_TOOL		=					"<xmp:CreatorTool>Polaris PDF Viewer</xmp:CreatorTool>";
	BrCHAR* STR_TOOL_WORD	=					"<xmp:CreatorTool>Polaris Word</xmp:CreatorTool>";
	BrCHAR* STR_TOOL_SLIDE	=					"<xmp:CreatorTool>Polaris Slide</xmp:CreatorTool>";
	BrCHAR* STR_TOOL_SHEET	=					"<xmp:CreatorTool>Polaris Sheet</xmp:CreatorTool>";

	BrCHAR*	STR_CREATOR_HDR	=					"<dc:creator><rdf:Seq><rdf:li>";
	BrCHAR	STR_CREATOR[BORA_DEFINEDNAME_LENGTH] = {0,};
	BrCHAR*	STR_CREATOR_FTR	=					"</rdf:li></rdf:Seq></dc:creator>";
			//STR_DSC2[29] = (BrCHAR)0xEC;	STR_DSC2[30] = (BrCHAR)0x9D;	STR_DSC2[31] = (BrCHAR)0xB4;
			//STR_DSC2[32] = (BrCHAR)0xEC;	STR_DSC2[33] = (BrCHAR)0xB6;	STR_DSC2[34] = (BrCHAR)0xA9;
			//STR_DSC2[35] = (BrCHAR)0xED;	STR_DSC2[36] = (BrCHAR)0x98;	STR_DSC2[37] = (BrCHAR)0xB8;

	BrCHAR* STR_TITLE_HDR = "<dc:title><rdf:Alt><rdf:li xml:lang=\"x-default\">";
	BrCHAR	STR_TITLE[BORA_DEFINEDNAME_LENGTH] = { 0, };
	BrCHAR* STR_TITLE_FTR = "</rdf:li></rdf:Alt></dc:title>";

	BrCHAR* STR_FORMAT		=					"<dc:format>application/pdf</dc:format>";

	BrCHAR*	STR_DOCID_HDR	=					"<xmpMM:DocumentID>";		//uuid:048A81A0-CF8E-4168-A8B8-70A9A1E23BFF
	BrCHAR*	STR_DOCID_FTR	=					"</xmpMM:DocumentID>";
	BrCHAR*	STR_INSID_HDR	=					"<xmpMM:InstanceID>";		//uuid:048A81A0-CF8E-4168-A8B8-70A9A1E23BFF
	BrCHAR*	STR_INSID_FTR	=					"</xmpMM:InstanceID>";

	BrCHAR*	STR_PRD			=					"<pdf:Producer>Polaris PDF Viewer</pdf:Producer>";
	BrCHAR*	STR_PART		=					"<pdfaid:part>1</pdfaid:part>";
	BrCHAR*	STR_CONF		=					"<pdfaid:conformance>B</pdfaid:conformance>";
	
	BrCHAR*	STR_DSC_FTR		=				"</rdf:Description>";
	BrCHAR*	STR_RDF_FTR		=			"</rdf:RDF>";
	BrCHAR*	STR_PACKET_FTR	=		"</x:xmpmeta><?xpacket end='w'?>";

	{
		char szModifiedBy[1024] = { 0, };
		char szAppName[1024] = { 0, };
		int  page = 0;
		int words = 0;
		bool bSavePreview = FALSE;
		BrGetSummaryData(STR_TITLE, sizeof(STR_TITLE), STR_CREATOR, sizeof(STR_CREATOR), szModifiedBy, sizeof(szModifiedBy), &page, &words, &bSavePreview, szAppName, sizeof(szAppName));
	}

	int		nSize = 0, i;

	strncpy_s(pMetaHead + nSize,	pMetaDataSize - nSize, STR_PACKET_HDR,		strlen(STR_PACKET_HDR));	nSize += strlen(STR_PACKET_HDR);

	strncpy_s(pMetaHead + nSize,	pMetaDataSize - nSize, STR_RDF_HDR,		strlen(STR_RDF_HDR));		nSize += strlen(STR_RDF_HDR);

	strncpy_s(pMetaHead + nSize,	pMetaDataSize - nSize, STR_DSC1_HDR,		strlen(STR_DSC1_HDR));		nSize += strlen(STR_DSC1_HDR);
	strncpy_s(pMetaHead + nSize,	pMetaDataSize - nSize, STR_DSC2_HDR,		strlen(STR_DSC2_HDR));		nSize += strlen(STR_DSC2_HDR);
	//strncpy(pMetaHead + nSize,	STR_DSC3_HDR,		strlen(STR_DSC3_HDR));		nSize += strlen(STR_DSC3_HDR);
	strncpy_s(pMetaHead + nSize,	pMetaDataSize - nSize, STR_DSC4_HDR,		strlen(STR_DSC4_HDR));		nSize += strlen(STR_DSC4_HDR);
	strncpy_s(pMetaHead + nSize,	pMetaDataSize - nSize, STR_DSC5_HDR,		strlen(STR_DSC5_HDR));		nSize += strlen(STR_DSC5_HDR);
	if(bPDFA == BrTRUE)
	{
		strncpy_s(pMetaHead + nSize,	pMetaDataSize - nSize, STR_DSC6_HDR,		strlen(STR_DSC6_HDR));		nSize += strlen(STR_DSC6_HDR);
	}
	strncpy_s(pMetaHead + nSize,	pMetaDataSize - nSize, STR_DSC7_HDR,		strlen(STR_DSC7_HDR));		nSize += strlen(STR_DSC7_HDR);

	strncpy_s(pMetaHead + nSize,	pMetaDataSize - nSize, STR_CREATE_HDR,		strlen(STR_CREATE_HDR));	nSize += strlen(STR_CREATE_HDR);
	char dateTime[26]={0,};
	getCurrentDateTimeString(dateTime, sizeof(dateTime), createTime);
	strncpy_s(pMetaHead + nSize,	pMetaDataSize - nSize, dateTime,		strlen(dateTime));	nSize += strlen(dateTime);

	strncpy_s(pMetaHead + nSize,	pMetaDataSize - nSize, STR_CREATE_FTR,		strlen(STR_CREATE_FTR));	nSize += strlen(STR_CREATE_FTR);
	strncpy_s(pMetaHead + nSize,	pMetaDataSize - nSize, STR_MODIFY_HDR,		strlen(STR_MODIFY_HDR));	nSize += strlen(STR_MODIFY_HDR);
	strncpy_s(pMetaHead + nSize,	pMetaDataSize - nSize, dateTime,		strlen(dateTime));	nSize += strlen(dateTime);
	strncpy_s(pMetaHead + nSize,	pMetaDataSize - nSize, STR_MODIFY_FTR,		strlen(STR_MODIFY_FTR));	nSize += strlen(STR_MODIFY_FTR);

	if (IsEditorMode(gpPaint) == EDITOR_WORD)
	{
		strncpy_s(pMetaHead + nSize, pMetaDataSize - nSize, STR_TOOL_WORD, strlen(STR_TOOL_WORD));			nSize += strlen(STR_TOOL_WORD);
	}
	else if(IsEditorMode(gpPaint) == EDITOR_PPT)
	{ 
		strncpy_s(pMetaHead + nSize, pMetaDataSize - nSize, STR_TOOL_SLIDE, strlen(STR_TOOL_SLIDE));			nSize += strlen(STR_TOOL_SLIDE);
	}
	else if (IsEditorMode(gpPaint) == EDITOR_SHEET)
	{
		strncpy_s(pMetaHead + nSize, pMetaDataSize - nSize, STR_TOOL_SHEET, strlen(STR_TOOL_SHEET));			nSize += strlen(STR_TOOL_SHEET);
	}
	else
	{
		strncpy_s(pMetaHead + nSize, pMetaDataSize - nSize, STR_TOOL, strlen(STR_TOOL));			nSize += strlen(STR_TOOL);
	}

	strncpy_s(pMetaHead + nSize,	pMetaDataSize - nSize, STR_CREATOR_HDR,			strlen(STR_CREATOR_HDR));			nSize += strlen(STR_CREATOR_HDR);
	strncpy_s(pMetaHead + nSize,	pMetaDataSize - nSize, STR_CREATOR,			strlen(STR_CREATOR));			nSize += strlen(STR_CREATOR);
	strncpy_s(pMetaHead + nSize,	pMetaDataSize - nSize, STR_CREATOR_FTR,			strlen(STR_CREATOR_FTR));			nSize += strlen(STR_CREATOR_FTR);
	strncpy_s(pMetaHead + nSize,	pMetaDataSize - nSize, STR_TITLE_HDR,			strlen(STR_TITLE_HDR));			nSize += strlen(STR_TITLE_HDR);
	strncpy_s(pMetaHead + nSize,	pMetaDataSize - nSize, STR_TITLE,			strlen(STR_TITLE));				nSize += strlen(STR_TITLE);
	strncpy_s(pMetaHead + nSize,	pMetaDataSize - nSize, STR_TITLE_FTR,			strlen(STR_TITLE_FTR));			nSize += strlen(STR_TITLE_FTR);
	strncpy_s(pMetaHead + nSize,	pMetaDataSize - nSize, STR_FORMAT,			strlen(STR_FORMAT));			nSize += strlen(STR_FORMAT);

	strncpy_s(pMetaHead + nSize,	pMetaDataSize - nSize, STR_PRD,			strlen(STR_PRD));			nSize += strlen(STR_PRD);

	if(bPDFA == BrTRUE){
		strncpy_s(pMetaHead + nSize,	pMetaDataSize - nSize, STR_PART,			strlen(STR_PART));			nSize += strlen(STR_PART);
		strncpy_s(pMetaHead + nSize,	pMetaDataSize - nSize, STR_CONF,			strlen(STR_CONF));			nSize += strlen(STR_CONF);
	}

	strncpy_s(pMetaHead + nSize,	pMetaDataSize - nSize, STR_DSC_FTR,		strlen(STR_DSC_FTR));		nSize += strlen(STR_DSC_FTR);
	strncpy_s(pMetaHead + nSize,	pMetaDataSize - nSize, STR_RDF_FTR,		strlen(STR_RDF_FTR));		nSize += strlen(STR_RDF_FTR);
	strncpy_s(pMetaHead + nSize,	pMetaDataSize - nSize, STR_PACKET_FTR,		strlen(STR_PACKET_FTR));	nSize += strlen(STR_PACKET_FTR);

	// Replace ' with "
	for (i = 0; i < nSize; i++)
		if (pMetaHead[i] == 0x27)
			pMetaHead[i] = 0x22;

	return nSize;
}

void PDFGenerator::GenerateMetaData(BrBYTE* pMetaData)
{
	BrBYTE	METADATA[SIZE_PDFA_METADATA] = {
		0x78, 0x9C, 0x9D, 0x96, 0x77, 0x54, 0x54, 0xD7,  0x16, 0x87, 0xCF, 0xBD, 0x77, 0x7A, 0xA1, 0xCD,
		0x30, 0x74, 0x18, 0x7A, 0xAF, 0x52, 0x06, 0x10,  0xE9, 0x1D, 0xA4, 0x57, 0x51, 0x18, 0x66, 0x06,
		0x18, 0xCA, 0x00, 0xC3, 0x0C, 0xD8, 0x0B, 0x22,  0x2A, 0x10, 0x51, 0x44, 0xA4, 0x29, 0x82, 0x04,
		0x05, 0x0C, 0x18, 0x0D, 0x45, 0x62, 0x45, 0x14,  0x0B, 0x01, 0x51, 0x01, 0x7B, 0x40, 0x82, 0x80,
		0x12, 0x83, 0x51, 0x6C, 0xA8, 0x64, 0x46, 0xD6,  0x4A, 0x7C, 0x79, 0x79, 0xEF, 0xE5, 0xE5, 0xF7,
		0xC7, 0x3D, 0xDF, 0xDA, 0x67, 0xEF, 0x73, 0xF7,  0xD9, 0x7B, 0xDF, 0xB5, 0x2E, 0x00, 0x24, 0x2F,
		0x3F, 0x2E, 0x2F, 0x1D, 0x96, 0x02, 0x20, 0x8D,  0x27, 0xE0, 0x07, 0x7B, 0xBA, 0xD0, 0x23, 0xA3,
		0xA2, 0xE9, 0xD8, 0x7E, 0x00, 0x03, 0x3C, 0xC0,  0x00, 0x73, 0x00, 0x98, 0xAC, 0xAC, 0x0C, 0xFF,
		0x10, 0x8F, 0x50, 0x20, 0x92, 0xB7, 0xBB, 0x2B,  0x3D, 0x4B, 0xE4, 0x04, 0xFE, 0x45, 0xAF, 0x87,
		0x01, 0x24, 0x5E, 0x6F, 0x19, 0x7B, 0x05, 0xD2,  0xE9, 0xE0, 0xFF, 0x93, 0x34, 0x2B, 0x83, 0x2F,
		0x00, 0x00, 0x0A, 0x14, 0xF1, 0x12, 0x36, 0x27,  0x8B, 0x25, 0xE2, 0x3C, 0x11, 0xA7, 0xE6, 0x08,
		0x32, 0xC4, 0xF6, 0x59, 0x11, 0x53, 0xE3, 0x53,  0xC4, 0x0C, 0xA3, 0xC4, 0xCC, 0x17, 0x25, 0x28,
		0x62, 0x79, 0x31, 0x27, 0x2E, 0xB2, 0xD1, 0x67,  0x9F, 0x45, 0x76, 0x12, 0x33, 0x3B, 0x8D, 0xC7,
		0x16, 0xB1, 0x38, 0xE7, 0x0C, 0x76, 0x1A, 0x5B,  0xCC, 0x3D, 0x22, 0xDE, 0x91, 0x2D, 0xE4, 0x88,
		0x18, 0xF1, 0x13, 0x71, 0x7E, 0x36, 0x97, 0x93,  0x23, 0xE2, 0xDB, 0x22, 0xD6, 0x4A, 0x15, 0xA6,
		0x71, 0x45, 0xFC, 0x56, 0x1C, 0x9B, 0xC6, 0x61,  0x66, 0x01, 0x80, 0x22, 0x89, 0xED, 0x02, 0x0E,
		0x2B, 0x49, 0xC4, 0x66, 0x22, 0x26, 0xF1, 0x43,  0x83, 0x5D, 0x45, 0xBC, 0x14, 0x00, 0x1C, 0x29,
		0xF1, 0x0B, 0x8E, 0xFF, 0x82, 0x05, 0x9C, 0xD5,  0x02, 0xF1, 0xA5, 0x5C, 0xD3, 0x33, 0xD6, 0xF0,
		0xB9, 0x89, 0x49, 0x02, 0xBA, 0x1E, 0x4B, 0x9F,  0x6E, 0x6E, 0x6B, 0xCB, 0xA0, 0x7B, 0x71, 0x72,
		0x52, 0x39, 0x02, 0x81, 0x71, 0x20, 0x93, 0x95,  0xC2, 0xE4, 0xB3, 0xE9, 0xAE, 0xE9, 0x69, 0x19,
		0x4C, 0xDE, 0x1A, 0x00, 0x16, 0xEF, 0xFC, 0x59,  0x32, 0xE2, 0xDA, 0xD2, 0x45, 0x45, 0xB6, 0x36,
		0xB7, 0xB5, 0xB6, 0x36, 0xB6, 0x30, 0x31, 0xFF,  0xA2, 0x50, 0xFF, 0x75, 0xF3, 0x6F, 0x4A, 0xDC,
		0xDB, 0x45, 0x7A, 0x19, 0xF4, 0xB9, 0x67, 0x10,  0xAD, 0xEF, 0x0F, 0xDB, 0x5F, 0xF9, 0xA5, 0xD7,
		0x01, 0xC0, 0x98, 0x13, 0xD5, 0x66, 0xF7, 0x1F,  0xB6, 0xF8, 0x0A, 0x00, 0x3A, 0xB6, 0x01, 0x20,
		0x7F, 0xEF, 0x0F, 0x9B, 0xD6, 0x21, 0x00, 0x24,  0x45, 0x7D, 0x6B, 0x1F, 0xF8, 0xE2, 0x3E, 0x34,
		0xF1, 0xBC, 0x24, 0x09, 0x04, 0x19, 0x76, 0xA6,  0xA6, 0x39, 0x39, 0x39, 0x26, 0x5C, 0x0E, 0xCB,
		0x44, 0x5C, 0xD0, 0xDF, 0xF5, 0x3F, 0x1D, 0xFE,  0x86, 0xBE, 0x78, 0x9F, 0x89, 0xF8, 0xB8, 0xDF,
		0xCB, 0x43, 0x77, 0xE3, 0x24, 0x30, 0x85, 0xA9,  0x02, 0xBA, 0xB8, 0x6E, 0xAC, 0xF4, 0xD4, 0x74,
		0x21, 0x9F, 0x9E, 0x95, 0xC1, 0x64, 0x71, 0xE8,  0xC6, 0x7F, 0x1E, 0xE2, 0x7F, 0x1C, 0xF8, 0xD7,
		0x79, 0x18, 0x05, 0x73, 0x12, 0x38, 0x7C, 0x0E,  0x4F, 0x14, 0x11, 0x2E, 0x9A, 0x32, 0x2E, 0x2F,
		0x51, 0xD4, 0x6E, 0x1E, 0x9B, 0x2B, 0xE0, 0xA6,  0xF3, 0xE8, 0x5C, 0xDE, 0x7F, 0x6A, 0xE2, 0x3F,
		0x0C, 0xFB, 0x93, 0x16, 0xE7, 0x5A, 0x24, 0x4A,  0xFD, 0x27, 0x40, 0x8D, 0x35, 0x01, 0x52, 0x03,
		0x54, 0x80, 0xFC, 0xDC, 0x07, 0x50, 0x14, 0x22,  0x40, 0x62, 0x0E, 0x8A, 0x76, 0xA0, 0xDF, 0xFB,
		0xE6, 0x87, 0x0F, 0x07, 0x81, 0xA2, 0x35, 0x42,  0x6D, 0x72, 0x71, 0xEE, 0x3F, 0x0B, 0xFA, 0xF7,
		0x53, 0xE1, 0x62, 0xF1, 0x23, 0x8B, 0x9B, 0xF8,  0x39, 0xCE, 0x35, 0x38, 0x94, 0xCE, 0x12, 0xF2,
		0xB3, 0x17, 0xF7, 0xC4, 0x9F, 0x25, 0x40, 0x03,  0x02, 0x90, 0x04, 0x54, 0xA0, 0x00, 0x54, 0x81,
		0x26, 0xD0, 0x03, 0xC6, 0xC0, 0x02, 0xD8, 0x00,  0x7B, 0xE0, 0x04, 0xDC, 0x81, 0x0F, 0x08, 0x00,
		0xA1, 0x20, 0x0A, 0xAC, 0x02, 0x2C, 0x90, 0x04,  0xD2, 0x00, 0x1F, 0xE4, 0x80, 0xF5, 0x60, 0x0B,
		0xC8, 0x07, 0x85, 0x60, 0x37, 0xD8, 0x07, 0x2A,  0x41, 0x0D, 0xA8, 0x07, 0x8D, 0xA0, 0x05, 0x9C,
		0x00, 0x1D, 0xE0, 0x34, 0xB8, 0x00, 0x2E, 0x83,  0xEB, 0xE0, 0x06, 0x18, 0x02, 0xF7, 0xC1, 0x28,
		0x98, 0x00, 0xCF, 0xC0, 0x2C, 0x78, 0x0D, 0xE6,  0x21, 0x08, 0xC2, 0x42, 0x64, 0x88, 0x02, 0x29,
		0x40, 0x6A, 0x90, 0x36, 0x64, 0x08, 0x59, 0x40,  0x0C, 0x68, 0x19, 0xE4, 0x0E, 0xF9, 0x41, 0xC1,
		0x50, 0x14, 0x14, 0x07, 0x25, 0x42, 0x3C, 0x48,  0x08, 0xAD, 0x87, 0xB6, 0x42, 0x85, 0x50, 0x09,
		0x54, 0x09, 0xD5, 0x42, 0x8D, 0xD0, 0xB7, 0xD0,  0x29, 0xE8, 0x02, 0x74, 0x15, 0x1A, 0x84, 0xEE,
		0x42, 0x63, 0xD0, 0x34, 0xF4, 0x2B, 0xF4, 0x1E,  0x46, 0x60, 0x12, 0x4C, 0x85, 0x55, 0x60, 0x1D,
		0xD8, 0x14, 0x66, 0xC0, 0xCE, 0xB0, 0x2F, 0x1C,  0x0A, 0xAF, 0x84, 0x13, 0xE1, 0x4C, 0x78, 0x2D,
		0x9C, 0x07, 0xEF, 0x82, 0xCB, 0xE1, 0x3A, 0xF8,  0x18, 0xDC, 0x0E, 0x5F, 0x80, 0xAF, 0xC3, 0x43,
		0xF0, 0x28, 0xFC, 0x0C, 0x9E, 0x43, 0x00, 0x42,  0x44, 0x68, 0x88, 0x3A, 0x62, 0x8C, 0x30, 0x10,
		0x57, 0x24, 0x00, 0x89, 0x46, 0x12, 0x10, 0x3E,  0xB2, 0x11, 0x29, 0x40, 0xCA, 0x90, 0x3A, 0xA4,
		0x05, 0xE9, 0x42, 0x7A, 0x91, 0x5B, 0xC8, 0x28,  0x32, 0x83, 0xBC, 0x43, 0x61, 0x50, 0x14, 0x14,
		0x1D, 0x65, 0x8C, 0xB2, 0x47, 0x79, 0xA1, 0xC2,  0x50, 0x2C, 0x54, 0x26, 0x6A, 0x23, 0xAA, 0x08,
		0x55, 0x89, 0x3A, 0x8A, 0x6A, 0x47, 0xF5, 0xA0,  0x6E, 0xA1, 0xC6, 0x50, 0xB3, 0xA8, 0x4F, 0x68,
		0x32, 0x5A, 0x19, 0x6D, 0x88, 0xB6, 0x43, 0x7B,  0xA3, 0x23, 0xD1, 0x89, 0xE8, 0x1C, 0x74, 0x3E,
		0xBA, 0x0C, 0xDD, 0x80, 0x6E, 0x43, 0x5F, 0x42,  0x0F, 0xA1, 0x27, 0xD0, 0xAF, 0x31, 0x18, 0x0C,
		0x0D, 0xA3, 0x8B, 0xB1, 0xC1, 0x78, 0x61, 0xA2,  0x30, 0xC9, 0x98, 0x75, 0x98, 0x22, 0xCC, 0x01,
		0x4C, 0x2B, 0xE6, 0x3C, 0x66, 0x10, 0x33, 0x8E,  0x99, 0xC3, 0x62, 0xB1, 0x0A, 0x58, 0x43, 0xAC,
		0x03, 0x36, 0x00, 0xCB, 0xC4, 0x0A, 0xB0, 0xF9,  0xD8, 0x0A, 0xEC, 0x31, 0xEC, 0x39, 0xEC, 0x4D,
		0xEC, 0x04, 0xF6, 0x2D, 0x8E, 0x88, 0x53, 0xC3,  0x59, 0xE0, 0x3C, 0x70, 0xD1, 0x38, 0x1E, 0x2E,
		0x17, 0x57, 0x86, 0x6B, 0xC2, 0x9D, 0xC5, 0xDD,  0xC4, 0x4D, 0xE2, 0xE6, 0xF1, 0x52, 0x78, 0x6D,
		0xBC, 0x1D, 0x3E, 0x00, 0xCF, 0xC6, 0xAF, 0xC1,  0x17, 0xE3, 0xEB, 0xF1, 0x5D, 0xF8, 0x01, 0xFC,
		0x04, 0x7E, 0x9E, 0x20, 0x4D, 0xD0, 0x25, 0x38,  0x10, 0x42, 0x09, 0xC9, 0x84, 0x2D, 0x84, 0x72,
		0x42, 0x0B, 0xE1, 0x12, 0xE1, 0x01, 0xE1, 0x25,  0x91, 0x48, 0xD4, 0x20, 0xDA, 0x12, 0x83, 0x88,
		0x5C, 0xE2, 0x66, 0x62, 0x39, 0xF1, 0x38, 0xF1,  0x0A, 0x71, 0x8C, 0xF8, 0x8E, 0x24, 0x43, 0x32,
		0x20, 0xB9, 0x92, 0x62, 0x48, 0x42, 0xD2, 0x2E,  0xD2, 0x11, 0xD2, 0x79, 0xD2, 0x5D, 0xD2, 0x4B,
		0x32, 0x99, 0xAC, 0x43, 0x76, 0x22, 0x47, 0x93,  0x05, 0xE4, 0x5D, 0xE4, 0x46, 0xF2, 0x45, 0xF2,
		0x23, 0xF2, 0x5B, 0x09, 0x8A, 0x84, 0x89, 0x84,  0xB7, 0x04, 0x5B, 0x62, 0x93, 0x44, 0x95, 0x44,
		0xBB, 0xC4, 0x4D, 0x89, 0xE7, 0x92, 0x78, 0x49,  0x6D, 0x49, 0x67, 0xC9, 0x55, 0x92, 0x6B, 0x25,
		0xCB, 0x24, 0x4F, 0x4A, 0x0E, 0x48, 0xCE, 0x48,  0xE1, 0xA5, 0x74, 0xA4, 0x5C, 0xA5, 0x98, 0x52,
		0x1B, 0xA5, 0xAA, 0xA4, 0x4E, 0x49, 0x8D, 0x48,  0xCD, 0x49, 0x53, 0xA4, 0xCD, 0xA5, 0x03, 0xA4,
		0xD3, 0xA4, 0x8B, 0xA4, 0x9B, 0xA4, 0xAF, 0x4A,  0x4F, 0xC9, 0x60, 0x65, 0x74, 0x64, 0xDC, 0x65,
		0xD8, 0x32, 0x79, 0x32, 0x87, 0x65, 0x2E, 0xCA,  0x8C, 0x53, 0x10, 0x8A, 0x26, 0xC5, 0x95, 0xC2,
		0xA2, 0x6C, 0xA5, 0xD4, 0x53, 0x2E, 0x51, 0x26,  0xA8, 0x18, 0xAA, 0x2E, 0xD5, 0x9B, 0x9A, 0x4C,
		0x2D, 0xA4, 0x7E, 0x43, 0xED, 0xA7, 0xCE, 0xCA,  0xCA, 0xC8, 0x5A, 0xCA, 0x86, 0xCB, 0xAE, 0x96,
		0xAD, 0x92, 0x3D, 0x23, 0x3B, 0x4A, 0x43, 0x68,  0x3A, 0x34, 0x6F, 0x5A, 0x2A, 0xAD, 0x98, 0x76,
		0x82, 0x36, 0x4C, 0x7B, 0x2F, 0xA7, 0x22, 0xE7,  0x2C, 0xC7, 0x91, 0xDB, 0x29, 0xD7, 0x22, 0x77,
		0x53, 0xEE, 0x8D, 0xBC, 0x92, 0xBC, 0x93, 0x3C,  0x47, 0xBE, 0x40, 0xBE, 0x55, 0x7E, 0x48, 0xFE,
		0xBD, 0x02, 0x5D, 0xC1, 0x5D, 0x21, 0x45, 0x61,  0x8F, 0x42, 0x87, 0xC2, 0x43, 0x45, 0x94, 0xA2,
		0x81, 0x62, 0x90, 0x62, 0x8E, 0xE2, 0x41, 0xC5,  0x4B, 0x8A, 0x33, 0x4A, 0x54, 0x25, 0x7B, 0x25,
		0x96, 0x52, 0x81, 0xD2, 0x09, 0xA5, 0x7B, 0xCA,  0xB0, 0xB2, 0x81, 0x72, 0xB0, 0xF2, 0x3A, 0xE5,
		0xC3, 0xCA, 0x7D, 0xCA, 0x73, 0x2A, 0xAA, 0x2A,  0x9E, 0x2A, 0x19, 0x2A, 0x15, 0x2A, 0x17, 0x55,
		0x66, 0x54, 0x69, 0xAA, 0x4E, 0xAA, 0xC9, 0xAA,  0xA5, 0xAA, 0x67, 0x55, 0xA7, 0xD5, 0x28, 0x6A,
		0xCB, 0xD4, 0xB8, 0x6A, 0xA5, 0x6A, 0xE7, 0xD4,  0x9E, 0xD2, 0x65, 0xE9, 0xCE, 0xF4, 0x54, 0x7A,
		0x39, 0xBD, 0x87, 0x3E, 0xAB, 0xAE, 0xAC, 0xEE,  0xA5, 0x2E, 0x54, 0xAF, 0x55, 0xEF, 0x57, 0x9F,
		0xD7, 0xD0, 0xD5, 0x08, 0xD3, 0xC8, 0xD5, 0x68,  0xD5, 0x78, 0xA8, 0x49, 0xD0, 0x64, 0x68, 0x26,
		0x68, 0x96, 0x6A, 0x76, 0x6B, 0xCE, 0x6A, 0xA9,  0x69, 0xF9, 0x6B, 0xAD, 0xD7, 0x6A, 0xD6, 0xBA,
		0xA7, 0x8D, 0xD7, 0x66, 0x68, 0x27, 0x69, 0xEF,  0xD7, 0xEE, 0xD5, 0x7E, 0xA3, 0xA3, 0xAB, 0x13,
		0xA1, 0xB3, 0x5D, 0xA7, 0x43, 0x67, 0x4A, 0x57,  0x5E, 0xD7, 0x5B, 0x77, 0xAD, 0x6E, 0xB3, 0xEE,
		0x03, 0x3D, 0xB2, 0x9E, 0xA3, 0x5E, 0xA6, 0x5E,  0x9D, 0xDE, 0x6D, 0x7D, 0x8C, 0x3E, 0x43, 0x3F,
		0x45, 0xFF, 0x80, 0xFE, 0x0D, 0x03, 0xD8, 0xC0,  0xCA, 0x20, 0xC9, 0xA0, 0xCA, 0x60, 0xC0, 0x10,
		0x36, 0xB4, 0x36, 0xE4, 0x1A, 0x1E, 0x30, 0x1C,  0x34, 0x42, 0x1B, 0xD9, 0x1A, 0xF1, 0x8C, 0xEA,
		0x8C, 0x46, 0x8C, 0x49, 0xC6, 0xCE, 0xC6, 0xD9,  0xC6, 0xCD, 0xC6, 0x63, 0x26, 0x34, 0x13, 0x3F,
		0x93, 0x5C, 0x93, 0x0E, 0x93, 0xE7, 0xA6, 0x5A,  0xA6, 0xD1, 0xA6, 0x7B, 0x4C, 0x7B, 0x4D, 0x3F,
		0x99, 0x59, 0x99, 0xA5, 0x9A, 0xD5, 0x9B, 0xDD,  0x37, 0x97, 0x31, 0xF7, 0x31, 0xCF, 0x35, 0xEF,
		0x32, 0xFF, 0xD5, 0xC2, 0xC0, 0x82, 0x65, 0x51,  0x65, 0x71, 0x7B, 0x09, 0x79, 0x89, 0xC7, 0x92,
		0x4D, 0x4B, 0x3A, 0x97, 0xBC, 0xB0, 0x34, 0xB4,  0xE4, 0x58, 0x1E, 0xB4, 0xBC, 0x63, 0x45, 0xB1,
		0xF2, 0xB7, 0xDA, 0x6E, 0xD5, 0x6D, 0xF5, 0xD1,  0xDA, 0xC6, 0x9A, 0x6F, 0xDD, 0x62, 0x3D, 0x6D,
		0xA3, 0x65, 0x13, 0x67, 0x53, 0x6D, 0x33, 0xC2,  0xA0, 0x32, 0x02, 0x19, 0x45, 0x8C, 0x2B, 0xB6,
		0x68, 0x5B, 0x17, 0xDB, 0x4D, 0xB6, 0xA7, 0x6D,  0xDF, 0xD9, 0x59, 0xDB, 0x09, 0xEC, 0x4E, 0xD8,
		0xFD, 0x62, 0x6F, 0x6C, 0x9F, 0x62, 0xDF, 0x64,  0x3F, 0xB5, 0x54, 0x77, 0x29, 0x67, 0x69, 0xFD,
		0xD2, 0x71, 0x07, 0x0D, 0x07, 0xA6, 0x43, 0xAD,  0xC3, 0xE8, 0x32, 0xFA, 0xB2, 0xB8, 0x65, 0x87,
		0x96, 0x8D, 0x3A, 0xAA, 0x3B, 0x32, 0x1D, 0xEB,  0x1C, 0x1F, 0x3B, 0x69, 0x3A, 0xB1, 0x9D, 0x1A,
		0x9C, 0x26, 0x9D, 0xF5, 0x9D, 0x93, 0x9D, 0x8F,  0x39, 0x3F, 0x77, 0x31, 0x73, 0xE1, 0xBB, 0xB4,
		0xB9, 0xBC, 0x71, 0xB5, 0x73, 0xDD, 0xE0, 0x7A,  0xDE, 0x0D, 0x71, 0xF3, 0x74, 0x2B, 0x70, 0xEB,
		0x77, 0x97, 0x71, 0x0F, 0x73, 0xAF, 0x74, 0x7F,  0xE4, 0xA1, 0xE1, 0x91, 0xE8, 0xD1, 0xEC, 0x31,
		0xEB, 0x69, 0xE5, 0xB9, 0xCE, 0xF3, 0xBC, 0x17,  0xDA, 0xCB, 0xD7, 0x6B, 0x8F, 0xD7, 0x88, 0xB7,
		0x8A, 0x37, 0xCB, 0xBB, 0xD1, 0x7B, 0xD6, 0xC7,  0xC6, 0x67, 0x83, 0x4F, 0x8F, 0x2F, 0xC9, 0x37,
		0xC4, 0xB7, 0xD2, 0xF7, 0xB1, 0x9F, 0x81, 0x1F,  0xDF, 0xAF, 0xCB, 0x1F, 0xF6, 0xF7, 0xF1, 0xDF,
		0xEB, 0xFF, 0x60, 0xB9, 0xF6, 0x72, 0xDE, 0xF2,  0x8E, 0x00, 0x10, 0xE0, 0x1D, 0xB0, 0x37, 0xE0,
		0x61, 0xA0, 0x6E, 0x60, 0x66, 0xE0, 0xF7, 0x41,  0x98, 0xA0, 0xC0, 0xA0, 0xAA, 0xA0, 0x27, 0xC1,
		0xE6, 0xC1, 0xEB, 0x83, 0x7B, 0x43, 0x28, 0x21,  0xB1, 0x21, 0x4D, 0x21, 0xAF, 0x43, 0x5D, 0x42,
		0x8B, 0x43, 0xEF, 0x87, 0xE9, 0x85, 0x09, 0xC3,  0xBA, 0xC3, 0x25, 0xC3, 0x63, 0xC2, 0x1B, 0xC3,
		0xDF, 0x44, 0xB8, 0x45, 0x94, 0x44, 0x8C, 0x46,  0x9A, 0x46, 0x6E, 0x88, 0xBC, 0x1E, 0xA5, 0x18,
		0xC5, 0x8D, 0xEA, 0x8C, 0xC6, 0x46, 0x87, 0x47,  0x37, 0x44, 0xCF, 0xAD, 0x70, 0x5F, 0xB1, 0x6F,
		0xC5, 0x44, 0x8C, 0x55, 0x4C, 0x7E, 0xCC, 0xF0,  0x4A, 0xDD, 0x95, 0xAB, 0x57, 0x5E, 0x5D, 0xA5,
		0xB8, 0x2A, 0x75, 0xD5, 0x99, 0x58, 0xC9, 0x58,  0x66, 0xEC, 0xC9, 0x38, 0x74, 0x5C, 0x44, 0x5C,
		0x53, 0xDC, 0x07, 0x66, 0x00, 0xB3, 0x8E, 0x39,  0x17, 0xEF, 0x1D, 0x5F, 0x1D, 0x3F, 0xCB, 0x72,
		0x65, 0xED, 0x67, 0x3D, 0x63, 0x3B, 0xB1, 0x4B,  0xD9, 0xD3, 0x1C, 0x07, 0x4E, 0x09, 0x67, 0x32,
		0xC1, 0x21, 0xA1, 0x24, 0x61, 0x2A, 0xD1, 0x21,  0x71, 0x6F, 0xE2, 0x74, 0x92, 0x63, 0x52, 0x59,
		0xD2, 0x0C, 0xD7, 0x95, 0x5B, 0xC9, 0x7D, 0x91,  0xEC, 0x95, 0x5C, 0x93, 0xFC, 0x26, 0x25, 0x20,
		0xE5, 0x48, 0xCA, 0x42, 0x6A, 0x44, 0x6A, 0x6B,  0x1A, 0x2E, 0x2D, 0x2E, 0xED, 0x14, 0x4F, 0x86,
		0x97, 0xC2, 0xEB, 0x49, 0x57, 0x4D, 0x5F, 0x9D,  0x3E, 0x98, 0x61, 0x98, 0x91, 0x9F, 0x31, 0x9A,
		0x69, 0x97, 0xB9, 0x2F, 0x73, 0x96, 0xEF, 0xCB,  0x6F, 0xC8, 0x82, 0xB2, 0x56, 0x66, 0x75, 0x0A,
		0xA8, 0xA2, 0x9F, 0xA9, 0x3E, 0xA1, 0x9E, 0x70,  0x9B, 0x70, 0x2C, 0x7B, 0x59, 0x76, 0x55, 0xF6,
		0xDB, 0x9C, 0xF0, 0x9C, 0x93, 0xAB, 0xA5, 0x57,  0xF3, 0x56, 0xF7, 0xAD, 0x31, 0x58, 0xB3, 0x73,
		0xCD, 0xE4, 0x5A, 0x8F, 0xB5, 0x5F, 0xAF, 0x43,  0xAD, 0x63, 0xAD, 0xEB, 0x5E, 0xAF, 0xBE, 0x7E,
		0xCB, 0xFA, 0xB1, 0x0D, 0xCE, 0x1B, 0x6A, 0x37,  0x42, 0x1B, 0xE3, 0x37, 0x76, 0x6F, 0xD2, 0xDC,
		0x94, 0xB7, 0x69, 0x62, 0xB3, 0xE7, 0xE6, 0xA3,  0x5B, 0x08, 0x5B, 0x52, 0xB6, 0xFC, 0x90, 0x6B,
		0x96, 0x5B, 0x92, 0xFB, 0x6A, 0x6B, 0xC4, 0xD6,  0xAE, 0x3C, 0x95, 0xBC, 0xCD, 0x79, 0xE3, 0xDB,
		0x3C, 0xB7, 0x35, 0xE7, 0x4B, 0xE4, 0xF3, 0xF3,  0x47, 0xB6, 0xDB, 0x6F, 0xAF, 0xD9, 0x81, 0xDA,
		0xC1, 0xDD, 0xD1, 0xBF, 0x73, 0xC9, 0xCE, 0x8A,  0x9D, 0x9F, 0x0A, 0xD8, 0x05, 0xD7, 0x0A, 0xCD,
		0x0A, 0xCB, 0x0A, 0x3F, 0x14, 0xB1, 0x8A, 0xAE,  0x7D, 0x65, 0xFE, 0x55, 0xF9, 0x57, 0x0B, 0xBB,
		0x12, 0x76, 0xF5, 0x17, 0x5B, 0x17, 0x1F, 0xDC,  0x8D, 0xD9, 0xCD, 0xDB, 0x3D, 0xBC, 0xC7, 0x71,
		0xCF, 0xD1, 0x12, 0xE9, 0x92, 0xB5, 0x25, 0xE3,  0x7B, 0xFD, 0xF7, 0xB6, 0x97, 0xD2, 0x4B, 0x0B,
		0x4A, 0x5F, 0xED, 0x8B, 0xDD, 0x77, 0xB5, 0xCC,  0xB2, 0xAC, 0x66, 0x3F, 0x61, 0xBF, 0x70, 0xFF,
		0x68, 0xB9, 0x5F, 0x79, 0x67, 0x85, 0x56, 0xC5,  0xEE, 0x8A, 0x0F, 0x95, 0x49, 0x95, 0x43, 0x55,
		0x2E, 0x55, 0xAD, 0xD5, 0xCA, 0xD5, 0x3B, 0xAB,  0xDF, 0x1C, 0x60, 0x1F, 0xB8, 0x79, 0xD0, 0xE9,
		0x60, 0x4B, 0x8D, 0x4A, 0x4D, 0x61, 0xCD, 0xFB,  0x43, 0xDC, 0x43, 0x77, 0x6A, 0x3D, 0x6B, 0xDB,
		0xEB, 0x74, 0xEA, 0xCA, 0x0E, 0x63, 0x0E, 0x67,  0x1F, 0x7E, 0x52, 0x1F, 0x5E, 0xDF, 0xFB, 0x35,
		0xE3, 0xEB, 0xC6, 0x06, 0xC5, 0x86, 0xC2, 0x86,  0x8F, 0x47, 0x78, 0x47, 0x46, 0x8F, 0x06, 0x1F,
		0xED, 0x69, 0xB4, 0x69, 0x6C, 0x6C, 0x52, 0x6E,  0x2A, 0x6E, 0x86, 0x9B, 0x85, 0xCD, 0xD3, 0xC7,
		0x62, 0x8E, 0xDD, 0xF8, 0xC6, 0xED, 0x9B, 0xCE,  0x16, 0xE3, 0x96, 0xDA, 0x56, 0x5A, 0x6B, 0xE1,
		0x71, 0x70, 0x5C, 0x78, 0xFC, 0xE9, 0xB7, 0x71,  0xDF, 0x0E, 0x9F, 0xF0, 0x3D, 0xD1, 0x7D, 0x92,
		0x71, 0xB2, 0xE5, 0x3B, 0xED, 0xEF, 0xAA, 0xDB,  0x28, 0x6D, 0x05, 0xED, 0x50, 0xFB, 0x9A, 0xF6,
		0xD9, 0x8E, 0xA4, 0x8E, 0xD1, 0xCE, 0xA8, 0xCE,  0xC1, 0x53, 0x3E, 0xA7, 0xBA, 0xBB, 0xEC, 0xBB,
		0xDA, 0xBE, 0x37, 0xF9, 0xFE, 0xC8, 0x69, 0xF5,  0xD3, 0x55, 0x67, 0x64, 0xCF, 0x14, 0x9F, 0x25,
		0x9C, 0xCD, 0x3B, 0xBB, 0x70, 0x6E, 0xED, 0xB9,  0xB9, 0xF3, 0x19, 0xE7, 0x67, 0x2E, 0x24, 0x5E,
		0x18, 0xEF, 0x8E, 0xED, 0xBE, 0x7F, 0x31, 0xF2,  0xE2, 0xED, 0x9E, 0xA0, 0x9E, 0xFE, 0x4B, 0xBE,
		0x97, 0xAE, 0x5C, 0xF6, 0xB8, 0x7C, 0xB1, 0xD7,  0xB9, 0xF7, 0xDC, 0x15, 0x87, 0x2B, 0xA7, 0xAF,
		0xDA, 0x5D, 0x3D, 0x75, 0x8D, 0x71, 0xAD, 0xE3,  0xBA, 0xF5, 0xF5, 0xF6, 0x3E, 0xAB, 0xBE, 0xB6,
		0x1F, 0xAC, 0x7E, 0x68, 0xEB, 0xB7, 0xEE, 0x6F,  0x1F, 0xB0, 0x19, 0xE8, 0xBC, 0x61, 0x7B, 0xA3,
		0x6B, 0x70, 0xE9, 0xE0, 0xD9, 0x9B, 0x8E, 0x37,  0x2F, 0xDC, 0x72, 0xBB, 0x75, 0xF9, 0xB6, 0xF7,
		0xED, 0xEB, 0x43, 0xCB, 0x87, 0x06, 0x87, 0xC3,  0x86, 0xEF, 0x8C, 0xC4, 0x8C, 0x8C, 0xDE, 0x61,
		0xDF, 0x99, 0xBA, 0x9B, 0x7A, 0xF7, 0xC5, 0xBD,  0xEC, 0x7B, 0xF3, 0xF7, 0x37, 0x3F, 0x40, 0x3F,
		0x28, 0x78, 0x28, 0xF5, 0xB0, 0xEC, 0x91, 0xF2,  0xA3, 0xBA, 0x1F, 0xF5, 0x7F, 0x6C, 0x1D, 0xB5,
		0x1E, 0x3D, 0x33, 0xE6, 0x36, 0xD6, 0xF7, 0x38,  0xE4, 0xF1, 0xFD, 0x71, 0xD6, 0xF8, 0xB3, 0x9F,
		0xB2, 0x7E, 0xFA, 0x30, 0x91, 0xF7, 0x84, 0xFC,  0xA4, 0x6C, 0x52, 0x6D, 0xB2, 0x71, 0xCA, 0x62,
		0xEA, 0xF4, 0xB4, 0xC7, 0xF4, 0x8D, 0xA7, 0x2B,  0x9E, 0x4E, 0x3C, 0xCB, 0x78, 0x36, 0x3F, 0x93,
		0xFF, 0xB3, 0xF4, 0xCF, 0xD5, 0xCF, 0xF5, 0x9E,  0x7F, 0xF7, 0x8B, 0xD3, 0x2F, 0x7D, 0xB3, 0x91,
		0xB3, 0x13, 0x2F, 0xF8, 0x2F, 0x16, 0x7E, 0x2D,  0x7A, 0xA9, 0xF0, 0xF2, 0xC8, 0x2B, 0xCB, 0x57,
		0xDD, 0x73, 0x81, 0x73, 0x8F, 0x5E, 0xA7, 0xBD,  0x9E, 0x7F, 0x53, 0xF0, 0x56, 0xE1, 0xED, 0xD1,
		0x77, 0x8C, 0x77, 0xBD, 0xEF, 0x23, 0xDE, 0x4F,  0xCE, 0xE7, 0x7C, 0xC0, 0x7E, 0x28, 0xFF, 0xA8,
		0xFF, 0xB1, 0xEB, 0x93, 0xEF, 0xA7, 0x07, 0x0B,  0x69, 0x0B, 0x0B, 0xBF, 0x01, 0xF7, 0x84, 0xF3,
		0xFB
	};

	for (int i = 0; i < SIZE_PDFA_METADATA; i++)
		pMetaData[i] = METADATA[i];
}

int	PDFGenerator::GenerateKids(Object* a_pPages, Object* a_pPagesRef)
{
	Object* pKids = BrNEW Object();
	if (pKids == NULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");
		return errMemoryNotEnough;
	}

	pKids->initArray((XRef*)NULL);	
	//AddXRefEntry(pKids);

	int objNumber = m_nEntryIndex;

	for (int i = 0; i < m_nPageCount; i++)
	{
		//if (NULL == GeneratePage(a_pPagesRef))
		//	return errMemoryNotEnough;
		m_nEntryIndex++;

		Object oRef;
		oRef.initRef(m_nEntryIndex, 0);
		pKids->getArray()->add(&oRef);

		m_pPageNumbers[i] = m_nEntryIndex;
	}

	// pages object reference to kids
	//Object kidesRef;
	//kidesRef.initRef(objNumber, 0);
	//a_pPages->getDict()->add(XGetKey("Kids"), &kidesRef);
	a_pPages->getDict()->add(XGetKey("Kids"), pKids);

	BrFree(pKids);
	
	return errNone;
}

#define ADDED_OBJ_COUNT		50

int PDFGenerator::AddXRefEntry(void* a_pObj, GBool bStream)
{
	m_nEntryIndex++;

	if (m_nEntryIndex > m_nEntryCount - 1)
	{
		m_pEntries = (XRefEntry*) BrRealloc(m_pEntries, (m_nEntryCount + ADDED_OBJ_COUNT) * BrSizeOf(XRefEntry));
		m_ppObjects = (void**) BrRealloc(m_ppObjects, (m_nEntryCount + ADDED_OBJ_COUNT) * BrSizeOf(void*));
		m_pbWrited = (bool*)BrRealloc(m_pbWrited, (m_nEntryCount + ADDED_OBJ_COUNT) * BrSizeOf(bool));
		m_pbXStream = (bool*)BrRealloc(m_pbXStream, (m_nEntryCount + ADDED_OBJ_COUNT) * BrSizeOf(bool));
	
		if (m_ppObjects == NULL || m_pEntries == NULL || m_pbWrited == NULL || m_pbXStream == NULL)
		{
			SET_ERROR((PoError)kPoErrMemory, "");

			BRCONTEXT;
			ThrowBrThreadError(Brcontext, kThreadSaveCancelErr);
			//return errMemoryNotEnough;
		}

		for (int i = m_nEntryCount; i < m_nEntryCount + ADDED_OBJ_COUNT; i++) {
			memset(&m_pEntries[i], 0, BrSizeOf(XRefEntry));
			m_ppObjects[i] = NULL;
			m_pbWrited[i] = false;
			m_pbXStream[i] = false;
		}

		m_nEntryCount += ADDED_OBJ_COUNT;
	}

	m_pEntries[m_nEntryIndex].gen = 0;
	m_pEntries[m_nEntryIndex].type = xrefEntryUncompressed;

	m_ppObjects[m_nEntryIndex] = a_pObj;
	if(bStream)
		m_pbXStream[m_nEntryIndex] = BrTRUE;

	return errNone;
}

int	PDFGenerator::GenerateXRef()
{
	// 1. Root Obj;
	m_nRootGeneration = 0;
	m_nRootNumber = 1;

	// 2. alloc xref entries;
	m_nEntryCount = m_nPageCount * 30; // �ϴ� XRef Entry �� ������ page������ 30��� �����Ѵ�. 10 -> 30
	m_pEntries = (XRefEntry*) BrMalloc(m_nEntryCount * BrSizeOf(XRefEntry));
	if (m_pEntries == NULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");
		return errMemoryNotEnough;
	}

	memset(m_pEntries, 0, BrSizeOf(XRefEntry) * m_nEntryCount);

	// 3. Create Objects Array 
	m_ppObjects = (void**)BrMalloc(m_nEntryCount * BrSizeOf(void*));
	if (m_ppObjects == NULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");
		return errMemoryNotEnough;
	}

	memset(m_ppObjects, 0, BrSizeOf(Object*) * m_nEntryCount);

	//4. Create Writed Boolean Array
	m_pbWrited = (bool*) BrMalloc(m_nEntryCount * BrSizeOf(bool));
	if (m_pbWrited == NULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");
		return errMemoryNotEnough;
	}

	memset(m_pbWrited, 0, m_nEntryCount * BrSizeOf(bool));

	//5. Stream Array 
	m_pbXStream = (bool*) BrMalloc(m_nEntryCount * BrSizeOf(bool));
	if (m_pbWrited == NULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");
		return errMemoryNotEnough;
	}

	memset(m_pbXStream, 0, m_nEntryCount * BrSizeOf(bool));

	return errNone;
}

void PDFGenerator::CompleteGeneration(BrBOOL bSave)
{	
	if (m_xref)
	{
		Object RefEncrypt;
		m_xref->getEncryptDict()->dictLookupNF("Encrypt", &RefEncrypt);
		if (!RefEncrypt.isNull())
		{
			XRefEntry* e = m_xref->getEntry(RefEncrypt.getRefNum());
			RefEncrypt.free();

			Object* pEncryptObj = BrNEW Object();
			pEncryptObj->initDict((XRef*)NULL);

			e->obj.copy(pEncryptObj);
			AddXRefEntry(pEncryptObj);
			//	e->obj.free();
			m_pbWrited[m_nEntryIndex] = false;
		}
	}

	m_bComplete = true;
	m_nEntryCount = m_nEntryIndex + 1;

	if (m_ppObjects == NULL || m_pEntries == NULL || m_pbWrited == NULL || m_pbXStream == NULL)
		return;

	Object oCount;
	oCount.initInt(m_nTotalPage);
	((Object*)m_ppObjects[m_nPagesObjNumber])->getDict()->set("Count", &oCount);

	if( m_pExportData.GetSize() > 0 )
	{
		Object* pFontObj = BrNULL;
		int index;
		Object obj;
		for (int i = 0; i < (int)m_fontArray.count(); i++)
		{
			Object obj2;
			index = m_fontArray[i];
			pFontObj = (Object*)m_ppObjects[index];
			pFontObj->getDict()->lookupNF("ToUnicode", &obj2);
			if(!obj2.isNull())
			{
				pFontObj->getDict()->lookup("BaseFont", &obj);
				m_fontArray.RemoveAt(i);
				obj2.free();
				break;
			}
		}
		if(!obj.isNull())
		{
			GenerateFinalFontFile();

			// CNZ-55839 ���� font data�� ���� �� stream�� write�� m_pbWrited �� true�� �Ǿ� dangling pointer�� �߻��� �� ���� �� �´µ�
			// iOS������ ���� �߻��ϰ� �ִٰ� �ϹǷ� data ���� �� write�� ���� �ϰ� ���� write�� Ÿ�� �ʵ��� flag�� �ٲ�д�
			// side ����� ������ �� �� ġ���� ������ �ǵ��� ���� font data ���� �� write�� ���� ���� ������ ã�� ������ ��
			if(bSave)
			{
				Guint offset;
				WriteStream(m_pOutStream, &offset);
				bSave = false;
			}

			if( m_pExportData.GetSize() > 0 )
			{
				for(int idx= 0; idx < m_pExportData.GetSize(); idx++)
					BrDELETE m_pExportData.at(idx);
				m_pExportData.RemoveAll();
			}
			obj.free();
		}
	}

	if(bSave)
	{
		Guint offset;
		WriteStream(m_pOutStream, &offset);
	}

	CloseFile();
}

int	PDFGenerator::WriteTrailer(Guint a_nXRefOffset, int a_nRefSize, OutStream* a_pStream, GBool a_bIncrUpdate)
{
	int errRet = errNone;

	Dict* trailerDict = BrNEW Dict((XRef*)NULL);
	if (trailerDict == NULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");
		return errMemoryNotEnough;
	}
	Object obj1;
	obj1.initInt(a_nRefSize);
	trailerDict->set("Size", &obj1);
	obj1.free();

	GBool hasEncrypt = gFalse;
	if (m_xref && !m_xref->getEncryptDict()->isNone()) {//&& saveAsPageNums == BrNULL) {
		Object obj2;
		m_xref->getEncryptDict()->dictLookupNF("Encrypt", &obj2);
		if (!obj2.isNull()) {
			obj2.setRefNum(m_nEntryIndex);
			trailerDict->set("Encrypt", &obj2);
			hasEncrypt = gTrue;
			obj1.free();
		}
	}

	//calculate md5 digest
	char dateTime[30] = { 0, };
	char fileID[40] = { 0, };
	getCurrentDateTimeString(dateTime, sizeof(dateTime));
	Decrypt::md5((Guchar*)dateTime, 16, (Guchar*)fileID);
	GString* temp = BrNEW GString((const char*)fileID, 16);
	if (temp == NULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");
		return errMemoryNotEnough;
	}
	obj1.initString(temp);

	//create ID array
	Object obj2, obj3, obj4, obj5;
	obj2.initArray((XRef*)NULL);

	if (a_bIncrUpdate || hasEncrypt) {
		//only update the second part of the array
		if (m_xref && m_xref->getEncryptDict()->getDict()->lookup("ID", &obj4) != NULL) {
			if (!obj4.isArray()) {
				error((-1, "PDFDoc::writeTrailer original file's ID entry isn't an array. Trying to continue"));
			}
			else {
				//Get the first part of the ID
				obj4.arrayGet(0, &obj3);

				obj2.arrayAdd(&obj3);
				obj2.arrayAdd(&obj1);
				trailerDict->set("ID", &obj2);
			}
		}
	}
	else {
		//new file => same values for the two identifiers
		obj2.arrayAdd(&obj1);
		GString* temp = BrNEW GString((const char*)fileID, 16);
		if (temp == NULL)
		{
			SET_ERROR((PoError)kPoErrMemory, "");
			return errMemoryNotEnough;
		}
		obj1.initString(temp);

		obj2.arrayAdd(&obj1);
		trailerDict->set("ID", &obj2);
	}

	obj1.initRef(m_nRootNumber, m_nRootGeneration);
	trailerDict->set("Root", &obj1);

	obj1.initRef(m_nDocumentInfoNumber, 0);
	trailerDict->set("Info", &obj1);

	a_pStream->printf("trailer\r\n");

	WriteDictionary(trailerDict, a_pStream, false);

	//errRet = WriteDictionary(trailerDict, a_pStream);
	a_pStream->printf("\r\nstartxref\r\n");
	a_pStream->printf("%i\r\n", a_nXRefOffset);
	a_pStream->printf("%%%%EOF\r\n");

	BrDELETE trailerDict;

	return errRet;
}

void PDFGenerator::getFileID(char* srcData, char* fileId, int fileIdSize)
{
	char key[17];
	Decrypt::md5((Guchar *)srcData, 16 , (Guchar *)key);
	for (int i = 0; i < 16; i++)
		_snprintf_s(fileId+i*2, fileIdSize-(i*2), fileIdSize-(i*2)-1, "%02X", key[i]&0xff);
}
void PDFGenerator::getCurrentDateTimeString(char* dateTime, int dateTimeSize, time_t createTime)
{
#if defined( WINDOWS_8 ) && defined(_WIN32)
	SYSTEMTIME st;
	GetLocalTime(&st);
#endif //WINDOWS_8
	time_t t = createTime != 0 ? createTime : time(NULL);
	struct tm *timeinfo_local, *timeinfo_gm; 
	time (&t);
#ifdef WIN32
	struct tm tmptimeinfo;
	localtime_s (&tmptimeinfo, &t);
	timeinfo_local = &tmptimeinfo;
#else
	timeinfo_local = localtime (&t);
#endif
	int localHour = timeinfo_local->tm_hour;
	int localMin = timeinfo_local->tm_min;
	char strDate[11]={0,};
	char strTime[9]={0,};
	char strTimezone[7]={0,};
	strftime(strDate, 11, "%Y-%m-%d", timeinfo_local);
	strftime(strTime, 9, "%H:%M:%S", timeinfo_local);
	//char* arrDayNames[7] = {"S", "M", "T", "W", "T", "F", "S"};
	char* arrDayNames[7] = {"T", "T", "T", "T", "T", "T", "T"};
#ifdef WIN32	
	errno_t err1 = gmtime_s(&tmptimeinfo, &t);	
	timeinfo_gm = &tmptimeinfo;
#else
	timeinfo_gm = gmtime(&t);
#endif	
	if (localHour - timeinfo_gm->tm_hour > 0 && localHour - timeinfo_gm->tm_hour < 10)
	{
		if (abs(localMin - timeinfo_gm->tm_min) > 0)
		{
			_snprintf_s(strTimezone, sizeof(strTimezone), sizeof(strTimezone)-1, "+0%d:%d",localHour - timeinfo_gm->tm_hour, localMin - timeinfo_gm->tm_min);
		}else{
			_snprintf_s(strTimezone, sizeof(strTimezone), sizeof(strTimezone)-1, "+0%d:00",localHour - timeinfo_gm->tm_hour);
		}

	}else if (localHour - timeinfo_gm->tm_hour >= 10)
	{
		if (abs(localMin - timeinfo_gm->tm_min) > 0)
		{
			_snprintf_s(strTimezone, sizeof(strTimezone), sizeof(strTimezone)-1, "+%d:%d",localHour - timeinfo_gm->tm_hour, localMin - timeinfo_gm->tm_min);
		}else{
			_snprintf_s(strTimezone, sizeof(strTimezone), sizeof(strTimezone)-1, "+%d:00",localHour - timeinfo_gm->tm_hour);
		}
	}else if (localHour - timeinfo_gm->tm_hour < 0 && localHour - timeinfo_gm->tm_hour > -10)
	{
		if (abs(localMin - timeinfo_gm->tm_min) > 0)
		{
			_snprintf_s(strTimezone, sizeof(strTimezone), sizeof(strTimezone)-1, "-0%d:%d",abs(localHour - timeinfo_gm->tm_hour), abs(localMin - timeinfo_gm->tm_min));
		}else{
			_snprintf_s(strTimezone, sizeof(strTimezone), sizeof(strTimezone)-1, "-0%d:00",abs(localHour - timeinfo_gm->tm_hour));
		}
	}else if (localHour - timeinfo_gm->tm_hour <= -10)
	{
		if (abs(localMin - timeinfo_gm->tm_min) > 0)
		{
			_snprintf_s(strTimezone, sizeof(strTimezone), sizeof(strTimezone)-1, "-%d:%d",abs(localHour - timeinfo_gm->tm_hour), abs(localMin - timeinfo_gm->tm_min));
		}else{
			_snprintf_s(strTimezone, sizeof(strTimezone), sizeof(strTimezone)-1, "-%d:00",abs(localHour - timeinfo_gm->tm_hour));
		}
	}
#if defined( WINDOWS_8 ) && defined(_WIN32)
	_snprintf_s(dateTime, dateTimeSize, dateTimeSize-1, "%s%s%s%s",strDate, arrDayNames[st.wDayOfWeek], strTime, strTimezone);
#endif //WINDOWS_8
}

int	PDFGenerator::WriteHeader(OutStream* a_pStream)
{
	if (a_pStream == NULL)
		return errOpenFile;

	if(!a_pStream->printf("%%PDF-%.1f\r%%%c%c%c%c\r\n",m_fPDFVersion, 0xe2, 0xe3, 0xcf, 0xd3))
		return errFileIO;

	return errNone;
}

int	PDFGenerator::OpenFile(GString *a_pFileName)
{
	BFile *f = BrNEW BFile();
	OutStream *pStream;

	if ( !f->Open(CUtil::UTF8ToBString(a_pFileName->getCString()), "wb") ) {
		BR_SAFE_DELETE(f);
		//error((-1, "Couldn't open file '%s'", a_pFileName->getCString()));
		ERR_TRACE((PoError)kPoErrFileCreate);
		return errOpenFile;
	}
	pStream = BrNEW FileOutStream(f,0);
	if (pStream == NULL)
	{
		BR_SAFE_DELETE(f);
		SET_ERROR((PoError)kPoErrMemory, "");
		return errMemoryNotEnough;
	}

	m_pFileInfo = f;
	m_pOutStream = pStream;

	return WriteHeader(m_pOutStream);
}

void PDFGenerator::CloseFile()
{
	if (m_pOutStream)
		BrDELETE m_pOutStream;

	BR_SAFE_DELETE(m_pFileInfo);
}

int	PDFGenerator::WriteStream(OutStream* a_pStream, Guint *offset)
{
	int errRet = errNone;
	for (int i = m_nRootNumber; i < m_nEntryCount; i++)
	{
		Ref ref;
		ref.num = i;
		ref.gen = 0;
//		Guint offset ;

		if (m_pbWrited[i] == false)
		{
			if (m_pbXStream[i]){
				XStream* pStream = (XStream*)m_ppObjects[i];
				errRet = WriteStream((XStream*)m_ppObjects[i], &ref, a_pStream, offset);
				BrDELETE pStream;				
			} else {
				Object* pObj = (Object*)m_ppObjects[i];
				errRet = WriteObject((Object*)m_ppObjects[i], &ref, a_pStream, offset);
				if (pObj != NULL)
				{
					pObj->free();

					BrDELETE pObj;
				}
			}

			m_pEntries[i].offset = *offset;
			m_pbWrited[i] = true;
		}			
	}

	Guint uxrefOffset = a_pStream->getPos();

	// write xref to stream
	errRet = WriteXRef(a_pStream);
	if(errRet == errNone)
	{
		// write trailer to stream
		errRet = WriteTrailer(uxrefOffset, m_nEntryCount, a_pStream, true);
	}

	if(errRet != errNone)
		SET_ERROR((PoError)kPoErrFileStorage, "");
	return errRet;
}

int PDFGenerator::WriteXRef(OutStream* a_pStream)
{
	int errRet = errNone;
	//write the new xref
	a_pStream->printf("xref\r\n");
	int i = 0;
	//while (i < m_nEntryCount) {
	//	int j;
	//	for(j=i; j<m_nEntryCount; j++) { //look for consecutive entries
	//		if ((m_pEntries[j].type == xrefEntryFree) && (m_pEntries[j].gen == 0))
	//			break;
	//	}
	//	if (j-i != 0)
	//	{
	//		a_pStream->printf("%i %i\r\n", i, j-i);
	//		for (int k=i; k<j; k++) {
	//			XRefEntry &e = m_pEntries[k];
	//			if(e.gen > 65535) e.gen = 65535; //cap generation number to 65535 (required by PDFReference)
	//			a_pStream->printf("%010i %05i %c\r\n", e.offset, e.gen, (e.type==xrefEntryFree)?'f':'n');
	//		}
	//		i = j;
	//	}
	//	else ++i;
	//}

	a_pStream->printf("%i %i\r\n", 0, m_nEntryCount);
	a_pStream->printf("%010i %05i %c\r\n",0, 65535, 'f');

	for (i = 1; i < m_nEntryCount; i ++)
	{
		XRefEntry &e = m_pEntries[i];
		if(e.gen > 65535) e.gen = 65535; //cap generation number to 65535 (required by PDFReference)
		if(!a_pStream->printf("%010i %05i %c\r\n", e.offset, e.gen, (e.type==xrefEntryFree)?'f':'n'))
		{
			errRet = errFileIO;
			break;
		}
	}

	if(errRet != errNone)
		SET_ERROR((PoError)kPoErrFileStorage, "");
	return errRet;
}

int PDFGenerator::WriteDictionary(Dict* a_pDict, OutStream* a_pStream, bool bFree)
{
	int errRet = errNone;
	Object obj1;
	if (!a_pStream->printf("<<"))
		errRet = errFileIO;

	for (int i=0; i<a_pDict->getLength(); i++) {
		GString keyName(a_pDict->getKey(i));
//		if (!keyName.cmp("Annots") && a_pDict->getValNF(i, &obj1)->isRef())
//		{
//			// songrc - temp
//			//Ref annotsRef = obj1.getRef();
//			//if (xref->getEntry(annotsRef.num)->type == xrefEntryFree)
//			//	continue;
//		}
//		obj1.free();
		GString *keyNameToPrint = keyName.sanitizedName(gFalse /* non ps mode */);
		if(!a_pStream->printf("/%s ", keyNameToPrint->getCString()))
		{
			BrDELETE keyNameToPrint;
			if (bFree )
				obj1.free();
			errRet = errFileIO;
			break;
		}
		BrDELETE keyNameToPrint;

		if (strcmp(keyName.getCString(), "O") == 0 || strcmp(keyName.getCString(), "U") == 0 || strcmp(keyName.getCString(), "ID") == 0
			|| strcmp(keyName.getCString(), "OE") == 0 || strcmp(keyName.getCString(), "UE") == 0 || strcmp(keyName.getCString(), "Perms") == 0)
			dontUseFileKey = true;
		Guint offset;
		errRet = WriteObject(a_pDict->getValNF(i, &obj1), NULL, a_pStream, &offset);
		dontUseFileKey = false;
		if ( bFree )
			obj1.free();
	}
	if (!a_pStream->printf(">>"))
		errRet = errFileIO;
	if (errRet != errNone)
		SET_ERROR((PoError)kPoErrFileStorage, "");
	return errRet;
}

int PDFGenerator::writeStream(BoraStream* str, OutStream* outStr)
{
	int errRet = errNone;
	if (!outStr->printf("stream\r\n"))
	{
		errRet = errFileIO;
	}
	str->reset();
	for (int c = str->getChar(); c != EOF; c = str->getChar()) {
		if (!outStr->printf("%c", c))
			errRet = errFileIO;
	}
	if (!outStr->printf("\r\nendstream\r\n"))
		errRet = errFileIO;

	if (errRet != errNone)
		SET_ERROR((PoError)kPoErrFileStorage, "");
	return errRet;
}

int PDFGenerator::WriteStream (XStream* a_pXStr, Ref *a_pRef, OutStream* a_pStream, Guint *offset)
{
	int errRet = errNone;
	
	if (a_pXStr == NULL || a_pRef == NULL)
		return errDamaged;

	*offset = a_pStream->getPos();
	Object* pDict = a_pXStr->GetDict();

	if(a_pRef) 
		a_pStream->printf("%i %i obj\r\n", a_pRef->num, a_pRef->gen);

	Guchar* fileKey = NULL;
	Guchar* newfilekey = NULL;
	CryptAlgorithm encAlgorithm = cryptRC4;
	int keyLength = 0;
	CryptType nEncryptType = cryptNone;
	if ( m_xref )
		m_xref->getEncryptionParameters(&fileKey, &encAlgorithm, &keyLength, &nEncryptType, &newfilekey);

	//if (nEncryptType == cryptChangePassword)
	//{
	//	if (newfilekey != NULL)
	//		fileKey = newfilekey;
	//}
	//else if (nEncryptType == cryptDeletePassword || (fileKey != BrNULL && saveAsPageNums != BrNULL))
	//{
	//	fileKey = BrNULL;
	//	nEncryptType = cryptDeletePassword;
	//	// saveAsPageNums �� Null �� �ƴ� ���� ������ ������ , ���� �� ���
	//}

	if (nEncryptType == cryptNewPassword && fileKey)
	{
		Object obj;

		EncryptStream* encStream = NULL;
		encStream = BrNEW EncryptStream(BrNEW MemStream((char*)a_pXStr->GetStreamBuffer(), 0, a_pXStr->GetStreamBufferLength(), obj.initNull()),
			fileKey, encAlgorithm, keyLength, a_pRef->num, a_pRef->gen);
		encStream->setAutoDelete(gFalse);

		encStream->reset();
		//recalculate stream length
		int tmp = 0;
		for (int c = encStream->getChar(); c != EOF; c = encStream->getChar()) {
			tmp++;
		}
		obj.initInt(tmp);
		pDict->getDict()->set("Length", &obj);
		obj.free();

		if (errNone != WriteDictionary(pDict->getDict(), a_pStream))
			return errFileIO;

		errRet = writeStream(encStream, a_pStream);
		if (errRet != errNone)
			return errRet;
	}
	else
	{
		if (errNone != WriteDictionary(pDict->getDict(), a_pStream))
			return errFileIO;

		a_pStream->printf("stream\r\n");
		if (!a_pStream->writeBuffer((byte*)a_pXStr->GetStreamBuffer(), a_pXStr->GetStreamBufferLength()))
			return errFileIO;
		a_pStream->printf("\r\nendstream\r\n");

	}

	if (a_pRef)
		a_pStream->printf("endobj\r\n");

	if(errRet != errNone)
		SET_ERROR((PoError)kPoErrFileStorage, "");
	return errRet;
}

int PDFGenerator::WriteString (GString* a_pString, OutStream* a_pStream, Guchar* fileKey, CryptAlgorithm encAlgorithm, int keyLength, int objNum, int objGen, bool bHex)
{
	int errRet = errNone;
	const char* parens1 = (bHex ? "<" : "(");
	const char* parens2 = (bHex ? "> " : ") ");
	// Encrypt string if encryption is enabled
	GString* sEnc = NULL;
	if (fileKey && !dontUseFileKey) {
		Object obj;
		EncryptStream* enc = BrNEW EncryptStream(BrNEW MemStream(a_pString->getCString(), 0, a_pString->getLength(), obj.initNull()),
			fileKey, encAlgorithm, keyLength, currentRef.num, currentRef.gen);
		sEnc = BrNEW GString();
		int c;
		enc->reset();
		while ((c = enc->getChar()) != EOF) {
			sEnc->append((char)c);
		}

		BrDELETE enc;
		a_pString = sEnc;
	}

	if (a_pString->hasUnicodeMarker()) {
		//unicode string don't necessary end with \0
		const char* c = a_pString->getCString();
		if (!a_pStream->printf(parens1))
			errRet = errFileIO;
		for(int i=0; i<a_pString->getLength(); i++) {
			char unescaped = *(c+i)&0x000000ff;
			//escape if needed
			if (unescaped == '(' || unescaped == ')' || unescaped == '\\')
			{
				if(!a_pStream->printf("%c", '\\'))
				{
					errRet = errFileIO;
					break;
				}
			}
			if(!a_pStream->printf("%c", unescaped))
			{
				errRet = errFileIO;
				break;
			}
		}
		if (!a_pStream->printf(parens2))
			errRet = errFileIO;
	} else {
		const char* c = a_pString->getCString();
		if (!a_pStream->printf(parens1))
			errRet = errFileIO;
		for(int i=0; i<a_pString->getLength(); i++) {
			char unescaped = *(c + i) & 0x000000ff;
			//escape if needed
			if (unescaped == '\r')
				a_pStream->printf("\\r");
			else if (unescaped == '\n')
				a_pStream->printf("\\n");
			else {
				if (unescaped == '(' || unescaped == ')' || unescaped == '\\') {
					a_pStream->printf("%c", '\\');
				}
				a_pStream->printf("%c", unescaped);
			}
		}
		if (!a_pStream->printf(parens2))
			errRet = errFileIO;
	}
	BrDELETE sEnc;

	if(errRet != errNone)
		SET_ERROR((PoError)kPoErrFileStorage, "");

	return errRet;
}

int PDFGenerator::WriteObject (Object *a_pObj, Ref *a_pRef, OutStream* a_pStream, Guint *offset)
{
	Guchar* fileKey = NULL;
	Guchar* newfilekey = NULL;
	CryptAlgorithm encAlgorithm = cryptRC4;
	int keyLength = 0;
	CryptType nEncryptType = cryptNone;
	if (m_xref)
		m_xref->getEncryptionParameters(&fileKey, &encAlgorithm, &keyLength, &nEncryptType, &newfilekey);

	//if (nEncryptType == cryptChangePassword)
	//{
	//	if (newfilekey != NULL)
	//		fileKey = newfilekey;
	//}
	//else if (nEncryptType == cryptDeletePassword || (fileKey != BrNULL && saveAsPageNums != BrNULL))
	//{
	//	fileKey = BrNULL;
	//	nEncryptType = cryptDeletePassword;
	//	// saveAsPageNums �� Null �� �ƴ� ���� ������ ������ , ���� �� ���
	//}

	int errRet = errNone;
	Array *array;
	Object obj1;
	*offset = a_pStream->getPos();

	if (a_pObj == NULL)
		return errDamaged;

	if (a_pRef)
	{
		if ( !a_pStream->printf("%i %i obj\n", a_pRef->num, a_pRef->gen) )
			errRet = errFileIO;
		currentRef.num = a_pRef->num; currentRef.gen = a_pRef->gen;
	}

	switch (a_pObj->getType()) {
	case objBool:
		if ( !a_pStream->printf("%s ", a_pObj->getBool()?"true":"false") )
			errRet = errFileIO;
		break;
	case objInt:
		if ( !a_pStream->printf("%i ", a_pObj->getInt()) )
			errRet = errFileIO;
		break;
	case objReal:
		{
			GString s;
			s.appendf("{0:.10g}", a_pObj->getReal());
			if(!a_pStream->printf("%s ", s.getCString()))
			{
				errRet = errFileIO;
			}
			break;
		}
	case objString:
		errRet = WriteString(a_pObj->getString(), a_pStream, fileKey, encAlgorithm, keyLength, 0, 0, a_pObj->getType() == objHexString);
		break;
	case objName:
		{
			GString name(a_pObj->getName());
			GString *nameToPrint = name.sanitizedName(gFalse /* non ps mode */);
			if(!a_pStream->printf("/%s ", nameToPrint->getCString()))
			{
				errRet = errFileIO;
			}
			BrDELETE nameToPrint;
			break;
		}
	case objNull:
		if ( !a_pStream->printf( "null") )
			errRet = errFileIO;
		break;
	case objArray:
		{
			array = a_pObj->getArray();
			if ( !a_pStream->printf("[") )
				errRet = errFileIO;
			Guint offset1;
			for (int i=0; i<array->getLength(); i++) {
				errRet = WriteObject(array->getNF(i, &obj1), NULL,a_pStream, &offset1);
				if(errRet == errFileIO)
				{
					obj1.free();
					break;
				}
				obj1.free();
			}
			if ( !a_pStream->printf("]") )
				errRet = errFileIO;
		}
		break;
	case objDict:
		errRet = WriteDictionary(a_pObj->getDict(),a_pStream);
		break;
	case objRef:
		if ( !a_pStream->printf("%i %i R ", a_pObj->getRef().num, a_pObj->getRef().gen) )
			errRet = errFileIO;
		break;
	case objCmd:
		if ( !a_pStream->printf("cmd\r\n") )
			errRet = errFileIO;
		break;
	case objError:
		if ( !a_pStream->printf("error\r\n") )
			errRet = errFileIO;
		break;
	case objEOF:
		if ( !a_pStream->printf("eof\r\n") )
			errRet = errFileIO;
		break;
	case objNone:
		if ( !a_pStream->printf("none\r\n") )
			errRet = errFileIO;
		break;
	default:
		error((-1,"Unhandled objType : %i, please report a bug with a testcase\r\n", a_pObj->getType()));
		break;
	}

	if (a_pRef)
	{
		if (a_pObj->getType() == objStream)
		{
			if (!a_pStream->printf("endobj\r\n"))
				errRet = errFileIO;
		}
		else
		{
			if (!a_pStream->printf("\nendobj\r\n"))
				errRet = errFileIO;
		}
	}

	if(errRet != errNone)
		SET_ERROR((PoError)kPoErrFileStorage, "");

	return errRet;
}

PDFEncoder*	PDFGenerator::GetEncoder(int a_nType)
{
	PDFEncoder* pEncoder = NULL;

	switch (a_nType)
	{
		case ePDF_ENCODE_FLATE:
			{
				if (m_pEncoders[ePDF_ENCODE_FLATE] == NULL)
				{
					m_pEncoders[ePDF_ENCODE_FLATE] = BrNEW PDFFlateEncoder();
					if (m_pEncoders[ePDF_ENCODE_FLATE] == NULL)
					{
						SET_ERROR((PoError)kPoErrMemory, "");
						return NULL;
					}
				}

				pEncoder = m_pEncoders[ePDF_ENCODE_FLATE];
			}
			break;

		default:
			{
				if (m_pEncoders[ePDF_ENCODE_FLATE] == NULL)
				{
					m_pEncoders[ePDF_ENCODE_FLATE] = BrNEW PDFFlateEncoder();
					if (m_pEncoders[ePDF_ENCODE_FLATE] == NULL)
					{
						SET_ERROR((PoError)kPoErrMemory, "");
						return NULL;
					}
				}

				pEncoder = m_pEncoders[ePDF_ENCODE_FLATE];
			}
			break;
	}

	return pEncoder;
}

GBool PDFGenerator::ResetEncodeBuffer(Guint nSize)
{
	nSize = BrMAX(nSize + Guint(nSize*0.001)+12, ENCODE_BUFFER_LENGTH);
	
	if (m_pEncodeBuffer == NULL)
	{
		m_pEncodeBuffer = gmalloc(nSize);
		m_nEncodeBufferLen = nSize;
		if (m_pEncodeBuffer == NULL)
		{
			m_nEncodeBufferLen = 0;	
			return gFalse;
		}
	}
	else
	{
		if((int)nSize > m_nEncodeBufferLen)
		{
			m_pEncodeBuffer = grealloc(m_pEncodeBuffer, nSize);
			if(!m_pEncodeBuffer)
			{
				m_nEncodeBufferLen = 0;
				return gFalse;
			}
			m_nEncodeBufferLen = nSize;
		}
	}

	memset(m_pEncodeBuffer, 0, m_nEncodeBufferLen);
	return gTrue;
}

GraphicsXStream* PDFGenerator::BeginPath()
{
	int result = errNone;
	if (m_nCurPage >= m_nPageCount)
		return NULL;
	Object* pPage = (Object*)m_ppObjects[m_pPageNumbers[m_nCurPage]];
	if (pPage == NULL)
		return NULL;

	XRect pageRect;
	GetPageRect(m_nCurPage, &pageRect);
	Object oContentsRef;
	GraphicsXStream* pContents = NULL;

	pPage->getDict()->lookupNF("Contents", &oContentsRef);
	if (oContentsRef.isNull())
	{
		pContents = (GraphicsXStream*)GenerateContents(GRAPHICS_TYPE);
		if(pContents == BrNULL)
			return NULL;
		pContents->Initialize(pageRect);

		oContentsRef.initRef(m_nEntryIndex, 0);
		pPage->getDict()->add(XGetKey("Contents"), &oContentsRef);
		//m_pbXStream[m_nEntryIndex] = true;
	}
	else
	{
		pContents = (GraphicsXStream*)m_ppObjects[oContentsRef.getRef().num];
		pContents->Initialize(pageRect);
		oContentsRef.free();
	}

	GString* str = GString::format("q\n");

	result = pContents->AddDataBuffer(str);

	//[15.12.15][sglee1206] Coverity
	if(result != errNone)
	{
		BTrace("%s(%d): add Data fail",__FILE__,__LINE__);
	}
	else
	{
		// Coverity-23012
		// errNone �� ��쿡�� Delete
		BR_SAFE_DELETE(str);
	}

	return pContents;
}

int PDFGenerator::EndPath(GraphicsXStream* pPath)
{
	int result = pPath->finalize();
	return result;
}

BrINT PDFGenerator::SetGState(GraphicsXStream* pPath, LPBrXPDFGSInfo pGsInfo)
{
	int result = errNone;
	if(pGsInfo->nFillOpacity == -1 && pGsInfo->nStrokeOpacity == -1)
		return result;

	Object* pGsObj = BrNEW Object();
	if (pGsObj == NULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");
		return NULL;
	}


	pGsObj->initDict((XRef*)NULL);

	float opacity;
	Object opacityObj;
	if(pGsInfo->nStrokeOpacity != -1)
	{
		opacity = (float)pGsInfo->nStrokeOpacity / 255.f;
		opacityObj.initReal(opacity);
		pGsObj->getDict()->add(XGetKey("CA"), &opacityObj);
	}
	if(pGsInfo->nFillOpacity != -1)
	{
		opacity = (float)pGsInfo->nFillOpacity / 255.f;
		opacityObj.initReal(opacity);
		pGsObj->getDict()->add(XGetKey("ca"), &opacityObj);
	}

	result = AddXRefEntry(pGsObj);
	m_nGSObjectCount++;

	// 2.2 Add font object to resource
	if(result == errNone)
		result = AddPathToPage(m_nEntryIndex, pPath);

	return result;
}

int	PDFGenerator::AddPathToPage(int gsRef, GraphicsXStream* pPath)
{
	Object* pPage = (Object*)m_ppObjects[m_pPageNumbers[m_nCurPage]];
	if (pPage == NULL)
		return errBadCatalog;

	// 1. Check the Resource in Page.
	Object oResoucesDict;

	pPage->getDict()->lookupNF("Resources", &oResoucesDict);
	if (oResoucesDict.isNull())
	{
		oResoucesDict.initDict((XRef*)NULL);
		pPage->getDict()->add(XGetKey("Resources"), &oResoucesDict);
		oResoucesDict.getDict()->incRef();
	}

	// 2. Check the ExtGState in Resource
	Object oGsDict;
	oResoucesDict.getDict()->lookupNF("ExtGState", &oGsDict);
	if (oGsDict.isNull())
	{
		oGsDict.initDict((XRef*)NULL);
		oResoucesDict.getDict()->add(XGetKey("ExtGState"), &oGsDict);
		oGsDict.getDict()->incRef();
	}

	// 3. Add the ExtGState.
	Object oGSObjRef;
	oGSObjRef.initRef(gsRef, 0);

	char* pszGSObjName = GSObjectName(m_nGSObjectCount);

	oGsDict.getDict()->add(XGetKey(pszGSObjName), &oGSObjRef);

	pPath->SetGState(pszGSObjName);

	BrFree(pszGSObjName);
	oResoucesDict.free();
	oGsDict.free();

	return errNone;
}

void PDFGenerator::SetWritingMode(EBrXPDFWritingMode nMode)
{
	m_eWritingMode = nMode;
}

void PDFGenerator::SetTextExportType(EBrXFontType nType)
{
	m_eTextType = nType;
}

BrINT PDFGenerator::getUCSUnicodeLength()
{
	return m_pExportData.at(m_nCurEmbeddedFont)->getTextDataLength();
}

void PDFGenerator::setFlipType(BrFigureFlipType flipType)
{
	Object* pPage = (Object*)m_ppObjects[m_pPageNumbers[m_nCurPage]];

	Object oContentsRef;
	GraphicsXStream* pContents = NULL;

	pPage->getDict()->lookupNF("Contents", &oContentsRef);
	if (oContentsRef.isNull())
	{
		pContents = BeginPath();
		if(pContents)
			EndPath(pContents);

		oContentsRef.initRef(m_nEntryIndex, 0);
		pPage->getDict()->add(XGetKey("Contents"), &oContentsRef);
		//m_pbXStream[m_nEntryIndex] = true;
	}
	else
	{
		pContents = (GraphicsXStream*) m_ppObjects[oContentsRef.getRef().num];
		oContentsRef.free();
	}
	pContents->setFlipType(flipType);
}
BrFigureFlipType PDFGenerator::getFlipType()
{
	Object* pPage = (Object*)m_ppObjects[m_pPageNumbers[m_nCurPage]];

	Object oContentsRef;
	GraphicsXStream* pContents = NULL;

	pPage->getDict()->lookupNF("Contents", &oContentsRef);
	if (oContentsRef.isNull())
	{
		pContents = BeginPath();
		if (pContents)
			EndPath(pContents);

		oContentsRef.initRef(m_nEntryIndex, 0);
		pPage->getDict()->add(XGetKey("Contents"), &oContentsRef);
		//m_pbXStream[m_nEntryIndex] = true;
	}
	else
	{
		pContents = (GraphicsXStream*) m_ppObjects[oContentsRef.getRef().num];
		oContentsRef.free();
	}
	return pContents->getFlipType();
}
void PDFGenerator::setRotateAngle(BrINT angle)
{
	Object* pPage = (Object*)m_ppObjects[m_pPageNumbers[m_nCurPage]];

	Object oContentsRef;
	GraphicsXStream* pContents = NULL;

	pPage->getDict()->lookupNF("Contents", &oContentsRef);
	if (oContentsRef.isNull())
	{
		pContents = BeginPath();
		if (pContents)
			EndPath(pContents);

		oContentsRef.initRef(m_nEntryIndex, 0);
		pPage->getDict()->add(XGetKey("Contents"), &oContentsRef);
		//m_pbXStream[m_nEntryIndex] = true;
	}
	else
	{
		pContents = (GraphicsXStream*) m_ppObjects[oContentsRef.getRef().num];
		oContentsRef.free();
	}
	pContents->setRotate(angle);
}

void PDFGenerator::setFigureBox(LPBrRect bbox)
{
	Object* pPage = (Object*)m_ppObjects[m_pPageNumbers[m_nCurPage]];

	Object oContentsRef;
	GraphicsXStream* pContents = NULL;

	pPage->getDict()->lookupNF("Contents", &oContentsRef);
	if (oContentsRef.isNull())
	{
		pContents = BeginPath();
		if (pContents)
			EndPath(pContents);

		oContentsRef.initRef(m_nEntryIndex, 0);
		pPage->getDict()->add(XGetKey("Contents"), &oContentsRef);
		//m_pbXStream[m_nEntryIndex] = true;
	}
	else
	{
		pContents = (GraphicsXStream*) m_ppObjects[oContentsRef.getRef().num];
		oContentsRef.free();
	}
	pContents->setFigureBox(bbox);
}

void PDFGenerator::getFigureBox(XRect * bbox)
{
	Object* pPage = (Object*)m_ppObjects[m_pPageNumbers[m_nCurPage]];

	Object oContentsRef;
	GraphicsXStream* pContents = NULL;

	pPage->getDict()->lookupNF("Contents", &oContentsRef);
	if (oContentsRef.isNull())
	{
		pContents = BeginPath();
		if (pContents)
			EndPath(pContents);

		oContentsRef.initRef(m_nEntryIndex, 0);
		pPage->getDict()->add(XGetKey("Contents"), &oContentsRef);
		//m_pbXStream[m_nEntryIndex] = true;
	}
	else
	{
		pContents = (GraphicsXStream*) m_ppObjects[oContentsRef.getRef().num];
		oContentsRef.free();
	}

	BrRect getbbox = pContents->getFigureBox();
	bbox->left = getbbox.left;	bbox->top = getbbox.top;	bbox->right = getbbox.right;	bbox->bottom = getbbox.bottom;
}



void PDFGenerator::setFillType(int fillType)
{
	Object* pPage = (Object*)m_ppObjects[m_pPageNumbers[m_nCurPage]];

	Object oContentsRef;
	GraphicsXStream* pContents = NULL;

	pPage->getDict()->lookupNF("Contents", &oContentsRef);
	if (oContentsRef.isNull())
	{
		pContents = BeginPath();
		if (pContents)
			EndPath(pContents);

		oContentsRef.initRef(m_nEntryIndex, 0);
		pPage->getDict()->add(XGetKey("Contents"), &oContentsRef);
		//m_pbXStream[m_nEntryIndex] = true;
	}
	else
	{
		pContents = (GraphicsXStream*) m_ppObjects[oContentsRef.getRef().num];
		oContentsRef.free();
	}

	pContents->SetFillMode(fillType ? eXFILL_NONZERO_WINDING : exFILL_EVEN_ODD);
}

BrINT PDFGenerator::getPageHeight()
{
	Object* pPage = (Object*)m_ppObjects[m_pPageNumbers[m_nCurPage]];

	Object oContentsRef;
	GraphicsXStream* pContents = NULL;

	pPage->getDict()->lookupNF("Contents", &oContentsRef);
	if (oContentsRef.isNull())
	{
		pContents = BeginPath();
		if (pContents)
			EndPath(pContents);

		oContentsRef.initRef(m_nEntryIndex, 0);
		pPage->getDict()->add(XGetKey("Contents"), &oContentsRef);
		//m_pbXStream[m_nEntryIndex] = true;
	}
	else
	{
		pContents = (GraphicsXStream*) m_ppObjects[oContentsRef.getRef().num];
		oContentsRef.free();
	}

	XRect bbox = {0,};
	int result = GetPageRect(m_nCurPage, &bbox);

	return (bbox.bottom - bbox.top);
}


Object* PDFGenerator::getObject(int entryNum)
{
	return (Object*)m_ppObjects[entryNum];
}

int PDFGenerator::addOutlinesDict(int first, int last, int count)
{
	Object* outlinesObj = BrNEW Object();
	outlinesObj->initDict((XRef*)NULL);
	Object obj;
	outlinesObj->getDict()->add(XGetKey("Type"), obj.initName("Outlines")) ;
	if(count > 0)
		outlinesObj->getDict()->add(XGetKey("Count"), obj.initInt(count)) ;
	if(first > 0)
		outlinesObj->getDict()->add(XGetKey("First"), obj.initRef(first, 0)) ;
	if(last > 0)
		outlinesObj->getDict()->add(XGetKey("Last"), obj.initRef(last, 0)) ;

	if(AddXRefEntry(outlinesObj) == errNone)
		return m_nEntryIndex;
	return -1;
}

int PDFGenerator::addOutlineItem(GString* title, int parent, int prev, int next, int first, int last, int count, int action, int pageEntryNum, int posx, int posy)
{
	Object* outlineObj = BrNEW Object();
	outlineObj->initDict((XRef*)NULL);
	Object obj;

	if(title == BrNULL)
		title = BrNEW GString("");
	outlineObj->getDict()->add(XGetKey("Title"), obj.initString(title)) ;
	if(parent > 0)
		outlineObj->getDict()->add(XGetKey("Parent"), obj.initRef(parent, 0));
	if(prev > 0)
		outlineObj->getDict()->add(XGetKey("Prev"), obj.initRef(prev, 0));
	if(next > 0)
		outlineObj->getDict()->add(XGetKey("Next"), obj.initRef(next, 0));
	if(first > 0)
		outlineObj->getDict()->add(XGetKey("First"), obj.initRef(first, 0));
	if(last > 0)
		outlineObj->getDict()->add(XGetKey("Last"), obj.initRef(last, 0));
	if(count > 0)
		outlineObj->getDict()->add(XGetKey("Count"), obj.initInt(count));
	if(action > 0)
	{
		outlineObj->getDict()->add(XGetKey("A"), obj.initRef(parent, 0));
	}
	if(pageEntryNum > 0)
	{
		Object actionObj;
		actionObj.initDict((XRef*)NULL);
		
		Object tObj;
		obj.initArray((XRef*)NULL);
		obj.arrayAdd(tObj.initRef(pageEntryNum, 0));
		obj.arrayAdd(tObj.initName("XYZ"));
		obj.arrayAdd(tObj.initInt(posx));
		obj.arrayAdd(tObj.initInt(posy));
		obj.arrayAdd(tObj.initInt(0));

		actionObj.getDict()->add(XGetKey("D"), &obj);
		actionObj.getDict()->add(XGetKey("S"), tObj.initName("GoTo"));
		outlineObj->getDict()->add(XGetKey("A"), &actionObj);
	}

	if(AddXRefEntry(outlineObj) == errNone)
		return m_nEntryIndex;
	return -1;
}

void PDFGenerator::addChildOutlieItems(XBookmark* bookmark)
{
	for(int i = 0; i < bookmark->children.count(); i++)
	{
		XBookmark* item = *bookmark->children.GetAt(i);
		int refNum = addOutlineItem(item->title, 0, 0, 0, 0, 0, 0, 0, getPageEntryNum(item->pageNum), item->x, item->y);
		if(refNum == -1)
			return;
		item->refNum = refNum;
	}
}
int PDFGenerator::addOutlines(XBookmark* root)
{
	int refNum = 0;
	refNum = addOutlinesDict(0,0,root->getAllChildCount());
	if(refNum == -1)
		return -1;
	root->refNum = refNum;
	Object* catalog = getObject(m_nCatalogRefNum);
	Object obj;
	catalog->getDict()->add(XGetKey("Outlines"), obj.initRef(refNum, 0));
	
	addChildOutlieItems(root);

	int nMaxLevel = root->getMaxLevel();

	for(int i = 1; i < nMaxLevel; i++)
	{
		BArray<XBookmark*>* levelItems = root->getOutlineItemsAtLevel(i);
		for(int  j = 0; j < levelItems->count(); j++)
		{
			XBookmark* item = *levelItems->GetAt(j);
			addChildOutlieItems(item);
		}
		BrDELETE levelItems;
	}

	if(root->getAllChildCount() < 1)
		return 0;
	// first, last, parent, prev, last, count
	Object* remarkObj;
	remarkObj = getObject(refNum);
	int first = ((XBookmark*)*root->children.GetAt(0))->refNum;
	int last  = ((XBookmark*)*root->children.GetAt(root->children.count() - 1))->refNum;
	remarkObj->getDict()->add(XGetKey("First"), obj.initRef(first, 0));
	remarkObj->getDict()->add(XGetKey("Last"), obj.initRef(last, 0));
	for(int i = 0; i < root->children.count(); i++)
	{
		XBookmark* child = *root->children.GetAt(i);
		remarkObj = getObject(child->refNum);
		remarkObj->getDict()->add(XGetKey("Parent"), obj.initRef(refNum, 0));
		if(i != 0)
		{
			int prev = ((XBookmark*)*root->children.GetAt(i - 1))->refNum;
			remarkObj->getDict()->add(XGetKey("Prev"), obj.initRef(prev, 0));
		}
		if(i !=  root->children.count() - 1)
		{
			int next = ((XBookmark*)*root->children.GetAt(i + 1))->refNum;
			remarkObj->getDict()->add(XGetKey("Next"), obj.initRef(next, 0));
		}
	}

	for(int i = 1; i < nMaxLevel; i++)
	{
		BArray<XBookmark*>* levelItems = root->getOutlineItemsAtLevel(i);
		for(int  j = 0; j < levelItems->count(); j++)
		{
			XBookmark* item = *levelItems->GetAt(j);
			if(item->children.count() < 1)
				continue;
			remarkObj = getObject(item->refNum);
			first = ((XBookmark*)*item->children.GetAt(0))->refNum;
			last  = ((XBookmark*)*item->children.GetAt(item->children.count() - 1))->refNum;
			remarkObj->getDict()->add(XGetKey("First"), obj.initRef(first, 0));
			remarkObj->getDict()->add(XGetKey("Last"), obj.initRef(last, 0));
			remarkObj->getDict()->add(XGetKey("Count"), obj.initInt(item->getAllChildCount()));

			for(int k = 0; k < item->children.count(); k++)
			{
				XBookmark* child = *item->children.GetAt(k);
				remarkObj = getObject(child->refNum);
				remarkObj->getDict()->add(XGetKey("Parent"), obj.initRef(item->refNum, 0));
				if(k != 0)
				{
					int prev = ((XBookmark*)*item->children.GetAt(k - 1))->refNum;
					remarkObj->getDict()->add(XGetKey("Prev"), obj.initRef(prev, 0));
				}
				if(k !=  item->children.count() - 1)
				{
					int next = ((XBookmark*)*item->children.GetAt(k + 1))->refNum;
					remarkObj->getDict()->add(XGetKey("Next"), obj.initRef(next, 0));
				}
			}
		}
		BrDELETE levelItems;
	}

	return 1;
}

void PDFGenerator::getSysFontFace()
{
	BrINT nFontFace = BrGetSystemFontFaceCnt();
	BrINT nInterFontFace = BrGetInternalFontFaceCnt();
	m_nSysFontCnt = nFontFace + nInterFontFace;
	if(m_Face != NULL)
		free(m_Face);
	m_Face = (PO_Face*)malloc(sizeof(PO_Face)*(m_nSysFontCnt+1));
	memset(m_Face, 0, sizeof(PO_Face)*(m_nSysFontCnt+1));
	
	PO_Face* fontFace = (PO_Face*)BrGetSystemFontFace();
	PO_Face* internalFace = (PO_Face*)BrGetInternalFontFace();
	
	if(internalFace != BrNULL)
	{
		BrINT i,j;
		i = j = 0;
		for(BrINT idx = 0; idx < m_nSysFontCnt; idx++)
		{
			if(fontFace[i] != BrNULL && internalFace[j] != BrNULL)
				m_Face[idx] = fontFace[i]->nFontPoolIndex <= internalFace[j]->nFontPoolIndex ? fontFace[i++]:internalFace[j++];
			else if(fontFace[i] != BrNULL)
				m_Face[idx] = fontFace[i++];
			else if(internalFace[j] != BrNULL)
				m_Face[idx] = internalFace[j++];
			else
				m_Face[idx] = NULL;
		}
	}
	else
	{
		for(BrINT idx = 0; idx < m_nSysFontCnt; idx++)
			m_Face[idx] = fontFace[idx];
	}
}
#endif // EXPORT_PDF
