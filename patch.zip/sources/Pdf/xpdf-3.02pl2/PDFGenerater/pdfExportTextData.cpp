#include <OfficePreCompPDF.hpp>

#ifdef EXPORT_PDF

#include "pdfExportTextData.h"
#include "XStream.h"
#include "font/pdfFont.h"
//#include "XCommon.h"

PDFExportTextData::PDFExportTextData()
{
	m_pTextData = BrNULL;
	m_pGlyphData = BrNULL;
	m_nTextArrayCapacity = DEFAULT_TEXT_ARRAY_SIZE;
	m_pTextData = (BrULONG*)BrMalloc(BrSizeOf(BrULONG)*(m_nTextArrayCapacity+1));
	m_pGlyphData = (BrINT*)BrMalloc(BrSizeOf(BrINT)*(m_nTextArrayCapacity+1));
	//[18.03.09][sglee1206][WPD-1104]Glyph Index Oth .notdef �� �����ϹǷ� -1�� �ʱ�ȭ��
	memset(m_pGlyphData, -1, BrSizeOf(BrINT)*m_nTextArrayCapacity);

	m_FontInfoEntryIndex = 0;
	m_nFontUnicodeIndex = 0;
	m_FontCIDSetEntryIndex = 0;
	m_pEncodeBuffer = BrNULL;
	m_nEncodeBufferLen = 0;	
	m_pEncodeCIDSetBuffer = BrNULL;
	m_nEncodeCIDSetBufferLen = 0;	
	m_pFont = BrNEW PDFFont;
	m_pFontBuf = BrNULL;
	m_pFontFilePath = (BrCHAR*)BrMalloc(MAX_XPDF_FONT_LEN);
	m_nFontFileSize = 0;

	m_pCIDSetBuf = BrNULL;
	m_nCIDSetSize = 0;
	memset(m_pFontFilePath, 0, MAX_XPDF_FONT_LEN);
	m_pFontDataAddr = BrNULL;
	m_nFontDataSize = 0;
	m_nTextArraySize = 0;	
	m_pFontFaceName = BrNULL;
	m_nFontFaceIndex = -1;
	m_oDescendentFont.initNull();
	m_nFirstGlyf = -1;
	m_nLastGlyf = 0;

	m_nCidIndicesCapacity = DEFAULT_TEXT_ARRAY_SIZE;
	m_nUsedCidIndices = BrNULL;
	m_nUsedCidIndices = (BrINT*)BrMalloc(BrSizeOf(BrINT)*(m_nCidIndicesCapacity+1));
	m_nUsedCidIndicesSize = 0;
	m_bUseCFF = BrFALSE;
	m_pCFF	= BrNULL;
	m_eExportTextType = ePDF_TEXT_TYPE_NORMAL;
}

PDFExportTextData::~PDFExportTextData()
{
	BR_SAFE_FREE( m_pTextData );
	BR_SAFE_FREE( m_pGlyphData );
	BR_SAFE_FREE( m_pEncodeBuffer );
	BR_SAFE_FREE( m_pEncodeCIDSetBuffer );
	BR_SAFE_DELETE( m_pFont );
	BR_SAFE_FREE(m_pFontFilePath);

	if(!m_oDescendentFont.isNull())
	{
		m_oDescendentFont.free();
	}

	BR_SAFE_FREE(m_pFontBuf);
	BR_SAFE_FREE(m_pCIDSetBuf);
	BR_SAFE_FREE(m_nUsedCidIndices);

	BR_SAFE_FREE(m_pFontFaceName);
}

void PDFExportTextData::addText(BrULONG* pTextData, BrINT nIndex)
{
	int i = 0;
	BrWORD glyfIndex = m_pFont->getCodeFromCodeMap(*pTextData);

	if(glyfIndex == 0)
		return;

	BrWORD usedCidIndex = -1;
	if(m_bUseCFF && m_pCFF && m_pCFF->m_arrCIDs)
	{
		if(m_pCFF->m_arrCIDs.GetSize() > glyfIndex)
		{
			usedCidIndex = glyfIndex;
			glyfIndex = m_pCFF->m_arrCIDs.at(glyfIndex);
		}
	}

	for(i = 0; i < m_nTextArraySize; i++)
	{
		if(m_pGlyphData[i] == glyfIndex)		// same char
			return;
		else if(m_pGlyphData[i] > glyfIndex)	// index over
			break;
	}

	if( m_nTextArrayCapacity == m_nTextArraySize)
	{
		m_nTextArrayCapacity += DEFAULT_TEXT_ARRAY_SIZE;
		BrULONG* pCopyData = (BrULONG*)BrMalloc(BrSizeOf(BrULONG)*(m_nTextArrayCapacity+1));
		if( !pCopyData )
		{
			SET_ERROR((PoError)kPoErrMemory, "");

			return;
		}

		BrINT* pCopyCovertData = (BrINT*)BrMalloc(BrSizeOf(BrINT)*(m_nTextArrayCapacity+1));
		if( !pCopyCovertData )
		{
			SET_ERROR((PoError)kPoErrMemory, "");

			//[16.12.13] Coverity-22930
			BR_SAFE_FREE(pCopyData);

			return;
		}

		memset(pCopyData, 0, BrSizeOf(BrULONG)*m_nTextArrayCapacity);
		memcpy(pCopyData, m_pTextData, BrSizeOf(BrULONG)*m_nTextArraySize);
		BrFree(m_pTextData);
		m_pTextData = pCopyData;

		memset(pCopyCovertData, -1, BrSizeOf(BrINT)*m_nTextArrayCapacity);
		memcpy(pCopyCovertData, m_pGlyphData, BrSizeOf(BrINT)*m_nTextArraySize);
		BrFree(m_pGlyphData);
		m_pGlyphData = pCopyCovertData;
	}

	for(int k = m_nTextArraySize; k > i; k--)
	{
		m_pTextData[k] = m_pTextData[k-1];
		m_pGlyphData[k] = m_pGlyphData[k-1];
	}
	m_pTextData[i] = *pTextData;
	m_pGlyphData[i] = glyfIndex;
	m_nTextArraySize++;
	m_nFirstGlyf = (m_pTextData[0] != 0 && m_nTextArraySize >=2)? m_pGlyphData[1]:m_pGlyphData[0];
	m_nLastGlyf = m_pGlyphData[m_nTextArraySize-1];
	addUseCidIndex(usedCidIndex);
}

void PDFExportTextData::addGylfIndex(BrULONG* pTextData, BrINT pGlyfIndex)
{
	int i = 0;
	BrWORD usedCidIndex = -1;
	if(m_bUseCFF && m_pCFF && m_pCFF->m_arrCIDs)
	{
		if(m_pCFF->m_arrCIDs.GetSize() > pGlyfIndex)
		{
			usedCidIndex = pGlyfIndex;
			pGlyfIndex = m_pCFF->m_arrCIDs.at(pGlyfIndex);
		}
	}
	for(i = 0; i < m_nTextArraySize; i++)
	{
		if(m_pGlyphData[i] == pGlyfIndex)		// same char
			return;
		else if(m_pGlyphData[i] > pGlyfIndex)	// index over
			break;
	}
	if( m_nTextArrayCapacity == m_nTextArraySize)
	{
		m_nTextArrayCapacity += DEFAULT_TEXT_ARRAY_SIZE;
		BrULONG* pCopyData = (BrULONG*)BrMalloc(BrSizeOf(BrULONG)*(m_nTextArrayCapacity+1));
		if( !pCopyData )
		{
			SET_ERROR((PoError)kPoErrMemory, "");

			return;
		}

		BrINT* pCopyCovertData = (BrINT*)BrMalloc(BrSizeOf(BrINT)*(m_nTextArrayCapacity+1));
		if( !pCopyCovertData )
		{
			SET_ERROR((PoError)kPoErrMemory, "");

			//[16.12.13] Coverity-22958
			BR_SAFE_FREE(pCopyData);

			return;
		}

		memset(pCopyData, 0, BrSizeOf(BrULONG)*m_nTextArrayCapacity);
		memcpy(pCopyData, m_pTextData, BrSizeOf(BrULONG)*m_nTextArraySize);
		BrFree(m_pTextData);
		m_pTextData = pCopyData;

		memset(pCopyCovertData, -1, BrSizeOf(BrINT)*m_nTextArrayCapacity);
		memcpy(pCopyCovertData, m_pGlyphData, BrSizeOf(BrINT)*m_nTextArraySize);
		BrFree(m_pGlyphData);
		m_pGlyphData = pCopyCovertData;
	}	
	for(int k = m_nTextArraySize; k > i; k--)
	{
		m_pTextData[k] = m_pTextData[k-1];
		m_pGlyphData[k] = m_pGlyphData[k-1];
	}
	m_pTextData[i] = *pTextData;
	m_pGlyphData[i] = pGlyfIndex;
	m_nTextArraySize++;
	m_nFirstGlyf = (m_pTextData[0] != 0 && m_nTextArraySize >=2)? m_pGlyphData[1]:m_pGlyphData[0];
	m_nLastGlyf = m_pGlyphData[m_nTextArraySize-1];
	addUseCidIndex(usedCidIndex);
}

void PDFExportTextData::addUseCidIndex(BrINT usedCidIndex)
{
	if(usedCidIndex < 0)
		return;

	int i = 0;
	for(i = 0; i < m_nUsedCidIndicesSize; i++)
	{
		if(m_nUsedCidIndices[i] == usedCidIndex)		// same char
			return;
		else if(m_nUsedCidIndices[i] > usedCidIndex)	// index over
			break;
	}

	if( m_nCidIndicesCapacity == m_nUsedCidIndicesSize)
	{
		m_nCidIndicesCapacity += DEFAULT_TEXT_ARRAY_SIZE;
		BrINT* pCopyData = (BrINT*)BrMalloc(BrSizeOf(BrINT)*(m_nCidIndicesCapacity+1));
		if( !pCopyData )
		{
			SET_ERROR((PoError)kPoErrMemory, "");

			return;
		}

		memset(pCopyData, 0, BrSizeOf(BrINT)*m_nCidIndicesCapacity);
		memcpy(pCopyData, m_nUsedCidIndices, BrSizeOf(BrINT)*m_nUsedCidIndicesSize);
		BrFree(m_nUsedCidIndices);
		m_nUsedCidIndices = pCopyData;
	}

	for(int k = m_nUsedCidIndicesSize; k > i; k--)
	{
		m_nUsedCidIndices[k] = m_nUsedCidIndices[k-1];
	}

	m_nUsedCidIndices[i] = usedCidIndex;
	m_nUsedCidIndicesSize++;
}
void PDFExportTextData::setFontFilePath(BrCHAR* pPath)
{
	memcpy(m_pFontFilePath, pPath, MAX_XPDF_FONT_LEN);
}

void PDFExportTextData::setFontMemoryAddr( void* pFontData, BrLONG nSize )
{
	m_pFontDataAddr = pFontData;
	m_nFontDataSize = nSize;
}

bool g_bShowMsgData = false;
BrBOOL PDFExportTextData::createFontData()
{
	if ( !g_bShowMsgData ) BTrace("%s(%d) %s m_eExportTextType[%d], m_pFontFaceName[%s] m_pFontFilePath[%s] m_pFontDataAddr[%p] m_nFontDataSize[%d]", __FILE__, __LINE__, __FUNCTION__, m_eExportTextType, m_pFontFaceName, m_pFontFilePath, m_pFontDataAddr, m_nFontDataSize);
	if (m_pFontBuf)
	{
		BR_SAFE_FREE(m_pFontBuf);
		m_nFontFileSize = 0;
	}
	BrBOOL bRet = BrFALSE;
	m_pFont->setExportTextType( m_eExportTextType );
	m_pFont->setExportTextFontFaceName(m_pFontFaceName);
	if( strcmp(m_pFontFilePath, "") )
	{
		bRet = m_pFont->parse(m_pFontFilePath, &m_nFontFileSize);
		if( !bRet || !m_nFontFileSize )
		{
			if ( !g_bShowMsgData ) {
				g_bShowMsgData=true;
				BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
			}
			return BrFALSE;
		}

		m_pFontBuf = (BrBYTE *)BrMalloc(m_nFontFileSize);
		if(m_pFontBuf == BrNULL)
		{
			SET_ERROR((PoError)kPoErrMemory, "");
if ( !g_bShowMsgData ) {
	g_bShowMsgData=true;
	BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
}
			return BrFALSE;
		}
		memset(m_pFontBuf, 0, m_nFontFileSize);
	}
	else if( m_pFontDataAddr )
	{
		bRet = m_pFont->parseMem(m_pFontDataAddr, m_nFontDataSize);
		if( !bRet )
		{
			if ( !g_bShowMsgData ) {
				g_bShowMsgData=true;
				BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
			}
			return BrFALSE;
		}

		m_nFontFileSize = m_nFontDataSize;
		m_pFontBuf = (BrBYTE *)BrMalloc(m_nFontDataSize);
		if(m_pFontBuf == BrNULL)
		{
			SET_ERROR((PoError)kPoErrMemory, "");
if ( !g_bShowMsgData ) {
	g_bShowMsgData=true;
	BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
}
			return BrFALSE;
		}
		memset(m_pFontBuf, 0, m_nFontDataSize);
	}

	m_pFont->generateEmbedFontInfo(m_pFontBuf);

	m_bUseCFF = m_pFont->hasCFF();
	m_pCFF = m_pFont->getCFFData();
if ( !g_bShowMsgData ) {
	g_bShowMsgData=true;
	BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);
}
	return bRet;
}

BrBOOL PDFExportTextData::ResetEncodeBuffer(BrINT nSize)
{
	nSize = BrMAX(nSize + BrUINT(nSize*0.001)+12, ENCODE_BUFFER_LENGTH);

	if (m_pEncodeBuffer == NULL)
	{
		m_pEncodeBuffer = gmalloc(nSize);
		m_nEncodeBufferLen = nSize;
		if (m_pEncodeBuffer == NULL)
		{
			m_nEncodeBufferLen = 0;	
			return BrFALSE;
		}
	}
	else
	{
		if((int)nSize > m_nEncodeBufferLen)
		{
			m_pEncodeBuffer = grealloc(m_pEncodeBuffer, nSize);
			if(!m_pEncodeBuffer)
			{
				m_nEncodeBufferLen = 0;
				return BrFALSE;
			}
			m_nEncodeBufferLen = nSize;
		}
	}

	memset(m_pEncodeBuffer, 0, m_nEncodeBufferLen);
	BrINT nCIDSetSize = m_pFont->getGlyfCount();

	if(m_bUseCFF)
	{
		BrINT cidMax = BrMAX(m_pCFF->m_nCIDMax, m_pCFF->m_arrCIDs.size() - 1);
		nCIDSetSize = cidMax / 8 + 1;//m_pCFF->m_arrCIDs.at(m_pCFF->m_arrCIDs.size() -1);
	}
	else
	{
		if((nCIDSetSize & 0x7) != 0)
		{
			nCIDSetSize = (nCIDSetSize >> 3) +1;
		}
		else
		{
			nCIDSetSize = nCIDSetSize >> 3;
		}
	}
	if (m_pEncodeCIDSetBuffer == NULL)
	{
		m_pEncodeCIDSetBuffer = gmalloc(nCIDSetSize);
		m_nEncodeCIDSetBufferLen = nCIDSetSize;
		m_pCIDSetBuf = (BrBYTE *)BrMalloc(nCIDSetSize);
		m_nCIDSetSize = nCIDSetSize;
		if (m_pEncodeCIDSetBuffer == NULL || m_pCIDSetBuf == NULL)
		{
			m_nEncodeCIDSetBufferLen = 0;
			m_nCIDSetSize = 0;
			return BrFALSE;
		}
	}
	else
	{
		if((int)nCIDSetSize > m_nEncodeCIDSetBufferLen)
		{
			m_pEncodeCIDSetBuffer = grealloc(m_pEncodeCIDSetBuffer, nCIDSetSize);
			m_pCIDSetBuf = (BrBYTE *)BrRealloc(m_pCIDSetBuf,nCIDSetSize);
			if(!m_pEncodeCIDSetBuffer || !m_pCIDSetBuf)
			{
				m_nEncodeCIDSetBufferLen = 0;
				m_nCIDSetSize = 0;
				return BrFALSE;
			}
			m_nEncodeCIDSetBufferLen = nCIDSetSize;
			m_nCIDSetSize = nCIDSetSize;
		}
	}
	memset(m_pEncodeCIDSetBuffer, 0, m_nEncodeCIDSetBufferLen);
	memset(m_pCIDSetBuf, 0, m_nCIDSetSize);
	return BrTRUE;
}

BrBOOL PDFExportTextData::makeExportData()
{
	BrBOOL bRet = BrFALSE;
	clearBaseFontInfo();
	m_pFont->setExportTextType( m_eExportTextType );
	m_pFont->setNumberOfGlyphs(m_nTextArraySize+1);
	m_pFont->setUnicodeData(m_pTextData, m_pGlyphData,m_nTextArraySize);
	createFontData();
	BrUINT16* pWidths = m_pFont->getGlyfWidths();
	//[14.07.03][sglee1206] width �� �� ����
	if(m_oDescendentFont.isDict() && ( pWidths != BrNULL))
	{
		m_oDescendentFont.getDict()->remove("W");
		m_oDescendentFont.getDict()->remove("DW");

		{
			Object oWidths, oWElem, oCElem;
			oWidths.initArray(NULL);
			
			// m_pGlyphData Array �� m_nTextArraySize ���� �۾ƾ� �Ѵ�.
			//[18.03.09][sglee1206][WPD-1104]Glyph Index Oth .notdef �� �����ϹǷ� ���� ����
			//[18.06.01][sglee1206][LQQ-7632]CFF Font ���� �� Width Table ó�� ����
			if(m_bUseCFF && m_pCFF && m_pCFF->m_arrCIDs)
			{
				for(int i = 0; m_nUsedCidIndices[i] >= 0 ; i++)
				{

					if(i >= m_nTextArraySize )
						break;

					oWElem.initArray(NULL);
					oCElem.initInt(m_nUsedCidIndices[i]);

					Object one;

					do
					{
						one.initInt(pWidths[m_nUsedCidIndices[i++]]);
						oWElem.getArray()->add(&one);
					}while(i < m_nTextArraySize && m_nUsedCidIndices[i] - m_nUsedCidIndices[i-1] == 1);

					i--;

					oWidths.getArray()->add(&oCElem);
					oWidths.getArray()->add(&oWElem);
				}
			}
			else
			{
				for(int i = 0; m_pGlyphData[i] >= 0 ; i++)
				{
				
					if(i >= m_nTextArraySize )
						break;

					oWElem.initArray(NULL);
					oCElem.initInt(m_pGlyphData[i]);

					Object one;

					do
					{
						one.initInt(pWidths[m_pGlyphData[i++]]);
						oWElem.getArray()->add(&one);
					}while(i < m_nTextArraySize && m_pGlyphData[i] - m_pGlyphData[i-1] == 1);
				
					i--;

					oWidths.getArray()->add(&oCElem);
					oWidths.getArray()->add(&oWElem);
				}
			}
		
			m_oDescendentFont.getDict()->add(XGetKey("W"), &oWidths);
		}
	}
	return BrTRUE;
}
BrWORD PDFExportTextData::getCodeFromCodeMap(BrULONG charCode)
{
	if(m_pFont != BrNULL && ePDF_TEXT_TYPE_NORMAL < m_eExportTextType && m_eExportTextType < ePDF_TEXT_TYPE_MAX)
	{
		BrWORD nRet = m_pFont->getCodeFromCodeMap(charCode);

		if(m_bUseCFF && m_pCFF && m_pCFF->m_arrCIDs)
		{
			if(m_pCFF->m_arrCIDs.GetSize() > nRet)
			{
				nRet = m_pCFF->m_arrCIDs.at(nRet);
			}
		}

		return nRet;
	}
	else
		return 0;
}
BrBOOL PDFExportTextData::getFontInfo(BrXPDFFontInfo* pFontInfo)
{
	return m_pFont->getFontInfo(pFontInfo);
}

void PDFExportTextData::setFontFaceName(const char* pFontFaceName, BrINT nFontFaceIndex, BrINT nSystemFontIndex)
{
	if(pFontFaceName)
	{
		if(m_pFontFaceName != BrNULL)
		{
			BrFree(m_pFontFaceName);
			m_pFontFaceName = BrNULL;
		}

		BrINT nFontName = BrStrLen(pFontFaceName)+8;	//Subset(6) + '+' + Font Name + \0
		m_pFontFaceName = (BrCHAR *)BrCalloc(nFontName, BrSizeOf(BrCHAR));
		if(m_pFontFaceName != BrNULL)
		{
			// [16.08.08][sglee1206] PDF Export �� ����� Font(nanumgothic ��)�� System Font Name�� ���� ��� PDF Embedded Font �߸� ó���Ǵ� ���� ����[XPD-6956]
			// [18.09.13][sglee1206] ���꼼Ʈ ó�� �߰�
			if(nSystemFontIndex < 0)
			{
				if(nFontFaceIndex < eEF_MaxFontType)
					strncpy_s(m_pFontFaceName, nFontName, "EMBDEF+", strlen("EMBDEF+"));	//EF Font
				else
					strncpy_s(m_pFontFaceName, nFontName, "EMDEMF+", strlen("EMDEMF+"));	//EMF Font
			}
			else
				strncpy_s(m_pFontFaceName, nFontName, "ABCDEE+", strlen("ABCDEE+"));		//Other Font

			strncat_s(m_pFontFaceName, nFontName, pFontFaceName, strlen(pFontFaceName));
		}
	}
	m_nFontFaceIndex = nFontFaceIndex;
}

void PDFExportTextData::setDescendentFont(Object* pDescendentFont)
{
	if(pDescendentFont != NULL)
	{
		if(!m_oDescendentFont.isNull())
			m_oDescendentFont.free();
		pDescendentFont->copy(&m_oDescendentFont);
	}
}

void PDFExportTextData::setExportTextType( EBrXFontType eType )
{
	m_eExportTextType = eType;
}

void PDFExportTextData::clearBaseFontInfo()
{
	// Crear �� �� Create �� ���� �ϴ°�� m_pCFF �� NULL �� �ƴϸ� Crash �߻�
	if (m_pCFF == m_pFont->getCFFData())
	{
		m_pCFF = BrNULL;
		m_bUseCFF = BrFALSE;
	}

	m_pFont->clear();
}

void PDFExportTextData::optimizeCFF()
{
	if(m_pCFF)
	{
		m_pCFF->Optimize(m_nUsedCidIndices,m_nUsedCidIndicesSize);

		if(m_pFontBuf != BrNULL)
			BR_SAFE_FREE(m_pFontBuf);
		m_pFontBuf = (BrBYTE *)BrMalloc(m_pCFF->write_length);
		if(m_pFontBuf == BrNULL)
		{
			SET_ERROR((PoError)kPoErrMemory, "");

			return;
		}
		memset(m_pFontBuf, 0, m_pCFF->write_length);
		memcpy(m_pFontBuf, m_pCFF->write_data,m_pCFF->write_length);
		m_nFontDataSize = m_pCFF->write_length;
	}
}
#endif//#ifdef EXPORT_PDF