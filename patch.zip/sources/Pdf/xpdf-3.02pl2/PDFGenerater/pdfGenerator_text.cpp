#include <OfficePreCompPDF.hpp>

#ifdef EXPORT_PDF

#include "goo/GString.h"
#include "xpdf/config.h"
#include "xpdf/Page.h"
#include "xpdf/GlobalParams.h"
#include "xpdf/Catalog.h"
//#include "xpdf/Stream.h"
#include "xpdf/XRef.h"
//#include "xpdf/OutputDev.h"
#include "xpdf/Error.h"
#include "xpdf/ErrorCodes.h"
#include "xpdf/PDFDoc.h"

#include "pdfGenerator.h"
#include "encoders/pdfEncoder.h"
#include "encoders/pdfFlateEncoder.h"

#include "XStream.h"
#include "xpdf/GfxFont.h"

#include "pdfExportTextData.h"

#include "font/cff.h"

#define MAX_DEFAULT_STANDARD_FONTS	13

bool IsDefaultStandardFont(char* fontname, char* encoding)
{
	//[16.08.16][sglee1206] Courier.ttc�� ��� ����ó���Ͽ����ϴ� �� Standard Font�� �ν��Ͽ� ������� �ʾƼ� ���� �߻�
	//���� encoding �� �� ó��
	if (strcmp(encoding, "Identity-H") == 0)
	{
		return false;
	}

	const char defaultStandardFonts[MAX_DEFAULT_STANDARD_FONTS][32] = {
		"Times-Roman",
		"Times-Bold",
		"Times-Italic",
		"Times-BoldItalic",
		"Helvetica",
		"Helvetica-Bold",
		"Helvetica-Oblique",
		"Helvetica-BoldOblique",
		"Courier",
		"Courier-Bold",
		"Courier-Oblique",
		"Courier-BoldOblique",
//		"Symbol",
		"ZapfDingbats"
	};

	bool bIs = false;
	for(int i = 0; i < MAX_DEFAULT_STANDARD_FONTS; i++) {
		if (strcmp(fontname, defaultStandardFonts[i])  == 0) {
			bIs = true;
			break;
		}
	}

	return bIs;
}


BrINT PDFGenerator::AddText(LPBrUseFontInfo pFontInfo, BrBYTE nTextType, void* pText,  BrINT nTextLen, LPBrFPOINT pPos, XRect* a_pClipRect, LPBrFPOINT pShadowPos, BrBYTE m_nFDFlag, LPBrCharGap pCharInterval) 
{
	if (m_nCurPage >= m_nPageCount)
		return errBadPageNum;

	if (m_nCurFontRef <= 0)
		return errDamaged;

	if (pFontInfo == NULL || pFontInfo->nFontSize <= 0)
		return errInvalidParameter;

	if (pText == NULL || nTextLen < 0)
		return errInvalidParameter;

	Object* pPage = (Object*)m_ppObjects[m_pPageNumbers[m_nCurPage]];
	if (pPage == NULL)
		return errBadCatalog;

	Object oContentsRef;
	TextXStream* pContents = NULL;

	pPage->getDict()->lookupNF("Contents", &oContentsRef);
	if (oContentsRef.isNull())
	{
		pContents = (TextXStream*)GenerateContents(TEXT_TYPE);
		if(pContents == BrNULL)
			return errMemoryNotEnough; // �޸� ���� ���� ��쵵 ���� �� �ֳ�? ���� �� ������			

		oContentsRef.initRef(m_nEntryIndex, 0);
		pPage->getDict()->add(XGetKey("Contents"), &oContentsRef);
		//m_pbXStream[m_nEntryIndex] = true;
	}
	else
	{
		pContents = (TextXStream*) m_ppObjects[oContentsRef.getRef().num];
		oContentsRef.free();
	}

	if( pFontInfo->nShadowColor != -1  && pShadowPos)
	{
		BrUseFontInfo pShadowFontInfo = {0};
		memcpy( &pShadowFontInfo, pFontInfo, BrSizeOf(BrUseFontInfo) );
		pShadowFontInfo.nColor = pShadowFontInfo.nShadowColor;
//[2012.09.17][ekaloss] Text ũ�⿡ ���� shadowOffset ũ�Ⱑ ������� �ʴ� ����.
		if (0 != AddContents(pContents, &pShadowFontInfo, nTextType, pText, nTextLen, pShadowPos->x, pShadowPos->y, a_pClipRect, m_nFDFlag, pCharInterval))
			return errMemoryNotEnough;
	}
	if (0 != AddContents(pContents, pFontInfo, nTextType, pText, nTextLen, pPos->x, pPos->y, a_pClipRect, m_nFDFlag, pCharInterval))
		return errMemoryNotEnough;

	return errNone;
}


void PDFGenerator::SetEncoding(BrCHAR* pEncoding, BrINT nAttFlg)
{
	if(BR_ISSET_STATE(nAttFlg, eXPDFRegCodeFATTType))
		m_bIsUnicode = true;	
	else if(pEncoding)
	{
		BString strEng((const char *)pEncoding);
		if (strEng.upper().contains("UCS") || strEng.upper().contains("UTF") || m_eWritingMode == eXPDF_WRITING_RIGHT_TO_LEFT)
			m_bIsUnicode = true;
		else
			m_bIsUnicode = false;
	}
	else
		m_bIsUnicode = false;		
}

BrINT PDFGenerator::SetFont(LPBrXPDFFontInfo pFontInfo)
{
	int result = errNone;

	// 1. Check condition
	// 1.1 validate font
	if (pFontInfo == NULL || strlen(pFontInfo->szFaceName) == 0 || strlen(pFontInfo->szEncoding) == 0)
		return errInvalidParameter;

	// 1.2 �̹� ��ϵ� ���� ��ü�� �ִ°��� ����.
	//if (m_eWritingMode != eXPDF_WRITING_RIGHT_TO_LEFT && CheckDuplicateFont(pFontInfo->szFaceName, pFontInfo->szEncoding))
	//if (CheckDuplicateFont(pFontInfo->szFaceName, pFontInfo->szEncoding))
	if (CheckDuplicateFont(pFontInfo))
	{
		//return errInvalidParameter;
		SetEncoding(pFontInfo->szEncoding, pFontInfo->sCodeTable.nAttFlag);
		return errNone;
	}

	// 2. Add font to Resource
	// 2.1 Create font object
	Object* pFontObj = BrNULL;
	if (IsDefaultStandardFont(pFontInfo->szFaceName, pFontInfo->szEncoding) == true)
		pFontObj = GenerateDefalutFont(pFontInfo->szFaceName);
	else
		pFontObj = GenerateNormalFont(pFontInfo);

	if (pFontObj == BrNULL)
		return errNotComplete;

	m_fontArray.Add(m_nEntryIndex);

	// 2.2 Add font object to resource
	result = AddFontToPage(m_nEntryIndex);
	if (result != errNone)
		return result;

	// 3 Check if the encoding of the current font is according to unicode.
	SetEncoding(pFontInfo->szEncoding, pFontInfo->sCodeTable.nAttFlag);
	
	// 3 Save the ref number of currently selected font.
	m_nCurFontRef = m_nEntryIndex;

	return result;
}

int	PDFGenerator::AddFontToPage(int fontRef)
{
	Object* pPage = (Object*)m_ppObjects[m_pPageNumbers[m_nCurPage]];
	if (pPage == NULL)
		return errBadCatalog;

	// 1. Check the Resource in Page.
	Object oResoucesDict;

	pPage->getDict()->lookupNF("Resources", &oResoucesDict);
	if (oResoucesDict.isNull())
	{
		oResoucesDict.initDict((XRef*)NULL);
		pPage->getDict()->add(XGetKey("Resources"), &oResoucesDict);
		oResoucesDict.getDict()->incRef();
	}

	// 2. Check the Font in Resource
	Object oFontDict;
	oResoucesDict.getDict()->lookupNF("Font", &oFontDict);
	if (oFontDict.isNull())
	{
		oFontDict.initDict((XRef*)NULL);
		oResoucesDict.getDict()->add(XGetKey("Font"), &oFontDict);
		oFontDict.getDict()->incRef();
	}

	// 3. Add the font.
	Object oFontObjRef;
	oFontObjRef.initRef(fontRef, 0);

	char* pszFontObjName = FontObjectName(m_nFontObjectCount);

	oFontDict.getDict()->add(pszFontObjName, &oFontObjRef);
	oFontDict.free();
	oResoucesDict.free();

	return errNone;
}

bool PDFGenerator::CheckDuplicateFont(LPBrXPDFFontInfo pFontInfo)//char* fontname, char* encode)
{
	char* encode = pFontInfo->szEncoding;		
	bool bIsExist = false;
	if (m_fontArray.count() == 0 || pFontInfo == NULL || strlen(pFontInfo->szFaceName) == 0)
		return bIsExist;

	char* fontname = pFontInfo->szFaceName;

	BrBOOL bRegFont = BR_ISSET_STATE(pFontInfo->sCodeTable.nAttFlag, eXPDFRegCodeFATTType);
	int index;
	Object* pFontObj = BrNULL;
	for (int i = 0; i < (int)m_fontArray.count(); i++)
	{
		// 1. Get the font name int the saved pdf.
		Object obj;
		index = m_fontArray[i];
		pFontObj = (Object*)m_ppObjects[index];
		pFontObj->getDict()->lookup("BaseFont", &obj);

		// 2. Check the duplicate default font.
		if (!bRegFont && strcmp(obj.getName(), fontname) == 0 && IsDefaultStandardFont(fontname, pFontInfo->szEncoding) == true)
		{
			obj.free();
			bIsExist = true;
			break;
		}
		

		if (encode == NULL)
		{
			obj.free();
			continue;
		}

		// 2. Check the duplicate system font.
		// 2.1 Get the encoding info.
		Object obj2;
		pFontObj->getDict()->lookup("Encoding", &obj2);
		// 2.2 Check the duplication.
		if (strcmp(obj.getName(), fontname) == 0)
		{
			if(strcmp(obj2.getName(), encode) == 0)
			{
				if(!bRegFont)
				{
					bIsExist = true;
					obj.free();
					obj2.free();
					break;
				}				
			}
			else if(bRegFont)
			{
				Object oBaseEncoding;
				obj2.getDict()->lookup("BaseEncoding", &oBaseEncoding);
				if(!oBaseEncoding.isNone() && strcmp(oBaseEncoding.getName(), encode) == 0)
				{
#if 0
					Object oLastChar;
					BrXPDFCodeInfo* pCodes = (BrXPDFCodeInfo*)pFontInfo->sCodeTable.pData;
					pFontObj->getDict()->lookup("LastChar", &oLastChar);
					if(!oLastChar.isNone() && oLastChar.getInt() == pFontInfo->sCodeTable.nLastCode)
					{
						Object oDiff;					
						obj2.getDict()->lookup("Differences", &oDiff);
						if(!oDiff.isNone())
						{
							int i = 0;
							Array * pDiff = oDiff.getArray();
							for(i = 0; i < pFontInfo->sCodeTable.nLen; i++)
							{
								Object one;
								pDiff->get(i+1, &one);
								if(one.isNull())
								{
									if(pCodes[i].pCodeName)
									{
										one.free();
										break;
									}
								}
								else if(!pCodes[i].pCodeName || strcmp(one.getName(), pCodes[i].pCodeName) != 0)
								{
									one.free();
									break;
								}
								one.free();
							}
							if(i >= pFontInfo->sCodeTable.nLen)
								bIsExist = true;
						}
						oDiff.free();
						oLastChar.free();
					}
#else //
					BrXPDFCodeInfo* pCodes = (BrXPDFCodeInfo*)pFontInfo->sCodeTable.pData;						
					Object oDiff;					
					obj2.getDict()->lookup("Differences", &oDiff);
					if(!oDiff.isNone())
					{
						int i = 0;
						Array * pDiff = oDiff.getArray();
						if(pDiff->getLength() == pFontInfo->sCodeTable.nLen+1)
						{
							for(i = 0; i < pFontInfo->sCodeTable.nLen; i++)
							{
								Object one;
								pDiff->get(i+1, &one);
								if(one.isNull())
								{
									if(pCodes[i].pCodeName)
									{
										one.free();
										break;
									}
								}
								else if(!pCodes[i].pCodeName || strcmp(one.getName(), pCodes[i].pCodeName) != 0)
								{
									one.free();
									break;
								}
								one.free();
							}
							if(i >= pFontInfo->sCodeTable.nLen)
								bIsExist = false;
						}						
					}
					oDiff.free();
						
					
#endif //
					obj2.free();
				}
				oBaseEncoding.free();
			}
		}		
		
		obj.free();
		obj2.free();
		
	}

	// 3 Save the ref number of currently selected font.
	if (bIsExist == true)
	{
		// �߰��Ϸ��� ��ü�� ��ü��Ͽ� �����Ѵٸ� ���� ������ �ڿ��� ref���� �����ϴ°��� �˻�.
		// �̰��� ������ 2���̻��� �� ����Ǵ� �����̴�.
		if (m_nFontObjectCount == 0 || IsExistFontInPage(index) == false)
		{
			m_nFontObjectCount++;
			AddFontToPage(index);
		}

		m_nCurFontRef = index;
	}

	return bIsExist;
}

bool PDFGenerator::IsExistFontInPage(int fontRef)
{
	bool bIsExist = false;
	Object oResoucesDict, oFontDict;

	// 1. Check if resource exist.
	Object* pPage = (Object*)m_ppObjects[m_pPageNumbers[m_nCurPage]];
	pPage->getDict()->lookupNF("Resources", &oResoucesDict);
	if (oResoucesDict.isNull())
		return bIsExist;
	
	// 2. Check if font-item exist.
	oResoucesDict.getDict()->lookupNF("Font", &oFontDict);
	if (oFontDict.isNull())
		return bIsExist;

	// 3. Check if the relevant ref-index exist.
	Dict* dict = oFontDict.getDict();
	Object obj;
	for (int i = 0; i < dict->getLength(); i++) {
		dict->getVal(i, &obj);
		if (obj.getRefNum() == fontRef) {
			bIsExist = true;
			obj.free();
			break;
		}
		obj.free();
	}
	oFontDict.free();
	oResoucesDict.free();

	return bIsExist;
}

Object*		PDFGenerator::GenerateDefalutFont(char* fontname)
{
	Object* pFont = BrNEW Object();
	if (pFont == NULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");
		return NULL;
	}

	pFont->initDict((XRef*)NULL);

	// Type 
	Object oType;
	oType.initName("Font");
	pFont->getDict()->add(XGetKey("Type"), &oType);

	// Subtype
	Object oSubType;
	oSubType.initName("Type1");
	pFont->getDict()->add(XGetKey("Subtype"), &oSubType);

	// BaseFont
	Object oBaseFont;
	oBaseFont.initName(fontname);
	pFont->getDict()->add(XGetKey("BaseFont"), &oBaseFont);

	// Encoding
	Object oEncoding;
	oEncoding.initName("WinAnsiEncoding");
	pFont->getDict()->add(XGetKey("Encoding"), &oEncoding);

	if(AddXRefEntry(pFont) != errNone)
	{
		BrDELETE pFont;
		return BrNULL;
	}
	m_nFontObjectCount++;

	return pFont;
}

Object*		PDFGenerator::GenerateNormalFont(LPBrXPDFFontInfo pFontInfo)
{
	Object* pObj = BrNULL;

	if (pFontInfo->nType == eXPDFCIDFontType0 || pFontInfo->nType == eXPDFCIDFontType2)
		pObj = GenerateCIDFont(pFontInfo);
	else
		pObj = GenerateSimpleFont(pFontInfo);

	return pObj;
}

Object*	PDFGenerator::GenerateSimpleFont(LPBrXPDFFontInfo pFontInfo)
{
	BrBOOL bRegFont = BrFALSE;
	Object* pFont = BrNEW Object();
	if (pFont == NULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");
		return NULL;
	}

	bRegFont = BR_ISSET_STATE(pFontInfo->sCodeTable.nAttFlag, eXPDFRegCodeFATTType);
	pFont->initDict((XRef*)NULL);

	// Type 
	Object oType;
	oType.initName("Font");
	pFont->getDict()->add(XGetKey("Type"), &oType);

	// BaseFont
	Object oBaseFont;
	oBaseFont.initName(pFontInfo->szFaceName, true);
	pFont->getDict()->add(XGetKey("BaseFont"), &oBaseFont);

	// Encoding
	Object oEncoding;
	if(bRegFont)
	{
		oEncoding.initDict((XRef*)NULL);

		// BaseEncoding
		Object oBaseEncoding;
		oBaseEncoding.initName(pFontInfo->szEncoding, true);
		oEncoding.getDict()->add(XGetKey("BaseEncoding"), &oBaseEncoding);

		// Differences
		Object oDiff, oCode;
		oCode.initInt(1);
		oDiff.initArray((XRef*)NULL);
		oDiff.getArray()->add(&oCode);

		BrXPDFCodeInfo* pCodes = (BrXPDFCodeInfo*)pFontInfo->sCodeTable.pData;
		for(int i = 0; i < pFontInfo->sCodeTable.nLen; i++)
		{
			Object one;
			if(pCodes[i].pCodeName)
				one.initName(pCodes[i].pCodeName, true);
			else
				one.initName("");
			oDiff.getArray()->add(&one);			
		}	

		oEncoding.getDict()->add(XGetKey("Differences"), &oDiff);
	}
	else
	{
		oEncoding.initName(pFontInfo->szEncoding, true);
	}	
	pFont->getDict()->add(XGetKey("Encoding"), &oEncoding);

	// Subtype
	Object oSubType;
	switch(pFontInfo->nType)
	{
	case eXPDFFontType1:
		oSubType.initName("Type1");
		break;
	case eXPDFFontMMType1:
		oSubType.initName("MMType1");
		break;
	case eXPDFFontType3:
		oSubType.initName("Type3");
		break;
	case eXPDFFontTrueType:
		oSubType.initName("TrueType");
		break;
	default:
		oSubType.initName("TrueType");
		break;
	}
	pFont->getDict()->add(XGetKey("Subtype"), &oSubType);

	// FirstChar
	Object oFristChar;
	int nCode = pFontInfo->sCodeTable.nFirstCode;
	oFristChar.initInt(nCode);
	pFont->getDict()->add(XGetKey("FirstChar"), &oFristChar);

	// LastChar
	Object oLastChar;
	nCode = pFontInfo->sCodeTable.nLastCode;
	oLastChar.initInt(nCode);
	pFont->getDict()->add(XGetKey("LastChar"), &oLastChar);

	// Width
	Object oWidths;
	oWidths.initArray(NULL);
	if(bRegFont)
	{
		BrXPDFCodeInfo* pCodes = (BrXPDFCodeInfo*)pFontInfo->sCodeTable.pData;
		for(int i = 0; i < pFontInfo->sCodeTable.nLen; i++)
		{
			Object one;
			one.initInt(pCodes[i].nWidth);
			oWidths.getArray()->add(&one);
		}
	}
	else
	{
		BrUINT16* pWidths = (BrUINT16*)pFontInfo->sCodeTable.pData;
		for(int i = 0; i < pFontInfo->sCodeTable.nLen; i++)
		{
			Object one;
			one.initInt(pWidths[i]);
			oWidths.getArray()->add(&one);
		}
	}
	
	pFont->getDict()->add(XGetKey("Widths"), &oWidths);

	// Font Descriptor Reference
	Object* pFontDescriptor = GenerateFontDescriptor(pFontInfo);

	Object oFontDescriptorRef;
	oFontDescriptorRef.initRef(m_nEntryIndex,0);
	pFont->getDict()->add(XGetKey("FontDescriptor"), &oFontDescriptorRef);

	// ToUnicode
	if (bRegFont)
	{
		BrXPDFCodeInfo* pCodes = (BrXPDFCodeInfo*)pFontInfo->sCodeTable.pData;
		int nLen = pFontInfo->sCodeTable.nLen;
		if(GenearateToUnicodeInfo(pCodes, nLen) != errNone)
		{
			BrDELETE pFont;
			return BrNULL;
		}
		Object oToUnicode;
		oToUnicode.initRef(m_nEntryIndex, 0);
		pFont->getDict()->add(XGetKey("ToUnicode"), &oToUnicode);
	}

	if(AddXRefEntry(pFont) != errNone)
	{
		BrDELETE pFont;
		return BrNULL;
	}
	m_nFontObjectCount++;

	return pFont;
}

int PDFGenerator::GenearateToUnicodeInfo(BrXPDFCodeInfo* pCodes, int nCodeTableLen)
{
	int errRet = errNone;
	XStream* pStream = NULL;
	EPDF_ENCODE_TYPE encodeType = ePDF_ENCODE_NONE;

	pStream = BrNEW XStream(ePDF_ENCODE_FLATE);
	if (pStream == NULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");
		return errMemoryNotEnough;
	}

	GString pBuf;

	errRet = AddXRefEntry(pStream, BrTRUE);
	if(errRet != errNone)
	{
		return errRet;
	}

	// 1.Append the unicode information stream.
	GString* strTemp = BrNULL;

	pBuf.append("/CIDInit/ProcSet findresource begin\n");
	pBuf.append("12 dict begin\n");
	pBuf.append("begincmap\n");
	pBuf.append("/CIDSystemInfo<</Registry(EE)/Ordering(UCS)/Supplement 0>>def\n");
	pBuf.append("/CMapName/EE def\n");
	pBuf.append("1 begincodespacerange\n");
	pBuf.append("<00><ff>\n");
	pBuf.append("endcodespacerange\n");
	strTemp = GString::format("{0:d} beginbfrange\n", nCodeTableLen);
	pBuf.append(strTemp);
	BrDELETE strTemp;
	for(int i = 0; i < nCodeTableLen; i++)
	{
		int index = i + 1;
		int nUnicode = pCodes[i].nCode;
		strTemp = GString::format("<{0:02x}> <{1:02x}> <{2:04x}>\n", index, index, nUnicode);
		pBuf.append(strTemp);
		BrDELETE strTemp;
	}
	pBuf.append("endbfrange\n");
	pBuf.append("endcmap\n");
	pBuf.append("CMapName currentdict/CMap defineresource pop\n");
	pBuf.append("end\n");
	pBuf.append("end\n");

	// 2. build the stream dictionary
	// 2.1 Compress stream
	PDFEncoder* pEncoder = GetEncoder(pStream->GetType());
	pEncoder->Reset();
	ResetEncodeBuffer(pBuf.getLength());

	unsigned int destLen = m_nEncodeBufferLen;

	if (0 != pEncoder->Encode(m_pEncodeBuffer, &destLen, pBuf.getCString(), pBuf.getLength()))
	{
		return errFailToEncodeBuffer;
	}

	pStream->SetStreamBuffer(m_pEncodeBuffer, destLen);

	// 2.2 Write Stream
	Ref xStreamRef; 
	Guint offset;

	xStreamRef.num = m_nEntryIndex; 
	xStreamRef.gen = 0;

	errRet = WriteStream(pStream, &xStreamRef, m_pOutStream, &offset);
	m_pbWrited[m_nEntryIndex] = true;
	m_pEntries[m_nEntryIndex].offset = offset;

	BR_SAFE_DELETE(pStream);

	return errRet;
}

int PDFGenerator::GenearateToUnicodeInfo(BrBOOL bWriteStream)
{
	int errRet = errNone;
	//Object *pUnicodeInfo = BrNEW Object;

	XStream* pStream = NULL;
	//EPDF_ENCODE_TYPE encodeType = ePDF_ENCODE_NONE;
	GString pBuf;

	if(!bWriteStream)
	{
		pStream = BrNEW XStream(ePDF_ENCODE_FLATE);
		if (pStream == NULL)
		{
			SET_ERROR((PoError)kPoErrMemory, "");
			return errMemoryNotEnough;
		}
		errRet = AddXRefEntry(pStream, BrTRUE);
		if(errRet != errNone)
			BrDELETE pStream;
	}	
	else
	{
		pStream = (XStream*)m_ppObjects[m_pExportData.at(m_nCurEmbeddedFont)->m_nFontUnicodeIndex];
		// 1.Append the unicode information stream.
		GString* strTemp = BrNULL;

		int nCodeTableLen = (m_pExportData.at(m_nCurEmbeddedFont)->getExportTextType() != ePDF_TEXT_TYPE_UCS4) ?
			m_pExportData.at(m_nCurEmbeddedFont)->getTextDataLength() : 0;

		pBuf.append("/CIDInit/ProcSet findresource begin\n");
		pBuf.append("12 dict begin\n");
		pBuf.append("begincmap\n");
		pBuf.append("/CIDSystemInfo << /Registry(Adobe) /Ordering(UCS) /Supplement 0>>def\n");
		pBuf.append("/CMapName /Adobe-Identity-UCS def\n");
		//pBuf->append("/CMapType 2 def\n");
		pBuf.append("1 begincodespacerange\n");
		pBuf.append("<0000><FFFF>\n");
		pBuf.append("endcodespacerange\n");
		if(nCodeTableLen > 0)
		{
			BrULONG*	pTextData = m_pExportData.at(m_nCurEmbeddedFont)->getTextData();
			BrINT*		pGlyfData = m_pExportData.at(m_nCurEmbeddedFont)->getTextGlyfData();
			strTemp = GString::format("{0:d} beginbfchar\n", nCodeTableLen);
			pBuf.append(strTemp);
			BrDELETE strTemp;
			for(int i = 0; i < nCodeTableLen; i++)
			{

				strTemp = GString::format("<{0:04x}> <{1:04x}>\n",pGlyfData[i] ,pTextData[i]);
				pBuf.append(strTemp);
				BrDELETE strTemp;
			}
			pBuf.append("endbfchar\n");
		}
		pBuf.append("endcmap\n");
		pBuf.append("CMapName currentdict/CMap defineresource pop\n");
		pBuf.append("end\n");
		pBuf.append("end\n");

		//// 2. build the stream dictionary
		//// 2.1 Compress stream
		PDFEncoder* pEncoder = GetEncoder(pStream->GetType());
		ResetEncodeBuffer(pBuf.getLength());

		unsigned int destLen = m_nEncodeBufferLen;

		if (0 != pEncoder->Encode(m_pEncodeBuffer, &destLen, pBuf.getCString(), pBuf.getLength()))
		{
			return errFailToEncodeBuffer;
		}

		pStream->SetStreamBuffer(m_pEncodeBuffer, destLen);

		// 2.2 Write Stream
		Ref xStreamRef; 
		Guint offset;

		xStreamRef.num = m_pExportData.at(m_nCurEmbeddedFont)->m_nFontUnicodeIndex;
		xStreamRef.gen = 0;

		errRet = WriteStream(pStream, &xStreamRef, m_pOutStream, &offset);
		m_pbWrited[m_pExportData.at(m_nCurEmbeddedFont)->m_nFontUnicodeIndex] = true;
		m_pEntries[m_pExportData.at(m_nCurEmbeddedFont)->m_nFontUnicodeIndex].offset = offset;

		BR_SAFE_DELETE(pStream);
	}
	
	return errRet;
}

Object*	PDFGenerator::GenerateCIDFont(LPBrXPDFFontInfo pFontInfo)
{
	Object* pFont = BrNEW Object();
	if (pFont == NULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");
		return NULL;
	}

	pFont->initDict((XRef*)NULL);

	// Type 
	Object oType;
	oType.initName("Font");
	pFont->getDict()->add(XGetKey("Type"), &oType);

	// BaseFont
	Object oBaseFont;
	oBaseFont.initName(pFontInfo->szFaceName, true);
	pFont->getDict()->add(XGetKey("BaseFont"), &oBaseFont);

	// Encoding
	Object oEncoding;
	oEncoding.initName(pFontInfo->szEncoding, true);
	pFont->getDict()->add(XGetKey("Encoding"), &oEncoding);

	// Subtype
	Object oSubType;
	oSubType.initName("Type0");
	pFont->getDict()->add(XGetKey("Subtype"), &oSubType);

	// DescendentFont Reference
	Object pFontDescriptor;
	Object* pDescendentFont = GenerateDescendentFont(pFontInfo,&pFontDescriptor);
	if(pDescendentFont == BrNULL)
	{
		BrDELETE pFont;
		return BrNULL;
	}

	Object oDescendentRefArray,oDescendentRef;
	oDescendentRef.initRef(m_nEntryIndex,0);
	oDescendentRefArray.initArray((XRef*)NULL);
	oDescendentRefArray.getArray()->add(&oDescendentRef);
	pFont->getDict()->add(XGetKey("DescendantFonts"), &oDescendentRefArray);
	{
		Object oFontFileRef;

		pFontDescriptor.getDict()->lookupNF("FontFile2", &oFontFileRef);
		if(oFontFileRef.isNull())
			pFontDescriptor.getDict()->lookupNF("FontFile3", &oFontFileRef);

		if(!oFontFileRef.isNull())
		{
			m_pExportData.at(m_nCurEmbeddedFont)->setDescendentFont(pDescendentFont);
			Object oToUnicodeRef;
			GenearateToUnicodeInfo();
			if(m_pExportData.at(m_nCurEmbeddedFont)->m_nFontUnicodeIndex == 0)
			{
				oToUnicodeRef.initRef(m_nEntryIndex, 0);
				m_pExportData.at(m_nCurEmbeddedFont)->m_nFontUnicodeIndex = m_nEntryIndex;
				pFont->getDict()->add(XGetKey("ToUnicode"), &oToUnicodeRef);	
			}
		}
		oFontFileRef.free();
	}

	if(AddXRefEntry(pFont) != errNone)
	{
		BrDELETE pFont;
		return BrNULL;
	}
	m_nFontObjectCount++;
	pFontDescriptor.free();

	return pFont;
}

Object*	PDFGenerator::GenerateDescendentFont(LPBrXPDFFontInfo pFontInfo, Object* fontDescriptor)
{
	Object *oDescendentFont = BrNEW Object;
	oDescendentFont->initDict((XRef*)NULL);

	// Width
	if (pFontInfo->sCodeTable.nLen != 0)
	{
		Object oWidths, oWElem, oCElem;
		oWidths.initArray(NULL);
		oWElem.initArray(NULL);

		if(pFontInfo->sCodeTable.nFirstCode)
		{
#if 1
			oCElem.initInt(1);
			if(BR_ISSET_STATE(pFontInfo->sCodeTable.nAttFlag, eXPDFRegCodeFATTType))
			{
				BrXPDFCodeInfo* pCodes = (BrXPDFCodeInfo*)pFontInfo->sCodeTable.pData;
				for(int i = 0; i < pFontInfo->sCodeTable.nLen; i++)
				{
					Object one;
					one.initInt(pCodes[i].nWidth);
					oWElem.getArray()->add(&one);
				}
			}
			else
			{
				BrUINT16* pWidths = (BrUINT16*)pFontInfo->sCodeTable.pData;
				for(int i = 0; i < pFontInfo->sCodeTable.nLen; i++)
				{
					Object one;
					one.initInt(pWidths[i]);
					oWElem.getArray()->add(&one);
				}
			}			
#else //
			oCElem.initInt(pFontInfo->sCodeTable.nFirstCode);

			for(int i = 0; i < pFontInfo->sCodeTable.nLen; i++)
			{
				Object one;
				one.initInt(pFontInfo->sCodeTable.pWidths[i]);
				oWElem.getArray()->add(&one);
			}
#endif //
			oWidths.getArray()->add(&oCElem);
			oWidths.getArray()->add(&oWElem);

		}
		else
		{
			oCElem.initInt(0);
			BrUINT16* pWidths = (BrUINT16*)pFontInfo->sCodeTable.pData;
			for(int i = 0; i < pFontInfo->sCodeTable.nLen; i++)
			{
				Object one;
				if( pWidths )
					one.initInt(pWidths[i]);
				else
					one.initInt(pFontInfo->sCodeTable.nDefWidth);
				oWElem.getArray()->add(&one);
			}
			oWidths.getArray()->add(&oCElem);
			oWidths.getArray()->add(&oWElem);
		}
		
		oDescendentFont->getDict()->add(XGetKey("W"), &oWidths);
	}
	else if(pFontInfo->sCodeTable.nDefWidth != -1)
	{
		Object oWidths, oFirst, oLast, oValue;
		if(pFontInfo->sCodeTable.nLastCode > 0 && pFontInfo->sCodeTable.nLastCode > pFontInfo->sCodeTable.nFirstCode)
		{
			oWidths.initArray(NULL);

		
			oFirst.initInt(pFontInfo->sCodeTable.nFirstCode);
			oWidths.getArray()->add(&oFirst);
		
			oLast.initInt(pFontInfo->sCodeTable.nLastCode);
			oWidths.getArray()->add(&oLast);
		
			oValue.initInt(pFontInfo->sCodeTable.nDefWidth);
			oWidths.getArray()->add(&oValue);
		
			oDescendentFont->getDict()->add(XGetKey("W"), &oWidths);
		}
		else
		{
			oValue.initInt(pFontInfo->sCodeTable.nDefWidth);
			oDescendentFont->getDict()->add(XGetKey("DW"), &oValue);
		}
	}
	else
	{
		Object oWidth;
		oWidth.initInt(1000);
		oDescendentFont->getDict()->add(XGetKey("DW"), &oWidth);
	}

	// Type
	Object oType;
	oType.initName("Font");
	oDescendentFont->getDict()->add(XGetKey("Type"), &oType);

	// Subtype
	Object oSubType;
	if(pFontInfo->nType == eXPDFCIDFontType2)
	{
		oSubType.initName("CIDFontType2");
	}
	else if(pFontInfo->nType == eXPDFCIDFontType0)
	{
		oSubType.initName("CIDFontType0");
	}
	else
	{
		oDescendentFont->free();
		BrDELETE oDescendentFont;
		return BrNULL;
	}

	oDescendentFont->getDict()->add(XGetKey("Subtype"), &oSubType);

	// BaseFont
	Object oBaseFont;
	oBaseFont.initName(pFontInfo->szFaceName, true);
	oDescendentFont->getDict()->add(XGetKey("BaseFont"), &oBaseFont);

	// Create CIDSystemInfo Object
	Object *pCIDSystemInfo = BrNEW Object;
	pCIDSystemInfo->initDict((XRef*)NULL);

	Object oRegistry;
	GString *str = BrNEW GString(pFontInfo->pCIDSystemInfo->szRegistry);
	oRegistry.initString(str);
	pCIDSystemInfo->getDict()->add(XGetKey("Registry"), &oRegistry);

	Object oOrdering;
	str = BrNEW GString(pFontInfo->pCIDSystemInfo->szOrdering);
	oOrdering.initString(str);
	pCIDSystemInfo->getDict()->add(XGetKey("Ordering"), &oOrdering);

	Object oSupplement;
	oSupplement.initInt(pFontInfo->pCIDSystemInfo->nSupplement);
	pCIDSystemInfo->getDict()->add(XGetKey("Supplement"), &oSupplement);

	if(AddXRefEntry(pCIDSystemInfo) != errNone)
	{
		BrDELETE oDescendentFont;
		return BrNULL;
	}

	// CIDSystemInfo Reference
	Object oCIDSystemInfo;
	oCIDSystemInfo.initRef(m_nEntryIndex,0);
	oDescendentFont->getDict()->add(XGetKey("CIDSystemInfo"), &oCIDSystemInfo);

	// CIDTOGIDMap Reference
	if(!pFontInfo->bCFF)
	{
		Object oCIDToGIDMap;
		oCIDToGIDMap.initName("Identity");
		oDescendentFont->getDict()->add(XGetKey("CIDToGIDMap"), &oCIDToGIDMap);
	}

	// Font Descriptor Reference
	Object* pFontDescriptor = GenerateFontDescriptor(pFontInfo);
	if(pFontDescriptor == BrNULL)
	{
		BrDELETE oDescendentFont;
		return BrNULL;
	}
	pFontDescriptor->copy(fontDescriptor);

	Object oFontDescriptorRef;
	oFontDescriptorRef.initRef(m_nEntryIndex,0);
	oDescendentFont->getDict()->add(XGetKey("FontDescriptor"), &oFontDescriptorRef);

	if(AddXRefEntry(oDescendentFont) != errNone)
	{
		BrDELETE oDescendentFont;
		return BrNULL;
	}

	return oDescendentFont;
}

Object*	PDFGenerator::GenerateFontDescriptor(LPBrXPDFFontInfo pFontInfo)
{
	// Font Descriptor
	Object *oFontDescriptor = BrNEW Object;
	oFontDescriptor->initDict((XRef*)NULL);

	// Type
	Object oType;
	oType.initName("FontDescriptor");
	oFontDescriptor->getDict()->add(XGetKey("Type"), &oType);

	// FontName
	Object oFontName;
	oFontName.initName(pFontInfo->szFaceName, true);
	oFontDescriptor->getDict()->add(XGetKey("FontName"), &oFontName);

	// Flags
	Object oFlags;
	oFlags.initInt(pFontInfo->nFlags);
	oFontDescriptor->getDict()->add(XGetKey("Flags"), &oFlags);

	// Create CIDSystemInfo Object
	//Object *pCIDSet = BrNEW Object;
	//pCIDSet->initDict((XRef*)NULL);

	//FontBBox
	Object oFontBBox;
	oFontBBox.initArray(NULL);
	Object oSX,oSY,oEX,oEY;
	oSX.initInt(pFontInfo->sBBox.left);
	oSY.initInt(pFontInfo->sBBox.top);
	oEX.initInt(pFontInfo->sBBox.right);
	oEY.initInt(pFontInfo->sBBox.bottom);
	oFontBBox.getArray()->add(&oSX);
	oFontBBox.getArray()->add(&oSY);
	oFontBBox.getArray()->add(&oEX);
	oFontBBox.getArray()->add(&oEY);
	oFontDescriptor->getDict()->add(XGetKey("FontBBox"), &oFontBBox);

	// ItalicAngle
	Object oItalicAngle;
	oItalicAngle.initInt(pFontInfo->nAngle);
	oFontDescriptor->getDict()->add(XGetKey("ItalicAngle"), &oItalicAngle);

	// Ascent
	Object oAscent;
	oAscent.initInt(pFontInfo->nAscent);
	oFontDescriptor->getDict()->add(XGetKey("Ascent"), &oAscent);

	// Descent
	Object oDescent;
	oDescent.initInt(pFontInfo->nDescent);
	oFontDescriptor->getDict()->add(XGetKey("Descent"), &oDescent);

	// CapHeight
	Object oCapHeight;
	oCapHeight.initInt(pFontInfo->nCapHeight);
	oFontDescriptor->getDict()->add(XGetKey("CapHeight"), &oCapHeight);

	// StemV
	Object oStemV;
	oStemV.initInt(pFontInfo->nStemV);
	oFontDescriptor->getDict()->add(XGetKey("StemV"), &oStemV);

BTrace("%s(%d) %s m_eTextType[%d] pFontInfo->szFaceName[%s], pFontInfo->bCFF[%d]", __FILE__, __LINE__, __FUNCTION__, m_eTextType, pFontInfo->szFaceName, pFontInfo->bCFF);	
	// Embeded Font File By Ryucw
	if (m_eTextType != ePDF_TEXT_TYPE_NORMAL && GenerateBaseFontFile(pFontInfo->szFaceName, pFontInfo->bCFF) != false)
	{
		Object oFontFile;
		oFontFile.initRef(m_nEntryIndex, 0);
		m_pExportData.at(m_nCurEmbeddedFont)->m_FontInfoEntryIndex = m_nEntryIndex;
		if (pFontInfo->nType == eXPDFCIDFontType2)
			oFontDescriptor->getDict()->add(XGetKey("FontFile2"), &oFontFile);
		else if(pFontInfo->nType == eXPDFCIDFontType0)
			oFontDescriptor->getDict()->add(XGetKey("FontFile3"), &oFontFile);

		Object oCIDSet;
		if(GenerateCIDSet() == errNone)
		{
			oCIDSet.initRef(m_nEntryIndex, 0);
			m_pExportData.at(m_nCurEmbeddedFont)->m_FontCIDSetEntryIndex = m_nEntryIndex;
			oFontDescriptor->getDict()->add(XGetKey("CIDSet"), &oCIDSet);
		}
	}
	else
		BTrace("Not CID FONT 0 & 2");

	if(AddXRefEntry(oFontDescriptor) != errNone)
	{
		BrDELETE oFontDescriptor;
		return BrNULL;
	}

	return oFontDescriptor;
}

BrBOOL PDFGenerator::GetFontInfo(BrXPDFFontInfo* pFontInfo, BrCHAR* fontFaceName,BrINT nFontFileIndex)
{
	BrBOOL bRet = BrFALSE;
	if( fontFaceName == BrNULL || nFontFileIndex < 0)
		return bRet;

	char * _Context;
	BrCHAR* tmpFontFaceName = strtok_s(fontFaceName, ",", &_Context);
	const char* m_FaceName = BrNULL;
	BrBOOL bFind = BrFALSE;
	BrBOOL bEFFace = BrFALSE;
	BrBOOL bEFTFont = BrFALSE;
	BrINT nSystemFontIndex = -1;
	BrINT nType = -1;
	BrINT nSize = 0;
	BrBYTE nOutAtt = 0;
	int fontIdx = -1;

	//���������� �þ�� ��찡 �����ϹǷ� �������� ���ʿ���
	if(m_nSysFontCnt <= nFontFileIndex)
	{
		getSysFontFace();
	}

	//[16.01.05][sglee1206] Font Index Matching ��ƾ ����.
	//EG Print�� ���� PDF Export�� ������ �־ ������

	//m_EFFace ���� m_Face
	if(m_Face != BrNULL && m_FontPoolIndex[0] <= nFontFileIndex && nFontFileIndex <= m_FontPoolIndex[1])
	{
		fontIdx = nFontFileIndex;
	}
	//m_EFFace
	else if(m_EFFace != BrNULL && m_FontPoolIndex[3] <= nFontFileIndex && nFontFileIndex <= m_FontPoolIndex[4])
	{
		nFontFileIndex -= m_FontPoolIndex[3];
		bEFFace = BrTRUE;
	}
	//m_poFullSetFont
	else if(m_poFullSetFont!= BrNULL && m_FontPoolIndex[4] < nFontFileIndex && nFontFileIndex <= m_FontPoolIndex[5])
	{
		if (m_poFullSetFont->pBold->nFontPoolIndex == nFontFileIndex)
		{
			bEFTFont = BrTRUE;
		}
		else if (m_poFullSetFont->pItalic->nFontPoolIndex == nFontFileIndex)
		{
			bEFTFont = BrTRUE;
		}
		else if (m_poFullSetFont->pBoldItalic->nFontPoolIndex == nFontFileIndex)
		{
			bEFTFont = BrTRUE;
		}
		else if (m_poFullSetFont->pFullSet->nFontPoolIndex == nFontFileIndex)
		{
			bEFTFont = BrTRUE;
		}
	}
	
	//�Ϲ����� m_Face
	if(!bEFFace && !bEFTFont && fontIdx < 0)
	{
		fontIdx = nFontFileIndex - m_FontPoolIndex[2];
	}
	

	for(int idx = 0; idx < m_pExportData.GetSize()+1; idx++)
	{
		if(idx == m_pExportData.GetSize())
		{
			m_pExportData.Add(BrNEW PDFExportTextData());
		}

		if(m_pExportData.at(idx)->getFontFaceName() == BrNULL)
		{
			if(!bEFFace && !bEFTFont && fontIdx >= 0)
			{
				FT_Face fontFace = m_Face[fontIdx]->ft_face;
				m_FaceName = FT_Get_Postscript_Name(fontFace) != NULL ? FT_Get_Postscript_Name(fontFace) : fontFace->family_name;
				nSystemFontIndex = m_Face[fontIdx]->nFontListIndex;
				if( fontFace->stream->pathname.pointer )
				{
					m_pExportData.at(idx)->setFontFilePath((BrCHAR*)fontFace->stream->pathname.pointer);
				}
				else
				{
#if defined( USE_TTF_HEADER_FONT)
					if(fontIdx == 0)
						nType = eFT_BaseEmFont;
					else
#endif
						nType = getFontType(m_FaceName);
					if( nType != -1 )
					{
						BrCHAR* pFontData = BrGetEmFontData(nType, -1, nSize, eFontNormal, nOutAtt);
						m_pExportData.at(idx)->setFontMemoryAddr(pFontData, nSize);
					}
					//�޸𸮿� �ö� ��Ʈ�� ��� ó��
					else if(fontFace->stream->size > 0 && fontFace->stream->base != BrNULL)
					{
						BrUCHAR* pFontData = fontFace->stream->base;
						nSize = fontFace->stream->size;
						m_pExportData.at(idx)->setFontMemoryAddr(pFontData, nSize);
					}
				}
				m_pExportData.at(idx)->setFontFaceName(m_FaceName,nFontFileIndex,nSystemFontIndex);
			}
			else
			{
				if(bEFFace && m_EFFace != NULL)
				{
					if(nFontFileIndex < eEF_MaxFontType)
					{
						m_FaceName = FT_Get_Postscript_Name(m_EFFace[nFontFileIndex]->ft_face)!= NULL ? FT_Get_Postscript_Name(m_EFFace[nFontFileIndex]->ft_face): m_EFFace[nFontFileIndex]->ft_face->family_name;
						nSystemFontIndex = m_EFFace[nFontFileIndex]->nFontListIndex;
						if( m_EFFace[nFontFileIndex]->ft_face->stream->pathname.pointer )
						{
							m_pExportData.at(idx)->setFontFilePath((BrCHAR*)m_EFFace[nFontFileIndex]->ft_face->stream->pathname.pointer);
						}
						else
						{
							nType = eFT_FamilyFont;
							BrCHAR* pFontData = BrGetEmFontData(nType, nFontFileIndex, nSize, eFontNormal, nOutAtt);
							m_pExportData.at(idx)->setFontMemoryAddr(pFontData, nSize);
						}
						m_pExportData.at(idx)->setFontFaceName(m_FaceName,nFontFileIndex,nSystemFontIndex);
						bFind = BrTRUE;
					}
				}
				if(BrFALSE == bFind && m_poFullSetFont)
				{
					if (m_poFullSetFont->pBold->nFontPoolIndex == nFontFileIndex)
					{
						m_FaceName = FT_Get_Postscript_Name(m_poFullSetFont->pBold->ft_face) != NULL ? FT_Get_Postscript_Name(m_poFullSetFont->pBold->ft_face) : m_poFullSetFont->pBold->ft_face->family_name;
						nSystemFontIndex = m_poFullSetFont->pBold->nFontListIndex;
						if (m_poFullSetFont->pBold->ft_face->stream->pathname.pointer)
						{
							m_pExportData.at(idx)->setFontFilePath((BrCHAR*)m_poFullSetFont->pBold->ft_face->stream->pathname.pointer);
						}
						else
						{
							nType = eFT_FamilyFont;
							BrCHAR* pFontData = BrGetEmFontData(nType, eEF_TimesFont, nSize, eFontBold, nOutAtt);
							m_pExportData.at(idx)->setFontMemoryAddr(pFontData, nSize);
						}
						m_pExportData.at(idx)->setFontFaceName(m_FaceName, nFontFileIndex, nSystemFontIndex);
						bFind = BrTRUE;
					}
					else if (m_poFullSetFont->pItalic->nFontPoolIndex == nFontFileIndex)
					{
						m_FaceName = FT_Get_Postscript_Name(m_poFullSetFont->pItalic->ft_face) != NULL ? FT_Get_Postscript_Name(m_poFullSetFont->pItalic->ft_face) : m_poFullSetFont->pItalic->ft_face->family_name;
						nSystemFontIndex = m_poFullSetFont->pItalic->nFontListIndex;
						if (m_poFullSetFont->pItalic->ft_face->stream->pathname.pointer)
						{
							m_pExportData.at(idx)->setFontFilePath((BrCHAR*)m_poFullSetFont->pItalic->ft_face->stream->pathname.pointer);
						}
						else
						{
							nType = eFT_FamilyFont;
							BrCHAR* pFontData = BrGetEmFontData(nType, eEF_TimesFont, nSize, eFontItalic, nOutAtt);
							m_pExportData.at(idx)->setFontMemoryAddr(pFontData, nSize);
						}
						m_pExportData.at(idx)->setFontFaceName(m_FaceName, nFontFileIndex, nSystemFontIndex);
						bFind = BrTRUE;
					}
					else if (m_poFullSetFont->pBoldItalic->nFontPoolIndex == nFontFileIndex)
					{
						m_FaceName = FT_Get_Postscript_Name(m_poFullSetFont->pBoldItalic->ft_face) != NULL ? FT_Get_Postscript_Name(m_poFullSetFont->pBoldItalic->ft_face) : m_poFullSetFont->pBoldItalic->ft_face->family_name;
						nSystemFontIndex = m_poFullSetFont->pBoldItalic->nFontListIndex;
						if (m_poFullSetFont->pBoldItalic->ft_face->stream->pathname.pointer)
						{
							m_pExportData.at(idx)->setFontFilePath((BrCHAR*)m_poFullSetFont->pBoldItalic->ft_face->stream->pathname.pointer);
						}
						else
						{
							nType = eFT_FamilyFont;
							BrCHAR* pFontData = BrGetEmFontData(nType, eEF_TimesFont, nSize, eFontBoldItalic, nOutAtt);
							m_pExportData.at(idx)->setFontMemoryAddr(pFontData, nSize);
						}
						m_pExportData.at(idx)->setFontFaceName(m_FaceName, nFontFileIndex, nSystemFontIndex);
						bFind = BrTRUE;
					}
					else if (m_poFullSetFont->pFullSet->nFontPoolIndex == nFontFileIndex)
					{
						m_FaceName = FT_Get_Postscript_Name(m_poFullSetFont->pFullSet->ft_face) != NULL ? FT_Get_Postscript_Name(m_poFullSetFont->pFullSet->ft_face) : m_poFullSetFont->pFullSet->ft_face->family_name;
						nSystemFontIndex = m_poFullSetFont->pFullSet->nFontListIndex;
						if (m_poFullSetFont->pFullSet->ft_face->stream->pathname.pointer)
						{
							m_pExportData.at(idx)->setFontFilePath((BrCHAR*)m_poFullSetFont->pFullSet->ft_face->stream->pathname.pointer);
						}
						else
						{
							nType = eFT_FamilyFont;
							BrCHAR* pFontData = BrGetEmFontData(nType, eEF_TimesFont, nSize, eFontNormal, nOutAtt);
							m_pExportData.at(idx)->setFontMemoryAddr(pFontData, nSize);
						}
						m_pExportData.at(idx)->setFontFaceName(m_FaceName, nFontFileIndex, nSystemFontIndex);
						bFind = BrTRUE;
					}
				}

				if(BrFALSE == bFind)
				{
					BTrace("Find Fail!!!!!!!");	
					BrDELETE m_pExportData.at(idx);
					m_pExportData.RemoveAt(idx);
					return bRet;
				}
			}

			m_pExportData.at(idx)->setExportTextType(m_eTextType);
			bRet = m_pExportData.at(idx)->createFontData();

			if(!bRet)
			{
				BrDELETE m_pExportData.at(idx);
				m_pExportData.RemoveAt(idx);
				return bRet;
			}

		}	
		if(bRet || ( m_pExportData.at(idx)->getFontFaceName() != BrNULL 
			&& m_pExportData.at(idx)->getExportTextType() == m_eTextType
			&& nFontFileIndex == m_pExportData.at(idx)->getFontFaceIndex() ) 
			)
		{
			memset(pFontInfo->szFaceName, 0, sizeof(pFontInfo->szFaceName));
			strncpy_s(pFontInfo->szFaceName, sizeof(pFontInfo->szFaceName), m_pExportData.at(idx)->getFontFaceName(), strlen(m_pExportData.at(idx)->getFontFaceName()));
			bRet = m_pExportData.at(idx)->getFontInfo(pFontInfo);
			m_nCurEmbeddedFont = idx;
			break;
		}
	}

	return bRet;
}
bool PDFGenerator::GenerateBaseFontFile(BrCHAR* fontFaceName, BrBOOL bCFF )
{
	//[14.05.13][sglee1206] ������ �����̹Ƿ� ���� �ʿ�
	if(m_pExportData.at(m_nCurEmbeddedFont)->m_nFontFileSize > 1024)
	{
		XStream* pStream = BrNEW XStream(ePDF_ENCODE_FLATE);	
		if (pStream == NULL)
		{
			SET_ERROR((PoError)kPoErrMemory, "");
			return BrFALSE;
		}

		if(AddXRefEntry(pStream, BrTRUE) != errNone)
		{
			BrDELETE pStream;
			return BrFALSE;
		}

		PDFEncoder* pEncoder = GetEncoder(pStream->GetType());
		m_pExportData.at(m_nCurEmbeddedFont)->ResetEncodeBuffer(m_pExportData.at(m_nCurEmbeddedFont)->m_nFontFileSize);
		if (0 != pEncoder->Encode(m_pExportData.at(m_nCurEmbeddedFont)->m_pEncodeBuffer, &m_pExportData.at(m_nCurEmbeddedFont)->m_nEncodeBufferLen, 
			m_pExportData.at(m_nCurEmbeddedFont)->m_pFontBuf, m_pExportData.at(m_nCurEmbeddedFont)->m_nFontFileSize))
		{
			BR_SAFE_FREE(m_pExportData.at(m_nCurEmbeddedFont)->m_pFontBuf);
			return BrFALSE;
		}

		pStream->SetStreamBuffer(m_pExportData.at(m_nCurEmbeddedFont)->m_pEncodeBuffer, m_pExportData.at(m_nCurEmbeddedFont)->m_nEncodeBufferLen);

		return BrTRUE;
	}
	else
		return BrFALSE;
}

void PDFGenerator::GenerateFinalFontFile()
{
	for( int i = 0; i < m_pExportData.GetSize(); i++ )
	{
		
		m_pExportData.at(i)->makeExportData();

		XStream* pStream = (XStream*)m_ppObjects[m_pExportData.at(i)->m_FontInfoEntryIndex];
		if (pStream == NULL)
		{
			//g_BoraThreadAtom.m_nErrorCode = kPoErrMemory;
			//ERR_TRACE(kPoErrMemory);
			//return;
			continue;
		}

		PDFEncoder* pEncoder = GetEncoder(pStream->GetType());

		if(m_pExportData.at(i)->m_bUseCFF)
		{
			m_pExportData.at(i)->optimizeCFF();
			m_pExportData.at(i)->ResetEncodeBuffer(m_pExportData.at(i)->m_pCFF->write_length);
			if (0 != pEncoder->Encode(m_pExportData.at(i)->m_pEncodeBuffer, &m_pExportData.at(i)->m_nEncodeBufferLen, (void*)m_pExportData.at(i)->m_pCFF->write_data, m_pExportData.at(i)->m_pCFF->write_length))
			{
				BR_SAFE_FREE(m_pExportData.at(i)->m_pFontBuf);
				//return;
				continue;
			}
			pStream->AppendStreamBuffer(m_pExportData.at(i)->m_pEncodeBuffer, m_pExportData.at(i)->m_nEncodeBufferLen);
			
			Object obj;
			pStream->GetDict()->dictAdd(XGetKey("Subtype"), obj.initName("CIDFontType0C"));
		}
		else
		{
			m_pExportData.at(i)->ResetEncodeBuffer(m_pExportData.at(i)->m_nFontFileSize);
			if (0 != pEncoder->Encode(m_pExportData.at(i)->m_pEncodeBuffer, &m_pExportData.at(i)->m_nEncodeBufferLen, m_pExportData.at(i)->m_pFontBuf, m_pExportData.at(i)->m_nFontFileSize))
			{
				BR_SAFE_FREE(m_pExportData.at(i)->m_pFontBuf);
				//return;
				continue;
			}
			pStream->AppendStreamBuffer(m_pExportData.at(i)->m_pEncodeBuffer, m_pExportData.at(i)->m_nEncodeBufferLen);
		}

		

		// 2.2 Write Stream
		Ref xStreamRef; 
		Guint offset;

		xStreamRef.num = m_pExportData.at(i)->m_FontInfoEntryIndex; 
		xStreamRef.gen = 0;

		WriteStream(pStream, &xStreamRef, m_pOutStream, &offset);
		m_pbWrited[m_pExportData.at(i)->m_FontInfoEntryIndex] = true;
		m_pEntries[m_pExportData.at(i)->m_FontInfoEntryIndex].offset = offset;

		BR_SAFE_DELETE(pStream);

		BrINT unicodeLen = m_pExportData.at(i)->getTextDataLength();
#if 1	
		//[14.05.25][sglee1206] CIDSet ����
		if(m_pExportData.at(i)->m_FontCIDSetEntryIndex != 0)
		{
			// 1.Calculate the cid values.
			if (m_pExportData.at(i)->m_bUseCFF && m_pExportData.at(i)->m_pCFF->m_arrCIDs.size() > 0)
			{
				CFF *cff = m_pExportData.at(i)->m_pCFF;
				BrINT cidMax = cff->m_arrCIDs.at(cff->m_arrCIDs.size() - 1);

				BrINT index, cid, bitIndex, value;
				for (BrINT idx = 0 ; idx < cff->m_arrCIDs.size(); idx++)
				{
					cid = cff->m_arrCIDs.at(idx);
					index = cid / 8;
					bitIndex = cid % 8;
					value = 0x1;

					if (bitIndex != 0)
						value = (value << (7 - bitIndex)) & 0xFFFFFFFF;
					else
						value = 0x80;

					if (index < m_pExportData.at(i)->m_nCIDSetSize)
						m_pExportData.at(i)->m_pCIDSetBuf[index] = m_pExportData.at(i)->m_pCIDSetBuf[index] | value;
					else
					{
						SET_EDIT_WARNING_LOG(kPoWarnPDFExportFontFail, "CFF buffer overflow");
						BRTHREAD_ASSERT(0); // ���� �ɸ��� case ������ cielc �Ǵ� sglee1206 ���� �˷��ּ���
					}
				}
			}
			else
			{
				BrINT*		pGlyfData = m_pExportData.at(i)->getTextGlyfData();
				m_pExportData.at(i)->m_pCIDSetBuf[0] |= 0x80;
				for(int idx = 0; idx < unicodeLen; idx++)
				{
					short k = pGlyfData[idx]/8;
					short def = pGlyfData[idx]%8;

					BrUCHAR flag =0;
					if(def == 0)
						flag = 0x80;
					else if(def == 1)
						flag = 0x40;
					else if(def == 2)
						flag = 0x20;
					else if(def == 3)
						flag = 0x10;
					else if(def == 4)
						flag = 0x08;
					else if(def == 5)
						flag = 0x04;
					else if(def == 6)
						flag = 0x02;
					else if(def == 7)
						flag = 0x01;

					m_pExportData.at(i)->m_pCIDSetBuf[k] |= flag;
				}
			}

			XStream* pCIDSetStream = (XStream*)m_ppObjects[m_pExportData.at(i)->m_FontCIDSetEntryIndex];
			if (pCIDSetStream == NULL)
			{
				//g_BoraThreadAtom.m_nErrorCode = kPoErrMemory;
				//ERR_TRACE(kPoErrMemory);
				//return;
				continue;
			}

			PDFEncoder* pCIDEncoder = GetEncoder(pCIDSetStream->GetType());

			if (0 != pCIDEncoder->Encode(m_pExportData.at(i)->m_pEncodeCIDSetBuffer, &m_pExportData.at(i)->m_nEncodeCIDSetBufferLen, m_pExportData.at(i)->m_pCIDSetBuf, m_pExportData.at(i)->m_nCIDSetSize))
			{
				BR_SAFE_FREE(m_pExportData.at(i)->m_pCIDSetBuf);
			}
			else
			{
				pCIDSetStream->AppendStreamBuffer(m_pExportData.at(i)->m_pEncodeCIDSetBuffer, m_pExportData.at(i)->m_nEncodeCIDSetBufferLen);

				// 2.2 Write Stream
				Ref xCIDSetStreamRef; 
				Guint CIDSetOffset;

				xCIDSetStreamRef.num = m_pExportData.at(i)->m_FontCIDSetEntryIndex; 
				xCIDSetStreamRef.gen = 0;

				WriteStream(pCIDSetStream, &xCIDSetStreamRef, m_pOutStream, &CIDSetOffset);
				m_pbWrited[m_pExportData.at(i)->m_FontCIDSetEntryIndex] = true;
				m_pEntries[m_pExportData.at(i)->m_FontCIDSetEntryIndex].offset = CIDSetOffset;

				BR_SAFE_DELETE(pCIDSetStream);
			}
		}
#endif
		if (m_pExportData.at(i)->m_nFontUnicodeIndex > 0)
		{
			m_nCurEmbeddedFont = i;
			GenearateToUnicodeInfo(BrTRUE);
		}


	}
}

BrINT PDFGenerator::getFontType( const char* fontFaceName )
{
	if(fontFaceName == NULL)
		return -1;

	if( !strcmp(fontFaceName, "NanumGothic") )
		return eFT_NanumGothicFont;
	else if( !strcmp(fontFaceName, "HYWingding") )
		return eFT_WingdingsFont;
	else if( !strcmp(fontFaceName, "HYWingding2") )
		return eFT_Wingdings2Font;
	else if( !strcmp(fontFaceName, "HYWingding3") )
		return eFT_Wingdings3Font;
	else if( !strcmp(fontFaceName, "HYWebdings") )
		return eFT_WebdingsFont;
	else if( !strcmp(fontFaceName, "HYSymbol") )
		return eFT_SymbolFont;
	else if( !strncmp(fontFaceName, "STIXGeneral",BrStrLen("STIXGeneral")) )
		return eFT_STIXMathFont;
	else if( !strcmp(fontFaceName, "HyhwpEQ") )
		return eFT_HyhwpEQFont;

	return -1;
}

//[14.03.20][sglee1206] �����ϴ� Font�� �ش��ϴ� ������ code���� ���� �� �ֵ��� �Լ� �߰�
BrWORD PDFGenerator::getCodeFromCodeMap(BrULONG charCode)
{
	BrWORD tmp = 0;
	if(m_pExportData.GetSize() > m_nCurEmbeddedFont)
	{
		tmp = m_pExportData.at(m_nCurEmbeddedFont)->getCodeFromCodeMap(charCode);
	}
	return tmp;
}

BrULONG		PDFGenerator::UTF8ToUnicode(BrULONG UTF8)
{
	BrULONG unicode = 0;
	BrUSHORT Z = UTF8 >> 16;
	Z--;

	unicode = 0xD800;	// 1101 10
	unicode = unicode | (Z << 6);
	Z = (UTF8 & 0x0000FC00) >> 10;
	unicode = unicode | Z;
	unicode = unicode << 16;
	unicode = unicode | 0xDC00;
	unicode = unicode | (UTF8 & 0x000003FF);

	return unicode;
}

#endif//#ifdef EXPORT_PDF