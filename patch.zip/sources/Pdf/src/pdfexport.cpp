#include <OfficePreCompPDF.hpp>

#ifdef  EXPORT_PDF
#include "pdfexport.h"
#include "BrLocaleLanguageDef.h"
#include "PDFGenerater/pdfGenerator.h"
#include "xpdf/ErrorCodes.h"
#include "PDFGenerater/XStream.h"
#include "xpdf/NameToUnicodeTable.h"
#include "PainterPdf.h"
#include "BFile.h"
#include "butil.h"
#include "PrBitmapFlag.h"

typedef enum
{
	eNoneLineCap,
	eSquareLineCap,
	eRoundLineCap,
	eLineCapMax
}eLINE_CAP_TYPE_PDF;
typedef enum
{
	eMiterDefaultLineJoin = 0,
	eMiterLineJoin,
	eMiterRevertLineJoin,
	eRoundLineJoin,
	eBevelLineJoin,
	eMiterRoundlLineJoin	
}eLINE_JOIN_TYPE_PDF;


char* getUniCodeNme(BrUSHORT nCode)
{
	char* pName = BrNULL;
	int i = 0;
	while (nameToUnicodeTab[i].u != 0)
	{
		if (nCode == nameToUnicodeTab[i].u)
		{
			pName = nameToUnicodeTab[i].name;
			break;
		}
		i++;
	}

	return pName;
}

BrUSHORT getRecheckUnicode(BrUSHORT nCode)
{
	BrUSHORT nUnicode = nCode;

	// �����ڵ忡 ������ �̸��� ã�� ���� ��� �ش� 2���ڵ带 ã�´�.
	int nCount = BrSizeOf(arabicCodeList) / BrSizeOf(BrUSHORT) / 2;
	int nIndex1 = 0, nIndex2 = 1;
	if (nUnicode > 0x7000)
	{
		nIndex1 = 0;
		nIndex2 = 1;
	}
	else
	{
		nIndex1 = 1;
		nIndex2 = 0;
	}

	for (int i = 0; i < nCount; i++)
	{
		if (arabicCodeList[i][nIndex1] == nUnicode)
		{
			nUnicode = arabicCodeList[i][nIndex2];
			break;
		}
	}

	return nUnicode;
}

BPDFExport::BPDFExport()
{
	init();
}

BPDFExport::~BPDFExport()
{
	BR_SAFE_FREE(m_clipRect);
	BR_SAFE_DELETE(m_rootBookmark);
	BR_SAFE_DELETE(m_pGenerator);
}

void BPDFExport::init()
{
	m_clipRect = (XRect*)BrMalloc(BrSizeOf(XRect));
	memset(m_clipRect, 0, BrSizeOf(XRect));
	m_nOregFontIndex = eNoneOREGCTFont;
	m_pGenerator = BrNULL;

	m_bBottomWaterMark = BrFALSE;
	m_bRemoveHyperlink = BrFALSE;
	m_bUsePageSize = BrFALSE;
	m_nImageMargin = 0;

	BrUSHORT wTimesNewRoman[] = {0x74, 0x69,0x6D,0x65,0x73,0x20,0x6E,0x65,0x77,0x20,0x72,0x6F,0x6D,0x61,0x6E,0x00};

	m_nState = eNormal_PDFExtState;
	memset(&m_sCTTable, 0, BrSizeOf(m_sCTTable));
	memset(&m_sFontFace, 0, BrSizeOf(m_sFontFace));
	memset(&m_sCIDInfo, 0, BrSizeOf(m_sCIDInfo));

	CUtil::WcsNcpy(m_sFontFace, wTimesNewRoman, MAX_FONT_LEN);
	m_nFontFaceLen = 15;
	m_nRegFontType = eNone_RegCType;
	setFontInfo(0, BrTRUE);
	m_sTextAtt.nAngle = 0;
	m_sTextAtt.nBgColor = WHITE_COLOR;
	m_sTextAtt.nColor = BLACK_COLOR;
	m_sTextAtt.nFontSize = 10.0;	
	m_sTextAtt.nShadowColor = 0xffffffff;
	m_sTextAtt.fScaleX = m_sTextAtt.fScaleY = 1.0;
	m_nFDFlag = eNone_PDFFDFlag;
	m_pPathStream = BrNULL;
	m_nRotateAngle = 0;
	m_nFlipType = eFigureFlipNone; // Coverity-14676

	m_rootBookmark = BrNULL;
	m_bPenWidthIsTwip = BrFALSE;
	m_bNeedChangeFont = BrFALSE;
	m_bHasClippingPath = BrFALSE;
	clearTextPool();
	pathAttInit();
	memset(&m_sBrushBitData, 0, BrSizeOf(m_sBrushBitData));	
	BR_SET_STATE(m_nState, (eDefaultFont_PDFExtState|eUpdateFont_PDFExtState));
}

void BPDFExport::clearDefCIDFont()
{
	memset(&m_sDefCIDFontInfo, 0, BrSizeOf(m_sDefCIDFontInfo));
	m_nDefCIDFontIndex = -1;
	BR_REL_STATE(m_nState, eDefCIDFontMask_PDFExtState);
}

void BPDFExport::clearTextPool()
{
	m_nTextPoolSPos.x = m_nTextPoolSPos.y = 0;
	m_nTextPoolEPos.x = m_nTextPoolEPos.y = 0;
	m_nTextPoolShadowSPos.x = m_nTextPoolShadowSPos.y = 0;
	m_nTextPoolShadowEPos.x = m_nTextPoolShadowEPos.y = 0;
	m_bTextPoolShadow = BrFALSE;
	m_aTextPool.resize(0);
}

void BPDFExport::clearRegCodeTable()
{	
	LPBrXPDFRegTextInfo pTextInfo = BrNULL;
	BrINT nSize = m_aRegTextInfo.size();
	for(BrINT i = 0; i<nSize;i++)
	{
		pTextInfo = m_aRegTextInfo.GetAt(i);
		if(pTextInfo->pTextIndexs)
			BrFree(pTextInfo->pTextIndexs);
	}
	m_aRegTextInfo.resize(0);
	memset(&m_nUseRegCode, -1, BrSizeOf(m_nUseRegCode));	
	m_nRegFontIndex = -1;
	m_nRegFontType = eNone_RegCType;
	m_aRegBaseTextAtt.resize(0);	
	m_aRegCode.resize(0);
	clearTextPool();
}

BrBOOL BPDFExport::open(BrCHAR* pPDFPath, LPBrRect pMaxPageRect, BrINT nExpectedTotalPage, BrBOOL bPDFAExport)
{
	BrINT err = errNone;
	GString errMsg = "PDF Export Fail";

	if(pMaxPageRect)
	{
		BR_SAFE_DELETE(m_pGenerator);
		m_pGenerator = BrNEW PDFGenerator;
		if(m_pGenerator)
		{
			XRect xRect = {(float)pMaxPageRect->left, (float)pMaxPageRect->top, (float)pMaxPageRect->right, (float)pMaxPageRect->bottom};
			GString sFile = pPDFPath;			
			time_t createTime = time(BrNULL);
			err = m_pGenerator->GenerateDocument(nExpectedTotalPage, &xRect, &sFile, createTime);
			if(err == errNone)
			{
				err = m_pGenerator->GeneratePdfEntry(bPDFAExport, createTime);
				if(err == errNone)
				{
					sFile.clear();
					return BrTRUE;
				}				
			}

			sFile.clear();
			BrDELETE m_pGenerator;
			m_pGenerator = BrNULL;

			errMsg.appendf(" err %d", err);
			SET_ERROR_LOG(kPoErrPDFExportFail, errMsg.getCString(), __FUNCTION__);

			return BrFALSE;
		}
	}

	errMsg.appendf(" err %d", err);
	SET_ERROR_LOG(kPoErrPDFExportFail, errMsg.getCString(), __FUNCTION__);

	return BrFALSE;
}

BrINT BPDFExport::close(BrBOOL bSave)
{
	BrINT ret = 0;
	if(m_pGenerator)
	{
		if(m_rootBookmark){
			ret = m_pGenerator->addOutlines(m_rootBookmark);
			BrDELETE m_rootBookmark;
			m_rootBookmark = BrNULL;
		}

		if(ret != -1)	// addOutlines�� fail�� -1
			ret = completePage();
		if(ret == errNone)
			m_pGenerator->CompleteGeneration(bSave);

		BrDELETE m_pGenerator;
		m_pGenerator = BrNULL;
	}
	return ret;
}

BrINT BPDFExport::completePage()
{
	BrINT ret = errNone;

	if(m_pGenerator && BR_ISSET_STATE(m_nState, ePageMaking_PDFExtState))
	{
		//[2012.09.12][ekaloss] ������ ��ȯ �� underline color�� set ������ ���ϴ� ���� ����.  
		m_cPencolor = BLACK_COLOR;
		m_cBrushcolor = BLACK_COLOR;	//[[dwchun : 2012.08.24] : Export�� XStream�� Color���� "B"(Block)�̱� ������ �⺻ ���� Block���� ���� ��
		m_nPenWidth = 1;
		m_nPenStyle = eSolid;
		m_nRotateAngle = 0;

		BrINT nPageNum = m_pGenerator->GetCurrentPageNum();
		postExport();
		endPath();

		if(m_bBottomWaterMark == BrFALSE)
		{
			PrBitmap waterMark;
			PrBitmapFlag sFlag;

			if(g_PDFExportWaterMarkUse == BrTRUE) 
			{
				// ��ü Page Water Mark ���
				XRect xRect = {0,};
				m_pGenerator->GetPageRect(nPageNum, &xRect);


				BrINT width = (xRect.left+xRect.right);
				BrINT height = (xRect.top+xRect.bottom);

				BrRect rt = { 0, 0, width, height };

				// �̹� ���� target ���� rect ������ addImage ���ο��� ����� ���� �����ؼ� �����صд�.
				// twip�� device ��ǥ���� ���̷� twip �� ���� 5������ ������ �߻��� �� ����
				{
					rt.left = Device2twips(twips2DeviceX(rt.left, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
					rt.top = Device2twips(twips2DeviceY(rt.top, gpPaint->zoom.m_iScale, 0,getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
					rt.right = Device2twips(twips2DeviceX(rt.right, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
					rt.bottom = Device2twips(twips2DeviceY(rt.bottom, gpPaint->zoom.m_iScale, 0, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
				}

				char *waterMarkPath = BrNULL;

				waterMarkPath = (char*)BrGetPDFExportWaterMarkPath(nPageNum , (rt.right-rt.left) , (rt.bottom-rt.top));
				if(waterMarkPath != BrNULL)
				{
					if(waterMark.loadImageFile(waterMarkPath, 0, 0, 0, 100, sFlag, BrNULL))
					{
						addImage(&waterMark, &rt);
						waterMark.free_all();
					}
				}
			}
			else
			{
				if(BrStrLen(g_PDFexportWaterMarkPath) > 0 && waterMark.loadImageFile(g_PDFexportWaterMarkPath, 0, 0, 0, 100, sFlag, BrNULL))
				{

					BrINT width = waterMark.getDib()->biWidth;
					BrINT height = waterMark.getDib()->biHeight;
					XRect xRect = {0,};
					m_pGenerator->GetPageRect(nPageNum, &xRect);

					BrINT midWidth = (xRect.left+xRect.right)/2;
					BrINT midHeight = (xRect.top+xRect.bottom)/2;

					BrRect rt = { midWidth-width/2, midHeight-height/2, midWidth+width/2, midHeight+height/2 };

					waterMark.setAlpha(g_PDFExportWaterMarkAlpha);

					// �̹� ���� target ���� rect ������ addImage ���ο��� ����� ���� �����ؼ� �����صд�.
					// twip�� device ��ǥ���� ���̷� twip �� ���� 5������ ������ �߻��� �� ����
					{
						rt.left = Device2twips(twips2DeviceX(rt.left, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
						rt.top = Device2twips(twips2DeviceY(rt.top, gpPaint->zoom.m_iScale, 0,getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
						rt.right = Device2twips(twips2DeviceX(rt.right, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
						rt.bottom = Device2twips(twips2DeviceY(rt.bottom, gpPaint->zoom.m_iScale, 0, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
					}

					addImage(&waterMark, &rt);

					waterMark.free_all();
				}
			}
		}

		ret = m_pGenerator->CompletePage(nPageNum);
		BR_REL_STATE(m_nState, ePageMaking_PDFExtState);
	}
	BR_SET_STATE(m_nState, eUpdateFont_PDFExtState);

	if (ret != errNone)
	{
		GString errMsg = "PDF Export Fail";
		errMsg.appendf(" errCode %d", ret);
		SET_ERROR_LOG(kPoErrPDFExportFail, errMsg.getCString(), __FUNCTION__);
	}

	return ret;
}

void BPDFExport::postExport()
{
	addRegText();
}

BrBOOL BPDFExport::addPage(BrINT nPageNum, LPBrRect pPageRect, PrBitmap* pBitmap, BoraAnnotInfo* pAnnotInfo, BrINT nAnnotCount)
{
	if(m_pGenerator && pBitmap && pBitmap->isHasBitmap() && pPageRect && nPageNum)
	{
		BrINT nErr = errNone;
		nErr = completePage();

		if(nErr == errNone && pBitmap && pBitmap->isHasBitmap())
		{
			XRect xRect = {(float)pPageRect->left, (float)pPageRect->top, (float)pPageRect->right, (float)pPageRect->bottom};
			nPageNum--;
			nErr = m_pGenerator->GeneratePage(nPageNum);

			if(nErr == errNone)
				m_pGenerator->SetPageRect(nPageNum, &xRect);

			if(m_bBottomWaterMark == BrTRUE)
			{
				PrBitmap waterMark;
				PrBitmapFlag sFlag;
				if(BrStrLen(g_PDFexportWaterMarkPath) > 0 && waterMark.loadImageFile(g_PDFexportWaterMarkPath, 0, 0, 0, 100, sFlag, BrNULL))
				{
					BrINT width = waterMark.getDib()->biWidth;
					BrINT height = waterMark.getDib()->biHeight;
					XRect xRect = {0,};
					m_pGenerator->GetPageRect(nPageNum, &xRect);

					BrINT midWidth = (xRect.left+xRect.right)/2;
					BrINT midHeight = (xRect.top+xRect.bottom)/2;

					BrRect rt = { midWidth-width/2, midHeight-height/2, midWidth+width/2, midHeight+height/2 };

					waterMark.setAlpha(g_PDFExportWaterMarkAlpha);

					//// �̹� ���� target ���� rect ������ addImage ���ο��� ����� ���� �����ؼ� �����صд�.
					//// twip�� device ��ǥ���� ���̷� twip �� ���� 5������ ������ �߻��� �� ����
					//{
					//	rt.left = Device2twips(twips2DeviceX(rt.left, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
					//	rt.top = Device2twips(twips2DeviceY(rt.top, gpPaint->zoom.m_iScale, 0,getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
					//	rt.right = Device2twips(twips2DeviceX(rt.right, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
					//	rt.bottom = Device2twips(twips2DeviceY(rt.bottom, gpPaint->zoom.m_iScale, 0, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
					//}

					addImage(&waterMark, &rt);

					waterMark.free_all();
				}
			}

			BrRect rcTest = { 0, };
			if (m_bUsePageSize)
			{
				// Page Size �� ���缭 �̹��� ����� ���� �Ѵ�.
				// m_bUsePageSize ���� imagetoPDF ���ۿ����� TRUE üũ�ϵ��� �Ѵ�. ���Ƿ� Ÿ ���� ��ȯ�ÿ��� ������� �ʴ´�.
				// m_nImageScale ���� ���� ���� ����
				// EX ) m_nImageScale - 0 ����X , m_nImageScale - 10 ,, 10% ����

				BrFLOAT pW = (float)pPageRect->right - (float)pPageRect->left;
				BrFLOAT pH = (float)pPageRect->bottom - (float)pPageRect->top;
				BrINT reLeft = 0;
				
				if (m_nImageMargin != 0)
				{
					BrFLOAT reW = (pW * ((float)m_nImageMargin / 100));
					pW = pW - reW;
					reLeft = reW / 2;
				}

				BrFLOAT reH = pBitmap->getDib()->biHeight * ((BrFLOAT)pW / (BrFLOAT)pBitmap->getDib()->biWidth);

				BrINT reRight = (BrINT)pW + reLeft;
				BrINT reTop = ((BrINT)pH - (BrINT)reH) / 2;
				BrINT reBottom = reTop + (BrINT)reH;
				
				rcTest = { reLeft , reTop, reRight, reBottom };
			}
			else
				rcTest = {pPageRect->left, pPageRect->top, pPageRect->right, pPageRect->bottom};

			if(nErr == errNone)
				addImage(pBitmap, &rcTest);

			if(nErr == errNone && pAnnotInfo && nAnnotCount )
			{
				for( BrINT i = 0; i < nAnnotCount; i++ )
				{
					if( nPageNum == pAnnotInfo[i].nPageIndex - 1 )
					{
						XRect rectAnnot = {(float)pAnnotInfo[i].nXPos, (float)pAnnotInfo[i].nYPos, (float)(pAnnotInfo[i].nXPos+STICKY_NOTE_WIDTH), (float)(pAnnotInfo[i].nYPos+STICKY_NOTE_HEIGHT)};
						XRect rectPopup = {(float)pPageRect->right, 0, (float)(pPageRect->right+STICKY_NOTE_POPUP_WIDTH), (float)STICKY_NOTE_POPUP_HEIGHT};

						XStickyNote stickyNote;
						XAnnotPopup annotPopup;
						memset(&stickyNote, 0, BrSizeOf(stickyNote));
						memset(&annotPopup, 0, BrSizeOf(annotPopup));

						// Annot Popup Set
						annotPopup.open = true;
						annotPopup.rect = rectPopup;
						annotPopup.szAuthor = (UINT16*)"author";
						annotPopup.szContents = (UINT16*)pAnnotInfo[i].strNoteContents;
						annotPopup.szSubject = (UINT16*)"subject";
						annotPopup.type = ePDF_ANNOT_POPUP;
						annotPopup.flag = 28;

						// StickyNote Set
						stickyNote.popup = &annotPopup;
						stickyNote.rect = rectAnnot;
						stickyNote.szAuthor = (UINT16*)"author";
						stickyNote.szContents = (UINT16*)pAnnotInfo[i].strNoteContents;
						stickyNote.szSubject = (UINT16*)"subject";
						stickyNote.szLabel = "label";
						stickyNote.type = ePDF_ANNOT_TEXT;
						stickyNote.colorNum = 3;
						stickyNote.colors = (float*)BrMalloc(BrSizeOf(float)*3);
						*(stickyNote.colors + 0) = 1.0;
						*(stickyNote.colors + 1) = 0.5;
						*(stickyNote.colors + 2) = 0.0;
						stickyNote.flag = 28;

						nErr = m_pGenerator->AddStickyNoteToPage(nPageNum, &stickyNote);

						BrFree(stickyNote.colors);
					}
				}
			}

			if(m_bBottomWaterMark == BrFALSE)
			{
				PrBitmap waterMark;
				PrBitmapFlag sFlag;
				if(BrStrLen(g_PDFexportWaterMarkPath) > 0 && waterMark.loadImageFile(g_PDFexportWaterMarkPath, 0, 0, 0, 100, sFlag, BrNULL))
				{
					BrINT width = waterMark.getDib()->biWidth;
					BrINT height = waterMark.getDib()->biHeight;
					XRect xRect = {0,};
					m_pGenerator->GetPageRect(nPageNum, &xRect);

					BrINT midWidth = (xRect.left+xRect.right)/2;
					BrINT midHeight = (xRect.top+xRect.bottom)/2;

					BrRect rt = { midWidth-width/2, midHeight-height/2, midWidth+width/2, midHeight+height/2 };

					waterMark.setAlpha(g_PDFExportWaterMarkAlpha);

					//// �̹� ���� target ���� rect ������ addImage ���ο��� ����� ���� �����ؼ� �����صд�.
					//// twip�� device ��ǥ���� ���̷� twip �� ���� 5������ ������ �߻��� �� ����
					//{
					//	rt.left = Device2twips(twips2DeviceX(rt.left, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
					//	rt.top = Device2twips(twips2DeviceY(rt.top, gpPaint->zoom.m_iScale, 0,getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
					//	rt.right = Device2twips(twips2DeviceX(rt.right, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
					//	rt.bottom = Device2twips(twips2DeviceY(rt.bottom, gpPaint->zoom.m_iScale, 0, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
					//}

					addImage(&waterMark, &rt);

					waterMark.free_all();
				}
			}

			if(nErr == errNone)
				nErr = m_pGenerator->CompletePage(nPageNum);
		}

		if(nErr == errNone)
			return BrTRUE;
	}

	return BrFALSE;
}

BrBOOL BPDFExport::addPage(BrINT nPageNum, LPBrRect pPageRect, BrCHAR* pPath, BrSize sOrgSize, BoraAnnotInfo* pAnnotInfo, BrINT nAnnotCount)
{
	BrINT nErr = errNone;

	if(m_pGenerator && pPath && pPageRect && nPageNum)
	{

		nErr = completePage();

		if(nErr == errNone)
		{
			BFile file;
			BString strSrcFile = CUtil::UTF8ToBString((char*)pPath);
			if ( file.Open(strSrcFile, BMV_READ_ONLY) )
			{
				XImage sXimage = {0,};

				sXimage.length = file.Size();
				sXimage.buffer = BrMalloc(sXimage.length);
				if(sXimage.buffer)
				{
					if(sXimage.length == file.Read((BrBYTE*)sXimage.buffer, sXimage.length))
					{
						sXimage.width = sOrgSize.cx;
						sXimage.height = sOrgSize.cy;
						sXimage.colorSpace = ePDF_COLORSPACE_RGB;
						sXimage.numComponents = 3;
						XRect xRect = {(float)pPageRect->left, (float)pPageRect->top, (float)pPageRect->right, (float)pPageRect->bottom};
						nPageNum--;
						nErr = m_pGenerator->GeneratePage(nPageNum);

						if(nErr == errNone)
							m_pGenerator->SetPageRect(nPageNum, &xRect);

						if(nErr == errNone)
							nErr = m_pGenerator->AddImage(&sXimage, &xRect, BrNULL);

						if(nErr == errNone && pAnnotInfo && nAnnotCount )
						{
							for( BrINT i = 0; i < nAnnotCount; i++ )
							{
								if( nPageNum == pAnnotInfo[i].nPageIndex - 1 )
								{
									XRect rectAnnot = {(float)pAnnotInfo[i].nXPos, (float)pAnnotInfo[i].nYPos, (float)(pAnnotInfo[i].nXPos+STICKY_NOTE_WIDTH), (float)(pAnnotInfo[i].nYPos+STICKY_NOTE_HEIGHT)};
									XRect rectPopup = {(float)pPageRect->right, 0, (float)(pPageRect->right+STICKY_NOTE_POPUP_WIDTH), (float)STICKY_NOTE_POPUP_HEIGHT};

									XStickyNote stickyNote;
									XAnnotPopup annotPopup;
									memset(&stickyNote, 0, BrSizeOf(stickyNote));
									memset(&annotPopup, 0, BrSizeOf(annotPopup));

									// Annot Popup Set
									annotPopup.open = true;
									annotPopup.rect = rectPopup;
									annotPopup.szAuthor = (UINT16*)"author";
									annotPopup.szContents = (UINT16*)pAnnotInfo[i].strNoteContents;
									annotPopup.szSubject = (UINT16*)"subject";
									annotPopup.type = ePDF_ANNOT_POPUP;
									annotPopup.flag = 28;

									// StickyNote Set
									stickyNote.popup = &annotPopup;
									stickyNote.rect = rectAnnot;
									stickyNote.szAuthor = (UINT16*)"author";
									stickyNote.szContents = (UINT16*)pAnnotInfo[i].strNoteContents;
									stickyNote.szSubject = (UINT16*)"subject";
									stickyNote.szLabel = "label";
									stickyNote.type = ePDF_ANNOT_TEXT;
									stickyNote.colorNum = 3;
									stickyNote.colors = (float*)BrMalloc(BrSizeOf(float)*3);
									*(stickyNote.colors + 0) = 1.0;
									*(stickyNote.colors + 1) = 0.5;
									*(stickyNote.colors + 2) = 0.0;
									stickyNote.flag = 28;

									nErr = m_pGenerator->AddStickyNoteToPage(nPageNum, &stickyNote);

									BrFree(stickyNote.colors);
								}
							}
						}
						if(nErr == errNone)
							nErr = m_pGenerator->CompletePage(nPageNum);
					}

					BrFree(sXimage.buffer);
				}

				file.Close();


				if(nErr == errNone)
					return BrTRUE;
			}
		}
	}

	return BrFALSE;
}

BrBOOL BPDFExport::createPage(LPBrSize pPageSize)
{
	BrINT ret = errNone;
	if(m_pGenerator)
	{
		ret = completePage();

		if(ret == errNone)
		{
		BrINT nCurPage = m_pGenerator->GetCurrentPageNum()+1;
		if(m_pGenerator->GeneratePage(nCurPage) == errNone)
		{
			BR_SET_STATE(m_nState, ePageMaking_PDFExtState);

			if(pPageSize)
			{
				XRect sPageRect = {(BrFLOAT)0, (BrFLOAT)0, 
					(BrFLOAT)twips2DeviceX(Device2twips(pPageSize->cx, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION), 
					(BrFLOAT)twips2DeviceY(Device2twips(pPageSize->cy, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, 0, TARGET_DEVICE_RESOLUTION)};
				m_pGenerator->SetPageRect(nCurPage, &sPageRect);
			}

			if(m_bBottomWaterMark == BrTRUE)
			{
				PrBitmap waterMark;
				PrBitmapFlag sFlag;
				if(BrStrLen(g_PDFexportWaterMarkPath) > 0 && waterMark.loadImageFile(g_PDFexportWaterMarkPath, 0, 0, 0, 100, sFlag, BrNULL)){

					BrINT width = waterMark.getDib()->biWidth;
					BrINT height = waterMark.getDib()->biHeight;
					XRect xRect = {0,};
					m_pGenerator->GetPageRect(nCurPage, &xRect);

					BrINT midWidth = (xRect.left+xRect.right)/2;
					BrINT midHeight = (xRect.top+xRect.bottom)/2;

					BrRect rt = { midWidth-width/2, midHeight-height/2, midWidth+width/2, midHeight+height/2 };

					waterMark.setAlpha(g_PDFExportWaterMarkAlpha);

					// �̹� ���� target ���� rect ������ addImage ���ο��� ����� ���� �����ؼ� �����صд�.
					// twip�� device ��ǥ���� ���̷� twip �� ���� 5������ ������ �߻��� �� ����
					{
						rt.left = Device2twips(twips2DeviceX(rt.left, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
						rt.top = Device2twips(twips2DeviceY(rt.top, gpPaint->zoom.m_iScale, 0,getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
						rt.right = Device2twips(twips2DeviceX(rt.right, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
						rt.bottom = Device2twips(twips2DeviceY(rt.bottom, gpPaint->zoom.m_iScale, 0, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
					}

					addImage(&waterMark, &rt);

					waterMark.free_all();
				}
			}

			return BrTRUE;
		}
	}
	}
	return BrFALSE;
}

BrINT BPDFExport::closePage()
{
	BrINT ret = errNone;

	if(m_pGenerator)
	{
		ret = completePage();
		clearBrush();
	}
	return ret;
}

void* BPDFExport::addBookmark(void* pParent, BrUINT16* sz_Title, BrINT n_TitleLen, BrINT nPageNum, BrINT nX, BrINT nY)
{
	XBookmark* item = NULL;
	XRect sPageRect = {0,};

	if(pParent == BrNULL) {
		if(m_rootBookmark == BrNULL)
			m_rootBookmark = BrNEW XBookmark();

		item = m_rootBookmark->addChild(sz_Title, n_TitleLen);
		item->pageNum = nPageNum-1;
		item->x = nX;
		if(m_pGenerator->GetPageRect(nPageNum-1, &sPageRect) == errNone) {
			item->y = sPageRect.bottom - nY;
		} else if(m_pGenerator->GetPageRect(nPageNum-2, &sPageRect) == errNone) {
			item->pageNum = nPageNum-2;
			item->y = nY;
		} else
			item->y = nY;
	} else {
		item = ((XBookmark*)pParent)->addChild(sz_Title, n_TitleLen);
		item->pageNum = nPageNum-1;
		item->x = nX;
		if(m_pGenerator->GetPageRect(nPageNum-1, &sPageRect) == errNone) {
			item->y = sPageRect.bottom - nY;
		} else if(m_pGenerator->GetPageRect(nPageNum-2, &sPageRect) == errNone) {
			item->pageNum = nPageNum-2;
			item->y = nY;
		} else
			item->y = nY;
	}

	return (void*)item;
}

BrBOOL BPDFExport::addImage(PrBitmap * pImage, LPBrRect pPageRect, BrINT nRoateAngle, BrPOINT* pRotAngleCPos, BrBOOL bPreblended )
{
	if(pPageRect!=BrNULL && gpPaint != BrNULL){
		pPageRect->left = twips2DeviceX(Device2twips(pPageRect->left, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
		pPageRect->top = twips2DeviceY(Device2twips(pPageRect->top, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, 0, TARGET_DEVICE_RESOLUTION);
		pPageRect->right = twips2DeviceX(Device2twips(pPageRect->right, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
		pPageRect->bottom = twips2DeviceY(Device2twips(pPageRect->bottom, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, 0, TARGET_DEVICE_RESOLUTION);
	}

	//[2013.08.02][inkkim] rotate point transform upon ptd export resolution
	if (pRotAngleCPos!=BrNULL && gpPaint != BrNULL)
	{
		pRotAngleCPos->x = twips2DeviceX(Device2twips(pRotAngleCPos->x, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
		pRotAngleCPos->y = twips2DeviceY(Device2twips(pRotAngleCPos->y, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, 0, TARGET_DEVICE_RESOLUTION);
	}

	postExport();

	//pImage->dumpImage(-pImage->cx(), 100);
	if(m_pGenerator && pImage && pImage->isHasBitmap() && pPageRect)
	{
		BrINT nErr = errNone;	
		BrDWORD nJPEGSize = 0;
		BrINT nSaveFormat = eImage_JPEG;
#if 1
#ifdef USE_32BIT_IMAGE
		if(pImage->getBitCount() == 32 && pImage->isHasAlphaBit())
		{			
			LPBrBITMAPINFOHEADER pDIBBit = BrNULL;
			LPBrBITMAPINFOHEADER pMaskBit = BrNULL;

			nSaveFormat = eImage_DIB;
			//pDIBBit = (LPBrBITMAPINFOHEADER)pImage->save(nSaveFormat, &nJPEGSize, BrTRUE);
			//pImage->convertDIB_SYSM(eBGR888Bitmap, BrTRUE, &pDIBBit, &pMaskBit);
			pImage->convertDIB(eBGR888Bitmap, BrTRUE, &pDIBBit, &pMaskBit);

			if(pDIBBit && pMaskBit)
			{
				XBitmap sRGBBit = {0};
				XBitmap sAlphaBit = {0};
				XRect xRect = {(float)pPageRect->left, (float)pPageRect->top, (float)pPageRect->right, (float)pPageRect->bottom};
				sRGBBit.width = pImage->cx();
				sRGBBit.height = pImage->cy();
				sRGBBit.buffer = GETDATAPOS(pDIBBit);
				sRGBBit.bytesPerPixel = 3;
				sRGBBit.format = eXBITMAP_RGB888;

				sAlphaBit.width = sRGBBit.width;
				sAlphaBit.height = sRGBBit.height;
				sAlphaBit.buffer = GETDATAPOS(pMaskBit);
				sAlphaBit.bytesPerPixel = 1;
				sAlphaBit.format = eXBITMAP_RGB888;

				// �׻� RGBBit�� AlphaBit���� �����ؼ� �����ϰ� �����Ƿ� RGBBit�� preblended �Ǿ����� �ʴ�.
				// �Ŀ� �ش� ����� �ʿ��� ��쿡 �Բ� ������ ��.
				if(m_clipRect->left == 0 && m_clipRect->top == 0 && m_clipRect->right == 0 && m_clipRect->bottom == 0)
					nErr = m_pGenerator->AddImage(&sRGBBit, &sAlphaBit, &xRect, &xRect, -nRoateAngle, pRotAngleCPos, BrFALSE /*bPreblended*/);
				else
					nErr = m_pGenerator->AddImage(&sRGBBit, &sAlphaBit, &xRect, m_clipRect, -nRoateAngle, pRotAngleCPos, BrFALSE /*bPreblended*/);

				PrBitmap::freeDIB(pDIBBit);
				BrFree(pMaskBit);
				if(nErr == errNone)
					return BrTRUE;
			}						
		}
#else
		if(pImage->isHasMaskBitmap() && pImage->getBitCount() <= 16)		
		{			
			LPBrBITMAPINFOHEADER pDIBBit = BrNULL;

			nSaveFormat = eImage_DIB;
			//pDIBBit = (LPBrBITMAPINFOHEADER)pImage->save(nSaveFormat, &nJPEGSize, BrTRUE);
			pImage->convertDIB(eBGR888Bitmap, BrFALSE, &pDIBBit);
			//pImage->convertDIB_SYSM(eBGR888Bitmap, BrFALSE, &pDIBBit);

			if(pDIBBit)
			{
				XBitmap sRGBBit = {0};
				XBitmap sAlphaBit = {0};
				XRect xRect = {(float)pPageRect->left, (float)pPageRect->top, (float)pPageRect->right, (float)pPageRect->bottom};
				sRGBBit.width = pImage->cx();
				sRGBBit.height = pImage->cy();
				sRGBBit.buffer = GETDATAPOS(pDIBBit);
				sRGBBit.bytesPerPixel = 3;
				sRGBBit.format = eXBITMAP_RGB888;

				sAlphaBit.width = sRGBBit.width;
				sAlphaBit.height = sRGBBit.height;
				sAlphaBit.buffer = pImage->getMaskData();
				sAlphaBit.bytesPerPixel = 1;
				sAlphaBit.format = eXBITMAP_RGB888;

				if(m_clipRect->left == 0 && m_clipRect->top == 0 && m_clipRect->right == 0 && m_clipRect->bottom == 0)
					nErr = m_pGenerator->AddImage(&sRGBBit, &sAlphaBit, &xRect, &xRect, -nRoateAngle, pRotAngleCPos);
				else
					nErr = m_pGenerator->AddImage(&sRGBBit, &sAlphaBit, &xRect, m_clipRect, -nRoateAngle, pRotAngleCPos);

				//BrFree(pDIBBit);
				PrBitmap::freeDIB(pDIBBit);				
				if(nErr == errNone)
					return BrTRUE;
			}			
		}
#endif

		else
		{
			XImage sXimage = {0,};
			PrBitmap s16BitBitmap;
			PrBitmap* pExtBitmap = pImage;
			if(pImage->getBitCount() < 16)
			{
				s16BitBitmap.createBitmap(pImage->cx(), pImage->cy());
				s16BitBitmap.bitBlt(0, 0, pImage, 0, 0, pImage->cx(), pImage->cy());
				pExtBitmap = &s16BitBitmap;
			}
			sXimage.buffer = pExtBitmap->save(nSaveFormat, &nJPEGSize);
			if(sXimage.buffer)
			{
				XRect xRect = {(float)pPageRect->left, (float)pPageRect->top, (float)pPageRect->right, (float)pPageRect->bottom};
				//sXimage.format = eXIMAGE_JPEG;
				sXimage.length = nJPEGSize;
				sXimage.width = pImage->cx();
				sXimage.height = pImage->cy();
				//if(nSaveFormat == eImage_PNG)
				sXimage.angle = -nRoateAngle;

				if(m_clipRect->left == 0 && m_clipRect->top == 0 && m_clipRect->right == 0 && m_clipRect->bottom == 0)
					nErr = m_pGenerator->AddImage(&sXimage, &xRect, &xRect, pRotAngleCPos);
				else
					nErr = m_pGenerator->AddImage(&sXimage, &xRect, m_clipRect, pRotAngleCPos);
				BrFree(sXimage.buffer);
				if(nErr == errNone)
					return BrTRUE;
			}
		}
#else //
		XImage sXimage = {0,};

		if(pImage->isHasMaskBitmap())
			nSaveFormat = eImage_PNG;

		sXimage.buffer = pImage->save(nSaveFormat, &nJPEGSize);		

		//////////////////////////////////////////////////////////
		//pImage->save("e:/test.png", BrNULL, BrNULL,  eImage_PNG);
		//pImage->dumpImage(0, 0);
		//DumpImage(pImage->getDib(), pImage->cx(), 0);
		/*
		BFile file;
		BString strSrcFile = CUtil::UTF8ToBString((char*)"d:/test.dat");
		if ( file.Open(strSrcFile, "w+") )
		{
		file.Write(pImage->getDataSize(), pImage->getData());
		file.Close();
		}
		*/
		//////////////////////////////////////////////////////////
		if(sXimage.buffer)
		{
			XRect xRect = {(float)pPageRect->left, (float)pPageRect->top, (float)pPageRect->right, (float)pPageRect->bottom};
			//sXimage.format = eXIMAGE_JPEG;
			sXimage.length = nJPEGSize;
			sXimage.width = pImage->cx();
			sXimage.height = pImage->cy();
			//if(nSaveFormat == eImage_PNG)
			sXimage.angle = -nRoateAngle;

			nErr = m_pGenerator->AddImage(&sXimage, &xRect);
			BrFree(sXimage.buffer);
			if(nErr == errNone)
				return BrTRUE;
		}
#endif //
	}
	return BrFALSE;
}

void BPDFExport::setCIDInfo(BrBYTE nType, BrXPDFFontInfo* pFontInfo)
{
	if(nType > eNoneCTFontClass && nType <= eUCSCTFontClass)
	{
		pFontInfo->pCIDSystemInfo = &m_sCIDInfo;
		memset(m_sCIDInfo.szRegistry, 0, sizeof(m_sCIDInfo.szRegistry));
		strncpy_s(m_sCIDInfo.szRegistry, sizeof(m_sCIDInfo.szRegistry), "Adobe", strlen("Adobe"));
		m_sCIDInfo.nSupplement = 2;
		switch(nType)
		{
		case eGB1CTFontClass:
			memset(m_sCIDInfo.szOrdering, 0, sizeof(m_sCIDInfo.szOrdering));
			strncpy_s(m_sCIDInfo.szOrdering, sizeof(m_sCIDInfo.szOrdering), "GB1", strlen("GB1"));
			memset(pFontInfo->szEncoding, 0, sizeof(pFontInfo->szEncoding));
			strncpy_s(pFontInfo->szEncoding, sizeof(pFontInfo->szEncoding), "UniGB-UTF16-H", strlen("UniGB-UTF16-H"));
			m_sCIDInfo.nSupplement = 4;
			break;
		case eCNS1CTFontClass:
			memset(m_sCIDInfo.szOrdering, 0, sizeof(m_sCIDInfo.szOrdering));
			strncpy_s(m_sCIDInfo.szOrdering, sizeof(m_sCIDInfo.szOrdering), "CNS1", strlen("CNS1"));
			memset(pFontInfo->szEncoding, 0, sizeof(pFontInfo->szEncoding));
			strncpy_s(pFontInfo->szEncoding, sizeof(pFontInfo->szEncoding), "UniCNS-UTF16-H", strlen("UniCNS-UTF16-H"));
			m_sCIDInfo.nSupplement = 2;
			break;
		case eJapan1CTFontClass:
			memset(m_sCIDInfo.szOrdering, 0, sizeof(m_sCIDInfo.szOrdering));
			strncpy_s(m_sCIDInfo.szOrdering, sizeof(m_sCIDInfo.szOrdering), "Japan1", strlen("Japan1"));
			memset(pFontInfo->szEncoding, 0, sizeof(pFontInfo->szEncoding));
			strncpy_s(pFontInfo->szEncoding, sizeof(pFontInfo->szEncoding), "UniJIS-UTF16-H", strlen("UniJIS-UTF16-H"));
			m_sCIDInfo.nSupplement = 5;				
			break;
		case eJapan2CTFontClass:
			memset(m_sCIDInfo.szOrdering, 0, sizeof(m_sCIDInfo.szOrdering));
			strncpy_s(m_sCIDInfo.szOrdering, sizeof(m_sCIDInfo.szOrdering), "Japan2", strlen("Japan2"));
			//				BrStrCpy(pFontInfo->szEncoding, "UniCNS-UTF16-H", 256);
			m_sCIDInfo.nSupplement = 5;
			break;
		case eKorea1CTFontClass:
			memset(m_sCIDInfo.szOrdering, 0, sizeof(m_sCIDInfo.szOrdering));
			strncpy_s(m_sCIDInfo.szOrdering, sizeof(m_sCIDInfo.szOrdering), "Korea1", strlen("Korea1"));
			memset(pFontInfo->szEncoding, 0, sizeof(pFontInfo->szEncoding));
			strncpy_s(pFontInfo->szEncoding, sizeof(pFontInfo->szEncoding), "UniKS-UTF16-H", strlen("UniKS-UTF16-H"));
			break;
		case eKorea2CTFontClass:
			memset(m_sCIDInfo.szOrdering, 0, sizeof(m_sCIDInfo.szOrdering));
			strncpy_s(m_sCIDInfo.szOrdering, sizeof(m_sCIDInfo.szOrdering), "Korea1", strlen("Korea1"));
			memset(pFontInfo->szEncoding, 0, sizeof(pFontInfo->szEncoding));
			strncpy_s(pFontInfo->szEncoding, sizeof(pFontInfo->szEncoding), "UniKS-UCS2-H", strlen("UniKS-UCS2-H"));
			break;
		case eUCSCTFontClass:
			memset(m_sCIDInfo.szOrdering, 0, sizeof(m_sCIDInfo.szOrdering));
			strncpy_s(m_sCIDInfo.szOrdering, sizeof(m_sCIDInfo.szOrdering), "Identity", strlen("Identity"));
			memset(pFontInfo->szEncoding, 0, sizeof(pFontInfo->szEncoding));
			strncpy_s(pFontInfo->szEncoding, sizeof(pFontInfo->szEncoding), "Identity-H", strlen("Identity-H"));
			m_sCIDInfo.nSupplement = 0;
			break;

		}	
	}
	else
	{
		pFontInfo->pCIDSystemInfo = &m_sCIDInfo;
		memset(m_sCIDInfo.szRegistry, 0, sizeof(m_sCIDInfo.szRegistry));
		strncpy_s(m_sCIDInfo.szRegistry, sizeof(m_sCIDInfo.szRegistry), "Adobe", strlen("Adobe"));
		//[14.05.28][sglee1206] ������ ���� �Է���... ������ �� ���� �ʿ�
		memset(m_sCIDInfo.szOrdering, 0, sizeof(m_sCIDInfo.szOrdering));
		strncpy_s(m_sCIDInfo.szOrdering, sizeof(m_sCIDInfo.szOrdering), "Identity", strlen("Identity"));
		memset(pFontInfo->szEncoding, 0, sizeof(pFontInfo->szEncoding));
		strncpy_s(pFontInfo->szEncoding, sizeof(pFontInfo->szEncoding), "Identity-H", strlen("Identity-H"));
		m_sCIDInfo.nSupplement = 2;
	}
}

void BPDFExport::makeFaceName(BrCHAR* pFaceName, int pFaceNameSize, BrINT nFlag, BrCHAR* pPrefix, BrCHAR* pBItalic, BrCHAR* pBold, BrCHAR* pItalic, BrCHAR* pOrgFace)
{
	if(BR_ISSET_STATE(nFlag, (eForceBoldCTFontBOpt| eItalicCTFontBOpt)))
		_snprintf_s(pFaceName, pFaceNameSize, pFaceNameSize-1, "%s%s", pPrefix, pBItalic);
	else if(BR_ISSET_STATE(nFlag, eForceBoldCTFontBOpt))
		_snprintf_s(pFaceName, pFaceNameSize, pFaceNameSize-1, "%s%s", pPrefix, pBold);
	else if(BR_ISSET_STATE(nFlag, eItalicCTFontBOpt))
		_snprintf_s(pFaceName, pFaceNameSize, pFaceNameSize-1, "%s%s", pPrefix, pItalic);
	else 
		_snprintf_s(pFaceName, pFaceNameSize, pFaceNameSize-1, "%s", pOrgFace);
}

void BPDFExport::setFontDescriptorFlag(BrBOOL* pBold, BrBOOL* pItalic, BrBOOL* pStroke)
{
	BrBYTE nOldFlag = m_nFDFlag;
	if(pBold)
	{
		if(*pBold)
			BR_SET_STATE(m_nFDFlag, eBold_PDFFDFlag);
		else
			BR_REL_STATE(m_nFDFlag, eBold_PDFFDFlag);
	}
	if(pItalic)
	{
		if(*pItalic)
			BR_SET_STATE(m_nFDFlag, eItalic_PDFFDFlag);
		else
			BR_REL_STATE(m_nFDFlag, eItalic_PDFFDFlag);
	}
	if(pStroke)
	{
		if(*pStroke)
			BR_SET_STATE(m_nFDFlag, eStroke_PDFFPFlag);
		else
			BR_REL_STATE(m_nFDFlag, eStroke_PDFFPFlag);
	}

	if(nOldFlag != m_nFDFlag)
	{
		addRegText();
		updateFontDescriptorFlag();
		if(BR_ISSET_STATE(m_nState, eDefaultFont_PDFExtState))
			BR_SET_STATE(m_nState, eUpdateFlag_PDFExtState);
	}
}

void BPDFExport::updateDefFontDescriptorFlag()
{
	if(m_nCTFontIndex != SymbolCTFont)
	{
		BrINT nOldFlag = m_sFontInfo.nFlags;
		BrBOOL bSetRegBold = BR_ISSET_STATE(m_nFDFlag, eBold_PDFFDFlag);
		BrBOOL bSetRegItalic = BR_ISSET_STATE(m_nFDFlag, eItalic_PDFFDFlag); 

		if(bSetRegBold != BR_ISSET_STATE(m_sFontInfo.nFlags, eForceBoldCTFontBOpt))
		{
			if(bSetRegBold)
				BR_SET_STATE(m_sFontInfo.nFlags, eForceBoldCTFontBOpt);
			else
				BR_REL_STATE(m_sFontInfo.nFlags, eForceBoldCTFontBOpt);
		}

		if(bSetRegItalic != BR_ISSET_STATE(m_sFontInfo.nFlags, eItalicCTFontBOpt)) 
		{
			if(bSetRegItalic)
			{
				BR_SET_STATE(m_sFontInfo.nFlags, eItalicCTFontBOpt);
				m_sFontInfo.nAngle = -15;
			}
			else
			{
				BR_REL_STATE(m_sFontInfo.nFlags, eItalicCTFontBOpt);
				m_sFontInfo.nAngle = 0;
			}
		}

		if(nOldFlag != m_sFontInfo.nFlags)
		{
			LPBrCTFontAtts pFontAtt = (LPBrCTFontAtts)&arrFontCTAtts[m_nCTFontIndex];

			if(m_nCTFontIndex == eTimesNewRomanCTFont)
			{
				makeFaceName(m_sFontInfo.szFaceName, sizeof(m_sFontInfo.szFaceName), m_sFontInfo.nFlags, CTCIDFONT_TIMES_PREFIX, CTFONT_BITALIC_SUFFIX, CTFONT_BOLD_SUFFIX,
					CTFONT_ITALIC_SUFFIX, pFontAtt->sFace);
				/*			
				if(BR_ISSET_STATE(m_sFontInfo.nFlags, (eForceBoldCTFontBOpt| eItalicCTFontBOpt)))
				sprintf(m_sFontInfo.szFaceName, "Times%s", CTFONT_BITALIC_SUFFIX);
				else if(BR_ISSET_STATE(m_sFontInfo.nFlags, eForceBoldCTFontBOpt))
				sprintf(m_sFontInfo.szFaceName, "Times%s", CTFONT_BOLD_SUFFIX);
				else if(BR_ISSET_STATE(m_sFontInfo.nFlags, eItalicCTFontBOpt))
				sprintf(m_sFontInfo.szFaceName, "Times%s", CTFONT_ITALIC_SUFFIX);
				else 
				sprintf(m_sFontInfo.szFaceName, "%s", pFontAtt->sFace);			
				*/					
			}				
			else
			{
				makeFaceName(m_sFontInfo.szFaceName, sizeof(m_sFontInfo.szFaceName), m_sFontInfo.nFlags, pFontAtt->sFace, CTDEFFONT_BITALIC_SUFFIX, CTDEFFONT_BOLD_SUFFIX,
					CTDEFFONT_ITALIC_SUFFIX, pFontAtt->sFace);			
				/*				
				if(BR_ISSET_STATE(m_sFontInfo.nFlags, (eForceBoldCTFontBOpt| eItalicCTFontBOpt)))
				sprintf(m_sFontInfo.szFaceName, "%s%s", pFontAtt->sFace, CTDEFFONT_BITALIC_SUFFIX);
				else if(BR_ISSET_STATE(m_sFontInfo.nFlags, eForceBoldCTFontBOpt))
				sprintf(m_sFontInfo.szFaceName, "%s%s", pFontAtt->sFace, CTDEFFONT_BOLD_SUFFIX);
				else if(BR_ISSET_STATE(m_sFontInfo.nFlags, eItalicCTFontBOpt))
				sprintf(m_sFontInfo.szFaceName, "%s%s", pFontAtt->sFace, CTDEFFONT_ITALIC_SUFFIX);
				else 
				sprintf(m_sFontInfo.szFaceName, "%s", pFontAtt->sFace);
				*/					
			}			
		}

		if(m_nDefCIDFontIndex != -1 || BR_ISSET_STATE(m_nState, eNeedCIDFont_PDFExtState))
			BR_SET_STATE(m_nState, (eUpdateFont_PDFExtState | eUpdateDefCIDFlag_PDFExtState));
		else
			BR_SET_STATE(m_nState, eUpdateFont_PDFExtState);
	}

	BR_REL_STATE(m_nState, eUpdateFlag_PDFExtState);	
}

BrBOOL BPDFExport::updateFontDescriptorFlag(BrXPDFFontInfo* pFontInfo, BrINT nIndex)
{	
	BrINT nOldFlag = pFontInfo->nFlags;
	BrBOOL bSetRegBold = BR_ISSET_STATE(m_nFDFlag, eBold_PDFFDFlag);
	BrBOOL bSetRegItalic = BR_ISSET_STATE(m_nFDFlag, eItalic_PDFFDFlag); 

	if(bSetRegBold != BR_ISSET_STATE(pFontInfo->nFlags, eForceBoldCTFontBOpt))
	{
		if(bSetRegBold)
			BR_SET_STATE(pFontInfo->nFlags, eForceBoldCTFontBOpt);
		else
			BR_REL_STATE(pFontInfo->nFlags, eForceBoldCTFontBOpt);
	}

	if(bSetRegItalic != BR_ISSET_STATE(pFontInfo->nFlags, eItalicCTFontBOpt)) 
	{
		if(bSetRegItalic)
		{
			BR_SET_STATE(pFontInfo->nFlags, eItalicCTFontBOpt);
			pFontInfo->nAngle = -15;
		}
		else
		{
			BR_REL_STATE(pFontInfo->nFlags, eItalicCTFontBOpt);
			pFontInfo->nAngle = 0;
		}
	}

	if(nOldFlag != pFontInfo->nFlags)
	{
		LPBrCTFontAtts pFontAtt = (LPBrCTFontAtts)&arrFontCTAtts[nIndex];

		if(nIndex <= MAX_DEF_CTFONT_INDEX)
		{
			if(nIndex == eTimesNewRomanCTFont)
			{
				makeFaceName(pFontInfo->szFaceName, sizeof(pFontInfo->szFaceName), pFontInfo->nFlags, CTCIDFONT_TIMES_PREFIX, CTFONT_BITALIC_SUFFIX, CTFONT_BOLD_SUFFIX,
					CTFONT_ITALIC_SUFFIX, pFontAtt->sFace);						
				/*				
				if(BR_ISSET_STATE(pFontInfo->nFlags, (eForceBoldCTFontBOpt| eItalicCTFontBOpt)))
				sprintf(pFontInfo->szFaceName, "Times%s", CTFONT_BITALIC_SUFFIX);
				else if(BR_ISSET_STATE(pFontInfo->nFlags, eForceBoldCTFontBOpt))
				sprintf(pFontInfo->szFaceName, "Times%s", CTFONT_BOLD_SUFFIX);
				else if(BR_ISSET_STATE(pFontInfo->nFlags, eItalicCTFontBOpt))
				sprintf(pFontInfo->szFaceName, "Times%s", CTFONT_ITALIC_SUFFIX);
				else 
				sprintf(pFontInfo->szFaceName, "%s", pFontAtt->sFace);			
				*/					
			}				
			else
			{
				makeFaceName(pFontInfo->szFaceName, sizeof(pFontInfo->szFaceName), pFontInfo->nFlags, pFontAtt->sFace, CTDEFFONT_BITALIC_SUFFIX, CTDEFFONT_BOLD_SUFFIX,
					CTDEFFONT_ITALIC_SUFFIX, pFontAtt->sFace);			
				/*				
				if(BR_ISSET_STATE(pFontInfo->nFlags, (eForceBoldCTFontBOpt| eItalicCTFontBOpt)))
				sprintf(pFontInfo->szFaceName, "%s%s", pFontAtt->sFace, CTDEFFONT_BITALIC_SUFFIX);
				else if(BR_ISSET_STATE(pFontInfo->nFlags, eForceBoldCTFontBOpt))
				sprintf(pFontInfo->szFaceName, "%s%s", pFontAtt->sFace, CTDEFFONT_BOLD_SUFFIX);
				else if(BR_ISSET_STATE(pFontInfo->nFlags, eItalicCTFontBOpt))
				sprintf(pFontInfo->szFaceName, "%s%s", pFontAtt->sFace, CTDEFFONT_ITALIC_SUFFIX);
				else 
				sprintf(pFontInfo->szFaceName, "%s", pFontAtt->sFace);
				*/					
			}		
		}
#if 0		
		if(nIndex < CIDFONT_INDEX_BEGIN)
		{
			if(BR_ISSET_STATE(pFontInfo->nFlags, (eForceBoldCTFontBOpt| eItalicCTFontBOpt)))
				sprintf(pFontInfo->szFaceName, "%s%s", pFontAtt->sFace, CTFONT_BITALIC_SUFFIX);
			else if(BR_ISSET_STATE(pFontInfo->nFlags, eForceBoldCTFontBOpt))
				sprintf(pFontInfo->szFaceName, "%s%s", pFontAtt->sFace, CTFONT_BOLD_SUFFIX);
			else if(BR_ISSET_STATE(pFontInfo->nFlags, eItalicCTFontBOpt))
				sprintf(pFontInfo->szFaceName, "%s%s", pFontAtt->sFace, CTFONT_ITALIC_SUFFIX);
			else 
				sprintf(pFontInfo->szFaceName, "%s", pFontAtt->sFace);
		}		
#endif //0
		else
		{
			makeFaceName(pFontInfo->szFaceName, sizeof(pFontInfo->szFaceName), pFontInfo->nFlags, pFontAtt->sFace, CTCIDFONT_BITALIC_SUFFIX, CTCIDFONT_BOLD_SUFFIX,
				CTCIDFONT_ITALIC_SUFFIX, pFontAtt->sFace);		
			/*			
			if(BR_ISSET_STATE(pFontInfo->nFlags, (eForceBoldCTFontBOpt| eItalicCTFontBOpt)))
			sprintf(pFontInfo->szFaceName, "%s%s", pFontAtt->sFace, CTCIDFONT_BITALIC_SUFFIX);
			else if(BR_ISSET_STATE(pFontInfo->nFlags, eForceBoldCTFontBOpt))
			sprintf(pFontInfo->szFaceName, "%s%s", pFontAtt->sFace, CTCIDFONT_BOLD_SUFFIX);
			else if(BR_ISSET_STATE(pFontInfo->nFlags, eItalicCTFontBOpt))
			sprintf(pFontInfo->szFaceName, "%s%s", pFontAtt->sFace, CTCIDFONT_ITALIC_SUFFIX);
			else 
			sprintf(pFontInfo->szFaceName, "%s", pFontAtt->sFace);
			*/				
		}
		return BrTRUE;		
	}
	return BrFALSE;	
}

void BPDFExport::updateFontDescriptorFlag()
{	
	if(m_nCTFontIndex <= MAX_DEF_CTFONT_INDEX)
		updateDefFontDescriptorFlag();
	else
	{
		if(updateFontDescriptorFlag(&m_sFontInfo, m_nCTFontIndex))
		{			
			if(m_nDefCIDFontIndex != -1 || BR_ISSET_STATE(m_nState, eNeedCIDFont_PDFExtState))
				BR_SET_STATE(m_nState, (eUpdateFont_PDFExtState | eUpdateDefCIDFlag_PDFExtState));
			else
				BR_SET_STATE(m_nState, eUpdateFont_PDFExtState);				
		}
		BR_REL_STATE(m_nState, eUpdateFlag_PDFExtState);		
	}	
}

BrBOOL BPDFExport::updateDefCIDFontDescriptorFlag()
{
	BrBOOL bRet = BrTRUE;
	if(m_nDefCIDFontIndex != -1 && BR_ISSET_STATE(m_nState, eUpdateDefCIDFlag_PDFExtState))
	{
		bRet = updateFontDescriptorFlag(&m_sDefCIDFontInfo, m_nDefCIDFontIndex);
		BR_REL_STATE(m_nState, eUpdateDefCIDFlag_PDFExtState);		
	}
	return bRet;
}

void BPDFExport::setFontInfo(BrINT nFontIndex, BrXPDFFontInfo* pFontInfo)
{
	LPBrCTFontAtts pFontAtt = (LPBrCTFontAtts)&arrFontCTAtts[nFontIndex];
	memset(pFontInfo, 0, BrSizeOf(*pFontInfo));
	strncpy_s(pFontInfo->szFaceName, sizeof(pFontInfo->szFaceName), pFontAtt->sFace, strlen(pFontAtt->sFace));

	if(nFontIndex > MAX_DEF_CTFONT_INDEX)
	{
		pFontInfo->sBBox.left = pFontAtt->sBBox.left;
		pFontInfo->sBBox.top = pFontAtt->sBBox.top;
		pFontInfo->sBBox.right = pFontAtt->sBBox.right;
		pFontInfo->sBBox.bottom = pFontAtt->sBBox.bottom;
		pFontInfo->nFlags = pFontAtt->nFlags;
		pFontInfo->nAscent = pFontAtt->nAscent;
		pFontInfo->nDescent = pFontAtt->nDescent;
		pFontInfo->nAngle = pFontAtt->nAngle;	
		pFontInfo->nCapHeight = pFontAtt->nCapHeight;
		pFontInfo->nStemV = pFontAtt->nStemV;
		pFontInfo->sCodeTable.nLen = pFontAtt->nCWidthLen;

		if(nFontIndex >= CIDFONT_INDEX_BEGIN)
		{
			//strcpy(pFontInfo->szEncoding, "WinAnsiEncoding");	

			pFontInfo->nType = eXPDFCIDFontType2;
			setCIDInfo(pFontAtt->nCIDCType, pFontInfo);
			pFontInfo->sCodeTable.nDefWidth = pFontAtt->nCWDefWidth;
			pFontInfo->sCodeTable.pData = pFontAtt->pCWidths;	
			if((pFontInfo->sCodeTable.pData && pFontAtt->nCWidthLen == BASE_CIDCWIDTHS_LEN) 
				|| (pFontAtt->nCWidthLen == 0 && pFontAtt->nCWDefWidth))
			{
				pFontInfo->sCodeTable.nFirstCode = BASE_FIRTST_CIDCODE;
				pFontInfo->sCodeTable.nLastCode = BASE_LAST_CIDCODE;
			}			
		}
		else
		{
			BrINT i;
			BrUINT16* pCTTable = BrNULL;

			strncpy_s(pFontInfo->szEncoding, sizeof(pFontInfo->szEncoding), "WinAnsiEncoding", strlen("WinAnsiEncoding"));
			pFontInfo->nType = eXPDFFontTrueType;
			pFontInfo->sCodeTable.nFirstCode = BASE_FIRTST_CODE;
			pFontInfo->sCodeTable.nLastCode = BASE_LAST_CODE;

			if(pFontAtt->nCWDefIndex != -1)
			{
				pFontInfo->sCodeTable.pData = m_sCTTable;
				if(pFontAtt->pCWidths)
					memcpy(m_sCTTable, pFontAtt->pCWidths, pFontAtt->nCWDefIndex*(BrSizeOf(BrUINT16)));

				pCTTable = m_sCTTable+pFontAtt->nCWDefIndex;

				for(i = pFontAtt->nCWDefIndex; i < pFontAtt->nCWidthLen -1; i++)
					*pCTTable++ = pFontAtt->nCWDefWidth;
				*pCTTable = pFontAtt->nCWLastWidth;
			}
			else
				pFontInfo->sCodeTable.pData = pFontAtt->pCWidths;			
		}
	}
	else
	{
		strncpy_s(pFontInfo->szEncoding, sizeof(pFontInfo->szEncoding), "WinAnsiEncoding", strlen("WinAnsiEncoding"));
		pFontInfo->sBBox.left = pFontAtt->sBBox.left;
		pFontInfo->sBBox.top = pFontAtt->sBBox.top;
		pFontInfo->sBBox.right = pFontAtt->sBBox.right;
		pFontInfo->sBBox.bottom = pFontAtt->sBBox.bottom;
		pFontInfo->nFlags = pFontAtt->nFlags;
		pFontInfo->nAscent = pFontAtt->nAscent;
		pFontInfo->nDescent = pFontAtt->nDescent;
		pFontInfo->nAngle = pFontAtt->nAngle;	
		pFontInfo->nCapHeight = pFontAtt->nCapHeight;
		pFontInfo->nStemV = pFontAtt->nStemV;
		pFontInfo->nType = eXPDFFontTrueType;
	}

}

void BPDFExport::setFontInfo(BrINT nFontIndex, BrBOOL bInit)
{
	LPBrCTFontAtts pFontAtt = BrNULL;

	addRegText();
	m_nCTFontIndex = nFontIndex;
	clearDefCIDFont();
	clearRegCodeTable();

	if(ISNEED_DEFCIDFONT(m_nCTFontIndex))
		BR_SET_STATE(m_nState, eNeedCIDFont_PDFExtState);

	setFontInfo(nFontIndex, &m_sFontInfo);

	if(bInit)
	{
		m_nFDFlag = eNone_PDFFDFlag;
		BR_REL_STATE(m_nState, eUpdateFlag_PDFExtState);
	}
	else if(m_nFDFlag != eNone_PDFFDFlag)
	{
		BR_SET_STATE(m_nState, eUpdateFlag_PDFExtState);
	}

	if(BR_ISSET_STATE(m_nState, eUpdateFlag_PDFExtState))
		updateFontDescriptorFlag();

	BR_REL_STATE(m_nState, eDefaultFont_PDFExtState);
	BR_SET_STATE(m_nState, eUpdateFont_PDFExtState);
}

void BPDFExport::updateFontInfo(BrBOOL bInit)
{
	BrINT nIndex = getCTFontIndex();

	if(bInit || m_nCTFontIndex != nIndex )
		setFontInfo(nIndex, bInit);
}

BrINT BPDFExport::getCTFontIndex()
{
	BrINT nIndex = eTimesNewRomanCTFont;
	BrUSHORT cNCode = BrToLower(m_sFontFace[0]);

	m_nOregFontIndex = eNoneOREGCTFont;

	switch(cNCode)
	{
	case 0x61:
		if(m_nFontFaceLen == 5)
		{
			BrUSHORT wArial[] = {0x72,0x69,0x61,0x6C,0x00};		//Arial
			if(CUtil::WcsICmp(m_sFontFace+1, wArial) == 0)
				nIndex = eArialCTFont;
		}
		else if(m_nFontFaceLen == 12)
		{
			BrUSHORT wArialNarrow[] = {0x72,0x69,0x61,0x6C, 0x20, 0x6e, 0x61, 0x72, 0x72, 0x6f, 0x77, 0x00};		//Arial Narrow
			if(CUtil::WcsICmp(m_sFontFace+1, wArialNarrow) == 0)
				nIndex = eArialNarrowCTFont;
		}
		else if(m_nFontFaceLen == 16)
		{
			BrUSHORT wLocalFont[] = { 0x72, 0x69, 0x61, 0x6c, 0x20, 0x75, 0x6e, 0x69, 0x63, 0x6f, 0x64, 0x65, 0x20, 0x6d, 0x73, 0x00 };	//Arial Unicode MS
			if(CUtil::WcsICmp(m_sFontFace+1, wLocalFont) == 0)
				nIndex = eArialUnicodeMSCTFont;
		}
		break;
	case 0x62:
		if(m_nFontFaceLen == 6)
		{
			if(m_sFontFace[1] == 0x61)
			{
				BrUSHORT wBatang[] = {0x61, 0x74, 0x61, 0x6E, 0x67, 0x00};		//Batang
				if(CUtil::WcsICmp(m_sFontFace+1, wBatang) == 0)
					nIndex = eBatangCTFont;
			}
		}
		break;
	case 0x63:
		if(m_nFontFaceLen == 7)
		{
			//[2012.10.12][ekaloss] Calibri ��Ʈ�� setFont ������ ��� �ÿ��� �ش� ��Ʈ�� ��� ���� �ʴ� ���� ����. 
			BrUSHORT wCourier[] = {0x6F,0x75,0x72,0x69,0x65,0x72,0x00};//Courier 
			BrUSHORT wCalibri[] = {0x6c, 0x69, 0x62, 0x72, 0x69, 0x00};  //Calibri

			if(CUtil::WcsICmp(m_sFontFace+1, wCourier) == 0)
				nIndex= eCourierCTFont;
			else if(CUtil::WcsICmp(m_sFontFace+2, wCalibri) == 0)
				nIndex= eCalibriCTFont;

		}
		else if(m_nFontFaceLen == 11)
		{
			BrUSHORT wCourierNew[] = {0x6F,0x75,0x72,0x69,0x65,0x72,0x20,0x6E,0x65,0x77,0x00};//Courier New
			if(CUtil::WcsICmp(m_sFontFace+1, wCourierNew) == 0)
				nIndex= eCourierCTFont;
		}

		else if(m_nFontFaceLen == 13)
		{
			BrUSHORT wComicSansMS[] = {0x6f, 0x6d, 0x69, 0x63, 0x20, 0x73, 0x61, 0x6e, 0x73, 0x20, 0x6d, 0x73, 0x00};  //Comic Sans MS
			if(CUtil::WcsICmp(m_sFontFace+1, wComicSansMS) == 0)
				nIndex= eComicSansMSCTFont;
		}			
		break;			
	case 0x64:
		if(m_nFontFaceLen == 5)
		{	
			BrUSHORT wDotum[] = {0x6F, 0x74, 0x75, 0x6D, 0x00};  //Dutom
			if(CUtil::WcsICmp(m_sFontFace+1, wDotum) == 0)
				nIndex = eDotumCTFont;		
		}
		break;
	case 0x67:
		if(m_nFontFaceLen == 5)
		{
			BrUSHORT wGulim[] = {0x75, 0x6C, 0x69, 0x6D, 0x00};		//Gulim
			if(CUtil::WcsICmp(m_sFontFace+1, wGulim) == 0)
				nIndex = eGulimCTFont;		
		}
		else if(m_nFontFaceLen == 8)
		{
			BrUSHORT wGaramond[] = {0x61, 0x72, 0x61, 0x6D, 0x6F, 0x6E, 0x64, 0x00};		//Garamond
			if(CUtil::WcsICmp(m_sFontFace+1, wGaramond) == 0)
				nIndex = eGaramondCTFont;
		}
		else if(m_nFontFaceLen == 7)
		{
			BrUSHORT wGeorgia[] = {0x65, 0x6f, 0x72, 0x67, 0x69, 0x61, 0x00};		//Georgia
			if(CUtil::WcsICmp(m_sFontFace+1, wGeorgia) == 0)
				nIndex = eGeorgiaCTFont;				
		}			
		break;
	case 0x68:
		if(m_nFontFaceLen == 8)
		{
			BrUSHORT wSymbol[] = {0x59, 0x53, 0x79, 0x6d, 0x62, 0x6f, 0x6c ,0x00};		//HYSymbol
			if(CUtil::WcsICmp(m_sFontFace+1, wSymbol) == 0)
			{
				nIndex = SymbolCTFont;					
			}
		}
		else if(m_nFontFaceLen == 10)
		{
			BrUSHORT wWingding[] = {0x59, 0x77, 0x69, 0x6e, 0x67, 0x64, 0x69, 0x6e, 0x67, 0x00};		//HYWingding
			BrUSHORT wWebding[] = {0x59, 0x77, 0x65, 0x62, 0x64, 0x69, 0x6e, 0x67, 0x73, 0x00};			//HYWebdings
			if(CUtil::WcsICmp(m_sFontFace+1, wWingding) == 0)
			{
				nIndex = eWingdingsCTFont;					
			}
			else if(CUtil::WcsICmp(m_sFontFace+1, wWebding) == 0)
				nIndex = eWebdingsCTFont;
		}
		else if( m_nFontFaceLen == 11)
		{

			cNCode = BrToLower(m_sFontFace[10]);
			if(cNCode == 0x32)
			{
				BrUSHORT wWingding2[] = {0x59, 0x77, 0x69, 0x6e, 0x67, 0x64, 0x69, 0x6e, 0x67, 0x32, 0x00};  //HYWingding2
				if(CUtil::WcsICmp(m_sFontFace+1, wWingding2) == 0)
				{
					m_nOregFontIndex = eWingdings2OREGCTFont;
					nIndex = eWingdingsCTFont;
				}						
			}
			else if(cNCode == 0x33)
			{
				BrUSHORT wWingding3[] = {0x59, 0x77, 0x69, 0x6e, 0x67, 0x64, 0x69, 0x6e, 0x67, 0x33, 0x00};  //HYWingding3
				if(CUtil::WcsICmp(m_sFontFace+1, wWingding3) == 0)
				{
					m_nOregFontIndex = eWingdings3OREGCTFont;
					nIndex = eWingdingsCTFont;
				}						
			}
		}
		break;
	case 0x6C:
		if(m_nFontFaceLen == 11)
		{
			BrUSHORT wLusidaSans[] = {0x75, 0x63, 0x69, 0x64, 0x61, 0x20, 0x73, 0x61, 0x6e, 0x73, 0x00};  //Lusida Sans
			if(CUtil::WcsICmp(m_sFontFace+1, wLusidaSans) == 0)
				nIndex = eLucidaSansCTFont;
		}
		else if( m_nFontFaceLen == 19 )
		{
			BrUSHORT wLucidaSansUnicode[] = {0x75, 0x63, 0x69, 0x64, 0x61, 0x20, 0x73, 0x61, 0x6e, 0x73, 0x20, 0x75, 0x6e, 0x69, 0x63, 0x6f, 0x64, 0x65, 0x00};		//Lucida Sans Unicode
			if(CUtil::WcsICmp(m_sFontFace+1, wLucidaSansUnicode) == 0)
				nIndex = eLucidaSansUnicodeCTFont;				
		}
		break;					
	case 0x6d:
		if(m_nFontFaceLen == 7)
		{
			BrUSHORT wMingLiU[] = {0x69, 0x6E, 0x67, 0x6C, 0x69, 0x75, 0x00};		//MingLiU
			if(CUtil::WcsICmp(m_sFontFace+1, wMingLiU) == 0)
				nIndex = eMingLiUCTFont;				
		}
		else if(m_nFontFaceLen == 10)
		{
			cNCode = BrToLower(m_sFontFace[4]);
			if(cNCode == 0x67)
			{
				BrUSHORT wMSPGothic[] = {0x73, 0x20, 0x70, 0x67, 0x6f, 0x74, 0x68, 0x69, 0x63, 0x00};	//MS PGothic					
				if(CUtil::WcsICmp(m_sFontFace+1, wMSPGothic) == 0)
					nIndex = eMSPGothicCTFont;									
			}
		}
		else if(m_nFontFaceLen == 11)
		{
			BrUSHORT wMotoyaLMaru[] = {0x6f, 0x74, 0x6f, 0x79, 0x61, 0x6c, 0x6d, 0x61, 0x72, 0x75, 0x00};	//MotoyaLMaru
			if(CUtil::WcsICmp(m_sFontFace+1, wMotoyaLMaru) == 0)
				nIndex = eMotoyaLMaruCTFont;
		}
		break;
	case 0x70: 				
		if(m_nFontFaceLen == 8)					
		{
			BrUSHORT wPalatino[] = {0x61, 0x6c, 0x61, 0x74, 0x69, 0x6e, 0x6f, 0x00};		//Palatino
			if(CUtil::WcsICmp(m_sFontFace+1, wPalatino) == 0)
				nIndex = eArialNarrowCTFont;
		}
		else if(m_nFontFaceLen == 17)					
		{
			BrUSHORT wPalatino[] = {0x61,0x6c, 0x61, 0x74, 0x69, 0x6e, 0x6f, 0x20, 0x6c, 0x69, 0x6e, 0x6f, 0x74, 0x79, 0x70, 0x65, 0x00};		//Palatino Linotype
			if(CUtil::WcsICmp(m_sFontFace+1, wPalatino) == 0)
				nIndex = eArialNarrowCTFont;
		}
		break;
	case 0x73:
		if(m_nFontFaceLen == 6 )
		{
			BrUSHORT wSimSun[] = {0x69, 0x6d, 0x73, 0x75, 0x6e ,0x00};		//SimSun
			BrUSHORT wSymbol[] = {0x79, 0x6d, 0x62, 0x6f, 0x6c ,0x00};		//Symbol
			if(CUtil::WcsICmp(m_sFontFace+1, wSimSun) == 0)
				nIndex = eSimSunCTFont;
			else if(CUtil::WcsICmp(m_sFontFace+1, wSymbol) == 0)
				nIndex = SymbolCTFont;
		}
		break;			
	case 0x74:
		if(m_nFontFaceLen == 15)		
		{
			BrUSHORT wTimesNewRoman[] = {0x69,0x6D,0x65,0x73,0x20,0x6E,0x65,0x77,0x20,0x72,0x6F,0x6D,0x61,0x6E,0x00};	//Times New Roman
			if(CUtil::WcsICmp(m_sFontFace+1, wTimesNewRoman) == 0)
				nIndex = eTimesNewRomanCTFont;
		}
		else if(m_nFontFaceLen == 6)
		{
			BrUSHORT wTahoma[] = {0x61,0x68,0x6F,0x6D,0x61,0x00};	//Tahoma
			if(CUtil::WcsICmp(m_sFontFace+1, wTahoma) == 0)
				nIndex = eTahomaCTFont;
		}
		break;	
	case 0x76:
		if(m_nFontFaceLen == 7)
		{
			BrUSHORT wVerdana[] = {0x65,0x72,0x64,0x61,0x6E,0x61,0x00};		//Verdana
			if(CUtil::WcsICmp(m_sFontFace+1, wVerdana) == 0)
				nIndex = eVerdanaCTFont;
		}
		break;	
	case 0x77:
		if(m_nFontFaceLen == 9)
		{
			BrUSHORT wWingding[] = {0x69, 0x6e, 0x67, 0x64, 0x69, 0x6e, 0x67, 0x73, 0x00};		//Wingdings
			if(CUtil::WcsICmp(m_sFontFace+1, wWingding) == 0)
			{
				nIndex = eWingdingsCTFont;					
			}
		}
		else if( m_nFontFaceLen == 8 )
		{
			BrUSHORT wWebding[] = {0x65, 0x62, 0x64, 0x69, 0x6e, 0x67, 0x73, 0x00};		//Webdings
			if(CUtil::WcsICmp(m_sFontFace+1, wWebding) == 0)
				nIndex = eWebdingsCTFont;
		}
		else if( m_nFontFaceLen == 11)
		{

			cNCode = BrToLower(m_sFontFace[10]);
			if(cNCode == 0x32)
			{
				BrUSHORT wWingding2[] = {0x69, 0x6e, 0x67, 0x64, 0x69, 0x6e, 0x67, 0x73, 0x20, 0x32, 0x00};  //Wingdings 2
				if(CUtil::WcsICmp(m_sFontFace+1, wWingding2) == 0)
				{
					m_nOregFontIndex = eWingdings2OREGCTFont;
					nIndex = eWingdingsCTFont;
				}						
			}
			else if(cNCode == 0x33)
			{
				BrUSHORT wWingding3[] = {0x69, 0x6e, 0x67, 0x64, 0x69, 0x6e, 0x67, 0x73, 0x20, 0x33, 0x00};  //Wingdings 3
				if(CUtil::WcsICmp(m_sFontFace+1, wWingding3) == 0)
				{
					m_nOregFontIndex = eWingdings3OREGCTFont;
					nIndex = eWingdingsCTFont;
				}						
			}

		}


		break;
	case 0x5b8b:
		if( m_nFontFaceLen == 2 )
		{
			BrUSHORT wSimSun[] = {0x4f53, 0x00};		//SimSun
			if(CUtil::WcsICmp(m_sFontFace+1, wSimSun) == 0)
				nIndex = eSimSunCTFont;
		}
		break;
	case 0xAD81:
		if(m_nFontFaceLen == 2)
		{
			BrUSHORT wGS[] = {0xC11C,0x00};//�ü�
			if(CUtil::WcsICmp(m_sFontFace+1, wGS) == 0)
				nIndex = eGungsuhCTFont;
		}
		break;
	case 0xAD74:
		if(m_nFontFaceLen == 2)
		{
			BrUSHORT wGR[] = {0xB9BC,0x00};//����
			if(CUtil::WcsICmp(m_sFontFace+1, wGR) == 0)
				nIndex = eGulimCTFont;
		}
		break;			
	case 0xB3CB:
		if(m_nFontFaceLen == 2)
		{
			BrUSHORT wDU[] = {0xC6C0,0x00};//����
			if(CUtil::WcsICmp(m_sFontFace+1, wDU) == 0)
				nIndex = eDotumCTFont;			
		}
		break;	
	case 0xBC14:
		if(m_nFontFaceLen == 2)
		{
			BrUSHORT wBT[] = {0xD0D5,0x00};//����
			if(CUtil::WcsICmp(m_sFontFace+1, wBT) == 0)
				nIndex = eBatangCTFont;	
		}
		break;			
	}
	return nIndex;
}

BrBOOL BPDFExport::setFont(BrUSHORT* strFontName, BrUINT nLen, BrBOOL bInit)
{
	if(m_nFontFaceLen != nLen || CUtil::WcsCmp(m_sFontFace, strFontName) != 0)
	{
		BrINT nMinLen = BrMIN(MAX_FONT_LEN, nLen);
		memset(m_sFontFace, 0, BrSizeOf(m_sFontFace));
		CUtil::WcsNcpy(m_sFontFace, strFontName, nMinLen);
		m_nFontFaceLen = nMinLen;
		updateFontInfo();
		return BrTRUE;
	}
	return BrFALSE;
}

void BPDFExport::setFont()
{
	if(BR_ISSET_STATE(m_nState, eUpdateDefCIDFont_PDFExtState))
	{
		BR_REL_STATE(m_nState, eUpdateDefCIDFont_PDFExtState);
		m_pGenerator->SetFont(&m_sDefCIDFontInfo);
		BR_SET_STATE(m_nState, eRegDefCIDFont_PDFExtState);
	}
	else if(BR_ISSET_STATE(m_nState, eUpdateFont_PDFExtState))
	{
		BR_REL_STATE(m_nState, eUpdateFont_PDFExtState);
		m_pGenerator->SetFont(&m_sFontInfo);		
	}
}

void BPDFExport::setRegFont()
{
	BrXPDFCodeTable sOrgCodTable = m_sFontInfo.sCodeTable;

	memcpy(&sOrgCodTable, &m_sFontInfo.sCodeTable, BrSizeOf(sOrgCodTable));
	BR_SET_STATE(m_sFontInfo.sCodeTable.nAttFlag, eXPDFRegCodeFATTType);
	m_sFontInfo.sCodeTable.nDefWidth = -1;
	m_sFontInfo.sCodeTable.nLen = m_aRegCode.size();
	m_sFontInfo.sCodeTable.nFirstCode = 1;
	m_sFontInfo.sCodeTable.nLastCode = m_sFontInfo.sCodeTable.nLen;
	m_sFontInfo.sCodeTable.pData = m_aRegCode.data(); 

	if(m_nRegFontType == eArabic_RegCType)
	{
		BrCHAR	szBackFaceName[MAX_XPDF_FONT_LEN] = {0}; 
		BrINT nOldFlags = m_sFontInfo.nFlags;
		LPBrCTFontAtts pFontAtt = (LPBrCTFontAtts)&arrFontCTAtts[m_nCTFontIndex];

		m_sFontInfo.nFlags = pFontAtt->nFlags;
		strncpy_s(szBackFaceName, sizeof(szBackFaceName), m_sFontInfo.szFaceName, strlen(m_sFontInfo.szFaceName));
		memset(m_sFontInfo.szFaceName, 0, BrSizeOf(m_sFontInfo.szFaceName));
		if(m_nCTFontIndex == eTimesNewRomanCTFont)
			strncpy_s(m_sFontInfo.szFaceName, sizeof(m_sFontInfo.szFaceName), CTCIDFONT_TIMES_WFPREFIX, strlen(CTCIDFONT_TIMES_WFPREFIX));
		else
		{
			strncpy_s(m_sFontInfo.szFaceName, sizeof(m_sFontInfo.szFaceName), pFontAtt->sFace, strlen(pFontAtt->sFace));
		}
		m_pGenerator->SetFont(&m_sFontInfo);
		memset(m_sFontInfo.szFaceName, 0, BrSizeOf(m_sFontInfo.szFaceName));
		strncpy_s(m_sFontInfo.szFaceName, sizeof(m_sFontInfo.szFaceName), szBackFaceName, strlen(szBackFaceName));
		m_sFontInfo.nFlags = nOldFlags;
	}
	else
	{
		if(m_nCTFontIndex == eTimesNewRomanCTFont)
		{
			LPBrCTFontAtts pFontAtt = (LPBrCTFontAtts)&arrFontCTAtts[m_nCTFontIndex];
			makeFaceName(m_sFontInfo.szFaceName, sizeof(m_sFontInfo.szFaceName), m_sFontInfo.nFlags, CTCIDFONT_TIMES_WFPREFIX, CTCIDFONT_BITALIC_SUFFIX, CTCIDFONT_BOLD_SUFFIX,
				CTCIDFONT_ITALIC_SUFFIX, CTCIDFONT_TIMES_WFPREFIX);

			m_pGenerator->SetFont(&m_sFontInfo);
			makeFaceName(m_sFontInfo.szFaceName, sizeof(m_sFontInfo.szFaceName), m_sFontInfo.nFlags, CTCIDFONT_TIMES_PREFIX, CTFONT_BITALIC_SUFFIX, CTFONT_BOLD_SUFFIX,
				CTFONT_ITALIC_SUFFIX, pFontAtt->sFace);
		}
		else
		{
			m_pGenerator->SetFont(&m_sFontInfo);
		}
	}

	memcpy(&m_sFontInfo.sCodeTable, &sOrgCodTable, BrSizeOf(sOrgCodTable));
	BR_SET_STATE(m_nState, eUpdateFont_PDFExtState);
}

BrBYTE BPDFExport::getRegCodeType(BrUSHORT nCode, BrBYTE & nSubType, BrINT & nRegIndex, BrINT & nRegCTIndex)
{
	nSubType = eNone_RegCType;
	if(BR_ISARABIC_CODE(nCode))
	{
		nRegIndex = nCode - BRARABIC_CODE_MIN;
		nRegCTIndex = nCode - BRARABIC_CODE_MIN;
		nSubType = eArabic_RegCSubType;
		return eArabic_RegCType;
	}
	else if(BR_ISARABIC_PFORMS_A_CODE(nCode))
	{			
		nRegCTIndex = nCode - BRARABIC_PFORMS_A_CODE_MIN;
		nRegIndex = BRARABIC_CODE_SIZE+nRegCTIndex;	
		nSubType = eArabic_PFORMS_A_RegCSubType;
		return eArabic_RegCType;
	}
	else if(BR_ISARABIC_PFORMS_B_CODE(nCode))
	{
		nRegCTIndex = nCode - BRARABIC_PFORMS_B_CODE_MIN;
		nRegIndex = BRARABIC_CODE_SIZE+BRARABIC_PFORMS_A_CODE_SIZE+nRegCTIndex;	
		nSubType = eArabic_PFORMS_B_RegCSubType;
		return eArabic_RegCType;
	}
	else if(BR_ISLATIN_EXTA_CODE(nCode))
	{
		nRegCTIndex = nCode - BRLATIN_EXTA_CODE_MIN;
		nRegIndex = nRegCTIndex;	
		nSubType = eLatinExtA_RegCSubType;
		return eLatinExt_RegCType;	
	}
	else if(BR_ISLATIN_EXTB_CODE(nCode))
	{
		nRegCTIndex = nCode - BRLATIN_EXTB_CODE_MIN;
		nRegIndex = BRLATIN_EXTA_CODE_SIZE+nRegCTIndex;	
		nSubType = eLatinExtB_RegCSubType;
		return eLatinExt_RegCType;	
	}
	else if(BR_ISLATIN_EXTADD_CODE(nCode))
	{
		nRegCTIndex = nCode - BRLATIN_EXTADD_CODE_MIN;
		nRegIndex = BRLATIN_EXTA_CODE_SIZE+BRLATIN_EXTB_CODE_SIZE+nRegCTIndex;	
		nSubType = eLatinExtAdd_RegCSubType;
		return eLatinExt_RegCType;	
	}
	return eNone_RegCType;
}

BrBOOL BPDFExport::isRegCodeFont(BString* pText)
{
	BrBOOL bRet = BrFALSE;
	LPBrCTFontAtts pFontAtt = (LPBrCTFontAtts)&arrFontCTAtts[m_nCTFontIndex];
	BrINT nLen = pText->length();

	if(pFontAtt->nRegCodeLen && nLen)
	{
		BrBYTE nSubType;
		BrINT nNewType, nRegIndex, nRegCTIndex, nCodeTableIndex;
		BrUSHORT nCode;
		BChar* pChar = (BChar*)pText->unicode();

		nCode = pChar[0].unicode();
		nNewType = getRegCodeType(nCode, nSubType, nRegIndex, nRegCTIndex);
		if(nNewType != eNone_RegCType)
		{
			bRet = BrTRUE;
			if(nNewType != m_nRegFontType)
			{
				if(m_nRegFontType != eNone_RegCType)
					addRegText();					
				m_nRegFontType = nNewType;
			}

			switch(m_nCTFontIndex)
			{
			case eTimesNewRomanCTFont:
				switch(nSubType)
				{
				case eArabic_RegCSubType:			nCodeTableIndex = eTimes_Arabic_RegCType;				break;	
				case eArabic_PFORMS_A_RegCSubType:	nCodeTableIndex = eTimes_Arabic_PFORMS_A_RegCType;	break;
				case eArabic_PFORMS_B_RegCSubType:	nCodeTableIndex = eTimes_Arabic_PFORMS_B_RegCType;	break;
				case eLatinExtA_RegCSubType:		nCodeTableIndex = eTimes_LatinExtA_RegCType;			break;
				case eLatinExtB_RegCSubType:		nCodeTableIndex = eTimes_LatinExtB_RegCType;			break;						
				case eLatinExtAdd_RegCSubType:		nCodeTableIndex = eTimes_LatinExtAdd_RegCType;			break;	
				default: bRet = BrFALSE; break;
				}
				break;
			case eArialCTFont:
				switch(nSubType)
				{
				case eArabic_RegCSubType:			nCodeTableIndex = eArial_Arabic_RegCType;				break;	
				case eArabic_PFORMS_A_RegCSubType:	nCodeTableIndex = eArial_Arabic_PFORMS_A_RegCType;		break;
				case eArabic_PFORMS_B_RegCSubType:	nCodeTableIndex = eArial_Arabic_PFORMS_B_RegCType;		break;
				case eLatinExtA_RegCSubType:		nCodeTableIndex = eArial_LatinExtA_RegCType;			break;
				case eLatinExtB_RegCSubType:		nCodeTableIndex = eArial_LatinExtB_RegCType;			break;						
				case eLatinExtAdd_RegCSubType:		nCodeTableIndex = eArial_LatinExtAdd_RegCType;			break;							
				default: bRet = BrFALSE; break;						
				}
				break;
			case eTahomaCTFont:
				switch(nSubType)
				{
				case eArabic_RegCSubType:			nCodeTableIndex = eTahoma_Arabic_RegCType;				break;	
				case eArabic_PFORMS_A_RegCSubType:	nCodeTableIndex = eTahoma_Arabic_PFORMS_A_RegCType;		break;
				case eArabic_PFORMS_B_RegCSubType:	nCodeTableIndex = eTahoma_Arabic_PFORMS_B_RegCType;		break;
				case eLatinExtA_RegCSubType:		nCodeTableIndex = eTahoma_LatinExtA_RegCType;			break;
				case eLatinExtB_RegCSubType:		nCodeTableIndex = eTahoma_LatinExtB_RegCType;			break;						
				case eLatinExtAdd_RegCSubType:		nCodeTableIndex = eTahoma_LatinExtAdd_RegCType;			break;							
				default: bRet = BrFALSE; break;						
				}
				break;
			case eCourierCTFont:
				switch(nSubType)
				{
				case eArabic_RegCSubType:			nCodeTableIndex = eCourierNew_Arabic_RegCType;				break;	
				case eArabic_PFORMS_A_RegCSubType:	nCodeTableIndex = eCourierNew_Arabic_PFORMS_A_RegCType;		break;
				case eArabic_PFORMS_B_RegCSubType:	nCodeTableIndex = eCourierNew_Arabic_PFORMS_B_RegCType;		break;
				case eLatinExtA_RegCSubType:		nCodeTableIndex = eCourierNew_LatinExtA_RegCType;			break;
				case eLatinExtB_RegCSubType:		nCodeTableIndex = eCourierNew_LatinExtB_RegCType;			break;						
				case eLatinExtAdd_RegCSubType:		nCodeTableIndex = eCourierNew_LatinExtAdd_RegCType;			break;							
				default: bRet = BrFALSE; break;						
				}
				break;
			default:
				bRet = BrFALSE;
				break;
			}				

			if(bRet)
			{
				BrXPDFCodeInfo* pPDFCodeInfo = BrNULL;
				for(BrINT i = 0; i < nLen; i++)
				{
					nCode = pChar[i].unicode();
					nNewType = getRegCodeType(nCode, nSubType, nRegIndex, nRegCTIndex);
					if(m_nUseRegCode[nRegIndex] == -1)
					{
						BrINT nSize = m_aRegCode.size();
						m_aRegCode.resize(nSize+1);
						pPDFCodeInfo = m_aRegCode.GetAt(nSize);
						pPDFCodeInfo->nCode = nCode;
						pPDFCodeInfo->nWidth = pFontAtt->pRegCodeTable[nCodeTableIndex].pWidths[nRegCTIndex];
						pPDFCodeInfo->pCodeName = getUniCodeNme(nCode);

						if(pPDFCodeInfo->pCodeName == BrNULL)
						{
							nCode = getRecheckUnicode(nCode);
							pPDFCodeInfo->pCodeName = getUniCodeNme(nCode);
						}
						m_nUseRegCode[nRegIndex] = nSize;
					}
				}				
			}			
		}		
		else if(m_nRegFontType !=  eNone_RegCType)
		{
			addRegText();	
		}
	}

	return bRet;
}

BrBOOL BPDFExport::IsNeedChangeFont(BString* pText)
{
	BrBOOL nRet = BrFALSE;
	BrBOOL bCheck = BrFALSE;
	BrBOOL nHanja = BrFALSE;

	BChar* pChar = (BChar*)pText->unicode();
	BrUSHORT nCode = pChar[0].unicode();

	//[13.12.17][sglee1206]Winding Export �� Font ���� ���� ���ϵ��� ����
	if(m_nCTFontIndex == eWingdingsCTFont || m_nCTFontIndex == eWebdingsCTFont || m_nCTFontIndex == SymbolCTFont)
		bCheck = BrFALSE;
	else if(m_nCTFontIndex < CIDFONT_INDEX_BEGIN)
		bCheck = BrTRUE;
	else
	{		
		if(m_nCTFontIndex == DEF_HANGUL_CIDFONT_INDEX)
		{
			nHanja = IS_HANJA(nCode);
			if(nHanja)
				bCheck = BrTRUE;
		}
	}

	if(bCheck)
	{
		LPBrCTFontAtts pFontAtt = (LPBrCTFontAtts)&arrFontCTAtts[m_nCTFontIndex];
		if((BR_ISARABIC_CODE(nCode) || BR_ISARABIC_PFORMS_A_CODE(nCode) || BR_ISARABIC_PFORMS_B_CODE(nCode)) && pFontAtt->pRegCodeTable != BrNULL)
			return BrFALSE;

		if(BR_ISSET_STATE(m_nState, eNeedCIDFont_PDFExtState))
			nRet = BrTRUE;
		else if( ISNEED_DEFCIDFONT(m_nCTFontIndex) || nCode > 0xff )
		{
			if(IS_MODERN_KOREAN(nCode) || ( nHanja || IS_HANJA(nCode)) || IS_JAPANESE(nCode) || 
				IS_UCS2_General_Punctuation(nCode) || IS_UCS2_Geometric_Shapes(nCode) || IS_UCS2_Halfwidth_and_Fullwidth_Forms(nCode) ||
				IS_UCS2_Cyrillic(nCode) || IS_UCS2_Greek(nCode) || IS_UCS2_Currency_Symbols(nCode) || IS_UCS2_Mathematical_Operators(nCode))
				nRet = BrTRUE;
		}
		else if( IS_POLARIS_SYMBOL(nCode) )
			nRet = BrTRUE;

		if(nRet)
			m_bNeedChangeFont = BrTRUE;
	}

	return nRet;
}

BrBOOL BPDFExport::isCheckDefCIDFont(BString* pText, BrBOOL&  bUpdateFont)
{
	BrBOOL bRet = BrFALSE;

	bUpdateFont = BrTRUE;

	//[dwchun : 2012.08.27] : eNeedCIDFont_PDFExtState �÷��װ� �������� �ʾҴ��� �ѱ��̳� ���ڿ� ���� ���ڵ��� ������ CID Font�� �����ϵ��� �Ѵ�.
	if( IsNeedChangeFont(pText) )
	{
		BChar* pChar = (BChar*)pText->unicode();
		BrUSHORT nCode = pChar[0].unicode();
		BrINT nNewIndex  = -1;

		if(IS_MODERN_KOREAN(nCode))
		{
			bRet = BrTRUE;
			nNewIndex = DEF_HANGUL_CIDFONT_INDEX;
		}
		else if(IS_HANJA(nCode) || IS_JAPANESE(nCode))
		{
			bRet = BrTRUE;
			nNewIndex = DEF_HANJA_CIDFONT_INDEX;		//[dwchun : 2012.07.30] : ������ ��� ���� Index ����
		}
		else if(IS_UCS2_Greek(nCode) || IS_UCS2_General_Punctuation(nCode) || IS_UCS2_Geometric_Shapes(nCode) || IS_UCS2_Halfwidth_and_Fullwidth_Forms(nCode) || IS_UCS2_Cyrillic(nCode) )	//[dwchun : 2012.08.22] : �ѱ�, ����, �Ͼ �ƴϾ CID ��Ʈ�� �ʿ��� ��� ���⿡ ������ �߰�
		{
			bRet = BrTRUE;
			if( IS_JAPANESE_SPECIAL_CODE(nCode) )
				nNewIndex = DEF_JAPAN_SPECIAL_INDEX;
			else
				nNewIndex = DEF_HANGUL_SPECIAL_INDEX;
		}
		else if(IS_UCS2_Currency_Symbols(nCode) )
		{
			//[dwchun : 2012.09.25] : ��ȭ��ȣ�� ��� Adobe Korean CMap �迭���� ���ԵȰ� ����. Ȯ���� �� ��� Chinese CMap�� ����.
			bRet = BrTRUE;

			if(nCode == 0x20A9)
				nNewIndex = DEF_HANGUL_CIDFONT_INDEX;
			else
				nNewIndex = DEF_HANJA_SPECIAL_INDEX;
		}
		else if( IS_POLARIS_SYMBOL(nCode) )
		{
			bRet = BrTRUE;

			if(nCode == 0x00A3 || nCode == 0x00A5)
				nNewIndex = DEF_HANJA_SPECIAL_INDEX;
			else if(nCode == 0x00AE)
				nNewIndex = DEF_JAPAN_SPECIAL_INDEX;
			else
				nNewIndex = DEF_HANGUL_CIDFONT_INDEX;
		}
		else if(IS_UCS2_Mathematical_Operators(nCode) )
		{
			bRet = BrTRUE;
			nNewIndex = DEF_JAPAN_SPECIAL_INDEX;
		}
		else
		{
			if(BR_ISSET_STATE(m_nState, eRegDefCIDFont_PDFExtState))
			{
				BR_SET_STATE(m_nState, eUpdateFont_PDFExtState);	
			}
			BR_REL_STATE(m_nState, (eUpdateDefCIDFont_PDFExtState|eRegDefCIDFont_PDFExtState));
		}

		if(nNewIndex != -1)
		{
			addRegText();
			if(m_nDefCIDFontIndex != nNewIndex)
			{
				m_nDefCIDFontIndex = nNewIndex;		//[dwchun : 2012.07.30] : ������ ��� ������ ������ ���� Index ����
				BR_SET_STATE(m_nState, (eUpdateDefCIDFlag_PDFExtState|eUpdateDefCIDFont_PDFExtState));
				setFontInfo(m_nDefCIDFontIndex, &m_sDefCIDFontInfo);
				updateDefCIDFontDescriptorFlag();
			}
			else
			{
				bUpdateFont = updateDefCIDFontDescriptorFlag();
				if(BR_ISSET_STATE(m_nState, eRegDefCIDFont_PDFExtState) && !bUpdateFont)
					bUpdateFont = BrFALSE;
				else
				{
					BR_SET_STATE(m_nState, eUpdateDefCIDFont_PDFExtState);
					bUpdateFont = BrTRUE;
				}
			}
		}
	}

	return bRet;
}

BrBOOL BPDFExport::addText(BString* pText, BrFLOAT nTextWidth, LPBrFPOINT pPos, LPBrFPOINT pShadowPos, BrINT nFontFileIndex, BrULONG* p4ByteText, BString* pGlyphText, BrBOOL bTwip, BrBOOL bUseTextIndex, LPBrCharGap pCharInterval)
{
	BTrace("%s(%d) %s pText->utf8()[%s]", __FILE__, __LINE__, __FUNCTION__, pText->utf8());	
	//[15.01.22][sglee1206] ���۾��� �ʿ����� Ȯ�� �ʿ�
	if(nTextWidth < 0.0f && p4ByteText == BrNULL && pGlyphText == BrNULL) 
		return BrFALSE;
//BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);	
	BrBOOL bRet = BrFALSE;
	BrFPOINT fPos = {0.0f, 0.0f};
	BrFPOINT fShadowPos = {0.0f, 0.0f};
	BrFLOAT nMultiple = 10000.0f;
	if(pPos!=BrNULL){
		pPos->x = pPos->x * nMultiple;
		if( bTwip )
		{
			pPos->y = pPos->y * nMultiple;
			pPos->x = twip2DeviceF(pPos->x, gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
			fPos.x = pPos->x / nMultiple;
			pPos->y = twip2DeviceF(pPos->y, gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
			fPos.y = pPos->y / nMultiple;

		}
		else
		{
			pPos->x = twip2DeviceF(Device2twipsF(pPos->x, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
			fPos.x = pPos->x / nMultiple;
			pPos->y = twip2DeviceF(Device2twipsF(pPos->y, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
			fPos.y = pPos->y;
		}
	}
	if(pShadowPos != BrNULL){
		pShadowPos->x = pShadowPos->x * nMultiple;
		if( bTwip )
		{
			pShadowPos->x = twip2DeviceF(pShadowPos->x, gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
			fShadowPos.x = pShadowPos->x / nMultiple;
			pShadowPos->y = twip2DeviceF(pShadowPos->y, gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
			fShadowPos.y = pShadowPos->y;
		}
		else
		{
			pShadowPos->x = twip2DeviceF(Device2twipsF(pShadowPos->x, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
			fShadowPos.x = pShadowPos->x / nMultiple;
			pShadowPos->y = twip2DeviceF(Device2twipsF(pShadowPos->y, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
			fShadowPos.y = pShadowPos->y;
		}
	}

	if(m_bNeedChangeFont)
	{
		//BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);	
		m_nCTFontIndex = eTimesNewRomanCTFont;
		updateFontInfo();
		m_bNeedChangeFont = BrFALSE;
	}

	BrINT ii = 0;
	BrINT nTextLen = pText->length();
	BChar* pChar = (BChar*)pText->unicode();
	BrUSHORT nCode = pChar[0].unicode();
	BChar* pGlyphChar;
	BrUSHORT* nGlyphCode = BrNULL;
	BrINT nOldCTFontIndex = 0;
	if(bUseTextIndex)
	{
		//BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);	
		pGlyphChar = (BChar*)pGlyphText->unicode();
		nGlyphCode = (BrUSHORT*)BrMalloc(BrSizeOf(BrUSHORT)*(nTextLen+1));
		for(ii = 0; ii < nTextLen; ii++)
		{
			nGlyphCode[ii] = pGlyphChar[ii].unicode();
		}
		nGlyphCode[nTextLen] = 0;
	}
	LPBrCTFontAtts pFontAtt = (LPBrCTFontAtts)&arrFontCTAtts[m_nCTFontIndex];

	//preAddRegText(pPos);
	BrBOOL bEmbedCJK2Char = BrFALSE;
	//[15.01.18][sglee1206] ��� Font ����ó��
	if(p4ByteText == BrNULL)
	{
		//BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);	
		p4ByteText = (BrULONG*)BrMalloc(BrSizeOf(BrULONG)*(nTextLen+1));
		if(p4ByteText)
		{
			for (ii = 0; ii < nTextLen; ii++)
			{
				p4ByteText[ii] = pChar[ii].unicode() & 0xFFFF;
			}
			p4ByteText[nTextLen] = 0;

			//[15.03.30][sglee1206] Symbol ó�� ����. ZPD-10233
			if( m_nCTFontIndex == eWingdingsCTFont
				|| m_nCTFontIndex == SymbolCTFont
				)
			{
				for (ii = 0; ii < nTextLen; ii++)
				{
					p4ByteText[ii] |= 0xF000;
				}
				//*p4ByteText |= 0xF000;
			}
			bEmbedCJK2Char = BrTRUE;
		}
	}

	if(m_pGenerator && p4ByteText)
	{
		//BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);	
		BrBOOL bSetFont = BrTRUE;
		BrBOOL bEmbeddedFont = BrFALSE;
		if(bUseTextIndex)
		{
			//BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);	
			BrINT nTextIndex = 0;//(BrINT)nGlyphCode;
			m_pGenerator->SetTextExportType(ePDF_TEXT_TYPE_UNICODE);

			m_nCTFontIndex = eEmbedCTFont;	// ����� fontCodeTable�� Index�� ����Ͽ� ó���ϹǷ� �ӽ÷� eEmbedCTFont �߰���
			memset(&m_sFontInfo, 0, BrSizeOf(*(&m_sFontInfo)));
			int nLen = BrWcsLen(m_sFontFace);

			bEmbeddedFont = m_pGenerator->GetFontInfo(&m_sFontInfo,m_sFontInfo.szFaceName,nFontFileIndex);

			// visual studio debug ȯ�濡�� nFlags ���� ���������� ����Ŀ� ǥ������ ������ �Ʒ� if���� �������ϴ���. ������ �𸣰ڰ� 
			// font�� �̹� bold�� ����Ǿ��ִ� ��� �߰��� bold���� �ʵ��� �Ѵ�.
			// bold font - PDFFont::loadHeadTag ����
			if((m_sFontInfo.nFlags & 0x40000) == 0x40000)
				BR_REL_STATE(m_nFDFlag, eBold_PDFFDFlag);
			if((m_sFontInfo.nFlags & 0x40) == 0x40)
				BR_REL_STATE(m_nFDFlag, eItalic_PDFFDFlag);

			if(bEmbeddedFont == BrTRUE)
			{
				setCIDInfo(eUCSCTFontClass, &m_sFontInfo);
				for(ii = 0; ii < nTextLen; ii++)
				{
					nTextIndex = (BrINT)nGlyphCode[ii];
					m_pGenerator->SetGlyfIndexCode(&p4ByteText[ii], nTextIndex, BrSizeOf(nTextIndex));
				}
				//Font�� �߰��� �ٲ� state�� ������� �ʴ� ��� �����Ͽ� �߰�. ���� ���� ������ ����
				if(!BR_ISSET_STATE(m_nState, eUpdateFont_PDFExtState))
				{
					BR_SET_STATE(m_nState, eUpdateFont_PDFExtState);
				}
			}
			else
			{
				updateFontInfo();
				m_pGenerator->SetTextExportType(ePDF_TEXT_TYPE_NORMAL);
			}
		}
		else if(p4ByteText)	// 4byte
		{
			//BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);	
			if( (*p4ByteText & 0xffff0000) != 0 || *p4ByteText == 0x263a )
				m_pGenerator->SetTextExportType(ePDF_TEXT_TYPE_UCS4);
			else
				m_pGenerator->SetTextExportType(ePDF_TEXT_TYPE_UNICODE);

			//[16.02.23][sglee1206] ���� CTFontIndex ����. Wingding ó�� Symbol Font�� ��� 0xF000 ORing ó���� �ʿ��ϹǷ� �ش� ������ ������ �ʿ䰡 ����
			//CSP-3238
			nOldCTFontIndex = m_nCTFontIndex;
			m_nCTFontIndex = eEmbedCTFont;	// ����� fontCodeTable�� Index�� ����Ͽ� ó���ϹǷ� �ӽ÷� eEmbedCTFont �߰���
			memset(&m_sFontInfo, 0, BrSizeOf(*(&m_sFontInfo)));
			int nLen = BrWcsLen(m_sFontFace);
			bEmbeddedFont = m_pGenerator->GetFontInfo(&m_sFontInfo,m_sFontInfo.szFaceName,nFontFileIndex);

			// bold font - PDFFont::loadHeadTag ����
			if((m_sFontInfo.nFlags & 0x40000) == 0x40000)
				BR_REL_STATE(m_nFDFlag, eBold_PDFFDFlag);
			if((m_sFontInfo.nFlags & 0x40) == 0x40)
				BR_REL_STATE(m_nFDFlag, eItalic_PDFFDFlag);

			if(bEmbeddedFont == BrTRUE)
			{
				//BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);	
				setCIDInfo(eUCSCTFontClass, &m_sFontInfo);
				for(ii = 0; ii < nTextLen; ii++)
				{
					//nTextIndex = (BrINT)nGlyphCode[ii];
					//m_pGenerator->SetGlyfIndexCode(nTextIndex, BrSizeOf(nTextIndex));
					m_pGenerator->SetUCS4Unicode(&p4ByteText[ii], BrSizeOf(p4ByteText[ii]));
				}
				
				//Font�� �߰��� �ٲ� state�� ������� �ʴ� ��� �����Ͽ� �߰�. ���� ���� ������ ����
				if(!BR_ISSET_STATE(m_nState, eUpdateFont_PDFExtState))
				{
					BR_SET_STATE(m_nState, eUpdateFont_PDFExtState);
				}
			}
			else
			{
				//BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);	
				m_pGenerator->SetTextExportType(ePDF_TEXT_TYPE_NORMAL);
				updateFontInfo();
				BrUSHORT* tmp = (BrUSHORT*)BrMalloc(BrSizeOf(BrUSHORT)*nTextLen+1);
				for(ii = 0; ii < nTextLen; ii++)
				{
					tmp[ii] = p4ByteText[ii] & 0x0000ffff;
				}
				pText->setUnicodeCodes(tmp,BrSizeOf(p4ByteText[ii])/BrSizeOf(BrULONG)*nTextLen);
				BrFree(tmp);
				//for(ii = 0; ii < nTextLen; ii++)
				//{
				//	BrUSHORT tmp = p4ByteText[ii] & 0x0000ffff;
				//	pText->setUnicodeCodes(&tmp,BrSizeOf(p4ByteText[ii])/BrSizeOf(BrULONG));
				//}
				//BrUSHORT tmp = *p4ByteText & 0x0000ffff;
				//pText->setUnicodeCodes(&tmp,BrSizeOf(p4ByteText)/BrSizeOf(BrULONG));
			}
		}
		else
		{
			//BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);	
			//Font�� �߰��� �ٲ� state�� ������� �ʴ� ��� �����Ͽ� �߰�. ���� ���� ������ ����
			updateFontInfo();
			m_pGenerator->SetTextExportType(ePDF_TEXT_TYPE_NORMAL);
		}
//BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);	
		if(bEmbeddedFont == BrFALSE && isCheckDefCIDFont(pText, bSetFont))
		{
			//BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);	
			//[2012.09.07][ekaloss] QA buillet ��ȣ ��ġ ���� �ʴ� ����
			BChar* pChar = (BChar*)pText->unicode();
			BrUSHORT nCode = pChar[0].unicode();
			if(nCode == 0x2022)
			{
				fPos.x -= nTextWidth;
				if(pShadowPos)
					pShadowPos->x -= nTextWidth;
			}

			if(bSetFont)
				setFont();
		}
		else if(bEmbeddedFont == BrFALSE && isRegCodeFont(pText))
		{
			//BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);	
			if (addRegTextInfo(pText, nTextWidth, &fPos, &fShadowPos))
				bRet = BrTRUE;
			else
				clearRegCodeTable();
			goto func_end;
		}
		else
			setFont();

		//[dwchun : 2012.09.25] : �������� �Ѱ��ִ� ���� �ϰ����� ���� ���⼭ �����ش�.
		BString cText = BrNULL;
		BString cChangeText = BrNULL;
//BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);	
		//wingdings 2 �� wingdings 3 ��Ʈ�� ������ text�� unicode�� wingdings ��Ʈ�� unicode�� match ���ش�.
		if(m_nCTFontIndex == eWingdingsCTFont && (m_nOregFontIndex == eWingdings2OREGCTFont || m_nOregFontIndex == eWingdings3OREGCTFont) )
		{
			//BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);	
			for(ii = 0; ii < nTextLen; ii++)
			{
				FT_ULong nMatchCode = pText->at(ii).unicode();
				switch(nMatchCode)
				{
				case 0x00a4:
					{
						BChar c((BrUINT16)0x70);
						cChangeText = c;
						pText->replace(ii, 1, cChangeText);
						//pText = &cChangeText;	
					}
					break;
				case 0x0023:
					{
						BChar c((BrUINT16)0xe1);
						cChangeText = c;
						pText->replace(ii, 1, cChangeText);
						//pText = &cChangeText;
					}
					break;
				}
			}
		}

//BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);	
		if(    m_nCTFontIndex == eWingdingsCTFont
			|| m_nCTFontIndex == SymbolCTFont
			)
		{
			//BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);	
			for(ii = 0; ii < nTextLen; ii++)
			{
				if( pText->at(ii).unicode() & 0xf000 )
				{
					cText = (BChar(pText->at(ii).unicode() & 0x00ff));
					//pText = &cText;
					pText->replace(ii, 1, cText);
				}
			}
		}
//BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);	
		// [14.04.22][sglee1206] get CodeMap
		if(bEmbeddedFont == BrTRUE)	// ���� ��Ʈ�� ���(14.03.20 ����� �ѱ� �Ϻο� Emoji)
		{
			//BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);	
			BrWORD* tmp = (BrWORD*)BrMalloc(sizeof(BrWORD)*(nTextLen+1));

			if (tmp == BrNULL)
				goto func_end;

			if(tmp != BrNULL)
			{
				for(ii = 0; ii < nTextLen; ii++)
					tmp[ii] = bUseTextIndex? nGlyphCode[ii]:m_pGenerator->getCodeFromCodeMap(p4ByteText[ii]);
				tmp[nTextLen]=0;
				m_nCTFontIndex = nOldCTFontIndex;
				pText->setUnicodeCodes(tmp,pText->length());
			}

			BR_SAFE_FREE(tmp);
		}
//BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);	
		if (errNone == m_pGenerator->AddText(&m_sTextAtt, eXPDFStrTextType, pText, pText->length(), &fPos, m_clipRect, &fShadowPos, m_nFDFlag, pCharInterval))
			bRet = BrTRUE;
	}
func_end:
	if (bUseTextIndex)
		BR_SAFE_FREE(nGlyphCode);
	if (bEmbedCJK2Char)
		BR_SAFE_FREE(p4ByteText);
//BTrace("%s(%d) %s", __FILE__, __LINE__, __FUNCTION__);	
	return BrFALSE;
}

void BPDFExport::addRegText()
{
	BrINT nLen;

	addRegTextInfofromTextPool();
	nLen = m_aRegTextInfo.size();
	if(nLen)
	{
		BrUSHORT* pCodeIndex;
		BrXPDFRegTextInfo* pTextInfo;		
		BrUseFontInfo* pTextAtts = (BrUseFontInfo*)m_aRegBaseTextAtt.data();		
		BrXPDFRegTextInfo* pTextInfos = (BrXPDFRegTextInfo*)m_aRegTextInfo.data();		

		BTrace("PDF Export incorrect routine!!");
		//[16.08.16][sglee1206] �ش� ��ƾ ó���� Crash �߻�Ȯ���� ���� ���� �̻�� ó��
		//�ش� ��ƾ ó������ �ʴ� ��� �ش� ���ڰ� ����µ� �� ������ Crash �߻��� ���ֱ� ���� ó������ �ʵ��� ��
		if(false)
		{
			setRegFont();

			for(BrINT i = 0; i < nLen; i++)
			{		
				pTextInfo = &pTextInfos[i];

				if(pTextInfo->nTextLen > 1)
					pCodeIndex = pTextInfo->pTextIndexs;
				else
					pCodeIndex = &pTextInfo->nTextIndex;

				if(pTextInfo->bSetShadow)
				{
					if(m_pGenerator->AddText(&pTextAtts[pTextInfo->nAttIndex], eXPDFUniIndexTextType, pCodeIndex, pTextInfo->nTextLen, &pTextInfo->sPos, m_clipRect, &pTextInfo->sShadowPos) != errNone)
						break;
				}
				else
				{
					if(m_pGenerator->AddText(&pTextAtts[pTextInfo->nAttIndex], eXPDFUniIndexTextType, pCodeIndex, pTextInfo->nTextLen, &pTextInfo->sPos, m_clipRect, BrNULL) != errNone)
						break;			
				}
			}
		}
		clearRegCodeTable();
	}	
}

BrINT BPDFExport::addRegTextAtt()
{
	BrINT nIndex = -1, i;
	BrUseFontInfo* pAtt = BrNULL;
	BrINT nLen = m_aRegBaseTextAtt.size();
	if(nLen)
	{
		pAtt = m_aRegBaseTextAtt.data();
		for(i = 0; i < nLen; i++)
		{
			if(pAtt[i].nAngle == m_sTextAtt.nAngle && pAtt[i].nBgColor == m_sTextAtt.nBgColor && pAtt[i].nColor == m_sTextAtt.nColor
				&& pAtt[i].nFontSize == m_sTextAtt.nFontSize && pAtt[i].nHorzScale == m_sTextAtt.nHorzScale && pAtt[i].nShadowColor == m_sTextAtt.nShadowColor)
			{
				nIndex = i;
				break;
			}
		}
	}

	if(nIndex == -1)	
	{
		if(m_aRegBaseTextAtt.resize(nLen+1))
		{
			BrUseFontInfo* pAtt = m_aRegBaseTextAtt.GetAt(nLen);
			pAtt->nAngle = m_sTextAtt.nAngle;
			pAtt->nBgColor = m_sTextAtt.nBgColor;
			pAtt->nColor = m_sTextAtt.nColor;
			pAtt->nFontSize = m_sTextAtt.nFontSize;
			pAtt->nHorzScale = m_sTextAtt.nHorzScale;
			pAtt->nShadowColor = m_sTextAtt.nShadowColor;
			nIndex = nLen;
		}
	}

	return nIndex;
}

void BPDFExport::getUniCodeIndex(BrUSHORT* pIndexPool, BChar* pChar, BrINT nLen, BrBOOL bRev)
{
	BrUSHORT nCode;
	BrBYTE nSubType;
	BrINT nRegIndex, nRegCTIndex;

	if(bRev && nLen > 1)
	{
		for(BrINT i = nLen-1; i >= 0; i--)
		{
			nCode = pChar[i].unicode();

			getRegCodeType(nCode, nSubType, nRegIndex, nRegCTIndex);
			pIndexPool[i] = m_nUseRegCode[nRegIndex];
		}	
	}
	else
	{
		for(BrINT i = 0; i < nLen; i++)
		{
			nCode = pChar[i].unicode();

			getRegCodeType(nCode, nSubType, nRegIndex, nRegCTIndex);
			pIndexPool[i] = m_nUseRegCode[nRegIndex];
		}		

	}
}

BrBOOL BPDFExport::addRegTextInfo(void* pData, BrBOOL bUniIndex, BrINT nLen, LPBrFPOINT pPos, LPBrFPOINT pShadowPos, BrBOOL bRev)
{
	//if(pPos!=BrNULL){
	//	pPos->x = twips2DeviceX(Device2twips(pPos->x, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
	//	pPos->y = twips2DeviceY(Device2twips(pPos->y, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, 0, TARGET_DEVICE_RESOLUTION);
	//}
	//if(pShadowPos != BrNULL){
	//	pShadowPos->x = twips2DeviceX(Device2twips(pShadowPos->x, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
	//	pShadowPos->y = twips2DeviceY(Device2twips(pShadowPos->y, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, 0, TARGET_DEVICE_RESOLUTION);
	//}

	BrINT nAttIndex = addRegTextAtt();
	BrINT nSize = m_aRegTextInfo.size();		

	if(m_aRegTextInfo.resize(nSize+1))
	{	
		BrXPDFRegTextInfo * pTextInfo = m_aRegTextInfo.GetAt(nSize);
		if(nLen > 1)
		{
			pTextInfo->pTextIndexs = (BrUSHORT*)BrMalloc(BrSizeOf(BrUSHORT)*nLen);
			if(pTextInfo->pTextIndexs)
			{
				pTextInfo->nTextIndex = 0;
				if(bUniIndex)
				{
					if(bRev)
					{
						BrUSHORT* pCIndex = (BrUSHORT*)pData;
						for(BrINT i = 0; i< nLen; i++)
							pTextInfo->pTextIndexs[i] = pCIndex[nLen-1-i];
					}
					else
						memcpy(pTextInfo->pTextIndexs, pData, BrSizeOf(BrUSHORT)*nLen);
				}
				else
					getUniCodeIndex(pTextInfo->pTextIndexs, (BChar*)pData, nLen, bRev);
			}
			else
			{
				m_aRegTextInfo.resize(nSize);
				return BrFALSE;
			}
		}
		else
		{
			if(bUniIndex)
				pTextInfo->nTextIndex = *((BrUSHORT*)pData);
			else
				getUniCodeIndex(&pTextInfo->nTextIndex, (BChar*)pData, nLen, bRev);

			pTextInfo->pTextIndexs = BrNULL;
		}

		pTextInfo->nTextLen = nLen;
		pTextInfo->nAttIndex = addRegTextAtt();
		pTextInfo->sPos = *pPos;		
		if(pShadowPos)
		{
			pTextInfo->bSetShadow = BrTRUE;
			pTextInfo->sShadowPos = *pShadowPos;
		}
		else
		{
			pTextInfo->bSetShadow = BrFALSE;
			pTextInfo->sShadowPos.x = pTextInfo->sShadowPos.y = 0;
		}

		return BrTRUE;
	}
	return BrFALSE;
}

void BPDFExport::addRegTextInfofromTextPool()
{
	BrINT nSize = m_aTextPool.size();
	if(nSize)
	{
		BrBOOL bRev = BrFALSE;
		LPBrFPOINT pPos = &m_nTextPoolSPos;
		LPBrFPOINT pShadowPos = (m_bTextPoolShadow)? &m_nTextPoolShadowSPos : BrNULL;
		if(m_nRegFontType == eArabic_RegCType)
		{
			bRev = BrTRUE;
			pPos = &m_nTextPoolEPos;
			if(pShadowPos)
				pShadowPos = &m_nTextPoolShadowEPos;

			m_pGenerator->SetWritingMode(eXPDF_WRITING_RIGHT_TO_LEFT);
		}
		addRegTextInfo(m_aTextPool.data(), BrTRUE, nSize, pPos, pShadowPos, bRev);
		clearTextPool();		
	}
}

void BPDFExport::preAddRegText(LPBrPOINT pPos)
{
	if(m_aTextPool.size() && m_nRegFontType == eArabic_RegCType && m_nTextPoolEPos.y == pPos->y && m_nTextPoolEPos.x < pPos->x)
		addRegText();
}

BrBOOL BPDFExport::addRegTextInfo(BString* pText, BrFLOAT nTextWidth, LPBrFPOINT pPos, LPBrFPOINT pShadowPos)
{
	//if(pPos!=BrNULL){
	//	pPos->x = twips2DeviceX(Device2twips(pPos->x, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
	//	pPos->y = twips2DeviceY(Device2twips(pPos->y, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, 0, TARGET_DEVICE_RESOLUTION);
	//}
	//if(pShadowPos != BrNULL){
	//	pShadowPos->x = twips2DeviceX(Device2twips(pShadowPos->x, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
	//	pShadowPos->y = twips2DeviceY(Device2twips(pShadowPos->y, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, 0, TARGET_DEVICE_RESOLUTION);
	//}

	BrINT nAttIndex = addRegTextAtt();
	BrINT nPoolSize, nSize = m_aRegTextInfo.size();		
	BrINT nLen = pText->length();
	BChar* pChar = (BChar*)pText->unicode();

	if(m_nRegFontType == eArabic_RegCType)
	{
		BrFPOINT sShadowPos = {0, 0};
		nPoolSize = m_aTextPool.size();
		if(!nPoolSize)
		{			
			if(!m_aTextPool.resize(nLen))
				return BrFALSE;

			m_nTextPoolSPos = m_nTextPoolEPos = *pPos;
			if(pShadowPos)
			{
				m_bTextPoolShadow = BrTRUE;
				m_nTextPoolShadowSPos = m_nTextPoolShadowEPos = *pShadowPos;
			}
			else
			{
				m_bTextPoolShadow = BrFALSE;
				m_nTextPoolShadowSPos = m_nTextPoolShadowEPos = sShadowPos;
			}
			getUniCodeIndex(m_aTextPool.data(), (BChar*)pText->unicode(), nLen, BrTRUE);
		}
		else
		{
			if(pPos->y == m_nTextPoolEPos.y && (m_nTextPoolEPos.x > pPos->x) && (m_nTextPoolEPos.x - pPos->x) <= nTextWidth+1+nTextWidth/3)			
			{
				if(!m_aTextPool.resize(nPoolSize+nLen))
					return BrFALSE;
				m_nTextPoolEPos = *pPos;

				if(pShadowPos)
				{
					m_bTextPoolShadow = BrTRUE;
					m_nTextPoolShadowEPos = *pShadowPos;
				}
				getUniCodeIndex(m_aTextPool.data()+nPoolSize, (BChar*)pText->unicode(), nLen, BrTRUE);
			}
			else
			{
				addRegTextInfofromTextPool();
				if(!m_aTextPool.resize(nLen))
					return BrFALSE;

				if(pShadowPos)
				{
					m_bTextPoolShadow = BrTRUE;
					m_nTextPoolShadowSPos = m_nTextPoolShadowEPos = *pShadowPos;
				}
				else
				{
					m_bTextPoolShadow = BrFALSE;
					m_nTextPoolShadowSPos = m_nTextPoolShadowEPos = sShadowPos;
				}

				m_nTextPoolSPos = m_nTextPoolEPos = *pPos;
				getUniCodeIndex(m_aTextPool.data(), (BChar*)pText->unicode(), nLen, BrTRUE);				
			}
		}		
		return BrTRUE;
	}
	else
	{		
		if(addRegTextInfo(pChar, BrFALSE, nLen, pPos, pShadowPos, BrFALSE))
		{
			m_pGenerator->SetWritingMode(eXPDF_WRITING_LEFT_TO_RIGHT);
			return BrTRUE;		
		}
	}
	return BrFALSE;
}

inline BrFLOAT ExtPDFResF(BrFLOAT fTwips, BrLONG nZoomIn, BrLONG iResX)
{
	return (BrFLOAT)(fTwips * (BrFLOAT)(1440*ZOOM_10000)) /  (gpPaint->zoom.m_iScale * getExportPDFRes());
}

void BPDFExport::setTextAtt(BrFLOAT nSize, BrCOLORREF nColor, BrCOLORREF nBgColor, BrCOLORREF nShadowColor, BrINT nAngle, BrINT nHRatio, BrBOOL bBold, BrBOOL bItalic, BrBOOL bStroke)
{
	nSize = twip2DeviceF(ExtPDFResF(nSize, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
	//nSize = twips2DeviceX(Device2twips(nSize, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);

	if(m_sTextAtt.nAngle != nAngle || m_sTextAtt.nBgColor != nBgColor || m_sTextAtt.nColor != nColor || m_sTextAtt.nFontSize != nSize || m_sTextAtt.nHorzScale != nHRatio || m_sTextAtt.nShadowColor != nShadowColor)
		addRegTextInfofromTextPool();
	m_sTextAtt.nAngle = nAngle;
	m_sTextAtt.nBgColor = nBgColor;
	m_sTextAtt.nShadowColor = nShadowColor;
	m_sTextAtt.nColor = nColor;
	m_sTextAtt.nFontSize = nSize;
	m_sTextAtt.nHorzScale = nHRatio;
	setFontDescriptorFlag(&bBold, &bItalic, &bStroke);
}

void BPDFExport::setTextHeight(BrFLOAT nSize)
{
	nSize = twip2DeviceF(ExtPDFResF(nSize, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
	//nSize = twips2DeviceX(Device2twips(nSize, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);

	if(m_sTextAtt.nFontSize != nSize)
		addRegTextInfofromTextPool();
	m_sTextAtt.nFontSize = nSize;
}

void BPDFExport::setTextColor(BrCOLORREF nColor)
{
	if(m_sTextAtt.nColor != nColor)
		addRegTextInfofromTextPool();
	m_sTextAtt.nColor = nColor;
}

void BPDFExport::setTextBackColor(BrCOLORREF nBgColor)
{
	if(m_sTextAtt.nBgColor != nBgColor)
		addRegTextInfofromTextPool();
	m_sTextAtt.nBgColor = nBgColor;
}

void BPDFExport::setTextRotate(BrINT nAngle)
{
	if(m_sTextAtt.nAngle != nAngle)
		addRegTextInfofromTextPool();
	m_sTextAtt.nAngle = nAngle;
}

void BPDFExport::setTextHorzScale(BrINT nRatio)
{
	if(m_sTextAtt.nHorzScale != nRatio)
		addRegTextInfofromTextPool();
	m_sTextAtt.nHorzScale = nRatio;
}

void BPDFExport::setBold(BrBOOL bBold)
{
	BrBOOL *boolNullPtr = NULL;
	setFontDescriptorFlag(&bBold, boolNullPtr);
}

void BPDFExport::setItalic(BrBOOL bItalic)
{
	setFontDescriptorFlag(BrNULL, &bItalic);
}

void BPDFExport::setScaleX(BrFLOAT xScale)
{
	if(m_sTextAtt.fScaleX != xScale)
		addRegTextInfofromTextPool();
	m_sTextAtt.fScaleX = xScale;
}

void BPDFExport::setScaleY(BrFLOAT yScale)
{
	if(m_sTextAtt.fScaleY != yScale)
		addRegTextInfofromTextPool();
	m_sTextAtt.fScaleY = yScale;
}

void BPDFExport::pathAttInit()
{
	m_cPencolor = BLACK_COLOR;
	m_cBrushcolor = WHITE_COLOR;	//[[dwchun : 2012.08.24] : Export�� XStream�� Color���� "B"(Block)�̱� ������ �⺻ ���� Block���� ���� ��
	m_nPenWidth = 1;
	m_nPenStyle = eSolid;
	m_nGstate.nFillOpacity=0;
	m_nGstate.nStrokeOpacity=0;
	m_nLineCap = eXLINE_CAP_BUTTER; //���
	m_nLineJoin = eXLINE_JOIN_ROUND; //����
	BR_REL_STATE(m_nState, (eSetPenColorFlag_PDFExtState|eSetBrushColorFlag_PDFExtState|eSetPenWidthFlag_PDFExtState|eSetPenStyleFlag_PDFExtState|eSetGstateFlag_PDFExtState | eSetLineCapFlag_PDFExtState | eSetLineJoinFlag_PDFExtState));
}
void BPDFExport::setPenAtt(BrINT nWidth, BrCOLORREF cColor, BrBYTE nStyle, BrBYTE nCap, BrBYTE nJoin)
{
	if(nCap)
	{
		if(nCap == eNoneLineCap) nCap = eXLINE_CAP_BUTTER;
		else if(nCap == eSquareLineCap) nCap = eXLINE_CAP_PROJECTING;
		else nCap = eXLINE_CAP_ROUND; //nCap == eRoundLineCap 
		setCap((BrINT)nCap);
	}
	if(nJoin)
	{
		if(nJoin == eRoundLineJoin) nJoin = eXLINE_JOIN_ROUND;
		else if(nJoin == eBevelLineJoin) nJoin = eXLINE_JOIN_BEVEL;
		else nJoin = eXLINE_JOIN_MITER; //nJoin == miter
		setJoin((BrINT)nJoin);
	}

	setPenStyle(nStyle);
	setPenColor(cColor);
	setPenWidth(nWidth);
}

void BPDFExport::setPenColor(BrCOLORREF cColor)
{
	if(m_cPencolor != cColor || !BR_ISSET_STATE(m_nState, eSetPenColorFlag_PDFExtState))
	{
		m_cPencolor = cColor;
		if(m_pPathStream)
		{
			m_pPathStream->SetStrokeColor(m_cPencolor);
			BR_REL_STATE(m_nState, eUpdatePenColorFlag_PDFExtState);			
		}
		else
			BR_SET_STATE(m_nState, eUpdatePenColorFlag_PDFExtState);
		BR_SET_STATE(m_nState, eSetPenColorFlag_PDFExtState);		
	}
}

void BPDFExport::setBrushColor(BrCOLORREF cColor)
{
	// image brush�� �ܻ� ä��� color brush�� �� �� �ϳ��� ���ϱ� ���⼭ ������ �ɰ� ����
	// �ٵ� color brush�� state�� �����ϴµ� image brush�� �� brushbitdata�� ������ �켱�ϴ°ž�? ������ �ǵ��ȴ�� �Ǵ��� �̷��� ¥�� �ڵ尡 �ȿ����ݾ� �̰�
	clearImageBrush(); 

	if(m_cBrushcolor != cColor || !BR_ISSET_STATE(m_nState, eSetBrushColorFlag_PDFExtState))
	{
		m_cBrushcolor = cColor;
		if(m_pPathStream)
		{
			m_pPathStream->SetFillColor(m_cBrushcolor);
			BR_REL_STATE(m_nState, eUpdateBrushColorFlag_PDFExtState);	
		}
		else
			BR_SET_STATE(m_nState, eUpdateBrushColorFlag_PDFExtState);	
		BR_SET_STATE(m_nState, eSetBrushColorFlag_PDFExtState);	
	}
}

void BPDFExport::setPenWidth(BrINT nWidth)
{	
#if 0//ndef USE_EXT_PDF_2_0 //[2014.06.25] pdf2 ������ nWidth ���� baseLineWidth�� (Twip��)���� ������ ����Ѵ�.
	nWidth = twips2DeviceX(Device2twips(nWidth, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
#endif //USE_EXT_PDF_2_0
	if(m_nPenWidth != nWidth || !BR_ISSET_STATE(m_nState, eSetPenWidthFlag_PDFExtState))
	{
		m_nPenWidth = nWidth;
		if(m_pPathStream)
		{
			m_pPathStream->SetStrokeWidth(m_nPenWidth, m_bPenWidthIsTwip ? true : false);
			BR_REL_STATE(m_nState, eUpdatePenWidthFlag_PDFExtState);
		}
		else
			BR_SET_STATE(m_nState, eUpdatePenWidthFlag_PDFExtState);
		BR_SET_STATE(m_nState, eSetPenWidthFlag_PDFExtState);
	}
}

BrBOOL BPDFExport::setPenWidthTwip(BrBOOL bIsTwip)
{
	BrBOOL bOld = m_bPenWidthIsTwip;
	m_bPenWidthIsTwip = bIsTwip;
	return bOld;
}

void BPDFExport::setPenStyle(BrBYTE nStyle)
{
	if(m_nPenStyle != nStyle || !BR_ISSET_STATE(m_nState, eSetPenStyleFlag_PDFExtState))
	{
		m_nPenStyle = nStyle;
		if(m_pPathStream)
		{
 			m_pPathStream->SetStrokeDashStyle(m_nPenStyle, m_nLineCap, m_nPenWidth);

			BR_REL_STATE(m_nState, eUpdatePenStyleFlag_PDFExtState);
		}
		else
			BR_SET_STATE(m_nState, eUpdatePenStyleFlag_PDFExtState);
		BR_SET_STATE(m_nState, eSetPenStyleFlag_PDFExtState);
	}
}

void BPDFExport::updateDrawAtt()
{
	if(BR_ISSET_STATE(m_nState, eUpdatePenColorFlag_PDFExtState))
	{
		m_pPathStream->SetStrokeColor(m_cPencolor);
		BR_REL_STATE(m_nState, eUpdatePenColorFlag_PDFExtState);
	}

	if(BR_ISSET_STATE(m_nState, eUpdateBrushColorFlag_PDFExtState))
	{
		m_pPathStream->SetFillColor(m_cBrushcolor);
		BR_REL_STATE(m_nState, eUpdateBrushColorFlag_PDFExtState);
	}

	//Cap �� ���� ����� �� ������ ������ Dash Style�� ���� �ؾ� ��. 
	if(BR_ISSET_STATE(m_nState, eUpdateLineCapFlag_PDFExtState))
	{
		m_pPathStream->SetStrokeCapStyle(m_nLineCap);
		BR_REL_STATE(m_nState, eUpdateLineCapFlag_PDFExtState);
	}	
	if(BR_ISSET_STATE(m_nState, eUpdateLineJoinFlag_PDFExtState))
	{
		m_pPathStream->SetStrokeJoinStyle(m_nLineJoin);
		BR_REL_STATE(m_nState, eUpdateLineJoinFlag_PDFExtState);
	}
	if(BR_ISSET_STATE(m_nState, eUpdateGstateFlag_PDFExtState))
	{
		m_pGenerator->SetGState(m_pPathStream, &m_nGstate);
		BR_REL_STATE(m_nState, eUpdateGstateFlag_PDFExtState);
	}	

	if(BR_ISSET_STATE(m_nState, eUpdatePenWidthFlag_PDFExtState))
	{
		m_pPathStream->SetStrokeWidth(m_nPenWidth, m_bPenWidthIsTwip ? true : false);
		BR_REL_STATE(m_nState, eUpdatePenWidthFlag_PDFExtState);
	}

	if(BR_ISSET_STATE(m_nState, eUpdatePenStyleFlag_PDFExtState))
	{
		m_pPathStream->SetStrokeDashStyle(m_nPenStyle, m_nLineCap, m_nPenWidth);
		BR_REL_STATE(m_nState, eUpdatePenStyleFlag_PDFExtState);
	}	
}


void BPDFExport::moveTo(LPBrFPOINT pos, BrBOOL bCalcFloat /* = BrFalse */)
{
	BrFPOINT fPos = {0, 0};

	if (pos!=BrNULL) {

		if (!bCalcFloat) { // �����ڵ�
			fPos.x = twips2DeviceX(Device2twips(pos->x, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
			fPos.y = twips2DeviceY(Device2twips(pos->y, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, 0, TARGET_DEVICE_RESOLUTION);
		}
		else {
			fPos.x = twip2DeviceF(ExtPDFResF(pos->x, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION); 
			fPos.y = twip2DeviceF(ExtPDFResF(pos->y, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION); 
		}
	}

	if(m_pPathStream)
	{
		XPoint sPos = {fPos.x, fPos.y};		
		updateDrawAtt();
		m_pPathStream->MoveTo(sPos);
	}	
}

void BPDFExport::lineTo(LPBrFPOINT pos, BrBOOL bStroke, BrBOOL bCalcFloat /* = BrFalse */)
{
	BrFPOINT fPos = {0, 0}; // [2015.06.11][235] pos�� ���� �����Ͽ�, ���� ��ƾ���� �߻��Ǵ� ���� ����

	if(pos!=BrNULL){

		if (!bCalcFloat) { // �����ڵ�
			fPos.x = twips2DeviceX(Device2twips(pos->x, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
			fPos.y = twips2DeviceY(Device2twips(pos->y, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, 0, TARGET_DEVICE_RESOLUTION);
		}
		else { // [2015.06.04][235] pos�� �Ǽ����� ���, �̿����� ����ϵ��� ����
			fPos.x = twip2DeviceF(ExtPDFResF(pos->x, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION); 
			fPos.y = twip2DeviceF(ExtPDFResF(pos->y, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION); 
		}
	}

	if(m_pPathStream)
	{
		XPoint sPos = {fPos.x, fPos.y};
		m_pPathStream->LineTo(sPos, bStroke=(bStroke!=0));
	}	
}

void BPDFExport::fillSolidrect(BrFRect* pRect, BrCOLORREF cFillColor, BrBOOL bCalcFloat)
{
	// Coverity-16636
	if(pRect == BrNULL)
		return;

	if (!bCalcFloat) // �����ڵ�
	{
		pRect->left = twips2DeviceX(Device2twips(pRect->left, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
		pRect->top = twips2DeviceY(Device2twips(pRect->top, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, 0, TARGET_DEVICE_RESOLUTION);
		pRect->right = twips2DeviceX(Device2twips(pRect->right, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
		pRect->bottom = twips2DeviceY(Device2twips(pRect->bottom, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, 0, TARGET_DEVICE_RESOLUTION);
	}
	else // [2016.04.18][235][ZPD-30077] pRect ��ǥ�� �ȸ´� ���� ����
	{
		pRect->left		= twip2DeviceF(ExtPDFResF(pRect->left, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION); 
		pRect->top		= twip2DeviceF(ExtPDFResF(pRect->top, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION); 
		pRect->right	= twip2DeviceF(ExtPDFResF(pRect->right, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION); 
		pRect->bottom	= twip2DeviceF(ExtPDFResF(pRect->bottom, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION); 
	}	

	if(m_pPathStream)
	{
		XRect rect = {pRect->left, pRect->top, pRect->right, pRect->bottom};
		m_pPathStream->SetFillColor(cFillColor);
		// // [2016.04.18][235][ZPD-30077] Stroke Width�� ���� ����(���� ũ�⺸�� �� ũ�� draw�ϱ� ����)
		m_pPathStream->SetNoneStroke();
		m_pPathStream->Rectangle(rect, true);
		if(cFillColor != m_cBrushcolor)
			BR_SET_STATE(m_nState, eUpdateBrushColorFlag_PDFExtState);
		if(cFillColor != m_cPencolor)
			BR_SET_STATE(m_nState, eUpdatePenColorFlag_PDFExtState);
		if(m_nPenWidth != 1)
			BR_SET_STATE(m_nState, eUpdatePenWidthFlag_PDFExtState);
	}
}

void BPDFExport::fillRect(BrFRect* pRect, BrBOOL bCalcFloat)
{
	// Coverity-16610
	if(pRect == BrNULL)
		return;
	
	if (!bCalcFloat) // �����ڵ�
	{
		pRect->left = twips2DeviceX(Device2twips(pRect->left, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
		pRect->top = twips2DeviceY(Device2twips(pRect->top, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, 0, TARGET_DEVICE_RESOLUTION);
		pRect->right = twips2DeviceX(Device2twips(pRect->right, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
		pRect->bottom = twips2DeviceY(Device2twips(pRect->bottom, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, 0, TARGET_DEVICE_RESOLUTION);
	}
	else // [2016.04.18][235][ZPD-30077] pRect ��ǥ�� �ȸ´� ���� ����
	{
		pRect->left		= twip2DeviceF(ExtPDFResF(pRect->left, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION); 
		pRect->top		= twip2DeviceF(ExtPDFResF(pRect->top, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION); 
		pRect->right	= twip2DeviceF(ExtPDFResF(pRect->right, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION); 
		pRect->bottom	= twip2DeviceF(ExtPDFResF(pRect->bottom, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION); 
	}

	if(m_pPathStream)
	{
		XRect rect = { pRect->left, pRect->top, pRect->right, pRect->bottom };

		if(m_sBrushBitData.nType != eImage_NONE)
			m_pGenerator->getFigureBox(&rect);

		updateDrawAtt();
		m_pPathStream->SetNoneStroke();
		m_pPathStream->Rectangle(rect, true);	
	}	
}

void BPDFExport::rect(BrFRect* pRect, BrBOOL bFill)
{
	// Coverity-16647
	if(pRect==BrNULL)
		return;

	pRect->left = twips2DeviceX(Device2twips(pRect->left, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
	pRect->top = twips2DeviceY(Device2twips(pRect->top, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, 0, TARGET_DEVICE_RESOLUTION);
	pRect->right = twips2DeviceX(Device2twips(pRect->right, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
	pRect->bottom = twips2DeviceY(Device2twips(pRect->bottom, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, 0, TARGET_DEVICE_RESOLUTION);

	if(m_pPathStream)
	{
		XRect rect = {pRect->left, pRect->top, pRect->right, pRect->bottom};
		updateDrawAtt();
		m_pPathStream->Rectangle(rect, (bFill)? true:false);	
	}
}

void BPDFExport::beginPath()
{
	postExport();
	if(m_pGenerator)
	{
		if(!m_bHasClippingPath) // clip path�� ������ �� �ȴ���? clip path ���ο� �����ϰ� �ݾƾ����� �ʾ�?
			endPath();		
		m_pPathStream  = m_pGenerator->BeginPath();

		if(m_pPathStream)
		{
			XRect coord;
			if( m_clipRect && !m_bHasClippingPath) 
			{
				m_pGenerator->ConvPageCoord(m_pGenerator->GetCurrentPageNum(), m_clipRect, &coord);
				m_pPathStream->SetClipRect(&coord);
				m_bHasClippingPath = BrTRUE; // clip rect �ִ��� clip path�� �߻��Ͽ����� true ����
			}
			if(m_pPathStream->applyRotateAndFlip() == errNone)
			{
				XRect bbox = {0,};
				m_pGenerator->getFigureBox(&bbox);
				BrINT pageHeight = m_pGenerator->getPageHeight();

				//[2016.06.01][XPD-2332] pdf export pattern brush�� ������ export ��.
				if(bbox.left == 0 && bbox.top == 0 && bbox.right == 0 && bbox.bottom == 0) //�� ����� ������ �� �ʿ���. �ϴ� bbox�������� m_clipRect �������� export�ϵ��� ���� 
				{
					bbox.left = m_clipRect->left;
					bbox.top = m_clipRect->top;
					bbox.right = m_clipRect->right;
					bbox.bottom = m_clipRect->bottom;
				}

				if(m_sBrushBitData.pBitData && (bbox.right-bbox.left!=0) && (bbox.bottom-bbox.top!=0))
				{
					int xStep = bbox.right - bbox.left;
					int yStep = bbox.bottom - bbox.top;

					if(m_sBrushBitData.bPattern)
					{
						//[2014.03.17] pattern image �� bbox �� pattern image ũ�� ��ŭ�̾�� �� ��.
						bbox.right = bbox.left + m_sBrushBitData.nWidth; 
						bbox.bottom = bbox.top + m_sBrushBitData.nHeight;

						xStep = m_sBrushBitData.nWidth;
						yStep = m_sBrushBitData.nHeight;
					}

					BrFPOINT transOffset = { (BrFLOAT)xStep + m_sBrushBitData.sOffset.x, (BrFLOAT)-(bbox.top - (pageHeight - bbox.bottom) + yStep + m_sBrushBitData.sOffset.y) };
					BrFLOAT mat[6] = {1, 0, 0, 1, transOffset.x, transOffset.y };			

					if(m_sBrushBitData.pAlpha || m_sBrushBitData.bPattern)
					{
						if(m_sBrushBitData.pBitData)
						{
							XBitmap sRGBBit = {0};
							LPBrBITMAPINFOHEADER RGBbuffer = (LPBrBITMAPINFOHEADER)m_sBrushBitData.pBitData;

							sRGBBit.width = m_sBrushBitData.nWidth;
							sRGBBit.height = m_sBrushBitData.nHeight;
							sRGBBit.buffer = GETDATAPOS(RGBbuffer);
							sRGBBit.bytesPerPixel = 3;
							sRGBBit.format = eXBITMAP_RGB888;

							BrBOOL bChanged = BrFALSE;
							// ȸ���� ��Ȳ�� ���� �������� ���� ���� ������ ȸ���� ��Ȳ�� Ȯ������ ���ؼ� Ȯ���� ����
							// word���� cell ä��Ⱑ �׸� ä��Ⱑ �Ұ��ϰ� hwp���� cell ä��⿡ ȸ���� ����.
							// cell ���� �׸������̳� ���� �׸�ä���� brush�� ���� pattern�� �ƴ϶� addimage�� ���´�
							// �׷��ٸ� �� �ڵ带 Ż ���� ���°� �ƴѰ�?
							if((m_nRotateAngle%360!=0 || m_nFlipType != eFigureFlipNone) && !m_sBrushBitData.bEnableRotate)
							{
								BrRect rotbbox = {(BrLONG)bbox.left, (BrLONG)bbox.top, (BrLONG)bbox.right, (BrLONG)bbox.bottom};
								BrRotateBoundary(rotbbox, m_nRotateAngle);
								bbox.left = rotbbox.left; bbox.top = rotbbox.top; bbox.right = rotbbox.right; bbox.bottom = rotbbox.bottom;

								m_pGenerator->setFlipType(eFigureFlipNone);
								m_pGenerator->setRotateAngle(0);
								bChanged = BrTRUE;

								mat[4] = bbox.right-bbox.left;
								mat[5] = -(bbox.top - (pageHeight - bbox.bottom) + (bbox.bottom-bbox.top));
								xStep = bbox.right - bbox.left;
								yStep = bbox.bottom - bbox.top;
							}

							if (m_sBrushBitData.pAlpha)
							{
								XBitmap sAlphaBit = { 0 };

								sAlphaBit.width = m_sBrushBitData.nWidth;
								sAlphaBit.height = m_sBrushBitData.nHeight;
								sAlphaBit.buffer = m_sBrushBitData.pAlpha;
								sAlphaBit.bytesPerPixel = 1;
								sAlphaBit.format = eXBITMAP_RGB888;

								m_pGenerator->AddPattern(&sRGBBit, &sAlphaBit, 1, 1, 2, bbox, xStep, yStep, mat);
							}
							else
								m_pGenerator->AddPattern(&sRGBBit, BrNULL, 1, 1, 2, bbox, xStep, yStep, mat);
								
							if(bChanged)
							{
								m_pGenerator->setFlipType(m_nFlipType);
								m_pGenerator->setRotateAngle(m_nRotateAngle);
							}
						}
					}
					else
					{
						XImage sImage = {0,};
						sImage.width = m_sBrushBitData.nWidth;
						sImage.height = m_sBrushBitData.nHeight;
						sImage.buffer = m_sBrushBitData.pBitData;
						sImage.isHasAlpha = false;

/***					�̰��� raw data�� fd stream ��ü�̴�
						PrBitmap dump;
						PrBitmapFlag et;
						dump.loadImagePtr((char*)m_sBrushBitData.pBitData, m_sBrushBitData.nDataSize,0,0,100,et,0);
						dump.dumpImage(0,0,0);
***/
						if(m_sBrushBitData.bEnableRotate)
							sImage.angle = m_nRotateAngle;

						sImage.format = 	eXIMAGE_JPEG;
						sImage.length = m_sBrushBitData.nDataSize;

						BrBOOL bChanged = BrFALSE;
						if((m_nRotateAngle%360!=0 || m_nFlipType != eFigureFlipNone) && !m_sBrushBitData.bEnableRotate)
						{
							BrRect rotbbox = {(BrLONG)bbox.left, (BrLONG)bbox.top, (BrLONG)bbox.right, (BrLONG)bbox.bottom};
							BrRotateBoundary(rotbbox, m_nRotateAngle); // [2014.03.17] Rotate �� Boundary �ȿ� pattern�� add �ؾ���.
							bbox.left = rotbbox.left; bbox.top = rotbbox.top; bbox.right = rotbbox.right; bbox.bottom = rotbbox.bottom;

							m_pGenerator->setFlipType(eFigureFlipNone);
							m_pGenerator->setRotateAngle(0);
							bChanged = BrTRUE;

							mat[4] = bbox.right-bbox.left;
							mat[5] = -(bbox.top - (pageHeight - bbox.bottom) + (bbox.bottom-bbox.top));
							xStep = bbox.right - bbox.left;
							yStep = bbox.bottom - bbox.top;
						}
						m_pGenerator->AddPattern(&sImage, 1, 1, 2, bbox, xStep, yStep, mat);

						if(bChanged)
						{
							m_pGenerator->setFlipType(m_nFlipType);
							m_pGenerator->setRotateAngle(m_nRotateAngle);
						}
					}
				}				
			}	
		}
	}

}

void BPDFExport::endPath()
{
	if(m_pGenerator && m_pPathStream)
	{
		m_pGenerator->EndPath(m_pPathStream);

		if(m_bHasClippingPath)
		{ // ClippingPath �� �����Ǿ� �ִ� ����� endpath �� �� �� �� ȣ�����ش�.
			m_pGenerator->EndPath(m_pPathStream);
			m_bHasClippingPath = BrFALSE;
		}

		pathAttInit();
		m_pPathStream = BrNULL;
	}
}


void BPDFExport::enforceEndClipPath()
{
	if(m_pGenerator && m_pPathStream && m_bHasClippingPath)
	{
		// ClippingPath �� �����Ǿ� �ִ� ����� ������ ClipPath�� ȣ�����ش�.
		m_pGenerator->EndPath(m_pPathStream);
		m_bHasClippingPath = BrFALSE;
		pathAttInit();
		m_pPathStream = BrNULL;
	}
}

void BPDFExport::endPath(BrBOOL bStrok, BrBOOL bFill)
{
	if(m_pGenerator && m_pPathStream)
	{
		if(!bStrok)
		{
#if 0
			if(m_cPencolor != m_cBrushcolor)
			{
				m_pPathStream->SetStrokeColor(m_cBrushcolor);
			}
			if(m_nPenWidth != 1)
			{
				m_pPathStream->SetStrokeWidth(1);
			}
#endif //0
			m_pPathStream->SetNoneStroke();
		}
		m_pPathStream->endPath(bStrok? true : false, bFill? true : false);
		m_pGenerator->EndPath(m_pPathStream);

		if (m_bHasClippingPath)
		{ // ClippingPath �� �����Ǿ� �ִ� ����� endpath �� �� �� �� ȣ�����ش�.
			m_pGenerator->EndPath(m_pPathStream);
			m_bHasClippingPath = BrFALSE;
		}

		pathAttInit();
		m_pPathStream = BrNULL;
	}
}

//[2012.11.05][ekaloss] PDF ���� Export �� alpha �� ���� �ǵ��� ����.
void BPDFExport::SetGState(BrXPDFGSInfo* pGsInfo)
{
	if( (m_nGstate.nFillOpacity!=pGsInfo->nFillOpacity) || (m_nGstate.nStrokeOpacity!=pGsInfo->nStrokeOpacity) || (!BR_ISSET_STATE(m_nState, eSetGstateFlag_PDFExtState)))
	{
		m_nGstate.nFillOpacity = pGsInfo->nFillOpacity;
		m_nGstate.nStrokeOpacity = pGsInfo->nStrokeOpacity;

		if(m_pGenerator && m_pPathStream)
		{
			m_pGenerator->SetGState(m_pPathStream, pGsInfo);
			BR_REL_STATE(m_nState, eUpdateGstateFlag_PDFExtState);
		}
		else
			BR_SET_STATE(m_nState, eUpdateGstateFlag_PDFExtState);
		BR_SET_STATE(m_nState, eSetGstateFlag_PDFExtState);
	}
}

void BPDFExport::clearImageBrush()
{
	if(m_sBrushBitData.pBitData)
	{
		if(m_sBrushBitData.nType == eImage_DIB)
		{
			LPBrBITMAPINFOHEADER pDIB = (LPBrBITMAPINFOHEADER)m_sBrushBitData.pBitData;
			PrBitmap::freeDIB(pDIB);
		}
		else	
			BrFree(m_sBrushBitData.pBitData);
	}
	memset(&m_sBrushBitData, 0, BrSizeOf(m_sBrushBitData));
}

#define bezierCircle 0.55228475f
void rotatePointByAngle(float &x, float &y, float ang, float cx = 0, float cy = 0)
{
	float tX, tY;
	x = x - cx;
	y = y - cy;
	tX = x * BrCos(ang) - y * BrSin(ang); tY = x * BrSin(ang) + y * BrCos(ang);
	x = tX + cx;
	y = tY + cy;
}

void BPDFExport::closepath()
{
	if(m_pPathStream)
	{
		m_pPathStream->closepath();
	}	
}
void BPDFExport::setCap(BrINT nCap)
{
	if(m_nLineCap != nCap || !BR_ISSET_STATE(m_nState, eSetLineCapFlag_PDFExtState))
	{
		m_nLineCap = nCap;
		if(m_pPathStream)
		{
			m_pPathStream->SetStrokeCapStyle(m_nLineCap);
			BR_REL_STATE(m_nState, eUpdateLineCapFlag_PDFExtState);
		}
		else
			BR_SET_STATE(m_nState, eUpdateLineCapFlag_PDFExtState);
		BR_SET_STATE(m_nState, eSetLineCapFlag_PDFExtState);
	}
}
void BPDFExport::setJoin(BrINT nJoin)
{
	if(m_nLineJoin != nJoin || !BR_ISSET_STATE(m_nState, eSetLineJoinFlag_PDFExtState))
	{
		m_nLineJoin = nJoin;
		if(m_pPathStream)
		{
			m_pPathStream->SetStrokeJoinStyle(m_nLineJoin);
			BR_REL_STATE(m_nState, eUpdateLineJoinFlag_PDFExtState);
		}
		else
			BR_SET_STATE(m_nState, eUpdateLineJoinFlag_PDFExtState);
		BR_SET_STATE(m_nState, eSetLineJoinFlag_PDFExtState);
	}
}

void BPDFExport::ellipse(BrFLOAT x1, BrFLOAT y1, BrFLOAT x2, BrFLOAT y2, BrBOOL bFill, BrBOOL isStroke)
{
	BrFRect fRect = {x1, y1, x2, y2};

	float a0;
	a0 = BrDEGtoRAD(0); //startAngle

	

	float rx = (x2 - x1) / 2;
	float ry = -(y2 - y1) / 2; // Y axis conversion

	float orgX, orgY;
	orgX = (x2 - x1) / (float)2 + x1;
	orgY = (y2 - y1) / (float)2 + y1;

	float mX, mY;
	mX = 1; mY = 0;
	rotatePointByAngle(mX, mY, a0);
	mX = orgX - mX * rx; mY = orgY + mY * ry;
	BrFPOINT startPos = {mX, mY};

	moveTo(&startPos, BrTRUE); // 0 ���� ��ġ��
	arcTo(&fRect, 180, 180, 1, 1, 1); // [ZPD-593][2015.09.10] Dash�� �߰��Ǿ� Export��, ���� �׷��� ������ ���濡 ����  arcTo�� startAngle�� endAngle�� ���� �ٲ���
	//m_pPathStream->endPath((isStroke)?true:false, (bFill)?true:false);
}

void BPDFExport::polygon(LPBrPOINT pOffset, LPBrPOINT lpp, BrUINT32 nCount, BrBOOL isFill, BrBOOL isStroke)
{
	if(m_pPathStream)
	{
		BrPUBLIC_MEMPOOL sMPool = {0};		
		if(BrGetPublicMemPool(sMPool, eNormal_PMPFlag, BrSizeOf(XPoint)*nCount))
		{
			XPoint* pXPos = (XPoint*)sMPool.pMem;
			for(BrUINT i = 0; i < nCount; i++)
			{
				pXPos[i].x = twips2DeviceX(Device2twips(lpp[i].x+pOffset->x, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
				pXPos[i].y = twips2DeviceY(Device2twips(lpp[i].y+pOffset->y, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, 0, TARGET_DEVICE_RESOLUTION);			
			}
			updateDrawAtt();

			if(!isStroke)
			{
#if 0//
				if(m_cPencolor != m_cBrushcolor)
				{
					m_pPathStream->SetStrokeColor(m_cBrushcolor);
					BR_SET_STATE(m_nState, eUpdatePenColorFlag_PDFExtState);
				}
				if(m_nPenWidth != 1)
				{
					m_pPathStream->SetStrokeWidth(1);
					//m_pPathStream->SetStrokeWidth(0);
					BR_SET_STATE(m_nState, eUpdatePenWidthFlag_PDFExtState);

				}
#endif //0
				m_pPathStream->SetNoneStroke();
			}

			m_pPathStream->Polygon(pXPos, nCount, (isFill)? true : false);	
			BrReleasePublicMemPool(&sMPool);
		}		
	}

}

BrBOOL BPDFExport::bezierCurveTo(LPBrFPOINT pPos1, LPBrFPOINT pPos2, LPBrFPOINT pPos3)
{
	if(m_pPathStream && pPos1 && pPos2 && pPos3)
	{
		XCurve cv;

		cv.curve_type = eXPATH_CURVE_TYPE1;
		cv.pos1.x = twip2DeviceF(ExtPDFResF(pPos1->x, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION); 
		cv.pos1.y = twip2DeviceF(ExtPDFResF(pPos1->y, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION); 

		cv.pos2.x = twip2DeviceF(ExtPDFResF(pPos2->x, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION); 
		cv.pos2.y = twip2DeviceF(ExtPDFResF(pPos2->y, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION); 

		cv.pos3.x = twip2DeviceF(ExtPDFResF(pPos3->x, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION); 
		cv.pos3.y = twip2DeviceF(ExtPDFResF(pPos3->y, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION); 

		m_pPathStream->Curve(cv, false);	
		return BrTRUE;
	}	
	return BrFALSE;
}

BrBOOL BPDFExport::polyBezier(LPBrPOINT pos, BrUINT32 nCount, BrBOOL bFill)
{
	return BrFALSE;
}

BrBOOL BPDFExport::polyline(LPBrPOINT pOffset, LPBrPOINT lpp, BrUINT32 nCount)
{
	if(m_pPathStream)
	{
		BrPUBLIC_MEMPOOL sMPool = {0};		
		if(BrGetPublicMemPool(sMPool, eNormal_PMPFlag, BrSizeOf(XPoint)*nCount))
		{
			XPoint* pXPos = (XPoint*)sMPool.pMem;
			for(BrUINT i = 0; i < nCount; i++)
			{
				pXPos[i].x = twips2DeviceX(Device2twips(lpp[i].x+pOffset->x, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
				pXPos[i].y = twips2DeviceY(Device2twips(lpp[i].y+pOffset->y, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, 0, TARGET_DEVICE_RESOLUTION);			
			}
			updateDrawAtt();

			m_pPathStream->Polyline(pXPos, nCount);	 
			BrReleasePublicMemPool(&sMPool);
		}		
	}
	return BrFALSE;
}

void BPDFExport::setFlipType(BrBYTE nFlipType)
{
	if(m_pGenerator)
	{
		m_nFlipType = (BrFigureFlipType)nFlipType;
		m_pGenerator->setFlipType((BrFigureFlipType)nFlipType);
	}
}

void BPDFExport::setFillType(BrBYTE nFillType)
{
	if(m_pGenerator)
		m_pGenerator->setFillType(nFillType);
}

void BPDFExport::setRotateAngle(BrINT nAngle)
{
	if(m_pGenerator)
	{
		m_nRotateAngle = nAngle;
		m_pGenerator->setRotateAngle(nAngle);
	}
}

BrBYTE BPDFExport::arcTo(LPBrFRect pRect, BrINT startAngle, BrINT endAngle, BrBOOL isFill, BrBOOL isStroke,  BrBOOL isClockWise, BrINT32 nTailArrowObjIndex)
{
	// Coverity-16608
	if(pRect==BrNULL)
		return errInvalidParameter;
	
	// [PCD-539][2015.09.15] arcTo�ÿ� Floating ������ ��ǥ���� �����Ѵ�.
	pRect->left = twip2DeviceF(ExtPDFResF(pRect->left, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
	pRect->top = twip2DeviceF(ExtPDFResF(pRect->top, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
	pRect->right = twip2DeviceF(ExtPDFResF(pRect->right, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
	pRect->bottom = twip2DeviceF(ExtPDFResF(pRect->bottom, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
	
	BrINT oristartAngle = startAngle;
	BrINT oriendAngle = endAngle;

	BrFLOAT x1 = pRect->left;
	BrFLOAT y1 = pRect->top;
	BrFLOAT x2 = pRect->right;
	BrFLOAT y2 = pRect->bottom;
	if(x2 < x1)
	{
		BrFLOAT temp;
		temp = x1; x1 = x2; x2 = temp;
	}
	if(y2 < y1)
	{
		BrFLOAT temp;
		temp = y1; y1 = y2; y2 = temp;
	}

	startAngle = startAngle % 360;
	endAngle = endAngle % 360;

	if(startAngle < 0)
		startAngle += 360;
	if(endAngle < 0)
		endAngle += 360;

	bool isChanged = false;
	if(isClockWise)
	{
		if(startAngle <= endAngle)  // [2015.08.07][235] startAngle�� endAngle�� ���� ��� Drawing�� �� �ֵ��� ����
			startAngle += 360;


		BrINT temp;
		temp = startAngle;
		startAngle = endAngle;
		endAngle = temp;
		isChanged = true;
	}else
	{
		if(startAngle >= endAngle)
		{
			endAngle += 360;
		}
	}

	float a0, a1;
	a0 = BrDEGtoRAD(startAngle);
	a1 = BrDEGtoRAD(endAngle);

	BrFLOAT rx = (x2 - x1) / 2;
	BrFLOAT ry = -(y2 - y1) / 2; // Y axis conversion

	BrFLOAT orgX, orgY;
	orgX = (x2 - x1) / 2 + x1;
	orgY = (y2 - y1) / 2 + y1;

	float X0,Y0,X1,Y1,X2,Y2,X3,Y3;
	BrFLOAT sAng = a1 - a0;

	if(sAng == 0 && oristartAngle != oriendAngle)
		sAng = BrDEGtoRAD(360);


	int nCount = floor(sAng / (M_PI / 2));
	float fRemainingAngle = sAng - floor(sAng / (M_PI / 2)) * (M_PI / 2);

	float rRation = ry / rx;

	// curve�� idx�� ������ �ִ� 5���� ������ �����Ͽ�, XPath�� XCurve�� idx�� 1���� �ø�.
	XPath ph1[6]; //= {{eXPATH_MOVE_POINT, (void*)&mv1}, {eXPATH_CURVE_TYPE, (void*)&cv3},{eXPATH_CURVE_TYPE, (void*)&cv4}, {eXPATH_LINE_POINT, (void*)&mv1}};
	XCurve curves[5];
	XPoint mp = {0,0};
	int nPointNum = 0;

	if(nCount > 0)
	{
		float mX, mY;
		mX = 1; mY = 0;
		rotatePointByAngle(mX, mY, a0);
		mX = orgX + mX * rx; mY = orgY + mY * ry;
		//pContents->MoveTo(mX, mY);
		XCurve curve;
		curve.curve_type = eXPATH_CURVE_TYPE1;
		curve.pos1.x = 1; curve.pos1.y = bezierCircle;
		curve.pos2.x = bezierCircle; curve.pos2.y = 1;
		curve.pos3.x = 0; curve.pos3.y = 1;

		rotatePointByAngle(curve.pos1.x, curve.pos1.y, a0);
		rotatePointByAngle(curve.pos2.x, curve.pos2.y, a0);
		rotatePointByAngle(curve.pos3.x, curve.pos3.y, a0);

		curve.pos1.x = orgX + curve.pos1.x * rx;  curve.pos1.y = orgY + curve.pos1.y * ry;
		curve.pos2.x = orgX + curve.pos2.x * rx;  curve.pos2.y = orgY + curve.pos2.y * ry;
		curve.pos3.x = orgX + curve.pos3.x * rx;  curve.pos3.y = orgY + curve.pos3.y * ry;

		//pContents->Curve(curve,true);
		// fill path
		mp.x = mX; mp.y = mY;
		ph1[nPointNum].path_type = eXPATH_MOVE_POINT;
		nPointNum++;


		ph1[nPointNum].path_type = eXPATH_CURVE_TYPE;
		curves[nPointNum-1] = curve;
		nPointNum++;

		if(nCount > 1)
		{
			//pContents->MoveTo(curve.pos3.x, curve.pos3.y);
			curve.curve_type = eXPATH_CURVE_TYPE1;

			curve.pos1.x = -bezierCircle; curve.pos1.y = 1;
			curve.pos2.x = -1; curve.pos2.y = bezierCircle;
			curve.pos3.x = -1; curve.pos3.y = 0;

			rotatePointByAngle(curve.pos1.x, curve.pos1.y, a0);
			rotatePointByAngle(curve.pos2.x, curve.pos2.y, a0);
			rotatePointByAngle(curve.pos3.x, curve.pos3.y, a0);
			curve.pos1.x = orgX + curve.pos1.x * rx;  curve.pos1.y = orgY + curve.pos1.y * ry;
			curve.pos2.x = orgX + curve.pos2.x * rx;  curve.pos2.y = orgY + curve.pos2.y * ry;
			curve.pos3.x = orgX + curve.pos3.x * rx;  curve.pos3.y = orgY + curve.pos3.y * ry;
			//pContents->Curve(curve,true);

			ph1[nPointNum].path_type = eXPATH_CURVE_TYPE;
			curves[nPointNum-1] = curve;
			nPointNum++;

			if(nCount > 2)
			{
				//pContents->MoveTo(curve.pos3.x, curve.pos3.y);
				curve.curve_type = eXPATH_CURVE_TYPE1;

				curve.pos1.x = -1; curve.pos1.y = - bezierCircle;
				curve.pos2.x = -bezierCircle; curve.pos2.y = -1;
				curve.pos3.x = 0; curve.pos3.y = -1;

				rotatePointByAngle(curve.pos1.x, curve.pos1.y, a0);
				rotatePointByAngle(curve.pos2.x, curve.pos2.y, a0);
				rotatePointByAngle(curve.pos3.x, curve.pos3.y, a0);
				curve.pos1.x = orgX + curve.pos1.x * rx;  curve.pos1.y = orgY + curve.pos1.y * ry;
				curve.pos2.x = orgX + curve.pos2.x * rx;  curve.pos2.y = orgY + curve.pos2.y * ry;
				curve.pos3.x = orgX + curve.pos3.x * rx;  curve.pos3.y = orgY + curve.pos3.y * ry;
				//pContents->Curve(curve,true);

				ph1[nPointNum].path_type = eXPATH_CURVE_TYPE;
				curves[nPointNum-1] = curve;
				nPointNum++;

				if(nCount > 3)
				{
					//pContents->MoveTo(curve.pos3.x, curve.pos3.y);
					curve.curve_type = eXPATH_CURVE_TYPE1;
					curve.pos1.x = bezierCircle; curve.pos1.y = -1;
					curve.pos2.x = 1; curve.pos2.y = - bezierCircle;
					curve.pos3.x = 1; curve.pos3.y = 0;

					rotatePointByAngle(curve.pos1.x, curve.pos1.y, a0);
					rotatePointByAngle(curve.pos2.x, curve.pos2.y, a0);
					rotatePointByAngle(curve.pos3.x, curve.pos3.y, a0);
					curve.pos1.x = orgX + curve.pos1.x * rx;  curve.pos1.y = orgY + curve.pos1.y * ry;
					curve.pos2.x = orgX + curve.pos2.x * rx;  curve.pos2.y = orgY + curve.pos2.y * ry;
					curve.pos3.x = orgX + curve.pos3.x * rx;  curve.pos3.y = orgY + curve.pos3.y * ry;
					//pContents->Curve(curve,true);

					ph1[nPointNum].path_type = eXPATH_CURVE_TYPE;
					curves[nPointNum-1] = curve;
					nPointNum++;
				}
			}
		}
	}

	if(fRemainingAngle > 0)
	{
		float fStartAng = nCount * (M_PI / 2) + a0 + fRemainingAngle / 2;

		X0 = BrCos(fRemainingAngle/2);
		Y0 = BrSin(fRemainingAngle/2);


		X1 = (4 - X0) / 3; Y1 = (1 - X0)*(3 - X0) / (3 * Y0);
		X3 = X0; Y3 = - Y0;
		X2 = X1; Y2 = - Y1;

		rotatePointByAngle(X0, Y0, fStartAng);
		rotatePointByAngle(X1, Y1, fStartAng);
		rotatePointByAngle(X2, Y2, fStartAng);
		rotatePointByAngle(X3, Y3, fStartAng);

		//
		X0 *= rx; Y0 *= ry;
		X1 *= rx; Y1 *= ry;
		X2 *= rx; Y2 *= ry;
		X3 *= rx; Y3 *= ry;


		X0 += orgX; Y0 += orgY;
		X1 += orgX; Y1 += orgY;
		X2 += orgX; Y2 += orgY;
		X3 += orgX; Y3 += orgY;

		//pContents->MoveTo(X0,Y0);
		XCurve curve;
		curve.curve_type = eXPATH_CURVE_TYPE1;
		curve.pos1.x = X1; curve.pos1.y = Y1;
		curve.pos2.x = X2; curve.pos2.y = Y2;
		curve.pos3.x = X3; curve.pos3.y = Y3;

		if(nPointNum != 0)
		{
			curve.pos3.x = X0; curve.pos3.y = Y0;
			XPoint temp;
			temp = curve.pos1; curve.pos1 = curve.pos2; curve.pos2 = temp;
		}

		//pContents->Curve(curve, true);

		if(nPointNum == 0)
		{
			isChanged = !isChanged;
			mp.x = X0; mp.y = Y0;
			ph1[nPointNum].path_type = eXPATH_MOVE_POINT;
			nPointNum++;
		}
		ph1[nPointNum].path_type = eXPATH_CURVE_TYPE;
		curves[nPointNum-1] = curve;
		nPointNum++;
	}

	{
	ph1[0].pData = &mp;
	for(int i = 1; i < nPointNum; i++)
		ph1[i].pData = &curves[i-1];

	//reverse
	if(isChanged)
	{
		BArray<XPoint> pointAry;
		for(int i = nPointNum - 1; i >= 1; i--)
		{
			XCurve curve = *(XCurve*)ph1[i].pData;
			pointAry.Add(curve.pos3);
			pointAry.Add(curve.pos2);
			pointAry.Add(curve.pos1);
		}
		pointAry.Add(*(XPoint*)ph1[0].pData);
		mp = *pointAry.GetAt(0);
		ph1[0].pData = &mp;
		for(int i = 0; i < (pointAry.GetSize() - 1) / 3; i++)
		{
			curves[i].pos1 = *pointAry.GetAt(1 + 3 * i);
			curves[i].pos2 = *pointAry.GetAt(1 + 3 * i + 1);
			curves[i].pos3 = *pointAry.GetAt(1 + 3 * i + 2);
			ph1[1 + i].pData = &curves[i];
		}
	}

	// MoveTo

	if(nTailArrowObjIndex != -1)
		m_pPathStream->MoveTo(mp.x, mp.y);

	m_pPathStream->LineTo(mp.x, mp.y, false);
	//m_pPathStream->Shape(ph1, nPointNum, isStroke, isFill, false);       
	for (int i = 0; i < nPointNum; i++)
	{
		switch(ph1[i].path_type)
		{
		case eXPATH_MOVE_POINT:
			{
				XPoint pt = *(XPoint*)(ph1[i].pData);
				if(pt.x !=mp.x || pt.y !=mp.y)
					m_pPathStream->MoveTo(pt);
				break;
			}
		case eXPATH_LINE_POINT:
			{
				XPoint pt = *(XPoint*)(ph1[i].pData);
				m_pPathStream->LineTo(pt, false);
				break;
			}
		case eXPATH_CURVE_TYPE:
			{
				XCurve cv = *(XCurve*)(ph1[i].pData);
				m_pPathStream->Curve(cv, false);
				break;
			}
		default:
			return errInvalidParameter;
		}
	}

	}

//last point
//XCurve curve = curves[nPointNum-2];
//m_pPathStream->MoveTo(curve.pos3.x, curve.pos3.y);

return errNone;
}

BrBOOL BPDFExport::setImageBrush(LPBrBITMAPINFOHEADER pDIB, BrBYTE* pAlpha, BrBOOL bFixedRatio, BrBOOL bEnableRotate, BrBOOL bPattern/* = BrFALSE*/, BrFLOAT fRatioX /*= 100.f*/, BrFLOAT fRatioY/* = 100.f*/)
{
	clearImageBrush();

	if(pDIB)
	{
		PrBitmap SrcBitmap;
		SrcBitmap.setDib(pDIB, BrTRUE);

		PrBitmap sBrushBitmap;

		//[2016.06.02][XPD-2210] ǥ�� ä��⸦ �׸����� ���� �� pdf export �� �뷮�� ������������ Ŀ���� ����
		//������ ��� fRatio �� ��� �������� �� ��� �������� �Ȱ��� export ��
		if(bPattern && (fRatioX != 100.f || fRatioY != 100.f))
		{
			BrINT nNewWidth = pDIB->biWidth * (fRatioX/100.0);
			BrINT nNewHeight = pDIB->biHeight * (fRatioY/100.0);

			BrBOOL nRet = SrcBitmap.scaleEx(nNewWidth, nNewHeight, &sBrushBitmap);
			if(!nRet)
				sBrushBitmap = SrcBitmap;

			XRect bbox = {0,};
			m_pGenerator->getFigureBox(&bbox);
			if(bbox.right- bbox.left != 0 && bbox.bottom-bbox.top != 0 && bbox.right - bbox.left < sBrushBitmap.cx() && bbox.bottom-bbox.top < sBrushBitmap.cy())
			{
				//bbox�� �����Ǿ� �ְ�, �� ���� �ƴ� ��쿡�� bbox ������ ��ŭ�� crop �ؼ� export �ϵ��� ���� ( �뷮 ������ )
				BRect rBBOX(0,0,bbox.right-bbox.left, bbox.bottom-bbox.top);
				BrBOOL bSuccessCrop = sBrushBitmap.crop(rBBOX);
				if(!bSuccessCrop)
					BRTHREAD_ASSERT(0);
			}
		}
		else
			sBrushBitmap = SrcBitmap;

#ifndef USE_32BIT_IMAGE
		if(pAlpha)
		{
			LPBrBITMAPINFOHEADER pDIBBit = BrNULL;
			//sBrushBitmap.convertDIB_SYSM(eBGR888Bitmap, BrFALSE, &pDIBBit);
			sBrushBitmap.convertDIB(eBGR888Bitmap, BrFALSE, &pDIBBit);
			if(!pDIBBit)
				return BrFALSE;
			m_sBrushBitData.pBitData = (BrBYTE*)pDIBBit;
			m_sBrushBitData.nType = eImage_DIB;
		}
#else
		if(pDIB->biBitCount == 32 && sBrushBitmap.isHasAlphaBit())
		{
			LPBrBITMAPINFOHEADER pDIBBit = BrNULL;
			LPBrBITMAPINFOHEADER pMaskBit = BrNULL;

			//sBrushBitmap.convertDIB_SYSM(eBGR888Bitmap, BrTRUE, &pDIBBit, &pMaskBit);
			sBrushBitmap.convertDIB(eBGR888Bitmap, BrTRUE, &pDIBBit, &pMaskBit);
			if(!pDIBBit)
				return BrFALSE;
			m_sBrushBitData.pBitData = (BrBYTE*)pDIBBit;
			if(pMaskBit)
				m_sBrushBitData.pAlpha = GETDATAPOS(pMaskBit);
			m_sBrushBitData.nType = eImage_DIB;
		}
#endif //USE_32BIT_IMAGE
		else
		{
			if(bPattern) // ������ ��� jpeg ���� ���� �� �ս� ����� �����Ƿ� dib�� �������� �Ѵ�.
			{
				LPBrBITMAPINFOHEADER pDIBBit = BrNULL;
				//sBrushBitmap.convertDIB_SYSM(eBGR888Bitmap, BrTRUE, &pDIBBit);
				sBrushBitmap.convertDIB(eBGR888Bitmap, BrTRUE, &pDIBBit);

				if(!pDIBBit)
					return BrFALSE;
				m_sBrushBitData.pBitData = (BrBYTE*)pDIBBit;
				m_sBrushBitData.nType = eImage_DIB;
			}
			else
			{
				BrDWORD nJPEGSize = 0;	
				if(sBrushBitmap.getBitCount() < 16)
				{
					PrBitmap s16Bitmap;				
					s16Bitmap.createBitmap(sBrushBitmap.cx(), sBrushBitmap.cy());
					s16Bitmap.bitBlt(0, 0, &sBrushBitmap, 0, 0, sBrushBitmap.cx(), sBrushBitmap.cy());
					m_sBrushBitData.pBitData = (BrBYTE*)s16Bitmap.save(eImage_JPEG, &nJPEGSize);
					if(!m_sBrushBitData.pBitData)
						return BrFALSE;

				}
				else
				{
					m_sBrushBitData.pBitData = (BrBYTE*)sBrushBitmap.save(eImage_JPEG, &nJPEGSize);
					if(!m_sBrushBitData.pBitData)
						return BrFALSE;
				}
				m_sBrushBitData.nDataSize = nJPEGSize;
				m_sBrushBitData.nType = eImage_JPEG;
			}

		}
		m_sBrushBitData.bEnableRotate = bEnableRotate;
		m_sBrushBitData.bFixedRatio = bFixedRatio;

		if (m_pGenerator && bPattern == BrFALSE)
		{
			XRect bbox = { 0, };
			m_pGenerator->getFigureBox(&bbox);

			// ���� �ڵ�ó�� ����ع����� Ȯ��� ȭ���� �ʹ� ��������. ������ ������ ����ϵ�
			// PO���� zoom�� 400%���� �����ϱ� 4�� �̻��� ��쿣 �޸� ��뷮 ���� �����ؼ� ���ع�����
			sBrushBitmap.scaleEx(BrMIN((bbox.right - bbox.left)*4, sBrushBitmap.cx()), BrMIN((bbox.bottom - bbox.top) * 4, sBrushBitmap.cy()), &sBrushBitmap);
		}
		m_sBrushBitData.nWidth = sBrushBitmap.cx();
		m_sBrushBitData.nHeight = sBrushBitmap.cy();

#ifndef USE_32BIT_IMAGE
		m_sBrushBitData.pAlpha = pAlpha;	
#endif //USE_32BIT_IMAGE

		return BrTRUE;		
	}
	return BrFALSE;
}

BrBOOL  BPDFExport::setImagePatternBrush(LPBrBITMAPINFOHEADER pDIB, BrBYTE* pAlpha, BrFLOAT fRatioX, BrFLOAT fRatioY, BrINT nFillType, BrBOOL bEnableRotate, LPBrPOINT pOffset)
{
	if(setImageBrush(pDIB, pAlpha, BrFALSE, bEnableRotate, BrTRUE, fRatioX, fRatioY))
	{
		if(pOffset)
		{
			m_sBrushBitData.sOffset.x = pOffset->x;
			m_sBrushBitData.sOffset.y = pOffset->y;
		}
		//setImageBrush ���ο��� fRatio��� ������ ���ֵ��� �����߱� ������ 100���� set
		m_sBrushBitData.fRatioX = 100.f;
		m_sBrushBitData.fRatioY = 100.f;

		m_sBrushBitData.nPatternFlip = nFillType;
		m_sBrushBitData.bPattern = BrTRUE;
		return BrTRUE;		
	}
	return BrFALSE;
}

void BPDFExport::clearBrush()
{
	clearImageBrush();
	m_cBrushcolor = WHITE_COLOR;	//[[dwchun : 2012.08.24] : Export�� XStream�� Color���� "B"(Block)�̱� ������ �⺻ ���� Block���� ���� ��
	BR_REL_STATE(m_nState, eSetBrushColorFlag_PDFExtState);
}

void BPDFExport::setfigureBox(LPBrRect rcFigure)
{
	// Coverity-16596
	if(rcFigure == BrNULL)
		return;

	rcFigure->left = twips2DeviceX(Device2twips(rcFigure->left, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
	rcFigure->top = twips2DeviceY(Device2twips(rcFigure->top, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, 0, TARGET_DEVICE_RESOLUTION);
	rcFigure->right = twips2DeviceX(Device2twips(rcFigure->right, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
	rcFigure->bottom = twips2DeviceY(Device2twips(rcFigure->bottom, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, 0, TARGET_DEVICE_RESOLUTION);
	
	if(m_pGenerator)
		m_pGenerator->setFigureBox(rcFigure);
}



void BPDFExport::setFontIncrement(BrINT nIndex)
{
	m_pGenerator->setFontIncrementValue(nIndex);
}

BrRect BPDFExport::setClipRect(BrRect* pRect)
{
	BrRect oldRect = {0, 0, 0, 0};

	if( m_clipRect )
	{
		oldRect.left = twips2DeviceX(Device2twips(m_clipRect->left, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
		oldRect.top = twips2DeviceY(Device2twips(m_clipRect->top, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, 0, TARGET_DEVICE_RESOLUTION);
		oldRect.right = twips2DeviceX(Device2twips(m_clipRect->right, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
		oldRect.bottom = twips2DeviceY(Device2twips(m_clipRect->bottom, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, 0, TARGET_DEVICE_RESOLUTION);

		m_clipRect->left = twips2DeviceX(Device2twips(pRect->left, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
		m_clipRect->top = twips2DeviceY(Device2twips(pRect->top, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, 0, TARGET_DEVICE_RESOLUTION);
		m_clipRect->right = twips2DeviceX(Device2twips(pRect->right, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
		m_clipRect->bottom = twips2DeviceY(Device2twips(pRect->bottom, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, 0, TARGET_DEVICE_RESOLUTION);
	}

	return oldRect;
}

void BPDFExport::restoreClipRect()
{
}

void BPDFExport::addStickyNote(BoraStickyNoteInfo* annotInfo)
{
	BrINT nCurPage = m_pGenerator->GetCurrentPageNum();
	XRect rectAnnot = {(float)annotInfo->nXPos, (float)annotInfo->nYPos, (float)(annotInfo->nXPos+STICKY_NOTE_WIDTH), (float)(annotInfo->nYPos+STICKY_NOTE_HEIGHT)};
	XRect rectPopup = {(float)annotInfo->nPopupXPos, (float)annotInfo->nPopupYPos, (float)(annotInfo->nPopupXPos+STICKY_NOTE_POPUP_WIDTH), (float)(annotInfo->nPopupYPos+STICKY_NOTE_POPUP_HEIGHT)};

	rectAnnot.left = twips2DeviceX(Device2twips(rectAnnot.left, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
	rectAnnot.top = twips2DeviceX(Device2twips(rectAnnot.top, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
	rectAnnot.right = rectAnnot.left+STICKY_NOTE_WIDTH;
	rectAnnot.bottom = rectAnnot.top+STICKY_NOTE_HEIGHT;

	rectPopup.left = twips2DeviceX(Device2twips(rectPopup.left, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
	rectPopup.top = twips2DeviceX(Device2twips(rectPopup.top, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
	rectPopup.right = rectPopup.left + STICKY_NOTE_POPUP_WIDTH;
	rectPopup.bottom = rectPopup.top + STICKY_NOTE_POPUP_HEIGHT;

	XStickyNote stickyNote;
	XAnnotPopup annotPopup;
	memset(&stickyNote, 0, BrSizeOf(stickyNote));
	memset(&annotPopup, 0, BrSizeOf(annotPopup));

	// Annot Popup Set
	annotPopup.open = annotInfo->bOpen;
	annotPopup.rect = rectPopup;
	annotPopup.szAuthor = annotInfo->pszAuthor;
	annotPopup.nAuthorLen = annotInfo->nAuthorLen;
	annotPopup.szContents = annotInfo->pszNoteContents;
	annotPopup.nContentsLen = annotInfo->nNoteContentsLen;
	annotPopup.szSubject = annotInfo->pszSubject;
	annotPopup.nSubjectLen = annotInfo->nSubjectLen;
	annotPopup.type = ePDF_ANNOT_POPUP;
	annotPopup.flag = 28;

	// StickyNote Set
	stickyNote.popup = &annotPopup;
	stickyNote.rect = rectAnnot;
	stickyNote.szAuthor = annotInfo->pszAuthor;
	stickyNote.nAuthorLen = annotInfo->nAuthorLen;
	stickyNote.szContents = annotInfo->pszNoteContents;
	stickyNote.nContentsLen = annotInfo->nNoteContentsLen;
	stickyNote.szSubject = annotInfo->pszSubject;
	stickyNote.nSubjectLen = annotInfo->nSubjectLen;
	stickyNote.szCreationDate = annotInfo->pszCreationDate;
	stickyNote.szLabel = "label";
	stickyNote.type = ePDF_ANNOT_TEXT;
	stickyNote.colorNum = 3;
	stickyNote.colors = (float*)BrMalloc(BrSizeOf(float)*3);
	*(stickyNote.colors + 0) = 1.0;
	*(stickyNote.colors + 1) = 0.5;
	*(stickyNote.colors + 2) = 0.0;
	stickyNote.flag = 28;

	m_pGenerator->AddStickyNoteToPage(nCurPage, &stickyNote);

	BrFree(stickyNote.colors);
}

void BPDFExport::addFreeTextAnnot(BoraFreetextAnnotInfo* annotInfo)
{
	BrINT nCurPage = m_pGenerator->GetCurrentPageNum();

	// FreeTextAnnot Set
	XFreeText freeTextBox;
	memset(&freeTextBox, 0, BrSizeOf(freeTextBox));

	freeTextBox.type = ePDF_ANNOT_FREETEXT;

	// Text Content
	freeTextBox.szText = annotInfo->szText;
	freeTextBox.nTextLen = annotInfo->nTextLen;

	// Author
	freeTextBox.szAuthor = annotInfo->pszAuthor;
	freeTextBox.nAuthorLen = annotInfo->nAuthorLen;

	// Subj
	freeTextBox.szSubject = annotInfo->pszSubject;
	freeTextBox.nSubjectLen = annotInfo->nSubjectLen;

	// CreationDate
	freeTextBox.szCreationDate = annotInfo->pszCreationDate;

	// Rect
	XRect freeTextRect;
	freeTextRect.left = twips2DeviceX(Device2twips(annotInfo->nLeft, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
	freeTextRect.top = twips2DeviceX(Device2twips(annotInfo->nTop, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
	freeTextRect.right = twips2DeviceX(Device2twips(annotInfo->nRight, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
	freeTextRect.bottom = twips2DeviceX(Device2twips(annotInfo->nBottom, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
	freeTextBox.rect = freeTextRect;

	// Border Widtth
	freeTextBox.width = twip2DeviceF(annotInfo->borderWidth, gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);

	// Border Color
	{
		freeTextBox.Bordercolors = (float*)BrMalloc(BrSizeOf(float) * 3);
		*(freeTextBox.Bordercolors + 0) = GetBrRValue(annotInfo->borderColor);
		*(freeTextBox.Bordercolors + 1) = GetBrGValue(annotInfo->borderColor);
		*(freeTextBox.Bordercolors + 2) = GetBrBValue(annotInfo->borderColor);
	}

	// Fill Color
	if (annotInfo->bgColor != NONE_COLOR_BITS)
	{
		freeTextBox.colorNum = 3;
		freeTextBox.colors = (float*)BrMalloc(BrSizeOf(float) * 3);
		*(freeTextBox.colors + 0) = GetBrRValue(annotInfo->bgColor);
		*(freeTextBox.colors + 1) = GetBrGValue(annotInfo->bgColor);
		*(freeTextBox.colors + 2) = GetBrBValue(annotInfo->bgColor);
	}

	// Font Color
	if (m_sTextAtt.nColor)
		freeTextBox.fontColors = m_sTextAtt.nColor;

	// Font Size
	freeTextBox.fontSize = m_sTextAtt.nFontSize;

	m_pGenerator->AddFreeTextAnnotToPage(nCurPage , &freeTextBox);

	// Color Free
	BrFree(freeTextBox.colors);
	BrFree(freeTextBox.Bordercolors);
}

#ifdef USE_PDFEXPORT_INKANNOT
void BPDFExport::addInkAnnot(BoraInkAnnotInfo* annotInfo)
{
	BrINT nCurPage = m_pGenerator->GetCurrentPageNum();
	XRect pageRect = { 0, };
	m_pGenerator->GetPageRect(nCurPage, &pageRect);

	// USE_PDFEXPORT_INKANNOT ������ ����ϸ� EMO-1700 �̽� �߻����� ���Ƿ� Width ���� �����Ѵ�.
	// std �� ���� ������ ���� �ʱ� ������ Device2tiwpsF  �� ���� üũ �� Width ���� 1/10 �� ���ҽ�Ű�� ������� �켱 üũ.
	// Max - 12 ,  Min - 1 �� üũ�ϰ� �ֱ� ������ �ش� ������ ���� ����
	BrFLOAT fTwip = Device2twipsF(annotInfo->nWidth, gpPaint->zoom.m_iScale, getExportPDFRes());
	fTwip = ( fTwip / 10 ) * 9;

	BrFLOAT width = BrMAX(BrMIN(twip2DeviceF(fTwip, gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION), 12), 1);

	XRect rectAnnot = {(float)annotInfo->nLeft, (float)annotInfo->nTop, (float)(annotInfo->nRight), (float)(annotInfo->nBottom)};
	XRect rectPopup = {(float)(pageRect.right)
		, (float)twip2DeviceF(Device2twipsF(annotInfo->nTop, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION)
		, (float)(pageRect.right) + STICKY_NOTE_POPUP_WIDTH
		, (float)twip2DeviceF(Device2twipsF(annotInfo->nTop, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION) + STICKY_NOTE_POPUP_HEIGHT};

	rectAnnot.left = twip2DeviceF(Device2twipsF(rectAnnot.left, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION) - width;
	rectAnnot.top = twip2DeviceF(Device2twipsF(rectAnnot.top, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION) - width;
	rectAnnot.right = twip2DeviceF(Device2twipsF(rectAnnot.right, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION) + width;
	rectAnnot.bottom = twip2DeviceF(Device2twipsF(rectAnnot.bottom, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION) + width;

	XInk inkAnnot;
	XAnnotPopup annotPopup;
	memset(&inkAnnot, 0, BrSizeOf(inkAnnot));
	memset(&annotPopup, 0, BrSizeOf(annotPopup));

	// Annot Popup Set
	annotPopup.open = annotInfo->bOpen;
	annotPopup.rect = rectPopup;
	annotPopup.szAuthor = annotInfo->pszAuthor;
	annotPopup.nAuthorLen = annotInfo->nAuthorLen;
	annotPopup.szContents = annotInfo->pszNoteContents;
	annotPopup.nContentsLen = annotInfo->nNoteContentsLen;
	annotPopup.szSubject = annotInfo->pszSubject;
	annotPopup.nSubjectLen = annotInfo->nSubjectLen;
	annotPopup.type = ePDF_ANNOT_POPUP;
	annotPopup.flag = 28;

	// inkAnnot Set
	inkAnnot.popup = &annotPopup;
	inkAnnot.rect = rectAnnot;
	inkAnnot.szAuthor = annotInfo->pszAuthor;
	inkAnnot.nAuthorLen = annotInfo->nAuthorLen;
	inkAnnot.szContents = annotInfo->pszNoteContents;
	inkAnnot.nContentsLen = annotInfo->nNoteContentsLen;
	inkAnnot.szSubject = annotInfo->pszSubject;
	inkAnnot.nSubjectLen = annotInfo->nSubjectLen;
	inkAnnot.szCreationDate = annotInfo->pszCreationDate;
	inkAnnot.type = ePDF_ANNOT_INK;
	inkAnnot.colorNum = 3;
	inkAnnot.colors = (float*)BrMalloc(BrSizeOf(float)*3);
	*(inkAnnot.colors + 0) = GetBrRValue(annotInfo->fColor);
	*(inkAnnot.colors + 1) = GetBrGValue(annotInfo->fColor);
	*(inkAnnot.colors + 2) = GetBrBValue(annotInfo->fColor);
	// GetBrAValue�� USE_32BIT_IMAGE off�� 0xff�� �����̴���
	inkAnnot.ca = (annotInfo->fColor >> BrP32SHIFTBIT_A) & 0xFF;
	inkAnnot.flag = 4;
	inkAnnot.inkList = (BArray<LPBDrawingTrace>*)BrNEW BArray<LPBDrawingTrace>;//annotInfo->inkList;
	inkAnnot.width = width;

	BDrawingTrace * pTrace = BrNULL;
	LPBDrawingTrace curr = BrNULL;
	BrINT nCount = 0;
	BrINT i = 0;
	BrINT j = 0;
	
	for(i = 0; i < ((BArray<LPBDrawingTrace>*)annotInfo->inkList)->GetSize(); i++)
	{
		curr = ((BArray<LPBDrawingTrace>*)annotInfo->inkList)->at(i);
		nCount = curr->m_nPoint;

		if(nCount > 0)
		{
			pTrace = BrNEW BDrawingTrace;
			pTrace->m_nPoint = nCount;
			pTrace->m_pDrawingTraceXY = (BrFPOINT*)BrMalloc(BrSizeOf(BrFPOINT)*nCount);

			for(j = 0; j < nCount; j++)
			{
				pTrace->m_pDrawingTraceXY[j].x = twip2DeviceF(Device2twipsF(curr->m_pDrawingTraceXY[j].x, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
				pTrace->m_pDrawingTraceXY[j].y = twip2DeviceF(Device2twipsF(curr->m_pDrawingTraceXY[j].y, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
			}

			inkAnnot.inkList->Add(pTrace);
		}
	}

	inkAnnot.offset.x = twip2DeviceF(Device2twipsF(annotInfo->offsetX, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
	inkAnnot.offset.y = twip2DeviceF(Device2twipsF(annotInfo->offsetY, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);

	m_pGenerator->addInkToPage(nCurPage, &inkAnnot);

	BrFree(inkAnnot.colors);

	for(i = 0; i < ((BArray<LPBDrawingTrace>*)inkAnnot.inkList)->GetSize(); i++)
	{
		curr = ((BArray<LPBDrawingTrace>*)inkAnnot.inkList)->at(i);
		BR_SAFE_FREE(curr->m_pDrawingTraceXY);
	}
	inkAnnot.inkList->RemoveAll();
}
#endif // USE_PDFEXPORT_INKANNOT

void BPDFExport::addHyperlink(BoraHyperlinkInfo* annotInfo)
{
	BrINT nSrcPage = annotInfo->nSourcePageNum;
	// the rect of the hyperlink area
	XRect hyperlinkRect;
	
	hyperlinkRect.left = twips2DeviceX(Device2twips(annotInfo->nLeft, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);//annotInfo->nLeft; 
	hyperlinkRect.top = twips2DeviceX(Device2twips(annotInfo->nTop, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
	hyperlinkRect.right = twips2DeviceX(Device2twips(annotInfo->nRight, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
	hyperlinkRect.bottom = twips2DeviceX(Device2twips(annotInfo->nBottom, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);

	XHyperlink hyperlink;
	hyperlink.type = ePDF_ANNOT_HYPERLINK;
	if(annotInfo->nType == TYPE_GOTO)
	{
		hyperlink.actionKind = actionGoTo;
		hyperlink.destKind = destXYZ;
		hyperlink.left = twips2DeviceX(Device2twips(annotInfo->nTargetXPos, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
		hyperlink.top = twips2DeviceX(Device2twips(annotInfo->nTargetYPos, gpPaint->zoom.m_iScale, getExportPDFRes()), gpPaint->zoom.m_iScale, TARGET_DEVICE_RESOLUTION);
		hyperlink.pageRef.num = m_pGenerator->getPageEntryNum(annotInfo->nTargetPageNum);
		hyperlink.pageRef.gen = 0;
	}
	else if(annotInfo->nType == TYPE_URI)
	{
		hyperlink.actionKind = actionURI;
		hyperlink.uri = annotInfo->pszURI;
	}
	hyperlink.border = 0;
	hyperlink.rect = hyperlinkRect;

	m_pGenerator->addHyperlinkToPage(nSrcPage, &hyperlink);

}
BrINT BPDFExport::getCurPageNum()
{
	if(m_pGenerator)
		return m_pGenerator->GetCurrentPageNum();
	else
		return 0;
}

void BPDFExport::beginClipPath()
{
	if(m_pGenerator)
		m_pPathStream  = m_pGenerator->BeginPath();
}
void BPDFExport::endClipPath(BrBYTE ClipRule)
{
	if(m_pPathStream && m_pGenerator)
	{
		m_pPathStream->endClipPath(ClipRule);
		m_bHasClippingPath = BrTRUE;
	}
}

// ���ο��� buf �� ����
// ȣ���������� free ���־�� ��
char* BPDFExport::BStringToUTF8(BString& src)
{
	if (src == NULL || src.length() <= 0)
		return NULL;

	int nBufLen = src.length() * 3 + 1;
	char* buf = (char*) BrMalloc(nBufLen);	// CJK Char �� �����Ͽ� ����� �Ҵ�
	if (buf == NULL)
	{
		SET_ERROR((PoError)kPoErrMemory, "");

		return NULL;
	}

	int nLen = 0;
	for(unsigned int i = 0; i <src.length(); i++)
	{
		unsigned short code = src.at(i).unicode();
		if (code < 0x80) {
			buf[nLen++] = (char)code;
		}
		else if (code < 0x800) {
			buf[nLen++] = (0xC0 | code >> 6);
			buf[nLen++] = (0x80 | code & 0x3F);
		}
		else/* if (c < 0x10000)*/ {
			buf[nLen++] = (0xE0 | code >> 12);
			buf[nLen++] = (0x80 | code >> 6 & 0x3F);
			buf[nLen++] = (0x80 | code & 0x3F);
		}
		//else if (c < 0x200000) {
		//	putchar (0xF0 | c>>18);
		//	putchar (0x80 | c>>12 & 0x3F);
		//	putchar (0x80 | c>>6 & 0x3F);
		//	putchar (0x80 | c & 0x3F);
		//}
	}
	buf[nLen] = 0;

	return buf;
}

#endif //EXPORT_PDF
