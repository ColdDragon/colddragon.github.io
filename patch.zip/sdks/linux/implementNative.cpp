#include "implementNative.h"

#include "nativeStringUtil.h"
#include "nativeCallback.h"
#include "native.h"
#include "debugJni.h"
#include "jniHeader.h"
#include "loadUcnv.h"
//#include "bmvfuncinterface.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <assert.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <fcntl.h>

#ifdef BASED_WINDOWS_SYSTEM
	#include <Windows.h.>
	#include <direct.h>
#ifdef _UNICODE
	#include <wchar.h>
#endif
	#include <io.h>
#else
	#include <unistd.h>
	#include <sys/times.h>
	#include <sys/time.h>
	//#include <linux/rtc.h>
	#include <dirent.h>
	#include <locale.h>
	#include <sys/sysinfo.h>
	#include <wchar.h>
#endif 

#ifdef LINUX_LIB
#include "PWordLibrary/PWordControl/EngineInterface/PEngine.h"
#endif

#ifdef __cplusplus 
extern "C" {
#endif
#ifdef _WIN32
wchar_t* UTF8ToCString(const char* pBuffer)
{
	int nSize= strlen(pBuffer);
	wchar_t *pOutput = new wchar_t[nSize+1];
	memset(pOutput, 0, sizeof(wchar_t)*(nSize+1));
	int nLength = MultiByteToWideChar(CP_UTF8, 0, pBuffer, nSize, pOutput, sizeof(wchar_t)*nSize);
	pOutput[nLength] = '\0';
	return pOutput;
}

char* UnicodeToUTF8(wchar_t* str, BOOL bUTF8)
{
	char* pBuffer = NULL;
	if ( str != NULL && wcslen(str) > 0 )
//	if ( !str.IsEmpty() && str.GetLength() > 0 )
	{
		pBuffer = (char*)malloc(wcslen(str)*3);
		memset(pBuffer, 0, wcslen(str)*3);
		WideCharToMultiByte(bUTF8?CP_UTF8:CP_ACP, 0, (LPWSTR)(LPCWSTR)str, wcslen(str), pBuffer, wcslen(str)*2, 0, 0);
	}
	return pBuffer;
}
#endif //_WIN32
///////// font path, bookmark path, heap size  ///////
#define PATH_MAX 1024
static char gFontPath[PATH_MAX] = "";
static char gTempPath[PATH_MAX] = "";

void	  impNativeSetTempPath(JNIEnv* env, jstring tempPath){
	int nLen = CopyJstring2Utf8(env, gTempPath, tempPath, PATH_MAX);
#if 0//def UI_DEBUG
	char logPath[1024];
	sprintf(logPath,"%s/TracePoLibrary.log",gTempPath);
	ui_debug_setLogFileName(logPath);
#endif
}

#ifndef BRMAX_EXTENSION_LENGTH
	#define BRMAX_EXTENSION_LENGTH 32	// btypes.h 
#endif

static char gFileExt[BRMAX_EXTENSION_LENGTH];
void	  impNativeSetFileExt(JNIEnv* env, jstring fileExt){
	int nLen = CopyJstring2Utf8(env, gFileExt, fileExt, BRMAX_EXTENSION_LENGTH);

	if(nLen > 0)
	{
		for(int i=0; gFileExt[i] != NULL; i++)
		{
			if(gFileExt[i] >= 'A' && gFileExt[i] <= 'Z')
				gFileExt[i] = (gFileExt[i]-'A') +'a';
		}
	}
}

#ifdef SUPPORT_GET_FILE_EXTENSION_BY_EXTERNAL
int BGetDocumentFileExtension(char* strExt)
{
	strncpy(strExt, gFileExt, BRMAX_EXTENSION_LENGTH);
	return strlen(strExt);
}
#endif 

////
////void	  impNativeSetBookMarkPath(JNIEnv* env, jstring bookMarkPath){
////	int nLen = CopyJstring2Utf8(env, gBookmarkPath, bookMarkPath, PATH_MAX);
////	if(nLen) // nLen �� PATH_MAX - borainfo.dat ���� ũ�� �ȵ�. �������ϱ?�ϴ� �н�
////		BrStrCat(gBookmarkPath, "borainfo.dat", PATH_MAX);
////		//strcat(gBookmarkPath, "borainfo.dat");
////
////	ui_debug("impNativeSetTempPath = %s\n", gBookmarkPath);	
////}
//
//
static int gHeapSize = 16;
static int gExternNumOfAvailableCores = 0;
static int gDividePrintImageHeight = 0;
static int gXlsPageToBitmapMaxRow = -1;
static int gPDFWithAnnotaion = true;
//
////char* impNativeGetFontPathBuffer(){ return gFontPath; }
////char* impNativeGetBookmarkPathBuffer(){ return gBookmarkPath; }
void	impNativeSetHeapSize(int nHeapSize){ gHeapSize = nHeapSize; }
void	impNativeSetExternNumOfAvailableCores(int core)
{
	if(core > 0)
		gExternNumOfAvailableCores = core;
}

typedef enum
{
	eDecodeToUnicode,
	eEncodeToAscii,

	eImplementCallBacksMax
}eImplement_CALLBACKS;

JNINativeCallBackMethod gImplementCallBacks[] = {
	{"DecodeToUnicode", "(ILjava/nio/ByteBuffer;)Ljava/lang/String;", NULL},
	{"EncodeToAscii", "(ILjava/lang/String;[B)V", NULL},
};

static jobject gConvObj = NULL;
static jclass gConvClass = NULL;

int registerConversionCallBack(JNIEnv* env, jobject iconv)
{
	gConvObj = env->NewGlobalRef(iconv);
	
	jclass clazz_local = env->GetObjectClass(iconv);
	
	if (clazz_local == NULL) {
		ui_debug("implementNative.cpp [%d] registerConversionCallBack unable to find class", __LINE__);
		return JNI_FALSE;
	}
	else	{
		/* Create a global reference */
        	gConvClass = (jclass)env->NewGlobalRef(clazz_local);

		/* The local reference is no longer useful */
     		env->DeleteLocalRef(clazz_local);
	}


	
	int callback_count =  sizeof(gImplementCallBacks) / sizeof(gImplementCallBacks[0]);
	if(callback_count != eImplementCallBacksMax)
	{
		ui_debug("implementNative.cpp [%d] registerConversionCallBack count missmatch", __LINE__);
		return JNI_FALSE;
	}
		
	for(int i=0;i<eImplementCallBacksMax;i++)
	{
		gImplementCallBacks[i].fnPtr = env->GetMethodID(gConvClass, gImplementCallBacks[i].name, gImplementCallBacks[i].signature);		
		if (gImplementCallBacks[i].fnPtr == NULL) 
		{
			ui_debug("implementNative.cpp [%d] Can't find PlatformLibrary. [%d]\n", __LINE__, i);
			return JNI_FALSE;
		}	
	}
	
	//ui_debug("implementNative.cpp [%d] registerConversionCallBack numMethods '%d'", __LINE__, callback_count);
	return JNI_TRUE;
}
//
//////////////////////////
//// platform
//
//// ���� ��� ������ core���� ������ �Լ�
#ifdef SUPPORT_MULTICORE
int BGetNumOfAvailableCores()
{
	if(gExternNumOfAvailableCores > 0)
		return gExternNumOfAvailableCores;
#ifdef BASED_WINDOWS_SYSTEM
	SYSTEM_INFO sysinfo;
	GetSystemInfo(&sysinfo);
	return sysinfo.dwNumberOfProcessors;
#else
	return get_nprocs ();
#endif
}

#endif // SUPPORT_MULTICORE

long	BGetAvailableMemSize(void)
{
	long	size = (1024*1024*gHeapSize);
	return (long)(size);
}

static char gFontFolderPath[PATH_MAX] = "";
void setFontFolderPath(const char* path)
{
	strcpy(gFontFolderPath, path);
}
void setTempFolderPath(char* path)
{
	strcpy(gTempPath, path);
}

#define FONTLIST_SIZE 500 	
char gFontPaths[FONTLIST_SIZE][BORA_FULLPATH_LENGTH] = {0,};
int gnFontCount = 0;
void BGetSystemFont(int *nTotalCount, BrFontType nType[], unsigned char* pFont[], unsigned int nSize[])
{
#ifdef LINUX_LIB
#include <dirent.h>
	//char* fontDirPath = "/usr/share/fonts/truetype/";
	DIR* fontDir;
	struct dirent* entry;
	fontDir = opendir(gFontFolderPath);
	if(fontDir){
		int fontCount = 0;
		while((entry = readdir(fontDir)) != NULL){
			if(strstr(entry->d_name,".ttf") || strstr(entry->d_name,".TTF") ||
				strstr(entry->d_name,".ttc") || strstr(entry->d_name,".TTC") ||
				strstr(entry->d_name,".otf") || strstr(entry->d_name,".OTF")){
				sprintf(gFontPaths[fontCount],"%s/%s",gFontFolderPath, entry->d_name);
				nType[fontCount] = FONTTYPE_FILE;
				nSize[fontCount] = 0;
				pFont[fontCount] = (unsigned char*)&gFontPaths[fontCount];
				fontCount++;
			}
		}
		*nTotalCount = fontCount;
		if(fontCount == 0)
			PRINTERROR("font not found");
		closedir(fontDir);
	}
	else{
		PRINTERROR("%s fontfolder not found", gFontFolderPath);
	}

	DIR* tempDir;
	tempDir = opendir(gTempPath);
	if(!tempDir)
		PRINTERROR("%s tempfolder not found", gTempPath);
	else
		closedir(tempDir);
	return;
#endif
	if(gnFontCount == 0)
	{
		//*nTotalCount = 0;
		memset(gFontPaths, 0x0, sizeof(gFontPaths));

		JNIEnv* env = getJNIEnv();
		jobjectArray fontPaths = BNativeGetSystemFontPathArray(env);
		jsize arraySize = env->GetArrayLength(fontPaths);

		*nTotalCount = arraySize;

		int nFontCount = 0;
		char pFontPath[BORA_FULLPATH_LENGTH] = {0,};
		for(jsize i=0;i<arraySize;i++)
		{
			memset(pFontPath, 0, sizeof(pFontPath));
			
			jstring fontPath = (jstring)env->GetObjectArrayElement(fontPaths, i);
			CopyJstring2Utf8(env, pFontPath, fontPath, sizeof(pFontPath));
			env->DeleteLocalRef(fontPath); // is this correct??
#ifdef BASED_WINDOWS_SYSTEM
			if ( _access((const char*)pFontPath, 0)==0 )
#else
			if ( access((const char*)pFontPath, 0)==0 )
#endif
			{
				memcpy(gFontPaths[nFontCount], pFontPath, strlen(pFontPath));
				nType[nFontCount] = FONTTYPE_FILE;
				nSize[nFontCount] = 0;
				pFont[nFontCount] = (unsigned char*)&gFontPaths[nFontCount];
				//ui_debug("add multifont[%d] = %s\n", i, gFontPaths[i]);
				nFontCount++;
				if ( nFontCount == FONTLIST_SIZE )
					break;
			}
		}

		*nTotalCount = nFontCount;
		gnFontCount = nFontCount;
	}
	else
	{
		for(jsize i = 0; i < gnFontCount; i++)
		{
			nType[i] = FONTTYPE_FILE;
			nSize[i] = 0;
			pFont[i] = (unsigned char*)&gFontPaths[i];
		}
		*nTotalCount = gnFontCount;
	}
}

// CMap ������ ��Ʈ�������� "CMap"�̶�� �̸��� ������ �����ؾ���.
static char gPDFFontPath[PATH_MAX] = "";
void*	BGetPDFFontFilePath(char *pathName)
{
	char* pdfFontFolderName = "CMap";
	if(strlen(gPDFFontPath) == 0){
		char fontFolderPath[PATH_MAX] = "";
		strcpy(fontFolderPath, gFontPaths[0]);
		char separator = '/';
#ifdef BASED_WINDOWS_SYSTEM
		separator = '\\';
#endif
		char* separatorPos = strrchr(fontFolderPath,separator);
		*separatorPos = '\0';
		sprintf(gPDFFontPath,"%s%c%s%c", fontFolderPath, separator, pdfFontFolderName, separator);
	}
	return (void*)gPDFFontPath;
}

// Memo, Print ����� ����ϴ� ���(�ε��� ������ �ִ� ���)
// ���̺귯�� ���ο��� ������ ������ �ϰԵ�
// ���� ������������ ����� mmcapp���� ���� �ʿ� ����
void*	BGetTempPath(void)
{
	return (void*)gTempPath;
}

void*	BGetFavoriteTempPath(void)
{
	//Favorite �̹��� Data ���ϵ� ���� �� �� 
	return (void*)gTempPath;
}

char* BGetBlankImagePath()
{
	return NULL;
}

// �ϸ�ũ ����� ���� ���� ���
// hidden ������ ����
void* BGetBookmarkPath(void)
{
	return NULL;
}

void BOnSheetAutoFilterStartStateCallBack(int nStart) {}

// �޸� ���� interface �Լ�
void*	BMalloc(int size)
{
	return malloc(size);
}

void BFree(void* ptr)
{
	if(ptr)
		free(ptr);
}

void* BMallocEx(int size)
{
	return malloc(size);
}

void BFreeEx(void* ptr)
{
	if(ptr)
		free(ptr);
}

void* BFileMapMalloc(int size)
{
	return malloc(size);
}

void BFileMapFree(void* ptr)
{
	if(ptr)
		free(ptr);
}

void* BMmemmove( void *dest, void *src, int count )
{
	return memmove(dest, src, count);
}

void* BRealloc(void* memblock, int size)
{
	return realloc(memblock, size);
}

char* toLocaleStringFromUTF8(const char* pStr)
{
#define CP_UTF8 65001
#define CP_ACP  0

	//convert widechar
	int cbMultiByte = strlen(pStr);
	int cchWideChar = cbMultiByte + 1;
	char *lpMultiByteStr = NULL;
	unsigned short *lpWideStr = (unsigned short *)calloc(cchWideChar, sizeof(unsigned short));	
	int nWideLen = BMultiByteToWideChar( CP_UTF8, pStr, cbMultiByte, lpWideStr, cchWideChar);
	if ( nWideLen > 0 )
	{
		lpWideStr[nWideLen] = '\0';
			
		cbMultiByte = (nWideLen+1) * 4;
		lpMultiByteStr = (char*)calloc( cbMultiByte, sizeof(char));
		int	nMultiLen = BWideCharToMultiByte( CP_ACP, (const unsigned short *)lpWideStr, cchWideChar, lpMultiByteStr,  cbMultiByte );
		if ( nMultiLen > 0 )
			lpMultiByteStr[nMultiLen] = '\0';	
	//	BTrace("%s(%d) %s fopen(%s, %s)= %x", __FILE__, __LINE__, __FUNCTION__, lpMultiByteStr, in_mode, pF);		
	}
	free(lpWideStr);	
	return lpMultiByteStr;;
}

void* BFopen(const char* pFilePath, const char *in_mode)
{
	ui_debug("%s(%d) %s pFilePath[%s] in_mode[%s]", __FILE__, __LINE__, __FUNCTION__, pFilePath, in_mode);
#ifdef _UNICODE
	wchar_t* pFileName = UTF8ToCString(pFilePath);
	wchar_t* pFileMode = UTF8ToCString(in_mode);
	void* pF = _wfopen(pFileName, pFileMode);
	delete pFileName;
	delete pFileMode;
	return pF;
#else
	void* pF = fopen(pFilePath, in_mode);
	ui_debug("%s(%d) %s pF[%p]", __FILE__, __LINE__, __FUNCTION__, pF);
	if ( pF )
		return pF;

	char* szFile = toLocaleStringFromUTF8(pFilePath);
	pF = fopen(szFile, in_mode);
	ui_debug("%s(%d) %s fopen(%s, %s)= %x", __FILE__, __LINE__, __FUNCTION__, szFile, in_mode, pF);
	free(szFile);
	return pF;
#endif	
}

int BFclose(void* pFile)
{
	return fclose((FILE*)pFile);
}

int BFread(void *ptr, int size, int nmemb, void* pFile)
{
	return fread(ptr, size, nmemb, (FILE*)pFile);
}

int BFwrite(const void *ptr, int size, int nmemb, void* pFile)
{
	if( !fwrite(ptr, size, nmemb, (FILE*)pFile) )
		return 0;
	return size*nmemb;
}

int BFflush(void *pFile)
{
	return fflush((FILE*)pFile);
}

int	BFerror(void* pFile)
{
	// error return�� PC version�� �����ϰ� ����
	return -1;
	//return errno;
}

int BFseek(void* pFile, long pos, int type)
{
	if( fseek((FILE*)pFile, pos, type) )
		return -1;
	return 0;
}

int BFseek64(void* pFile, long long pos, int type)
{
	return BFseek(pFile, pos, type);
}

int BFtell(void* pFile)
{
	return ftell((FILE*)pFile);
}

long long BFtell64(void* pFile)
{
	return BFtell(pFile);
}

int BFgetc(void *hf)
{
	return fgetc((FILE *)hf);
}

int	BFputc(int c, void *hf)
{
	return fputc(c, (FILE *)hf);
}

int Bungetc(int c, void *hf)
{
	return ungetc(c, (FILE *)hf);
}

void BGetFileInfo(char* szName, int *nSize, int *szModified)
{
#ifdef _UNICODE
	wchar_t* pFileName = UTF8ToCString(szName);
	struct _stat64i32 st;
	int nRet = _wstat64i32(pFileName, &st);
	delete pFileName;
#else
	struct stat st;
	int nRet = stat(szName, &st);
	if ( nRet != 0 )
	{
		char* szFile = toLocaleStringFromUTF8(szName);
		nRet = stat(szFile, &st);
		free(szFile);
	}
#endif
	if ( nRet == 0 )
	{
		*nSize = (long)st.st_size;
		*szModified = (long)st.st_mtime;
	}
}

int BMakeDirectory(char* pDir)
{
#ifdef BASED_WINDOWS_SYSTEM
#ifdef _UNICODE
	wchar_t* pFileName = UTF8ToCString(pDir);
	int err = _wmkdir( pFileName );
	delete pFileName;
#else
	int err = _mkdir( pDir );
#endif 
#else
	int err = mkdir( pDir, 0777);
	if ( err != 0 )
	{
		char* szFile = toLocaleStringFromUTF8(pDir);
		err = mkdir( szFile, 0777);
		free(szFile);
	}
#endif 
	if(  err== 0 )
		return 1;
	else if (errno == EEXIST)
		return 1;

	return 0;
}

bool	BFileLock(bool bLock){	return true;}

int BGetFileInfoEx(char* szName, unsigned int* pAtt, int *pSize, int *pModified)
{
#ifdef _UNICODE
	wchar_t* pFileName = UTF8ToCString(szName);
	struct _stat64i32 statbuf;
	int nRet = _wstat64i32(pFileName, &statbuf);
	delete pFileName;
#else
	struct stat statbuf;
	int nRet = stat(szName, &statbuf);
	if ( nRet != 0 )
	{
		char* szFile = toLocaleStringFromUTF8(szName);
		nRet = stat(szFile, &statbuf);
		free(szFile);
	}
#endif
	if( nRet == 0)
	{
		if(pSize)
			*pSize = (long)statbuf.st_size;
		if(pModified)
			*pModified = (long)statbuf.st_mtime;
		if(pAtt)
		{
			*pAtt = BR_FATT_NORMAL;
			if(statbuf.st_mode & S_IFDIR)
				*pAtt = BR_FATT_DIR;
			//if(!(statbuf.st_mode & S_INHID))
			//	*pAtt |= BR_FATT_HIDDEN;
			if(!(statbuf.st_mode & S_IWRITE) && (statbuf.st_mode & S_IREAD))
				*pAtt |= BR_FATT_READONLY;
		}
		return 1;
	}	

	return 0;	
}
#ifdef SUPPORT_ZLIB_MEMORY_OPEN
#include "zlib/zlib.h"
#define SYSEM_MEMORY_ERROR		101;
#define SYSEM_FILE_ERROR		102;
void* GetZlibBuffer(char* a_szFilePath, int* pResult, unsigned long* pBufferSize)
{
	int nDocumentSize = 0;
	int nModify = 0;
	BGetFileInfo(a_szFilePath, &nDocumentSize, &nModify);
	if(0 == nDocumentSize)
	{
		*pResult = SYSEM_FILE_ERROR;
		return NULL;
	}

	void* pDocumentBuffer = malloc(nDocumentSize);
	if(NULL == pDocumentBuffer)
	{
		*pResult = SYSEM_MEMORY_ERROR;
		return NULL;
	}

	gzFile pFile = gzopen(a_szFilePath, "rb");
	if(NULL == pFile)
	{
		*pResult = SYSEM_FILE_ERROR;
		return NULL;
	}

	gzread(pFile, pDocumentBuffer, nDocumentSize);
	unsigned long nOutputSize = (unsigned long)(nDocumentSize * 1.5);

	void* pOutBuffer = NULL;
	int err = Z_ERRNO;
	while(true)
	{
		pOutBuffer = malloc(nOutputSize);
		if(NULL == pOutBuffer)
		{
			*pResult = SYSEM_MEMORY_ERROR;
			return NULL;
		}

		err = uncompress((unsigned char*)pOutBuffer,&nOutputSize,(unsigned char*)pDocumentBuffer,nDocumentSize);
		if(Z_OK == err)
			break;
		else if(Z_BUF_ERROR == err)
		{
			nOutputSize *= 2;
			free(pOutBuffer);
			pOutBuffer = NULL;
		}
		else
		{
			nOutputSize = 0;
			free(pOutBuffer);
			pOutBuffer = NULL;
			break;
		}
	}
	*pResult = err;
	*pBufferSize = nOutputSize;
	gzclose(pFile);
	free(pDocumentBuffer);
	pDocumentBuffer = NULL;
	return pOutBuffer;
}
#endif

#if 0
#include "zlib/zlib.h"

void* TestZlib(unsigned long* pSize)
{
	//if(false)
	//{
	//	unsigned char* inbuf;
	//	unsigned char* outbuf;
	//	
	//	unsigned long INBUFSIZE;
	//	unsigned long OUTBUFSIZE;
	//	
	//	
	//	long size = 0;
	//	long modi = 0;
	//	BGetFileInfo("E:\\11.docx", &size, &modi);
	//	if(0 == size)
	//		return;

	//	INBUFSIZE = size;
	//	inbuf=new unsigned char[INBUFSIZE];

	//	FILE* f = fopen("E:\\11.docx", "rb");

	//	fread(inbuf, INBUFSIZE, 1, f);
	//	fclose(f);

	//	//strcpy((char*)inbuf,"1234567890_ABCDEF...Z");
	//	//INBUFSIZE=strlen((char*)inbuf)+1;

	//	//Upon entry, destLen is the total size of the destination buffer, 
	//	//which must be at least 0.1% larger than sourceLen plus 12 bytes.
	//	
	//	//Integer�� �ݿø� ���� ������ 1�� ���ߴ�. 
	//	OUTBUFSIZE=(unsigned long)1.001*(INBUFSIZE+12) + 1;
	//	outbuf=new unsigned char[OUTBUFSIZE];
	//	memset(outbuf, 0, OUTBUFSIZE);

	//	int err=compress2(outbuf, &OUTBUFSIZE, inbuf, INBUFSIZE, Z_DEFAULT_COMPRESSION);
	//	if( err==Z_OK )
	//	{
	//		//gzFile file = gzopen("E:\\zlibex.zlib", "wb");
	//		//gzwrite(file, outbuf, OUTBUFSIZE);
	//		//gzclose(file);
	//		FILE* file = fopen("E:\\zlibex1.zlib", "wb");
	//		fwrite(outbuf, OUTBUFSIZE, 1,  file);
	//		fclose(file);
	//	}

	//}

	//if(true)
	//{
		long size = 0;
		long modi = 0;
		BGetFileInfo("E:\\zlibdoc", &size, &modi);
		if(0 == size)
			return NULL;
		
		void* buffer = malloc(size);
		gzFile file = gzopen("E:\\zlibdoc", "rb");

		gzread(file, buffer, size);
		unsigned long inputSize = size;
		unsigned long outputSize = size * 2;

		outputSize = size;
		void* outbuffer = NULL;
		while(true)
		{
			outbuffer = malloc(outputSize);
			int err=uncompress((unsigned char*)outbuffer,&outputSize,(unsigned char*)buffer,inputSize);
			if( err==Z_OK )
			{
				break;
			}
			else if(Z_BUF_ERROR == err)
			{
				outputSize *= 2;
				free(outbuffer);
			}
			else
			{
				if(NULL != outbuffer)
				{
					free(outbuffer);
					outbuffer = NULL;
				}
				break;
			}
		}
		gzclose(file);
		free(buffer);
		//if(NULL != outbuffer)
		//	free(outbuffer);
		*pSize = outputSize;
		return outbuffer;
	//}

	//if(false)
	//{
	//	unsigned char* inbuf;
	//	unsigned char* outbuf;
	//	
	//	unsigned long INBUFSIZE;
	//	unsigned long OUTBUFSIZE;
	//	
	//	
	//	inbuf=new unsigned char[1000];
	//	
	//	strcpy((char*)inbuf,"1234567890_ABCDEF...Z");
	//	INBUFSIZE=strlen((char*)inbuf)+1;


	//	//Upon entry, destLen is the total size of the destination buffer, 
	//	//which must be at least 0.1% larger than sourceLen plus 12 bytes.
	//	
	//	//Integer�� �ݿø� ���� ������ 1�� ���ߴ�. 
	//	OUTBUFSIZE=(unsigned long)1.001*(INBUFSIZE+12) + 1;
	//	outbuf=new unsigned char[OUTBUFSIZE];

	//	//in-memory ������ ���� �Լ��� compress()�� compress2()�� �ִ�.
	//	//���⼭�� ���� ������ ���� �� �ִ� compress2()�� ����� ���ڴ�.

	//	//Compression Level�� ������ ���� ���ǵǾ� �ִ�.
	//	//#define Z_NO_COMPRESSION         0
	//	//#define Z_BEST_SPEED             1
	//	//#define Z_BEST_COMPRESSION       9
	//	//#define Z_DEFAULT_COMPRESSION  (-1)
	//	int err=compress2(outbuf, &OUTBUFSIZE, inbuf, INBUFSIZE, Z_DEFAULT_COMPRESSION);

	//	//Compress2�Լ��� ������ ���� ���� �ڵ带 ��ȯ�Ѵ�.
	//	//compress2 returns Z_OK if success, 
	//	//Z_MEM_ERROR if there was not enough memory, 
	//	//Z_BUF_ERROR if there was not enough room in the output buffer
	//	//Z_STREAM_ERROR if the level parameter is invalid

	//	//uncompress returns Z_OK if success, 
	//	//Z_MEM_ERROR if there was not enough memory, 
	//	//Z_BUF_ERROR if there was not enough room in the output buffer, 
	//	//or Z_DATA_ERROR if the input data was corrupted. 
	//	inbuf[0] = NULL;
	//	err=uncompress(inbuf,&INBUFSIZE,outbuf,OUTBUFSIZE);
	//	
	//	delete [] outbuf;
	//	delete [] inbuf;
	//}
}
#endif 

void DeleteDir(char* pPath)
{
#if 0
	int state		= 0;
	char	*file_path	= NULL;

	struct	dirent	*dir_ent;
	DIR 	*dp;

	if ((dp = opendir(pPath)) == NULL)
	{
		ui_debug("error opendir [%s]", pPath);
		return;
	}

	file_path = (char*)malloc(sizeof(char) * 256);
	while ((dir_ent = readdir(dp)) != NULL)
	{
		if (strcmp(dir_ent->d_name, ".") == 0 || strcmp(dir_ent->d_name, "..") == 0)
			continue;

		memset(file_path, 0x00, 256);
		sprintf(file_path, "%s/%s", pPath, dir_ent->d_name);
		state = unlink(file_path);
		if (state != 0)
			ui_debug("can't delete file [%s]", file_path);
	}

	free(file_path); 
	closedir(dp);
	state = rmdir(pPath);
	if (state != 0)
		ui_debug("can't delete [%s]", pPath);

	ui_debug("DeleteDir Success [%s]\n", pPath);
#endif		
}

int BDeleteDirectory(char* pDir)
{
	if (pDir != NULL) {
		DeleteDir(pDir);
	}

	return 1;
}

#ifdef BASED_WINDOWS_SYSTEM
void UnixTimeToFileTime(time_t t, LPFILETIME pft)
{
	// Note that LONGLONG is a 64-bit value
	LONGLONG ll;

	ll = Int32x32To64(t, 10000000) + 116444736000000000;
	pft->dwLowDateTime = (DWORD)ll;
	pft->dwHighDateTime = (DWORD)(ll >> 32);
}
#endif

int BSetFileTime(char* szName, unsigned long nLastAccess, unsigned long nLastWrite)
{
	int nRet = 0;
#ifdef BASED_WINDOWS_SYSTEM
#ifdef _UNICODE
	wchar_t* pFileName = UTF8ToCString(szName);
	HANDLE hfile = CreateFileW(pFileName, GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_ALWAYS, 0, NULL);
	delete pFileName;
#else
	HANDLE hfile = CreateFile(szName, GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_ALWAYS, 0, NULL);
#endif
	if(hfile != INVALID_HANDLE_VALUE)
	{
		FILETIME act, modt;//, cur_time;
		FILETIME *pAct= NULL, *pModt = NULL;

		if(nLastAccess)
		{
			UnixTimeToFileTime(nLastAccess, &act);
			pAct = &act;
		}

		if(nLastWrite)
		{
			UnixTimeToFileTime(nLastWrite, &modt);
			pModt = &modt;
		}

		if(SetFileTime(hfile, (LPFILETIME) NULL, pAct, pModt))
			nRet = 1;

		CloseHandle(hfile);
	}
#endif 

	return nRet;
}

void BGetSystemTime(int *nYear, int *nMonth, int *nDay, int *nWday, int *nHour, int *nMinute, int *nSecond)
{
	time_t ltime;
	struct tm *today;
	time(&ltime);
	if ( today = localtime(&ltime))
	{
		if(nYear)
			*nYear = today->tm_year + 1900;
		if(nMonth)
			*nMonth = (int)today->tm_mon;
		if(nDay)
			*nDay = (int)today->tm_mday;
		if(nWday)
			*nWday = (int)today->tm_wday;
		if(nHour)
			*nHour = (int)today->tm_hour;
		if(nMinute)
			*nMinute = (int)today->tm_min;
		if(nSecond)
			*nSecond = (int)today->tm_sec;
	}
}
  
int BIsDRMDocumentSupport(const char* a_pStrPath)
{
	return 0;
}

void	BGet_ImagePlaceHolder_DefaultImage(LPBoraBitmapBuffer pBoraBitmapBuffer)
{
}

// File system���� ���� ���½� file id�� 0������ �����ϴ� ��� ���
int BUseZeroFileID(void)
{
	return 0;
}

bool BRemoveProtectFrame()
{
	return true;
}

// for DRM file open
int BGetFileExtOnDRM(char* szFilePath, char* szFileName, char* szFileExt)
{
	return 0;
}

void* BFopen_DRM(const char* pFilePath, const char *in_mode)
{
//#ifdef _UNICODE
//	wchar_t* pFileName = UTF8ToCString(pFilePath);
//	wchar_t* pFileMode = UTF8ToCString(in_mode);
//	void* pF = NULL;
//	if ( pFileName!=NULL && pFileMode!=NULL )
//		pF = _wfopen(pFileName, pFileMode);
//	delete pFileName;
//	delete pFileMode;
//	return pF;
//#else
//	return fopen(pFilePath, in_mode);
//#endif
	return BFopen(pFilePath, in_mode);
}

int BFclose_DRM(void* pFile)
{
	return fclose((FILE*)pFile);
}

int BFread_DRM(void *ptr, int size, int nmemb, void* pFile)
{
	return fread(ptr, size, nmemb, (FILE*)pFile);
}

int BFwrite_DRM(const void *ptr, int size, int nmemb, void* pFile)
{
	if( !fwrite(ptr, size, nmemb, (FILE*)pFile) )
		return 0;
	return size*nmemb;
}

int BFseek_DRM(void* pFile, long pos, int type)
{
	if( fseek((FILE*)pFile, pos, type) )
		return -1;
	return 0;
}

int BFseek64_DRM(void* pFile, long long pos, int type)
{
	return BFseek_DRM(pFile, pos, type);
}

int BFtell_DRM(void* pFile)
{
	return ftell((FILE*)pFile);
}

long long BFtell64_DRM(void* pFile)
{
	return BFtell_DRM(pFile);
}

int BFSetEOF_DRM(void *hf)
{
	return 0;
}

jobjectArray IGetSheetNameList(JNIEnv* env)
{
	jint count = BrGetSheetCount();
	int nSize = BORA_SHEETNAME_LENGTH*3+1;
	jobjectArray stringArray =  NULL;
	char** nameList =  (char**)malloc(count * sizeof(char*));

	if(nameList) {

		for(int i=0;i<count;i++) {
			nameList[i] = (char*)malloc(nSize);
			memset(nameList[i], 0x0, nSize);
		}

		BrGetSheetNameList((char**)nameList);
		stringArray =  MakeStringArray(env, nameList, count);

		for(int i=0;i<count;i++)
			free(nameList[i]);
		free(nameList);
	}

	return stringArray;
}

#define CP_ACP 0
#define CODE_PAGE_MAX_LEN 32
#define DEFAULT_LOCALE BR_LOCALE_KOREAN
#define DEFAULT_CODEPAGE_NUM CP_KSC5601
#define DEFAULT_CODEPAGE_STR "windows-949"
//
static char gszDefaultCodePage[CODE_PAGE_MAX_LEN] = DEFAULT_CODEPAGE_STR;
static BR_LOCALE_TYPE gLocaleType = DEFAULT_LOCALE;
static BR_LOCALE_TYPE gSysLocaleType = DEFAULT_LOCALE;
char* getCodePage(int nCodePage)
{
	static char szCodePage[32] = {0,};	
	int nLocale = nCodePage;
	if ( nLocale == CP_ACP )
		return gszDefaultCodePage;

	switch( nLocale )
	{
	case CP_SHIFTJIS:	//�Ϻ���
		strncpy(szCodePage, "cp932", 32);
		break;	
	case CP_KSC5601:	//�ѱ���
		strncpy(szCodePage, "windows-949", 32);
		break;		
	case CP_WINDOWS1250:	//�߾� ������
		strncpy(szCodePage, "cp1250", 32);
		break;
	case CP_WINDOWS1251:	//���þƾ�
		strncpy(szCodePage, "cp1251", 32);	
		break;
	case CP_WINDOWS1252:	//�� ������
		strncpy(szCodePage, "cp1252", 32);		
		break;
	case CP_WINDOWS1253:	//�׸�����
		strncpy(szCodePage, "cp1253", 32);				
		break;
	case CP_WINDOWS1254:	//��Ű��
		strncpy(szCodePage, "cp1254", 32);				
		break;
	case CP_WINDOWS1255:	//���긮��
		strncpy(szCodePage, "cp1255", 32);				
		break;
	case CP_WINDOWS1256:	//�ߵ���
		strncpy(szCodePage, "cp1256", 32);				
		break;
	case 1257:	//�� ������
		strncpy(szCodePage, "cp1257", 32);				
		break;
	case 1258:	//��Ʈ����
		strncpy(szCodePage, "cp1258", 32);				
		break;		
	case CP_IBM420:
		strncpy(szCodePage, "IBM-420", 32);						
		break;
	case CP_IBM424:
		strncpy(szCodePage, "IBM-424", 32);								
		break;
	case CP_KOI8_R:
		strncpy(szCodePage, "koi8-r", 32);										
		break;
	case CP_ISO8859_1:
		strncpy(szCodePage, "ISO-8859-1", 32);												
		break;
	case CP_ISO8859_2:
		strncpy(szCodePage, "ISO-8859-2", 32);
		break;
	case CP_ISO8859_3:
		strncpy(szCodePage, "ISO-8859-3", 32);
		break;
	case CP_ISO8859_4:
		strncpy(szCodePage, "ISO-8859-4", 32);		
		break;
	case CP_ISO8859_5:
		strncpy(szCodePage, "ISO-8859-5", 32);
		break;
	case CP_ISO8859_6:
		strncpy(szCodePage, "ISO-8859-6", 32);
		break;
	case CP_ISO8859_7:
		strncpy(szCodePage, "ISO-8859-7", 32);		
		break;
	case CP_ISO8859_8:
		strncpy(szCodePage, "ISO-8859-8", 32);		
		break;
	case CP_ISO8859_9:
		strncpy(szCodePage, "ISO-8859-9", 32);		
		break;
	case CP_ISO8859_8_I:
		strncpy(szCodePage, "ISO-8859-8-I", 32);		
		break;
	case CP_ISO2022_JP:
		strncpy(szCodePage, "ISO-2022-JP", 32);				
		break;
	case CP_ISO2022_KR:
		strncpy(szCodePage, "ISO-2022-KR", 32);						
		break;
	case CP_ISO2022_CN:
		strncpy(szCodePage, "ISO-2022-CN", 32);								
		break;
	case CP_EUCJP:
		strncpy(szCodePage, "EUC-JP", 32);										
		break;
	case CP_EUCKR:
		strncpy(szCodePage, "EUC-KR", 32);		
		break;
	case CP_GB18030:
		strncpy(szCodePage, "GB18030", 32);		
		break;
	case 65001:
		strncpy(szCodePage, "UTF-8", 32);				
		break; 
	case 850:	//Latin(���Ͼ�, etc,...)
		strncpy(szCodePage, "cp850", 32);				
		break;
	case 863:	//��������
		strncpy(szCodePage, "cp863", 32);					
		break;
	case 865:	//�븣����
		strncpy(szCodePage, "cp865", 32);					
		break;
	case 874:	//�±���
		strncpy(szCodePage, "cp874", 32);						
		break;
	case 936:	//�߱��� (��ü)
		strncpy(szCodePage, "windows-936", 32);						
		break;
	case CP_BIG5:	//�߱��� (��ü)
		strncpy(szCodePage, "windows-950", 32);
		break;

	// english ���� default�� ó��		
	case 437:	//����		
	default:
		strncpy(szCodePage, DEFAULT_CODEPAGE_STR, 32);
		break;
	}

	return szCodePage;
}

void impNativeSetLocale(int a_locale)
{
	BR_LOCALE_TYPE locale = (BR_LOCALE_TYPE)a_locale;
	POSetUserLocale(locale);
	if(gLocaleType == locale)
		return;
	
	gLocaleType = locale;

	int nCodePage;
	switch(locale)
	{
	case BR_LOCALE_JAPANESE: // shift-jis �� �� ���� �����.
		nCodePage = CP_SHIFTJIS;
		break;		
		
	case BR_LOCALE_S_CHINESE:
		nCodePage = 936;	
		break;	

	case BR_LOCALE_KOREAN:
		nCodePage = CP_EUCKR;
		break;
		
	case BR_LOCALE_T_CHINESE_TW:
	case BR_LOCALE_T_CHINESE_HK:
		nCodePage = 950;		
		break;	
		
	case BR_LOCALE_ROMANIAN:
	case BR_LOCALE_POLISH:
	case BR_LOCALE_HUNGARIAN:
	case BR_LOCALE_SERBIAN:
	case BR_LOCALE_SLOVENIAN:
	case BR_LOCALE_CZECH:
	case BR_LOCALE_CROATIAN:
	case BR_LOCALE_SLOVAK:
		nCodePage = CP_WINDOWS1250;		
		break;	

	case BR_LOCALE_RUSSIAN:
	case BR_LOCALE_KAZAKHSTAN:
	case BR_LOCALE_BULGARIAN:
	case BR_LOCALE_MACEDONIAN_FYROM:
	case BR_LOCALE_RUSSIAN_ISRAEL: // ru-Il
		nCodePage = CP_WINDOWS1251;
		break;		
		
	case BR_LOCALE_DANISH:
	case BR_LOCALE_GERMAN:
	case BR_LOCALE_SPANISH:
	case BR_LOCALE_FINNISH:
	case BR_LOCALE_FRENCH:
	case BR_LOCALE_ITALIAN:
	case BR_LOCALE_DUTCH:	// nl-nl
	case BR_LOCALE_NORWEGIAN:	// no-no
	case BR_LOCALE_BRAZILIAN_PORTUGUESE:	// pt-br
	case BR_LOCALE_PORTUGUESE:	// pt
	case BR_LOCALE_CANADIAN_FRENCH: // fr-ca
	case BR_LOCALE_ICELANDIC:
	case BR_LOCALE_SWEDISH:
	case BR_LOCALE_SPANISH_MEXICO:
	case BR_LOCALE_DUTCH_BELGIUM:
	case BR_LOCALE_FRENCH_SWITZERLAND:
	case BR_LOCALE_FRENCH_BELGIUM:
	case BR_LOCALE_GERMAN_SWITZERLAND:
	case BR_LOCALE_ITALIAN_SWITZERLAND:
		nCodePage = CP_WINDOWS1252;
		break;

	case BR_LOCALE_GREEK:
		nCodePage = CP_WINDOWS1253;
		break;	
		
	case BR_LOCALE_TURKISH:
		nCodePage = CP_WINDOWS1254;		
		break;	
		
	case BR_LOCALE_HEBREW:
	case BR_LOCALE_HEBREW2:
		nCodePage = CP_WINDOWS1255;		
		break;	

	case BR_LOCALE_ARABIC:
		nCodePage = CP_WINDOWS1256;
		break;	

	case BR_LOCALE_LITHUANIAN:
	case BR_LOCALE_LATVIAN:
	case BR_LOCALE_ESTONIAN:
		nCodePage = 1257;
		break;
		
	case BR_LOCALE_VIETNAMES:
		nCodePage = 1258;
		break;

	// english ���� default�� ó��
	case BR_LOCALE_US_ENGLISH:
	case BR_LOCALE_ENGLISH_AUSTRAILIA:
	case BR_LOCALE_ENGLISH_CANADA:
	case BR_LOCALE_ENGLISH_IRELAND:		
	case BR_LOCALE_UK_ENGLISH:		
	default:
		nCodePage = DEFAULT_CODEPAGE_NUM;
		break;
	}
	
	#ifdef CODE_PAGE_932
		nCodePage = CP_SHIFTJIS;
	#endif
	
	strncpy(gszDefaultCodePage, getCodePage(nCodePage),CODE_PAGE_MAX_LEN);
}

int BMultiByteToWideChar( unsigned int CodePage, const char *lpMultiByteStr, int cbMultiByte, unsigned short *lpWideStr, int cchWideChar )
{	
#ifdef __linux__
#ifdef _DLOPEN_UCNV_
	UErrorCode status = U_ZERO_ERROR;
	UConverter *conv;
	int32_t     len;

	char* pCodePage = getCodePage(CodePage);

	conv = ucnv_open(pCodePage, &status);

	len = ucnv_toUChars(conv, (UChar *)lpWideStr, cchWideChar, lpMultiByteStr, cbMultiByte, &status);
	ucnv_close(conv);

	// ui_debug("BMultiByteToWideChar end \n");
	//	ui_debug("pCodePage[%s] input_size[%d], output_size[%d]", pCodePage, strlen(lpMultiByteStr), cchWideChar);
	//	ui_debug("CodePage[%d], lpMultiByteStr[%s], u16len((wchar_t*)lpWideStr)[%d]", CodePage, lpMultiByteStr, u16len((wchar_t*)lpWideCharStr));
	return strlen(lpMultiByteStr);
#else
	return 0;
#endif
#elif defined(__sparc__)
	return 0;
#else
	unsigned int nCodePage = CodePage;//CP_ACP;
	//if (CodePage == CP_ACP)
	//{
	//	if (g_nCodePage != 19)
	//		nCodePage = g_nCodePage;
	//}
	//else if (CodePage == CP_UTF8)
	//{
	//	us32_t nRet = com_convert_utf8_to_unicode((us16_t *)lpWideStr, 
	//		cchWideChar*2,
	//		(void *)lpMultiByteStr, 
	//		cbMultiByte);
	//	return nRet;
	//}
	//else
	//	nCodePage = CodePage;
	return MultiByteToWideChar(nCodePage, 0, lpMultiByteStr, cbMultiByte, (LPWSTR)lpWideStr, cchWideChar);
	//JNIEnv* env = getJNIEnv();
	//jstring wideString;

	//if(CodePage == 65001)
	//{
	//	wideString = env->NewStringUTF(lpMultiByteStr);
	//}
	//else
	//{
	//	jobject byteBuffer = env->NewDirectByteBuffer((void*)lpMultiByteStr, cbMultiByte);
	//	wideString  = (jstring)env->CallObjectMethod(gConvObj, gImplementCallBacks[eDecodeToUnicode].fnPtr, CodePage, byteBuffer);
	//	env->DeleteLocalRef(byteBuffer);
	//}

	//jint len = env->GetStringLength(wideString);	
	//const jchar* pUCode = env->GetStringChars(wideString, NULL); 

	//memcpy(lpWideStr, pUCode, len*sizeof(jchar));

	//env->ReleaseStringChars(wideString, pUCode);	
	//env->DeleteLocalRef(wideString);

	//return len;
#endif
}

int	BWideCharToMultiByte( unsigned int CodePage, const unsigned short *lpWideCharStr, int cchWideChar, char *lpMultiByteStr, int cbMultiByte )
{	
#ifdef __linux__
#ifdef _DLOPEN_UCNV_
	UErrorCode status = U_ZERO_ERROR;
	UConverter *conv;
	int32_t     len;
	char* pCodePage = getCodePage(CodePage);

	conv = ucnv_open(pCodePage, &status);

	len = ucnv_fromUChars(conv, lpMultiByteStr, cbMultiByte, (UChar *)lpWideCharStr, cchWideChar, &status);
	ucnv_close(conv);
	return strlen(lpMultiByteStr);
#else
	return 0;
#endif
#elif defined(__sparc__)
	return 0;
#else
	unsigned int nCodePage = CodePage;//CP_ACP;
	//if (CodePage == CP_ACP)
	//{
	//	if (g_nCodePage != 19)
	//		nCodePage = g_nCodePage;
	//}
	//else
	//	nCodePage = CodePage;
	return WideCharToMultiByte(nCodePage, 0, (LPCWSTR)lpWideCharStr, cchWideChar, lpMultiByteStr, cbMultiByte, NULL, NULL);
	//JNIEnv* env = getJNIEnv();
	//jstring wideString = env->NewString((jchar*)lpWideCharStr, cchWideChar);

	//if(CodePage == 65001)
	//{
	//	const char* pMCode = env->GetStringUTFChars(wideString, NULL);
	//	strncpy(lpMultiByteStr, pMCode , cbMultiByte);
	//	env->ReleaseStringUTFChars(wideString, pMCode);		
	//}
	//else
	//{
	//	jbyteArray byteBuffer = env->NewByteArray(cbMultiByte);
	//	env->CallVoidMethod(gConvObj, gImplementCallBacks[eEncodeToAscii].fnPtr, CodePage, wideString, byteBuffer);
	//	char* pMCode = (char*)env->GetByteArrayElements(byteBuffer, NULL);
	//	strncpy(lpMultiByteStr, pMCode , cbMultiByte);		
	//	//strcpy(lpMultiByteStr, (char*)pMCode);

	//	env->ReleaseByteArrayElements(byteBuffer, (jbyte*)pMCode, NULL);
	//}

	//env->DeleteLocalRef(wideString);	

	//return strlen(lpMultiByteStr);
#endif
} 

void BOnSetFormulaSelectionEnabled(int nEnabled)
{

}

void createTotalsRowMenuDlg( BrFilterMenus& a_rMenus )
{

}

void createDataValidationMenuDlg( BrFilterMenus& a_rMenus )
{

}

void BOnSheetDataValidationError(int nErrorStyle, char* strErrorTitle, char* strError) 
{
	
}

void BOnSheetDataValidationMenu(BrFilterMenus* a_pFilterMenus)
{
	createDataValidationMenuDlg(*a_pFilterMenus);
}

void BOnSheetAutoFilterStatusChanged(int evStatus) {}
void BOnSheetAutoFilterMenu(BrFilterMenus* menus){}
void BOnSheetAutoFilterIndexCellRect(BrFilterMenus* menus) {}
void BOnSheetAutoFilterContext(BoraPoint2 oAutoFilterRange, BoraPoint2 oIndexRange, BoraPoint2 oDataRange, BoraPoint2 oStartRange) {}


//USE_SHEET_PIVOT_TABLE_2017
void BOnSheetPivotTableInDocument(bool bExistPivotTableInDocument, bool bExistPivotTableInCurrentSheet) {}
void BOnSheetPivotSelected(bool a_bSelected, bool a_bNotSupportEdit, bool a_bHideFieldList) {}
void BOnSheetPivotFieldListInfoChanged() {}
void BOnSheetGetPivotFieldListInfo(LPBrPivotTableFieldListInfo a_pInfo) {}
void BOnSheetPivotPageFilterSelected(LPBoraIRect a_pRect, int a_nPageFieldIndex, LPBrPivotPageFilterInfo a_pInfo) {}
void BOnSheetPivotRCFilterSelected(LPBoraIRect a_pRect, LPBrSheetPivotRCFilterButtonInfo a_pRCFilterButtonInfo) {}
int BOnSheetPivotNotification(enumBrPivotTableNotificationType a_nNotiType) { return 0; }
int	BOnSheetGetResImagePathLen(enumBrSheetResImage a_eImageType) { return 0; }
bool BOnSheetGetResImagePath(enumBrSheetResImage a_eImageType, char* pImagePath) { return false; }
void BOnSheetPivotTableContextTabActiveInfo(BrSheetPivotTableContextTabInfo* a_ArrInfo, int a_ArrInfoCount) {}
void BOnSheetPivotTableOptionInfo(BrSheetPivotTableOption* a_pOptionInfo) {}
void BOnSheetPivotTableFieldSettingInfo(BrSheetPivotTableSetting_Field* a_pPivotFieldInfo) {}
void BOnSheetPivotTableDataFieldSettingInfo(BrSheetPivotTableSetting_DataField* a_pDataFieldInfo) {}
//USE_SHEET_PIVOT_TABLE_2017



void BOnOLEFormatInfo(int nOleExtensionType, char* pFileName)
{

}

void BOnSheetEditBlock()
{

}

void BOnSheetDynamicLoading(int nVal)
{

}

void BOnSheetCircularReferenceWarning()
{

}

void BOnSheetProtectionSheetCannotEdit(int nCellCannotEditType)
{

}

void BOnSheetDataTableChangePart()
{

}

void BOnSheetArrayChangePart()
{

}

#ifdef SHEET_USE_SCROLLOFFSET
bool BGetSheetScrollOffset(unsigned int* a_pOffsetX, unsigned int* a_pOffsetY) 
{
	return false;
}
#endif

void BOnSheetNextCommentSearchFinish()
{

}

void BOnSheetPrevCommentSearchFinish()
{

}

void BOnSheetFilterCommandResult(int nFilterCommandResult)
{

}

void BOnSheetCellMoveCommandResult(int nCellMoveResult )
{

}

void BOnSheetStatusBarFuncData(BrStatusBarFuncData* rStatusBarFuncData)
{

}

void BOnSheetHyperlinkTooltip( BrHyperlinkTooltip* rTooltipData  )
{

}

void BOnSheetInsertDeleteCellResult(int nCellInsertDeleteResult )
{

}

void BOnSheetTableTotalsRowMenu(BrFilterMenus* pMenus )
{
	createTotalsRowMenuDlg( *pMenus );
}

void BOnSheetCalculateTimeOver(int timeOverType)
{

}

void BOnSheetClipboardClearResult(int nSheetClipboardClipboardResult )
{
	switch (nSheetClipboardClipboardResult)
	{
	case BR_SHEET_CLIPBOARD_NOT_CLEAR_RESULT:
		break;
	case BR_SHEET_CLIPBOARD_CLEAR_RESULT:
		break;
	default:
		break;
	}
}

void BOnSheetTabColorChangeResult(int nSheetTabColorChangeResult)
{
	switch (nSheetTabColorChangeResult)
	{
	case BR_SHEET_TAB_COLOR_NOT_CHANGE_RESULT:
		break;
	case BR_SHEET_TAB_COLOR_CHANGE_RESULT:
		break;
	default:
		break;
	}
}

void BOnSheetOutlineUndoRedoResult(int nSheetOutlineUndoRedoResult)
{
	switch (nSheetOutlineUndoRedoResult)
	{
	case BR_SHEET_OUTLINE_ROW_UNDO_REDO_RESULT:
		break;
	case BR_SHEET_OUTLINE_COL_UNDO_REDO_RESULT:
		break;
	default:
		break;
	}
}

void BOnSheetCommonErrors(char* psError)
{

}

void BOnSheetOperationState(int nOperation, int nState)
{

}

void BGLTrace(const char* s ,...)
{

}

void impNativeSetPDFWithAnnotation(int bWith)
{ 
	gPDFWithAnnotaion = bWith; 
}

#ifdef SUPPORT_PDF_OUTPUT_IMAGE_WITH_ANNOTATION
bool BGetPDFOutputWithAnnotation()
{
	if(0 == gPDFWithAnnotaion)
		return false;
	return true;
}
#endif

void impNativeSetXlsPageToBitmapMaxRow(int nMaxRow)
{
	if(nMaxRow > 0)
		gXlsPageToBitmapMaxRow = nMaxRow;
}

#ifdef SUPPORT_PRINT_XLS_PAGE_TO_BITMAP_MAXROW
int BGetXlsPageToBitmapMaxRow()
{
	return gXlsPageToBitmapMaxRow;
}
#endif

void BGetEditSymbolSettingInfo(int *bShowEditSymbol, BrEditSymbolShowStateSetting *pState)
{
}

void impNativeSetDividePrintImageHeight(int nHeight)
{
	gDividePrintImageHeight = nHeight;
	if(gDividePrintImageHeight < 0)
		gDividePrintImageHeight = 0;
}

#ifdef SUPPORT_DIVIDE_PRINT_IMAGE
int BGetDividePrintImageHeight()
{
	return gDividePrintImageHeight;
}
#endif

bool IsTextFile(char* a_szFilePath)
{
	if(0 == strcmp(gFileExt, ".txt"))
		return true;

	char *ext = strrchr(a_szFilePath,'.'); 
	if(NULL == ext)
		return false;

	if(0 == strcmp(ext, ".txt"))
		return true;

	return false;
}


void savefile(char* str)
{
	if(NULL == str && NULL == str[0])
		return;
	FILE *p = NULL;
	p = fopen("/data/Po7/guenwoo/Test/0524_TestBuild/logmsg.txt", "a+");
	if(NULL == p)
		return;
	fwrite(str, sizeof(char), strlen(str), p);
	fclose(p);
}

void BTrace(const char* s ,...)
{
#ifdef UI_DEBUG
	static char str[LOG_CONTENTS_LENGTH] = {0, };
	va_list ap;

	va_start(ap, s);
	if (s)
	{
		vsprintf(str, s, ap);
		strcat(str, "\n");
		ui_debug(str);
//		printf(str);
//		savefile(str);
	}
	va_end(ap);
#endif
}


void GiveWarning(PoError e)
{
	// e should not be less than kPoWarn!
}


void AppendFileWrite(char* file, char* str)
{
#if 0
	if(NULL == str && NULL == str[0])
		return;
	FILE *p = NULL;
	p = fopen(file, "a+");
	if(NULL == p)
		return;
	fwrite(str, sizeof(char), strlen(str), p);
	fclose(p);
#endif
}

#ifdef _DEBUG
void BErrorTrace(const char* s ,...)
{
#if 0
	{
		char str[LOG_CONTENTS_LENGTH] = {0, };
		va_list ap;

		va_start(ap, s);
		if (s)
		{
			vsprintf(str, s, ap);
			BTrace(str);
		}
		va_end(ap);
	}
#endif
}

void BThreadTraceUI(const char* s ,...)
{
#if 0
	{
		char str[LOG_CONTENTS_LENGTH] = {0, };
		va_list ap;

		va_start(ap, s);
		if (s)
		{
			vsprintf(str, s, ap);
			BTrace(str);
		}
		va_end(ap);
	}
#endif
}

void BMemoryTrace(const char* s ,...)
{
#if 0
	{
		char str[LOG_CONTENTS_LENGTH] = {0, };
		va_list ap;

		va_start(ap, s);
		if (s)
		{
			vsprintf(str, s, ap);
			BTrace(str);
		}
		va_end(ap);
	}
#endif
}

void BActionTrace(const char* s ,...)
{
#if 0
	{
		char str[LOG_CONTENTS_LENGTH] = {0, };
		va_list ap;

		va_start(ap, s);
		if (s)
		{
			vsprintf(str, s, ap);
			BTrace(str);
		}
		va_end(ap);
	}
#endif
}

void BrTrace(const char* s ,...)
{
#if 0 
	{
		char str[LOG_CONTENTS_LENGTH] = {0, };
		va_list ap;

		va_start(ap, s);
		if (s)
		{
			vsprintf(str, s, ap);
			BTrace(str);
		}
		va_end(ap);
	}
#endif
}
#endif // _DEBUG


char* BGetDocPassword()
{
	return NULL;
}

unsigned int BGetTickCount(void)
{
#ifdef _WIN32
	return GetTickCount();
#else
       struct timeval mytime;
       gettimeofday(&mytime, NULL);
       uint64_t tt = mytime.tv_sec*1000LL + mytime.tv_usec/1000; // calculate milliseconds
       return (unsigned int)tt;
#endif
}

unsigned int BGetElapsedTime(unsigned int nTime)
{
	return (BGetTickCount() - nTime);
}

int BRemove(const char *pFile, bool bFileLock )
{
#ifdef BASED_WINDOWS_SYSTEM
#ifdef _UNICODE
	wchar_t* pFileName = UTF8ToCString(pFile);		
	int nRet = _wunlink( pFileName );
	delete pFileName;
	return nRet;
#else
	return _unlink( pFile );
#endif
#else
	int nRet = remove(pFile) ;
	if ( nRet != 0 )
	{
		char* szFile = toLocaleStringFromUTF8(pFile);
		nRet = remove(pFile) ;
		free(szFile);
	}
	return nRet;
#endif
}

int	BRename( char* pFileName , char* pReName, bool bFileLock )
{
#ifdef _UNICODE
	wchar_t* szFileName = UTF8ToCString(pFileName);		
	wchar_t* szReName = UTF8ToCString(pReName);		
	int nRet = _wrename(szFileName, szReName);
	delete szFileName;
	delete szReName;
	return nRet;
#else
	int nRet = rename( pFileName, pReName );
	if ( nRet != 0 )
	{
		char* szFileName = toLocaleStringFromUTF8(pFileName);
		char* szReName = toLocaleStringFromUTF8(pReName);
		nRet = rename( szFileName, szReName );
		free(szFileName);
		free(szReName);
	}
	return nRet;
#endif
}

int BFileExist( char*  pFileName)
{
	if(pFileName == NULL)
		return 0;
#ifdef _UNICODE
	wchar_t* szFileName = UTF8ToCString(pFileName);		
	int nRet = !_waccess(szFileName, 0);
	delete szFileName;
	return nRet;
#else
	int nRet = access(pFileName, 0);
//	BTrace("%s(%d) %s access(%s, 0)= %x pFileName[%x, %x, %x]", __FILE__, __LINE__, __FUNCTION__, pFileName, nRet, pFileName[0], pFileName[1], pFileName[2]);
	if ( nRet == 0 )
		return 1;

	char* szFileName = toLocaleStringFromUTF8(pFileName);
	
	nRet = access(szFileName, 0);
//	BTrace("%s(%d) %s access(%s, 0)= %x", __FILE__, __LINE__, __FUNCTION__, lpMultiByteStr, nRet);
	free(szFileName);
	return nRet==0?1:0;
//	 FILE *f = fopen(pFileName, "r");  
//	 if (!f) 
//	 {
//		 struct stat   buffer;   
//		 return (stat (pFileName, &buffer) == 0);
//	 }
//	 fclose(f);
#endif
	 return 1;  
}

int	BGetResString(int nStrID, unsigned short* pOutput, int nBuffLen, BR_LOCALE_TYPE nLocale)
{
	return 0;
}

bool BIsDeleteChar(unsigned char bLinkType, unsigned char bSubType)
{
// 	int nRes = IDOK;
// 
// 	if(bLinkType == 2 /*LINKTYPE::TYPESET*/)
// 	{
// 		if(bSubType == 0x01 /*FOOTNOTE_MARK*/)
// 			nRes = AfxMessageBox("���ָ� �����Ͻðڽ��ϱ�?", MB_OKCANCEL);
// 		else if(bSubType == 0x04 /*ENDNOTE_MARK*/)
// 			nRes = AfxMessageBox("���ָ� �����Ͻðڽ��ϱ�?", MB_OKCANCEL);
// 		else if(bSubType == 0x02 || bSubType == 0x08)	// FOOTNOTE_ITEM or ENDNOTE_ITEM
// 			nRes = AfxMessageBox("��ȣ�ֱ⸦ �����Ͻðڽ��ϱ�?", MB_OKCANCEL);
// 	}
// 
// 	if(nRes == IDOK)
// 		return true;

	return false;
}

bool BIsDeleteHWPTypeseChar(unsigned short *pString, BrHWPTypeSetSymbolIndex nIndex, bool bEulPostPosition)
{
	return false;
}

void* BGetPDFExportWaterMarkPath(int page , int width , int height )
{
	return 0;
}


const char* BGetClipboardDirectory()
{
	return "";
}

extern "C" void BChronometryTrace(const char* s ,...)
{

}

void BCoreNotify( int nNotifyCode )
{

}


int BGetPageListCount()
{
	return 0;
}

void BGetPageList(int a_nSlideCount, int *a_pSlidelist)
{

}

#ifdef _DEBUG
typedef struct _tBITMAPINFOHEADER{
    //BrDWORD		biSize;
    //BrLONG		biWidth;
    //BrLONG		biHeight;
    //BrWORD		biPlanes;
    //BrWORD		biBitCount;
    //BrDWORD		biCompression;
    //BrDWORD		biSizeImage;
    //BrLONG		biXPelsPerMeter;
    //BrLONG		biYPelsPerMeter;
    //BrDWORD		biClrUsed;
    //BrDWORD		biClrImportant;
} BrBITMAPINFOHEADER, *LPBrBITMAPINFOHEADER;
typedef struct tagBPoint
{
	//BrINT32		x;
	//BrINT32		y;
} BrPoint, *LPBrPOINT, BrPOINT;
extern "C" void DumpImage(LPBrBITMAPINFOHEADER lpbi, int x, int y, BYTE bEnableAlpha)
{
}
extern "C" void DumpAlphaImage(LPBrBITMAPINFOHEADER lpbi, LPBrBITMAPINFOHEADER lpbm, int x, int y)
{
}
extern "C" void DumpPolyline(BrPoint *pPoint, int *pCount, int nPoly, int nScale, BrCOLORREF color, int offsetx, int offsety)
{
}
extern "C" void DumpPolygon(BrPoint *pPoint, int *pCount, int nPoly, int nScale, BrCOLORREF color)
{
}
extern "C" void DumpRawImage(char *data, int width, int height, int bits, int x, int y)
{
}
extern "C" void DumpMaskImage(LPBrBITMAPINFOHEADER lpbi, int x, int y)
{
}
extern "C" void DumpCropImage(LPBrBITMAPINFOHEADER lpbi, int x, int y, BYTE bEnableAlpha, int sx, int sy, int cx, int cy) 
{
}
#endif

int BGetLocale()
{
	return (int)gLocaleType;
}

int BGetSysLocale()
{
	return (int)gSysLocaleType;
}

bool BGetXlsFuncNameListConsiderLocale(char** a_ppNameList, int a_nFuncNameCount)
{
	return false;// �ٸ� Locale ������ ���� ��� False�� ó���ϸ� �������� �⺻ ���� �Է�.

}

void BSpellCheck(unsigned short *pWordStr, int nLen, unsigned char bClass, int nPageNum, int nObjectID, int nNoteNum, int nParaIndex, int  nColIndex, int bDraw)
{

}

void BOnAllFindStart(int a_nListSize)
{

}

void BSendTrackReviewModeInfo(int nReviewMode)
{

}

void BSleep(unsigned long milisec)
{
#ifdef _WIN32
	Sleep((DWORD)milisec);
#endif //_WIN32
}

/*
void* BGetDefaultFontName(char* pFontName)
{
	strcpy(pFontName, "Arial");
	return NULL;
}
*/
char* BGetDefaultFontName(BrEditModeType nDocType, bool bEnglish)
{
	static char pFontName[1024] = {0,};
	if ( nDocType == EDITOR_SHEET )
	{
		strcpy(pFontName, "Arial");
	}
	else
		strcpy(pFontName, "Malgun Gothic");	

	return pFontName;
}

void * BGetDefaultLineSp(float* pLineSp)
{
	return NULL;
}

void* BGetDefaultFontSize( float* pFontSize)
{
	*pFontSize = 11;
	return NULL;
}

bool BIsShowDiffEditingSymbol() {return 0;}

char** BDefaultFontList(int* nCount) {return NULL;}

void BOnSetOLEFramePath(char* pPath)
{

}

void BOnShowKeypad()
{

}

void BOnSetRangeInputFieldText(char *pText)
{

}

int BOnGetTextFontList(BrSheetCellMultiFormat **pList)
{
	return 0;
}

int	BOnGetFormulaFieldTextLen()
{
	return 0;
}

/* r49551���� ���ŵ�
void BSendSheetResultToUI ( BrSheetResult* a_pResult ) 
{

}
*/

void BAttachCurrentThread(void* pInterfaceHandle)
{
	attachCurrentThread();
}

void BDetachCurrentThread()
{
	detachCurrentThread();
}

void BOnSetFormulaFieldSelection(int nStartPos, int nEndPos)
{

}

int BOnGetFormulaFieldText(char* pText)
{
	return 0;
}

void BOnGetFormulaFieldSelection(int* nStartPos, int* nEndPos)
{

}

void BOnSetFormulaFieldText(char* pText, unsigned char bOnlyFormulaField)
{

}

void BOnSetNameBoxText(char* pText)
{

}

void BOnEndDataRange()
{

}

void BOnSetDataRange(const char* a_pDataRange, const char *a_pData)
{

}

bool BGetRevisionFormatElementsRes(int text_res_size, unsigned short **text_res, int para_res_size, unsigned short **para_res, int &locale)
{
	return true;
}

#ifdef SUPPORT_MULTISHEET_INPUTFIELD
void BOnGetMultiSheetTabInfo(BrMultiSheetTabInfo* pMultiSheetTabInfo)
{
	pMultiSheetTabInfo->nMultiSheetCount = 0;
}
#endif	// SUPPORT_MULTISHEET_INPUTFIELD
int BOnGetSystemTimeLength(int nHour, int nMinute, double nSecond)
{
	return 0;
}

int BOnGetSystemDateLength(int nYear, int nMonth, int nDay)
{
	return 0;
}

int	BOnGetSystemTime(char* pTimeStr)
{
	return 0;
}

int BOnGetSystemLongDate(char* pDateStr)
{
	return 0;
}

int	BGetUserMinZoom(int *nMinZoom)
{
	return 0;
}

void BSetPermission( char* path , int mode , int bRecursive )
{

}

void BModeChange(int preMode, int changeMode, int penMode, int nCurOperation)
{
	return;
}

void* BGetArtBorderResPath()
{
	return NULL;
}

void BOnSetSparkGroupEnable(bool bGroup, bool bRelease)
{

}

void BOnSetSheetProgress(int a_nOperationType, int a_nPercentage)
{

}

void BOnGetSheetWarningCheckUI(IN int a_nOperationType, OUT int* a_pResult)
{	
	/*
	switch (a_nOperationType)
	{
	case BR_SHEET_REMOVE_DATA_CONNECTION_RANGE:
		{
			//Ȯ�� �� ����� �Բ� ���̺��� ����. ��� �� ���Ḹ ����.
			if(BTrace("Include Connected Table. Remove it?", MB_OKCANCEL) == IDOK)
				*a_pResult = BrTRUE;
			break;
		}
	case BR_SHEET_HTML_IMPORT_DATA_OVERFLOW:
		{
			//Ȯ�� �� ����� �Բ� ���̺��� ����. ��� �� ���Ḹ ����.
			if(AfxMessageBox("�����Ͱ� ���� �ð��� �ҿ�˴ϴ�. ����Ͻðڽ��ϱ�?", MB_OKCANCEL) == IDOK)
				*asult = BrTRUE;
			else
				*a_pResult = BrFALSE;
			break;
		}
	case BR_SHEET_TABLE_CONVRT_RANGE_RUNNING_TIME_WARNING:
		{
			//Ȯ�� �� ǥ �ߺ��� �׸� ���� ���� ����
			if(AfxMessageBox("�۾��� �Ϸ��ϴ� �� �ð��� ���� �ɸ� �� �ֽ��ϴ�. ����Ͻðڽ��ϱ�?", MB_OKCANCEL) == IDOK)
				*a_pResult = BrTRUE;
			else
				*a_pResult = BrFALSE;
			break;
		}
	default:
		break;
	}
	*/
}

void BOnSheetGetHiddenRowColList(BrSheetRowColHiddenState* pRowColHiddenState)
{
	int nListSize = pRowColHiddenState->nListSize;
	bool bIsRow = pRowColHiddenState->bIsRow;
}
int BGetSeletedSectionIndex()
{
	return 2;
}
bool BGetDefaultPaperSize(BrDefaultPaperLayout *pDefaultPaperLayout) {return false;}
void BOnSheetStatusBarFilterData(BrStatusBarFilterData* rStatusBarFilterData) {}
void BOnSheetExternalLinkPathUpdateError(BrSheetExternalLinkUpdateError* a_pError) {}
void BOnSheetTabChanged() {  }
void BOnGetExternalSheetNameList(IN BrSheetExternalSheetListInfo* a_pInfo, OUT char** a_pResult) {}
void BOnGetExternalAbsolutPath(IN char* a_pRelativePath, OUT char** a_pAbsolutePath){}
int	BGetCalcDateTime(char* strDate, unsigned short* pOutput) { return 0; }
#ifdef USE_HWP_CONTROL
//Pasoo DRM DesFile Packing
bool	BPackContent_DRM(void* a_pSrcFile, void* a_pDesFile)
{
	return true;
}
#endif	//USE_HWP_CONTROL

void	BOnSheetDataConnectionRefreshInterval(int a_nId, int a_nInterval, bool a_bInterval) {}
void BOnSheetDataConnectionRecursiveResult(BrSheetDataConnectionRecursiveAccessResult* a_pRecursiveInfo) {}
void BOnSheetDataConnectionAccessTable(short a_nAccessTable) {}
void BOnGetAccessTableInfo(IN char* a_pFileName, IN char* a_pTableName, IN char* a_pFilePath, OUT BrSheetAccessTableInfo* a_rAccessTableInfo) {}

#ifdef XLSX_TEXT_IMPORT_WIZARD
void	BOnGetSheetTextWizard(OUT LPBrGuiTextImportWizardEvent a_pWizard) {}
#endif
int		BOnCompareString(char* a_pValue1, char* a_pValue2, bool a_bIgnoreCase, int a_nLocale) { return -2; }
bool BIsJISUApp(){	return false;}
void BOnGetAppVersion(char* a_pAppVersion){}
bool BIsODTEditorApp(){	return false;}

char* BGetDefaultResFontName(BrResFontName eResName)
{
	static char pFontName[1024] = {0,};
	strcpy(pFontName, "Malgun Gothic");

	return pFontName;
}

int POCBCheckBackupFilePath(const char* pFilePath)
{	
	return 0;
}

bool BReplaceFile(char* pExistingFileName, char* pNewFileName)
{
	bool bRtn = false;
#ifdef _WIN32	
	wchar_t* szExistingFileName = UTF8ToCString(pExistingFileName);
	wchar_t* szNewFileName = UTF8ToCString(pNewFileName);

	bRtn = ReplaceFileW(szExistingFileName, szNewFileName, NULL, 0, NULL, NULL) == TRUE ? true : false;
	delete[] szExistingFileName;
	delete[] szNewFileName;
#endif
	return bRtn;
}

void BGetPDFMemoryUseRange(float* fMin, float* fMax)
{
}
int				BGetButtonSize(int a_nSizeType) { return 0; }
void BOnSheetFormulaErrorPopupMenuPositionInfo(LPBrSheetFormulaErrorPopupMenuPositionInfo a_pFormualErrorPopupMenuPositionInfo) {};

#ifdef __cplusplus
}
#endif
