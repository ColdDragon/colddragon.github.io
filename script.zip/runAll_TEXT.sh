#!/bin/bash

mode=TEXT
test_files=("10Byte.doc" "110221.hwp" "d.pptx" "guide.docx" "pdf-sample1.pdf" "ppt-sample1.ppt" "Symbian.xlsx" "xls-sample1.xls")
for test_file in ${test_files[@]}; do  
	./run.sh $test_file $mode
done