#!/bin/bash

function DosToUnix()
{
	cat $1|tr -d '\015' > $1.sh
	rm $1
	mv $1.sh $1
	chmod +x $1
#	echo "Complete : "$1
}

for filename in `echo *.sh`
do
	DosToUnix $filename
done
