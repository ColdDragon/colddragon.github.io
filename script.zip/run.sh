#!/bin/bash

file_name=$1
mode=$2
result_path=./result
if [ "$mode" == "" ]; then
	mode=PNG
fi
if [ "$file_name" == "" ]; then
	file_name=./guide.docx
else
	result_path=./result_${mode}/${file_name#./*}
	if [ "$mode" == "PDF" ]; then
		result_path=./result_${mode}/${file_name#./*}.pdf
	fi
fi

rm -f pomsg.log
if [ "$mode" == "INFO" ]; then
	java -jar ./PolarisConverter8.jar $mode $file_name $result_path 
else
	java -jar ./PolarisConverter8.jar $mode $file_name $result_path 1280 1280 temp
fi
if [ "$mode" == "PDF" ]; then
	cp -f pomsg.log ${result_path}_pomsg.log
else
	cp -f pomsg.log $result_path/${mode}_pomsg.log
fi