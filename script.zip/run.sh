#!/bin/bash

file_name=$1
mode=$2
result_path=./result
if [ "$mode" == "" ]; then
	mode=PNG
fi
if [ "$file_name" == "" ]; then
	file_name=./guide.docx
else
	result_path=./result/${file_name#./*}
fi

rm -f pomsg.log
if [ "$mode" == "INFO" ]; then
	java -jar ./PolarisConverter8.jar $mode $file_name $result_path 
else
	java -jar ./PolarisConverter8.jar $mode $file_name $result_path 1280 1280 temp
fi
cp -f pomsg.log $result_path/${mode}_pomsg.log
