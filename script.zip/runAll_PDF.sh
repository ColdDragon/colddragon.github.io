#!/bin/bash

rm -rf result_PDF
mode=PDF
test_files=("samples/doc-sample.doc" "samples/hwp-sample.hwp" "samples/ppt-sample.ppt" "samples/xls-sample.xls" "samples/docx-sample.docx" "samples/pdf-sample.pdf" "samples/pptx-sample.pptx" "samples/xlsx-sample.xlsx")
for test_file in ${test_files[@]}; do  
	./run.sh $test_file $mode
done